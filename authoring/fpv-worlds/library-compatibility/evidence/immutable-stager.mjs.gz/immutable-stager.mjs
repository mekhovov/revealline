import assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { readEditionZip } from '/private/tmp/fpv-creator-starters-20261004/publishing/edition-zip.mjs';
const candidate = '/private/tmp/fpv-library-compat-admission-4eeb7bc44',
  output = '/private/tmp/fpv-library-compat-admitted-player-4eeb7bc44',
  reusable = '/tmp/fpv-required-coating-admitted-player-364',
  mutable = '/private/tmp/fpv-creator-starters-20261004',
  sha = (b) => createHash('sha256').update(b).digest('hex'),
  checks = [],
  check = (name, passed) => { checks.push({ name, passed: !!passed }); assert(passed, name); },
  json = async (name) => JSON.parse(await fs.readFile(path.join(candidate, name))),
  verification = await json('optional-candidate-verification.json'),
  envelope = await json('optional-packages.json');
check('Exact source-bound two-build admission', verification.sourceRevision === '4eeb7bc4480acc1f82f07d436401283ea80cfd04' && verification.reproducibleBuilds === 2 && verification.committedInputsVerified && verification.admission.zipMembersVerified);
for (const f of (await json('optional-checksums.json')).files) {
  const b = await fs.readFile(path.join(candidate, f.path));
  check('Candidate checksum ' + f.path, b.length === f.bytes && sha(b) === f.sha256);
}
const row = envelope.packages.find((r) => r.id === 'fpv-worlds'),
  zip = await fs.readFile(path.join(candidate, row.distribution.path)),
  manifestBytes = await fs.readFile(path.join(candidate, row.manifest.path)),
  manifest = JSON.parse(manifestBytes),
  entries = readEditionZip(zip),
  expected = new Map(manifest.files.map((f) => [f.path, f]));
check('Exact admitted ZIP bytes', zip.length === row.distribution.bytes && sha(zip) === row.distribution.sha256);
check('Exact admitted descriptor bytes', manifestBytes.length === row.manifest.bytes && sha(manifestBytes) === row.manifest.sha256);
expected.set('optional-package.json', { bytes: manifestBytes.length, sha256: sha(manifestBytes) });
check('All102 admitted members', entries.size === 102 && expected.size === 102 && entries.get('optional-package.json').equals(manifestBytes));
await fs.mkdir(output);
const prior = JSON.parse(await fs.readFile(reusable + '.json')),
  reusableReal = await fs.realpath(reusable),
  priorFiles = new Map(prior.files.map((f) => [f.path, f])), files = [];
let linkedFiles = 0, writtenFiles = 0, writtenBytes = 0;
for (const [name, bytes] of entries) {
  const expectedFile = expected.get(name), target = path.join(output, name);
  assert(target.startsWith(output + '/') && !path.isAbsolute(name) && !name.split('/').includes('..'));
  check('Admitted member ' + name, expectedFile?.bytes === bytes.length && expectedFile.sha256 === sha(bytes));
  await fs.mkdir(path.dirname(target), { recursive: true });
  const old = priorFiles.get(name);
  if (old?.bytes === bytes.length && old.sha256 === sha(bytes)) {
    const source = path.join(reusable, name), stat = await fs.lstat(source), real = await fs.realpath(source);
    assert(stat.isFile() && !stat.isSymbolicLink() && real.startsWith(reusableReal + '/'));
    assert((await fs.readFile(source)).equals(bytes));
    let current; try { current = await fs.stat(path.join(mutable, name)); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    assert(!current || current.ino !== stat.ino || current.dev !== stat.dev, 'No mutable source inode');
    await fs.link(source, target); linkedFiles++;
  } else { await fs.writeFile(target, bytes, { flag: 'wx' }); writtenFiles++; writtenBytes += bytes.length; }
  check('Stored member ' + name, (await fs.readFile(target)).equals(bytes));
  files.push({ path: name, bytes: bytes.length, sha256: sha(bytes) });
}
const inventory = await json(row.sourceInventory.path), receipt = {
  format: 'FPVLibraryCompatibilityAdmittedPlayer.v1', sourceRevision: verification.sourceRevision,
  sourceTree: verification.sourceTree, output, entry: manifest.entry, zip: row.distribution,
  sourceInventory: path.join(candidate, row.sourceInventory.path), checks, files,
  totals: { files: files.length, originalInputs: inventory.inputs.length, originalInputBytes: inventory.inputs.reduce((n, f) => n + f.bytes, 0) },
  storage: { reusable, linkedFiles, writtenFiles, writtenBytes },
  limitations: ['Exact complete102-file admitted4eeb7bc44 ZIP, no runtime overlays.', 'This stages a local player; native UI/public deployment/offline are separate observations.', 'This integrated source includes qualified HUD ecf; unmerged Creator repair is not included.'],
};
await fs.writeFile(output + '.json', JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ output, receipt: output + '.json', checks: checks.length, ...receipt.storage, ...receipt.totals }));
