import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const base = '/private/tmp/fpv-world-library-admitted-01fc6ad20/fixture';
const out = '/private/tmp/fpv-world-library-ready-diagnostic-r2';
const hash = (b) => createHash('sha256').update(b).digest('hex');
const fixtureBytes = await fs.readFile(path.join(base, 'fixture.json'));
assert.equal(hash(fixtureBytes), 'ac116c5c93d8d4b90958f251b3558432d05004ded1dd2c7a26c047756b3d65c0');
const prior = JSON.parse(fixtureBytes);
assert.equal(prior.kind, 'admitted-package');
assert.equal(prior.overlays.length, 0);
await fs.mkdir(out);
for (const entry of prior.files) {
  const source = path.join(base, 'player', entry.path), bytes = await fs.readFile(source);
  assert.equal(bytes.length, entry.bytes);
  assert.equal(hash(bytes), entry.sha256);
  const target = path.join(out, 'player', entry.path);
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.link(source, target);
}
for (const entry of prior.browserSources) {
  const bytes = await fs.readFile(path.join(base, entry.path));
  assert.equal(bytes.length, entry.bytes);
  assert.equal(hash(bytes), entry.sha256);
}
for (const name of ['pack.rlpack', 'worker-diagnostic.js'])
  await fs.link(path.join(base, name), path.join(out, name));
const diagnostic = await fs.readFile('/tmp/fpv-library-ready-diagnostic.js');
await fs.writeFile(path.join(out, 'ready-diagnostic.js'), diagnostic, { flag: 'wx' });
const hostPath = 'player/optional-practice/fpv-worlds/fixture-host.html';
const host = (await fs.readFile(path.join(base, hostPath), 'utf8')).replace('<head>',
  '<head><script src="../../../ready-diagnostic.js"></script>');
await fs.writeFile(path.join(out, hostPath), host, { flag: 'wx' });
let harness = await fs.readFile(path.join(base, 'browser-harness.mjs'), 'utf8');
harness = harness.replace('  n.click();', "  ctx.w.fixtureReadyMark('before-click', n);\n  n.click();\n  ctx.w.fixtureReadyMark('after-click', n);");
harness = harness.replace('  n.value = v;', "  ctx.w.fixtureReadyMark('before-change:' + v, n);\n  n.value = v;");
harness = harness.replace("  click(q('#world-flight-menu'));", `  await delay(750);
  receipt.status = 'ready-boundary-observed';
  receipt.diagnostic = clone(ctx.w.fixtureReadyObservation());
  receipt.hostSnapshot = ctx.app.snapshot();
  receipt.limits = fixture.limits;
  captureNetwork();
  render('Ready boundary observed; diagnostic only, not complete Library qualification.');
  return;
  click(q('#world-flight-menu'));`);
harness = harness.replace("    receipt.status = 'failed';", "    receipt.status = 'failed';\n    receipt.diagnostic = ctx.w?.fixtureReadyObservation ? clone(ctx.w.fixtureReadyObservation()) : null;\n    receipt.hostSnapshot = ctx.app?.snapshot?.();\n    receipt.limits = fixture?.limits;");
assert(harness.includes('ready-boundary-observed') && harness.includes('receipt.diagnostic = ctx.w?'));
await fs.writeFile(path.join(out, 'browser-harness.mjs'), harness, { flag: 'wx' });
const html = (await fs.readFile(path.join(base, 'index.html'), 'utf8'))
  .replaceAll('Run Library download and preservation checks', 'Run readiness diagnostic')
  .replaceAll('Optional world Library qualification', 'Admitted Library readiness diagnostic')
  .replace('Actual admitted host closure with explicit source overlays where declared. Native isolated',
    'Readiness diagnostic only; stops after the original Ready wait or its unchanged timeout. Exact admitted runtime without overlays. Native isolated');
await fs.writeFile(path.join(out, 'index.html'), html, { flag: 'wx' });
const fixture = { ...prior, kind: 'admitted-readiness-diagnostic', originalFixtureSHA256: hash(fixtureBytes),
  head: prior.head, overlays: [], browserSources: [], limits: [...prior.limits,
    'Bounded readiness diagnostic only. The original exact Ready assertion and30-second bound are unchanged. No automatic resume, focus spoof, clock mutation or production guard changes.',
    'Flight-status setter stacks and bounded native RAF/focus observations add overhead; timings are diagnostic only. Stops750ms after original Ready wait succeeds; otherwise preserves the full timeout.'] };
for (const name of ['index.html', 'browser-harness.mjs', 'worker-diagnostic.js', 'ready-diagnostic.js', hostPath, 'pack.rlpack']) {
  const bytes = await fs.readFile(path.join(out, name));
  fixture.browserSources.push({ path: name, bytes: bytes.length, sha256: hash(bytes) });
}
const bytes = JSON.stringify(fixture, null, 2) + '\n';
await fs.writeFile(path.join(out, 'fixture.json'), bytes, { flag: 'wx' });
console.log(JSON.stringify({ out, source: fixture.admittedSource, files: fixture.files.length,
  overlays: fixture.overlays, fixtureSHA256: hash(bytes) }));
