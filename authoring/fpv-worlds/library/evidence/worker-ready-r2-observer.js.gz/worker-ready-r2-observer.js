/* Bounded fixture-only observation. Native clocks, focus, callbacks and guards stay intact. */
(() => {
  const data = { format: 'FPVLibraryReadyTrace.v1', timeOrigin: performance.timeOrigin,
    events: [], statuses: [], actions: [], frames: [], dropped: {}, maxFrameGap: 0 };
  const snapshot = () => ({ at: performance.now(), wall: new Date().toISOString(),
    visibility: document.visibilityState, hidden: document.hidden, focused: document.hasFocus(),
    active: document.activeElement?.id || document.activeElement?.tagName || null,
    flightOpen: !!document.getElementById('flight-dialog')?.open,
    status: document.getElementById('flight-status')?.textContent ?? null,
    armDisabled: document.getElementById('world-arm')?.disabled ?? null,
    pauseDisabled: document.getElementById('world-pause')?.disabled ?? null });
  const push = (key, value, bound) => {
    if (data[key].length < bound) data[key].push(value);
    else data.dropped[key] = (data.dropped[key] ?? 0) + 1;
  };
  data.initial = snapshot();
  window.fixtureReadyTrace = data;
  window.fixtureReadyMark = (action, node) => push('actions', { ...snapshot(), action,
    target: node?.id || node?.getAttribute?.('aria-label') || node?.textContent?.trim().slice(0, 80),
    type: node?.tagName, disabled: node?.disabled }, 128);
  window.fixtureReadyObservation = () => ({ ...data, final: snapshot() });
  for (const type of ['focus', 'blur', 'focusin', 'focusout', 'pagehide']) {
    addEventListener(type, (event) => push('events', { ...snapshot(), type,
      target: event.target?.id || event.target?.tagName || 'window' }, 256), true);
  }
  document.addEventListener('visibilitychange', () => push('events',
    { ...snapshot(), type: 'visibilitychange' }, 256));
  const descriptor = Object.getOwnPropertyDescriptor(Node.prototype, 'textContent');
  Object.defineProperty(Node.prototype, 'textContent', { ...descriptor,
    set(value) {
      const observed = this.id === 'flight-status';
      const stack = observed && data.statuses.length < 128 ? new Error('status write').stack : null;
      const result = descriptor.set.call(this, value);
      if (observed) push('statuses', { ...snapshot(), value: String(value), stack }, 128);
      return result;
    },
  });
  const nativeRAF = window.requestAnimationFrame;
  let previous = null;
  window.requestAnimationFrame = function (callback) {
    return nativeRAF.call(this, function (timestamp) {
      if (callback.name === 'frame') {
        const now = performance.now(), gap = previous === null ? 0 : now - previous;
        previous = now;
        data.maxFrameGap = Math.max(data.maxFrameGap, gap);
        if (data.frames.length < 100 || gap > 100)
          push('frames', { ...snapshot(), callback: callback.name, timestamp, gap }, 256);
      }
      return callback.call(this, timestamp);
    });
  };
})();
