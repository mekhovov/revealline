import datetime
import json
import os
import pathlib
import shutil
import signal
import subprocess
import sys
import time

root, revision, logfile, receiptfile, *command = sys.argv[1:]
assert root == '/Users/oleksandr.mekhovov/.codex/worktrees/fpv-garage-surfaces/go_test'
assert revision == '2c99a82508f23e508666d7354a1b473507514d48'
assert command and not pathlib.Path(logfile).exists() and not pathlib.Path(receiptfile).exists()
env = dict(os.environ, GIT_NO_LAZY_FETCH='1')
env['PATH'] = '/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin:' + env['PATH']
def git(*args):
    return subprocess.check_output(['git', '-c', 'maintenance.auto=false', '-c', 'gc.auto=0', *args], cwd=root, env=env).decode().strip()
assert git('rev-parse', 'HEAD') == revision and not git('status', '--porcelain')
floor = 3 * 1024 ** 3
minimum = shutil.disk_usage(root).free
assert minimum >= floor
result = {'sourceRevision': revision, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'command': command, 'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'minimumFreeBytes': minimum, 'stoppedForDiskFloor': False}
with open(logfile, 'xb') as log:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    result['pid'] = process.pid
    while process.poll() is None:
        free = shutil.disk_usage(root).free
        minimum = min(minimum, free)
        if free < floor:
            result['stoppedForDiskFloor'] = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
            break
        time.sleep(0.5)
    result['exitCode'] = process.wait()
result.update(finishedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(), minimumFreeBytes=minimum, cleanAfter=not git('status', '--porcelain'))
with open(receiptfile, 'x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
sys.exit(result['exitCode'] if result['exitCode'] >= 0 else 1)
