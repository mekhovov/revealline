import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root=process.cwd(), target=process.argv[2];
if(root!=='/Users/oleksandr.mekhovov/.codex/worktrees/fpv-garage-surfaces/go_test'||!/^[a-f0-9]{40}$/.test(target??''))throw Error('Exact owned checkout and full revision required');
const git=(args,extra={})=>execFileSync('git',args,{cwd:root,maxBuffer:512*1024*1024,env:{...process.env,GIT_NO_LAZY_FETCH:'1'},...extra});
if(git(['rev-parse','HEAD']).toString().trim()!==target)throw new Error('Wrong qualification head');
if(git(['status','--porcelain']).length)throw new Error('Qualification source must be clean');
const config=JSON.parse(git(['show','HEAD:game/build-config.json']));
const catalog=config.optionalChapters?.catalog?JSON.parse(git(['show','HEAD:'+config.optionalChapters.catalog])):{packs:[]};
const additional=[...(config.optionalOffline??[]),...catalog.packs.map(p=>p.path)];
const selected=p=>(p.startsWith('publishing/') && (p.split('/').length===2 || /\.(?:mjs|js)$/.test(p))) || [...config.include,...additional,"scripts","optional-practice","intake"].some(name=>p===name||p.startsWith(name+'/')) || (p.startsWith('authoring/')&&!p.startsWith('authoring/library/')&&/\.(?:mjs|js|html|json)$/.test(p)) || p==='authoring/library/fpv-enemy-presentations/index.html';
const entries=git(['ls-tree','-rz','--full-tree','HEAD']).toString().split('\0').filter(Boolean).map(line=>{const [meta,name]=line.split('\t');const [mode,type,oid]=meta.split(' ');return{mode,type,oid,name}}).filter(row=>row.type==='blob'&&['100644','100755'].includes(row.mode)&&selected(row.name));
const sources=['/private/tmp/fpv-creator-starters-20261004','/Users/oleksandr.mekhovov/.codex/worktrees/fpv-world-framework/go_test','/private/tmp/fpv-editor-modes-20261004','/private/tmp/fpv-mountain-reservoir-20261004','/Users/oleksandr.mekhovov/work/my_projects/go_test','/Users/oleksandr.mekhovov/.codex/worktrees/fpv-garage-surfaces/go_test','/Users/oleksandr.mekhovov/.codex/worktrees/fpv-stadium-structures/go_test'];
const blobHash=b=>createHash('sha1').update(`blob ${b.length}\0`).update(b).digest('hex');
let existing=0,cloned=0,gitFiles=0,logicalBytes=0,fallbackBytes=0;
for(const row of entries){const volume=await fs.statfs(root);if(volume.bavail*volume.bsize<3*1024**3)throw new Error('Free space below3GiB; materialization stopped');const dest=path.join(root,row.name);let prior;try{prior=await fs.readFile(dest)}catch(e){if(e.code!=='ENOENT')throw e}
if(prior){if(blobHash(prior)!==row.oid)throw new Error('Existing source differs: '+row.name);existing++;continue;}
await fs.mkdir(path.dirname(dest),{recursive:true});const temp=dest+'.mode-validation-clone';let copied=false;
for(const from of sources){const source=path.join(from,row.name);try{const stat=await fs.lstat(source);if(!stat.isFile())continue;execFileSync('/bin/cp',['-c',source,temp]);const b=await fs.readFile(temp);if(blobHash(b)===row.oid){await fs.rename(temp,dest);cloned++;logicalBytes+=b.length;copied=true;break}await fs.unlink(temp);}catch(e){if(e.code==='ENOENT')continue;throw e}}
if(!copied){const b=git(['cat-file','blob',row.oid]);if(fallbackBytes+b.length>2232130)throw new Error('Fallback byte bound exceeded: '+row.name);if(blobHash(b)!==row.oid)throw new Error('Git blob differs');await fs.writeFile(dest,b,{flag:'wx',mode:parseInt(row.mode,8)});gitFiles++;fallbackBytes+=b.length;}
}
if(git(['status','--porcelain']).length)throw new Error('Materialized source differs from commit');
console.log(JSON.stringify({format:'FPVGroundCohortValidationMaterialization.v1',sourceRevision:target,selected:entries.length,existing,apfsClones:cloned,cloneLogicalBytes:logicalBytes,gitFallbackFiles:gitFiles,gitFallbackBytes:fallbackBytes,allSelectedGitBlobHashesVerified:true},null,2));
