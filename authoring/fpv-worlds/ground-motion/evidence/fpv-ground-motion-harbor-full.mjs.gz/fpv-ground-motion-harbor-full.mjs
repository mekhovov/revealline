import {readFile,writeFile} from 'node:fs/promises';
import {createWorldFlight,initWorldRuntime} from '/private/tmp/fpv-creator-starters-20261004/optional-practice/civilian-fpv/world-model.mjs';
import {createWorldCollision} from '/private/tmp/fpv-creator-starters-20261004/optional-practice/civilian-fpv/world-collision.mjs';
await initWorldRuntime();const project=JSON.parse(await readFile('/tmp/fpv-harbor-world-r3-v1/prepared/project.json','utf8')),rows=[];
for(const id of ['harbor-docks-05','harbor-docks-06'])for(const mode of ['self-level','acro']){
 const course=structuredClone(project.courses.find(c=>c.id===id));course.actors[0].groundMotion='support-v1';const f=createWorldFlight({course,mode}),w=createWorldCollision(course);let travel=0,still=0,maxStill=0,blocked=0,missing=0,maxGap=0,minGap=Infinity;const supports={};
 try{f.arm();let s=f.snapshot();for(let i=0;i<3000;i++){const old=s.actors[0].position;s=f.step({roll:0,pitch:0,yaw:0,throttle:0,actions:0});const a=s.actors[0],d=Math.hypot(...['x','y','z'].map(k=>a.position[k]-old[k]));travel+=d;still=d===0?still+1:0;maxStill=Math.max(maxStill,still);blocked+=Number(a.blocked);const ground=w.support(a.position,a.radius,220);if(!ground)missing++;else{supports[ground.id]=(supports[ground.id]??0)+1;maxGap=Math.max(maxGap,a.position.y-ground.y);minGap=Math.min(minGap,a.position.y-ground.y);}}rows.push({id,mode,travel,maxStill,blocked,missing,minGap,maxGap,supports,final:s.actors[0],ticks:s.ticks,identity:f.identity,completed:s.status==='complete'});}finally{f.dispose();w.dispose();}
}
await writeFile('/tmp/fpv-ground-motion-harbor-full-candidate.json',JSON.stringify(rows,null,2),{flag:'wx'});console.log(JSON.stringify(rows,null,2));
