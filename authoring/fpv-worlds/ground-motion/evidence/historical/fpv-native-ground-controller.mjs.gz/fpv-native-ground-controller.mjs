import R from '/private/tmp/fpv-creator-starters-20261004/optional-practice/civilian-fpv/vendor/rapier/rapier.mjs';
import {readFile,writeFile} from 'node:fs/promises';
await R.init();
const rows=JSON.parse(await readFile('/tmp/fpv-harbor-r3-minimal-ground-cases.json','utf8')).cases;
const results=[];
for(const row of rows.slice(2,5))for(const offset of [0.01,0.02,0.03,0.05]){
 const w=new R.World({x:0,y:0,z:0}),ids=new Map();
 const floor=w.createCollider(new R.ColliderDesc(new R.HalfSpace({x:0,y:1,z:0})));ids.set(floor.handle,'$floor');
 for(const o of row.course.obstacles){const d=R.ColliderDesc.cuboid(...['x','y','z'].map(k=>(o.max[k]-o.min[k])/2000));d.setTranslation(...['x','y','z'].map(k=>(o.max[k]+o.min[k])/2000));ids.set(w.createCollider(d).handle,o.id);}
 w.step(); const a=row.course.actors[0],lift=a.type==='patrol'?a.height/2:a.radius;
 const d=a.type==='patrol'?R.ColliderDesc.capsule((lift-a.radius)/1000,a.radius/1000):R.ColliderDesc.ball(a.radius/1000);
 let p={...a.position,y:a.position.y+Math.round(offset*1000)+1};
 d.setTranslation(p.x/1000,(p.y+lift)/1000,p.z/1000);const col=w.createCollider(d);
 const c=w.createCharacterController(offset);c.enableAutostep(.2,.3,false);c.enableSnapToGround(.22);c.setMaxSlopeClimbAngle(Math.PI/6);c.setMinSlopeSlideAngle(Math.PI/6);c.setApplyImpulsesToDynamicBodies(false);
 const out={name:row.name,offset,start:p,nudge:c.normalNudgeFactor(),samples:[]};
 for(let i=0;i<800;i++){
  col.setTranslation({x:p.x/1000,y:(p.y+lift)/1000,z:p.z/1000});
  c.computeColliderMovement(col,{x:0,y:-.01,z:Math.round(a.speed/50)/1000},undefined,undefined,x=>ids.has(x.handle));
  const m=c.computedMovement(),grounded=c.computedGrounded();
  if(i<3||m.z<.0005){
   out.samples.push({tick:i,p,m,grounded,collisions:Array.from({length:c.numComputedCollisions()},(_,j)=>{const v=c.computedCollision(j);return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,k==='collider'?ids.get(x.handle):x]));})});
  }
  p={x:Math.round(p.x+m.x*1000),y:a.position.y+Math.round(offset*1000)+1,z:Math.round(p.z+m.z*1000)};
  if(m.z<.0005)break;
 }
 out.end=p;results.push(out);w.free();
}
await writeFile('/tmp/fpv-native-ground-controller-offset-diagnostic.json',JSON.stringify(results,null,2),{flag:'wx'});
console.log(JSON.stringify(results.map(({name,offset,start,end,samples})=>({name,offset,start,end,last:samples.at(-1)})),null,2));
