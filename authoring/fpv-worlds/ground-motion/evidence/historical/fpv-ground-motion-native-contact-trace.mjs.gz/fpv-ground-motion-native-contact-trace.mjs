import R from '/private/tmp/fpv-creator-starters-20261004/optional-practice/civilian-fpv/vendor/rapier/rapier.mjs';
import {groundMotionCases} from '/private/tmp/fpv-creator-starters-20261004/authoring/fpv-worlds/ground-motion/cases.mjs';
import {createWorldFlight,initWorldRuntime} from '/private/tmp/fpv-creator-starters-20261004/optional-practice/civilian-fpv/world-model.mjs';
import {writeFile} from 'node:fs/promises';
await initWorldRuntime();let trace=[],events=[];
const restore=[];
for(const [proto,name] of [[R.World.prototype,'castShape'],[R.World.prototype,'intersectionWithShape'],[R.KinematicCharacterController.prototype,'computedMovement'],[R.KinematicCharacterController.prototype,'computedGrounded']]){
 const old=proto[name];proto[name]=function(...args){const result=old.apply(this,args);const contact=name==='intersectionWithShape'&&result?result.contactShape(args[2],args[0],args[1],.03):null;events.push({name,contact,args:['castShape','intersectionWithShape'].includes(name)?args.slice(0,4).map((x,i)=>i===3&&name==='castShape'?x.type:x):[],result:typeof result==='object'&&result?Object.fromEntries(Object.entries(result).map(([k,v])=>[k,k==='collider'?v?.handle:v])):result});return result;};restore.push(()=>proto[name]=old);
}
const item=groundMotionCases().find(x=>x.name==='patrol/slope-15');item.course.actors[0].groundMotion='support-v1';const f=createWorldFlight({course:item.course});
try{f.arm();let state=f.snapshot(),still=0;for(let i=0;i<3000;i++){events=[];const before=state.actors[0];state=f.step({roll:0,pitch:0,yaw:0,throttle:0,actions:0});const after=state.actors[0];trace.push({i,before,after,events});if(trace.length>8)trace.shift();still=JSON.stringify(before.position)===JSON.stringify(after.position)?still+1:0;if(still>4)break;}}finally{f.dispose();restore.forEach(fn=>fn());}
await writeFile('/tmp/fpv-ground-motion-native-slope-contact-trace.json',JSON.stringify(trace,null,2),{flag:'wx'});console.log(JSON.stringify(trace.at(-1),null,2));
