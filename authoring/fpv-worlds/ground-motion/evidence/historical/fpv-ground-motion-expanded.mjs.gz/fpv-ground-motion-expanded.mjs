import {writeFile} from 'node:fs/promises';
import {groundMotionCases} from '/private/tmp/fpv-creator-starters-20261004/authoring/fpv-worlds/ground-motion/cases.mjs';
import {createWorldFlight,initWorldRuntime} from '/private/tmp/fpv-creator-starters-20261004/optional-practice/civilian-fpv/world-model.mjs';
import {createWorldCollision} from '/private/tmp/fpv-creator-starters-20261004/optional-practice/civilian-fpv/world-collision.mjs';
await initWorldRuntime();const rows=[];
for(const item of groundMotionCases()){
 item.course.actors[0].groundMotion='support-v1';
 const flight=createWorldFlight({course:item.course}),survey=createWorldCollision(item.course);
 let travel=0,still=0,maxStill=0,missing=0,overlaps=0,wrongSupport=0,blocked=0,minY=Infinity,maxY=-Infinity;
 try{
  flight.arm();let s=flight.snapshot();
  for(let i=0;i<3000;i++){
   const old=s.actors[0].position;s=flight.step({roll:0,pitch:0,yaw:0,throttle:0,actions:0});const a=s.actors[0];
   const d=Math.hypot(...['x','y','z'].map(k=>a.position[k]-old[k]));travel+=d;still=d===0?still+1:0;maxStill=Math.max(still,maxStill);blocked+=Number(a.blocked);
   minY=Math.min(minY,a.position.y);maxY=Math.max(maxY,a.position.y);
   const ground=survey.support({...a.position,y:a.position.y+20},a.radius,40);if(!ground)missing++;else if(item.surface&&ground.id!==item.surface)wrongSupport++;
   // An independent solid envelope check for each synthetic horizontal ceiling.
   const ceiling=item.course.obstacles.find(o=>o.id==='ceiling');if(ceiling && a.position.y+(a.type==='vehicle'?a.radius*2:a.height)>ceiling.min.y)overlaps++;
  }
  const p=s.actors[0].position;
  const pass=missing===0&&wrongSupport===0&&overlaps===0&&(item.expect==='travel'?travel>item.minTravel&&maxStill<10:p.z>=item.minZ&&p.z<=item.maxZ&&s.actors[0].blocked);
  rows.push({name:item.name,pass,travel,maxStill,blocked,missing,wrongSupport,overlaps,minY,maxY,final:s.actors[0]});
 }finally{flight.dispose();survey.dispose();}
}
await writeFile(process.argv[2],JSON.stringify(rows,null,2),{flag:'wx'});console.log(JSON.stringify(rows.map(({final,...rest})=>({...rest,position:final.position})),null,2));
