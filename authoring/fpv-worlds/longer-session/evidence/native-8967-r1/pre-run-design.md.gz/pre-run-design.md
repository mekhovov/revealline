# Longer native session attribution

Observation scaffold only, not staged/run. Root owns browser; D1 supplies the one
final combined exact 102-member/95-input admission including Creator repair,
Library compatibility, HUD and warm readiness. No overlay or duplicate build.

One owner measures Yard08 → Reservoir08 → Yard08 → Reservoir08. Each selection has
20 seconds disarmed at the native spawn pose, then 20 seconds of its verified
Self-level demonstration at ordinary 1x. Eight windows total 160 seconds, plus
native imports/loads. Two additional Ready loads give three same-owner resource
points per scene. Dispose, require every owned registered resource count zero,
then reopen a fresh owner and load each scene once without more timed windows.
Target total 3–5 minutes, actual wall time retained. No automatic resume/retry.

Settings use visible controls: authored appearance, balanced quality, FPV camera,
Self-level, keyboard. The selected profile must be actual authored Operations for
Yard and Ukrainian Horizons for Reservoir 50ff. Every boundary retains full state,
pose, camera, input preset/source, canvas size, profile, renderer.info and owned
registered resources. Repeated Ready poses and registered counts must match.
Internal geometry/texture/program values are reported separately; warming once
and plateauing is allowed, monotonic growth across three repeated same-scene
loads is an observation failure requiring investigation, not a proven memory leak.

The proven HUD observer retains native results and only aggregates RAF callbacks,
RAF gaps, draw CPU submission, structuredClone, direct observed DOM writes,
clientWidth reads and supported PerformanceObserver entries within each window.
Detailed boundary snapshots are outside windows. LoAF is feature-detected and
only reports entries beginning inside the window; its threshold is 50ms and no
entries does not imply no jank. Nested measures and observer overhead cannot be
added as independent costs. Browser UA/platform/DPR/viewport are recorded;
physical device and unrelated processes/tabs are explicitly unverified.

Actual pack 50ff and proof archive 073ee are separately imported through public file
controls. This uses verified playback as a repeatable moving workload and does
not duplicate D1's native install faults, course editing, catalogue download or
offline journey. It does not claim completion of these interrupted demonstrations.
Source errors, paused playback, focus/visibility changes and every stopped run
remain preserved; no clock alteration or private flight-state write is permitted.

Run prepare.mjs with absolute ROOT PLAYER INVENTORY FULL_REVISION PACK PROOFS
NEW_OUTPUT. It refuses mismatched or incomplete admission, missing integrated
Creator/compatibility source, any runtime overlay and an existing output.
All 102 members and all 95 committed inputs are checked before immutable linking.
The browser rehashes the player, observer and exact external content before run.
No build, browser or runtime optimization has been performed by this scaffold.

Offline authoring imports use the hash-bound repository ESM closure, with all 95
working input bytes compared to the admitted commit, not the standalone browser
archive without a package.json module boundary. This does not alter player bytes.
ImageBitmap.close calls are not observed; that specific ownership gate remains
unqualified. Replay checks bind course separately from kind/mode/rate/frame count
and the exact retained imported archive; no additional proof execution is claimed.
