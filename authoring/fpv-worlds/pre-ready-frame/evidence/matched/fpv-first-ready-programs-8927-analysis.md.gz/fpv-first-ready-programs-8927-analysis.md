# First-ready native program classification 8927

Receipt: `/tmp/fpv-first-ready-programs-8927.json` (641097 bytes), SHA-256 `fad1c9062ab2152ef7063f44c0ab1c48cd9c8af30c385d5b5850bb5bc9f4a854`. 228/228 PASS; four fresh hosts, twelve course loads and twenty-four recorded draws; no dropped program records, warnings or errors. Exact baseline f3764070e22f0b33b63fd0f7434690fa7455dc64, same source-overlay closure and workload as retained r2 resource observation. Root closed14 known completed GPU tabs before running; external CPU activity remained. Native clocks were unchanged. Observer timing and CPU contention prohibit total-latency/FPS/hardware conclusions.

## Proven classification

All66 additional first-draw native linkProgram calls are MeshDepthMaterial in both shader stages, with PCF shadow mapping and BasicDepthPacking(3200). This exactly equals the sum of info.programs deltas: six per Extraction08 load (six loads), five per Check-in01 load (six loads). No new link occurs on second or later draws in the retained observations.

The six observed signature classes are map+flipped side, untextured+flipped side and map+double side, each with regular and instanced vertex variants. The untextured instanced variant appears only in Extraction08 (six links); each of the other five signatures appears twelve times. These selected signatures classify the normal pinned Three path; they are not complete shader-source hashes or a general relink/detach tracer.

Existing prepare calls link scene standard/basic/line/sprite materials, with no MeshDepthMaterial link. Initial setCourse also links four PMREM/environment programs. Pinned Three compile() only invokes shadowMap.render when its _nodesHandler is non-null; the ordinary WebGL path here creates the observed depth variants in renderer.render. This establishes incomplete shadow shader preparation before Ready, not lazy actor construction, HDR output-pass creation, or texture upload duration. Registered actor/resources were already present in r2; GPU geometry/texture upload also happens during first draw, but this observer does not isolate its time cost.

## Smallest proposed prototype (plan only, no production edit)

Factor the existing state+camera/FOV/tilt submission into drawFlight(state). After normal asynchronous asset/compile preparation and optional ghost load, submit one current paused snapshot immediately before setting sceneReady. Reuse that path after quality preparation. Keep all token/generation/lifecycle guards and disarmed state. Renderer.draw must reject disposed/missing/lost context before submission and report context loss after it, so host never marks that warm submission Ready on failure.

Do not alter the clock, reset the frame-stall guard, advance the flight, disable shadows or replace materials. No offscreen target, second canvas, scene cache or duplicate texture ownership is needed. A first unchanged post-ready draw should then add zero programs or uploaded resources; a later actual camera/state change is outside that narrow invariant.

In-memory diff estimate against current owned source: host+167 bytes and renderer+98 = +265 bytes, before one explanatory comment/formatting. This is below root's provisional552-byte integrated margin, leaving287 bytes before comment and before exact integrated admission. No extra asset/file count. Treat exact current-main combined admission as authority; never infer release capacity from this estimate.

Qualification should compare baseline/candidate same public twelve-load workload, complete state/identity, camera/canvas dimensions, registered/uploaded resources,66 depth program signatures moving before Ready and zero extra work on first unchanged ready draw. Add functional quality supersession, import/fallback, ghost, context loss during preparation, ordinary retry, recovered/paused native state, first arm, owned disposal. Preserve opaque-guide screen ownership. Time values remain diagnostic; the claim is complete visible preparation before readiness, not less total work.

## Approved prototype now frozen

Root approved the plan. Independent branch `codex/fpv-pre-ready-shadow-frame`, source `2f9a7a87876a4ee64eb5b7c581b3ea339aaba146`, based on exact then-current main `7e76112411f96ae72979cebee0a62ccdd66577d6`. Only world-app.mjs and renderer.mjs changed. Actual source delta is379 bytes including explanatory comment and post-warm disposed/token/quality-generation checks. Root and D1 read-only reviews found no blocking ownership defect. Scoped syntax/ESLint/Prettier/diff checks pass. No full admission/build/browser acceptance yet; pending source#1076 remains untouched.

Matched fixture r1 was frozen but never run; Art found an accidental shader-stage completeness assertion3 instead of2 caused by the draw-count edit. Both r1 directories retained. Corrected r2 requires exactlytwo stages including vertex and fragment; this is fixture correction only. Runtime2f9 unchanged. Candidate r2 expects one pre-Ready draw; baseline r2 expects Ready before its first draw. Both capture36 submissions across12 original public loads, complete state equality, camera/canvas/resource identity, exact5/6 shadow variants, and no later program/upload growth.
