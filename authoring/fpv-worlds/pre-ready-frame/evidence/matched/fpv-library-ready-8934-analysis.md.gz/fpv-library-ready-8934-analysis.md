# Library readiness diagnostic 8934 — independent read-only analysis

Receipt: `/tmp/fpv-library-ready-8934-trace.json` (110333 bytes), SHA-256 `fe6dbcad4763847d31855db84b72a8967e2fa242041552146cebb502dac06ebf`. Original retained unchanged. Exact admitted host source `01fc6ad206f6ea7e6dd78921f799e2ed1a773915`; 120 completed checks before original 30-second Ready wait timed out. No runtime edits or browser rerun by this reviewer.

## Recorded sequence

| Native relative time | Observation |
| --- | --- |
| 623.1ms | Public Fly: Clearing check-in click |
| 648.6ms | startFlight:4721 writes Preparing scene…; Arm disabled |
| 1659.8ms | Native frame entry, timestamp643.3ms, actual execution gap1012.8ms; page visible/focused |
| 1660.4ms | pauseFlight:3650 writes Paused; stack advanceFrame:4411 proves elapsed-execution guard, not focus loss |
| 1702.5ms | startFlight:4908 writes Checking saved best… |
| 30635.5ms | Timeout capture still Checking saved best…; Arm disabled, page visible/focused, flight open |

Only these three status writes occurred; dropped records are empty, so there was no observed Ready write to miss. No window blur/visibility loss occurs during flight preparation. `events` contains ordinary element focus transitions only. App errors are empty. The RAF observation retains first100 entries and later gaps>100ms; it is not a complete frame log.

## What is established

The early pause was a legitimate native execution-gap guard. It did not stop startFlight: the later status write proves asynchronous preparation continued. Accepting Paused as Ready or manipulating focus would weaken the fixture and would not fix this run.

The final app snapshot reports `sectorTiming.status="none"`, `records=[]`, `ghost.loading=false`, tick0/disarmed and correct woodland-01. `resolveSectorReference` (3781–3842) with an empty candidate list sets none and clears its controller without awaiting proof replay. Therefore the Checking saved best text is stale: the operation named by that label completed. This is not evidence of a saved-record or IDB stall.

After that await, startFlight enters renderer.prepare/compileAsync (world-app4916 onward). Final renderer remains available, contextLost=false, 12 programs and zero uploaded geometries. Awaited shader preparation is the leading supported explanation. The current observer does not record promise settlement or GL completion polling, so it cannot prove which shader or driver condition caused the wait, nor rule out a later token/generation early return solely from its methods. Do not claim a compile deadlock yet.

## Safe next step

Root will first repeat the unchanged diagnostic with old active GPU tabs closed; preserve both receipts and record context conditions. If it still fails, add a fixture-only original-returning prepare start/settle observer and observe existing native COMPLETION_STATUS_KHR query results and timeout delivery, without extra GL queries, forced rendering, auto-focus/resume, altered clock, guard changes or a longer readiness timeout. Keep any future failure capture best-effort after recording the original error.

No runtime correction is justified by this receipt alone. A future status-copy correction should explicitly label shader preparation, independently of the unresolved wait; it is not a fix for readiness.

## Subsequent root-controlled repeat

Root reports the exact same frozen8934 diagnostic reached Ready in approximately3 seconds after closing14 known completed GPU tabs. The original failure remains preserved; no source, observer, timeout, focus guard or success predicate was changed. This makes aggregate graphics-resource pressure a supported environmental lead, but it does not isolate a driver/shader defect or prove those tabs are the sole cause. Root is repeating the complete Library fixture. No additional observer or runtime correction is warranted until that outcome.
