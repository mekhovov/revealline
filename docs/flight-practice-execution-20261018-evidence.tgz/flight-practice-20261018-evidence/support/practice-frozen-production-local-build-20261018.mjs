import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { frozenSource, committedInputMap, verifyCommittedInputs } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
import { readBuildConfig, collectBuildFiles } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/game-cli.mjs';
import { observeIndustrialPhase } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/verify-industrial-features.mjs';

const root='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const output='/private/tmp/practice-frozen-production-local-build-20261018';
const destination='/private/tmp/practice-tuning-upload-fixed-20261018-production';
await fs.mkdir(output);
assert.equal(await fs.access(destination).then(()=>true,()=>false),false);
const source=frozenSource(root),tree=committedInputMap(root);
assert.equal(source.sourceRevision,'3c6ac5ee0f524a1c3a456316b978cf4e0043e06c');
const sha=b=>createHash('sha256').update(b).digest('hex');
const config=await readBuildConfig(root);
const files=await collectBuildFiles(root,config);
const toolFiles=execFileSync('git',['ls-files','scripts','publishing'],{cwd:root,encoding:'utf8'}).trim().split('\n').filter(p=>p.endsWith('.mjs'));
const selected=[...new Set([...files,...toolFiles,'package.json','game/build-config.json'])].sort();
const pins=async()=>{const rows=[];for(const file of selected){const bytes=await fs.readFile(path.join(root,file));verifyCommittedInputs(new Map([[file,bytes]]),tree);rows.push({path:file,bytes:bytes.length,sha256:sha(bytes)});}return rows;};
const receipt={format:'PracticeFrozenProductionBuild.v1',startedAt:new Date().toISOString(),source,destination,node:process.version,platform:process.platform,arch:process.arch,deadlineMs:600000,qualified:false,publicEligible:false,passed:false,scope:'Local full core build with exact committed selected inputs and unchanged clean source. Not package release approval, hosting, CI, physical devices or human acceptance.'};
try{
  receipt.before=await pins();
  const reserve=1536*1024*1024;
  const disk=await fs.statfs('/private/tmp');
  receipt.storageBudget={freeBefore:disk.bavail*disk.bsize,reserveBytes:reserve,upperBoundBuildBytes:receipt.before.reduce((n,r)=>n+r.bytes,0)*2,localFilesystem:true};
  assert(receipt.storageBudget.freeBefore>receipt.storageBudget.upperBoundBuildBytes+reserve,'Insufficient measured local storage margin');
  receipt.command=['scripts/game-cli.mjs','build','--out',destination,'--version','v0.151.1','--revision',source.sourceRevision];
  console.log(JSON.stringify({source,files:selected.length,destination,deadlineMs:receipt.deadlineMs}));
  const controller=new AbortController();
  let checking=false;
  const guard=setInterval(async()=>{if(checking)return;checking=true;try{const disk=await fs.statfs('/private/tmp');const free=disk.bavail*disk.bsize;receipt.storageBudget.minimumObserved=Math.min(receipt.storageBudget.minimumObserved??Infinity,free);if(free<reserve){receipt.storageBudget.abortedForSpace=true;controller.abort();}}catch(e){receipt.storageBudget.guardError=e.message;controller.abort();}finally{checking=false;}},1000);
  try{receipt.result=await observeIndustrialPhase({command:receipt.command,cwd:root,log:path.join(output,'build.log'),deadlineMs:receipt.deadlineMs,signal:controller.signal});}finally{clearInterval(guard);}
  const log=await fs.readFile(path.join(output,'build.log'));
  receipt.logSha256=sha(log);
  receipt.after=await pins();
  assert.deepEqual(receipt.after,receipt.before);
  assert.deepEqual(frozenSource(root),source);
  receipt.sourceUnchanged=true;
  receipt.passed=receipt.result.exitCode===0&&!receipt.result.timedOut&&!receipt.result.interrupted&&!receipt.result.executionError;
  if(receipt.passed){receipt.build=JSON.parse(log);assert.equal(receipt.build.sourceRevision,source.sourceRevision);}
}catch(e){receipt.failure=e.message;process.exitCode=1;}
finally{receipt.finishedAt=new Date().toISOString();await fs.writeFile(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({passed:receipt.passed,result:receipt.result,failure:receipt.failure,output}));if(!receipt.passed)process.exitCode=1;}
