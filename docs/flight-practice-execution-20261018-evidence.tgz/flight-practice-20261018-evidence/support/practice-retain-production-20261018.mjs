import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
const source='/private/tmp/practice-tuning-upload-fixed-20261018-production';
const out='/Volumes/alex/CodexMigrationStaging/flight-practice-production-3c6ac5ee0-20261018';
await fs.mkdir(out);
const digest=async file=>{const h=createHash('sha256');for await(const b of createReadStream(file))h.update(b);return h.digest('hex');};
const files=[];
for(const name of ['distribution.zip','distribution.zip.sha256','manifest.json','offline-cache.json','offline-inventory.json','game/build-info.json']){
  const a=path.join(source,name),b=path.join(out,name);
  await fs.mkdir(path.dirname(b),{recursive:true});
  const before=await digest(a);await fs.copyFile(a,b,fs.constants.COPYFILE_EXCL);assert.equal(await digest(b),before);
  files.push({path:name,bytes:(await fs.stat(b)).size,sha256:before});
}
assert.equal(files[0].sha256,'2d4ddbfcbf400afd7b8656451ba10678f8f278ffaf5ddbaeadd6077e8aae4582');
await fs.writeFile(path.join(out,'retention.json'),JSON.stringify({format:'PracticeProductionRetention.v1',passed:true,sourceRevision:'3c6ac5ee0f524a1c3a456316b978cf4e0043e06c',sourceTree:'ad8f538f6378cd22ea053fc1f56f0d0d370885af',files,scope:'Byte-identical retained original production archive and metadata. Loose original build remains at the capture-time local path. No deployment, hosting or approval.'},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({out,files}));
