import test from 'node:test';
import assert from 'node:assert/strict';
import { expectedImportedProfileExport } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/optional-installation-observer-helpers.mjs';

const incoming = { format: 'FlightProfiles.v1', radio: { id: 'fixture', verified: false }, response: { format: 'FlightResponseProfile.v1', id: 'incoming', name: 'Incoming', maxRate: 300, maxTilt: 35, expo: 40, responseTicks: 10 } };
const priorExport = { format: 'FlightProfiles.v2', radio: null, radios: [], response: { format: 'FlightResponseProfile.v1', id: 'gentle-v1', name: 'Gentle', maxRate: 240, maxTilt: 30, expo: 30, responseTicks: 8 } };
const notice = 'Included flight response settings were not applied. Rates & throttle profiles remain unchanged.';
test('delegated Rates owner preserves the actual prior response without dropping imported calibration', () => {
  const actual = expectedImportedProfileExport('FlightProfiles.v2', incoming, { ratesOwner: true, priorExport, importNotice: notice });
  assert.deepEqual(actual, { ...incoming, format: 'FlightProfiles.v2', radios: [incoming.radio], response: priorExport.response });
  assert.notEqual(actual.response, priorExport.response, 'Return an independent expectation, not a mutable live object.');
});
test('delegated response preservation requires a matching prior format and actual explicit notice', () => {
  for (const patch of [{ priorExport: null }, { priorExport: { ...priorExport, format: 'FlightProfiles.v99' } }, { priorExport: { ...priorExport, response: {} } }, { importNotice: '' }, { importNotice: 'Saved on this device' }, { ratesOwner: 'yes' }])
    assert.throws(() => expectedImportedProfileExport('FlightProfiles.v2', incoming, { ratesOwner: true, priorExport, importNotice: notice, ...patch }));
});
