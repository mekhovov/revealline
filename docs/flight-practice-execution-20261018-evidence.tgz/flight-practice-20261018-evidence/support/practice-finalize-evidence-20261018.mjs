import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const stage='/Volumes/alex/CodexMigrationStaging/flight-practice-20261018-evidence';
const sha=b=>createHash('sha256').update(b).digest('hex');
for(const file of await fs.readdir('/private/tmp'))
  if(file.startsWith('practice-offline-post-fix-20261018-')||file==='practice-offline-post-fix-20261018.log'||file==='practice-offline-post-fix-audit-20261018.mjs'){
    await fs.mkdir(path.join(stage,'offline-post-fix'),{recursive:true});
    await fs.copyFile(path.join('/private/tmp',file),path.join(stage,'offline-post-fix',file),fs.constants.COPYFILE_EXCL);
  }
for(const file of ['practice-full-post-fix-20261018.tap','practice-frozen-production-build-20261018.mjs','practice-retain-evidence-20261018.mjs','practice-finalize-evidence-20261018.mjs','practice-current-production-build-20261018.log'])
  await fs.copyFile(path.join('/private/tmp',file),path.join(stage,'support',file),fs.constants.COPYFILE_EXCL);
await fs.cp('/private/tmp/practice-frozen-production-build-20261018',path.join(stage,'frozen-production-build'),{recursive:true,errorOnExist:true,force:false});
await fs.cp('/private/tmp/practice-frozen-production-local-build-20261018',path.join(stage,'frozen-production-local-build'),{recursive:true,errorOnExist:true,force:false});
for(const name of ['practice-frozen-production-local-build-20261018.mjs','practice-retain-production-20261018.mjs','practice-tuning-populated-backup-browser-20261018.mjs','practice-tuning-populated-backup-audit-20261018.mjs','practice-historical-flight-ui-inspect-20261018.mjs','practice-historical-flight-menu-ui-inspect-20261018.mjs'])
  await fs.copyFile(path.join('/private/tmp',name),path.join(stage,'support',name),fs.constants.COPYFILE_EXCL);
for(const name of ['practice-tuning-populated-backup-browser-20261018-run1','practice-tuning-populated-backup-browser-20261018-run2','practice-historical-flight-ui-20261018','practice-historical-flight-menu-ui-20261018']){
  await fs.cp('/private/tmp/'+name,path.join(stage,name),{recursive:true,errorOnExist:true,force:false});
  await fs.copyFile('/private/tmp/'+name+'.log',path.join(stage,name+'.log'),fs.constants.COPYFILE_EXCL);
}
await fs.copyFile('/Volumes/alex/CodexMigrationStaging/flight-practice-production-3c6ac5ee0-20261018/retention.json',path.join(stage,'production-retention.json'),fs.constants.COPYFILE_EXCL);
await fs.writeFile(path.join(stage,'execution-supplement.json'),JSON.stringify({format:'PracticeExecutionSupplement.v1',notes:[
  'The first historical-flight UI probe labels one Worlds snapshot paused after Space, but the recorded public HUD and shell remain playing. That label is not accepted pause evidence. The later menu-specific probe witnesses actual toolbar pause and explicit Home Continue. Neither probe establishes update continuity.',
  'The first populated-library probe assumed two profiles after Save. Actual public save correctly created a separate assigned profile, yielding three. The failed receipt is preserved. The corrected probe requires exactly three named baseline profiles, four after a later edit, then restores exactly the baseline fields and persists them through reload.',
  'The full external production build hit its unchanged 600000ms diagnostic deadline while materializing output to the network-mounted volume; its tracked source stayed unchanged. Its incomplete owned output was retained at flight-practice-20261018-production-partial-J3DawZ. A disk-guarded local retry passed under the same deadline, without changing application or CI timeouts.',
  'The preceding unbound production diagnostic was intentionally terminated when its source changed for the CSS fix. Its empty log is not a passing or source-qualified build receipt.'
]},null,2)+'\n',{flag:'wx'});
const rows=[];
async function walk(directory,prefix=''){
  for(const item of (await fs.readdir(directory,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
    const file=path.join(directory,item.name),name=prefix+item.name;
    assert(!item.isSymbolicLink());
    if(item.isDirectory())await walk(file,name+'/');
    else{assert(item.isFile());const b=await fs.readFile(file);rows.push({path:name,bytes:b.length,sha256:sha(b)});}
  }
}
await walk(stage);
const manifest={format:'PracticeEvidenceInventory.v1',createdAt:new Date().toISOString(),files:rows,bytes:rows.reduce((n,r)=>n+r.bytes,0),publicEligible:false,scope:'Original success/failure receipts, actual browser backups/screenshots, observer snapshots and source-bound candidate/build metadata. No reviewer approval; package ZIP files remain separately retained in external immutable candidate folders.'};
await fs.writeFile(path.join(stage,'evidence-inventory.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({stage,files:rows.length,bytes:manifest.bytes,inventorySha256:sha(await fs.readFile(path.join(stage,'evidence-inventory.json')))}));
