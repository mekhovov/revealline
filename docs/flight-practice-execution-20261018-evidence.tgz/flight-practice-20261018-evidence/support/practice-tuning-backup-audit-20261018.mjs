import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readEditionZip } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
import { validateOptionalPackageAdmission } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/optional-package-admission.mjs';
import { validateTuningLibrary } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/optional-practice/civilian-fpv/tuning-library.mjs';

const bundle='/Volumes/alex/CodexMigrationStaging/flight-practice-tuning-upload-fixed-20261018-candidate';
const prior='/Volumes/alex/CodexMigrationStaging/flight-practice-main-cb8-20261018-candidate';
const output='/private/tmp/practice-tuning-backup-browser-20261018-run6';
const sha=b=>createHash('sha256').update(b).digest('hex');
const bytes=await fs.readFile(path.join(output,'observation.json')),r=JSON.parse(bytes);
const envelopeBytes=await fs.readFile(path.join(bundle,'optional-packages.json')),envelope=JSON.parse(envelopeBytes);
const oldEnvelope=JSON.parse(await fs.readFile(path.join(prior,'optional-packages.json')));
const admission=await validateOptionalPackageAdmission(envelope,{read:row=>fs.readFile(path.join(bundle,row.path))});
assert.equal(r.sourceRevision,'3c6ac5ee0f524a1c3a456316b978cf4e0043e06c');
assert.equal(r.sourceTree,'ad8f538f6378cd22ea053fc1f56f0d0d370885af');
assert.equal(r.envelopeSha256,'6e526b6438afd02cdad71e164af699c2c5cb15cc52a0dd90b65c3feed8f04f49');
assert.equal(r.envelopeSha256,sha(envelopeBytes));
assert.equal(r.passed,true);assert.equal(r.pending,0);assert(r.cleanup.every(c=>c.passed));
assert.equal(r.qualified,false);assert.equal(r.publicEligible,false);assert.deepEqual(r.unexpectedRequestFailures,[]);
assert.equal(r.optionalCoreProbeClassification.count,4);assert.equal(r.optionalCoreProbeClassification.visibleFallbacks,4);
assert.equal(r.guides.length,6);assert.equal(r.backups.length,4);
const maps=new Map(),changed=[];
for(const item of envelope.packages){
  const original=readEditionZip(await fs.readFile(path.join(bundle,item.distribution.path)));maps.set(item.id,original);
  const old=readEditionZip(await fs.readFile(path.join(prior,oldEnvelope.packages.find(p=>p.id===item.id).distribution.path)));
  assert.deepEqual([...original.keys()].sort(),[...old.keys()].sort());
  const diff=[...original.keys()].filter(p=>!original.get(p).equals(old.get(p))).sort();
  const expected=['optional-package.json',`optional-practice/${item.id}/guide.html`,`optional-practice/${item.id}/worker.js`,...(item.id==='civilian-flight'?[]:['optional-practice/civilian-fpv/tuning.css'])].sort();
  assert.deepEqual(diff,expected);
  changed.push({id:item.id,changed:diff});
}
for(const row of r.guides){assert(row.passed);const guide=maps.get(row.id).get(row.originalGuide.path);assert.equal(guide.length,row.originalGuide.bytes);assert.equal(sha(guide),row.originalGuide.sha256);}
for(const row of r.backups){
  assert(row.passed);assert.deepEqual(row.errors,[]);assert.equal(row.exports.length,3);
  const parsed=[];
  for(const pin of [...row.exports,row.download]){const file=await fs.readFile(path.join(output,pin.path));assert.equal(file.length,pin.bytes);assert.equal(sha(file),pin.sha256);if(pin.stage)parsed.push(validateTuningLibrary(file.toString()));}
  assert.deepEqual(parsed[1],parsed[2]);assert.equal(parsed[1].revision,parsed[0].revision+1);
  const semantic=v=>{const{revision,...rest}=v;return rest;};assert.deepEqual(semantic(parsed[0]),semantic(parsed[1]));
}
for(const row of [...r.guides,...r.backups]){const pin=row.screenshot,png=await fs.readFile(path.join(output,pin.path));assert.equal(png.length,pin.bytes);assert.equal(sha(png),pin.sha256);assert.equal(png.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
const observer=await fs.readFile(path.join(output,'observer-original.mjs'));assert.equal(sha(observer),r.observer.sha256);
const result={format:'PracticeTuningBackupIntegrityAudit.v1',passed:true,reportSha256:sha(bytes),sourceRevision:r.sourceRevision,sourceTree:r.sourceTree,envelopeSha256:r.envelopeSha256,admission,changedPackages:changed,guides:6,backups:4,screenshots:10,qualification:false,scope:'Repeatable mechanical audit, not a second human review. Only root library transaction revision may advance; every other field and persisted re-export matches. Original C4 flights remain bound to their own earlier candidate.'};
await fs.writeFile(path.join(output,'audit.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result));
