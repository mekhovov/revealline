import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const stage='/Volumes/alex/CodexMigrationStaging/flight-practice-20261018-evidence';
await fs.mkdir(stage);
const hash=b=>createHash('sha256').update(b).digest('hex');
const copies=[];
async function copy(source,target){const dest=path.join(stage,target);await fs.mkdir(path.dirname(dest),{recursive:true});await fs.cp(source,dest,{recursive:true,errorOnExist:true,force:false});copies.push({source,retainedAs:target});}
for(const [name,directory] of [
  ['local-ux-node20-first','practice-local-ux-20261018.pwMJAO'],
  ['local-ux-node22-second','practice-local-ux-node22-20261018.ldXkzr'],
  ['local-ux-node22-complete','practice-local-ux-complete-20261018.VTj7cW'],
  ['offline-profile-first-failed','practice-current-offline-20261018.cFlA5G'],
  ['offline-first-pass-metadata-erratum','practice-current-offline-retry-20261018.BoCUiS'],
  ['offline-final-audited','practice-current-offline-final-20261018.8ke72B'],
  ['historical-ui-mapping','practice-historical-ui-20261018.kFyM1j'],
])await copy('/private/tmp/'+directory,name);
for(let i=1;i<=6;i++){
  await copy(`/private/tmp/practice-tuning-backup-browser-20261018-run${i}`,`tuning-backup/run${i}`);
  await copy(`/private/tmp/practice-tuning-backup-browser-20261018-run${i}.log`,`tuning-backup/run${i}.log`);
}
// Run 1 predates the direct public route. Recover its exact recorded observer
// bytes from the retained run-2 snapshot, and require its original receipt hash.
const first=JSON.parse(await fs.readFile(path.join(stage,'tuning-backup/run1/observation.json')));
let original=await fs.readFile(path.join(stage,'tuning-backup/run2/observer-original.mjs'),'utf8');
original=original.replace('flight-practice-tuning-direct-guide-20261018-candidate','flight-practice-tuning-library-guide-20261018-candidate')
  .replace("(locale==='en'?'Aircraft, rates & throttle':'Дрон, рейти й газ')+' → '+l.library+' → '+l.transfer","l.rates+' → '+l.library+' → '+l.transfer")
  .replace("      await press(page.getByRole('button',{name:locale==='en'?'Aircraft, rates & throttle':'Дрон, рейти й газ',exact:true}),'Open tuning settings');","      await press(page.getByRole('button',{name:l.radio,exact:true}),'Open radio setup');\n      await press(page.locator('#setup-dialog').getByRole('button',{name:l.rates,exact:true}),'Open Rates owner');");
assert.equal(hash(original),first.observer.sha256,'Recovered run-1 source must match its original receipt exactly');
await fs.writeFile(path.join(stage,'tuning-backup/run1/observer-original.mjs'),original,{flag:'wx'});
for(const name of [
  'practice-local-ux-reproduction-20261018.mjs',
  'practice-local-ux-node22-reproduction-20261018.mjs',
  'practice-local-ux-complete-reproduction-20261018.mjs',
  'practice-current-offline-audit-20261018.mjs',
  'practice-historical-ui-inspect-20261018.mjs',
  'practice-profile-import-policy-before-20261018.mjs',
  'practice-tuning-backup-audit-20261018.mjs',
  'practice-guide-tuning-before-20261018.tap',
  'practice-guide-tuning-after-20261018.tap',
  'practice-guide-tuning-final-20261018.tap',
  'practice-guide-tuning-library-final-20261018.tap',
  'practice-guide-tuning-direct-route-20261018.tap',
  'practice-tuning-upload-css-before-20261018.tap',
  'practice-tuning-upload-css-after-20261018.tap',
  'practice-observer-post-fix-20261018.tap',
  'practice-tuning-guide-bundle-20261018.log',
  'practice-tuning-library-guide-bundle-20261018.log',
  'practice-tuning-direct-guide-bundle-20261018.log',
  'practice-tuning-upload-fixed-bundle-20261018.log',
])await copy('/private/tmp/'+name,'support/'+name);
for(const name of ['flight-practice-main-cb8-20261018-candidate','flight-practice-tuning-guide-20261018-candidate','flight-practice-tuning-library-guide-20261018-candidate','flight-practice-tuning-direct-guide-20261018-candidate','flight-practice-tuning-upload-fixed-20261018-candidate'])
  for(const member of ['optional-packages.json','optional-candidate-verification.json','optional-checksums.json','optional-package-review.json'])
    await copy('/Volumes/alex/CodexMigrationStaging/'+name+'/'+member,`candidate-metadata/${name}/${member}`);
await fs.writeFile(path.join(stage,'capture-provenance.json'),JSON.stringify({format:'PracticeEvidenceCaptureProvenance.v1',copies,notes:[
  'Original failed receipts are unchanged. Raw capture-time temporary paths remain provenance; retained relative members are durable within this evidence collection.',
  'The first passing offline receipt has a stale profiles.input description. It did not import a new response into the separate Rates owner. Its original bytes remain unchanged; the final audited receipt records the actual calibration-only policy and equal prior/retained response hashes.',
  'Node20 first local-UX attempt failed for a missing sparse fixture. Node22 second attempt failed for a different missing sparse fixture. Both exact committed fixtures were restored; the final Node22 attempt passes without increasing its deadline. This does not diagnose the original remote CI timeout.',
  'Tuning run1: incomplete guide route. Runs2/3: real Worlds CSS-hidden upload. Run4: all flows passed but optional-core request classification failed. Run5: observer sampled a transient disabled control too early. Run6: final bounded enabled-state wait plus exact declared optional-core/fallback checks passes. No original result was relabeled.',
  'Original candidate archives remain separately retained at their named external paths. This collection includes their envelopes/checksums/admissions, not all candidate ZIP bytes. No public release or human approval.'
]},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({stage,copied:copies.length,recoveredFirstObserver:true}));
