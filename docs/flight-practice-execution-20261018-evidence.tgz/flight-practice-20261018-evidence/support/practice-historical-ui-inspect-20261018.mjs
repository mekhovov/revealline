import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { chromium } from '/Users/oleksandr.mekhovov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import { admitPinnedHistoricalPractice } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/practice-historical-admission.mjs';
import { readEditionZip } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
import { unlockObservedPage } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/optional-installation-observer-helpers.mjs';

const output='/private/tmp/practice-historical-ui-20261018.kFyM1j';
const bundle='/Volumes/alex/CodexMigrationStaging/flight-practice-previous-v01424-20261016-candidate';
assert(process.env.OPTIONAL_INSTALLATION_PASSWORD);
const historical=await admitPinnedHistoricalPractice(bundle);
const hash=b=>createHash('sha256').update(b).digest('hex');
const maps=new Map();
for(const p of historical.envelope.packages) maps.set(p.id,readEditionZip(historical.admittedBytes.get(p.distribution.path)));
const types={'.mjs':'text/javascript','.js':'text/javascript','.json':'application/json','.html':'text/html','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.webp':'image/webp','.woff2':'font/woff2'};
const server=http.createServer((req,res)=>{
  const u=new URL(req.url,'http://127.0.0.1');
  const match=/^\/revealline\/practice\/(civilian-flight|civilian-fpv|fpv-worlds)\/releases\/v0\.142\.4\/site\/(.+)$/.exec(u.pathname);
  const bytes=match&&maps.get(match[1]).get(match[2]);
  if(!bytes){res.writeHead(404);res.end();return;}
  res.writeHead(200,{'Content-Type':types[path.extname(match[2])]??'application/octet-stream','Content-Length':bytes.length,'Cache-Control':'no-store'});res.end(bytes);
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
let browser;
const report={format:'HistoricalPracticeUIInspection.v1',admission:historical.receipt,observations:[],passed:false,cleanup:{browser:false,server:false},scope:'Public UI mapping only; not upgrade continuity, offline qualification, physical input, learning or publication.'};
const deadline=setTimeout(()=>{void browser?.close();server.closeAllConnections();server.close();},120000);
try{
  browser=await chromium.launch({channel:'chrome',headless:true});
  report.browser=browser.version();
  const context=await browser.newContext({viewport:{width:1280,height:900},locale:'en-US'});
  context.setDefaultTimeout(8000);
  const page=await context.newPage();
  async function snapshot(id,stage){
    const data=await page.evaluate(()=>{
      const d=document,visible=n=>!!n?.getClientRects().length&&getComputedStyle(n).visibility!=='hidden'&&!n.closest('[hidden]');
      return {lang:d.documentElement.lang,dialogs:[...d.querySelectorAll('dialog[open]')].map(n=>n.id),buttons:[...d.querySelectorAll('button,a,select,summary')].filter(visible).slice(0,100).map(n=>({id:n.id,tag:n.tagName,label:n.innerText?.trim().slice(0,160),value:n.tagName==='SELECT'?n.value:undefined,disabled:n.disabled??false,dataTab:n.dataset.tab})),height:d.querySelector('#readout')?.innerText,hud:[...d.querySelectorAll('[data-sim-hud]')].filter(visible).map(n=>({text:n.innerText,part:n.dataset.simHud})),phase:d.querySelector('[data-mode-play-shell]')?.dataset.phase};
    });
    const file=path.join(output,id+'-'+stage+'.png');const image=await page.screenshot();await fs.writeFile(file,image,{flag:'wx'});
    report.observations.push({id,stage,url:page.url(),data,screenshot:{path:file,bytes:image.length,sha256:hash(image)}});
  }
  async function click(selector){const n=page.locator(selector);assert(await n.isVisible());assert(await n.isEnabled());await n.click();}
  for(const id of ['civilian-flight','fpv-worlds']){
    await page.goto(`http://127.0.0.1:${server.address().port}/revealline/practice/${id}/releases/v0.142.4/site/optional-practice/${id}/index.html?lang=en`);
    await unlockObservedPage(page,process.env.OPTIONAL_INSTALLATION_PASSWORD);
    await page.locator(id==='civilian-flight'?'#gym-shell-action-primary':'#worlds-shell-action-missions').waitFor({state:'visible'});
    await snapshot(id,'home');
    if(id==='civilian-flight'){
      await click('#gym-shell-action-primary');await snapshot(id,'briefing');
      if(await page.locator('#gym-shell-action-start').isVisible())await click('#gym-shell-action-start');
      await snapshot(id,'started');
      await click('#gym-shell-action-pause');await snapshot(id,'paused');
    }else{
      await click('#worlds-shell-action-missions');await snapshot(id,'missions');
      if(await page.locator('#try-first-flight').isVisible()){
        await page.locator('#first-flight-mode').selectOption('self-level');
        await click('#try-first-flight');await snapshot(id,'legacy-first-flight');
      }
    }
  }
  report.passed=true;
}catch(e){report.failure=e.message;process.exitCode=1;}
finally{
  clearTimeout(deadline);
  try{await browser?.close();report.cleanup.browser=true;}catch(e){report.cleanup.browserError=e.message;}
  await new Promise(resolve=>{server.close(resolve);server.closeAllConnections();});report.cleanup.server=true;
  await fs.writeFile(path.join(output,'observation.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({passed:report.passed,failure:report.failure,stages:report.observations.map(o=>o.id+':'+o.stage),cleanup:report.cleanup}));
}
