import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import { createHash } from 'node:crypto';
import { setTimeout as pause } from 'node:timers/promises';
import { chromium } from '/Users/oleksandr.mekhovov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import { validateOptionalPackageAdmission } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/optional-package-admission.mjs';
import { readEditionZip } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
import { unlockObservedPage } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/optional-installation-observer-helpers.mjs';
import { nativeA11yScope } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/observe-practice-directory-native-a11y.mjs';
import { validateTuningLibrary } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/optional-practice/civilian-fpv/tuning-library.mjs';
import { OPTIONAL_PACKAGE_POLICIES } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/optional-package-policy.mjs';

const bundle = '/Volumes/alex/CodexMigrationStaging/flight-practice-tuning-upload-fixed-20261018-candidate';
const output = process.argv[2];
assert(path.isAbsolute(output) && path.dirname(output) === '/private/tmp');
assert(process.env.OPTIONAL_INSTALLATION_PASSWORD);
await fs.mkdir(output);
const sha = b => createHash('sha256').update(b).digest('hex');
const pin = (p,b) => ({path:p,bytes:b.length,sha256:sha(b)});
const scope = nativeA11yScope({overallMs:180000,actionMs:10000});
const run = (label, fn) => scope.run(label,fn);
const envelopeBytes = await fs.readFile(path.join(bundle,'optional-packages.json'));
const envelope = JSON.parse(envelopeBytes);
const report = {format:'PracticeTuningBackupBrowserObservation.v1',createdAt:new Date().toISOString(),sourceRevision:envelope.sourceRevision,sourceTree:envelope.sourceTree,envelopeSha256:sha(envelopeBytes),qualified:false,publicEligible:false,passed:false,guides:[],backups:[],cleanup:[],requestFailures:[],scope:'Local Chrome, six actual packaged EN/UK guide sections and four FPV public-UI full-library download/upload/restore/reload round trips. Nonempty default libraries, not customized settings, origin eviction, offline readiness, flights, novice review, physical inputs, speech or public deployment.'};
report.scope='Local Chrome, six packaged EN/UK guide sections and four FPV public-UI named custom-library backup round trips. A saved three-profile library is downloaded, a later fourth profile is created, then upload/restore must remove that fourth profile and recover all prior semantic fields across reload. Not origin eviction, radio calibration, controller-tune library, offline readiness, flights, novice review, physical inputs, speech or deployment.';
const maps = new Map();
report.admission = await run('Full original artifact admission',()=>validateOptionalPackageAdmission(envelope,{read:row=>fs.readFile(path.join(bundle,row.path))}));
for(const item of envelope.packages) maps.set(item.id,readEditionZip(await fs.readFile(path.join(bundle,item.distribution.path))));
const types={'.mjs':'text/javascript','.js':'text/javascript','.json':'application/json','.html':'text/html','.css':'text/css','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.woff2':'font/woff2','.webmanifest':'application/manifest+json'};
const server=http.createServer((req,res)=>{
  const url=new URL(req.url,'http://127.0.0.1');
  const match=/^\/revealline\/practice\/(civilian-flight|civilian-fpv|fpv-worlds)\/releases\/v0\.151\.1\/site\/(.+)$/.exec(url.pathname);
  const bytes=match && maps.get(match[1])?.get(match[2]);
  if(!bytes){if(report.requestFailures.length<64)report.requestFailures.push(url.pathname);res.writeHead(404);res.end();return;}
  res.writeHead(200,{'Content-Type':types[path.extname(match[2])]??'application/octet-stream','Content-Length':bytes.length,'Cache-Control':'no-store'});res.end(bytes);
});
let browser, context;
const close = async (name,fn) => {const cleanup=nativeA11yScope({overallMs:10000,actionMs:10000});try{await cleanup.run(name,fn);report.cleanup.push({name,passed:true});}catch(e){report.cleanup.push({name,passed:false,error:e.message});}finally{cleanup.stop();}};
const acquire = async (name,fn,adopt,lateClose) => run(name,async()=>{const value=await fn();adopt(value);try{scope.check();}catch(e){await lateClose(value);throw e;}return value;});
try{
  await run('Start owned loopback server',()=>new Promise(resolve=>server.listen(0,'127.0.0.1',resolve)));
  const origin=`http://127.0.0.1:${server.address().port}`;
  browser=await acquire('Start local Chrome',()=>chromium.launch({channel:'chrome',headless:true,timeout:10000}),b=>{browser=b;},b=>b.close());
  report.browser=browser.version();
  async function freshContext(){
    context=await acquire('Create isolated context',()=>browser.newContext({viewport:{width:1280,height:900},locale:'en-US',acceptDownloads:true}),c=>{context=c;},c=>c.close());
    context.setDefaultTimeout(8000);context.setDefaultNavigationTimeout(8000);
    return run('Create owned page',()=>context.newPage());
  }
  const labels={en:{settings:'Settings',radio:'Radio setup',rates:'Rates & throttle',library:'Library',transfer:'Import / export · Betaflight and backups',backup:'Backup complete library',download:'Download file',upload:'Upload text / JSON',restore:'Restore library backup',text:'Paste CLI or a SIM rate profile',warning:'Radio calibration and the tuning library are separate backups.'},uk:{settings:'Налаштування',radio:'Налаштувати пульт',rates:'Рейти й газ',library:'Бібліотека',transfer:'Імпорт / експорт · Betaflight і резервні копії',backup:'Резервна копія всієї бібліотеки',download:'Завантажити файл',upload:'Завантажити текст / JSON',restore:'Відновити бібліотеку',text:'Вставте CLI або профіль рейтів SIM',warning:'Калібрування пульта й бібліотека налаштувань потребують окремих резервних копій.'}};
  const base=(id,lang)=>`${origin}/revealline/practice/${id}/releases/${envelope.version}/site/optional-practice/${id}/`;
  async function press(locator,label){report.currentStep=label;await run(label,async()=>{await locator.waitFor({state:'visible'});while(!await locator.isEnabled()){scope.check();await pause(50);}scope.check();await locator.press('Enter');});}
  async function capture(page,file){const bytes=await run('Capture '+file,()=>page.screenshot({timeout:5000}));assert(bytes.length<8*1024*1024);await fs.writeFile(path.join(output,file),bytes,{flag:'wx'});return {...pin(file,bytes),visuallyQualified:false};}
  for(const locale of ['en','uk']) for(const id of maps.keys()){
    const row={id,locale,passed:false};report.guides.push(row);
    const page=await freshContext();const l=labels[locale];
    await run('Open admitted guide',()=>page.goto(base(id,locale)+`guide.html?lang=${locale}`));
    await run('Normal guide access',()=>unlockObservedPage(page,process.env.OPTIONAL_INSTALLATION_PASSWORD));
    await run('Wait for selected guide locale',()=>page.waitForFunction(locale=>document.documentElement.lang===locale&&document.querySelector('#locale')?.value===locale,locale));
    const sections=page.locator(`section[lang="${locale}"]`);
    const text=(await run('Read visible localized guide',()=>sections.allInnerTexts())).join(' ').replace(/\s+/g,' ');
    for(const phrase of [l.warning,(locale==='en'?'Aircraft, rates & throttle':'Дрон, рейти й газ')+' → '+l.library+' → '+l.transfer,l.backup,l.download,l.upload,l.restore])assert(text.includes(phrase),`Guide omits ${locale} ${phrase}`);
    const paragraph=sections.locator('p').filter({hasText:l.warning});assert.equal(await paragraph.count(),1);
    await run('Scroll backup instructions',()=>paragraph.scrollIntoViewIfNeeded());
    row.screenshot=await capture(page,`${locale}-${id}-guide.png`);
    row.originalGuide=pin(`optional-practice/${id}/guide.html`,maps.get(id).get(`optional-practice/${id}/guide.html`));
    row.passed=true;
    await close('Close guide context',()=>context.close());context=null;
  }
  for(const locale of ['en','uk'])for(const id of ['civilian-fpv','fpv-worlds']){
    const row={id,locale,passed:false,exports:[],optionalCoreFallbacks:[]};report.backups.push(row);
    const page=await freshContext();const l=labels[locale],prefix=id==='civilian-fpv'?'academy':'worlds';
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    async function open(){
      await run('Open admitted app',()=>page.goto(base(id,locale)+`index.html?lang=${locale}`));
      await run('Normal app access',()=>unlockObservedPage(page,process.env.OPTIONAL_INSTALLATION_PASSWORD));
      await press(page.locator(`#${prefix}-shell-action-settings`),'Open Settings');
      if(id==='civilian-fpv'){
        assert(OPTIONAL_PACKAGE_POLICIES[id].coreOnlyImports.some(r=>r.from==='optional-practice/civilian-fpv/sim-presentation.mjs'&&r.source==='../../game/ui/global-settings-tools.mjs'));
        assert(!maps.get(id).has('game/ui/global-settings-tools.mjs'));
        await press(page.locator(`#${prefix}-settings-tab-extras`),'Show optional-core fallback');
        const fallback=page.locator('[data-sim-global-tools-fallback]').getByRole('status');
        const expected=locale==='en'?'This package does not include the main game tools. SIM tools remain available.':'Цей пакет не містить спільних інструментів основної гри. Інструменти SIM залишаються доступними.';
        await run('Require real optional-core failure feedback',()=>fallback.filter({hasText:expected}).waitFor({state:'visible'}));
        assert.equal(await fallback.innerText(),expected);
        row.optionalCoreFallbacks.push({visible:true,text:expected});
      }
      await press(page.locator(`#${prefix}-settings-tab-controls`),'Open Controls');
      await press(page.getByRole('button',{name:locale==='en'?'Aircraft, rates & throttle':'Дрон, рейти й газ',exact:true}),'Open tuning settings');
      await press(page.locator('.workbench-nav').getByRole('button',{name:l.library,exact:true}),'Open Library');
      const summary=page.locator('summary').filter({hasText:l.transfer});
      await press(summary,'Open backup disclosure');
    }
    const text=()=>page.getByRole('textbox',{name:l.text,exact:true});
    async function exported(stage){
      await press(page.getByRole('button',{name:l.backup,exact:true}),'Prepare complete library backup');
      const value=await run('Read public library backup',()=>text().inputValue());
      const parsed=validateTuningLibrary(value);assert(parsed.profiles.length>0&&parsed.setups.length>0);
      row.exports.push({stage,...pin(`${locale}-${id}-${stage}.json`,Buffer.from(value)),revision:parsed.revision,profiles:parsed.profiles.length,setups:parsed.setups.length});
      await fs.writeFile(path.join(output,`${locale}-${id}-${stage}.json`),value,{flag:'wx'});
      return {value,parsed};
    }
    await open();
    await press(page.getByRole('button',{name:locale==='en'?'New Actual profile':'Новий профіль Actual',exact:true}),'Create actual saved custom profile');
    await run('Name custom backup profile',()=>page.getByRole('textbox',{name:locale==='en'?'Profile name':'Назва профілю',exact:true}).fill('Local browser backup '+locale));
    await press(page.getByRole('button',{name:locale==='en'?'Save for next flight':'Зберегти для наступного польоту',exact:true}),'Save named custom profile');
    const before=await exported('before');
    assert.equal(before.parsed.profiles.length,3);
    assert(before.parsed.profiles.some(p=>p.name==='Local browser backup '+locale));
    row.populatedBackup=true;
    const downloading=page.waitForEvent('download',{timeout:8000});
    await press(page.getByRole('button',{name:l.download,exact:true}),'Download library JSON');
    const download=await run('Observe real browser download',()=>downloading);
    const file=path.join(output,`${locale}-${id}-download.json`);
    await run('Keep external downloaded backup',()=>download.saveAs(file));
    const downloaded=await fs.readFile(file);assert.deepEqual(validateTuningLibrary(downloaded.toString()),before.parsed);
    row.download=pin(path.basename(file),downloaded);
    await press(page.getByRole('button',{name:locale==='en'?'New Actual profile':'Новий профіль Actual',exact:true}),'Create later fourth profile that restoration must remove');
    const changed=await exported('changed');
    assert.equal(changed.parsed.profiles.length,4);
    assert.equal(changed.parsed.revision,before.parsed.revision+1);
    await run('Upload downloaded library backup',async()=>{const input=page.getByLabel(l.upload,{exact:true});await input.waitFor({state:'visible'});await input.setInputFiles(file);});
    await run('Wait for selected JSON to appear',()=>page.waitForFunction(({label,expected})=>[...document.querySelectorAll('textarea')].some(el=>el.getAttribute('aria-label')===label&&el.value===expected),{label:l.text,expected:downloaded.toString()}));
    await press(page.getByRole('button',{name:l.restore,exact:true}),'Restore downloaded complete library');
    const after=await exported('after');
    assert.equal(after.parsed.revision,changed.parsed.revision+1);
    const semantic=value=>{const {revision,...rest}=value;return rest;};
    assert.deepEqual(semantic(after.parsed),semantic(before.parsed));
    row.normalization='Restoration advances the immediately prior transaction revision by exactly one, removes the later fourth profile, and restores every non-revision field to the downloaded three-profile named baseline.';
    row.screenshot=await capture(page,`${locale}-${id}-restored.png`);
    await open();
    const reloaded=await exported('reloaded');assert.equal(reloaded.value,after.value);
    assert.deepEqual(errors,[]);row.errors=errors;row.passed=true;
    await close('Close backup context',()=>context.close());context=null;
  }
  report.passed=report.guides.length===6&&report.backups.length===4&&[...report.guides,...report.backups].every(r=>r.passed);
}catch(e){report.failure=e.message;process.exitCode=1;
  const page=context?.pages()[0];
  if(page)try{report.failureDOM=await page.evaluate(()=>({dialogs:[...document.querySelectorAll('dialog[open]')].map(n=>({id:n.id,label:n.getAttribute('aria-label')})),visible:[...document.querySelectorAll('button,summary,input[type=file]')].filter(n=>n.checkVisibility()).map(n=>({id:n.id,label:n.innerText||n.getAttribute('aria-label')})),uploads:[...document.querySelectorAll('input[type=file]')].map(n=>({label:n.getAttribute('aria-label'),parents:[n,...(function*(p){while(p){yield p;p=p.parentElement;}})(n.parentElement)].slice(0,10).map(p=>({tag:p.tagName,id:p.id,hidden:p.hidden,open:p.open,section:p.dataset.section,display:getComputedStyle(p).display}))}))}));await page.screenshot({path:path.join(output,'failure.png'),timeout:5000});}catch{report.failureCaptureFailed=true;}
}
finally{
  scope.stop();
  if(context)await close('Close remaining context',()=>context.close());
  if(browser)await close('Close browser',()=>browser.close());
  await close('Close loopback server',()=>new Promise((resolve,reject)=>{server.close(e=>e?reject(e):resolve());server.closeAllConnections();}));
  await close('Settle outstanding owned operations',()=>scope.settled());
  report.pending=scope.pending();
  const probe='/revealline/practice/civilian-fpv/releases/v0.151.1/site/game/ui/global-settings-tools.mjs';
  const declaredProbes=report.requestFailures.filter(p=>p===probe);
  const fallbackCount=report.backups.filter(r=>r.id==='civilian-fpv').reduce((n,r)=>n+r.optionalCoreFallbacks.length,0);
  report.optionalCoreProbeClassification={path:probe,count:declaredProbes.length,visibleFallbacks:fallbackCount,policy:'Only the exact policy-declared lazy core-only import is exempt; all four loads must show the localized fallback. Core tools are not an offline package dependency.'};
  const unexpected=report.requestFailures.filter(p=>p!=='/favicon.ico'&&p!==probe);
  report.unexpectedRequestFailures=unexpected;
  report.passed&&=report.pending===0&&report.cleanup.every(r=>r.passed)&&unexpected.length===0&&declaredProbes.length===4&&fallbackCount===4&&report.requestFailures.filter(p=>p==='/favicon.ico').length<=1;
  report.observer=pin(path.basename(new URL(import.meta.url).pathname),await fs.readFile(new URL(import.meta.url)));
  await fs.writeFile(path.join(output,'observation.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({passed:report.passed,failure:report.failure,guides:report.guides.filter(r=>r.passed).length,backups:report.backups.filter(r=>r.passed).length,pending:report.pending,cleanup:report.cleanup}));
  if(!report.passed)process.exitCode=1;
}
