import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { frozenSource } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
import { observeIndustrialPhase } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/verify-industrial-features.mjs';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const base = '/Volumes/alex/CodexMigrationStaging';
const source = frozenSource(root), hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const output = `${base}/practice-main36-write-concurrency-20261019`;
await fs.mkdir(output);
const report = { format: 'PracticeLightweightIntegrationDiagnostic.v1', source, node: process.version, fullBuild: false, browserRun: false, operations: [] };
const operations = [
  { id: 'bounded-network-write-diagnostic', command: ['/private/tmp/practice-main36-write-concurrency-target-20261019.mjs'], deadlineMs: 120000 },
  { id: 'serial-focused-regressions', command: ['--test', '--test-concurrency=1', 'scripts/test-build-entry-writer.mjs', 'scripts/test-game-cli.mjs', 'game/test/fpv-aircraft-coach.test.mjs', 'game/test/fullscreen.test.mjs', 'game/test/first-flight-home-host.test.mjs', 'game/test/official-downloads.test.mjs', 'game/test/continuous-play-preferences.test.mjs'], deadlineMs: 600000 },
];
for (const operation of operations) {
  const log = `${output}/${operation.id}.log`;
  const result = await observeIndustrialPhase({ command: operation.command, cwd: root, log, deadlineMs: operation.deadlineMs });
  report.operations.push({ ...operation, result, logSha256: hash(await fs.readFile(log)) });
  console.log(JSON.stringify({ id: operation.id, result }));
  assert.deepEqual(frozenSource(root), source);
  if (result.exitCode !== 0 || result.timedOut || result.interrupted || result.executionError) break;
}
report.sourceAfter = frozenSource(root);
report.completed = report.operations.length === operations.length && report.operations.every(({ result }) => result.exitCode === 0 && !result.timedOut && !result.interrupted && !result.executionError);
report.scope = 'Small externally timed SMB diagnostic followed by serial selected unit/fixture regressions. All evidence goes to approved share. No full build, full suite, native browser/profile, performance budget or release acceptance.';
await fs.writeFile(`${output}/receipt.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
if (!report.completed) process.exitCode = 1;
