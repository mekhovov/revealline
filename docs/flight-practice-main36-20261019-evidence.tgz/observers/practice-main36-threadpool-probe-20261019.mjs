import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync, spawn } from 'node:child_process';
import { performance } from 'node:perf_hooks';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const output = '/Volumes/alex/CodexMigrationStaging/practice-main36-threadpool-20261019';
const prior = '/Volumes/alex/CodexMigrationStaging/practice-main36-write-concurrency-20261019/report.json';
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const revision = () => execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim();
if (process.argv[2] === 'child') {
  const staging = process.argv[3];
  assert(staging.startsWith(`${output}/owned-probe-`));
  const pins = JSON.parse(await fs.readFile(prior, 'utf8'));
  assert.equal(revision(), pins.source);
  const original = await fs.readFile(`${root}/scripts/build-entry-writer.mjs`, 'utf8');
  assert.equal(hash(original), pins.originalWriterSha256);
  const variant = original.replace('Math.min(4, entries.length)', 'Math.min(16, entries.length)');
  assert.notEqual(variant, original);
  const entries = [];
  for (const pin of pins.entries) {
    const bytes = await fs.readFile(path.join(root, pin.path));
    assert.equal(hash(bytes), pin.sha256);
    entries.push({ name: pin.path, bytes });
  }
  const { writeBuildEntries } = await import(`data:text/javascript;base64,${Buffer.from(variant).toString('base64')}`);
  const began = performance.now();
  await writeBuildEntries(root, staging, entries);
  const elapsedMs = performance.now() - began;
  for (const entry of entries) assert((await fs.readFile(path.join(staging, entry.name))).equals(entry.bytes));
  console.log(JSON.stringify({ threadpoolSize: process.env.UV_THREADPOOL_SIZE, applicationWorkers: 16, elapsedMs, exactFilesVerified: entries.length, variantSha256: hash(variant) }));
} else {
  await fs.mkdir(output);
  const source = revision();
  const work = await fs.mkdtemp(`${output}/owned-probe-`);
  const report = { source, node: process.version, inheritedThreadpoolSize: process.env.UV_THREADPOOL_SIZE ?? null, cases: [], ownedWork: work, removed: false, scope: 'Diagnostic child-only UV threadpool ABBA comparison, fixed 16 in-memory application workers, 128 pinned files. No production source/environment changes; not full-build or acceptance evidence.' };
  for (const [index, size] of [4, 16, 16, 4].entries()) {
    const staging = path.join(work, `case-${index}`);
    await fs.mkdir(staging);
    const result = await new Promise((resolve, reject) => {
      const child = spawn(process.execPath, [process.argv[1], 'child', staging], { cwd: root, env: { ...process.env, UV_THREADPOOL_SIZE: String(size) }, stdio: ['ignore', 'pipe', 'pipe'] });
      let stdout = '', stderr = '', timedOut = false;
      const timer = setTimeout(() => { timedOut = true; child.kill('SIGKILL'); }, 25000);
      child.stdout.on('data', (data) => { stdout += data; });
      child.stderr.on('data', (data) => { stderr += data; });
      child.once('error', reject);
      child.once('close', (code, signal) => { clearTimeout(timer); resolve({ code, signal, timedOut, stdout, stderr }); });
    });
    report.cases.push({ index, size, ...result });
    await fs.writeFile(`${output}/receipt.json`, JSON.stringify(report, null, 2) + '\n');
    assert.equal(result.code, 0, JSON.stringify(result));
    console.log(result.stdout.trim());
  }
  assert.equal(revision(), source);
  await fs.rm(work, { recursive: true });
  report.removed = true;
  report.sourceAfter = revision();
  await fs.writeFile(`${output}/receipt.json`, JSON.stringify(report, null, 2) + '\n');
}
