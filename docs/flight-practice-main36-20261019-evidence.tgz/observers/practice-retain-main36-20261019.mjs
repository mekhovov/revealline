import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const base = '/Volumes/alex/CodexMigrationStaging';
const staging = `${base}/practice-main36-20261019-evidence`;
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const items = [
  ...['practice-main36-write-concurrency-target-20261019.mjs', 'practice-main36-light-checks-20261019.mjs', 'practice-main36-threadpool-probe-20261019.mjs', 'practice-main36-candidate-20261019.mjs', 'practice-retain-main36-20261019.mjs'].map((name) => [`/private/tmp/${name}`, `observers/${name}`]),
  ...['original-writer.mjs', 'bounded-network-write-diagnostic.log', 'report.json', 'serial-focused-regressions.log', 'receipt.json'].map((name) => [`${base}/practice-main36-write-concurrency-20261019/${name}`, `lightweight/${name}`]),
  [`${base}/practice-main36-threadpool-20261019/receipt.json`, 'threadpool/receipt.json'],
  ...['receipt.json', 'comparison.json', 'bundle.log'].map((name) => [`${base}/practice-main36-candidate-20261019/${name}`, `candidate/${name}`]),
  ...['optional-packages.json', 'optional-candidate-verification.json', 'optional-package-review.json', 'optional-checksums.json'].map((name) => [`${base}/flight-practice-main36-20261019-candidate/${name}`, `candidate/${name}`]),
];
await fs.mkdir(staging);
const inventory = [];
for (const [original, name] of items) {
  const bytes = await fs.readFile(original);
  const target = path.join(staging, name);
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.writeFile(target, bytes, { flag: 'wx' });
  inventory.push({ path: name, original, bytes: bytes.length, sha256: hash(bytes) });
}
const range = execFileSync('git', ['range-diff', '--no-color', '237b405437def3c41b01165fe057af1ab06f618c..codex/practice-before-main-36e8-20261019', '36e8bc426589ab952c2fcc4fd62df39800edfeca..08fc3430c8f6670a76c1a749b3ad0b65bc9f9ded'], { cwd: root });
await fs.writeFile(`${staging}/rebase-range-diff.txt`, range, { flag: 'wx' });
inventory.push({ path: 'rebase-range-diff.txt', bytes: range.length, sha256: hash(range) });
await fs.writeFile(`${staging}/inventory.json`, JSON.stringify({ files: inventory }, null, 2) + '\n', { flag: 'wx' });
const archive = `${base}/practice-main36-20261019-evidence.tgz`;
execFileSync('/usr/bin/tar', ['-czf', archive, '-C', staging, '.']);
const verification = await fs.mkdtemp(`${base}/practice-main36-evidence-readback-`);
execFileSync('/usr/bin/tar', ['-xzf', archive, '-C', verification]);
for (const item of inventory) assert.equal(hash(await fs.readFile(path.join(verification, item.path))), item.sha256);
assert.deepEqual(JSON.parse(await fs.readFile(`${verification}/inventory.json`)).files, inventory);
const bytes = await fs.readFile(archive);
const target = `${root}/docs/flight-practice-main36-20261019-evidence.tgz`;
await fs.writeFile(target, bytes, { flag: 'wx' });
assert.equal(hash(await fs.readFile(target)), hash(bytes));
console.log(JSON.stringify({ archive: target, sha256: hash(bytes), bytes: bytes.length, files: inventory.length, verifiedExtracted: true, verification }, null, 2));
