import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { frozenSource } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
import { observeIndustrialPhase } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/verify-industrial-features.mjs';
import { readEditionZip } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const base = '/Volumes/alex/CodexMigrationStaging';
const output = `${base}/practice-main36-candidate-20261019`;
const candidate = `${base}/flight-practice-main36-20261019-candidate`;
const oldCandidate = `${base}/flight-practice-main-237-20261018-candidate`;
const source = frozenSource(root);
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
await fs.mkdir(output);
const share = await fs.statfs(base);
assert(share.bavail * share.bsize > 2 * 1024 ** 3, 'Insufficient share headroom');
const receipt = { source, node: process.version, candidate, previousCandidate: oldCandidate, scope: 'Small standalone packages only, output on approved share, 512 MiB child heap cap. Not a full site build, browser test, hosting or human approval.' };
receipt.result = await observeIndustrialPhase({
  command: ['--max-old-space-size=512', 'scripts/bundle-optional-practice.mjs', '--out', candidate, '--base-path', '/revealline/', '--packages', 'civilian-flight,civilian-fpv,fpv-worlds'],
  cwd: root, log: `${output}/bundle.log`, deadlineMs: 600000,
});
receipt.logSha256 = hash(await fs.readFile(`${output}/bundle.log`));
receipt.sourceAfter = frozenSource(root);
assert.deepEqual(receipt.sourceAfter, source);
await fs.writeFile(`${output}/receipt.json`, JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
assert.equal(receipt.result.exitCode, 0);
const newBytes = await fs.readFile(`${candidate}/optional-packages.json`);
const oldBytes = await fs.readFile(`${oldCandidate}/optional-packages.json`);
const current = JSON.parse(newBytes), previous = JSON.parse(oldBytes);
assert.equal(current.sourceRevision, source.sourceRevision);
const comparison = { source, previousSource: previous.sourceRevision, envelopeSha256: hash(newBytes), previousEnvelopeSha256: hash(oldBytes), packages: [], note: 'Exact ZIP-member comparisons include generated identities. Unchanged entries do not automatically qualify a new package. Changed runtime bytes require affected browser checks.' };
for (const pkg of current.packages) {
  const old = previous.packages.find((item) => item.id === pkg.id);
  assert(old);
  const currentZip = await fs.readFile(path.join(candidate, pkg.distribution.path));
  const oldZip = await fs.readFile(path.join(oldCandidate, old.distribution.path));
  assert.equal(hash(currentZip), pkg.distribution.sha256);
  assert.equal(hash(oldZip), old.distribution.sha256);
  const nextFiles = readEditionZip(currentZip), priorFiles = readEditionZip(oldZip);
  const changed = [], added = [], removed = [];
  let unchanged = 0;
  for (const [name, bytes] of nextFiles) {
    if (!priorFiles.has(name)) added.push(name);
    else if (bytes.equals(priorFiles.get(name))) unchanged++;
    else changed.push({ path: name, before: hash(priorFiles.get(name)), after: hash(bytes) });
  }
  for (const name of priorFiles.keys()) if (!nextFiles.has(name)) removed.push(name);
  comparison.packages.push({ id: pkg.id, zipSha256: hash(currentZip), bytes: currentZip.length, unchanged, changed, added, removed });
}
await fs.writeFile(`${output}/comparison.json`, JSON.stringify(comparison, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ completed: true, source, envelopeSha256: comparison.envelopeSha256, packages: comparison.packages.map(({ id, unchanged, changed, added, removed }) => ({ id, unchanged, changed: changed.map((item) => item.path), added, removed })) }, null, 2));
