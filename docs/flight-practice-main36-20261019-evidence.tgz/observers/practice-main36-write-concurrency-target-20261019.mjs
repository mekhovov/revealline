import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { performance } from 'node:perf_hooks';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const output = '/Volumes/alex/CodexMigrationStaging/practice-main36-write-concurrency-20261019';
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const original = await fs.readFile(`${root}/scripts/build-entry-writer.mjs`, 'utf8');
assert.equal(original.split('Math.min(4, entries.length)').length, 2);
const names = execFileSync('git', ['ls-files', '-z', '--', 'game'], { cwd: root, encoding: 'utf8' }).split('\0').filter((name) => name.endsWith('.mjs') && !name.includes('/test/')).sort((a, b) => hash(a).localeCompare(hash(b)));
const entries = [];
for (const name of names) {
  if ((await fs.stat(path.join(root, name))).size > 32768) continue;
  entries.push({ name, bytes: await fs.readFile(path.join(root, name)) });
  if (entries.length === 128) break;
}
assert.equal(entries.length, 128);
const work = await fs.mkdtemp(`${output}/owned-probe-`);
const report = { format: 'PracticeWriteConcurrencyDiagnostic.v1', node: process.version,
  source: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  originalWriterSha256: hash(original), localFreeBefore: null,
  entries: entries.map(({ name, bytes }) => ({ path: name, bytes: bytes.length, sha256: hash(bytes) })),
  cases: [], ownedWork: work, ownedTemporaryDirectoryRemoved: false,
  scope: 'Small SMB-only write diagnostic. In-memory variants change only the worker count, with no repository/runtime changes. Timings exclude subsequent exact-byte readback. Not a normal build, performance acceptance or installation check.' };
const local = await fs.statfs(root);
report.localFreeBefore = local.bavail * local.bsize;
await fs.writeFile(`${output}/original-writer.mjs`, original, { flag: 'wx' });
for (const [index, concurrency] of [4, 8, 16, 16, 8, 4].entries()) {
  const source = original.replace('Math.min(4, entries.length)', `Math.min(${concurrency}, entries.length)`);
  const { writeBuildEntries } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
  const staging = path.join(work, `case-${index}-${concurrency}`);
  await fs.mkdir(staging);
  const began = performance.now();
  await writeBuildEntries(root, staging, entries);
  const elapsedMs = performance.now() - began;
  for (const entry of entries) assert((await fs.readFile(path.join(staging, entry.name))).equals(entry.bytes));
  report.cases.push({ index, concurrency, elapsedMs, exactFilesVerified: entries.length, variantSha256: hash(source) });
  console.log(JSON.stringify(report.cases.at(-1)));
}
assert.equal(hash(await fs.readFile(`${root}/scripts/build-entry-writer.mjs`)), report.originalWriterSha256);
assert(work.startsWith(`${output}/owned-probe-`));
await fs.rm(work, { recursive: true });
report.ownedTemporaryDirectoryRemoved = true;
await fs.writeFile(`${output}/report.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ completed: true, cases: report.cases, totalSourceBytes: entries.reduce((sum, item) => sum + item.bytes.length, 0), ownedTemporaryDirectoryRemoved: true }));
