// Local review only: original admitted bytes, with local publication pointers.
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { editionHash, inspectEditionZip } from '../../publishing/edition-zip.mjs';
import { validateOptionalPackageAdmission } from '../../publishing/optional-package-admission.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const bundle = path.join(here, 'optional-bundle');
const envelopeBytes = await fs.readFile(path.join(bundle, 'optional-packages.json'));
const envelope = JSON.parse(envelopeBytes);
const read = async (row) => {
  const bytes = await fs.readFile(path.join(bundle, row.path));
  if (bytes.length !== row.bytes || editionHash(bytes) !== row.sha256)
    throw new Error(`Artifact identity mismatch: ${row.path}`);
  return bytes;
};
await validateOptionalPackageAdmission(envelope, { read });
const files = new Map();
const packages = [];
const basePath = '/revealline/';
for (const item of envelope.packages) {
  const manifestBytes = await read(item.manifest);
  const manifest = JSON.parse(manifestBytes);
  const archive = await read(item.distribution);
  const members = inspectEditionZip(archive, [
    ...manifest.files,
    { path: 'optional-package.json', bytes: manifestBytes.length, sha256: editionHash(manifestBytes) },
  ]);
  const root = `${basePath}practice/${item.id}/`;
  const site = `${root}releases/${envelope.version}/site/`;
  for (const [name, bytes] of members) {
    files.set(site + name, bytes);
    if (name.startsWith('launcher/')) files.set(root + 'app/' + name.slice(9), bytes);
  }
  files.set(root + 'app/current.json', Buffer.from(JSON.stringify({
    id: item.id, version: envelope.version,
    scope: `../releases/${envelope.version}/site/`, entry: manifest.entry,
  }) + '\n'));
  packages.push({
    id: item.id, revision: item.revision,
    distribution: item.distribution, files: manifest.files.length,
    bytes: manifest.files.reduce((sum, row) => sum + row.bytes, 0),
    launcher: `http://127.0.0.1:8972${root}app/?lang=en`,
    runtime: `http://127.0.0.1:8972${site}${manifest.entry}?lang=en`,
  });
}
const mime = {
  '.html': 'text/html; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.webp': 'image/webp',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav',
  '.mp3': 'audio/mpeg', '.glb': 'model/gltf-binary', '.gltf': 'model/gltf+json',
};
const server = http.createServer((req, res) => {
  if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405); res.end(); return; }
  const parsed = new URL(req.url, 'http://127.0.0.1:8972');
  let name = parsed.pathname;
  if (name.endsWith('/')) name += 'index.html';
  const bytes = files.get(name);
  if (!bytes) { res.writeHead(404, { 'Cache-Control': 'no-store' }); res.end('Not found'); return; }
  res.writeHead(200, {
    'Content-Type': mime[path.extname(name)] ?? 'application/octet-stream',
    'Content-Length': bytes.length, 'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(req.method === 'HEAD' ? undefined : bytes);
});
await new Promise((resolve, reject) => {
  server.once('error', reject);
  server.listen(8972, '127.0.0.1', resolve);
});
const receipt = {
  purpose: 'Local browser qualification only; no publication or completed review gates',
  sourceRevision: envelope.sourceRevision, sourceTree: envelope.sourceTree,
  envelopeSha256: editionHash(envelopeBytes), pid: process.pid, port: 8972,
  servedFromMemory: true, memberBytesUnmodified: true,
  fixtureMetadata: 'Only app/current.json pointers are locally generated; all runtime, worker and launcher bytes are admitted originals.',
  packages,
};
await fs.writeFile(path.join(here, 'browser-staging.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify(receipt, null, 2));
process.on('SIGTERM', () => server.close(() => process.exit(0)));
