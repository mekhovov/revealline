import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = '/Users/oleksandr.mekhovov/.codex/worktrees/fpv-garage-surfaces/go_test';
const source = '216b36ce15df84f5148d9d16e92c5defdee0da09';
const candidate = '/private/tmp/fpv-library-integrated-admission-216b36ce1';
const out = '/private/tmp/fpv-library-integrated-browser-216b36ce1';
const prior = '/private/tmp/fpv-world-library-admitted-01fc6ad20';
const acceptedMenu = '/private/tmp/fpv-menu-browser-411396374';
const sha = b => createHash('sha256').update(b).digest('hex');
const run = (script, args) => execFileSync(process.execPath, [path.join(root, script), ...args], {
  cwd: root, env: { ...process.env, GIT_NO_LAZY_FETCH: '1' }, encoding: 'utf8', maxBuffer: 4*1024*1024,
});
assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], {cwd:root,encoding:'utf8'}).trim(), source);
await fs.mkdir(out);
const players = [];
for (const [name,id] of [['worlds','fpv-worlds'],['academy','civilian-fpv']]) {
  console.log(run('scripts/stage-fpv-shell-admitted-player.mjs', [candidate,id,path.join(out,name),path.join(prior,name),source]));
  const raw = await fs.readFile(path.join(out,name+'.json'));
  const row = JSON.parse(raw);
  assert.equal(row.sourceRevision,source);
  assert.equal(row.files.length,name==='worlds'?102:69);
  players.push({name,receiptSHA256:sha(raw),...row});
}
console.log(run('authoring/fpv-worlds/library/prepare-browser.mjs', ['--player',path.join(out,'worlds'),'--out',path.join(out,'library'),'--admitted',source]));
console.log(run('authoring/fpv-worlds/prearm-focus/prepare-browser.mjs', [path.join(out,'worlds'),path.join(out,'focus'),source,'admitted']));
const menu = JSON.parse(await fs.readFile(path.join(acceptedMenu,'fixture.json')));
for (const row of menu.wrapper) {
  const b = await fs.readFile(path.join(acceptedMenu,row.path));
  assert.equal(b.length,row.bytes); assert.equal(sha(b),row.sha256);
}
const html = (await fs.readFile(path.join(acceptedMenu,'index.html'),'utf8'))
  .replace('Native menu responsive admitted preview','Integrated Library, menu and focus qualification')
  .replace('Exact admitted menu · 411396374','Exact integrated admission · 216b36ce1')
  .replace('<p id="dimensions"','<p><a href="./library/" style="color:#9ed6ff">Native Library matrix</a> · <a href="./focus/" style="color:#9ed6ff">Native focus fixture</a></p><p id="dimensions"');
const script = (await fs.readFile(path.join(acceptedMenu,'preview.mjs'),'utf8'))
  .replaceAll('411396374bf25a1888a4a861c089d19671fd8432', source);
await fs.writeFile(path.join(out,'index.html'),html,{flag:'wx'});
await fs.writeFile(path.join(out,'preview.mjs'),script,{flag:'wx'});
const descriptor = {format:'FPVIntegratedReliabilityFixture.v1',sourceRevision:source,
  candidate,players,overlays:[],sizes:menu.sizes,wrapper:[],subfixtures:[],
  limits:['Exact all-three admitted runtime; no source overlays or warm-frame prototype.',
    'Wrapper changes only native iframe CSS size. No physical device, hardware performance or offline claim.',
    'Library fault injection and focus observation are separately declared in each frozen subfixture.']};
for (const name of ['index.html','preview.mjs']) {
  const b=await fs.readFile(path.join(out,name)); descriptor.wrapper.push({path:name,bytes:b.length,sha256:sha(b)});
}
for (const name of ['library','focus']) {
  const b=await fs.readFile(path.join(out,name,'fixture.json')); descriptor.subfixtures.push({path:name+'/fixture.json',bytes:b.length,sha256:sha(b)});
}
const b=Buffer.from(JSON.stringify(descriptor,null,2)+'\n');
await fs.writeFile(path.join(out,'fixture.json'),b,{flag:'wx'});
console.log(JSON.stringify({out,source,fixtureSHA256:sha(b),subfixtures:descriptor.subfixtures}));
