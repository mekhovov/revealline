import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readEditionZip} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
const previous='/Volumes/alex/CodexMigrationStaging/flight-practice-tuning-upload-fixed-20261018-candidate';
const current='/Volumes/alex/CodexMigrationStaging/flight-practice-main-237-20261018-candidate';
const hash=b=>createHash('sha256').update(b).digest('hex');
const before=JSON.parse(await fs.readFile(previous+'/optional-packages.json'));
const bytes=await fs.readFile(current+'/optional-packages.json'),after=JSON.parse(bytes);
const verification=JSON.parse(await fs.readFile(current+'/optional-candidate-verification.json'));
assert.equal(after.sourceRevision,'6177d2cc83adb9cb76ff4088d502c21ddfd7d199');assert.equal(verification.reproducibleBuilds,2);assert(verification.committedInputsVerified&&verification.admission.zipMembersVerified&&!verification.publicEligible);
const packages=[];
for(const pkg of after.packages){const old=before.packages.find(x=>x.id===pkg.id);const aBytes=await fs.readFile(path.join(previous,old.distribution.path)),bBytes=await fs.readFile(path.join(current,pkg.distribution.path));assert.equal(hash(aBytes),old.distribution.sha256);assert.equal(hash(bBytes),pkg.distribution.sha256);const a=readEditionZip(aBytes),b=readEditionZip(bBytes),changes=[];for(const name of [...new Set([...a.keys(),...b.keys()])].sort()){if(a.has(name)&&b.has(name)&&a.get(name).equals(b.get(name)))continue;changes.push({path:name,before:a.has(name)?hash(a.get(name)):null,after:b.has(name)?hash(b.get(name)):null});}packages.push({id:pkg.id,revision:pkg.revision,members:b.size,changedFiles:changes});}
const result={format:'PracticeAcceptedMainCandidateDiff.v1',passed:true,previousSource:before.sourceRevision,currentSource:after.sourceRevision,currentTree:after.sourceTree,envelopeSha256:hash(bytes),version:after.version,reproducibleBuilds:2,strictOriginalAdmission:true,publicEligible:false,packages,scope:'Fresh admitted accepted-main package build and byte comparison. Does not transfer earlier native/production receipts onto new runtime bytes.'};
await fs.writeFile('/private/tmp/practice-main-237-candidate-diff-20261018.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({source:result.currentSource,envelope:result.envelopeSha256,packages:packages.map(p=>({id:p.id,files:p.members,changed:p.changedFiles.map(x=>x.path)}))}));
