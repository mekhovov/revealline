import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const bundle='/Volumes/alex/CodexMigrationStaging/flight-practice-main-237-20261018-candidate';
const bytes=await fs.readFile(bundle+'/optional-packages.json'),e=JSON.parse(bytes);
assert.equal(e.sourceRevision,'6177d2cc83adb9cb76ff4088d502c21ddfd7d199');
for(const kind of ['fpv','gym']){
 const p=JSON.parse(await fs.readFile(`/private/tmp/practice-current-${kind}-exercise-20261018-plan.json`,'utf8'));
 Object.assign(p,{bundle,envelopeSha256:createHash('sha256').update(bytes).digest('hex'),sourceRevision:e.sourceRevision,sourceTree:e.sourceTree,packageRevision:e.packages.find(x=>x.id===(kind==='gym'?'civilian-flight':'civilian-fpv')).revision,caseId:`main-237-${kind}-current-exercises`});
 await fs.writeFile(`/private/tmp/practice-main-237-${kind}-exercise-20261018-plan.json`,JSON.stringify(p,null,2)+'\n',{flag:'wx'});
}
console.log(JSON.stringify({passed:true,source:e.sourceRevision}));
