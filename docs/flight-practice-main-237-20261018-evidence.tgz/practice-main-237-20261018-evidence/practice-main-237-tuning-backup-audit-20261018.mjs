import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readEditionZip } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
import { validateOptionalPackageAdmission } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/optional-package-admission.mjs';
import { validateTuningLibrary } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/optional-practice/civilian-fpv/tuning-library.mjs';

const bundle='/Volumes/alex/CodexMigrationStaging/flight-practice-main-237-20261018-candidate';
const prior='/Volumes/alex/CodexMigrationStaging/flight-practice-tuning-upload-fixed-20261018-candidate';
const output='/private/tmp/practice-main-237-tuning-backup-20261018';
const sha=b=>createHash('sha256').update(b).digest('hex');
const bytes=await fs.readFile(path.join(output,'observation.json')),r=JSON.parse(bytes);
const envelopeBytes=await fs.readFile(path.join(bundle,'optional-packages.json')),envelope=JSON.parse(envelopeBytes);
const oldEnvelope=JSON.parse(await fs.readFile(path.join(prior,'optional-packages.json')));
const admission=await validateOptionalPackageAdmission(envelope,{read:row=>fs.readFile(path.join(bundle,row.path))});
assert.equal(r.sourceRevision,'6177d2cc83adb9cb76ff4088d502c21ddfd7d199');
assert.equal(r.sourceTree,'ba3902515d73e97ae18dda8ffc57ee698eba9825');
assert.equal(r.envelopeSha256,'b64909c3127ea428be8d188444bf2ae0873e299b71bfd991a737ba0c658ce2a5');
assert.equal(r.envelopeSha256,sha(envelopeBytes));
assert.equal(r.passed,true);assert.equal(r.pending,0);assert(r.cleanup.every(c=>c.passed));
assert.equal(r.qualified,false);assert.equal(r.publicEligible,false);assert.deepEqual(r.unexpectedRequestFailures,[]);
assert.equal(r.optionalCoreProbeClassification.count,4);assert.equal(r.optionalCoreProbeClassification.visibleFallbacks,4);
assert.equal(r.guides.length,6);assert.equal(r.backups.length,4);
const maps=new Map(),changed=[];
for(const item of envelope.packages){
  const original=readEditionZip(await fs.readFile(path.join(bundle,item.distribution.path)));maps.set(item.id,original);
  const old=readEditionZip(await fs.readFile(path.join(prior,oldEnvelope.packages.find(p=>p.id===item.id).distribution.path)));
  assert.deepEqual([...original.keys()].sort(),[...old.keys()].sort());
  const diff=[...original.keys()].filter(p=>!original.get(p).equals(old.get(p))).sort();
  const expected=JSON.parse(await fs.readFile('/private/tmp/practice-main-237-candidate-diff-20261018.json','utf8')).packages.find(p=>p.id===item.id).changedFiles.map(f=>f.path).sort();
  assert.deepEqual(diff,expected);
  changed.push({id:item.id,changed:diff});
}
for(const row of r.guides){assert(row.passed);const guide=maps.get(row.id).get(row.originalGuide.path);assert.equal(guide.length,row.originalGuide.bytes);assert.equal(sha(guide),row.originalGuide.sha256);}
for(const row of r.backups){
  assert(row.passed);assert(row.populatedBackup);assert.deepEqual(row.errors,[]);assert.equal(row.exports.length,4);
  const parsed=[];
  for(const pin of [...row.exports,row.download]){const file=await fs.readFile(path.join(output,pin.path));assert.equal(file.length,pin.bytes);assert.equal(sha(file),pin.sha256);if(pin.stage)parsed.push(validateTuningLibrary(file.toString()));}
  assert.equal(parsed[0].profiles.length,3);assert.equal(parsed[1].profiles.length,4);assert.equal(parsed[2].profiles.length,3);
  assert(parsed[0].profiles.some(p=>p.name==='Local browser backup '+row.locale));
  assert.deepEqual(parsed[2],parsed[3]);assert.equal(parsed[1].revision,parsed[0].revision+1);assert.equal(parsed[2].revision,parsed[1].revision+1);
  const semantic=v=>{const{revision,...rest}=v;return rest;};assert.deepEqual(semantic(parsed[0]),semantic(parsed[2]));
}
for(const row of [...r.guides,...r.backups]){const pin=row.screenshot,png=await fs.readFile(path.join(output,pin.path));assert.equal(png.length,pin.bytes);assert.equal(sha(png),pin.sha256);assert.equal(png.subarray(0,8).toString('hex'),'89504e470d0a1a0a');}
const observer=await fs.readFile(path.join(output,'observer-original.mjs'));assert.equal(sha(observer),r.observer.sha256);
const result={format:'PracticeTuningBackupIntegrityAudit.v1',passed:true,reportSha256:sha(bytes),sourceRevision:r.sourceRevision,sourceTree:r.sourceTree,envelopeSha256:r.envelopeSha256,admission,changedPackages:changed,guides:6,backups:4,screenshots:10,qualification:false,scope:'Repeatable mechanical audit, not a second human review. Only root library transaction revision may advance; every other field and persisted re-export matches. Original C4 flights remain bound to their own earlier candidate.'};
await fs.writeFile(path.join(output,'audit.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result));

