import fs from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {createHash} from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
const source='/private/tmp/practice-tuning-upload-fixed-20261018-production';
const target='/Volumes/alex/CodexMigrationStaging/flight-practice-production-3c6ac5ee0-20261018/site-original';
const result='/Volumes/alex/CodexMigrationStaging/flight-practice-production-3c6ac5ee0-20261018/loose-site-retention.json';
const hash=async file=>{const h=createHash('sha256');for await(const b of createReadStream(file))h.update(b);return h.digest('hex');};
assert.equal(await fs.realpath(source),source);
const manifest=JSON.parse(await fs.readFile(path.join(source,'manifest.json'),'utf8'));
assert.equal(manifest.sourceRevision,'3c6ac5ee0f524a1c3a456316b978cf4e0043e06c');
assert.equal(await hash(path.join(source,'manifest.json')),'f17f336902c4c01b0679eb839289fabeac474782976d471f81ad9d907fe7b3b6');
const files=[];const expected=new Map(manifest.files.map(f=>[f.path,f]));
async function list(dir,prefix=''){for(const entry of await fs.readdir(dir,{withFileTypes:true})){const n=prefix+entry.name;assert(!entry.isSymbolicLink());if(entry.isDirectory())await list(path.join(dir,entry.name),n+'/');else{assert(entry.isFile());files.push(n);}}}
await list(source);assert(files.length>=3558&&files.length<=3565);
assert(manifest.files.every(f=>files.includes(f.path)));
await fs.mkdir(target);let i=0;const receipts=[];
async function copy(){for(;;){const n=files[i++];if(n===undefined)return;assert(!path.isAbsolute(n)&&!n.split('/').includes('..'));const a=path.join(source,n),b=path.join(target,n),before=await hash(a),size=(await fs.stat(a)).size,pin=expected.get(n);if(pin){assert.equal(before,pin.sha256);assert.equal(size,pin.bytes);}await fs.mkdir(path.dirname(b),{recursive:true});await fs.copyFile(a,b,fs.constants.COPYFILE_EXCL);assert.equal(await hash(b),before);assert.equal((await fs.stat(b)).size,size);assert.equal(await hash(a),before);receipts.push({path:n,bytes:size,sha256:before});if(receipts.length%256===0)console.log(JSON.stringify({copied:receipts.length,total:files.length}));}}
await Promise.all([copy(),copy(),copy(),copy()]);assert.equal(receipts.length,files.length);
receipts.sort((a,b)=>a.path.localeCompare(b.path));
const report={format:'PracticeOwnedLooseBuildMove.v1',passed:true,sourceRevision:manifest.sourceRevision,source,target,files:receipts,scope:'Only this task generated production output, copied and hash-verified before removing its exact local directory. Original capture paths in historical receipts are unchanged; future use should resolve this retained path.'};
await fs.writeFile(result,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
// Explicit generated-only target; never a workspace, home, or user directory.
assert.equal(source,'/private/tmp/practice-tuning-upload-fixed-20261018-production');
await fs.rm(source,{recursive:true});
console.log(JSON.stringify({passed:true,retained:target,files:receipts.length,localGeneratedCopyRemoved:true}));
