import fs from 'node:fs/promises';
const output = '/Volumes/alex/CodexMigrationStaging/practice-build-preparation-profile-20261019';
const p = JSON.parse(await fs.readFile(`${output}/profile.json`));
const nodes = new Map(p.nodes.map((node) => [node.id, node]));
const parents = new Map(p.nodes.flatMap((node) => (node.children || []).map((id) => [id, node.id])));
const self = new Map(), inclusive = new Map();
const add = (map, id, ms) => map.set(id, (map.get(id) || 0) + ms);
for (let i = 0; i < p.samples.length; i++) {
  let id = p.samples[i];
  const ms = p.timeDeltas[i] / 1000;
  add(self, id, ms);
  while (id !== undefined) { add(inclusive, id, ms); id = parents.get(id); }
}
const top = (map) => [...map].sort((a, b) => b[1] - a[1]).slice(0, 25).map(([id, ms]) => ({
  ms, ...nodes.get(id).callFrame,
}));
const summary = {
  format: 'PracticeBuildPreparationCPUProfileSummary.v1', samples: p.samples.length,
  elapsedMs: (p.endTime - p.startTime) / 1000, self: top(self), inclusive: top(inclusive),
  scope: 'One short instrumented preparation window, not whole-build attribution or a completed build.',
};
await fs.writeFile(`${output}/summary.json`, JSON.stringify(summary, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(summary));
