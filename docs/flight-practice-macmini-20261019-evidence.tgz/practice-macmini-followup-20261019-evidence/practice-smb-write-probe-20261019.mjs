import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { writeBuildEntry } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/build-entry-writer.mjs';

const base = '/Volumes/alex/CodexMigrationStaging';
const work = await fs.mkdtemp(path.join(base, 'practice-owned-write-probe-20261019-'));
const source = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/game/build-config.json';
const bytes = await fs.readFile(source);
const report = { format: 'PracticeSMBWriteProbe.v1', work, rows: [], scope: 'Small filesystem diagnostic only; no browser, build, or performance acceptance.' };
try {
  for (const concurrency of [1, 4]) {
    const start = performance.now();
    let next = 0;
    await Promise.all(Array.from({ length: concurrency }, async () => {
      while (next < 24) {
        const index = next++;
        const target = path.join(work, String(concurrency), `directory-${index % 4}`, `${index}.json`);
        await fs.mkdir(path.dirname(target), { recursive: true });
        await writeBuildEntry(source, target, bytes);
      }
    }));
    const elapsedMs = performance.now() - start;
    for (let i = 0; i < 24; i++) assert.deepEqual(await fs.readFile(path.join(work, String(concurrency), `directory-${i % 4}`, `${i}.json`)), bytes);
    report.rows.push({ concurrency, members: 24, elapsedMs, exactBytesVerified: true });
  }
} finally {
  await fs.rm(work, { recursive: true });
  report.ownedTemporaryDirectoryRemoved = true;
  await fs.writeFile('/private/tmp/practice-smb-write-probe-20261019.json', JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify(report));
}
