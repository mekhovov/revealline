import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { frozenSource } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const base = '/Volumes/alex/CodexMigrationStaging';
const buildPath = `${base}/practice-macmini-production-build-20261019/receipt.json`;
const raw = await fs.readFile(buildPath), build = JSON.parse(raw);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const source = frozenSource(root);
assert.equal(source.sourceRevision, '8b98b7113b9d91c0a2c3cc5a4191e99755ab2522');
assert.deepEqual(build.source, source);
assert(build.sourceUnchanged && !build.passed && !build.publicEligible);
assert.deepEqual(build.before, build.after);
assert.equal(build.deadlineMs, 600000);
assert(build.result.timedOut && !build.result.interrupted && !build.result.executionError);
assert.equal(build.result.signal, 'SIGTERM');
assert(build.result.groupCleanup.absent);
assert(!build.storageBudget.abortedForSpace && !build.storageBudget.guardError);
assert(build.storageBudget.minimumOutputObserved >= build.storageBudget.reserveBytes);
assert(build.storageBudget.minimumSystemObserved >= build.storageBudget.localSystemFloorBytes);
assert.equal((await fs.stat(`${base}/practice-macmini-production-build-20261019/build.log`)).size, 0);
assert.equal(await fs.access(build.destination).then(() => true, () => false), false);
const probe = JSON.parse(await fs.readFile('/private/tmp/practice-smb-write-probe-20261019.json'));
assert(probe.ownedTemporaryDirectoryRemoved && probe.rows.every((row) => row.members === 24 && row.exactBytesVerified));
assert.equal(await fs.access(probe.work).then(() => true, () => false), false);
const tap = await fs.readFile('/private/tmp/practice-build-writer-20261019.tap', 'utf8');
assert.match(tap, /^# tests 47$/m);
assert.match(tap, /^# pass 47$/m);
for (const name of ['fail', 'cancelled', 'skipped', 'todo']) assert.match(tap, new RegExp(`^# ${name} 0$`, 'm'));
const stack = JSON.parse(await fs.readFile('/private/tmp/practice-owned-node-stack-20261019.json'));
assert.equal(stack.target, 'file:///private/tmp/practice-build-preparation-profile-20261019.mjs');
assert(stack.frames.some((frame) => frame.url.endsWith('/scripts/localization-content.mjs') && frame.functionName === 'extractContent'));
assert.equal((await fs.stat(`${base}/practice-build-preparation-profile-20261019/profile.json`)).size, 0);
assert.equal(await fs.access(`${base}/practice-build-preparation-profile-20261019/receipt.json`).then(() => true, () => false), false);
const absent = (pid) => {
  try { process.kill(pid, 0); return false; }
  catch (error) { assert.equal(error.code, 'ESRCH'); return true; }
};
assert(absent(49757) && absent(68400));
const code = [];
for (const name of ['scripts/game-cli.mjs', 'scripts/build-entry-writer.mjs', 'scripts/test-build-entry-writer.mjs']) {
  const bytes = await fs.readFile(`${root}/${name}`);
  code.push({ path: name, bytes: bytes.length, sha256: sha(bytes) });
}
const report = {
  format: 'PracticeMacMiniFollowupAudit.v1', completed: true, buildPassed: false,
  source, buildReceiptSha256: sha(raw), targetedTestsPassed: 47, targetedTapSha256: sha(Buffer.from(tap)), code,
  outputVolume: base, outputIsNetworkShare: true, browserOrRemoteExecutionPerformed: false,
  smbProbe: probe.rows, probeIsSmallDiagnosticOnly: true,
  buildDeadlineMs: 600000, timedOut: true, buildGroupAbsent: true, sourceInputsUnchanged: true,
  outputAbsent: true, storageGuardTriggered: false,
  minimumOutputFreeBytes: build.storageBudget.minimumOutputObserved,
  minimumSystemFreeBytes: build.storageBudget.minimumSystemObserved,
  profiling: { requestedCaptureMs: 45000, completedCPUProfile: false, incompleteProfileBytes: 0, completionReceiptExists: false, captureTimerDelayed: true, manuallyTerminatedOwnedPid: 68400, exitCode: 143, processAbsent: true, stack: stack.frames, wholeTimeoutCauseEstablished: false },
  productionJourneys: 'not run; no successful new full production build',
  scope: 'Preserves a failed unchanged-deadline normal build and incomplete profiling attempt. The stack identifies localization/level normalization as one concrete investigation target, not whole-run cost attribution. Bounded writer tests and small SMB diagnostic pass; no full-build, browser, performance, human, hosting or public-release pass is claimed.',
};
await fs.writeFile(`${base}/practice-macmini-followup-20261019-audit.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ completed: report.completed, buildPassed: false, targetedTestsPassed: 47, source, minimumOutputFreeBytes: report.minimumOutputFreeBytes, minimumSystemFreeBytes: report.minimumSystemFreeBytes, productionJourneys: report.productionJourneys, allOwnedBuildAndProfilingProcessesAbsent: true }));
