import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const targets = await fetch('http://127.0.0.1:9229/json/list', { signal: AbortSignal.timeout(2000) }).then((r) => r.json());
assert.equal(targets.length, 1);
assert.equal(targets[0].url, 'file:///private/tmp/practice-build-preparation-profile-20261019.mjs');
const socket = new WebSocket(targets[0].webSocketDebuggerUrl);
const pending = new Map(), scripts = new Map();
let next = 0, pausedResolve;
const paused = new Promise((resolve) => { pausedResolve = resolve; });
const timer = setTimeout(() => { socket.close(); process.exit(1); }, 12000);
socket.addEventListener('message', (event) => {
  const message = JSON.parse(event.data);
  if (message.id) {
    const operation = pending.get(message.id);
    pending.delete(message.id);
    if (message.error) operation?.reject(new Error(JSON.stringify(message.error)));
    else operation?.resolve(message.result);
  }
  if (message.method === 'Debugger.scriptParsed') scripts.set(message.params.scriptId, message.params.url);
  if (message.method === 'Debugger.paused') pausedResolve(message.params);
});
await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });
const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++next; pending.set(id, { resolve, reject }); socket.send(JSON.stringify({ id, method, params })); });
try {
  await send('Debugger.enable');
  await send('Debugger.pause');
  const snapshot = await paused;
  const report = { format: 'PracticeOwnedBuildPreparationStack.v1', capturedAt: new Date().toISOString(), target: targets[0].url, reason: snapshot.reason, frames: snapshot.callFrames.map((f) => ({ functionName: f.functionName, url: f.url || scripts.get(f.location.scriptId), location: f.location })), scope: 'Read-only JavaScript stack from the exact owned unqualified profiling process; not a completed CPU profile or build.' };
  await fs.writeFile('/private/tmp/practice-owned-node-stack-20261019.json', JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify(report));
} finally {
  await send('Debugger.resume').catch(() => {});
  socket.close();
  clearTimeout(timer);
}
