import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { frozenSource } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
const base = '/Volumes/alex/CodexMigrationStaging';
const source = frozenSource('/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test');
assert.equal(source.sourceRevision, '8b98b7113b9d91c0a2c3cc5a4191e99755ab2522');
const distribution = `${base}/flight-practice-main-237-20261019-production`;
const bundle = `${base}/flight-practice-main-237-20261018-candidate`;
const build = JSON.parse(await fs.readFile(`${base}/practice-macmini-production-build-20261019/receipt.json`));
assert(build.passed && build.sourceUnchanged && build.result.exitCode === 0 && !build.result.signal && !build.result.timedOut && !build.result.interrupted && !build.result.executionError);
assert.deepEqual(build.source, source);
const envelopeBytes = await fs.readFile(`${bundle}/optional-packages.json`);
const envelope = JSON.parse(envelopeBytes);
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const plan = {
  format: 'revealline-practice-directory-production-personal-appearance-plan.v2',
  protocol: 'practice-directory-production-personal-appearance.v2',
  caseId: 'main-237-macmini-production-six-routes',
  deviceLabel: 'Local macOS arm64, installed Google Chrome 155.0.8059.85, headless 1440x900',
  quietWindow: 'Owner-approved Mac mini SMB original build output; local browser. No exclusive resources, hosting or performance budget claimed.',
  cases: ['en-civilian-flight', 'en-civilian-fpv', 'en-fpv-worlds', 'uk-civilian-flight', 'uk-civilian-fpv', 'uk-fpv-worlds'],
  bundle, envelopeSha256: hash(envelopeBytes),
  sourceRevision: envelope.sourceRevision, sourceTree: envelope.sourceTree,
  packageRevision: envelope.packages.find((pkg) => pkg.id === 'civilian-fpv').revision,
  shellRevision: source.sourceRevision, shellTree: source.sourceTree,
  observerRevision: source.sourceRevision, observerTree: source.sourceTree,
  distribution,
  distributionManifestSha256: hash(await fs.readFile(`${distribution}/manifest.json`)),
};
await fs.writeFile(`${base}/practice-macmini-directory-20261019-plan.json`, JSON.stringify(plan, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(plan));
