import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readEditionZip } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
import { directoryJourneyOverlay } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/observe-practice-directory-journey.mjs';

const base = '/Volumes/alex/CodexMigrationStaging';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const out = `${base}/practice-macmini-directory-20261019`;
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const hashFile = async (name) => {
  const digest = createHash('sha256');
  for await (const chunk of createReadStream(name, { highWaterMark: 1024 * 1024 })) digest.update(chunk);
  return digest.digest('hex');
};
const raw = await fs.readFile(`${out}/observation.json`), r = JSON.parse(raw), p = r.plan;
assert(r.completed && r.procedureComplete && !r.qualified && r.cleanup.completed);
assert(r.observerSource.verifiedBefore && r.observerSource.verifiedAfter);
assert.equal(r.observerSource.sourceRevision, '8b98b7113b9d91c0a2c3cc5a4191e99755ab2522');
assert.equal(execFileSync('git', ['rev-parse', `${p.shellRevision}^{tree}`], { cwd: root, encoding: 'utf8' }).trim(), p.shellTree);
assert.equal(p.sourceRevision, '6177d2cc83adb9cb76ff4088d502c21ddfd7d199');
assert.equal(hash(await fs.readFile(`${p.distribution}/manifest.json`)), p.distributionManifestSha256);
const build = JSON.parse(await fs.readFile(`${base}/practice-macmini-production-build-20261019/receipt.json`));
assert(build.passed && build.sourceUnchanged && !build.publicEligible && !build.result.timedOut);
assert.equal(build.source.sourceRevision, p.shellRevision);
assert.equal(build.deadlineMs, 600000);
assert.deepEqual(build.before, build.after);
assert.equal(await hashFile(`${p.distribution}/distribution.zip`), build.build.sha256);
assert.equal(await fs.readFile(`${p.distribution}/distribution.zip.sha256`, 'utf8'), `${build.build.sha256}  distribution.zip\n`);
const manifest = JSON.parse(await fs.readFile(`${p.distribution}/manifest.json`));
assert.deepEqual(r.distribution.originalFiles, manifest.files);
assert(r.distribution.originalsVerifiedBefore && r.distribution.originalsVerifiedAfter);
let bytes = 0, next = 0;
await Promise.all(Array.from({ length: 4 }, async () => {
  while (next < manifest.files.length) {
    const row = manifest.files[next++];
    assert(!path.isAbsolute(row.path) && !row.path.split('/').includes('..'));
    const file = path.join(p.distribution, row.path);
    assert.equal((await fs.stat(file)).size, row.bytes);
    assert.equal(await hashFile(file), row.sha256);
    bytes += row.bytes;
  }
}));
assert.equal(bytes, manifest.totalBytes);
assert.equal(r.distributionIO.length, 2);
for (const io of r.distributionIO) {
  assert(io.completed && io.cleanup.completed && io.cleanup.openStreams === 0);
  assert.equal(io.completedFiles, manifest.files.length);
  assert.equal(io.completedBytes, bytes);
}
for (const row of r.authority) {
  assert.equal(await hashFile(path.join(root, row.path)), row.sha256);
  assert.equal(await hashFile(path.join(out, 'authority', path.basename(row.path))), row.sha256);
}
assert.deepEqual(r.servedSources, []);
assert.deepEqual(r.requestFailures, [{ path: '/favicon.ico', message: 'Outside local fixture root.' }]);
assert(r.resourceAcquisitions.every((row) => !row.pending && !row.timedOut));
assert(r.productionDelivery.cleared && r.productionDelivery.pendingReads === 0 && r.productionDelivery.remainingBytes === 0);
assert(r.productionDelivery.selectedBytes <= 134217728);
const overlay = new Map(r.overlay.map((row) => [row.path, row]));
const envelopeBytes = await fs.readFile(`${p.bundle}/optional-packages.json`), envelope = JSON.parse(envelopeBytes);
assert.equal(hash(envelopeBytes), p.envelopeSha256);
let members = 0, launchers = 0;
for (const pkg of envelope.packages) {
  const zip = await fs.readFile(path.join(p.bundle, pkg.distribution.path));
  assert.equal(hash(zip), pkg.distribution.sha256);
  for (const [name, body] of readEditionZip(zip)) {
    const item = overlay.get(`practice/${pkg.id}/releases/${envelope.version}/site/${name}`);
    assert.equal(item?.sha256, hash(body));
    assert.equal(item.bytes, body.length);
    members++;
    if (name.startsWith('launcher/')) {
      assert.equal(overlay.get(`practice/${pkg.id}/app/${name.slice(9)}`)?.sha256, hash(body));
      launchers++;
    }
  }
}
const regenerated = await directoryJourneyOverlay(p);
assert.equal(regenerated.files.size, overlay.size);
for (const [name, body] of regenerated.files) assert.equal(overlay.get(name)?.sha256, hash(body));
assert.equal(r.cases.length, 6);
let pngs = 0;
for (const c of r.cases) {
  assert(c.passed && c.mainGameReturn && c.standaloneDirectory);
  assert.deepEqual(c.errors, []);
  assert.deepEqual(c.runtimeRequestsBeforePlay, []);
  assert.equal(c.playActions, 1);
  assert.equal(c.cardsVerified, 3);
  assert.equal(c.app.locale, c.locale);
  assert.equal(c.app.phase, c.package === 'civilian-fpv' ? 'disarmed' : 'ready');
  assert.equal(c.personalAppearance.app.family, 'tryzub');
  assert.equal(c.guide.heading, c.locale === 'uk' ? 'Ваш перший тренувальний політ' : 'Your first practice flight');
  for (const image of c.screenshots) {
    const body = await fs.readFile(path.join(out, image.path));
    assert.equal(body.length, image.bytes);
    assert.equal(hash(body), image.sha256);
    pngs++;
  }
}
const result = {
  format: 'PracticeMacMiniProductionDirectoryAudit.v1', passed: true, receiptSha256: hash(raw),
  packageSource: p.sourceRevision, shellSource: p.shellRevision, observerSource: p.observerRevision,
  browser: r.browser, originalFiles: manifest.files.length, originalBytesRehashed: bytes,
  fullZipSha256: build.build.sha256, fullZipBytes: (await fs.stat(`${p.distribution}/distribution.zip`)).size,
  zipMembersVerified: members, stableLauncherCopies: launchers, allOverlayFilesRegenerated: overlay.size,
  cases: 6, onePlayEach: true, runtimeRequestsBeforePlay: 0, screenshotsHashed: pngs, cleanupVerified: true,
  scope: 'Local browser functional integration with original normal full build on Mac mini SMB. Not cold-filesystem performance, arming/exercises, restarted-offline, hardware, spoken/visual accessibility, human review, hosting or public release approval.',
};
await fs.writeFile(`${out}/audit.json`, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result));
