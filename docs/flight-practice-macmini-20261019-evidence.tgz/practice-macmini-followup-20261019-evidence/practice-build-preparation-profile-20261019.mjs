import inspector from 'node:inspector';
import fs from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
import { frozenSource } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
import { prepareBuildProject } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/game-cli.mjs';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const output = '/Volumes/alex/CodexMigrationStaging/practice-build-preparation-profile-20261019';
await fs.mkdir(output);
const source = frozenSource(root), session = new inspector.Session();
session.connect();
const post = (method, params = {}) => new Promise((resolve, reject) => session.post(method, params, (error, result) => error ? reject(error) : resolve(result)));
await post('Profiler.enable');
await post('Profiler.start');
const started = performance.now();
let stopped = false;
const finish = async (preparationComplete, error = null) => {
  if (stopped) return;
  stopped = true;
  const { profile } = await post('Profiler.stop');
  session.disconnect();
  await fs.writeFile(`${output}/profile.json`, JSON.stringify(profile), { flag: 'wx' });
  const receipt = {
    format: 'PracticeBuildPreparationCPUProfile.v1', source, captureElapsedMs: performance.now() - started,
    preparationComplete, buildAttempted: false, qualified: false, error,
    scope: 'Short read-only preparation profiling capture, intentionally stopped after 45 seconds if still running. Not a completed build, timing pass, hosting, or gameplay measurement.',
  };
  await fs.writeFile(`${output}/receipt.json`, JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify(receipt));
  process.exit(error ? 1 : 0);
};
setTimeout(() => { void finish(false); }, 45000);
try {
  await prepareBuildProject({ root, version: 'v0.151.1', sourceRevision: source.sourceRevision });
  await finish(true);
} catch (error) { await finish(false, error.message); }
