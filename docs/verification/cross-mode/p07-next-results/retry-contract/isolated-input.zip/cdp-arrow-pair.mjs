import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
const root=process.cwd(), profile=root+'/.cache/p07-browser-candidate-cc161f7d/profiles/storyflow';
const requireThat=(x,m)=>{if(!x)throw Error(m);};
const [port]=fs.readFileSync(profile+'/DevToolsActivePort','utf8').trim().split('\n');requireThat(/^\d+$/.test(port),'PORT');
const owner=execFileSync('/usr/sbin/lsof',['-nP','-t','-iTCP:'+port,'-sTCP:LISTEN'],{encoding:'utf8'}).trim();requireThat(/^\d+$/.test(owner),'ONE_BROWSER');
const ps=execFileSync('/bin/ps',['-p',owner,'-o','ppid=,args='],{encoding:'utf8'}).trim();const match=ps.match(/^(\d+)\s+(.+)$/);requireThat(match&&match[2].startsWith('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome ')&&match[2].includes('--user-data-dir='+profile),'PROFILE_OWNER');
const daemon=execFileSync('/bin/ps',['-p',match[1],'-o','args='],{encoding:'utf8'}).trim();requireThat(daemon.startsWith('/Users/oleksandr.mekhovov/.local/share/mise/installs/node/20.19.5/lib/node_modules/agent-browser/bin/agent-browser-darwin-arm64'),'DAEMON');
const response=await fetch('http://127.0.0.1:'+port+'/json/list',{signal:AbortSignal.timeout(3000)});requireThat(response.ok,'TARGET_HTTP');const pages=(await response.json()).filter(t=>t.type==='page'&&t.url==='about:blank');requireThat(pages.length===1,'EXACT_BLANK');
const target=pages[0],url=new URL(target.webSocketDebuggerUrl);requireThat(url.hostname==='127.0.0.1'&&url.port===port&&url.pathname==='/devtools/page/'+target.id,'TARGET_ENDPOINT');
const socket=new WebSocket(url);let seq=0;const pending=new Map();
socket.addEventListener('message',e=>{requireThat(typeof e.data==='string'&&e.data.length<65536,'MESSAGE_BOUND');const r=JSON.parse(e.data);const p=pending.get(r.id);if(p){clearTimeout(p.timer);pending.delete(r.id);r.error?p.reject(Error('CDP_REJECTED')):p.resolve(r.result);}});
const call=params=>new Promise((resolve,reject)=>{const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error('COMMAND_TIMEOUT'));},3000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method:'Input.dispatchKeyEvent',params}));});
const at=new Date().toISOString(),events=[];let down=false;
try{
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('OPEN_TIMEOUT')),3000);socket.addEventListener('open',()=>{clearTimeout(timer);resolve();},{once:true});socket.addEventListener('error',()=>{clearTimeout(timer);reject(Error('OPEN_FAILED'));},{once:true});});
 const base={key:'ArrowDown',code:'ArrowDown',windowsVirtualKeyCode:40,modifiers:0,autoRepeat:false};
 try{const params={...base,type:'keyDown'};await call(params);down=true;events.push({at:new Date().toISOString(),params,acknowledged:true});}
 finally{const params={...base,type:'keyUp'};await call(params);events.push({at:new Date().toISOString(),params,acknowledged:true});}
}finally{socket.close();}
const receipt={at,finishedAt:new Date().toISOString(),browserPid:Number(owner),daemonPid:Number(match[1]),targetId:target.id,url:'about:blank',nativeVirtualKeyCodeSupplied:false,events,profilePreserved:true,scope:'One explicit CDP down/up pair on task-owned blank page. Diagnostic only; no game acceptance.'};
fs.writeFileSync(root+'/.cache/p07-isolated-input-reproduction/cdp-arrow-pair.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
