(async () => {
  if (location.href !== 'about:blank') throw new Error('OWNED_PAGE_REQUIRED');
  const allowed = new Set(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','w','W','a','A','s','S','d','D','Enter','Escape',' ','Shift','Tab','Control','Alt','Meta','Backspace','Delete','Home','End','PageUp','PageDown','CapsLock','NumLock','ScrollLock','Pause','PrintScreen','ContextMenu','AudioVolumeMute','AudioVolumeDown','AudioVolumeUp','MediaPlayPause','MediaStop','MediaTrackNext','MediaTrackPrevious','BrowserBack','BrowserForward','BrowserRefresh','BrowserStop','BrowserSearch','BrowserFavorites','BrowserHome',...Array.from({length:24},(_,i)=>'F'+(i+1)),...Array.from({length:26},(_,i)=>'Key'+String.fromCharCode(65+i)),...Array.from({length:10},(_,i)=>'Digit'+i), 'Minus','Equal','BracketLeft','BracketRight','Backslash','Semicolon','Quote','Backquote','Comma','Period','Slash','ShiftLeft','ShiftRight','ControlLeft','ControlRight','AltLeft','AltRight','MetaLeft','MetaRight']);
  const category = value => value === '' ? '(empty)' : ['Unidentified','Dead','Process'].includes(value) ? value : allowed.has(value) ? value : '(other)';
  const counts = new Map(); let total = 0, capped = false;
  const started = performance.now();
  const cleanup = () => { document.removeEventListener('keydown', observe, true); document.removeEventListener('keyup', observe, true); };
  const observe = event => {
    total++;
    const label = [event.type, category(event.key), category(event.code), event.repeat ? 'repeat' : 'initial', event.isTrusted ? 'trusted' : 'untrusted'].join(':');
    counts.set(label, (counts.get(label) ?? 0) + 1);
    if (total >= 2000) { capped = true; cleanup(); }
  };
  document.addEventListener('keydown', observe, true); document.addEventListener('keyup', observe, true);
  try { await new Promise(resolve => setTimeout(resolve, 5000)); } finally { cleanup(); }
  return { elapsedMs:performance.now()-started, total, stoppedAtCap:capped, counts:Object.fromEntries(counts), removed:true };
})()
