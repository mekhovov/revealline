"""Retain one bounded owned browser command; no application-state injection."""
import datetime, hashlib, json, pathlib, shutil, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent
profile, step, *command = sys.argv[1:]
assert profile in ('networkflow', 'storyflow') and step.replace('-', '').isalnum()
assert command and shutil.disk_usage(ROOT).free > 520 * 1024 * 1024
out = ROOT / ('browser-' + profile)
out.mkdir(exist_ok=True)
prefix = out / step
assert not prefix.with_suffix('.command.json').exists()
args = ['agent-browser', '--config', str(ROOT / ('agent-browser-' + profile + '.json')),
        '--session', 'rl-p07-' + profile, *command]
record = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'profile': profile, 'args': args, 'timeoutSeconds': 50}
try:
    result = subprocess.run(args, capture_output=True, timeout=50)
    stdout, stderr, code = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as error:
    stdout, stderr, code = error.stdout or b'', error.stderr or b'', None
    record['timedOut'] = True
assert len(stdout) <= 2_000_000 and len(stderr) <= 100_000
for suffix, body in [('stdout', stdout), ('stderr', stderr)]:
    path = prefix.with_suffix('.' + suffix)
    with path.open('xb') as stream:
        stream.write(body)
    record[suffix] = {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
record['exitCode'] = code
with prefix.with_suffix('.command.json').open('x') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(stdout.decode(errors='replace'))
if stderr:
    print(stderr.decode(errors='replace'), file=sys.stderr)
if code != 0:
    raise SystemExit(code if code is not None else 124)
