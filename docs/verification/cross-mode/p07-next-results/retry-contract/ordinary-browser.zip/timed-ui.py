import pathlib,subprocess,datetime,json,time,sys
r=pathlib.Path(__file__).resolve().parents[2]
step,*args=sys.argv[1:]
p=pathlib.Path(__file__).resolve().parent/'timings';p.mkdir(exist_ok=True)
f=p/(step+'.json');assert not f.exists()
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
c=subprocess.run(['python3','-B',str(r/'.cache/p07-standard-input-journey/observe.py'),'storyflow',step,*args])
j={'start':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.monotonic()-t,'exitCode':c.returncode}
f.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j),flush=True)
raise SystemExit(c.returncode)
