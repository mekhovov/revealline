import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
const key=process.argv[2], step=process.argv[3];
if(!['ArrowDown','Escape'].includes(key)||!/^\d{2}-[a-z0-9-]+$/.test(step??'')) throw Error('FIXED_INPUT_ONLY');
const root=process.cwd(), profile=root+'/.cache/p07-browser-candidate-cc161f7d/profiles/storyflow';
const requireThat=(x,m)=>{if(!x)throw Error(m);};
const output=root+'/.cache/p07-standard-input-journey/'+step+'.key.json';requireThat(!fs.existsSync(output),'OUTPUT_EXISTS');
const binding=JSON.parse(fs.readFileSync(root+'/.cache/p07-performance-trace-server/binding.json'));requireThat(binding.commit==='c4851d140b8c7c8ebaebfede998b4d9e60f18807'&&binding.tree==='4fd8806a081f1a947d32d8c8a8acf910a6d2c6d4'&&Object.keys(binding.runtimeOverrides).length===0,'EXACT_SOURCE');
const [port]=fs.readFileSync(profile+'/DevToolsActivePort','utf8').trim().split('\n');requireThat(/^\d+$/.test(port),'PORT');
const owner=execFileSync('/usr/sbin/lsof',['-nP','-t','-iTCP:'+port,'-sTCP:LISTEN'],{encoding:'utf8'}).trim();requireThat(/^\d+$/.test(owner),'ONE_BROWSER');
const ps=execFileSync('/bin/ps',['-p',owner,'-o','ppid=,args='],{encoding:'utf8'}).trim();const match=ps.match(/^(\d+)\s+(.+)$/);requireThat(match&&match[2].startsWith('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome ')&&match[2].includes('--user-data-dir='+profile),'PROFILE_OWNER');
const daemon=execFileSync('/bin/ps',['-p',match[1],'-o','args='],{encoding:'utf8'}).trim();requireThat(daemon.startsWith('/Users/oleksandr.mekhovov/.local/share/mise/installs/node/20.19.5/lib/node_modules/agent-browser/bin/agent-browser-darwin-arm64'),'DAEMON');
const response=await fetch('http://127.0.0.1:'+port+'/json/list',{signal:AbortSignal.timeout(3000)});requireThat(response.ok,'TARGET_HTTP');const pages=(await response.json()).filter(t=>t.type==='page'&&t.url==='http://127.0.0.1:60371/game/');requireThat(pages.length===1,'EXACT_GAME');
const target=pages[0],url=new URL(target.webSocketDebuggerUrl);requireThat(url.hostname==='127.0.0.1'&&url.port===port&&url.pathname==='/devtools/page/'+target.id,'TARGET_ENDPOINT');
const socket=new WebSocket(url);let seq=0;const pending=new Map();
socket.addEventListener('message',e=>{requireThat(typeof e.data==='string'&&e.data.length<65536,'MESSAGE_BOUND');const r=JSON.parse(e.data);const p=pending.get(r.id);if(p){clearTimeout(p.timer);pending.delete(r.id);r.error?p.reject(Error('CDP_REJECTED')):p.resolve(r.result);}});
const call=params=>new Promise((resolve,reject)=>{const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error('COMMAND_TIMEOUT'));},3000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method:'Input.dispatchKeyEvent',params}));});
const at=new Date().toISOString(),events=[];let down=false;
try{
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('OPEN_TIMEOUT')),3000);socket.addEventListener('open',()=>{clearTimeout(timer);resolve();},{once:true});socket.addEventListener('error',()=>{clearTimeout(timer);reject(Error('OPEN_FAILED'));},{once:true});});
 const base={key,code:key,windowsVirtualKeyCode:key==='ArrowDown'?40:27,modifiers:0,autoRepeat:false};
 try{const params={...base,type:'keyDown'};await call(params);down=true;events.push({at:new Date().toISOString(),params,acknowledged:true});}
 finally{const params={...base,type:'keyUp'};await call(params);events.push({at:new Date().toISOString(),params,acknowledged:true});}
}finally{socket.close();}
const receipt={at,finishedAt:new Date().toISOString(),browserPid:Number(owner),daemonPid:Number(match[1]),targetId:target.id,url:'http://127.0.0.1:60371/game/',nativeVirtualKeyCodeSupplied:false,events,profilePreserved:true,scope:'One explicit CDP down/up pair on task-owned exact game page. Emulated keyboard; not physical device qualification.'};
fs.writeFileSync(output,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));
