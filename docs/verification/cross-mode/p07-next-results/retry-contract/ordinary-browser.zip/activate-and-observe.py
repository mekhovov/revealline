from pathlib import Path
import subprocess,time,json,datetime,sys
root=Path.cwd();out=root/'.cache/p07-standard-input-journey';step,button=sys.argv[1:]
assert button in ('retry-button','next-button') and step.replace('-','').isalnum()
receipt=out/(step+'.journey.json');assert not receipt.exists()
args=['agent-browser','--config',str(out/'agent-browser-storyflow.json'),'--session','rl-p07-storyflow']
expression="(() => { if(location.href!=='http://127.0.0.1:60371/game/') throw Error('OWNED_PAGE_REQUIRED'); return {overlayHidden:document.getElementById('game-overlay').hidden, preparationHidden:document.getElementById('flight-preparation-status').hidden, status:document.getElementById('flight-preparation-status').textContent, title:document.getElementById('overlay-title').textContent, mission:document.getElementById('overlay-eyebrow').textContent, focus:document.activeElement?.id}; })()"
at=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();rows=[]
click=subprocess.run(['python3','-B',str(out/'observe.py'),'storyflow',step+'-click','click','#'+button],capture_output=True,timeout=10)
assert click.returncode==0,(click.stdout,click.stderr)
for index in range(35):
 if time.monotonic()-t>=15:break
 q=subprocess.run([*args,'eval',expression],capture_output=True,timeout=5)
 row={'afterSeconds':time.monotonic()-t,'exitCode':q.returncode,'stdout':q.stdout.decode(),'stderr':q.stderr.decode()};rows.append(row)
 assert len(q.stdout)<16384 and len(q.stderr)<4096
 if q.returncode==0:
  state=json.loads(q.stdout)
  print(json.dumps({'afterSeconds':row['afterSeconds'],**state}),flush=True)
  if state['overlayHidden']:break
 time.sleep(.25)
j={'start':at,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-t,'button':button,'adoptedObserved':bool(rows and rows[-1]['exitCode']==0 and json.loads(rows[-1]['stdout'])['overlayHidden']),'precision':'CLI click start to public DOM observation including command and polling overhead','rows':rows}
receipt.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps({k:v for k,v in j.items() if k!='rows'}),flush=True)
