# P07 Retry contract test correction

This uncommitted candidate corrects obsolete synchronous replacement expectations at source `c4851d14`. Runtime code is unchanged. The five-path patch updates three test files, the Solo continuation guide and its maintainer guidance.

The picture-status cases use legal wins, skip the real celebration and finish earned-thumbnail acquisition before holding the next decoder. Both turning modes prove result, exact art, checkpoint and stored-record retention through Cancel, then direct successful Retry. Separate cases prove friendly failure feedback, local diagnostics and no automatic adoption or Resume on foreground return. Terminal keyboard/controller and defeat cases await actual preparation while retaining fresh-confirm, held-input isolation, input neutrality and paused checkpoint assertions.

Final validation: **38/38 across four complete files on Node 20.19.5 and Node 22.22.2**, sequentially with a 1024 MiB heap cap. Both commands used the same 1,111-file input manifest; zero failures, skips or cancellations. Formatting, lint and diff checks pass. These are 38 distinct cases, not 76 unique cases.

The two documentation files were updated after both successful commands, under root authorization, to describe the separate scoped ordinary browser pass on unchanged c485 code. Test/runtime bodies remain identical to their passing input pins. The browser used pointer controls plus paired emulated keys at 1280 × 633, DPR 1; it does not certify keyboard-only or physical-device access, general performance, offline use or public acceptance. The severe repeated-input slowdown was reproduced outside the game and corrected in the input driver; no game performance fix is claimed.

All setup and fixture-expectation failures remain in `runs/`; `preimages.json`, `hydration.json`, `catalog-hydration.json`, the two correction receipts and predecessor candidate directories explain them. The original hosted seven-failure records remain in the separate c485 CI-failure packet. No core status, checkpoint or player result was fabricated, no test was skipped, and no runtime deadline or input guarantee was relaxed.

`candidate.patch` and `candidate-pins.json` are the integration inputs. `final-verification.json` pins the complete-file receipts and the documentation-only successor. The index is empty; the pre-existing untracked `node_modules` symlink is not part of the patch. No commit, push, version allocation, build or publication was performed.
