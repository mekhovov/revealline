from pathlib import Path
import subprocess,json,hashlib,datetime,time,os,sys
root=Path.cwd();w=root/'.cache/worktrees/p07-retry-contract-tests';p=Path(__file__).resolve().parent;d=p/'runs'/sys.argv[1];d.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();env=dict(os.environ,GIT_NO_LAZY_FETCH='1',PYTHONDONTWRITEBYTECODE='1');rows=[]
for n in subprocess.check_output(['git','ls-files','-z'],cwd=w,env=env).decode().split('\0'):
 q=w/n
 if n and q.is_file() and not q.is_symlink():
  b=q.read_bytes();rows.append({'path':n,'bytes':len(b),'sha256':sha(b)})
(d/'inputs.json').open('x').write(json.dumps({'count':len(rows),'bytes':sum(x['bytes'] for x in rows),'files':rows},indent=2)+'\n')
files=['game/test/picture-ready-status.test.mjs','game/test/terminal-navigation.test.mjs','game/test/defeat-presentation-host.test.mjs','game/test/solo-result-continuation-host.test.mjs'];args=[sys.argv[2],'--max-old-space-size=1024','--test','--test-concurrency=1',*files];start=time.monotonic();stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (d/'stdout').open('xb') as so,(d/'stderr').open('xb') as se:rsp=subprocess.run(args,cwd=w,env=env,stdout=so,stderr=se)
for row in rows:
 b=(w/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
receipt={'command':args,'startedAt':stamp,'elapsedSeconds':time.monotonic()-start,'exitCode':rsp.returncode,'nodeVersion':subprocess.check_output([args[0],'--version']).decode().strip(),'inputManifest':{'path':str(d/'inputs.json'),'bytes':(d/'inputs.json').stat().st_size,'sha256':sha((d/'inputs.json').read_bytes())},'allRecordedInputsUnchangedAfter':True}
for n in ['stdout','stderr']:
 b=(d/n).read_bytes();receipt[n]={'bytes':len(b),'sha256':sha(b)}
(d/'receipt.json').open('x').write(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));print((d/'stdout').read_text()[-3000:]);raise SystemExit(rsp.returncode)
