# Later composition boundary

The candidate remains based on 90e8bc8102cc71a992a57aa1f41d7cdcd6659b3e. Its four production paths are the Couch host, shell and two read-only picture owners. It does not include the later P03 Library, Team HUD/actors or Couch resize checkpoint.

When composing with the reviewed resize shell, retain its same-root/current-action/foreground eligibility and end-of-update nearest reveal. The new optional `focusTransition` argument defaults to true and suppresses only the transition-owned focus side effect for the first successful Next adoption update. It must not suppress screen/status/render updates or later explicit Start/Resume behavior. The original Next action lease is the only authority to restore focus or start after the async preparation, including cleanup and queued callbacks; BODY alone cannot revive it.

The staged picture owners leave ordinary select/confirm behavior intact. The final initial installed status is synchronous after operation-promise publication, preserving both the old observer contract and reentrant predecessor joining. Keep captured authored recipe, independent candidate sequence and publication-before-retirement ordering. Re-run the applicable complete files on an actual composition rather than attributing these 90e8 results to a later tree.
