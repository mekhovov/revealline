from pathlib import Path
from urllib.request import urlopen
from datetime import datetime,timezone
import json,hashlib,subprocess,sys
root=Path(__file__).resolve().parents[2]
p=Path(__file__).resolve().parent
binding=p/'preview-normal-binding.json';b=json.loads(binding.read_text());over={r['path']:r for r in b['overlays']}
paths=[*over,'game/couch/index.html','game/couch/couch.css','game/multiplayer.mjs','game/ui/controller-navigation.mjs','game/ui/controller-router.mjs','game/presentation/page.mjs'];rows=[]
for name in paths:
 expected=(root/name).read_bytes() if name in over else subprocess.check_output(['git','--no-optional-locks','show',b['head']+':'+name],cwd=root)
 with urlopen('http://127.0.0.1:'+str(b['port'])+'/'+name,timeout=10) as r:body=r.read();assert r.status==200
 assert body==expected;rows.append({'path':name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'expected':'held working file' if name in over else b['head']})
record={'recordedAt':datetime.now(timezone.utc).isoformat(),'bindingSha256':hashlib.sha256(binding.read_bytes()).hexdigest(),'helperSha256':b['helperSha256'],'rows':rows,'scope':'HTTP source bytes only; no picture GET, browser state or native acceptance.'}
target=p/(sys.argv[1]+'.json');assert target.parent==p and not target.exists();target.write_text(json.dumps(record,indent=2)+'\n');print(target,len(target.read_bytes()),hashlib.sha256(target.read_bytes()).hexdigest());print('binding',hashlib.sha256(binding.read_bytes()).hexdigest())
