# Correction to provisional event labels

This run verified New-match confirmation cancels a pending Next while preserving completed results, not the direct Cancel button. At event03 Cancel picture loading was already focused. One Tab moved to New match; Return opened Keep this match confirmation. Events04/05 retain52.2%,8160,1:0 through late completion and event06 returns to results. Direct Cancel will be checked on a separate fresh origin. No claim that event04 activated Cancel.

Root inspected all six JPGs. Screenshot05 is mostly blank and does not corroborate its populated DOM; classify that image as inconclusive, not a game failure or a visual pass. Screens04/06 show the confirmation and preserved-result return.
