from pathlib import Path
from urllib.request import urlopen,Request
from datetime import datetime,timezone
import json,hashlib,subprocess,sys
root=Path(__file__).resolve().parents[2]
p=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(sys.argv)==3
binding=p/sys.argv[1];target=p/sys.argv[2]
assert binding.parent==p and target.parent==p and not target.exists()
b=json.loads(binding.read_text());h=json.loads((p/'source-held-07.json').read_text())
assert b['head']==h['base'] and b['overlays']==h['files'][:4]
over={r['path']:r for r in b['overlays']}
paths=[*over,'game/couch/index.html','game/couch/couch.css','game/multiplayer.mjs','game/ui/controller-navigation.mjs','game/ui/controller-router.mjs','game/presentation/page.mjs'];rows=[]
for name in paths:
 expected=(root/name).read_bytes() if name in over else subprocess.check_output(['git','--no-optional-locks','show',b['head']+':'+name],cwd=root)
 with urlopen('http://127.0.0.1:'+str(b['port'])+'/'+name,timeout=15) as r:body=r.read();assert r.status==200
 assert body==expected
 if name in over:assert len(body)==over[name]['bytes'] and sha(body)==over[name]['sha256']
 rows.append({'path':name,'bytes':len(body),'sha256':sha(body),'expected':'held07 physical source' if name in over else b['head']})
record={'recordedAt':datetime.now(timezone.utc).isoformat(),'bindingSha256':sha(binding.read_bytes()),'helperSha256':b['helperSha256'],'sourceHoldSha256':sha((p/'source-held-07.json').read_bytes()),'rows':rows,'scope':'HTTP source bytes only; no picture GET, browser state or native acceptance.'}
if 'transport' in b:
 t=b['transport'];start=datetime.now(timezone.utc)
 with urlopen(Request('http://127.0.0.1:'+str(b['port'])+'/'+t['path'],method='HEAD'),timeout=15) as r:
  assert r.status==200 and int(r.headers['Content-Length'])==t['bytes'];assert not r.read()
 record['pictureHead']={'status':200,'contentLength':t['bytes'],'elapsedSeconds':(datetime.now(timezone.utc)-start).total_seconds(),'getSequenceConsumed':False}
 log=p/b['requestLog'];record['requestLogAtCheck']={'bytes':len(log.read_bytes()),'sha256':sha(log.read_bytes())}
target.write_text(json.dumps(record,indent=2)+'\n');print(target,len(target.read_bytes()),sha(target.read_bytes()))
