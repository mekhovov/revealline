# Direct Cancel verified

Exactheld06,51279. Keyboard FirstSignal setup→actual52.2% clear8160points1:0→NextGET2failure→retryGET3→read actualactiveElementrace-picture-cancel→Return in samecall. Event03 returns completedresults withNextfocused,52.2%,8160,1:0. After6.5seconds event04 DOM preserves allsamevalues. Viewbothboards shows originalearnedpicture,event05;freshNext event06 starts0%,3lives with1:0 retained.

AllfourJPGs inspected. Screenshot04 is mostlyblank despite populatedDOM, so that individual image is inconclusive. Images03/05/06 clearly show retainedresult,picture,andnewround. No claim of physicalcontroller/touch/humanplaytest. No applicationstateorclockinjection.
