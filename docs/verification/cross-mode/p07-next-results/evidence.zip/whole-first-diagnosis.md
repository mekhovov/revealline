# First complete P07 cohort diagnostic

The held05 Node22 run executed 239 tests: 230 passed and nine failed. Node20 did not execute. The raw log, receipt, unchanged input lists and held05 source remain preserved.

Eight failures arise from the omitted exact `game/content/packs/fpv-arcade-r5.json` fixture: the chapter file could not import; installed recovery and two generated-owner fixtures could not read the pack; the installed default and static Orchard host used First Signal fallback; optional-snapshot fallback had no authored Orchard source; and the 51-combination unit case could not read the pack. This missing fixture is restored byte-for-byte from 90e8, without changing the Git index or generating content.

The ninth failure is an actual compatibility regression in the installed owner: the initial verifying report moved into a microtask. The existing cancellation test immediately reads that report. Held06 restores the report synchronously after publishing the operation promise, so a reentrant operation still has a valid predecessor promise to join. The targeted existing test passes. No assertion changes were needed.

The old normal preview had no native recorder. Its ten source HTTP bodies were checked after the failed run and its four overlay bodies copied before the one runtime edit. Its original configuration and binding remain unchanged. A fresh held06 origin is required for native review.
