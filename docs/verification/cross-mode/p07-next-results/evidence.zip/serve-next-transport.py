from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlsplit
from collections import OrderedDict
import subprocess, mimetypes, hashlib, json, os, threading, re, shutil, argparse, time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--config', required=True)
parser.add_argument('--binding', required=True)
parser.add_argument('--request-log', required=True)
args = parser.parse_args()
config_path = OUT / args.config
binding_path = OUT / args.binding
request_log_path = OUT / args.request_log
if request_log_path.parent != OUT or request_log_path.exists():
    raise RuntimeError('Use a fresh direct request log')
if config_path.parent != OUT or binding_path.parent != OUT or binding_path.exists():
    raise RuntimeError('Use direct owned configuration and a fresh binding name')
config_bytes = config_path.read_bytes()
config = json.loads(config_bytes)
TRANSPORT = {
    'path': 'game/presentation/compiled/assets/c1aedf89bc3433dc1cb60998fa1e2563480a590c38586332f444c4c12c772fce.png',
    'sha256': 'c1aedf89bc3433dc1cb60998fa1e2563480a590c38586332f444c4c12c772fce',
    'bytes': 40810,
    'steps': [{'get': 1, 'status': 200, 'delaySeconds': 0},
              {'get': 2, 'status': 503, 'delaySeconds': 0},
              {'get': 3, 'status': 200, 'delaySeconds': 6}],
    'subsequent': {'status': 200, 'delaySeconds': 0},
    'head': 'unchanged; does not consume the GET sequence',
}
if config.get('transport') != TRANSPORT:
    raise RuntimeError('Only the exact approved First Signal transport sequence is permitted')
BASE = config.get('head')
if not isinstance(BASE, str) or not re.fullmatch('[0-9a-f]{40}', BASE):
    raise RuntimeError('Final merged head remains unbound')
if subprocess.check_output(['git', '--no-optional-locks', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() != BASE:
    raise RuntimeError('Final head differs at preview launch')
LIMIT = 64 * 1024 * 1024
if shutil.disk_usage(OUT).free < 256 * 1024 * 1024:
    raise RuntimeError('Insufficient metadata reserve')
tree = subprocess.check_output(['git', '--no-optional-locks', 'rev-parse', BASE + '^{tree}'], cwd=ROOT, text=True).strip()
if tree != config.get('tree'):
    raise RuntimeError('Final tree binding differs')
regular = {}
for line in subprocess.check_output(['git', '--no-optional-locks', 'ls-tree', '-r', '-z', BASE], cwd=ROOT).split(b'\0'):
    if not line:
        continue
    meta, name = line.split(b'\t', 1)
    mode, kind, oid = meta.decode().split()
    name = name.decode()
    if mode in ('100644', '100755') and name.startswith(('game/', 'authoring/', 'docs/')):
        regular[name] = oid
overlays = {row['path']: row for row in config['overlays']}
if set(overlays) != {'game/couch/couch.mjs', 'game/couch/couch-shell.mjs', 'game/couch/couch-static-pictures.mjs', 'game/couch/couch-installed-chapters.mjs'}:
    raise RuntimeError('Only the four held Next transaction modules may overlay the base')
class OverlayDrift(Exception):
    pass
def overlay_body(name):
    row = overlays[name]
    path = ROOT / name
    if path.is_symlink() or path.stat().st_size != row['bytes'] or row['bytes'] > 1024 * 1024:
        raise OverlayDrift()
    body = path.read_bytes()
    if hashlib.sha256(body).hexdigest() != row['sha256']:
        raise OverlayDrift()
    return body
for name in overlays:
    overlay_body(name)
    regular.setdefault(name, None)
cache = OrderedDict()
cache_bytes = 0
cache_lock = threading.Lock()
requests = threading.BoundedSemaphore(4)

def git_body(name):
    global cache_bytes
    with cache_lock:
        if name in cache:
            body = cache.pop(name)
            cache[name] = body
            return body
        oid = regular[name]
        size = int(subprocess.check_output(['git', '--no-optional-locks', 'cat-file', '-s', oid], cwd=ROOT, stderr=subprocess.DEVNULL))
        if size > LIMIT:
            raise ValueError('Per-file limit')
        while cache and cache_bytes + size > LIMIT:
            _, old = cache.popitem(last=False)
            cache_bytes -= len(old)
        body = subprocess.check_output(['git', '--no-optional-locks', 'cat-file', 'blob', oid], cwd=ROOT, stderr=subprocess.DEVNULL)
        if len(body) != size:
            raise ValueError('Git body size mismatch')
        cache[name] = body
        cache_bytes += size
        return body

fixture = git_body(TRANSPORT['path'])
if len(fixture) != TRANSPORT['bytes'] or hashlib.sha256(fixture).hexdigest() != TRANSPORT['sha256']:
    raise RuntimeError('The exact First Signal original differs')
request_log = request_log_path.open('x')
log_lock = threading.Lock()
ordinal_lock = threading.Lock()
ordinal = 0
def record(event, **details):
    with log_lock:
        request_log.write(json.dumps({'event': event, 'utc': datetime.now(timezone.utc).isoformat(), **details}) + '\n')
        request_log.flush()
def request_step():
    global ordinal
    with ordinal_lock:
        ordinal += 1
        step = next((s for s in TRANSPORT['steps'] if s['get'] == ordinal), TRANSPORT['subsequent'])
        ticket = {'get': ordinal, 'status': step['status'], 'delaySeconds': step['delaySeconds']}
        record('request', path=TRANSPORT['path'], **ticket)
        return ticket

class Handler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.serve(False)
    def do_GET(self):
        self.serve(True)
    def serve(self, send_body):
        with requests:
            if self.headers.get('Host') != '127.0.0.1:' + str(self.server.server_port):
                self.send_error(403)
                return
            name = unquote(urlsplit(self.path).path).lstrip('/')
            if not name:
                self.send_response(302)
                self.send_header('Location', '/game/')
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            if name.endswith('/'):
                name += 'index.html'
            if '\\' in name or any(ord(ch) < 32 for ch in name) or any(part in ('.', '..', '.git', 'node_modules') for part in name.split('/')) or name not in regular:
                self.send_error(404)
                return
            ticket = None
            try:
                body = overlay_body(name) if name in overlays else git_body(name)
                length = len(body)
                if send_body and name == TRANSPORT['path']:
                    ticket = request_step()
                    if ticket['status'] == 503:
                        self.send_error(503, 'Bounded Next original transport refusal')
                        record('response', httpStatus=503, originalBytes=0, **ticket)
                        return
                    if ticket['delaySeconds']:
                        started = time.monotonic()
                        time.sleep(ticket['delaySeconds'])
                        record('delay-complete', elapsedSeconds=time.monotonic() - started, **ticket)
                start, end, status = 0, length - 1, 200
                requested = self.headers.get('Range')
                if requested:
                    match = re.fullmatch(r'bytes=(\d*)-(\d*)', requested)
                    if not match or not any(match.groups()):
                        raise ValueError('Invalid range')
                    low, high = match.groups()
                    if low:
                        start = int(low)
                        end = min(int(high), length - 1) if high else length - 1
                    else:
                        start = max(0, length - int(high))
                    if start > end or start >= length:
                        self.send_response(416)
                        self.send_header('Content-Range', 'bytes */' + str(length))
                        self.send_header('Content-Length', '0')
                        self.end_headers()
                        return
                    status = 206
                kind = 'text/javascript' if name.endswith('.mjs') else mimetypes.guess_type(name)[0] or 'application/octet-stream'
                self.send_response(status)
                self.send_header('Content-Type', kind)
                self.send_header('Content-Length', str(end - start + 1))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Accept-Ranges', 'bytes')
                if status == 206:
                    self.send_header('Content-Range', f'bytes {start}-{end}/{length}')
                self.end_headers()
                if send_body:
                    for offset in range(start, end + 1, 65536):
                        self.wfile.write(memoryview(body)[offset:min(offset + 65536, end + 1)])
                    if ticket is not None:
                        record('response', httpStatus=status, originalBytes=end - start + 1, originalSha256=hashlib.sha256(body).hexdigest(), **ticket)
            except OverlayDrift:
                self.send_error(409, "Held Next transaction source changed")
            except (KeyError, ValueError, subprocess.CalledProcessError):
                self.send_error(404)
            except (BrokenPipeError, ConnectionResetError):
                if ticket is not None:
                    record('client-disconnected', **ticket)
    def log_message(self, format, *args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
server.daemon_threads = True
binding = {'head': BASE, 'tree': tree, 'overlays': list(overlays.values()),
           'pid': os.getpid(), 'port': server.server_port,
           'url': f'http://127.0.0.1:{server.server_port}/game/couch/',
           'gitBlobCacheBytes': LIMIT, 'maxConcurrentRequests': 4,
           'config': {'path': args.config, 'bytes': len(config_bytes),
                      'sha256': hashlib.sha256(config_bytes).hexdigest()},
           'mode': 'First Signal GET1 normal / GET2 503 / GET3 six-second delay / later normal',
           'transport': TRANSPORT, 'requestLog': args.request_log,
           'helperSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'scope': 'Four exact SHA-bound Next transaction modules overlay the stated Git base; every other byte is an original regular Git blob. Only the pinned First Signal GET sequence differs at the transport boundary; HEAD is unchanged. No application state or game-clock fixture. Overlay drift is HTTP409. LRU bounds stored Git blobs, not total process RSS.'}
with binding_path.open('x') as file:
    json.dump(binding, file, indent=2)
    file.write('\n')
print(json.dumps(binding), flush=True)
try:
    server.serve_forever()
finally:
    server.server_close()
    request_log.close()
