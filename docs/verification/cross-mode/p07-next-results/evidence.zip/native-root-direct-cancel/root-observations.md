# Direct-Cancel attempt missed the delay window

At23:59:56.599 event03 Cancel was focused duringGET3 delay. The next action arrived at00:00:03.343, after the6secondresponse. It observed a newly running round with score1:0. Event04 provisional direct-cancel-result label is therefore NOT evidence of a Cancel click or a cancellation defect. DirectCancel remains pending on another independent origin, with activation in the same browser action call as focus observation.
