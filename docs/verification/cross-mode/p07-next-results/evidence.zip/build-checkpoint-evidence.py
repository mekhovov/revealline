"""Retain the bounded P07 originals once all recorders and test runs are closed."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT.parents[2]
CACHE = Path(__file__).resolve().parent
DEST = ROOT / 'docs/verification/cross-mode/p07-next-results'
sha = lambda data: hashlib.sha256(data).hexdigest()

assert shutil.disk_usage(ROOT).free >= 256 * 1024**2
assert (CACHE / 'friendly-copy-sequential-receipt.json').exists()
receipt = json.loads((CACHE / 'friendly-copy-sequential-receipt.json').read_text())
assert len(receipt['records']) == 2
assert all(row['exitCode'] == 0 for row in receipt['records'])
for closed in CACHE.glob('native*/closed.json'):
    assert json.loads(closed.read_text())['closed'] is True

excluded = {'candidate-evidence-inventory.json', 'README-final-draft.md',
            'guide-draft.md', 'guidance-draft.md'}
files = sorted(
    p for p in CACHE.rglob('*')
    if p.is_file() and not p.is_symlink()
    and '__pycache__' not in p.parts
    and p.name not in excluded
    and not p.name.startswith(('package-', 'staged-', 'commit-'))
)
sources = [(p, p.relative_to(CACHE).as_posix(), 'worktree') for p in files]
for folder, prefix in [('p07-friendly-root', 'friendly-native-root'),
                       ('p07-friendly-preparation', 'friendly-preparation')]:
    directory = REPO / '.cache' / folder
    assert directory.is_dir()
    sources += [(p, prefix + '/' + p.relative_to(directory).as_posix(), 'repository')
                for p in sorted(directory.rglob('*')) if p.is_file() and not p.is_symlink()]
assert json.loads((REPO / '.cache/p07-friendly-root/closed.json').read_text()) == {
    'closed': True, 'count': 2}
assert len(sources) < 400
assert sum(p.stat().st_size for p, _, _ in sources) <= 20 * 1024**2
DEST.mkdir(parents=True, exist_ok=True)
archive = DEST / 'evidence.zip'
mapping = DEST / 'evidence.json'
assert not archive.exists() and not mapping.exists()
rows = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for source, member, source_root in sources:
        data = source.read_bytes()
        info = zipfile.ZipInfo(member, (1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        out.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        base = ROOT if source_root == 'worktree' else REPO
        rows.append({'sourceRoot': source_root,
                     'source': source.relative_to(base).as_posix(), 'member': member,
                     'bytes': len(data), 'sha256': sha(data)})
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    assert len(saved.namelist()) == len(set(saved.namelist())) == len(rows)
    for row in rows:
        base = ROOT if row['sourceRoot'] == 'worktree' else REPO
        original = (base / row['source']).read_bytes()
        restored = saved.read(row['member'])
        assert restored == original
        assert len(restored) == row['bytes'] and sha(restored) == row['sha256']
body = archive.read_bytes()
mapping.write_text(json.dumps({
    'scope': 'Exact originals, including failed and inconclusive predecessors. '
             'Archive membership is retention, not a passing qualification claim. '
             'No runtime asset or complete ledger duplicates are included.',
    'archive': {'path': 'evidence.zip', 'bytes': len(body), 'sha256': sha(body)},
    'sourceRoots': {'worktree': str(ROOT), 'repository': str(REPO)},
    'members': len(rows), 'originalBytes': sum(row['bytes'] for row in rows),
    'files': rows,
}, indent=2) + '\n')
print(json.dumps({'members': len(rows), 'originalBytes': sum(r['bytes'] for r in rows),
                  'archiveBytes': len(body), 'archiveSha256': sha(body),
                  'mappingSha256': sha(mapping.read_bytes())}))
