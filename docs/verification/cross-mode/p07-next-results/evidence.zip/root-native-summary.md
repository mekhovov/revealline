# P07 Next-round browser review

Source: held06 (0852481a279486e0f63b80830228a4092142177b9f390eec15c1174567730c08). Five independent local origins used the same held runtime. No application state or clock was injected. The actual viewport was 1454 × 1348 CSS pixels at DPR 1.7999999523. All 23 captured JPEGs were inspected by root.

| Origin | Observed result | Scope |
| --- | --- | --- |
| 64817 | A real First Signal clear earned 52.2%, 8,160 points and a 1:0 match score. Next started a fresh round with three lives and preserved the 1:0 tally. | Pass for normal Next. The later attempt lost a life; it was not a second clear. |
| 64818 | The next picture returned HTTP 503. Results and View both boards remained available. Help cancelled the delayed retry; focus stayed on Read controls. Returning to results, viewing the earned image and a fresh Next all worked. | Pass for failure and Help cancellation. The host-only Ready-with-Help case is separate. |
| 64819 | Opening New match during the delayed retry cancelled it. Keep this match restored the earned result and score. | Pass for the observed setup confirmation. This was not a direct Cancel activation. |
| 50955 | Cancel had focus, but the next tool action occurred after the six-second delay had expired. A new round was already running. | Inconclusive for Cancel; not a product failure. |
| 51279 | Cancel was observed and activated in the same browser call, within the delayed request. The result and Next focus remained after 6.5 seconds. The original earned picture remained viewable; a fresh Next then started normally. | Pass for direct Cancel and retry. |

The HTTP 503 status exposes an internal asset path. The friendly-message successor remains necessary before accepting this feature. All five held06 HTTP/source comparisons must be retained separately from that successor.

Two individual screenshots were mostly blank despite populated DOM: 64819/event05 and 51279/event04. They are not visual passes. Their adjacent screenshots and recorded DOM support the narrower observations above. Provisional labels that anticipated a different outcome are explicitly corrected in each recorder's root notes; they are not assertions.

This verifies desktop browser keyboard journeys only. It does not certify physical controllers, touch hardware, audible output, human challenge/replay value, every campaign, or a public release.
