import sys,json,hashlib,subprocess,time,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
CACHE=ROOT/'.cache/next-result'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *x:subprocess.check_output(['git','--no-optional-locks',*x],cwd=ROOT)
authority=json.loads((CACHE/'qualification-inputs.json').read_text())
mode=sys.argv[1]
assert mode in ['targeted-final','whole-final']
assert not (CACHE/(mode+'-receipt.json')).exists()
def guard():
 assert git('rev-parse','HEAD').decode().strip()==authority['head']
 assert git('rev-parse','HEAD^{tree}').decode().strip()==authority['tree']
 assert sha(git('ls-files','--stage','-z'))==authority['indexSha256']
 assert not git('diff','--cached','--name-only')
 assert shutil.disk_usage(ROOT).free>=256*1024**2
 rows=[]
 for row in authority['inputs']:
  b=(ROOT/row['path']).read_bytes();actual={'path':row['path'],'bytes':len(b),'sha256':sha(b)};assert actual==row,row['path'];rows.append(actual)
 for row in authority['runtimes']:
  b=Path(row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 return rows
runner=Path(__file__).read_bytes();bound=(CACHE/'qualification-inputs.json').read_bytes();before=guard()
(CACHE/(mode+'-before.json')).write_text(json.dumps(before,indent=2)+'\n')
records=[]
for index,runtime in enumerate(authority['runtimes'] if mode=='whole-final' else authority['runtimes'][:1]):
 label='node22' if index==0 else 'node20'
 command=[runtime['path'],'--test','--test-concurrency=2']
 if mode=='targeted-final':
  command+=['--test-name-pattern=Next|staged|pending static stage|final context callback|previous-image cleanup|committed prior|installed candidate ready']
  files=authority['testFiles'][:3]
 else:files=authority['testFiles']
 command+=files
 log=CACHE/(mode+'-'+label+'.log');assert not log.exists();started=time.monotonic()
 with log.open('xb') as out:result=subprocess.run(command,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT)
 elapsed=time.monotonic()-started;b=log.read_bytes()
 records.append({'runtime':label,'command':command,'exitCode':result.returncode,'elapsedSeconds':elapsed,'log':log.name,'bytes':len(b),'sha256':sha(b)})
 assert Path(__file__).read_bytes()==runner and (CACHE/'qualification-inputs.json').read_bytes()==bound
 after=guard();(CACHE/(mode+'-after-'+label+'.json')).write_text(json.dumps(after,indent=2)+'\n')
 (CACHE/(mode+'-receipt.json')).write_text(json.dumps({'head':authority['head'],'tree':authority['tree'],'runnerSha256':sha(runner),'authoritySha256':sha(bound),'sourceHold':'source-held-04.json','inputCount':len(before),'inputBytes':authority['inputBytes'],'records':records,'inputsUnchanged':True},indent=2)+'\n')
 print(json.dumps(records[-1]),flush=True);print(b.decode()[-1400:],flush=True)
 if result.returncode:break
