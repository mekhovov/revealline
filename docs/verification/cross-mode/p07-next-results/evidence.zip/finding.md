# P07 failed-Next diagnostic

Base: `90e8bc8102cc71a992a57aa1f41d7cdcd6659b3e`. This isolated worktree is a diagnostic, not a releasable feature or an accepted phase. Production remains unchanged.

The new single host regression in `game/test/couch-static-picture-host.test.mjs` completes a real simulated round, retains its two run identities, checkpoints, result text and original picture, then refuses the next full picture decode. It fails at the first preservation assertion: actual `ready`, expected `finished`. `baseline.json`, raw logs and 524 before/after input pins retain that result. Browser image decoding is modeled; this is not a native network-failure result.

The source cause is `game/couch/couch.mjs`: the finished branch clears a completed match's wins when appropriate and calls `prepare()` before awaiting picture selection. `prepare()` immediately replaces the duel, resets presentation, and releases the installed picture owner. A failed next decode therefore leaves the new empty round instead of the completed Results.

Required correction: prepare the next duel and its picture as a separate candidate, leaving Results and both original arenas alive until the candidate is verified and deliberately adopted. Failure and Cancel discard only that candidate. They must preserve run identity, scores, round-win totals, original picture bytes/decoded lifetime, and View both boards. A late completion after a newer action, hidden page or disposal cannot start a round. If backgrounding retires Start but preparation succeeds, the existing explicit-Start contract must remain clear and tested.

A shallow assignment rollback is insufficient: installed `clear()` releases the accepted image, and `select()` clears its binding before preparation. Static selection releases its previous binding on adoption, before the host's later confirmation. Any transaction must preserve the old decoded lease until the host commits, including a failure during final confirmation. No captured canvas or substitute artwork is an acceptable replacement for the original identity.

Acceptance scenarios: decode/read/confirmation failure; explicit Cancel; failed retry then successful retry; new-match wins preserved until adoption; duplicate clicks; Back/Help/blur during preparation; stale completion after setup/disposal; same exact picture on both boards; no duplicate or Solo progression writes. Qualify shipped and installed chapters independently, then a real browser delayed/failed Next journey. The existing interrupted-Next expectation is retained unless the approved contract is explicitly revised with evidence.

This finding is assigned to the already approved P07 gate. It does not change delivery order or silently add failing tests to another phase.
