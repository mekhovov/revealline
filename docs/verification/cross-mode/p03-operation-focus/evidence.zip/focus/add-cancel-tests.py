from pathlib import Path
p=Path('game/test/operation-focus-host.test.mjs');s=p.read_text().replace("import { attachMissionPicker }", "import { captureOperationFocus } from '../ui/operation-focus.mjs';\nimport { attachMissionPicker }")
s=s.replace('  nativeDisabled(opener, () => onEnable?.(h));', "  nativeDisabled(opener, () => onEnable?.(h));\n  if (kind === 'install') nativeDisabled(h.$('library-operation-cancel'));")
a=s.index("test('explicit Library Cancel still returns")
s=s[:a]+'''// Native interior Tab remains browser-owned. Model its sequential start at the
// disabled opener; shared navigation still owns boundary wrapping and key events.
function tabToCancel(h, root, opener) {
  let cursor = opener;
  const eligible = (node) => {
    if (node.disabled || node.closest('[hidden],[inert]')) return false;
    for (let ancestor = node.parentElement; ancestor && ancestor !== root; ancestor = ancestor.parentElement)
      if (ancestor.tagName === 'DETAILS' && !ancestor.open && ancestor.querySelector('summary') !== node)
        return false;
    return true;
  };
  const expected = [
    [...root.querySelectorAll('summary')].find((node) => node.textContent === 'Paste pack JSON'),
    root.querySelector('[data-close="library-dialog"]'),
    h.$('library-operation-cancel'),
  ];
  for (const target of expected) {
    assert.ok(target);
    const active = h.doc.activeElement,
      event = active.emit('keydown', { key: 'Tab', code: 'Tab' });
    if (!event.defaultPrevented) {
      const all = [...root.querySelectorAll('button,a,input,select,textarea,summary')],
        index = all.indexOf(cursor);
      for (let n = 1; n <= all.length; n++) {
        const next = all[(index + n) % all.length];
        if (eligible(next)) { next.focus(); break; }
      }
    }
    cursor = h.doc.activeElement;
    assert.equal(cursor === target, true, `Actual native Tab order reaches ${target.id || target.textContent}`);
    cursor.emit('keyup', { key: 'Tab', code: 'Tab' });
  }
  return cursor;
}
test('explicit Library Cancel after three native Tabs renews return to the actual Install action', async (t) => {
  const { h, opener, root, complete } = await pending(t, 'install');
  const cancel = tabToCancel(h, root, opener);
  cancel.click();
  assert.equal(h.doc.activeElement === opener, true);
  await complete();
  assert.equal(h.doc.activeElement === opener, true);
  assert.match(h.$('pack-status').textContent, /Cancelled/);
});
for (const interruption of ['background', 'closed-root', 'cleanup-focus', 'cleanup-blur']) {
  test(`fresh explicit Cancel cannot restore after ${interruption}`, async (t) => {
    const { h, opener, root, complete } = await pending(t, 'install', {
      onEnable(page) {
        if (interruption === 'cleanup-focus')
          [...page.$('library-dialog').querySelectorAll('summary')].find((e) => e.textContent === 'Paste pack JSON').focus();
        if (interruption === 'cleanup-blur') page.win.emit('blur');
      },
    });
    const cancel = tabToCancel(h, root, opener), callback = cancel.onclick;
    if (interruption === 'background') { h.doc.focused = false; h.win.emit('blur'); }
    if (interruption === 'closed-root') root.close();
    callback(); // A queued actual control handler must still respect current ownership.
    assert.equal(h.doc.activeElement === opener, false);
    await complete();
    assert.equal(h.doc.activeElement === opener, false);
  });
}
test('Cancel while actual pack commit is finishing remains detached and cannot restore focus', async (t) => {
  const { h, opener, complete } = await pending(t, 'install');
  const cancel = h.$('library-operation-cancel'),
    text = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(SoloElement.prototype), 'textContent');
  let stopped = false;
  Object.defineProperty(cancel, 'textContent', {
    configurable: true,
    get() { return text.get.call(this); },
    set(value) {
      text.set.call(this, value);
      if (value === 'Stop waiting' && !stopped) {
        stopped = true;
        queueMicrotask(() => { cancel.focus(); cancel.click(); });
      }
    },
  });
  await complete();
  assert.equal(stopped, true, 'The actual commit stage was reached before Stop waiting');
  assert.equal(h.doc.activeElement === opener, false);
  assert.match(h.$('pack-status').textContent, /Validated and installed/);
  assert.ok([...h.$('installed-packs').querySelectorAll('button')].some((e) => e.textContent.startsWith('Play ')));
});
test('fresh return intent refuses a target outside its captured dialog', async (t) => {
  const { h, opener, complete } = await pending(t, 'install');
  const cancel = h.$('library-operation-cancel'), outside = h.$('shell-featured');
  cancel.focus();
  const lease = captureOperationFocus(cancel, { restoreTo: outside });
  assert.equal(lease.restore(), false);
  assert.equal(h.doc.activeElement === outside, false);
  cancel.click();
  await complete();
  assert.equal(h.doc.activeElement === opener, true);
});
'''
p.write_text(s)
