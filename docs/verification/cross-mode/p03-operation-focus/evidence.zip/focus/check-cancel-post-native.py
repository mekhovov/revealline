from pathlib import Path
import urllib.request,hashlib,json,subprocess,time
out=Path(__file__).resolve().parent
root=out.parents[1]
results=[]
for suffix in ['cancel']:
 config=json.loads((out/f'preview-config-{suffix}.json').read_text())
 bindingfile=out/'preview-cancel-delayed.json'
 binding=json.loads(bindingfile.read_text());overlays={r['path']:r for r in config['overlays']};rows=[]
 for path in config['httpCheckPaths']:
  expected=(root/path).read_bytes() if path in overlays else subprocess.check_output(['git','--no-optional-locks','show',binding['head']+':'+path],cwd=root)
  if path in overlays: assert hashlib.sha256(expected).hexdigest()==overlays[path]['sha256']
  start=time.monotonic()
  with urllib.request.urlopen(binding['url'].removesuffix('game/')+path,timeout=12) as response:
   body=response.read(1024*1024);assert body==expected and response.status==200
   rows.append({'path':path,'status':response.status,'mime':response.headers['Content-Type'],'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'elapsedSeconds':time.monotonic()-start})
 results.append({'binding':{'path':bindingfile.name,'sha256':hashlib.sha256(bindingfile.read_bytes()).hexdigest()},'paths':rows})
with (out/'post-native-http-cancel.json').open('x') as f:json.dump(results,f,indent=2);f.write('\n')
print('Held04 final6 HTTP pins match after9 native observations.')
