import test from 'node:test';
import assert from 'node:assert/strict';
import { soloPage, SoloElement, settle } from './helpers/solo-dom.mjs';
import { attachMissionPicker } from '../ui/mission-picker.mjs';

// Native disabling immediately moves focus off the button. Keep this local:
// the shared minimal DOM deliberately does not claim browser focus semantics.
function nativeDisabled(element, onEnable = () => {}) {
  let disabled = element.disabled;
  Object.defineProperty(element, 'disabled', {
    configurable: true,
    get: () => disabled,
    set(value) {
      const was = disabled;
      disabled = value;
      if (value && element.ownerDocument.activeElement === element) {
        element.blur();
        // Native blur does not bubble, but window/document capture still observes it.
        element.emit('blur', { bubbles: false, relatedTarget: null });
      }
      if (was && !value) onEnable();
    },
  });
}
async function pending(t, kind, { failure = false, onEnable } = {}) {
  const show = SoloElement.prototype.showModal;
  t.mock.method(SoloElement.prototype, 'showModal', function () {
    this.emit('beforetoggle', { oldState: 'closed', newState: 'open', bubbles: false });
    show.call(this);
  });
  const h = await soloPage(t, { titleScreen: true });
  // Model the actual Window identity, preserving this harness's style/Event stubs.
  Object.assign(h.win, h.doc.defaultView);
  h.doc.defaultView = h.win;
  let opener, root;
  if (kind === 'chapter') {
    h.$('shell-play').click();
    root = h.$('shell-missions');
    opener = [...h.$('mission-picker-cards').children].find(
      (node) => node.getAttribute('data-pack') === 'night-shift',
    );
  } else {
    h.$('shell-workshop').click();
    h.$('shell-library').click();
    h.doc.querySelector('[data-library-panel="packs"]').click();
    root = h.$('library-dialog');
    await settle(() =>
      [...h.$('builtin-packs').querySelectorAll('button')].some(
        (node) => node.textContent === 'Install fieldcraft',
      ),
    );
    opener = [...h.$('builtin-packs').querySelectorAll('button')].find(
      (node) => node.textContent === 'Install fieldcraft',
    );
  }
  assert.equal(root.open, true);
  const original = globalThis.fetch;
  let finish,
    requested = false;
  const gate = new Promise((resolve) => {
    finish = resolve;
  });
  t.mock.method(globalThis, 'fetch', async (url, options) => {
    if (url === `content/packs/${kind === 'chapter' ? 'night-shift' : 'fieldcraft'}.json`) {
      requested = true;
      await gate;
      if (failure) throw new Error('Original chapter unavailable');
    }
    return original(url, options);
  });
  nativeDisabled(opener, () => onEnable?.(h));
  opener.focus();
  opener.click();
  await settle(() => requested);
  assert.equal(opener.disabled, true);
  assert.equal(h.doc.activeElement === h.doc.body, true, 'Native disable dropped initiating focus');
  const complete = async () => {
    finish();
    if (kind === 'chapter') {
      await settle(() => !h.$('pack-select').disabled);
      // Flush the observer boundary absent from this minimal DOM.
      attachMissionPicker({ document: h.doc }).sync();
    } else await settle(() => !opener.disabled);
    await new Promise((resolve) => setImmediate(resolve));
    h.frame(0);
  };
  t.after(finish);
  return { h, opener, root, complete };
}
for (const kind of ['chapter', 'install']) {
  for (const failure of [false, true]) {
    test(`${kind} ${failure ? 'error' : 'completion'} restores its still-owned actual button after native disable`, async (t) => {
      const { h, opener, root, complete } = await pending(t, kind, { failure });
      const before = h.rendered.run;
      await complete();
      assert.equal(h.doc.activeElement === opener, true, 'Return to the exact initiating action');
      assert.equal(root.open, true);
      assert.equal(h.rendered.paused, true);
      assert.equal(h.rendered.run.tick, 0, 'Completion does not start a flight');
      if (kind === 'install' || failure) assert.equal(h.rendered.run === before, true);
      const status = h.$(kind === 'chapter' ? 'content-select-status' : 'pack-status');
      assert.match(
        status.textContent,
        failure
          ? kind === 'chapter'
            ? /Chapter download unavailable: Night Shift/
            : /Original chapter unavailable/
          : kind === 'chapter'
            ? /selected and ready/
            : /Validated and installed/,
      );
      if (kind === 'install' && !failure)
        assert.ok(
          [...h.$('installed-packs').querySelectorAll('button')].some((e) =>
            e.textContent.startsWith('Play '),
          ),
        );
    });
  }
  for (const decision of [
    'focus',
    'blur',
    'hidden',
    'pagehide',
    'close',
    'new-dialog',
    'body-key',
  ]) {
    test(`${kind} completion does not reclaim focus after ${decision}, even after returning to BODY`, async (t) => {
      const { h, opener, root, complete } = await pending(t, kind);
      if (decision === 'focus') {
        const back = root.querySelector('[data-close]');
        back.focus();
        back.blur();
      } else if (decision === 'blur') {
        h.win.emit('blur');
        h.win.emit('focus');
      } else if (decision === 'hidden') {
        h.doc.hidden = true;
        h.doc.emit('visibilitychange');
        h.doc.hidden = false;
        h.doc.emit('visibilitychange');
      } else if (decision === 'pagehide') h.win.emit('pagehide', { persisted: true });
      else if (decision === 'close') {
        root.close();
        root.showModal();
      } else if (decision === 'new-dialog') {
        h.$('help-dialog').showModal();
        h.$('help-dialog').close();
      } else h.doc.body.emit('keydown', { key: 'Tab', code: 'Tab' });
      await complete();
      assert.equal(
        h.doc.activeElement === opener,
        false,
        'A completed operation cannot undo newer intent',
      );
    });
  }
  test(`${kind} enable callback choosing another control is not overwritten`, async (t) => {
    const { h, opener, root, complete } = await pending(t, kind, {
      onEnable(page) {
        page
          .$(kind === 'chapter' ? 'shell-missions-back' : 'library-dialog')
          .querySelector?.('[data-close]')
          ?.focus();
        if (kind === 'chapter') page.$('shell-missions-back').focus();
      },
    });
    await complete();
    assert.equal(h.doc.activeElement === opener, false);
    assert.equal(root.contains(h.doc.activeElement), true);
  });
}
test('explicit Library Cancel still returns to the actual Install action', async (t) => {
  const { h, opener, complete } = await pending(t, 'install');
  h.$('library-operation-cancel').focus();
  h.$('library-operation-cancel').click();
  assert.equal(h.doc.activeElement === opener, true);
  await complete();
  assert.equal(h.doc.activeElement === opener, true);
  assert.match(h.$('pack-status').textContent, /Cancelled/);
});
