from pathlib import Path
import subprocess,json,hashlib,time
root=Path.cwd();out=root/'.cache/operation-focus';names=[str(p.relative_to(root)) for p in sorted((root/'game').rglob('*')) if p.is_file()]
def pins():return [{'path':n,'bytes':(root/n).stat().st_size,'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest()} for n in names]
for version in ['22.22.2','20.19.5']:
 label='final-node'+version.split('.')[0];node='/Users/oleksandr.mekhovov/.local/share/mise/installs/node/'+version+'/bin/node';before=pins();(out/(label+'-before.json')).write_text(json.dumps(before,indent=2)+'\n');start=time.monotonic()
 args=[node,'--test','--test-concurrency=2','--test-reporter=tap','game/test/coop-host.test.mjs','game/test/title-operation-status-host.test.mjs','game/test/operation-focus-host.test.mjs','game/test/mission-picker.test.mjs','game/test/mission-replacement-host.test.mjs','game/test/library-launch-host.test.mjs','game/test/modal-navigation.test.mjs']
 with (out/(label+'.log')).open('wb') as f:
  try:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=300);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 after=pins();(out/(label+'-after.json')).write_text(json.dumps(after,indent=2)+'\n');record={'base':subprocess.check_output(['git','--no-optional-locks','rev-parse','HEAD'],text=True).strip(),'command':args,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'existingInputsUnchanged':before==after,'logSha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()};(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);print('\n'.join((out/(label+'.log')).read_text().splitlines()[-10:]),flush=True)
 if code or before!=after:break
