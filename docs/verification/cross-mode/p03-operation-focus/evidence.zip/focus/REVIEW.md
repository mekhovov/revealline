# P03 operation focus correction

Base: `3acce1941116d18f9e86dcfa26dea463433cd3b2`, tree `d85af7e5d33100575317078aeba8df57d74fe2d5`.

The combined 34-file run remains a failed diagnostic: Node 22 had 740 tests, 737 pass and three obsolete fixture failures; Node 20 did not run. Its exact files stay in the original p03a-navigation cache. Independent Lagrange metadata review reconciled all 281 inputs and the raw summary. This work does not turn that run into a pass or add its count to the corrective tests.

Two actual native failures are separate from those fixtures. On the original source, disabling the focused Night Shift chapter card loses focus; the card is enabled after installation but never reclaims it. Library Install Fieldcraft similarly disables its actual initiating control; existing releaseTask restored only if Cancel had focus. The original native review has 47 events/eight screenshots, SHA f41b07b86cbd65a39030f8ee9d92b26fdf5549bfc6b346629ce976a0a6727489. Events21 and30 record the losses. The parent's event42 correction and other journey limits remain authoritative.

## Source boundary

A small ephemeral focus lease captures only the actual focused initiating control in its open dialog. It retires on another focused control, input outside its owned controls, a new/closing dialog, blur, hidden document, pagehide or explicit owner cancellation. It consumes itself before restoring, after checking the same connected/enabled/visible control and current foreground/focus. It neither opens a dialog nor triggers an action.

The chapter adapter requires a real busy cycle and the same mirrored row; external native selection or destruction cancels the lease. The Library adapter retains existing task/commit/check/abort logic and includes its existing Cancel control as an owned focus target. A detached write cancels focus ownership. No app, core, replay, strict profile, save, content installation or producer logic changes.

The connected original Install button survives refresh and is restored; this is not a general row-replacement focus solution. Remove from device legitimately removes/recreates its row. Both the old and new path refuse a disconnected opener; no separate resulting-row fallback was found in refresh/releaseTask. That remains a source limitation, not a newly observed native journey or a claim this patch fixes.

## Tests and retained diagnostics

The two fixture corrections alone passed all 76 tests on each runtime. Their original sources, exact final diff and receipts remain in `.cache/legacy-fixture-corrections`. Team now asserts all three actual fixed Solo links (header, Title, Missions). The Title tests assert named Start and induce the original download failure through a real explicit Missions selection, preserving error, run, pause, selection and saved bytes.

The new 21-case actual-host file models immediate native blur when a button is disabled and uses actual app/pack/Library handlers. It covers successful/error completion, explicit Cancel, changed focus followed by BODY, blur/foreground, hide/return, pagehide, close/reopen, another dialog, body keyboard intent and reentrant enable callbacks. The exact unchanged-source final baseline (`native-drop-before-04.log`) is 17 pass/four failures: both observed controls after completion/error. The corrected file passes 21/21. Earlier test-boundary errors are retained: wrong Missions opener, absent mock MutationObserver flushing, minimal defaultView lacking its window event target, the missing exact 15,204-byte Fieldcraft fixture, and wrapped chapter error copy. None is called a product failure.

The final whole-file scope is coop-host, title-operation-status-host, operation-focus-host, mission-picker, mission-replacement-host, library-launch-host and modal-navigation. Counts come from each actual complete raw run, not from adding the previous 76 or 21. Every finite materialized game input is hashed before/after. The complete 34-file combined gate must run again only after this correction is accepted and integrated.

The original main preview stays unchanged. Candidate preview is Git base3acce plus only three exact held focus modules, no application-state or game-clock fixture. It retains helper/config/binding/five HTTP pins; source drift returns409. Native correction, whole combined source, hosted/public and physical device acceptance remain separate gates.

## Native-proven successor

The first corrective candidate's seven-file pair passed 182 tests on both Nodes, but native port60252 still lost both controls. The root's four native events retain the chapter failure, its corrected premature success label (event3), and Library failure (event4), plus both original PNGs. That pair is a superseded source result, not accepted native evidence.

The actual browser exposed a capture-phase distinction: a descendant button's non-bubbling blur reaches a capturing window listener. The first helper treated it as losing the page. The successor checks `event.target === window` before retiring for window blur. No picker/Library owner logic changed. The local test model now emits that real non-bubbling element event and uses one actual Window identity; it preserves the existing true-window blur refusal and explicit Cancel oracle. The strengthened predecessor is 16/21 with five failures; the final targeted successor is21/21.

The first model correction initially routed events through h.win but retained a different defaultView object; two window-identity test failures were preserved and corrected in the model. An early whole successor run was stopped after that targeted result was noticed; it is a partial diagnostic with no complete count or Node20 run. All originals remain retained. Final source is held03, SHA5196f7a87486db6807f80423b8b95c23458db6065acbe68b8967baea2bb36d9a, with helper bfd24cb4985c6103acbb93115b6db135cf9c5b6acf25cbfb6c02a5727d4e442c. The final whole pair and fresh native61285 result must close independently.

Final closure: the held03 seven-file pair passes182/182 on each Node runtime, all280 finite game inputs unchanged. Root's successor native12events/threePNG closes both connected-opener cases and deliberate pending Tab→Paste pack JSON summary/no-steal. Its attempted optional Cancel instead reached Close Library; event12 corrects10–11, so there is no native operation-Cancel claim. The original first-candidate four events/twoPNG and all earlier raw diagnostics are preserved. Post-native source HTTP checks rehash all five normal and six delayed paths against exact held modules/base Git bytes. This is a bounded corrective work package; final combined35-file and hosted/public/physical gates remain open.
