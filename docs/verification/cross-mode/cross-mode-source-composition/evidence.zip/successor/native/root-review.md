# Collection return correction

Scoped native PASS on successor ebcf47cc, normal54111 origin. Keyboard Title→Collection→Flight records→Saves; the actual file chooser imports the retained legal25-record fixture. Upload activation used a pointer, so this is not a keyboard-only file-picker claim. Escape and600ms settlement retain focus on collection-records at y1287.578,bottom1331.571 inside actual1454×1348; Collection scroll562.222 and all five interior hit samples pass. Reopening Library and Escape again preserves the same visible opener. The prior empty-to-import growth defect had y1849.800 outside this viewport.

Four recorded actions, two original JPEGs; root inspected both. Source normal transport only, no app/state/time injection. Fixture records originate from legal traces, not human wins. The separate Field Kit whole-file pair, final composition/source gates, responsive public release and physical devices remain outstanding.
