from pathlib import Path
import hashlib,json,subprocess,sys,time,datetime,re,shutil
c=Path('.cache/collection-records-return');name=sys.argv[1];tests=json.loads((c/(name+'-cohort.json')).read_text())['testFiles'];hold=c/'source-held-02.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def snapshot():
 index=subprocess.check_output(['git','ls-files','-s','-z']);paths={r.split(b'\t')[1].decode() for r in index.split(b'\0') if r};paths.update(r['path'] for r in json.loads(hold.read_text())['files']);rows=[pin(p) for p in sorted(paths) if Path(p).is_file() and not Path(p).is_symlink()]
 return {'indexTree':subprocess.check_output(['git','write-tree'],text=True).strip(),'canonicalIndexSha256':sha(index),'count':len(rows),'bytes':sum(r['bytes'] for r in rows),'files':rows}
for row in json.loads(hold.read_text())['files']:assert pin(row['path'])==row
before=snapshot();(c/(name+'-before.json')).write_text(json.dumps(before,indent=2)+'\n');results=[]
for version in ['22.22.2','20.19.5']:
 assert snapshot()==before;assert shutil.disk_usage('.').free>268435456
 node=f'/Users/oleksandr.mekhovov/.local/share/mise/installs/node/{version}/bin/node';assert subprocess.check_output([node,'--version'],text=True).strip()=='v'+version
 argv=[node,'--test','--test-concurrency=1',*tests];log=c/f'{name}-node{version.split(".")[0]}.log';started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();print('START',name,version,len(tests),flush=True)
 with log.open('wb') as f:run=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
 (c/f'{name}-child-node{version.split(".")[0]}.json').write_text(json.dumps({'argv':argv,'exitCode':run.returncode,'elapsedSeconds':time.monotonic()-t},indent=2)+'\n')
 summary={k:int(m[-1]) for k in ['tests','pass','fail','cancelled','skipped','todo'] if (m:=re.findall(r'^# '+k+r' (\d+)$',log.read_text(),re.M))};after=snapshot();assert after==before;(c/f'{name}-after-node{version.split(".")[0]}.json').write_text(json.dumps(after,indent=2)+'\n')
 result={'version':version,'node':pin(node),'argv':argv,'startedAt':started,'elapsedSeconds':time.monotonic()-t,'exitCode':run.returncode,'log':pin(log),'summary':summary,'inputsUnchanged':True};results.append(result);print(json.dumps(result),flush=True)
 (c/(name+'-verification.json')).write_text(json.dumps({'sourceHold':pin(hold),'runner':pin(__file__),'testFiles':tests,'inputs':{k:v for k,v in before.items() if k!='files'},'results':results,'completePair':len(results)==2 and all(r['exitCode']==0 for r in results)},indent=2)+'\n')
 if run.returncode:sys.exit(run.returncode)
