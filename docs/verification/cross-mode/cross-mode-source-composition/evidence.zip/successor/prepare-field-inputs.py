from pathlib import Path
import json,subprocess,hashlib,shutil
root=Path.cwd();c=Path('.cache/collection-records-return');plan=json.loads((c/'finite-extra-plan.json').read_text());final=json.loads((c/'focus-verification.json').read_text());assert final['completePair']
assert shutil.disk_usage('.').free>268435456
index_before=subprocess.check_output(['git','ls-files','-s','-z']);tree=subprocess.check_output(['git','write-tree'],text=True).strip();assert tree==plan['tree']
owned=lambda:sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts)
remove=sorted([p for p in Path('docs/verification').rglob('*') if p.is_file() and not p.is_symlink() and 'fpv-redesign/baseline' not in str(p)]+[Path('game/content/packs/homeward-skies.json')]);removed=[]
for p in remove:
 b=p.read_bytes();oid=subprocess.check_output(['git','rev-parse',tree+':'+str(p)],text=True).strip();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid;removed.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':oid})
missing=[r for r in plan['missing'] if not Path(r['path']).exists()];before=owned();projected=before-sum(r['bytes'] for r in removed)+sum(r['bytes'] for r in missing)
assert projected<100*1024**2-1024*1024,projected
assert shutil.disk_usage('.').free+sum(r['bytes'] for r in removed)-sum(r['bytes'] for r in missing)>268435456
subprocess.run(['git','update-index','--skip-worktree','--stdin'],input=''.join(r['path']+'\n' for r in removed).encode(),check=True)
for p in remove:p.unlink()
gitdir=Path(subprocess.check_output(['git','rev-parse','--absolute-git-dir'],text=True).strip());sparse=gitdir/'info/sparse-checkout';patterns=set(sparse.read_text().splitlines());patterns.difference_update('/'+r['path'] for r in removed);patterns.update('/'+r['path'] for r in missing);sparse.write_text('\n'.join(sorted(patterns))+'\n')
added=[]
for r in missing:
 b=subprocess.check_output(['git','cat-file','blob',r['gitBlob']]);assert len(b)==r['bytes'];p=Path(r['path']);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);added.append({**r,'sha256':hashlib.sha256(b).hexdigest()})
subprocess.run(['git','update-index','--no-skip-worktree','--stdin'],input=''.join(r['path']+'\n' for r in missing).encode(),check=True)
assert subprocess.check_output(['git','ls-files','-s','-z'])==index_before
receipt={'tree':tree,'scope':'Swap exact owned immutable evidence/Homeward copies for the existing Field Kit whole-file reference inventory. No source edits, builds or generation. Eight-file pair is already sealed.','removed':removed,'added':added,'ownedBefore':before,'ownedAfter':owned(),'freeAfter':shutil.disk_usage('.').free,'indexUnchanged':True}
(c/'field-input-swap.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['removed','added']},indent=2))
