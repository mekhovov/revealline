from pathlib import Path
import json,hashlib,urllib.request,datetime,sys
out=Path(__file__).resolve().parent;root=out.parents[2];plan=json.loads((out/'http-source-plan.json').read_text());bp=out/'binding-native.json';binding=json.loads(bp.read_text());rows=[]
for row in plan['files']:
 with urllib.request.urlopen(binding['urls']['solo'].removesuffix('/game/')+'/'+row['path'],timeout=30) as response:
  body=response.read();assert response.status==200;assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256'];local=root/row['path'];assert local.is_file() and local.read_bytes()==body
  rows.append({**row,'httpStatus':response.status,'localMatches':True,'httpMatches':True,'contentType':response.headers.get('Content-Type')})
b=bp.read_bytes();receipt={'status':'All27 exact successor HTTP/local bodies match the immutable source plan.','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tree':plan['tree'],'origin':binding['urls']['solo'].removesuffix('/game/'),'binding':{'path':str(bp.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'files':rows,'count':len(rows),'bytes':sum(r['bytes'] for r in rows),'limits':'Read-only source response checks, no browser/application state. Native admission retains the pending separate Field Kit gate.'};p=out/(sys.argv[1]+'.json');assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');b=p.read_bytes();print(p.name,len(b),hashlib.sha256(b).hexdigest());print('binding',receipt['binding'])
