from pathlib import Path
import subprocess,json,hashlib,time,datetime,shutil,re,sys
c=Path('.cache/cross-mode-composition/final');plan=json.loads((c/'test-admission-plan.json').read_text());tree=plan['tree'];tests=plan['testFiles']
def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot():
 staged=subprocess.check_output(['git','ls-files','-s','-z']);rows=[]
 for line in staged.split(b'\0'):
  if not line:continue
  meta,path=line.split(b'\t',1);mode,blob,stage=meta.decode().split();assert stage=='0';p=Path(path.decode())
  if not p.is_file() or p.is_symlink():continue
  b=p.read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==blob,str(p);rows.append({'path':str(p),'bytes':len(b),'sha256':sha(b),'blob':blob})
 assert subprocess.check_output(['git','write-tree'],text=True).strip()==tree
 assert not subprocess.check_output(['git','diff','--name-only'])
 return {'tree':tree,'canonicalIndexSha256':sha(staged),'count':len(rows),'bytes':sum(r['bytes'] for r in rows),'files':rows}
results=[];before=snapshot();(c/'union-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
for version in ['22.22.2','20.19.5']:
 assert shutil.disk_usage('.').free>256*1024**2
 assert snapshot()==before
 node=f'/Users/oleksandr.mekhovov/.local/share/mise/installs/node/{version}/bin/node';assert subprocess.check_output([node,'--version'],text=True).strip()=='v'+version
 cmd=[node,'--test','--test-concurrency=2',*tests];name='node'+version.split('.')[0];log=c/f'union-{name}.log';started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 print(f'START {name}: {len(tests)} whole files, tree {tree}',flush=True)
 with log.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 b=log.read_bytes();text=b.decode(errors='replace');summary={key:int(matches[-1]) for key in ['tests','pass','fail','cancelled','skipped','todo'] if (matches:=re.findall(r'^# '+key+r' (\d+)$',text,re.M))}
 after=snapshot();assert after==before;(c/f'union-inputs-after-{name}.json').write_text(json.dumps({'tree':after['tree'],'canonicalIndexSha256':after['canonicalIndexSha256'],'count':after['count'],'bytes':after['bytes'],'samePhysicalRowsAsBefore':True,'snapshotSha256':sha(json.dumps(after,sort_keys=True).encode())},indent=2)+'\n')
 record={'version':version,'argv':cmd,'startedAt':started,'elapsedSeconds':time.monotonic()-t,'exitCode':r.returncode,'log':{'path':str(log),'bytes':len(b),'sha256':sha(b)},'summary':summary,'inputPinsUnchanged':True,'tree':tree};results.append(record);(c/f'union-{name}.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
 if r.returncode:break
receipt={'status':'Complete whole-file pair passed' if len(results)==2 and all(r['exitCode']==0 for r in results) else 'Diagnostic; failed run retained and later runtime not started.','scope':'Bounded internal source composition; no full build/release/public/native acceptance.','tree':tree,'sourceHold':{'path':str(c.parent/'source-held-02.json'),'sha256':sha((c.parent/'source-held-02.json').read_bytes())},'testFiles':tests,'testFileCount':len(tests),'inputs':{'count':before['count'],'bytes':before['bytes'],'canonicalIndexSha256':before['canonicalIndexSha256'],'unchanged':True,'limit':'Finite materialized tracked inputs, not full dynamic import or dependency-package tracing.'},'results':results}
(c/'verification-union.json').write_text(json.dumps(receipt,indent=2)+'\n');print('SEALED',receipt['status'],flush=True)
sys.exit(0 if len(results)==2 and all(r['exitCode']==0 for r in results) else 1)
