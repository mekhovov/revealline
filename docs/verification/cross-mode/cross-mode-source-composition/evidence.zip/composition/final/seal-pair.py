from pathlib import Path
import json, hashlib, re, subprocess, shutil, datetime
c = Path('.cache/cross-mode-composition/final')
def pin(path):
    p = Path(path); b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
r = json.loads((c/'verification-union.json').read_text())
assert r['tree'] == 'def1186e23ca8ce668b362c0b001f2b039eb76e5'
assert r['testFileCount'] == 39 and len(set(r['testFiles'])) == 39
assert [x['version'] for x in r['results']] == ['22.22.2', '20.19.5']
for result in r['results']:
    assert result['exitCode'] == 0 and result['inputPinsUnchanged'] and result['tree'] == r['tree']
    assert pin(result['log']['path']) == result['log']
    raw = Path(result['log']['path']).read_text()
    actual = {key: int(re.findall(r'^# '+key+r' (\d+)$',raw,re.M)[-1]) for key in ['tests','pass','fail','cancelled','skipped','todo']}
    assert actual == result['summary'] == {'tests':760,'pass':760,'fail':0,'cancelled':0,'skipped':0,'todo':0}
    assert result['argv'][3:] == r['testFiles']
    after = json.loads((c/f"union-inputs-after-node{result['version'][:2]}.json").read_text())
    assert after['samePhysicalRowsAsBefore'] and after['tree'] == r['tree']
before = json.loads((c/'union-inputs-before.json').read_text())
for row in before['files']:
    actual = pin(row['path'])
    assert all(actual[key] == row[key] for key in actual), row['path']
index = subprocess.check_output(['git','ls-files','-s','-z'])
assert hashlib.sha256(index).hexdigest() == before['canonicalIndexSha256']
assert subprocess.check_output(['git','write-tree'],text=True).strip() == r['tree']
assert not subprocess.check_output(['git','diff','--name-only'])
files = [c/'verification-union.json', c/'run-union.py', c/'union-inputs-before.json', c/'union-inputs-after-node22.json', c/'union-inputs-after-node20.json', c/'union-node22.json', c/'union-node20.json', c/'union-node22.log', c/'union-node20.log', c.parent/'source-held-01.json', c.parent/'source-held-02.json', c.parent/'diagnostic-01.json', c.parent/'dynamic-input-hydration.json']
owned = sum(p.stat().st_size for p in Path('.').rglob('*') if p.is_file() and not p.is_symlink())
assert owned < 100*1024*1024 and shutil.disk_usage('.').free > 256*1024*1024
closure = {'status':'Final complete 39-file pair passed; raw summary and final physical/index reconciliation independently repeated.', 'at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'tree':r['tree'], 'testsPerRuntime':760, 'physicalInputCount':before['count'], 'physicalInputBytes':before['bytes'], 'canonicalIndexSha256':before['canonicalIndexSha256'], 'ownedBytes':owned, 'freeBytes':shutil.disk_usage('.').free, 'limits':'Internal source composition only; combined native pending, no full build, release, public or phase acceptance.', 'records':[pin(p) for p in files]}
(c/'closure.json').write_text(json.dumps(closure,indent=2)+'\n')
print(json.dumps({'closure':pin(c/'closure.json'),'verification':pin(c/'verification-union.json'),'ownedBytes':owned,'testsPerRuntime':760},indent=2))
