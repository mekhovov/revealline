# Confirmed Collection growth defect

Exactdef1186e,preview49355. Actual empty Collection→Flight records→Saves and loads→file chooser(pointerclick)→legal25record fixture import→Escape. After600ms settled: collection-records retains focus but y1849.8004,bottom1893.7935 exceeds1348 viewport; CollectionscrollTop0. Emptyopenerwasvisibley483.68. Rootvisuallyinspected01/03. Failureconfirmed; unchanged-contentrevisitpassingdoesnotresolvethisgrowthcase. Threeevents,twoJPGs. Noappstateinjection.
