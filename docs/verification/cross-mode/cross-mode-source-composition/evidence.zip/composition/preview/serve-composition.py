from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlsplit
from collections import OrderedDict
import subprocess, mimetypes, hashlib, json, os, threading, re, shutil, argparse

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--config', required=True)
parser.add_argument('--binding', required=True)
parser.add_argument('--config-sha256', required=True)
parser.add_argument('--qualification-sha256', required=True)
args = parser.parse_args()
if not all(re.fullmatch(r'[a-z0-9][a-z0-9.-]*', value) for value in (args.config, args.binding)):
    raise RuntimeError('Use direct owned filenames')
config_path = OUT / args.config
binding_path = OUT / args.binding
if config_path.is_symlink() or binding_path.exists():
    raise RuntimeError('Use a regular owned configuration and a fresh binding name')
config_bytes = config_path.read_bytes()
if hashlib.sha256(config_bytes).hexdigest() != args.config_sha256:
    raise RuntimeError('Reviewed configuration differs')
config = json.loads(config_bytes)
TREE = config['tree']
if not re.fullmatch('[0-9a-f]{40}', TREE):
    raise RuntimeError('Exact source tree required')
GIT_ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1')
def git(*argv):
    return subprocess.check_output(['git', '--no-optional-locks', *argv], cwd=ROOT,
                                   env=GIT_ENV, stderr=subprocess.DEVNULL)
if git('rev-parse', 'HEAD').decode().strip() != config['head']:
    raise RuntimeError('Composition checkout head differs')
if git('write-tree').decode().strip() != TREE or git('diff', '--name-only'):
    raise RuntimeError('Held index or physical source differs')
if git('rev-parse', TREE + '^{tree}').decode().strip() != TREE:
    raise RuntimeError('Exact tree unavailable')
if len(config['sourceIdentities']) != 5 or len(config['originalParents']) != 4:
    raise RuntimeError('Four original parents plus common-base provenance required')
if [row['commit'] for row in config['sourceIdentities'] if row['role'] != 'common-base'] != config['originalParents']:
    raise RuntimeError('Source identity roles differ')
for row in config['sourceIdentities']:
    if git('rev-parse', row['commit'] + '^{tree}').decode().strip() != row['tree']:
        raise RuntimeError('Original source identity differs')
    if row['role'] != 'common-base':
        subprocess.run(['git', 'merge-base', '--is-ancestor', config['commonBase'], row['commit']],
                       cwd=ROOT, env=GIT_ENV, check=True)
hold_path = OUT.parent / 'source-held-02.json'
hold_bytes = hold_path.read_bytes()
if hashlib.sha256(hold_bytes).hexdigest() != config['sourceHoldSha256']:
    raise RuntimeError('Reviewed hold differs')
qualification_path = OUT.parent / 'final/verification-union.json'
qualification_bytes = qualification_path.read_bytes()
if hashlib.sha256(qualification_bytes).hexdigest() != args.qualification_sha256:
    raise RuntimeError('Reviewed whole-file qualification differs')
qualification = json.loads(qualification_bytes)
if (qualification['tree'] != TREE or qualification['testFiles'] != config['testFiles']
        or qualification['testFileCount'] != 39 or not qualification['inputs']['unchanged']
        or qualification['sourceHold']['sha256'] != config['sourceHoldSha256']
        or [result['version'] for result in qualification['results']] != ['22.22.2', '20.19.5']):
    raise RuntimeError('Exact whole-file pair required')
for result in qualification['results']:
    summary = result['summary']
    if (result['exitCode'] != 0 or not result['inputPinsUnchanged'] or result['tree'] != TREE
            or not summary['tests'] or summary['tests'] != summary['pass']
            or any(summary[name] != 0 for name in ('fail', 'cancelled', 'skipped', 'todo'))):
        raise RuntimeError('Whole-file pair did not pass')
LIMIT = 64 * 1024 * 1024
if shutil.disk_usage(OUT).free < 256 * 1024 * 1024:
    raise RuntimeError('Insufficient metadata reserve')
regular = {}
for line in git('ls-tree', '-r', '-z', TREE).split(b'\0'):
    if not line:
        continue
    meta, name = line.split(b'\t', 1)
    mode, kind, oid = meta.decode().split()
    name = name.decode()
    if mode in ('100644', '100755') and kind == 'blob' and name.startswith(('game/', 'authoring/', 'docs/')):
        regular[name] = oid
cache = OrderedDict()
cache_bytes = 0
cache_lock = threading.Lock()
requests = threading.BoundedSemaphore(4)

def git_body(name):
    global cache_bytes
    with cache_lock:
        if name in cache:
            body = cache.pop(name)
            cache[name] = body
            return body
        oid = regular[name]
        size = int(git('cat-file', '-s', oid))
        if size > LIMIT:
            raise ValueError('Per-file limit')
        while cache and cache_bytes + size > LIMIT:
            _, old = cache.popitem(last=False)
            cache_bytes -= len(old)
        body = git('cat-file', 'blob', oid)
        if len(body) != size or hashlib.sha1(b'blob ' + str(size).encode() + b'\0' + body).hexdigest() != oid:
            raise ValueError('Git body identity mismatch')
        cache[name] = body
        cache_bytes += size
        return body

class Handler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.serve(False)
    def do_GET(self):
        self.serve(True)
    def serve(self, send_body):
        with requests:
            if self.headers.get('Host') != '127.0.0.1:' + str(self.server.server_port):
                self.send_error(403)
                return
            name = unquote(urlsplit(self.path).path).lstrip('/')
            if not name:
                self.send_response(302)
                self.send_header('Location', '/game/')
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            if name.endswith('/'):
                name += 'index.html'
            if '\\' in name or any(ord(ch) < 32 for ch in name) or any(part in ('.', '..', '.git', 'node_modules') for part in name.split('/')) or name not in regular:
                self.send_error(404)
                return
            try:
                body = git_body(name)
                length = len(body)
                start, end, status = 0, length - 1, 200
                requested = self.headers.get('Range')
                if requested:
                    match = re.fullmatch(r'bytes=(\d*)-(\d*)', requested)
                    if not match or not any(match.groups()):
                        raise ValueError('Invalid range')
                    low, high = match.groups()
                    if low:
                        start = int(low)
                        end = min(int(high), length - 1) if high else length - 1
                    else:
                        start = max(0, length - int(high))
                    if start > end or start >= length:
                        self.send_response(416)
                        self.send_header('Content-Range', 'bytes */' + str(length))
                        self.send_header('Content-Length', '0')
                        self.end_headers()
                        return
                    status = 206
                kind = 'text/javascript' if name.endswith('.mjs') else mimetypes.guess_type(name)[0] or 'application/octet-stream'
                self.send_response(status)
                self.send_header('Content-Type', kind)
                self.send_header('Content-Length', str(end - start + 1))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Accept-Ranges', 'bytes')
                if status == 206:
                    self.send_header('Content-Range', f'bytes {start}-{end}/{length}')
                self.end_headers()
                if send_body:
                    for offset in range(start, end + 1, 65536):
                        self.wfile.write(memoryview(body)[offset:min(offset + 65536, end + 1)])
            except (KeyError, ValueError, subprocess.CalledProcessError):
                self.send_error(404)
            except (BrokenPipeError, ConnectionResetError):
                pass
    def log_message(self, format, *args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
server.daemon_threads = True
binding = {'head': config['head'], 'tree': TREE,
           'sourceIdentities': config['sourceIdentities'],
           'originalParents': config['originalParents'],
           'pid': os.getpid(), 'port': server.server_port,
           'urls': {name: f'http://127.0.0.1:{server.server_port}' + route for name, route in
                    {'solo': '/game/', 'versus': '/game/couch/', 'team': '/game/couch/relay-rescue.html'}.items()},
           'gitBlobCacheBytes': LIMIT, 'maxConcurrentRequests': 4,
           'config': {'path': args.config, 'bytes': len(config_bytes),
                      'sha256': hashlib.sha256(config_bytes).hexdigest()},
           'qualification': {'path': str(qualification_path.relative_to(ROOT)),
                             'bytes': len(qualification_bytes),
                             'sha256': hashlib.sha256(qualification_bytes).hexdigest()},
           'mode': 'normal',
           'helperSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'scope': 'Every served byte is an original regular Git blob from the exact combined tree. No working-file overlays, application state, clock, delay or network-fault fixture. The four original parents and separate common base retain their provenance roles. LRU bounds stored Git blobs, not total process RSS.'}
with binding_path.open('x') as file:
    json.dump(binding, file, indent=2)
    file.write('\n')
print(json.dumps(binding), flush=True)
try:
    server.serve_forever()
finally:
    server.server_close()
