# Shared native file-button contrast candidate

Three-path source candidate on `628e95daf403082768cdcf900a8ea1d1ef4629a2`, isolated branch `codex/p05-file-control-contrast`. It is not a release or native/browser acceptance. No version, index staging, commit, push, browser launch, build or test suite was performed.

The shared `.field-kit input[type='file']::file-selector-button` recipe gives the native button explicit paired text/background tokens, inherited font, 44px minimum inline/block dimensions and existing spacing/border/corner tokens. Hover and active match shared controls. Both exclude `:disabled` and aria-disabled; the disabled rule therefore also covers a native disabled fieldset. The input, native chooser, filename, label and event handlers are unchanged. No proxy chooser or global native-appearance override was introduced.

The base shared selector (0,2,2) outranks Motion's legacy pale recipe (0,1,2) and Video Poster's native recipe (0,0,2), without `!important`. Motion's stronger later selector changes compatible minimum size/wrapping only. Enabled-state selectors cannot match a disabled fieldset-owned input. Existing input focus paint remains the focus owner; real computed/native behaviour still needs inspection.

Source-config Prettier, `git diff --check`, exact patch/preimage pins and reverse-apply checks pass. `contrast-calculations.json` derives ratios from the unchanged default token source: normal/hover text 13.5759:1; active 12.388:1; disabled 8.1711:1; normal boundary 3.3572:1. These are mathematical declared-colour pairs, not measured browser paint or every installed theme. No mirrored CSS tests were added.

The guide links the reviewed MDN pseudo-element reference and records the native qualification matrix. Check real Motion before/after, Video Poster, Asset Studio and dynamic Still Media inputs; Theme/Plain and Standard/Large, portrait/landscape, long filenames, normal/hover/active/focus, disabled fieldsets, native choose/cancel/accepted file, forced colours and zoom. Additional engines and physical input remain separate. The prior screenshot finding established Motion's pale native button in one recorded Chromium environment only.

The initial cache-directory creation refused because root's `base.json` already existed; no source or original evidence was overwritten. The existing root binding was retained and the new packet files use separate paths.
