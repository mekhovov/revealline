# Native file controls

P05 source candidate; actual browser verification remains pending.

Native file buttons can retain user-agent font and colour rules instead of inheriting input styling, so set their font and both colours explicitly. See [MDN’s file-selector-button reference](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Selectors/::file-selector-button).

The shared Field Kit component stylesheet pairs the native file button's text and background tokens, including hover, active and disabled states. Its minimum inline/block size is the existing 44px target token. Font inheritance preserves Theme/Plain and Standard/Large preferences; spacing and corners use existing tokens. The native input, visible filename, label, focus outline, accepted types and chooser/change handlers remain intact. No proxy button or new input behavior is added.

The shared selector outranks Motion's legacy pale button and Video Poster's local recipe without `!important`. Motion's more specific wrapping/geometry rule remains compatible. Disabled styling matches `:disabled`, including a disabled fieldset, and `aria-disabled`; enabled hover/active rules exclude both. ARIA styling does not implement disabled behavior for callers.

Before acceptance, compare Motion's real Choose File button before/after in Theme/Plain × Standard/Large, portrait and short landscape. Record computed pseudo-element colours, target dimensions, focus and filename visibility, including a long filename. Check normal/hover/active, keyboard chooser open/cancel, a real supported local file and the loading fieldset. Recheck Video Poster, Asset Studio and one dynamic Still Media input. Include forced colours, zoom and additional engines during the wider P05 matrix. The OS chooser itself is outside page CSS.

Source-token contrast calculations describe declared colours only. They cannot establish inherited native pseudo-element paint, viewport fit, chooser behavior or physical touch/controller acceptance. No CSS-string mirror test substitutes for that browser evidence. Preserve bounded media validation, state ownership, exact originals and focus/cancellation behavior in all consumers.
