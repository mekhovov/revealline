import fs from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { importThemeBundle } from '/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/p05-media-controls-v0611/game/presentation/bundle.mjs';
import { canonicalJSON } from '/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/p05-media-controls-v0611/game/data-json.mjs';
const wt="/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/p05-media-controls-v0611", out="/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/p05-media-controls-production-fc2c7af6", source='fc2c7af6b22c703cc3bb2c081579878b7510f667';
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const old = (path) => execFileSync('git', ['show', `${source}:${path}`], { cwd: wt, env: { ...process.env, GIT_NO_LAZY_FETCH: '1' }, maxBuffer: 16 * 1024 * 1024 });
const ledger='authoring/library/fpv-field-kit/production.rltheme';
const beforeBytes=old(ledger), afterBytes=await fs.readFile(`${wt}/${ledger}`);
const before=await importThemeBundle(new Blob([beforeBytes]), { decodeImage:null });
const after=await importThemeBundle(new Blob([afterBytes]), { decodeImage:null });
const groupPrefixes={};
for (const group of ['assets','collections','slots','themes']) {
 assert.equal(canonicalJSON(after.document[group].slice(0,before.document[group].length)),canonicalJSON(before.document[group]),group);
 groupPrefixes[group]={prior:before.document[group].length,current:after.document[group].length,prefixExact:true};
}
for (const k of Object.keys(before.document)) if (!['assets','themes','revision','selection'].includes(k)) assert.equal(canonicalJSON(after.document[k]),canonicalJSON(before.document[k]),k);
assert.equal(before.document.revision,27); assert.equal(after.document.revision,28);
assert.deepEqual(after.document.selection,{...before.document.selection,theme:{id:'fpv',revision:28}});
assert.equal(before.assets.size,127); assert.equal(after.assets.size,before.assets.size);
const payloads=[];
for (const [hash,blob] of before.assets) {
 const prior=Buffer.from(await blob.arrayBuffer()), next=Buffer.from(await after.assets.get(hash).arrayBuffer());
 assert.ok(prior.equals(next),hash); assert.equal(sha(prior),hash);
 payloads.push({sha256:hash,bytes:prior.length});
}
const appendedAssets=after.document.assets.slice(before.document.assets.length).map(a=>({id:a.id,revision:a.revision,parent:a.provenance.parent}));
const ui=new Set(after.document.slots.filter(s=>s.group==='ui').map(s=>`${s.id}.field-kit`));
assert.ok(appendedAssets.length>0); for (const a of appendedAssets) assert.ok(ui.has(a.id),a.id);
const themeCss='game/presentation/compiled/theme.css'; assert.ok(old(themeCss).equals(await fs.readFile(`${wt}/${themeCss}`)));
const manifest=JSON.parse(await fs.readFile(`${wt}/game/presentation/compiled/manifest.json`));
assert.deepEqual(manifest.source,{id:'field-kit',revision:28}); assert.equal(manifest.files.length,130);
for (const f of manifest.files) {const b=await fs.readFile(`${wt}/game/presentation/compiled/${f.path}`);assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256);if(f.path.startsWith('assets/'))assert.ok(old(`game/presentation/compiled/${f.path}`).equals(b));}
const bindingPath='game/couch/coop-picture-bindings.mjs',bindingPrior=old(bindingPath).toString(),bindingCurrent=await fs.readFile(`${wt}/${bindingPath}`,'utf8');
assert.equal(bindingPrior.split('themeRevision: 27,').length-1,2);assert.equal(bindingCurrent,bindingPrior.replaceAll('themeRevision: 27,','themeRevision: 28,'));
const compiled=JSON.parse(await fs.readFile(`${wt}/game/presentation/compiled/runtime.json`));
const compiledPrior=JSON.parse(old('game/presentation/compiled/runtime.json'));
for(const slot of ['scene.reveal.wide','picture.fpv.adf5c9eea274ba7f']) assert.equal(canonicalJSON(compiled.resolved.assets[slot]),canonicalJSON(compiledPrior.resolved.assets[slot]),slot);
const report={status:'PASS_APPEND_ONLY_AND_EXACT_ARTWORK_PRESERVATION',source,oldLedger:{bytes:beforeBytes.length,sha256:sha(beforeBytes),revision:27},newLedger:{bytes:afterBytes.length,sha256:sha(afterBytes),revision:28},groupPrefixes,originalPayloads:payloads.length,originalPayloadBytes:payloads.reduce((n,p)=>n+p.bytes,0),allOriginalPayloadsByteExact:true,appendedAssets,compiledFiles:manifest.files.length+1,themeCssExact:true,teamBindings:{onlyTwoRevisionValuesChanged:true,from:27,to:28,exactPictureRecordsUnchanged:true},limits:'Source/bundle preservation and modeled gates only; no new browser or public acceptance.'};
await fs.writeFile(`${out}/preservation-review.json`,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
await fs.writeFile(`${out}/original-payload-pins.json`,JSON.stringify(payloads,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report));
