# P03 next slice: Library row focus

Source-only design at d0925c00518f0be6da0a3ea565112fee106dc8eb. No source, test or index edits and no execution/native observation. Exact inspected file pins are in library-row-focus-review.json. The final held04 connected-opener correction remains unchanged and accepted only to its documented scope.

## Concrete source boundaries

- `game/ui/library-panel.mjs:302–347` clears `#installed-packs` and recreates all Play/Remove controls on every refresh. Rows have no stable action IDs or data keys today. Remove begins a Library task at334; its own successful body refreshes at339, and `releaseTask` always refreshes again at516. Thus both successful removal and a rejected write disconnect the initiating Remove button. The held04 helper correctly refuses that dead target at `game/ui/operation-focus.mjs:64`.
- **Remove is already committing before its first await** (`library-panel.mjs:336–337`). There is no genuine cancel-before-commit removal journey in the current UI. Its pending control becomes Stop waiting, and520–531 deliberately detach without rollback or focus restoration. Preserve that distinction.
- Actual pack writes stay with `game/app.mjs:3118–3190`: writer/currentness checks, storage commit, checked reload and reconciliation. A failed pre-write commit retains previous packs at3151–3153; a later failure must not be presented as rollback. Determine a logical focus destination from the actual current pack model, not merely whether the task promise fulfilled. Removing the active pack may already select Base at3164–3169; this focus slice must neither alter that existing behavior nor claim that removal preserves the active flight.
- Builtin Install controls are appended once (`library-panel.mjs:879`) and are not rebuilt by refresh. Their positive held04 completion/Cancel paths are not this gap. Installed Play uses the separate R3 launch owner at311–328 and closes Library only after adoption; do not turn focus repair into another launch, reroute, or weakened currentness guard.

## Recommended small implementation

Scope only installed-pack Remove completion/error focus, with stable internal row/action keys assigned during rendering. Capture `{packId, packVersion, action:remove}` plus the original visible row order, Library visit/task identity and actual opener before disabling it. Keys select a DOM control only; they grant no content/adoption authority.

Resolve once after the final refresh and control reenable, against one captured current pack-list/render generation. Recheck that same model/generation after resolution before focusing. Use this exact order:

| Actual outcome | Logical destination in the still-open Expansion packs section |
| --- | --- |
| The same pack/version remains, including a refused write | Its recreated Remove from device control, so the error can be understood and retried. |
| The selected pack is absent after a completed removal | First Play in the next surviving row from the captured order; otherwise first Play in the previous surviving row. Focus never activates Play. |
| No captured neighboring row survives, or a same-ID pack was replaced with a different version | Existing `[data-library-panel="packs"]` button in `#library-dialog`. This stable, non-destructive section destination also handles the final installed pack. |
| Stop waiting during committed removal | Keep current detached behavior: no automatic return or rollback claim after settlement. |
| Existing precommit Cancel of builtin/file install | Keep held04's fresh actual-focused-Cancel lease and original connected opener; no policy change. |

Refuse the entire handoff after a newer focus/input choice, another dialog, changed Library visit/section, true Window blur, hidden/pagehide, closure/reopen or a superseded task. Do not choose a fallback just because focus is BODY. The permission to focus must still come from the live original operation lease. Return to Close Library, another panel, the document root, or a newly opened dialog is not an implicit fallback.

A small **internal** optional logical-target resolver can support this, defaulting to the existing immutable `restoreTo` behavior. It must be synchronous and code-owned, only evaluated while the lease is still live, and followed by a second ownership/foreground/same-root/connected/visible/enabled check. Consume the lease before calling focus. This avoids resurrecting a retired lease or allowing a reentrant renderer callback to steal focus. No persistent record, profile schema, content format, hint version or public/versioned API is needed. Keep the existing held04 API/default and all27 cases unchanged; only the explicit Remove adapter opts in. Do not introduce a general selector or callback supplied by imported content.

## Required acceptance for that slice

Use actual Library handlers and tiny prepared packs, modeling removal/disabling blur. Cover removal from a middle row, last row, sole row, a write failure with the pack still present, and an error after the model has already changed. Assert exact target identity, not non-BODY only. Prove the fallback never invokes Play or changes storage by itself. Verify the selected pack's real removal/storage result separately from focus.

Exercise a pending committed removal with Stop waiting; completion must remain detached. Retain the existing three-Tab install Cancel positive and no-steal cases. Add deliberate focus then BODY, close/reopen, section switch, new modal, true blur/hidden/pagehide, newer pack model, and reentrant target-resolution/cleanup focus guards. Preserve exact writer/currentness and R3 launch assertions. A minimal affected whole-file set is operation-focus-host, library-launch-host and modal-navigation, plus a new focused row case file if useful; add packs/storage tests only if their production boundary changes, which this design does not require.

Native gate: keyboard Remove on a non-active middle pack, sole-pack removal, pending Tab-away and Stop waiting. A controlled refused write is host evidence unless the browser provides a truthful reproducible failure; do not fabricate browser storage success/failure. Preserve the current held04 normal chapter/install/Cancel/no-steal journeys. This is a new candidate qualification, not acceptance derived from d092's188 tests or9 native events.

## Adjacent findings kept separate

`library-panel.mjs:211–232,271–274` replaces Score Previous/Next buttons during their own activation. Its `hadPagerFocus` fallback only handles a collapsed Gallery pager, not the ordinary Score or Gallery Next/Previous replacement. That is a separate pagination slice. First consider retaining the existing Previous/Next DOM controls and updating their page/count/callback state. Only a focused action becoming disabled or disappearing would need a logical fallback. Gallery may await pictureMedia, so any automatic handoff needs asynchronous ownership: preserve the equivalent enabled pager control, otherwise its other direction, otherwise the corresponding search field in the same dialog, without a later focus/input/foreground decision during delayed metadata. Gallery view-close already has a keyed `galleryReturn` path at1334–1362; retain it. No pager implementation is included in the current source hold.

Undo library/game-data buttons remain connected but become disabled after success (793–804 and757–768); they are a different logical-destination case, not installed row recreation. Profile-transfer source options are rebuilt, but the select and action buttons remain connected (profile-transfer-panel.mjs:67–97); do not claim the installed-row remedy covers that separate flow. Backup-set links have their own prepare/cancel/return ownership (backup-set-panel.mjs:60–100). None is a reason to widen this first Remove slice or modify P01 operation contracts.
