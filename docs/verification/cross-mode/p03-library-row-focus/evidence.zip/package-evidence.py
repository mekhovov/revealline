from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
CACHE = Path(__file__).resolve().parent
DEST = ROOT / 'docs/verification/cross-mode/p03-library-row-focus'
if shutil.disk_usage(ROOT).free < 256 * 1024 * 1024:
    raise RuntimeError('Insufficient metadata reserve')

names = [
    'admission.json', 'design.md', 'source-held-01.json', 'source-held-01.diff',
    'source-held-final.json', 'verification-tests.json', 'native-verification.json',
    'row-host-first-source.mjs', 'row-host-01-node22.log', 'row-host-01-node22.json',
    'row-host-02-node22.log', 'row-host-02-node22.json', 'first-run-diagnosis.md',
    'row-host-final-hold.json', 'row-host-final-format.log', 'row-host-final-lint.log',
    'source-format.log', 'source-lint.log', 'static-source.json',
    'format-baseline-diagnostic.json', 'run-final-pair.py',
    'serve-row-focus.py', 'preview-config.json', 'preview-normal.json',
    'preview-http-normal.json', 'post-native-http.json', 'preview-helper-reuse.diff',
    'prior-preview-helper.py', 'preview-helper-provenance.json', 'package-evidence.py',
]
names += [str(p.relative_to(CACHE)) for folder in ['final-pair', 'native-root'] for p in sorted((CACHE / folder).iterdir()) if p.is_file()]
if len(names) != len(set(names)):
    raise RuntimeError('Duplicate evidence member')
if sum((CACHE / name).stat().st_size for name in names) > 10 * 1024 * 1024:
    raise RuntimeError('Evidence input budget exceeded')

def pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

archive = DEST / 'evidence.zip'
rows = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name in names:
        path = CACHE / name
        body = path.read_bytes()
        output.writestr(name, body)
        rows.append({'source': str(path.relative_to(ROOT)), 'member': name, **pin(body)})
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert len(check.namelist()) == len(set(check.namelist())) == len(rows)
    for row in rows:
        assert check.read(row['member']) == (ROOT / row['source']).read_bytes()
mapping = {
    'format': 'revealline.p03-library-row-focus-evidence.v1',
    'base': 'd0925c00518f0be6da0a3ea565112fee106dc8eb',
    'tree': '02342b700c7d9fe7f2f1145161b66d7c8c04b62c',
    'scope': 'Two production modules, four complete test files on both Node runtimes and scoped desktop successful-removal journeys. No phase/public/device qualification.',
    'automated': {'completeFiles': 4, 'perRuntime': 108, 'newCases': {'soloApp': 10, 'libraryPanelModel': 6, 'helper': 7}, 'predecessorsAreNotAdditive': True},
    'native': {'events': 8, 'pngs': 4, 'scope': 'Middle/last/sole successful keyboard removal and nested Back; First Signal remains Ready.', 'hostOnly': ['failure', 'changed version/model', 'detached Stop waiting', 'newer focus and background refusal']},
    'archive': {'path': 'evidence.zip', **pin(archive.read_bytes())},
    'files': rows,
}
with (DEST / 'evidence.json').open('x') as output:
    json.dump(mapping, output, indent=2)
    output.write('\n')
print(json.dumps({'members': len(rows), 'originalBytes': sum(row['bytes'] for row in rows), 'archive': mapping['archive']}))
