# Final P03 native preview preparation

Not launched. `preview-config.template.json` intentionally has null head/tree. After root supplies final composed M identity, create a new `preview-config.json` with those exact full values. All served bytes come from that Git commit; there are no runtime overlays or copied source/media trees.

The helper reuses the reviewed Title-M Git regular-file routing and byte-range code. It binds a fresh localhost port, uses a 64 MiB Git-blob LRU and four transfer slots, and reads Git only for requested files under game/authoring/docs. Each member is at most 64 MiB. The cache bound is not total process RSS. The normal origin has no delay. A separate optional delayed origin adds exactly six seconds before each GET body of `game/content/campaign.json`, leaving its original bytes unchanged. It does not modify app state, game clocks, timers inside the app, storage or controller input. Each origin records its own exclusive binding and actual PID/port; do not reuse prior previews.

After root-authorized final launch, commands use fresh output names:

```
python3 .cache/p03-final-qualification/serve-preview.py --config preview-config.json --mode normal --binding preview-normal-binding.json
python3 .cache/p03-final-qualification/serve-preview.py --config preview-config.json --mode delayed --binding preview-delayed-binding.json
```

Run each server in its own managed terminal session. Once a binding exists, `check-preview.py --binding preview-normal-binding.json --out preview-normal-http.json` (same cache directory path for the script) checks 17 exact small production/JSON paths, including all three entry documents, shared mode/navigation/return owners and both Couch hosts. It compares status, final URL, MIME, size and SHA to exact Git bytes; it retains metadata only. Repeat against the separately bound delayed origin if root chooses it. HTTP checks are pending until those actual servers exist. Root owns all native actions and their qualified scope.

`preview-predecessor.json` pins the reused M helper. `preview-preparation.json` pins these new scripts/template/instructions. Python syntax was compiled without importing or executing them. No server or HTTP request was started during this preparation.
