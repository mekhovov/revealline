"""Bounded Git-only preparation; does not execute product code or change the index."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, posixpath, re, shutil, subprocess
ROOT = Path(__file__).resolve().parents[2]
CACHE = Path(__file__).resolve().parent
BASE = '183e0aff9975d5e92b4001cc1292b6ae51db2850'
FLOOR = 256 * 1024 * 1024
CAP = 8 * 1024 * 1024
NAMES = '''title-entry-host title-operation-status-host title-mode-departure-host
library-launch-host mission-replacement-host starting-setup-host restart-navigation-host
course-selection-host mode-return mode-return-v2 mode-return-host couch-shell
couch-navigation couch-departure couch-input couch-markup coop-host controller-navigation
menu-initial-focus modal-navigation modal-tab-boundary victory-story-ui terminal-navigation
couch-initial-focus coop-input-policy initial-focus-host pause-menu-host
nonmodal-header-navigation flight-pictures-host difficulty-host mission-picker
storage-retention-host storage-retention field-kit-flow'''.split()
TESTS = ['game/test/' + n + '.test.mjs' for n in NAMES]

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def sha(raw): return hashlib.sha256(raw).hexdigest()
def write(path, value):
    with path.open('x') as stream: json.dump(value, stream, indent=2); stream.write('\n')

def tree(head):
    rows = {}
    for line in git('ls-tree', '-r', '-l', head).decode().splitlines():
        meta, path = line.split('\t'); mode, kind, oid, size = meta.split()
        if kind == 'blob' and mode in ('100644', '100755'):
            rows[path] = {'path': path, 'gitBlob': oid, 'mode': mode, 'bytes': int(size)}
    return rows

def prepare(head, materialize=False, m_commit=None):
    if not re.fullmatch('[0-9a-f]{40}', head): raise RuntimeError('Full exact head required')
    if git('rev-parse','HEAD').decode().strip() != head: raise RuntimeError('Current HEAD differs')
    subprocess.run(['git','merge-base','--is-ancestor',BASE,head],cwd=ROOT,check=True)
    if git('diff','--name-only') or git('diff','--cached','--name-only'):
        raise RuntimeError('Tracked edits/index changes must be resolved by owner first')
    if m_commit:
        if not re.fullmatch('[0-9a-f]{40}', m_commit): raise RuntimeError('Full M commit required')
        subprocess.run(['git','merge-base','--is-ancestor',m_commit,head],cwd=ROOT,check=True)
    rows=tree(head); data={}
    def raw(p):
        if p not in data:
            if rows[p]['bytes'] > 16*1024*1024: raise RuntimeError('Unexpected large input: '+p)
            data[p]=git('cat-file','blob',rows[p]['gitBlob'])
        return data[p]
    # Conservative existing finite runtime/data envelope, plus actual tests and
    # transitive local text references. This is a superset, not runtime tracing.
    paths={p for p in rows if (ROOT/p).is_file() and
           ((p.startswith('game/') and ('/test/' not in p or '/test/helpers/' in p or '/test/fixtures/' in p)) or
            p.startswith('authoring/motion-lab/') or p in ('package.json','package-lock.json'))}
    prior=ROOT.parent/'p03r5-ready-focus/.cache/r5-adaptation/execution-inputs.json'
    if prior.is_file():
        paths |= {r['path'] for r in json.loads(prior.read_text())['paths']
                  if r['path'] in rows and (r['path'].startswith('game/') or r['path'].startswith('authoring/motion-lab/'))
                  and ('/test/' not in r['path'] or '/test/helpers/' in r['path'] or '/test/fixtures/' in r['path'])}
    pending=[p for p in TESTS if p not in rows]
    if m_commit and pending: raise RuntimeError('Final tests absent: '+str(pending))
    paths |= set(TESTS)-set(pending)
    todo=list(paths); seen=set()
    while todo:
        p=todo.pop()
        if p in seen: continue
        seen.add(p)
        if PurePosixPath(p).suffix not in ('.mjs','.js'): continue
        text=raw(p).decode('utf8')
        for value in re.findall(r'''["'`]([^"'`\n]+\.(?:mjs|js|json|html|css|mp3|txt)(?:\?[^"'`\n]*)?)["'`]''', text):
            value=value.split('?')[0]
            if '${' in value or ':' in value or '\\' in value: continue
            candidates=[posixpath.normpath(posixpath.join(posixpath.dirname(p),value)),
                        posixpath.normpath('game/'+value), value]
            for q in candidates:
                if q == 'authoring/library/fpv-route-choices/packs/fpv-route-choices.json':
                    # Optional chapter chooser URL, not read by this finite test set.
                    # No HTML navigation or optional full pack is materialized.
                    continue
                if q in rows:
                    if q not in paths: paths.add(q);todo.append(q)
                    break
    missing=[]; pins=[]
    for p in sorted(paths):
        b=raw(p); r={**rows[p],'sha256':sha(b)}; pins.append(r)
        target=ROOT/p
        if target.exists():
            if target.is_symlink() or target.read_bytes()!=b: raise RuntimeError('Existing input differs; preserved: '+p)
        else: missing.append(r)
    required=sum(r['bytes'] for r in missing)
    if materialize and (required > CAP or shutil.disk_usage(ROOT).free < FLOOR+required):
        raise RuntimeError('Bounded materialization/reserve exceeded: '+str(required))
    index=Path(git('rev-parse','--git-path','index').decode().strip())
    if not index.is_absolute(): index=ROOT/index
    index_before=sha(index.read_bytes())
    if materialize:
        for r in missing:
            p=ROOT/r['path'];p.parent.mkdir(parents=True,exist_ok=True)
            with p.open('xb') as stream: stream.write(raw(r['path']))
            if r['mode']=='100755': p.chmod(0o755)
        for r in pins:
            if sha((ROOT/r['path']).read_bytes())!=r['sha256']: raise RuntimeError('Post-intake input mismatch')
    if sha(index.read_bytes())!=index_before: raise RuntimeError('Index changed during preparation')
    if git('rev-parse','HEAD').decode().strip()!=head: raise RuntimeError('HEAD changed during preparation')
    result={'format':'revealline-p03-targeted-preparation.v1','head':head,
            'tree':git('rev-parse',head+'^{tree}').decode().strip(),'mCommit':m_commit,
            'executionAuthorized':False,'tests':TESTS,'pendingTests':pending,
            'inputScope':'Conservative finite runtime/data envelope plus transitive local text references; not a dynamic read trace.',
            'inputs':pins,'inputCount':len(pins),'inputBytes':sum(r['bytes'] for r in pins),
            'missingBefore':missing,'materialized':materialize,'materializedBytes':required if materialize else 0,
            'indexSha256Unchanged':index_before,'freeBytesAfter':shutil.disk_usage(ROOT).free,
            'reserveBytes':FLOOR,'newInputCapBytes':CAP}
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--head',required=True)
    parser.add_argument('--m-commit');parser.add_argument('--materialize',action='store_true')
    parser.add_argument('--out',required=True);a=parser.parse_args()
    out=CACHE/a.out
    if out.parent!=CACHE or out.exists(): raise RuntimeError('Use new direct cache output name')
    result=prepare(a.head,a.materialize,a.m_commit);write(out,result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('inputs','missingBefore','tests')}))
    print(json.dumps({'missingBefore':result['missingBefore']}))
