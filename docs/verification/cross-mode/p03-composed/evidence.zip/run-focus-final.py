"""Explicit final-source gate. Preparation manifests cannot execute until M is bound."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, re, selectors, shutil, signal, subprocess, time
ROOT=Path(__file__).resolve().parents[2]
CACHE=Path(__file__).resolve().parent
FLOOR=256*1024*1024
LOG_CAP=8*1024*1024
NODE_ROOT=Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node')

def git(*args): return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT).decode().strip()
def digest(path):
    h=hashlib.sha256(); size=0
    with path.open('rb') as stream:
        while block:=stream.read(1024*1024): h.update(block);size+=len(block)
    return {'path':str(path),'bytes':size,'sha256':h.hexdigest()}
def write(path, value):
    with path.open('x') as stream: json.dump(value,stream,indent=2);stream.write('\n')
def input_pins(manifest):
    out=[]
    for row in manifest['inputs']:
        path=ROOT/row['path']
        if not path.is_file() or path.is_symlink(): raise RuntimeError('Missing/nonregular input: '+row['path'])
        pin=digest(path);pin['path']=row['path'];out.append(pin)
    return out

def terminate(proc):
    if proc.poll() is None:
        os.killpg(proc.pid,signal.SIGTERM)
        try: proc.wait(timeout=5)
        except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=5)

def execute(command, out):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
    reason=None;written=0;next_progress=clock+30
    with out.open('xb') as log:
        proc=subprocess.Popen(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                              start_new_session=True,bufsize=0)
        selector=selectors.DefaultSelector();selector.register(proc.stdout,selectors.EVENT_READ)
        try:
            while selector.get_map():
                now=time.monotonic()
                if now-clock>1800: reason='Thirty-minute command bound exceeded';terminate(proc)
                if shutil.disk_usage(ROOT).free<FLOOR: reason='Metadata reserve breached';terminate(proc)
                for key,_ in selector.select(timeout=1):
                    raw=os.read(key.fileobj.fileno(),65536)
                    if not raw: selector.unregister(key.fileobj);continue
                    if written+len(raw)>LOG_CAP:
                        keep=max(0,LOG_CAP-written);log.write(raw[:keep]);written+=keep
                        reason='8 MiB log bound exceeded; original retained prefix is explicitly incomplete'
                        terminate(proc)
                    else: log.write(raw);written+=len(raw)
                if now>=next_progress:
                    print(json.dumps({'running':out.name,'seconds':round(now-clock,1),'logBytes':written}),flush=True)
                    next_progress=now+30
            code=proc.wait(timeout=5)
        finally:
            terminate(proc);selector.close();proc.stdout.close()
    raw=out.read_text(errors='replace');summary={}
    for line in raw.splitlines():
        match=re.match(r'^(?:#|ℹ) (tests|suites|pass|fail|cancelled|skipped|todo|duration_ms) (.+)$',line)
        if match: summary[match[1]]=match[2]
    clean=code==0 and reason is None and int(summary.get('tests','0'))>0
    clean=clean and all(summary.get(k)=='0' for k in ('fail','cancelled','skipped','todo'))
    clean=clean and summary.get('tests')==summary.get('pass')
    return {'command':command,'startedAt':started,'elapsedSeconds':time.monotonic()-clock,
            'exitCode':code,'boundedFailure':reason,'logComplete':reason is None,
            'log':digest(out),'rawSummary':summary,'passed':clean}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--manifest',required=True)
    parser.add_argument('--approved-head',required=True);parser.add_argument('--m-commit',required=True)
    parser.add_argument('--out',required=True);a=parser.parse_args()
    # These explicit pins are operator input only after root notification; never
    # infer authorization from time, an existing commit or earlier package tests.
    manifest_path=CACHE/a.manifest
    if manifest_path.parent!=CACHE: raise RuntimeError('Manifest must be a direct owned cache file')
    manifest=json.loads(manifest_path.read_text())
    if manifest['pendingTests'] or not manifest['mCommit']: raise RuntimeError('M integration remains unbound')
    if manifest['head']!=a.approved_head or manifest['mCommit']!=a.m_commit:
        raise RuntimeError('Explicit final authority differs from preparation')
    if not all(re.fullmatch('[0-9a-f]{40}',v) for v in (a.approved_head,a.m_commit)):
        raise RuntimeError('Full authority hashes required')
    subprocess.run(['git','merge-base','--is-ancestor',a.m_commit,a.approved_head],cwd=ROOT,check=True)
    tests=json.loads((CACHE/'test-list-focus-final.json').read_text())['tests']
    if manifest['tests']!=tests or len(set(tests))!=len(tests): raise RuntimeError('Whole file list changed')
    expected=[{k:r[k] for k in ('path','bytes','sha256')} for r in manifest['inputs']]
    if not set(tests)<=set(r['path'] for r in expected): raise RuntimeError('A whole test file lacks an input pin')
    index=Path(git('rev-parse','--git-path','index'))
    if not index.is_absolute():index=ROOT/index
    index_pin=digest(index)
    authority_files=[manifest_path,CACHE/'prepare-focus-final.py',Path(__file__),CACHE/'test-list-focus-final.json']
    authority_pins=[digest(p) for p in authority_files]
    if os.environ.get('NODE_OPTIONS') or os.environ.get('NODE_PATH'):
        raise RuntimeError('Unreviewed Node environment overrides')
    def guard():
        if git('rev-parse','HEAD')!=a.approved_head or git('rev-parse','HEAD^{tree}')!=manifest['tree']:
            raise RuntimeError('HEAD/tree changed')
        if git('diff','--name-only') or git('diff','--cached','--name-only'):
            raise RuntimeError('Tracked source/index differs')
        if digest(index)!=index_pin: raise RuntimeError('Index bytes changed')
        if input_pins(manifest)!=expected: raise RuntimeError('Input pins changed')
        if [digest(p) for p in authority_files]!=authority_pins: raise RuntimeError('Runner authority changed')
        if shutil.disk_usage(ROOT).free<FLOOR+2*LOG_CAP: raise RuntimeError('Insufficient metadata reserve')
    guard()
    target=CACHE/a.out
    if target.parent!=CACHE: raise RuntimeError('Use a fresh direct cache run name')
    target.mkdir(exist_ok=False)
    write(target/'inputs-before.json',{'paths':expected,'head':a.approved_head,'tree':manifest['tree']})
    write(target/'runner-authority.json',{'files':authority_pins,'index':index_pin,'concurrency':2,
          'wholeTestFiles':tests,'mCommit':a.m_commit,'sourceOnlyScope':True})
    runs=[]
    try:
        for label,version in [('node22','22.22.2'),('node20','20.19.5')]:
            guard();node=NODE_ROOT/version/'bin/node';node_pin=digest(node)
            runtime=subprocess.check_output([str(node),'--version'],text=True).strip()
            if runtime!='v'+version: raise RuntimeError('Unexpected Node runtime')
            command=[str(node),'--test','--test-concurrency=2','--test-reporter=tap',*tests]
            row=execute(command,target/(label+'.log'));row['runtime']=runtime;row['runtimeBinary']=node_pin
            # Preserve full post-input identities even if the command failed.
            after=input_pins(manifest);write(target/(label+'-inputs-after.json'),{'paths':after})
            row['inputPinsUnchanged']=after==expected
            row['runtimeBinaryUnchanged']=digest(node)==node_pin
            runs.append(row);write(target/(label+'-result.json'),row)
            guard()
            if not row['passed'] or not row['runtimeBinaryUnchanged']: break
        write(target/'completion.json',{'head':a.approved_head,'tree':manifest['tree'],'mCommit':a.m_commit,
              'runs':runs,'passed':len(runs)==2 and all(r['passed'] and r['inputPinsUnchanged'] for r in runs),
              'qualificationScope':'One combined targeted whole-file pair only; full hosted/native/public gates remain separate.'})
    except BaseException as error:
        write(target/'failure.json',{'type':type(error).__name__,'message':str(error),'completedRuns':len(runs)})
        raise
    passed=len(runs)==2 and all(r['passed'] and r['inputPinsUnchanged'] and r['runtimeBinaryUnchanged'] for r in runs)
    print(json.dumps({'out':str(target),'runs':len(runs),'passed':passed}),flush=True)
    if not passed: raise SystemExit(1)

if __name__=='__main__':main()
