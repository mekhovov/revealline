# Final P03 targeted gate preparation

Prepared against `183e0aff9975d5e92b4001cc1292b6ae51db2850`, tree `9aa78f574229c5d53cc8ad1d3190b7f64efd1214`. This is an execution plan and finite input intake, not a test result. M has passed its separate candidate pair but is not yet committed/composed in this authority. Root must supply the actual integrated head and M commit before execution.

`test-list.json` contains 33 distinct complete test files: 32 verified in current Git, plus the owner's actual incoming `game/test/title-mode-departure-host.test.mjs`. The actual existing `modal-navigation.test.mjs` remains in this list and will be pinned again from the final M composition. No test-name filters or sums of prior candidate counts are used. The extra whole initial-focus, header/pause, picture preparation, difficulty/mission picker, Team input-policy and storage-retention files cover the shared readiness, modal and actual save-owner boundaries used by the approved gate.

`admission-materialized.json` records 280 finite input pins / 15,535,098 bytes, including conservative existing runtime/data dependencies. It restored only 29 absent exact HEAD leaves / 556,110 bytes with exclusive file creation. Existing bytes were preserved; the Git index SHA stayed `2ddb6d9e06210ab73c96d7e78c062768dce8801abb104a4fce41ebd690d38d83`. The record contains every restored path, Git blob, size and SHA. Remaining free space was 934,170,624 bytes, above the 256 MiB metadata reserve. No sparse configuration, index, source content, docs or node_modules was changed.

Discovery is a conservative local text-reference inventory, not dynamic filesystem tracing. The first discovery followed browser HTML links and proposed unrelated pages/vendor input. A second identified an 11.95 MB optional chapter path constant in `game/optional-chapters.mjs:64–66`. That constant validates a catalogue pathname; these selected host tests do not load that optional full pack. Both discovery records and the initial cap refusal description are retained. The final intake follows JavaScript references and existing finite inputs only; it does not follow HTML navigation or materialize the optional authoring pack, archives, full site or browser media. Ordinary tiny generated fixture bytes are produced only when the tests eventually execute.

## Final binding and execution

After root explicitly supplies the final composed head and M source commit, run preparation once with those full exact values. Use a new output name; preparation refuses any existing destination, tracked edits, mismatched existing leaf, nonancestor M, missing final whole test or insufficient reserve. It reads the final Git tree again, so it cannot reuse the earlier M/base authority accidentally.

```
python3 .cache/p03-final-qualification/prepare.py --head FINAL_COMPOSED_SHA --m-commit ACTUAL_M_SHA --materialize --out final-inputs.json
python3 .cache/p03-final-qualification/run-pair.py --manifest final-inputs.json --approved-head FINAL_COMPOSED_SHA --m-commit ACTUAL_M_SHA --out run-final-01
```

The current preparation has `mCommit: null` and a pending title-mode test, so the runner refuses it. The explicit CLI authority is supplied only after root notification; neither the presence of a commit nor an old passing package authorizes a run. A final cherry-pick may use the integrated M commit; do not substitute an unrelated side-branch commit that is not an ancestor of final HEAD.

The runner executes Node 22.22.2 then Node 20.19.5, each with `--test --test-concurrency=2 --test-reporter=tap` and the entire stable file list. It records exact input hashes before and after each runtime, final HEAD/tree, index, runner/manifest/list hashes, runtime binary hashes, full commands, raw summaries and fresh exclusive logs. It stops after a failed first runtime and preserves that failure. There is no automatic rerun, test skipping or expected-count shortcut. A successful completion requires both actual complete summaries with no failures, cancellations, skips or todos and unchanged inputs/runtime bytes.

Each child has an 8 MiB log cap and 30-minute time bound; metadata free space is checked while it runs. A bound failure records an explicitly incomplete retained log prefix and never passes. Only that runner's process group can be terminated. The normal small logs remain byte-exact. No full build is invoked below the separate 3 GiB bulk-build floor.

The source scripts have been compiled for Python syntax only; no product module, test file, browser or hosted operation has run in this preparation. Root still owns full exact-source hosted gates, final native journeys, production reproduction, freeze, publication and public/offline qualification. This targeted pair cannot mark P03 accepted by itself.
