import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { soloPage, SoloElement, memoryStorage, settle } from './helpers/solo-dom.mjs';
import { authoritativeCheckpoint } from '../replay.mjs';
import {
  loadLibrary,
  emptyLibrary,
  saveLibrary,
  updatePreferences,
  recordLibraryCompletion,
} from '../library.mjs';
import { createRun, stepRun, getSummary, FIXED_DT } from '../core/index.mjs';
import { createDifficultyContext } from '../campaign-difficulty.mjs';
import { BoardPainter } from '../ui/render.mjs';

const read = async (path) => JSON.parse(await readFile(new URL(path, import.meta.url)));
const source = await read('../content/campaign.json');
const campaign = {
  ...source,
  id: 'library-launch-host',
  revision: '1',
  briefs: [source.briefs[0]],
  classRecipes: await read('../content/classes.json'),
  levels: [
    {
      ...source.levels[0],
      id: 'library-launch-level',
      revision: '1',
      enemies: [],
      objectives: [],
      supplies: [],
      walls: [],
      spawn: { x: 24.5, y: 0.5 },
      width: 48,
      height: 36,
      goal: { coverage: 0.5 },
    },
  ],
};
const slot = 'revealline.suspended.dev.v1',
  profile = 'revealline.library.dev.v1';
function nativeDialogs(t) {
  const show = SoloElement.prototype.showModal,
    close = SoloElement.prototype.close,
    focus = SoloElement.prototype.focus,
    opened = [];
  t.mock.method(SoloElement.prototype, 'showModal', function () {
    if (this.open) return;
    this.emit('beforetoggle', { newState: 'open', oldState: 'closed' });
    show.call(this);
    opened.push(this);
    this.querySelector('button:not(:disabled)')?.focus();
  });
  t.mock.method(SoloElement.prototype, 'close', function () {
    if (!this.open) return;
    if (this.contains(this.ownerDocument.activeElement))
      this.ownerDocument.activeElement = this.ownerDocument.body;
    close.call(this);
  });
  t.mock.method(SoloElement.prototype, 'focus', function (...args) {
    const top = opened.filter((e) => e.open).at(-1);
    if (!this.closest('[hidden],[inert],dialog:not([open])') && (!top || top.contains(this)))
      focus.apply(this, args);
  });
}
function action(element, type = 'click') {
  const fn = element[`on${type}`];
  let result;
  element[`on${type}`] = function (...args) {
    result = fn.apply(this, args);
    return result;
  };
  try {
    type === 'click' ? element.click() : element.emit(type);
  } finally {
    element[`on${type}`] = fn;
  }
  return Promise.resolve(result);
}
function press(h, key) {
  const target = h.doc.activeElement,
    event = target.emit('keydown', { key, code: key, repeat: false });
  if (!event.defaultPrevented && key === 'Escape') {
    const dialog = target.closest('dialog[open]');
    if (dialog && !dialog.emit('cancel', { bubbles: false }).defaultPrevented) dialog.close();
  }
  if (!event.defaultPrevented && key === 'Enter' && target.tagName === 'BUTTON') target.click();
  target.emit('keyup', { key, code: key });
}
function frames(h, n = 12) {
  for (let i = 0; i < n; i++) h.frame();
}
function checkpoint(h) {
  h.frame(0);
  return authoritativeCheckpoint(h.rendered.run);
}
function fixture() {
  let library = emptyLibrary();
  // Synthetic, verified-core completion feeds the public profile writer. This
  // fixture proves navigation/difficulty identity, not a native earned picture.
  const context = createDifficultyContext(campaign, 'gentle');
  const run = createRun(context.campaign.levels[0], {
    seed: 37,
    classId: 'scout',
    classRecipes: campaign.classRecipes,
  });
  for (let i = 0; i < 3000 && run.status === 'running'; i++)
    stepRun(run, { direction: 'down' }, FIXED_DT);
  assert.equal(run.status, 'won');
  library = recordLibraryCompletion(library, {
    campaign: context.campaign,
    result: getSummary(run),
    runId: 'fixture-picture',
    themeId: 'fpv',
    bodyId: 'fpv-body',
    completedAt: '2026-09-15T00:00:00.000Z',
  });
  const storage = memoryStorage();
  assert.equal(
    saveLibrary(storage, profile, updatePreferences(library, { turnPolicy: 'grid-center' })).ok,
    true,
  );
  return storage;
}
async function setup(t, options = {}) {
  nativeDialogs(t);
  t.mock.method(BoardPainter.prototype, 'drawGallery', () => {});
  const context = SoloElement.prototype.getContext;
  t.mock.method(SoloElement.prototype, 'getContext', function (...args) {
    return { ...context.apply(this, args), drawImage() {} };
  });
  return soloPage(t, { campaign, storage: fixture(), ...options });
}
async function flight(h) {
  h.change('level-select', campaign.levels[0].id);
  await settle(() => h.doc.body.dataset.pictureState === 'ready');
  h.$('start-button').click();
  await settle(() => h.doc.body.dataset.flightState === 'running');
  h.key('ArrowDown');
  frames(h, 27);
  h.key('ArrowDown', false);
  h.key('ArrowRight');
  h.frame();
  h.key('ArrowRight', false);
  assert.equal(h.rendered.run.player.cutting, true);
  assert.equal(h.rendered.run.player.queuedDirection, 'right');
  h.$('pause-button').click();
  h.frame(0);
}
async function install(h) {
  h.change('pack-select', 'night-shift');
  await settle(
    () =>
      h.$('pack-select').value === 'night-shift' &&
      h.doc.body.dataset.pictureState === 'ready' &&
      !h.$('pack-select').disabled,
  );
  h.change('pack-select', '');
  await settle(
    () =>
      h.$('pack-select').value === '' &&
      h.doc.body.dataset.pictureState === 'ready' &&
      !h.$('pack-select').disabled,
  );
}
function workshop(h, panel) {
  h.$('overlay-menu').click();
  h.$('shell-workshop').click();
  h.$('shell-library').click();
  assert.equal(h.$('shell-workshop-dialog').open, true);
  h.doc.querySelector(`[data-library-panel="${panel}"]`).click();
  assert.equal(h.$('library-dialog').open, true);
}
async function opener(h, kind) {
  if (kind === 'picture') {
    h.$('overlay-menu').click();
    h.$('shell-collection').click();
    await settle(() => h.$('gallery-grid').querySelector('.gallery-card'));
    const card = h.$('gallery-grid').querySelector('.gallery-card');
    await action(card);
    try {
      await settle(() => !h.$('gallery-replay').disabled);
    } catch (error) {
      error.message += h.$('gallery-view-meta').textContent;
      throw error;
    }
    h.$('gallery-replay').focus();
    return h.$('gallery-replay');
  }
  workshop(h, kind === 'installed' ? 'packs' : 'challenges');
  if (kind === 'installed') {
    const play = h
      .$('installed-packs')
      .querySelectorAll('button')
      .find((e) => e.textContent.startsWith('Play '));
    assert.ok(play);
    play.focus();
    return play;
  }
  h.$('challenge-date').value = '2026-09-15';
  h.$('challenge-kind').value = 'calm';
  h.$('launch-challenge').focus();
  return h.$('launch-challenge');
}
function preserved(h, run, before, saved) {
  frames(h);
  assert.equal(h.rendered.run, run);
  assert.deepEqual(checkpoint(h), before);
  assert.equal(h.rendered.paused, true);
  assert.equal(h.storage.getItem(slot), saved);
  assert.deepEqual(h.errors, []);
}
for (const kind of ['installed', 'challenge', 'picture'])
  test(`actual ${kind} launch: Stay retains exact opener/cut; explicit Replace closes owned parents and prepares without Resume`, async (t) => {
    const h = await setup(t);
    if (kind === 'installed') await install(h);
    await flight(h);
    const trigger = await opener(h, kind),
      run = h.rendered.run,
      before = checkpoint(h);
    await action(trigger);
    assert.equal(h.$('mission-replace-dialog').open, true);
    assert.equal(h.doc.activeElement.id, 'mission-replace-stay');
    assert.match(h.$('mission-replace-status').textContent, /saved and verified/);
    const saved = h.storage.getItem(slot);
    preserved(h, run, before, saved);
    press(h, 'Escape');
    assert.equal(h.doc.activeElement, trigger);
    preserved(h, run, before, saved);
    await action(trigger);
    const selectedSave = h.storage.getItem(slot);
    await action(h.$('mission-replace-confirm'));
    await settle(() => h.doc.body.dataset.pictureState === 'ready');
    h.frame(0);
    assert.notEqual(h.rendered.run, run);
    assert.equal(h.rendered.run.tick, 0);
    assert.equal(h.rendered.paused, true);
    assert.equal(h.storage.getItem(slot), selectedSave);
    for (const id of [
      'mission-replace-dialog',
      'library-dialog',
      'collection-dialog',
      'gallery-view-dialog',
      'shell-workshop-dialog',
      'shell-home',
    ])
      assert.equal(h.$(id).open, false, id);
    assert.equal(h.doc.activeElement.id, 'start-button');
    if (kind === 'picture') {
      assert.equal(h.rendered.run.seed, 37);
      assert.equal(
        h.rendered.run.revision,
        createDifficultyContext(campaign, 'gentle').campaign.levels[0].revision,
      );
      assert.equal(h.rendered.run.lives, 5);
    }
    assert.deepEqual(h.errors, []);
  });
for (const kind of ['installed', 'challenge'])
  test(`${kind} same selection is inert while unfinished and while ready`, async (t) => {
    const h = await setup(t);
    if (kind === 'installed') await install(h);
    let trigger = await opener(h, kind);
    await action(trigger);
    await settle(() => h.doc.body.dataset.pictureState === 'ready');
    h.frame(0);
    const ready = h.rendered.run;
    trigger = await opener(h, kind);
    const writes = h.storage.writes.length;
    await action(trigger);
    h.frame(0);
    assert.equal(h.rendered.run, ready);
    assert.equal(h.storage.writes.length, writes);
    assert.equal(h.$('library-dialog').open, true);
    assert.equal(h.$('mission-replace-dialog').open, false);
    h.$('library-dialog').close();
    h.$('shell-workshop-dialog').close();
    h.$('shell-home').close();
    h.$('start-button').click();
    await settle(() => h.doc.body.dataset.flightState === 'running');
    frames(h, 12);
    h.$('pause-button').click();
    trigger = await opener(h, kind);
    const run = h.rendered.run,
      before = checkpoint(h),
      saved = h.storage.getItem(slot);
    await action(trigger);
    preserved(h, run, before, saved);
    assert.equal(h.$('mission-replace-dialog').open, false);
  });
for (const kind of ['challenge', 'picture'])
  test(`${kind} closed/reopened origin during retained-save waiting cannot adopt or close its successor`, async (t) => {
    const h = await setup(t);
    await flight(h);
    const trigger = await opener(h, kind),
      run = h.rendered.run,
      before = checkpoint(h),
      saved = h.storage.getItem(slot);
    let release;
    navigator.locks.request = async (_name, _options, work) => {
      await new Promise((r) => {
        release = r;
      });
      return work();
    };
    const pending = action(trigger);
    await settle(() => release);
    if (kind === 'challenge') {
      h.$('library-dialog').close();
      h.$('library-button').click();
    } else {
      h.$('gallery-view-dialog').close();
      await action(h.$('gallery-grid').querySelector('.gallery-card'));
    }
    release();
    await pending;
    await action(h.$('mission-replace-confirm'));
    preserved(h, run, before, saved);
    assert.equal(h.$(kind === 'challenge' ? 'library-dialog' : 'gallery-view-dialog').open, true);
    assert.match(h.$('mission-replace-status').textContent, /changed|choose again/);
  });
test('changed saved slot after verification requires another deliberate Replace and preserves the newer bytes', async (t) => {
  const h = await setup(t);
  await flight(h);
  const trigger = await opener(h, 'challenge');
  const run = h.rendered.run,
    before = checkpoint(h);
  await action(trigger);
  const newer = JSON.stringify({
    ...JSON.parse(h.storage.getItem(slot)),
    savedAt: '2026-09-15T23:00:00Z',
  });
  h.storage.setItem(slot, newer);
  await action(h.$('mission-replace-confirm'));
  assert.match(h.$('mission-replace-status').textContent, /changed.*Review/);
  preserved(h, run, before, newer);
  await action(h.$('mission-replace-confirm'));
  h.frame(0);
  assert.notEqual(h.rendered.run, run);
  assert.equal(h.rendered.paused, true);
  assert.equal(h.storage.getItem(slot), newer);
});
test('unavailable saving gives truthful loss decision; Stay retains current checkpoint', async (t) => {
  const h = await setup(t);
  await flight(h);
  const trigger = await opener(h, 'challenge');
  const run = h.rendered.run,
    before = checkpoint(h),
    saved = h.storage.getItem(slot);
  t.mock.method(h.storage, 'setItem', () => {
    throw new Error('quota');
  });
  await action(trigger);
  assert.match(h.$('mission-replace-status').textContent, /not verified|unavailable/);
  assert.doesNotMatch(h.$('mission-replace-status').textContent, /saved and verified/);
  h.$('mission-replace-stay').click();
  assert.equal(h.doc.activeElement, trigger);
  preserved(h, run, before, saved);
});

for (const method of ['button', 'controller'])
  test(`${method} Stay cancels retained-save waiting; late work and other launch/setup owners stay inert`, async (t) => {
    let pad = null;
    const h = await setup(t, { readPads: () => (pad ? [pad] : []) });
    await flight(h);
    const trigger = await opener(h, 'challenge');
    const run = h.rendered.run,
      before = checkpoint(h),
      saved = h.storage.getItem(slot);
    let release;
    navigator.locks.request = async (_name, _options, work) => {
      await new Promise((r) => {
        release = r;
      });
      return work();
    };
    const pending = action(trigger);
    await settle(() => release);
    const title = h.$('mission-replace-target').textContent;
    for (const [id, value] of [
      ['class-select', 'bomber'],
      ['turn-select', 'immediate'],
      ['level-select', campaign.levels[0].id],
    ]) {
      h.$(id).value = value;
      await action(h.$(id), 'change');
    }
    await action(h.$('shell-team'));
    h.$('overlay-restart').click();
    await action(trigger);
    assert.equal(h.$('mission-replace-target').textContent, title);
    assert.equal(h.$('mode-leave-dialog').open, false);
    assert.equal(h.$('restart-dialog').open, false);
    if (method === 'button') press(h, 'Enter');
    else {
      pad = {
        index: 0,
        id: 'library-pad',
        connected: true,
        mapping: 'standard',
        axes: [0, 0, 0, 0],
        buttons: Array.from({ length: 17 }, () => ({ pressed: false, value: 0 })),
      };
      h.frame();
      pad.buttons[1] = { pressed: true, value: 1 };
      h.frame();
      pad.buttons[1] = { pressed: false, value: 0 };
      h.frame();
    }
    release();
    await pending;
    assert.equal(h.$('mission-replace-dialog').open, false);
    assert.equal(h.doc.activeElement, trigger);
    preserved(h, run, before, saved);
  });

test('picture Replay is explicitly fresh even for the same earned selection and keeps seed/difficulty', async (t) => {
  const h = await setup(t);
  let trigger = await opener(h, 'picture');
  await action(trigger);
  await settle(() => h.doc.body.dataset.pictureState === 'ready');
  h.frame(0);
  const first = h.rendered.run;
  trigger = await opener(h, 'picture');
  await action(trigger);
  await settle(() => h.doc.body.dataset.pictureState === 'ready');
  h.frame(0);
  assert.notEqual(h.rendered.run, first);
  assert.equal(h.rendered.run.tick, 0);
  assert.equal(h.rendered.run.seed, 37);
  assert.equal(h.rendered.run.lives, 5);
  assert.equal(h.rendered.paused, true);
  assert.equal(h.$('mission-replace-dialog').open, false);
});

test('practice challenge departure is session-only and never writes profile or suspended bytes', async (t) => {
  const { prepareScenario } = await import('../imports.mjs');
  const raw = await read('../content/scenarios/line-impact-demo.json');
  raw.settings.turnPolicy = 'grid-center';
  const previewStorage = memoryStorage({
    'revealline.playground.current': JSON.stringify((await prepareScenario(raw)).scenario),
  });
  const storage = memoryStorage({ sentinel: 'unchanged' });
  const h = await setup(t, { storage, previewStorage, search: '?practice=1&revision=2' });
  h.$('start-button').click();
  await settle(() => h.doc.body.dataset.flightState === 'running');
  frames(h, 5);
  h.$('pause-button').click();
  // The practice host exposes its Library shortcut, not the ordinary Workshop.
  h.$('library-button').click();
  h.doc.querySelector('[data-library-panel="challenges"]').click();
  h.$('challenge-date').value = '2026-09-15';
  h.$('challenge-kind').value = 'calm';
  const trigger = h.$('launch-challenge');
  trigger.focus();
  const run = h.rendered.run,
    before = checkpoint(h),
    writes = storage.writes.length,
    entries = [...storage.map];
  await action(trigger);
  assert.match(h.$('mission-replace-status').textContent, /session-only.*not saved/);
  h.$('mission-replace-stay').click();
  preserved(h, run, before, null);
  await action(trigger);
  await action(h.$('mission-replace-confirm'));
  h.frame(0);
  assert.notEqual(h.rendered.run, run);
  assert.equal(h.rendered.paused, true);
  assert.equal(storage.writes.length, writes);
  assert.deepEqual([...storage.map], entries);
});

test('a failure after approved selection does not claim rollback and cannot retry the partially adopted selection', async (t) => {
  const h = await setup(t);
  await flight(h);
  const trigger = await opener(h, 'challenge');
  await action(trigger);
  const saved = h.storage.getItem(slot);
  t.mock.method(BoardPainter.prototype, 'setLevel', () => {
    throw new Error('fixture paint setup failed');
  });
  await action(h.$('mission-replace-confirm'));
  assert.match(
    h.$('mission-replace-status').textContent,
    /field may have changed.*previous attempt was not restored/,
  );
  assert.equal(h.$('mission-replace-confirm').disabled, true);
  assert.equal(h.storage.getItem(slot), saved);
  h.$('mission-replace-stay').click();
  assert.equal(h.$('library-dialog').open, true);
  assert.equal(h.doc.activeElement, trigger);
});

for (const restore of ['resume-save', 'import-save'])
  test(`unchanged player export and ${restore} restore the saved cut after explicit Library selection`, async (t) => {
    const h = await setup(t);
    await flight(h);
    const trigger = await opener(h, 'challenge');
    const before = checkpoint(h);
    await action(trigger);
    const saved = h.storage.getItem(slot);
    await action(h.$('mission-replace-confirm'));
    await settle(() => h.doc.body.dataset.pictureState === 'ready');
    workshop(h, 'saves');
    const prior = loadLibrary(h.storage, profile).library;
    await action(h.$('export-library'));
    const exported = JSON.parse(h.$('save-json').value);
    assert.deepEqual(exported.gallery, prior.gallery);
    assert.match(h.$('save-status').textContent, /Library prepared/);
    assert.equal(h.$('library-dialog').open, true);
    if (restore === 'import-save') h.$('save-json').value = saved;
    await action(h.$(restore));
    h.frame(0);
    assert.deepEqual(checkpoint(h), before);
    assert.equal(h.rendered.paused, true);
    assert.equal(h.$('library-dialog').open, false);
    assert.equal(h.$('shell-workshop-dialog').open, false);
    assert.equal(h.doc.activeElement.id, 'start-button');
    assert.deepEqual(h.errors, []);
  });
