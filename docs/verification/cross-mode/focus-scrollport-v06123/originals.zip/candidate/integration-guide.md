# Bordered-dialog focus: integration handoff

The public v0.61.9 picture picker retains its draft and keyboard focus through rotation, but its bottom focus outline is clipped by 1.765625px after Large/Plain returns to portrait. The scroll helper reserves space from the dialog's outside border rather than its usable inside edge.

This candidate corrects that geometry in the shared focus helper. The original 8px clearance, label handling, sticky regions and lifecycle protections remain intact. No font, control size, outline, CSS, media or storage implementation changes are included. Native `clientTop` and `clientHeight` identify the scrollport; minimal non-native test surfaces keep the prior fallback.

## Reviewed evidence

- [Original public evidence](../p05-public-native-v0619/manifest.json) remains a partial pass with the required focus subgate failed. The published bytes are unchanged. [Typography addendum](../p05-public-native-v0619/typography-addendum.json) records the actual computed family lists without claiming which font supplies every glyph.
- [Frozen candidate](source.json) is based on `6db978db40287151489803e915cb4ecb9ea232ee`. The patch changes the helper and its regression test. Only the helper is overridden by the local server.
- [Preparation evidence](manifest.json) retains the original 13 passing and three new failing tests, then 16 passing tests on both Node 20 and 22, plus syntax, lint, format, patch and exact HTTP-byte checks.
- [Independent review](independent-review/review.md) verifies the patch and unchanged guards. Shared consumers at this source include Still/Story, Missions/briefing and Replay.
- [Native review](native/review.json) covers Large/Plain, Standard/Theme and Large/Theme. All nine initial portrait, landscape and portrait-return samples show the full picker outline and label inside the usable region. Large portrait return has 1.234375px clearance beyond the full outline. The owned image, verified preview status and unsaved metadata remain intact.
- Actual keyboard navigation reaches Close and activates it with Return; reopening and Escape restore the same opener in each typography case. All 18 raw native captures match the requested viewport dimensions.

## Release integration

Apply `candidate.patch` to the reviewed source and requalify shared consumers on the composed build. The current local source displays `DEV`; it is not a frozen release. Full source gates, versioning, commit, publication and public regression remain with the release coordinator. This packet makes no physical-device, spoken screen-reader, zoom, BFCache or full-phase claim.

For the maintained runtime skill, add: “Measure modal focus clearance against its client scrollport, excluding borders and scrollbars. Preserve the control's complete focus outline and label while respecting sticky regions. Do not change readable text size, target height, focus ownership or unsaved data to solve clipping.”

Suggested regression prompt: “Use an owned image in Still Media without saving an assignment. With Large/Plain, Standard/Theme and Large/Theme, Tab to the file picker and rotate 390×844 → 844×390 → 390×844. Compare the full outline against the inner scrollport and the label against the sticky status region. Confirm filename, unsaved fields and verified preview survive; then reach Close by keyboard, reopen with Return and close with Escape. Record computed families separately from per-glyph font claims.”
