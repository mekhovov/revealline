# Independent focus-clearance review

Result: no blocking implementation defect found in this bounded correction. This is an independent source/evidence review, not an independent test run or a browser approval.

Reviewed base: `6db978db40287151489803e915cb4ecb9ea232ee`. Reviewed helper SHA-256: `28d8b85dd9493163f487ae8913a98fb8287e38d1098aba02e3deb77294532736`; test SHA-256: `8160c638ca367834b4ff0c76c42463c9ea095de2070632b7cc94cb935c7cfc6f`; patch SHA-256: `273527618c544c9b264a727d862961bc70595e481e5d5a6d7688213c42bab6f9`.

## Correction and scope

At helper lines 15–33, the allowed region now begins at bounding top + clientTop and ends at that position + clientHeight. These are the untransformed element's inner vertical scrollport bounds. Borders and a horizontal scrollbar no longer count as drawable clearance. Measured heading/footer clipping remains stricter when present; padding is now expressed relative to the same inner origin. Both geometry properties must be finite, retaining the previous fallback for existing minimal fixtures. A real zero clientHeight is deliberately respected rather than replaced by a nonzero border box.

Recorded portrait case: client top19 and bottom825; old bottom limit820 left the field bottom819.765625 unchanged, so its 7px outward focus painting reached826.765625. New limit817 scrolls2.765625px, leaving the focus painting at824 (1px inside the clip). Top-edge regression similarly preserves a 1px margin. The same-focus repeat check proves no modeled drift.

No observer/listener scheduling, focus assignment, live operation ownership, disabled/hidden/closed/blurred checks, tall-control clamp, manual scroll handling, label opt-in or teardown changed (helper lines34–78). This correction does not touch media decoding, assignment, input, save, font, control dimensions or CSS.

## Shared callers

- Still: `game/ui/still-media-panel.mjs:193–198` opts into labels, with operations as its sticky heading and no footer. The 3px border/overflow-auto contract is in `game/ui/still-media-panel.css:49–58`; its sticky operation rail is130–140. Open refresh and disposal remain792/818.
- Story: its section is appended to that same dialog (`still-media-panel.mjs:211–233`), so its controls benefit from the same bounded scrollport. There is no separate Story focus-clearance owner.
- Missions/briefing: `game/ui/game-shell.mjs:44–49` uses measured heading plus deploy footer, with control-only default. If both rails already dominate the bounds, scrolling is unchanged; exposed native edges get the intended border correction. Refresh164/353 and destroy635 remain unchanged.
- Replay export: `game/app.mjs:6678–6682` uses its operation rail and control-only default. The tall textarea continues to use the pre-existing top clamp and independent manual scrolling. The bottom border is no longer counted as visible clearance.
- Motion Lab is not a direct or indirect caller of this helper in the reviewed production source. Only Still's host imports attachStillMediaPanel; Motion-specific routing is unaffected by this two-file patch.

The inspected caller styles contain no scale/zoom transform applied to these dialog scrollports. Combining unscaled client metrics with getBoundingClientRect would require revisiting this contract if a future caller introduces CSS scaling; that is not an observed regression here. Native client dimensions have integer rounding, so the retained 8px clearance should still be judged against actual painted focus at the intended zoom/device scale; finite geometry tests are not a raster guarantee.

## Tests and evidence

The candidate's first13 cases are byte-for-byte unchanged from exact base; only3 cases were appended. Retained RED Node20 uses the exact old helper and the exact new test file, with13passes and precisely the3 new failures: portrait painted-outline boundary, top edge and zero-height scrollport. GREEN receipts pin the new helper/test and show16/16 on Node20.19.5 and22.22.2. All receipt source hashes match files. The entire candidate patch reconstructs exactly from the two verified base/candidate bodies. No extra source or dependency modification is present in the patch.

Existing13 tests still cover expanded heading/footer, current-focus reading, tall reading controls/manual scroll, closed/hidden/blurred/outside/disposed guards, label opt-in/outside-label rejection and fallback when a label cannot fit. The added cases make the observed native boundary error fail without weakening those assertions.

Remaining acceptance belongs to the parent native checks: return through the real Still/Story dialog with retained focus; portrait→landscape→portrait in Large Plain, Standard Theme and Large Theme; no clipped painted outline, no unwanted scrolling or focus move. A small Missions/Replay smoke check is useful shared-helper qualification, especially a focused textarea/selector near the inner bottom edge. No code blocker is inferred from the absence of those native checks in this packet. Physical device, screen-reader and full release checks are outside this review.
