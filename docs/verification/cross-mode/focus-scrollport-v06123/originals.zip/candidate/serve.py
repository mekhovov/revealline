from pathlib import Path, PurePosixPath
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlsplit, unquote
import subprocess, os, json, hashlib, mimetypes, threading
ROOT=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test');PACKET=Path(__file__).resolve().parent
MANIFEST=json.loads((PACKET/'source.json').read_text());BASE=MANIFEST['base'];ENV={**os.environ,'GIT_NO_LAZY_FETCH':'1'}
FILES={r['path']:r for r in MANIFEST['files']};cache={};lock=threading.Lock();total=0
mimetypes.add_type('text/javascript','.mjs');mimetypes.add_type('font/woff2','.woff2')
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  global total
  name=unquote(urlsplit(self.path).path).lstrip('/')
  if '..' in PurePosixPath(name).parts or '\\' in name or '\x00' in name:return self.send_error(400)
  if not name or name.endswith('/'):name+='index.html'
  with lock:
   body=cache.get(name)
   if body is None:
    if name in FILES:
     body=(PACKET/FILES[name].get('localPath','overlay/'+name)).read_bytes()
     if len(body)!=FILES[name]['bytes'] or hashlib.sha256(body).hexdigest()!=FILES[name]['sha256']:return self.send_error(500,'Pinned overlay mismatch')
    else:
     size=subprocess.run(['git','cat-file','-s',BASE+':'+name],cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
     if size.returncode:return self.send_error(404)
     if int(size.stdout)>20*1024*1024:return self.send_error(413)
     result=subprocess.run(['git','show',BASE+':'+name],cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
     if result.returncode:return self.send_error(404)
     body=result.stdout
    if len(body)>20*1024*1024:return self.send_error(413)
    if total+len(body)<64*1024*1024:cache[name]=body;total+=len(body)
  sha=hashlib.sha256(body).hexdigest()
  self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(name)[0] or 'application/octet-stream');self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.send_header('X-RevealLine-Base',BASE);self.send_header('X-RevealLine-Body-SHA256',sha);self.end_headers();self.wfile.write(body)
  with lock:
   with (PACKET/'served.jsonl').open('a') as stream:stream.write(json.dumps({'path':name,'bytes':len(body),'sha256':sha,'overlay':name in FILES})+'\n')
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
while server.server_port in {50006,62596,51053,51527,53310,59879}:
 server.server_close();server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
(PACKET/'server.json').write_text(json.dumps({'pid':os.getpid(),'port':server.server_port,'base':BASE,'patchSHA256':MANIFEST['patch']['sha256']},indent=2)+'\n')
print('PREVIEW http://127.0.0.1:'+str(server.server_port)+'/authoring/still-media/',flush=True)
server.serve_forever()
