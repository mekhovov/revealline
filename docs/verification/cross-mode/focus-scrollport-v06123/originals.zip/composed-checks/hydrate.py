from pathlib import Path
import os,re,json,hashlib,subprocess,posixpath,shutil,datetime
R=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test'); W=R/'.cache/worktrees/p03-focus-scrollport-v06123'; C=R/'.cache/p03-focus-scrollport-v06123-checks'; CAP=24*1024**2; RES=512*1024**2
E={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1'}
def git(*a):return subprocess.check_output(['git','-C',str(W),*a],env=E)
def sha(b):return hashlib.sha256(b).hexdigest()
def size(p):return sum(q.stat().st_size for q in p.rglob('*') if q.is_file() and not q.is_symlink())
assert git('rev-parse','HEAD').decode().strip()=='17e0a455f76c3f4a72f2e596397a0e73463335a5'
tracked={}
for line in git('ls-tree','-r','-l','HEAD').decode().splitlines():
 m,p=line.split('\t'); mode,kind,oid,n=m.split();
 if kind=='blob':tracked[p]={'oid':oid,'bytes':int(n),'mode':mode}
tests=['focus-clearance','field-kit-flow','main-menu-collection-host','modal-navigation','mission-picker','still-media-display-host','still-media-host','still-media-panel','still-media-preview']
roots=['game/test/'+x+'.test.mjs' for x in tests]+['game/app.mjs','game/ui/tool-display-entry.mjs','authoring/still-media/launch.js']
roots += [p for p,v in tracked.items() if p.startswith('game/content/') and p.endswith('.json') and v['bytes']<1024**2]
todo=roots[:];seen=set();missing={};existing={};unresolved=set()
while todo:
 p=todo.pop()
 if p in seen:continue
 seen.add(p);q=W/p
 assert p in tracked and tracked[p]['mode']=='100644',p
 if q.exists():
  assert q.is_file() and not q.is_symlink(),p
  raw=q.read_bytes();existing[p]={'bytes':len(raw),'sha256':sha(raw)}
 else:
  assert tracked[p]['bytes']<=1024**2,(p,tracked[p]['bytes'])
  raw=git('cat-file','blob',tracked[p]['oid']);missing[p]=raw
 if p.endswith(('.mjs','.js','.html')):
  text=raw.decode()
  specs=re.findall(r'(?:from\s*|import\s*\(|import\s*|new URL\s*\()\s*["\'`](\.[^"\'`]+)["\'`]',text)
  specs+=re.findall(r'["\'](\.[^"\'\n]+\.(?:json|html|css))["\']',text)
  for spec in specs:
   path=posixpath.normpath(posixpath.join(posixpath.dirname(p),spec.split('?')[0]))
   if path in tracked and not path.endswith('.rltheme'):todo.append(path)
   elif '${' not in spec and not spec.startswith('http'):unresolved.add((p,spec))
new=sum(map(len,missing.values()));before=json.loads((C/'before.json').read_text())
assert size(W)+size(C)+new+1024**2<CAP,(size(W),size(C),new)
assert shutil.disk_usage(R).free>RES+new+1024**2
for row in before['protectedWorktreePins']:
 p=R/row['path'];assert sha(p.read_bytes())==row['sha256'],row['path']
sp=Path(git('rev-parse','--git-path','info/sparse-checkout').decode().strip());sp=sp if sp.is_absolute() else W/sp
admin=Path(git('rev-parse','--absolute-git-dir').decode().strip());assert sp.resolve()==admin/'info/sparse-checkout'
sparse=sp.read_bytes();(C/'sparse-before.txt').write_bytes(sparse)
plan={'source':before['head'],'tests':['game/test/'+x+'.test.mjs' for x in tests],'closurePaths':len(seen),'newBytes':new,'newFiles':len(missing),'files':[{'path':p,**tracked[p],'sha256':sha(b)} for p,b in sorted(missing.items())],'existing':existing,'unresolved':sorted(unresolved),'currentManagedBytes':size(W)+size(C),'capacity':CAP,'reserve':RES,'freeBefore':shutil.disk_usage(R).free}
(C/'hydration-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
sp.write_bytes(sparse+b''.join(('/'+p+'\n').encode() for p in sorted(missing) if ('/'+p+'\n').encode() not in sparse))
for p,raw in sorted(missing.items()):
 q=W/p;q.parent.mkdir(parents=True,exist_ok=True)
 with q.open('xb') as f:f.write(raw)
 assert sha(q.read_bytes())==sha(raw)
assert size(W)+size(C)<CAP and shutil.disk_usage(R).free>RES
(C/'hydration-complete.json').write_text(json.dumps({'source':before['head'],'newFiles':len(missing),'newBytes':new,'managedAfter':size(W)+size(C),'freeAfter':shutil.disk_usage(R).free,'sparseAfterSha256':sha(sp.read_bytes()),'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print(json.dumps({k:v for k,v in plan.items() if k not in ['files','existing','unresolved']},indent=2));print('unresolved',plan['unresolved'])
