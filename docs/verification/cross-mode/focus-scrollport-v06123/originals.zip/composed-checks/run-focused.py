from pathlib import Path
import subprocess,os,json,hashlib,datetime,shutil,time
R=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test');W=R/'.cache/worktrees/p03-focus-scrollport-v06123';C=R/'.cache/p03-focus-scrollport-v06123-checks'; E={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1'}
def size(p):return sum(x.stat().st_size for x in p.rglob('*') if x.is_file() and not x.is_symlink())
plan=json.loads((C/'hydration-plan.json').read_text()); before=json.loads((C/'before.json').read_text())
for version in ['20.19.5','22.22.2']:
 assert size(W)+size(C)<24*1024**2-2*1024**2 and shutil.disk_usage(R).free>512*1024**2+2*1024**2
 for row in before['protectedWorktreePins']:
  # Root owns docs/skills while this check executes; preserve original helper/test/version bodies.
  if '/game/' in row['path'] or row['path'].endswith(('package.json','package-lock.json')):
   assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
 node=Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node')/version/'bin/node'
 out=C/('node'+version[:2]+'-r1');out.mkdir(exist_ok=False)
 cmd=[str(node),'--test','--test-concurrency=1',*plan['tests']]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
 p=subprocess.run(cmd,cwd=W,env=E,capture_output=True,timeout=300)
 assert len(p.stdout)+len(p.stderr)<2*1024**2
 (out/'stdout').write_bytes(p.stdout);(out/'stderr').write_bytes(p.stderr)
 rec={'command':cmd,'cwd':str(W),'source':before['head'],'startedAt':start,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-tick,'exitCode':p.returncode,'stdoutBytes':len(p.stdout),'stdoutSha256':hashlib.sha256(p.stdout).hexdigest(),'stderrBytes':len(p.stderr),'stderrSha256':hashlib.sha256(p.stderr).hexdigest(),'claims':'Focused composed-source Node fixtures only; no browser, physical device, full qualification or public acceptance.'}
 (out/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n')
 print(json.dumps({'node':version,'exitCode':p.returncode,'seconds':rec['seconds'],'tail':p.stdout.decode(errors='replace')[-1600:],'stderr':p.stderr.decode(errors='replace')[-1000:]}),flush=True)
