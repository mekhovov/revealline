from pathlib import Path
import subprocess,os,json,hashlib,datetime,shutil,re
R=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test'); W=R/'.cache/worktrees/p03-focus-scrollport-v06123'; C=R/'.cache/p03-focus-scrollport-v06123-checks'; E={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1'}
def g(p,*a):return subprocess.check_output(['git','-C',str(p),*a],env=E).decode()
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(b),'sha256':sha(b)}
def size(p):return sum(q.stat().st_size for q in p.rglob('*') if q.is_file() and not q.is_symlink())
before=json.loads((C/'before.json').read_text());plan=json.loads((C/'hydration-plan.json').read_text())
root_status=g(R,'status','--porcelain=v1','--untracked-files=normal'); assert root_status==before['rootStatus']
root_tracked=g(R,'status','--porcelain=v1','--untracked-files=no');assert root_tracked==before['rootTrackedStatus']
for row in before['rootTrackedPins']+[before['rootIndex'],before['commonConfig']]:assert pin(R/row['path'])==row,row['path']
protected=[]
for row in before['protectedWorktreePins']:
 if '/game/' in row['path'] or row['path'].endswith(('package.json','package-lock.json')):
  assert pin(R/row['path'])==row,row['path'];protected.append(row)
assert len(protected)==5
hydrated=[]
for row in plan['files']:
 p=W/row['path']; b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path'];hydrated.append(pin(p))
assert g(W,'diff','--cached','--name-only')==''
subprocess.run(['git','-C',str(W),'diff','--check','--','game/ui/focus-clearance.mjs','game/test/focus-clearance.test.mjs'],env=E,check=True)
cohorts=[]
for ver in ['20','22']:
 d=C/('node'+ver+'-r1');rec=json.loads((d/'receipt.json').read_text());text=(d/'stdout').read_text()
 assert rec['exitCode']==0 and not (d/'stderr').read_bytes()
 counts={key:int(re.search(r'^# '+key+r' (\d+)$',text,re.M).group(1)) for key in ['tests','pass','fail','cancelled','skipped','todo']}
 assert counts=={'tests':157,'pass':157,'fail':0,'cancelled':0,'skipped':0,'todo':0}
 assert rec['stdoutSha256']==sha((d/'stdout').read_bytes())
 cohorts.append({'node':ver,'counts':counts,'fileCount':len(plan['tests']),'receipt':pin(d/'receipt.json'),'stdout':pin(d/'stdout'),'stderr':pin(d/'stderr')})
n=R/'.cache/p05-still-focus-successor-v0619-r1/shared-consumers-native';native=json.loads((n/'manifest.json').read_text())
for row in native['files']:
 b=(n/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
assert sum(row['bytes'] for row in native['files'])==native['totalBytes']
source_paths=plan['tests']+['game/ui/focus-clearance.mjs','game/app.mjs','game/ui/game-shell.mjs','game/ui/still-media-panel.mjs']
source_pins=[pin(W/p) for p in source_paths]
(C/'tested-source-pins.json').write_text(json.dumps({'source':before['head'],'files':source_pins,'hydratedExactGitFiles':hydrated},indent=2)+'\n')
(C/'after.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':g(W,'rev-parse','HEAD').strip(),'rootStatusRows':len(root_status.splitlines()),'rootStatusExact':True,'rootTrackedBodiesExact':True,'rootIndexExact':True,'commonConfigExact':True,'protectedFiveBodiesExact':True,'worktreeIndexUnstaged':True,'worktreeStatus':g(W,'status','--porcelain=v1','--untracked-files=normal'),'managedBytes':size(W)+size(C),'freeBytes':shutil.disk_usage(R).free},indent=2)+'\n')
assert size(W)+size(C)<24*1024**2 and shutil.disk_usage(R).free>512*1024**2
review={'status':'PASS — focused composed-source review; exact-source full qualification and public gates remain open','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseSource':before['head'],'baseTree':before['tree'],'branch':before['branch'],'candidateVersion':'0.61.23','sourceEditsByReviewer':False,'sourceScope':'The original runtime and helper test are byte-identical in 619 and 622; the donor patched bodies are byte-identical to this uncommitted623 composition. Parent-owned docs, skill, evidence and version edits are preserved.','cohorts':cohorts,'tests':plan['tests'],'findings':[],'reviewedBehavior':['Inner viewport starts at border-box top plus clientTop and ends at that point plus clientHeight; both native metrics must be finite. Zero-height client viewport remains empty.','Eight-pixel inner clearance preserves the recorded seven-pixel outward focus painting. Sticky heading/footer measurements, opt-in label fit/fallback, current-focus selection and lifecycle guards are unchanged.','No new frame loop, scroll listener, focus call, storage/media command, navigation owner or simulation effect was added.','Exact current consumers are Missions in game-shell.mjs, Replay dialog in app.mjs, and Still Media in still-media-panel.mjs. Source CSS inspection found no scale/zoom transform on those dialog containers; unrelated decorative rotations/translated boot status/scaled progress stripe do not establish a transformed-container defect.','Selected actual-host tests retain Missions/Replay opener return, paused checkpoints, generated replay identity, manual textarea scroll, modal/controller held-input handling and Still Media draft/preview/cancellation/disposal invariants.'],'nativeBoundary':{'manifest':pin(n/'manifest.json'),'review':pin(n/'review.json'),'verifiedPins':len(native['files']),'verifiedBytes':native['totalBytes'],'scope':'Read-only inspection of sealed exact619+helper source-preview originals; no browser executed by this reviewer and no native623/public acceptance inferred.','separateOpenFindings':['Forward-Tab horizontal Missions card clipping in source preview.','Replay JSON remains 11px under Large/Plain in source preview.'],'excludedCaptures':'Replay07/08 focused Close;09/10 are actual textarea-focus authority.'},'preservation':{'rootStatusRows':64,'rootStatusAndDirtyBodiesExact':True,'rootIndexExact':True,'commonConfigExact':True,'protectedFiveWorkingBodiesExact':True,'newHydratedFiles':len(hydrated),'newHydratedBytes':plan['newBytes'],'hydrationScope':'Only absent exact17e Git dependency bodies; per-worktree sparse file appended; no existing source file overwritten.'},'preparationRefusal':pin(C/'hydration-preflight-refusal-r1.json'),'limits':['Nine focused Node files, not the full source suite, production reproduction or ordinary build.','No composed623 browser, physical controller/touch, screen-reader, zoom, real BFCache or public acceptance.','Parent phases remain open; retained native horizontal/readability findings require separate scoped work.'],'evidence':[pin(C/p) for p in ['before.json','after.json','donor-review.json','hydration-plan.json','hydration-complete.json','tested-source-pins.json','run-focused.py','hydrate.py']]}
(C/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(C/'ready.json').write_text(json.dumps({'status':'ready for root source review','review':pin(C/'review.json'),'cohorts':[x['receipt'] for x in cohorts],'sourcePins':pin(C/'tested-source-pins.json'),'after':pin(C/'after.json'),'managedBytes':size(W)+size(C),'capBytes':24*1024**2,'reserveBytes':512*1024**2,'freeBytes':shutil.disk_usage(R).free,'noMutations':'No runtime/test edits, staging, commits, network, browser, production regeneration or full build.'},indent=2)+'\n')
print(json.dumps({'ready':pin(C/'ready.json'),'review':pin(C/'review.json'),'testsEach':157,'files':9,'rootRows':64,'managedBytes':size(W)+size(C),'freeBytes':shutil.disk_usage(R).free},indent=2))
