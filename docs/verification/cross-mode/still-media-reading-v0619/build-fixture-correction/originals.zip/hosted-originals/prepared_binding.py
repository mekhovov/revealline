"""Root-delegated GET-only intake binding; no final source or publication approval."""
from pathlib import Path
import hashlib,json,subprocess,shutil
HERE=Path(__file__).resolve().parent
BIND=json.loads((HERE/'intake-binding.json').read_bytes())
assert BIND['status']=='DELEGATED_READ_ONLY_INTAKE_BINDING_NOT_FINAL_ROOT_QUALIFICATION'
ROOT=Path(BIND['repositoryRoot']);WT=Path(BIND['sourceWorktree'])
SOURCE=BIND['source']['commit'];TREE=BIND['source']['tree'];VERSION=BIND['source']['version']
assert SOURCE=='d2c3fbf947f82c35fcb2e3adda8ee6b9df162878' and TREE=='fade4ac0a739aa06b7e6cdfdef0d5ee234bb238a' and VERSION=='v0.61.9'
assert HERE==ROOT/'.cache/p05-qualified/still-media-reading-v0619-d2c3fbf9'
assert not any(p.is_symlink() for p in [HERE,*HERE.parents,WT])
for row in BIND['rootDispatchOriginalPins']:
 p=Path(row['path']);assert p.is_relative_to(HERE/'source-dispatch-r1') and p.is_file() and not p.is_symlink()
 b=p.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
request=json.loads((HERE/'source-dispatch-r1/dispatch.request.json').read_bytes())
assert request=={'ref':'codex/p05-still-media-reading-v0619','inputs':{'operation':'qualify','freeze_snapshot':True}}
pr=json.loads((HERE/'source-dispatch-r1/pr-post.original').read_bytes())
assert pr['number']==124 and pr['html_url']=='https://github.com/mekhovov/revealline/pull/124'
assert pr['head']['sha']==SOURCE and pr['head']['ref']=='codex/p05-still-media-reading-v0619' and pr['base']['ref']=='main'
pr_request=json.loads((HERE/'source-dispatch-r1/pr.request.json').read_bytes())
assert pr_request['head']==pr['head']['ref'] and pr_request['base']=='main' and pr_request['draft'] is True
assert pr_request['body']==pr['body'] and pr_request['title']==pr['title']
remote=json.loads((HERE/'source-dispatch-r1/remote-head.original').read_bytes())
assert remote['ref']=='refs/heads/codex/p05-still-media-reading-v0619' and remote['object']['sha']==SOURCE
# Root did not emit the v617 command-receipt schema. Authenticate the actual
# created runs instead; never infer HTTP status from an empty POST response.
for family,rid,event,path in [('manual',35317589810,'workflow_dispatch','.github/workflows/qualify-release-source.yml'),('pr-source',35317591343,'pull_request','.github/workflows/deploy-pages.yml')]:
 run=json.loads((HERE/('source-dispatch-r1/discovery-'+family+'-run.json')).read_bytes())
 assert run['id']==rid and run['head_sha']==SOURCE and run['head_commit']['tree_id']==TREE
 assert run['event']==event and run['path']==path and run['run_attempt']==1
 assert '2026-09-18T07:02:45Z'<=run['created_at']<='2026-09-18T07:03:10Z'
RUN_RECORDS=BIND['runs'];RUNS={k:v['id'] for k,v in RUN_RECORDS.items()}
assert RUNS=={'manual':35317589810,'pr-source':35317591343} and all(v['attempt']==1 for v in RUN_RECORDS.values())
assert subprocess.check_output(['git','-C',str(WT),'rev-parse',SOURCE+'^{tree}']).decode().strip()==TREE
assert shutil.disk_usage(HERE).free>=BIND['limits']['freeReserveBytes']
assert sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())<=BIND['limits']['cacheBytes']
