"""GET-only terminal originals for pinned d2c3fbf9 while its isolated worktree has the reviewed fixture correction. No qualification or local source execution."""
from pathlib import Path
import sys, subprocess, hashlib, json, datetime
from collect_hosted import HERE, WT, SOURCE, TREE, RUNS, collect, objput, git
family=sys.argv[1];assert family in RUNS
assert git('rev-parse','HEAD').decode().strip()==SOURCE and git('rev-parse',SOURCE+'^{tree}').decode().strip()==TREE
assert git('diff','--cached','--name-only')==b''
changed=git('diff','--name-only').decode().splitlines()
assert sorted(changed)==['authoring/skills/xonix-runtime-maintainer/SKILL.md','game/test/still-workshop-build.test.mjs'],changed
P=HERE.parents[1]/'p05-still-build-fixture-v0619'; checked=json.loads((P/'checks-r5/node22-reading.json').read_bytes())['inputs']
for p in checked:
 b=(WT/p['path']).read_bytes();assert len(b)==p['bytes'] and hashlib.sha256(b).hexdigest()==p['sha256']
O=HERE/'delegated-execution'/('terminal-'+family+'-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));O.mkdir(parents=True,exist_ok=False)
objput(O/'start.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceUnderHostedTest':SOURCE,'tree':TREE,'family':family,'run':RUNS[family],'localCandidateIsClean':False,'localCandidateChanges':checked,'scope':'Pinned Git/actual hosted originals only. Root separately authorized the isolated local fixture correction; these bodies cannot qualify its successor.','command':['python3',str(Path(__file__).resolve()),family]})
try:
 collect(family)
except BaseException as e:
 objput(O/'exit.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':1,'exceptionType':type(e).__name__,'automaticRetry':False});raise
objput(O/'exit.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':0,'qualificationAccepted':False})
