from pathlib import Path
import subprocess,json,datetime,hashlib,shutil,os
R=Path.cwd();W=R/'.cache/worktrees/p05-still-media-reading-v0619';P=R/'.cache/p05-still-build-fixture-v0619';N=Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node');C=P/'checks-r3';C.mkdir(exist_ok=False);sha=lambda b:hashlib.sha256(b).hexdigest()
files=['game/test/still-workshop-build.test.mjs','game/test/still-media-display-host.test.mjs','game/test/tool-display-restoration.test.mjs','game/test/display-preferences.test.mjs','game/test/still-media-host.test.mjs','game/test/focus-clearance.test.mjs','game/test/still-media-panel.test.mjs'];changed=['game/test/still-workshop-build.test.mjs','authoring/skills/xonix-runtime-maintainer/SKILL.md'];pins=[{'path':n,'bytes':(W/n).stat().st_size,'sha256':sha((W/n).read_bytes())} for n in changed]
commands=[]
for version,label in [('20.19.5','node20'),('22.22.2','node22')]:
 node=str(N/version/'bin/node')
 commands.append((label+'-build',[node,'--test','--test-name-pattern=^(built workshop|Pages automatically|built poster/still)','game/test/still-workshop-build.test.mjs']))
 commands.append((label+'-reading',[node,'--test','--test-concurrency=1',*files[1:]]))
commands.extend([('lint',[str(N/'22.22.2/bin/node'),str(R/'node_modules/eslint/bin/eslint.js'),changed[0]]),('format',[str(N/'22.22.2/bin/node'),str(R/'node_modules/prettier/bin/prettier.cjs'),'--check',*changed]),('diff-check',['git','diff','--check'])])
for name,command in commands:
 assert shutil.disk_usage(R).free>512*1024**2+64*1024**2
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(command,cwd=W,capture_output=True,timeout=180);end=datetime.datetime.now(datetime.timezone.utc).isoformat()
 for suffix,b in [('stdout',p.stdout),('stderr',p.stderr)]:assert len(b)<2_000_000;(C/(name+'.'+suffix)).write_bytes(b)
 receipt={'startedAt':start,'finishedAt':end,'command':command,'cwd':str(W),'exitCode':p.returncode,'inputs':pins,'stdout':{'bytes':len(p.stdout),'sha256':sha(p.stdout)},'stderr':{'bytes':len(p.stderr),'sha256':sha(p.stderr)}};(C/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(name,p.returncode,p.stdout.decode()[-1200:],p.stderr.decode()[-1600:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
