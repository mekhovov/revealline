from pathlib import Path
import subprocess,re,posixpath,json,hashlib,shutil,os
R=Path.cwd();W=R/'.cache/worktrees/p05-still-media-reading-v0619';P=R/'.cache/p05-still-build-fixture-v0619';B='d2c3fbf947f82c35fcb2e3adda8ee6b9df162878';env=dict(os.environ,GIT_NO_LAZY_FETCH='1');pending=['scripts/game-cli.mjs'];seen={}
while pending:
 n=pending.pop()
 if n in seen:continue
 b=subprocess.check_output(['git','show',B+':'+n],env=env);seen[n]=b
 for dep in re.findall(r'(?:^|[;\r\n])\s*(?:import\b\s*(?:[^;"\']*?\bfrom\s*)?|export\b[^;"\']*?\bfrom\s*)["\']([^"\']+)["\']',b.decode()):
  if dep.startswith('.'):pending.append(posixpath.normpath(posixpath.join(posixpath.dirname(n),dep)))
missing={n:b for n,b in seen.items() if not (W/n).exists()};assert sum(len(b) for b in missing.values())<2_000_000 and shutil.disk_usage(R).free-sum(len(b) for b in missing.values())>512*1024**2
for n,b in seen.items():
 if (W/n).exists():assert (W/n).read_bytes()==b
for n,b in missing.items():p=W/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
record={'reason':'Initial sparse helper missed multiline static imports; original failed local startup retained separately from hosted fixture failure.','source':B,'selected':len(seen),'hydrated':len(missing),'bytes':sum(len(b) for b in missing.values()),'files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(missing.items())]};(P/'hydration-script-closure-r2.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
