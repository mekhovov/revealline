from pathlib import Path,PurePosixPath
import os,subprocess,re,json,hashlib,shutil,posixpath
R=Path.cwd();W=R/'.cache/worktrees/p05-still-media-reading-v0619';P=R/'.cache/p05-still-build-fixture-v0619';BASE='d2c3fbf947f82c35fcb2e3adda8ee6b9df162878';env=dict(os.environ,GIT_NO_LAZY_FETCH='1');sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','-C',str(W),'status','--porcelain','--untracked-files=no'],env=env)==b''
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],env=env,text=True).strip()==BASE
rows=subprocess.check_output(['git','ls-tree','-rl','-z',BASE],env=env).split(b'\0');tree={}
for row in rows:
 if row:
  meta,name=row.split(b'\t');mode,kind,blob,size=meta.split();tree[name.decode()]={'mode':mode.decode(),'blob':blob.decode(),'bytes':int(size)}
def body(n):
 assert n in tree and tree[n]['mode']=='100644' and tree[n]['bytes']<4_000_000,n
 return subprocess.check_output(['git','show',BASE+':'+n],env=env)
T='game/test/still-workshop-build.test.mjs';raw=body(T);seeds={T,'scripts/game-cli.mjs','scripts/pages-current-entry.mjs'}
for n in re.findall(r"['\"]([^'\"]+)['\"]",raw.decode()):
 if n in tree:seeds.add(n)
for n in ['tactical-read-clearing','tactical-borrowed-seconds','tactical-quiet-crossing']:seeds.add('authoring/library/tactical-teaching/scenarios/'+n+'.json')
for n in ['Dawn-Signal-originals.rlmedia','Dawn-Signal-stories.rlstory','manifest.json']:seeds.add('authoring/still-media/examples/dawn-signal/'+n)
# Follow the exact fixture's JS imports plus literal stylesheet resources. Do not recurse into the inert game entry or unrelated application graph.
seen={};pending=list(seeds)
while pending:
 n=pending.pop()
 if n in seen:continue
 b=body(n);seen[n]=b
 if n.endswith(('.mjs','.js')):
  for value in re.findall(r"(?:import|export)\s+(?:[^;\n]*?\sfrom\s*)?['\"]([^'\"]+)['\"]|import\(\s*['\"]([^'\"]+)['\"]",b.decode()):
   imp=next(x for x in value if x)
   if imp.startswith('.'):
    dep=posixpath.normpath(posixpath.join(posixpath.dirname(n),imp));assert dep in tree,(n,dep);pending.append(dep)
 if n.endswith('.css'):
  for imp in re.findall(r"url\(\s*['\"]?([^)'\"\s]+)",b.decode()):
   if imp.startswith(('data:','http:','https:','#')):continue
   dep=posixpath.normpath(posixpath.join(posixpath.dirname(n),imp.split('?')[0].split('#')[0]));assert dep in tree,(n,dep);pending.append(dep)
assert len(seen)<250 and sum(len(b) for b in seen.values())<16*1024**2
missing={n:b for n,b in seen.items() if not (W/n).exists()}
for n,b in seen.items():
 if (W/n).exists():assert (W/n).read_bytes()==b,n
record={'base':BASE,'selectedFiles':len(seen),'selectedBytes':sum(len(b) for b in seen.values()),'missingFiles':len(missing),'missingBytes':sum(len(b) for b in missing.values()),'files':[{'path':n,**tree[n],'sha256':sha(b),'wasMissing':n in missing} for n,b in sorted(seen.items())]}
assert shutil.disk_usage(R).free>=512*1024**2+record['missingBytes']+2_000_000
assert record['missingBytes']+sum(f.stat().st_size for f in P.rglob('*') if f.is_file())<32*1024**2
(P/'hydration-plan.json').write_text(json.dumps(record,indent=2)+'\n')
for n,b in missing.items():p=W/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
(P/'baseline-test.mjs').write_bytes(raw)
print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))
