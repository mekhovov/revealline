#!/usr/bin/env python3
"""Admit exact production inputs only; --execute-after-tests is a parent acknowledgment.

Default invocation is read-only. This helper does not run generation or tests.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import stat
import struct
import subprocess

HERE = Path(__file__).resolve().parent
PIN = "ffd3c8ba51eb64bd179f8bb6be48702341ebdb59e417e628c18d24cd752eb26d"
HEAD = "902bd54002734f16d83f7ee96a1a49859dba87e6"
TARGET = Path("/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/p03-final-integration")


def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def digest(body):
    return hashlib.sha256(body).hexdigest()


def ordinary(path):
    for entry in (path, *path.parents):
        require(not entry.is_symlink(), f"Unexpected symlink: {entry}")


def verify(path, row):
    ordinary(path)
    require(path.is_file(), f"Missing regular file: {path}")
    body = path.read_bytes()
    require(len(body) == row["bytes"] and digest(body) == row["sha256"], f"Changed bytes: {path}")
    expected_exec = row.get("mode") == "100755" if "mode" in row else row["executable"]
    require(bool(path.stat().st_mode & stat.S_IXUSR) == expected_exec, f"Changed mode: {path}")
    return body


def footprint(*roots):
    logical = allocated = 0
    for root in roots:
        for directory, dirs, files in os.walk(root, followlinks=False):
            for path in [Path(directory), *(Path(directory) / name for name in files + dirs)]:
                info = path.lstat()
                require(not stat.S_ISLNK(info.st_mode), f"Unexpected symlink: {path}")
                if path != Path(directory) and stat.S_ISDIR(info.st_mode):
                    continue
                allocated += info.st_blocks * 512
                if stat.S_ISREG(info.st_mode):
                    logical += info.st_size
    return {"logicalBytes": logical, "allocatedBytes": allocated}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute-after-tests", action="store_true")
    args = parser.parse_args()
    raw = (HERE / "intake.json").read_bytes()
    require(digest(raw) == PIN, "Intake changed; review a new helper pin.")
    manifest = json.loads(raw)
    require(manifest["sourceCommit"] == HEAD and manifest["worktree"] == str(TARGET), "Wrong source/target.")
    if not args.execute_after_tests:
        print(json.dumps({"status": "PREPARED_NOT_EXECUTED", "source": HEAD,
            "existingSourceFiles": 398, "additionalSourceFiles": 216, "prettierFiles": 56,
            "plannedPeakBytes": manifest["budget"]["plannedPeakBytes"],
            "parentMustWaitForCurrentTests": True, "generationIncluded": False}, indent=2))
        return
    ordinary(TARGET)
    require(not (HERE / "admission-receipt.json").exists() and not (HERE / "admission-failure.json").exists(),
            "Prior attempt exists; inspect it rather than rerunning.")
    options = ["-c", "core.hooksPath=/dev/null", "-c", "core.autocrlf=false"]

    def git(*args, data=None, checked=True):
        result = subprocess.run(["git", *options, "-C", str(TARGET), *args], input=data,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        require(not checked or result.returncode == 0, result.stderr.decode(errors="replace"))
        return result

    filters = git("config", "--get-regexp", r"^filter\..*\.(clean|smudge|process|required)$", checked=False)
    require(filters.returncode in (0, 1), "Cannot inspect checkout filters.")
    for line in filters.stdout.decode().splitlines():
        key = line.split(" ", 1)[0]
        options.extend(["-c", key + ("=false" if key.endswith(".required") else "=")])
    require(git("rev-parse", "HEAD").stdout.decode().strip() == HEAD, "HEAD changed; rebind admission.")
    require(git("rev-parse", "HEAD^{tree}").stdout.decode().strip() == manifest["sourceTree"], "Tree mismatch.")
    require(not git("status", "--porcelain", "--untracked-files=no").stdout, "Tracked source/index is not clean.")
    before_index = git("ls-files", "--stage", "-z").stdout
    require(len(before_index.split(b"\0")) - 1 == manifest["fullIndexEntries"]
            and digest(before_index) == manifest["fullIndexSha256"], "Complete logical index mismatch.")
    source = {row["path"]: row for row in manifest["sourceFiles"]}
    require(len(source) == 614 and len(manifest["existingPaths"]) == 398
            and len(manifest["additionalPaths"]) == 216 and len(manifest["prettierFiles"]) == 56, "Admission counts changed.")
    patterns = "".join("/" + path + "\n" for path in sorted(source)).encode()
    require(patterns == (HERE / "union-sparse-patterns.txt").read_bytes(), "Sparse patterns changed.")
    for path in manifest["existingPaths"]:
        verify(TARGET / path, source[path])
    for path in manifest["additionalPaths"]:
        require(not (TARGET / path).exists(), f"Additional path already exists: {path}; inspect before admission.")
    for row in source.values():
        actual = git("ls-tree", "HEAD", "--", row["path"]).stdout
        require(actual == f"{row['mode']} blob {row['gitBlob']}\t{row['path']}\n".encode(), "Source mode/blob mismatch.")
        body = git("cat-file", "blob", row["gitBlob"]).stdout
        require(len(body) == row["bytes"] and digest(body) == row["sha256"], "Source blob bytes mismatch.")
    package = TARGET / "node_modules/prettier"
    ordinary(package)
    require(not package.exists(), "Prettier target already exists; do not overwrite it.")
    for row in manifest["prettierFiles"]:
        require(row["path"].startswith("node_modules/prettier/") and ".." not in Path(row["path"]).parts,
                "Invalid package path.")
        verify(Path(row["originalPath"]), row)
    admin = Path(git("rev-parse", "--absolute-git-dir").stdout.decode().strip())
    before = footprint(TARGET, admin)
    reserves = manifest["budget"]["reserves"]
    future_reserve = sum(value for key, value in reserves.items() if key != "gitAndDirectoryMetadata")
    added = sum(math.ceil(source[path]["bytes"] / 4096) * 4096 for path in manifest["additionalPaths"])
    added += sum(math.ceil(row["bytes"] / 4096) * 4096 for row in manifest["prettierFiles"])
    cap = manifest["budget"]["capBytes"]
    require(max(before.values()) + added + future_reserve + 2 * 1024**2 <= cap, "Current window has insufficient headroom.")
    require(shutil.disk_usage(TARGET).free >= cap + 2 * 1024**3, "Insufficient free disk reserve.")
    require(not (TARGET / "authoring/library/fpv-field-kit/production.rltheme.lock").exists(), "Existing producer lock.")
    require(not list((TARGET / "game/presentation").glob(".presentation-stage-*")), "Existing compiler stage; inspect ownership.")
    require(not list((TARGET / "authoring/library/fpv-field-kit").glob("production.rltheme.tmp-*")), "Existing ledger temporary.")
    steps = []
    try:
        git("sparse-checkout", "set", "--no-cone", "--no-sparse-index", "--stdin", data=patterns)
        steps.append("Admitted the exact 614-path union without dropping original source paths.")
        package.mkdir(parents=True, exist_ok=False)
        for row in manifest["prettierFiles"]:
            destination = TARGET / row["path"]
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("xb") as stream:
                stream.write(verify(Path(row["originalPath"]), row))
            destination.chmod(0o755 if row["executable"] else 0o644)
        steps.append("Copied the 56 exact pinned regular Prettier files into the absent owned package.")
        for row in manifest["sourceFiles"] + manifest["prettierFiles"]:
            verify(TARGET / row["path"], row)
        require(git("ls-files", "--stage", "-z").stdout == before_index, "Logical index changed.")
        require(not git("status", "--porcelain", "--untracked-files=no").stdout, "Tracked source changed.")
        require(git("config", "--bool", "--get", "index.sparse").stdout.strip() == b"false", "Sparse index enabled.")
        compiled = TARGET / "game/presentation/compiled"
        old = json.loads((compiled / "manifest.json").read_bytes())
        require({path.relative_to(compiled).as_posix() for path in compiled.rglob("*") if path.is_file()}
                == {"manifest.json", *(row["path"] for row in old["files"])}, "Old compiler directory is incomplete or unmanaged.")
        require(len(old["files"]) + 1 == 131, "Old compiler inventory count mismatch.")
        ledger = (TARGET / "authoring/library/fpv-field-kit/production.rltheme").read_bytes()
        require(ledger[:8] == b"RLTHM1\r\n", "Bad ledger header.")
        length = struct.unpack(">I", ledger[8:12])[0]
        rows = json.loads(ledger[12:12 + length])["assets"]
        assets = {row["sha256"]: row for row in old["files"] if row["path"].startswith("assets/")}
        require(len(rows) == 127 and set(assets) == {row["sha256"] for row in rows}, "Historical original set mismatch.")
        offset = 12 + length
        for row in rows:
            body = ledger[offset:offset + row["bytes"]]
            require(len(body) == row["bytes"] and digest(body) == row["sha256"], "Historical ledger original mismatch.")
            require(body == (compiled / assets[row["sha256"]]["path"]).read_bytes(), "Compiled original differs from ledger.")
            offset += row["bytes"]
        require(offset == len(ledger) and sum(row["bytes"] for row in rows) == 4007816, "Ledger payload size mismatch.")
        after = footprint(TARGET, admin)
        require(max(after.values()) + future_reserve <= cap, "Admitted window exceeds reserved production headroom.")
        receipt = {"status": "ADMITTED_ONLY_NOT_GENERATED_NOT_TESTED", "source": HEAD,
            "parentAcknowledgedTestsFinished": True, "intakeSha256": PIN, "sourceFiles": 614,
            "prettierFiles": 56, "fullIndexEntries": manifest["fullIndexEntries"],
            "indexSha256": digest(before_index), "verifiedOldCompiledFiles": 131,
            "verifiedHistoricalOriginals": 127, "before": before, "after": after,
            "futureGenerationReserveBytes": future_reserve, "capBytes": cap, "steps": steps}
        (HERE / "admission-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps(receipt, indent=2))
    except BaseException as error:
        (HERE / "admission-failure.json").write_text(json.dumps({"error": str(error), "completedSteps": steps,
            "status": "RETAINED_FOR_PARENT_INSPECTION", "automaticCleanup": False}, indent=2) + "\n")
        raise


if __name__ == "__main__":
    main()
