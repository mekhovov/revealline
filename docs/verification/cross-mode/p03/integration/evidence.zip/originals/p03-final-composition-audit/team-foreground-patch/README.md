# Team foreground lifecycle correction candidate

Prepared outside the game worktree from `902bd54002734f16d83f7ee96a1a49859dba87e6`. The exact original bodies and their hashes are in `base/` and `base-pins.json`; candidates and patch hashes are recorded separately. **Not applied or tested by this reviewer.** Prettier parsed/formatted only these two external copies; `format.*` retains that command and output.

## Concrete source finding

The original Team `suspend()` calls `pause()`, which returns immediately if the core was already paused. That leaves its menu router and reading owner active. Team's update loop still polls and routes menu input while unfocused/hidden, and Resume lacks its own foreground guard. A held reading/menu direction or newly pressed Confirm can therefore reach an already-paused, visible but unfocused Team page. Versus already explicitly clears and gates this lifecycle.

This is inherited behavior exposed during P03 acceptance review, not a claimed browser reproduction. The separately held P18 candidate `97063f0ed85087c438a238ad864ed24bead2ee17` concerns detached-control presentation attribute ownership in `game/presentation/host.mjs`. Its Team source is older and has no correction for this foreground problem. No P18 source was imported.

## Minimal fix

`02-runtime-fix.patch` changes only `game/couch/relay-rescue.mjs`:

- Track inactive lifecycle separately from `document.hasFocus()`, so persisted pagehide and blur are effective even before browser properties change.
- Suspend always clears physical input, command batch, menu router and reader, even when the core was already paused. It retains the paused attempt and shared sound preferences/feedback.
- Inactive frames do not poll controllers, navigate, paint or step. A frame also detects an unfocused document if a notification was missed.
- Start and Resume independently reject inactive/unfocused pages.
- Focus, visible return and pageshow permit menu sampling again with cleared/neutral-gated input. They do not focus a control or resume play.
- Remove the added focus/pageshow return listeners during terminal disposal.

The patch does not change Team's existing fresh-direction rule after explicit Resume, the core simulation, strict picture/asset identity, audio production, storage, saved campaigns or menu visuals. Broader listener/presentation lifetime work remains P18.

## Failing-then-passing verification proposal

The parent can apply `01-tests-only.patch` first after the strict Team theme/production binding is usable, then run the complete `game/test/coop-host.test.mjs`. These four added cases are expected to fail the unchanged host; that is an expectation, not an executed result. Preserve the baseline stdout/stderr/exits and physical hashes. Then apply the runtime patch and rerun the same complete file on both pinned Node versions. The existing complete `couch-reading.test.mjs`, `couch-audio-master.test.mjs` and `coop-picture-host.test.mjs` provide the adjacent reading, P02 sound and async-picture gates. All four files already belong to the reviewed 39-file admission.

Three parameterized cases begin with actual paused Team Help, a genuinely joined modeled controller and an active reading direction. Blur, hidden document, and persisted pagehide must retire Done/reader immediately without stealing focus, block all subsequent hardware polling and reject direct stale Resume. Foreground return with Confirm held remains paused. A neutral release, Back out of Help and an explicit keyboard Resume then advance the actual game clock. The fourth case removes focus without dispatching blur; the next frame must pause before polling/stepping, retain the attempt, and still require explicit Resume later.

Assertions use the existing real Team host, actual markup, reader/router, both-player core and painter observation, HUD/progress, audio note/status and native button activation boundary. The getGamepads counter observes the external API boundary, not a private helper call. No synthetic run or guessed theme revision is substituted. Paint hashes/HUD are observable state evidence, not private Team checkpoint, browser pixels, audible output or physical device certification.

## Concise native acceptance matrix after qualification

Retain actual source/version, URL, viewport, input, result and original screenshot/AX for each relevant state; do not create another acceptance framework.

| Journey | Modes and input | Required observation |
|---|---|---|
| Title → mode choice → Ready → Start | Solo, Versus, Team; keyboard | Correct named mode/art, visible focus; preparation does not start a flight |
| Live cut → Pause → Help → read → Done/Escape → Back | All three; keyboard | Each action exits one layer; clock/cut remain paused; only explicit Resume continues |
| Active Help → native text pan → Done | Versus and Team; real browser pointer/touch emulation, physical touch separately | Browser owns scrolling; Done remains usable, ends once and does not Resume |
| Active reader → rotate/resize, with Plain/Large text | Versus and Team; portrait 390×844 and short landscape 844×390 | Current text/Done remains visible inside its actual panel; no new focus or game tick |
| Paused Help or Options → leave focus/tab → return | Versus and Team; actual focus changes | No background menu actions or automatic Resume; retired reader/held input needs deliberate new input |
| Sound edit → Help → Back to Options | Versus and Team | P02 master state and permanent Team explanation survive; relevant warning stays separate |
| Completed Results → Next Cancel/refusal → Help/View → Retry | Versus, plus Solo reward/story return | Previous result and full picture remain usable; no duplicate reward; sound intent survives |
| Change setup/mode → Stay/Back; then explicit departure | All three | Correct opener and still-paused attempt on cancellation; fixed destination only after explicit choice |

A real controller journey must separately demonstrate join/neutral gating, reading navigation, Back, Options edits, Resume and disconnect. Automated pad descriptors and resized desktop screenshots cannot close that physical-device gate. Optional story Skip/end/close focus, Collection/Library recovery, remaining player screens, full source/production/public/offline gates and P05 visual acceptance retain their existing separate scopes.
