#!/usr/bin/env python3
"""Finite P03 test runner. Default is a plan; execution needs an explicit group.

This records the actual physical working source, not a historical HEAD claim.
It never fills sparse files, installs modules, stages, generates, or repairs.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time

ROOT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
WT = ROOT / '.cache/worktrees/p03-final-integration'
HERE = ROOT / '.cache/p03-final-composition-audit/integration-runner-review'
MANIFEST = ROOT / '.cache/p03-final-composition-audit/a1a5-workspace-preparation/manifest.json'
MANIFEST_SHA = '434b5510b8d1fea98f7d9f4d8fcbe5fa9201e19f4c05042cad2dcf7a1d99bf98'
CAP = 104857600
OUTPUT_CAP = 16777216
NODES = [
    ('20.19.5', Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node/20.19.5/bin/node'), 88452192, 'c37b0c15f83f1b63c4b162c6f47e586ed6b00ac9ed093037fe679f676f9d2195'),
    ('22.22.2', Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node'), 112989184, '5c899797c4eb8f1db5563eea56538342ddb3e9276ee1b04a5a1f0f1023d2b011'),
]

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args], env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})

def physical_files(directory):
    result = []
    for base, dirs, files in os.walk(directory, followlinks=False):
        for name in dirs + files:
            p = Path(base) / name
            if p.is_symlink():
                raise RuntimeError(f'Symlink is outside finite physical admission: {p}')
        result.extend(Path(base) / name for name in files if not (Path(base) == directory and name == '.git'))
    return result

def snapshot(admitted):
    paths = physical_files(WT)
    names = {p.relative_to(WT).as_posix() for p in paths}
    if names != admitted:
        raise RuntimeError(f'Physical admission mismatch: missing={sorted(admitted-names)}, extra={sorted(names-admitted)}')
    rows = []
    for p in sorted(paths):
        info = p.stat()
        if not stat.S_ISREG(info.st_mode):
            raise RuntimeError(f'Non-ordinary input {p}')
        rows.append({'path': p.relative_to(WT).as_posix(), 'bytes': info.st_size,
                     'mode': oct(stat.S_IMODE(info.st_mode)), 'sha256': digest(p)})
    total = sum(row['bytes'] for row in rows)
    admin = Path(git('rev-parse', '--absolute-git-dir').decode().strip())
    admin_bytes = sum(p.stat().st_size for p in physical_files(admin))
    if total + admin_bytes > CAP:
        raise RuntimeError(f'Worktree logical bytes including Git administration exceed {CAP}')
    unmerged = git('ls-files', '-u')
    if unmerged:
        raise RuntimeError('Unresolved merge entries remain; do not test a partial composition.')
    return {'files': rows, 'inputBytes': total, 'gitAdministrationBytes': admin_bytes,
            'headObservation': git('rev-parse', 'HEAD').decode().strip(),
            'indexSha256': hashlib.sha256(git('ls-files', '-s', '-z')).hexdigest(),
            'status': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
            'qualificationBasis': 'Actual complete physical source and fixture hashes; HEAD is an observation only.'}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--group', choices=['non-team', 'team'])
    parser.add_argument('--attempt')
    parser.add_argument('--team-rebinding-reviewed', action='store_true')
    args = parser.parse_args()
    if digest(MANIFEST) != MANIFEST_SHA:
        raise RuntimeError('Reviewed 398-path/39-test admission changed.')
    manifest = json.loads(MANIFEST.read_text())
    tests = manifest['minimumCompleteTests']
    admitted = {row['path'] for row in manifest['variants']}
    if len(tests) != 39 or len(set(tests)) != 39 or len(admitted) != 398 or not set(tests) <= admitted:
        raise RuntimeError('Unexpected complete test/path inventory.')
    team = [p for p in tests if Path(p).name.startswith('coop-') or Path(p).name in {'couch-reading.test.mjs', 'couch-audio-master.test.mjs'}]
    other = [p for p in tests if p not in team]
    if len(team) != 9 or len(other) != 30:
        raise RuntimeError('Unexpected whole-file group split.')
    plan = {'status': 'PREPARED_NOT_EXECUTED', 'worktree': str(WT), 'manifestSha256': MANIFEST_SHA,
            'groups': {'non-team': other, 'team': team},
            'nodes': [{'version': v, 'path': str(p), 'bytes': n, 'sha256': h} for v,p,n,h in NODES],
            'scope': '39 complete files, sequential runtime groups; no browser, production, hardware or phase acceptance.'}
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return 0
    if not args.group or not args.attempt or not re.fullmatch('[a-z0-9][a-z0-9-]{0,63}', args.attempt):
        raise RuntimeError('Execution requires an explicit group and a fresh bounded attempt name.')
    if args.group == 'team' and not args.team_rebinding_reviewed:
        raise RuntimeError('Team is held until parent review of actual strict theme/production rebinding.')
    out = HERE / 'attempts' / args.attempt
    out.parent.mkdir(exist_ok=True)
    out.mkdir()  # Never overwrite an original attempt, even one that failed.
    write(out / 'plan.json', plan)
    write(out / 'runner.json', {'path': str(Path(__file__)), 'sha256': digest(Path(__file__))})
    results = []
    try:
        initial = snapshot(admitted)
        write(out / 'before-all.json', initial)
        selected = plan['groups'][args.group]
        environment = os.environ.copy()
        removed = {}
        for name in ['NODE_OPTIONS', 'NODE_PATH', 'NODE_COMPILE_CACHE']:
            if name in environment:
                removed[name] = 'Removed; original value intentionally not recorded.'
                del environment[name]
        write(out / 'environment.json', {'removed': removed, 'forcedModuleInferenceFlags': []})
        for version, node, size, sha in NODES:
            if node.is_symlink() or node.stat().st_size != size or digest(node) != sha:
                raise RuntimeError(f'Node {version} executable differs from reviewed original.')
            actual_version = subprocess.check_output([str(node), '--version'], env=environment).decode().strip()
            if actual_version != 'v' + version:
                raise RuntimeError(f'Unexpected Node version: {actual_version}')
            before = snapshot(admitted)
            write(out / f'node{version}.before.json', before)
            if before != initial:
                raise RuntimeError('Physical inputs or source index changed between runtime runs.')
            command = [str(node), '--test', '--test-concurrency=1', '--test-reporter=tap', *selected]
            stdout_path = out / f'node{version}.stdout.log'
            stderr_path = out / f'node{version}.stderr.log'
            start = time.monotonic()
            termination = None
            with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
                process = subprocess.Popen(command, cwd=WT, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
                while process.poll() is None:
                    if time.monotonic() - start > 900:
                        termination = '900 second group timeout'
                    if stdout_path.stat().st_size + stderr_path.stat().st_size > OUTPUT_CAP:
                        termination = '16 MiB raw output bound exceeded'
                    if termination:
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
                        break
                    time.sleep(0.5)
                code = process.wait()
            write(out / f'node{version}.exit.json', {'command': command, 'exit': code, 'termination': termination, 'seconds': time.monotonic()-start})
            after = snapshot(admitted)
            write(out / f'node{version}.after.json', after)
            counts = {}
            for line in stdout_path.read_text(errors='replace').splitlines():
                match = re.fullmatch(r'# (tests|pass|fail|cancelled|skipped|todo) (\d+)', line)
                if match:
                    counts[match[1]] = int(match[2])
            passed = code == 0 and not termination and before == after and counts.get('tests', 0) > 0 and counts.get('tests') == counts.get('pass') and all(counts.get(k) == 0 for k in ['fail', 'cancelled', 'skipped', 'todo'])
            result = {'version': version, 'command': command, 'completeFiles': len(selected), 'exit': code,
                      'termination': termination, 'seconds': time.monotonic()-start, 'counts': counts,
                      'inputsUnchanged': before == after, 'passed': passed,
                      'stdout': {'bytes': stdout_path.stat().st_size, 'sha256': digest(stdout_path)},
                      'stderr': {'bytes': stderr_path.stat().st_size, 'sha256': digest(stderr_path)}}
            write(out / f'node{version}.receipt.json', result)
            results.append(result)
            print(json.dumps(result), flush=True)
            if not passed:
                break
        final = snapshot(admitted)
        write(out / 'after-all.json', final)
        success = len(results) == 2 and all(r['passed'] for r in results) and initial == final
        write(out / 'result.json', {'status': 'PASS' if success else 'FAIL', 'group': args.group,
                                  'results': results, 'physicalInputsUnchanged': initial == final,
                                  'otherGroup': 'Not executed by this invocation; retain its separate original evidence.',
                                  'phaseAccepted': False})
        return 0 if success else 1
    except BaseException as error:
        write(out / 'failure.json', {'status': 'FAIL_RETAINED', 'error': f'{type(error).__name__}: {error}', 'completedResults': results})
        raise

if __name__ == '__main__':
    sys.exit(main())
