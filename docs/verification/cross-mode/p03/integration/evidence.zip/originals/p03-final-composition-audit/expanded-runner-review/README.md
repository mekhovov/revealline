# Expanded P03 test runner — prepared, not executed

`run-cohort.py` revises the existing runner for the approved production window. `run-cohort.diff` is the complete change against the preserved earlier runner. Only cache files were written; no source, index, admission, generation or test execution occurred.

The runner composes the pinned **614-path source admission** with three explicitly named paths in `production-test-extension.json`:

- `game/test/presentation-production-history.test.mjs` — complete optional production-history test.
- `game/test/fixtures/production-p01-v0574.json` — exact existing published P01 oracle, 1,413 bytes, SHA-256 `99adb3dc9f9566b2381d940dd045b928cd7573e8586e1b6afe188aaf6dec3e45`.
- `game/test/fixtures/production-p02-v0581.json` — reviewed published P02 oracle, 1,435 bytes, SHA-256 `60d52efd727f8fc3524fbb6a0fb63803253ae5ec83dcbe6d50cd2baf140d9ce3`.

Thus the explicit expected window is **617 source/output/test files + 56 pinned Prettier files = 673 physical files**. `expanded-sparse-patterns.txt` names all 617 source paths individually. It is a proposed parent admission, not an applied sparse change. The new test's literal imports already belong to the canonical producer's admitted dependency closure. The test's final edited body is recorded per attempt; both immutable oracle files must retain their exact pins.

The original **39 whole-file cohort** remains unchanged: **30 non-Team files** and **9 Team files**. The optional `production` group adds the **one complete production-history file**, for 40 named files in total. `--files` may select unique complete files only within the chosen group; it never selects individual test names. Unrun groups remain explicitly unqualified.

## What changes in verification

- Each attempt captures fresh bytes, modes and SHA-256 for every physical runtime input. Legitimate regenerated ledger/compiled JSON, story/Gallery corrections and the two seam-test edits are recorded as their actual current bodies, not rejected for differing from the old source. HEAD is an observation, not a claim that changed working bytes are committed.
- The actual compiled ownership manifest must match all 131 current output files and the ledger's actual source identity. All 127 historical payload originals / 4,007,816 bytes are hashed and checked against compiled identities. This finite recipe-only window adds no new image paths; another output path requires a named admission update. These checks do not replace canonical `--check`, model qualification or recipe approval.
- All HEAD paths must remain in the full logical index. Only the three named extension paths may be new index entries before a later commit. The exact full index listing is retained before/after; unresolved stages and missing historical paths refuse. Raw index cache allocation is not treated as staged-content authority.
- Actual source, Prettier, per-worktree Git administration and owned test-temporary bytes count toward **100 MiB**, using the larger of logical and allocated size. The runner samples this during execution and terminates on observed excess. Exact settled footprints and sampled peaks are recorded separately; this is not a guarantee about an unsampled transient peak or process RAM.
- Each attempt gets a private temporary directory, passed through `TMPDIR`, `TMP` and `TEMP`. The tests must retire their temporary fixtures; leftovers remain available for inspection and fail the attempt. Symlink targets in transient fixtures are not traversed or double-counted. Settled source inputs still reject symlinks.
- Existing Node binary pins, sequential execution, 900-second group timeout and 16 MiB raw stdout/stderr bound per runtime remain. Node executables stay external and are not copied into the source window. Evidence reports/logs are separately bounded outside the worktree. A monitoring exception or interruption also terminates the owned test process group.

Only logical input identity, HEAD/tree observations, the semantic index listing, status and production identity determine before/after preservation. Temporary-directory allocation and Git cache allocation are recorded and capacity-checked separately; they cannot manufacture an input-change failure.

## Parent execution after review

First admit the three exact source paths, apply the reviewed history-test update and finish canonical generation. Review the actual strict Team theme binding before using the Team flag. The earlier 614-path helper is immutable and should not be rerun over the now-populated window.

```sh
python3 /Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/p03-final-composition-audit/expanded-runner-review/run-cohort.py --execute --group non-team --node 22.22.2 --attempt expanded-non-team-node22
python3 /Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/p03-final-composition-audit/expanded-runner-review/run-cohort.py --execute --group team --team-rebinding-reviewed --attempt expanded-team
python3 /Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/p03-final-composition-audit/expanded-runner-review/run-cohort.py --execute --group production --attempt expanded-production
```

These are proposed commands, not execution receipts. Omitting `--node` runs both pinned runtimes sequentially. Use a fresh attempt name every time; original failed/passed attempts are never overwritten. The runner's default invocation prints the plan without running tests. This preparation only parsed the runner for Python syntax; it did not invoke that entry point.

Before/after hash manifests identify the exact tested inputs. They do not reconstruct uncommitted bodies by themselves: preserve the actual candidate/patch or its later commit when recording final qualification. No passing subset, generated identity or runner result accepts P03, physical devices or a public release.
