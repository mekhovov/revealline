"""Package reviewed original P03 evidence in cache; never run tests or modify Git."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import zipfile

ROOT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
HERE = Path(__file__).resolve().parent
OUT = HERE / 'delivery'
LIMIT = 5 * 1024**2
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda obj: (json.dumps(obj, indent=2, ensure_ascii=False) + '\n').encode()


def read(path):
    assert path.is_file() and not path.is_symlink(), path
    assert not any(p.is_symlink() for p in path.parents), path
    assert path.stat().st_size <= 2 * 1024**2, path
    return path.read_bytes()


def load(path):
    return json.loads(read(path))


def pin(path):
    raw = read(path)
    return {'sourcePath': str(path.relative_to(ROOT)), 'bytes': len(raw), 'sha256': sha(raw)}


def verified(row):
    raw = read(ROOT / row['sourcePath'])
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['sourcePath']
    return raw


def review_attempt(folder, expected_status, expected_runs=None):
    result = load(folder / 'result.json')
    assert result['status'] == expected_status and result['phaseAccepted'] is False
    assert result['physicalInputsUnchanged'] is True
    observed = []
    for run in result['results']:
        prefix = 'node' + run['version']
        assert load(folder / (prefix + '.receipt.json')) == run
        exit_record = load(folder / (prefix + '.exit.json'))
        assert all(exit_record[k] == run[k] for k in ['command', 'exit', 'termination'])
        assert run['inputsUnchanged'] and run['termination'] is None
        for stream in ['stdout', 'stderr']:
            raw = read(folder / (prefix + '.' + stream + '.log'))
            assert {'bytes': len(raw), 'sha256': sha(raw)} == run[stream]
        tap = read(folder / (prefix + '.stdout.log')).decode()
        counts = {k: int(re.findall(r'^# ' + k + r' (\d+)\s*$', tap, re.M)[-1])
                  for k in ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']}
        assert counts == run['counts']
        if expected_status == 'PASS':
            assert run['exit'] == 0 and run['passed'] and counts['tests'] == counts['pass']
            assert not any(counts[k] for k in ['fail', 'cancelled', 'skipped', 'todo'])
        before = load(folder / (prefix + '.before.json'))
        after = load(folder / (prefix + '.after.json'))
        assert {k: v for k, v in before.items() if k != 'windowFootprint'} == {
            k: v for k, v in after.items() if k != 'windowFootprint'}
        observed.append({'node': run['version'], 'completeFiles': run['completeFiles'], 'counts': counts})
    if expected_runs is not None:
        assert observed == expected_runs
    return {'attempt': str(folder.relative_to(ROOT)), 'status': result['status'],
            'runs': observed, 'phaseAccepted': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    intake = load(HERE / 'intake.json')
    if not args.execute:
        print(json.dumps({'status': 'PREPARED_NOT_PACKAGED', 'output': str(OUT),
                          'originalsPinned': len(intake['originals']),
                          'pending': intake['pendingAttempt']['path'],
                          'compressedLimitBytes': LIMIT, 'phaseAccepted': False}, indent=2))
        return
    assert not OUT.exists(), 'Use a new reviewed output for another delivery; never overwrite.'
    rows = list(intake['originals'])
    for row in rows:
        verified(row)
    summaries = [review_attempt(ROOT / a['path'], a['expectedStatus'], a['runs'])
                 for a in intake['completedAttempts']]

    # The only late-bound directory is this exact completed two-Node Versus attempt.
    pending = intake['pendingAttempt']
    folder = ROOT / pending['path']
    completion = load(HERE / 'versus-completion.json')
    for row in completion['originals']:
        verified(row)
    for row in pending['pinnedAlreadyStableInputs']:
        verified(row)
    expected_files = set(pending['requiredFiles'])
    assert {p.name for p in folder.iterdir() if p.is_file()} == expected_files
    assert all(p.is_file() or p.name == 'tmp' and p.is_dir() and not any(p.iterdir())
               for p in folder.iterdir())
    assert {r['sourcePath'] for r in completion['originals']} == {
        str((folder / name).relative_to(ROOT)) for name in expected_files}
    final = review_attempt(folder, pending['requiredStatus'], completion['expectedRuns'])
    assert [r['node'] for r in final['runs']] == pending['requiredNodes']
    summaries.append(final)
    rows.extend(completion['originals'])
    rows.extend(pin(HERE / name) for name in ['package-evidence.py', 'intake.json', 'versus-completion.json', 'README.md'])
    assert len(rows) == len({r['sourcePath'] for r in rows})

    # Retain each unique original body once; every omitted duplicate is an exact alias.
    original_members = {}
    members = {}
    for row in sorted(rows, key=lambda r: r['sourcePath']):
        raw = verified(row)
        key = (row['bytes'], row['sha256'])
        member = original_members.setdefault(key, 'originals/' + row['sourcePath'].removeprefix('.cache/'))
        if member in members:
            assert raw == members[member]
        else:
            members[member] = raw
        row['member'] = member
    # Runner bodies are original preserved versions, even where historical paths were reused.
    for a in [*intake['completedAttempts'], pending]:
        captured_runner = load(ROOT / a['path'] / 'runner.json')
        assert any(r['sha256'] == captured_runner['sha256'] and r['sourcePath'].endswith('.py') for r in rows)
    index_rows = [r for r in rows if '/full-index.' in r['sourcePath']]
    assert len({r['sha256'] for r in index_rows}) == 1
    for a in [pending, *intake['completedAttempts']]:
        folder = ROOT / a['path']
        if (folder / 'full-index.before.txt').exists():
            assert read(folder / 'full-index.before.txt') == read(folder / 'full-index.after.txt')

    versus_lines = '\n'.join(f"| Versus final seams | {r['node']} | {r['completeFiles']} | "
                             f"{r['counts']['pass']}/{r['counts']['tests']} | Passing final seam cohort |"
                             for r in final['runs'])
    readme = (read(HERE / 'README.md').decode().replace('@@VERSUS_ROWS@@', versus_lines)
              .replace('@@BUNDLE_STATE@@', 'Packaged original evidence; independent review and P03 acceptance remain separate.')).encode()
    manifest = {'format': 'revealline-integration-evidence.v1', 'phase': 'P03', 'phaseAcceptance': False,
                'scope': 'Original focused source runs, failed attempts, preparation/admission and initial production output. No browser/public/full-phase qualification.',
                'attempts': summaries, 'files': sorted(rows, key=lambda r: r['sourcePath']),
                'originalFiles': len(rows), 'originalBytes': sum(r['bytes'] for r in rows),
                'uniqueStoredOriginalFiles': len(members), 'uniqueStoredOriginalBytes': sum(map(len, members.values())),
                'duplicatePolicy': 'Identical bytes stored once. Every original path, size and hash maps to its member; no original is rewritten or deleted.',
                'fullIndex': {'originalCopies': len(index_rows), 'storedCopies': 1,
                              'bytes': index_rows[0]['bytes'], 'sha256': index_rows[0]['sha256'],
                              'member': index_rows[0]['member']},
                'excludedLargeOriginal': {'source': 'c93019a344f6f4c6ac03940c77ea09c81122d911',
                    'path': 'authoring/library/fpv-field-kit/production.rltheme', 'bytes': 6829381,
                    'sha256': 'c9e893cb6970596463e06b30f93f15ecc9ca52ec311c018de7ff70a8ff042cc7',
                    'reason': 'Immutable published Git blob; exact oracle/derivation included, binary not copied.'},
                'documentation': {'path': 'README.md', 'bytes': len(readme), 'sha256': sha(readme)}}
    encoded = encode(manifest)
    members.update({'manifest.json': encoded, 'README.md': readme})
    OUT.mkdir()
    archive = OUT / 'evidence.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, raw in sorted(members.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, raw)
    assert archive.stat().st_size <= LIMIT
    with zipfile.ZipFile(archive) as z:
        assert len(z.infolist()) == len(members) and set(z.namelist()) == set(members)
        for name, raw in members.items():
            assert z.read(name) == raw
        for row in rows:
            assert z.read(row['member']) == verified(row)
    (OUT / 'manifest.json').open('xb').write(encoded)
    (OUT / 'README.md').open('xb').write(readme)
    receipt = {'status': 'PASS_ORIGINAL_BUNDLE_BYTES_ONLY', 'phaseAcceptance': False,
               'archiveBytes': archive.stat().st_size, 'archiveSha256': sha(archive.read_bytes()),
               'archiveMembers': len(members), 'originalFiles': len(rows),
               'manifestSha256': sha(encoded), 'readmeSha256': sha(readme),
               'everyOriginalAndZipMemberRehashed': True, 'gitOrSourceMutation': False,
               'testsExecutedByPackager': False, 'independentReviewPending': True}
    (OUT / 'receipt.json').open('xb').write(encode(receipt))
    assert sum(p.stat().st_size for p in OUT.iterdir()) <= LIMIT
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
