# P03 combined reading and P02 preservation review

Read-only review; no product edits, test execution, browser observation, acceptance or publication by this reviewer.

## Source scope

- Accepted P02 source: `c93019a344f6f4c6ac03940c77ea09c81122d911`.
- Full incoming reading chain: `5f6782803b6218555e3f7a419fb594e73414c95d`; its non-documentation bodies equal tested `f81b14ee69531930b98a9e83dd63d69dd46401c4`.
- Actual completed integration read for this report: `bff9a1e1c1a6a320dd90bdbbe1d68ead9bb55295`. This report reads its Git blobs, not intermediate worktree files. The parent's additional 2,205-byte story-disposal patch is a separate working delta; its four complete affected test files are already admitted.
- Admission: `a1a5-workspace-preparation/manifest.json`, SHA256 `434b5510b8d1fea98f7d9f4d8fcbe5fa9201e19f4c05042cad2dcf7a1d99bf98`: 398 exact paths, 39 complete test files. The runner preserves that finite window and records actual physical bytes before and after each runtime.

No new implementation blocker was found in this bounded review. The two recommendations below are missing combined assertions, not observed failures. Existing separate guarantees are substantial; repeat tests only after meaningful changes or when these seams are added.

## c930 preservation and incoming reading

The integrated `couch-audio-master.test.mjs` delta versus c930 is only the 16-line actual Team presentation mount/readiness adaptation. It retains the ordinary changing Mute/Unmute action-label assertions and the permanent Team note/storage-failure/recovery test. Do not replace it wholesale with the older incoming audio test file.

`game/test/couch-audio-master.test.mjs:236` covers paused Versus checkpoint and existing transport continuity through master edits. Line 301 covers paused Team HUD/status preservation and no Team audio producer. Line 336 retains the actual permanent explanation, shared storage refusal, visible warning, recovery and lack of autoplay. These are product observations, not a check for a particular element ID alone.

The incoming opt-ins remain local to the two Couch hosts. Solo defaults are exercised by `controller-navigation.test.mjs:1573` and `controller-reading.test.mjs:460`; Solo actual input/prompt coverage remains in `reading-prompts-host.test.mjs`. There is no need to enable native reading scrolling or resize revelation globally to make Couch tests pass.

`couch-reading.test.mjs` observes real host registrations and actual paused simulations: three keyboard exit keys (102), native text pan/Done (175), foreground resize (210), deliberate modality/idle pad ownership (236), and Help closure/terminal disposal (262). The Team test compares HUD, progress and painter observations; it does not expose a private authoritative Team checkpoint. The browser/device gap remains explicit.

The lower-level tests already cover rejected/nonprimary pointers, stale roots/scopes/owners, native wheel ownership, unchanged keyboard defaults, clipped ancestor client boxes, reentrancy and teardown. Repeating these as more string assertions would add little confidence.

## Prioritized combined seams

### 1. Master settings/warnings survive actual Help reading and return

Extend the existing actual Couch audio host coverage, preferably in `game/test/couch-audio-master.test.mjs`, after strict Team rebinding. Exercise both real hosts without introducing a second fake reader or audio controller:

1. Start and pause a real attempt. For Versus retain actual active music transport; Team remains explicitly without a producer.
2. Edit Mute/volume through actual controls. For Team inject the existing storage refusal so a nonempty sound warning and permanent explanation are present.
3. Close Options, open Help, enter reading, perform one native content pan and one keyboard exit, then return to Options.
4. Assert the same audio preference bytes, current warning, permanent Team sentence, ordinary action labels, and unchanged paused attempt observations. For Versus also assert unchanged transport intent, selected song/cursor and source/Play count.
5. Recover Team storage with a real subsequent edit; only the warning clears. Reading hints stay in their own Help status and do not replace sound feedback.

Why this is a real seam: the integration combines new reading `onHint`/`onReadingChange`, moved shared controls, and c930's separate permanent/live audio messages. Current audio tests stop after Options edits, while current reading tests enter Help without an active audio failure/transport fixture. Both halves can pass while an interleaved journey regresses.

### 2. A cancelled or failed completed Next preserves current sound intent

Extend `game/test/couch-static-picture-host.test.mjs` using its existing real original-art boundary and actual `couchPage` audio adapter. The existing fixture can forward the already-supported `audio` argument; all necessary soundtrack harness modules are already in the finite admission.

1. Complete an actual round using the current fixed route, and use the actual Versus Mute control before Next. Mute must retain its playing transport intent; do not invent a Versus music-Pause action to construct this case.
2. Hold the next original read/decode. Cover Cancel and decode/read refusal as two meaningful cases.
3. While Results remains visible, open Help/read/return; then allow the obsolete pending operation to settle.
4. Assert unchanged result/round identities, scores and original-image lease, still-muted sound with the same playing transport intent and selected track/cursor/source without an extra Play, and a visible enabled Results action with no automatic flight start.
5. Perform one explicit Next retry to Ready; master mute remains authoritative until actual Unmute.

Existing relevant halves: `couch-static-picture-host.test.mjs:563` (failed Next/Results/View/retry), 636 (Cancel/Help/View/setup/disposal interruption), 747 (newer deliberate focus); `soundtrack-host.test.mjs:230` (playing MP3 through a successful Solo Next), 287 (music Pause through master edits), 548 (late Studio Play versus later intent). None currently combines retained sound state with a failed/cancelled completed picture transition. Keep this test about transport ownership and retained results, not private helper invocation counts.

If the parent adds the previously proposed explicit music-Pause case, place it in the Solo `soundtrack-host.test.mjs` journey using actual Studio Pause and a held managed-picture transition. Solo exposes that real player action. Do not add a private test-only Pause call or a new player feature to Versus merely for parity; shared advertised music transport expansion remains P02-B.

## Cases already covered; do not duplicate

- Library closes/reopens during retained-save waiting: `library-launch-host.test.mjs:293`; button/controller Stay cancellation and late work: 363.
- Title completion/cancellation must not steal newer focus or resume on return: `title-entry-host.test.mjs:383` plus its delayed picture/restore cases.
- Team Cancel, late bytes/decode, Retry, and explicit Ready/Start: complete `coop-picture-host.test.mjs`, including its actual original binding preparation.
- Current P01 feedback rail and Gallery event propagation: retained c930 assertions remain in the merged full `main-menu-collection-host.test.mjs` and `gallery-focus.test.mjs`.
- Story pending Play/mute, movie identity, earned score and disposal/focus: existing four complete story files plus the parent's separately reviewed minimal extension.

## Execution and boundaries

The prepared runner separates 30 non-Team files and nine whole Team/dependent files. The latter are all seven `coop-*` files plus `couch-reading.test.mjs` and `couch-audio-master.test.mjs`. Two Team component files use injected metadata and could run earlier, but conservatively holding the complete group avoids presenting a synthetic-only subset as final Team qualification.

Keep exact theme IDs, revisions, hashes, dimensions, collection and pack identities. Generate the final producer history/registries from the composed source, then bind Team to that actual reviewed theme revision. Do not lower the runtime to the incoming theme19, replace expected values with the values under test, or skip real preparation.

The 398-path graph includes four reviewed dynamic fixture expressions resolving to eight original PNGs; three dynamic actor-image expressions are outside explicit mocked rendering boundaries. This is an intentional model boundary, not proof that production can omit runtime artwork. Final generated dependencies must be re-reviewed if paths or slots change.

This cohort remains a minimum integration seam check. It does not replace six source gates, production/history/readiness, complete player-navigation coverage, actual audible media, browser/native observations, offline/public byte audits, human playtesting or physical touch/controller acceptance. No whole P03 completion follows from these tests alone.
