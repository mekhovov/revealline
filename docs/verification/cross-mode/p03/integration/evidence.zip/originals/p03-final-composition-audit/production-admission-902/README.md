# P03 production admission — ready for parent review, not executed

Source: `902bd54002734f16d83f7ee96a1a49859dba87e6`, tree `c876896e6166b8b99dc17e40ccd1c34cebbc5d9a`. The active test run is untouched.

All **315 producer/readiness inputs** match the approved bff9 proposal byte for byte. The 614-path union has only three legitimate committed changes since that proposal: the Gallery fixture, victory-story UI test and story-disposal guard. All **398 existing physical source files** match the current committed source. The complete logical index has **7,879 entries**, including all publication history; its 973,069-byte stage listing hashes to `a1f24ee836725206ab4d64762dcd8f231d20158549422637520a679b795fc296`.

The rebound inventory is `intake.json` (**263,645 bytes**, SHA-256 `ffd3c8ba51eb64bd179f8bb6be48702341ebdb59e417e628c18d24cd752eb26d`). It contains all exact source and Prettier byte/mode pins and the accepted temporary/output allowances. The updated union's logical size is **56,173,072 bytes** including Prettier; its estimated allocated peak remains **84,395,450 bytes**, leaving **20,462,150 bytes** below the 100 MiB cap.

## Proposed helper

`admit-production.py` has been parsed for syntax without invoking it. Its full proposed addition is retained in `admit-production.diff`.

Default invocation prints the pinned preparation only. After the current Node 22 test run finishes, the parent may explicitly execute:

```sh
python3 /Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/p03-final-composition-audit/production-admission-902/admit-production.py --execute-after-tests
```

The flag acknowledges the parent's scheduling decision; it does not independently verify that the tests passed. **This command has not been run.**

The helper:

1. Requires exact HEAD/tree, clean tracked source/index, the full index pin, unchanged current 398 files, absent additional paths, absent target Prettier package, unchanged original package bytes and no producer lock/temp/stage.
2. Checks actual window allocation plus the additional files and generation reserves before admission. It also requires an independent 2 GiB free-space reserve.
3. Applies the exact **614-path non-cone sparse union**, with a full index, adding **216 tracked files**. It disables checkout hooks and content-filter executables. It does not overwrite current source with historical copies.
4. Copies **56 exact regular Prettier 3.6.2 files** into the previously absent owned package directory using exclusive file writes, preserving their executable modes. It does not install dependencies or create a symlink.
5. Verifies every source/package byte and mode, unchanged full logical index, clean tracked state and the **complete 131-file old compiled directory**. It hashes all **127 ledger original payloads / 4,007,816 bytes** and compares each against its compiled original.
6. Measures actual admitted allocation with Git administration and verifies the remaining temporary/output reserve under 100 MiB. It records `admission-receipt.json` outside the worktree. A partial failure is retained for inspection with `admission-failure.json`; there is no automatic reset or deletion.

No generation, test, source edit, staging, commit, remote operation or release runs in the helper. It does not copy the separately authenticated high-resolution provenance illustrations. The existing [canonical generation plan](../production-window-bff9/README.md) remains the authority for subsequent producer write/check, source-specific recipe review and committed-ledger readiness checks.
