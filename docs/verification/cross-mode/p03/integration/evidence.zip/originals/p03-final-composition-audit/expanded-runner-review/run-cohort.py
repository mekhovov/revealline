#!/usr/bin/env python3
"""Finite P03 test runner. Default is a plan; execution needs an explicit group.

This records the actual physical working source, not a historical HEAD claim.
It never fills sparse files, installs modules, stages, generates, or repairs.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import struct
import subprocess
import sys
import time

ROOT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
WT = ROOT / '.cache/worktrees/p03-final-integration'
HERE = ROOT / '.cache/p03-final-composition-audit/expanded-runner-review'
MANIFEST = ROOT / '.cache/p03-final-composition-audit/production-admission-902/intake.json'
MANIFEST_SHA = 'ffd3c8ba51eb64bd179f8bb6be48702341ebdb59e417e628c18d24cd752eb26d'
TEST_MANIFEST = ROOT / '.cache/p03-final-composition-audit/a1a5-workspace-preparation/manifest.json'
TEST_MANIFEST_SHA = '434b5510b8d1fea98f7d9f4d8fcbe5fa9201e19f4c05042cad2dcf7a1d99bf98'
EXTENSION = HERE / 'production-test-extension.json'
EXTENSION_SHA = 'b748b1f9f17b3fc5078382a3119e990409cbe38a357bca066795737c9c8b97dd'
TEMPORARY = None
CAP = 104857600
OUTPUT_CAP = 16777216
NODES = [
    ('20.19.5', Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node/20.19.5/bin/node'), 88452192, 'c37b0c15f83f1b63c4b162c6f47e586ed6b00ac9ed093037fe679f676f9d2195'),
    ('22.22.2', Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node'), 112989184, '5c899797c4eb8f1db5563eea56538342ddb3e9276ee1b04a5a1f0f1023d2b011'),
]

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args], env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})

def physical_files(directory):
    result = []
    for base, dirs, files in os.walk(directory, followlinks=False):
        for name in dirs + files:
            p = Path(base) / name
            if p.is_symlink():
                raise RuntimeError(f'Symlink is outside finite physical admission: {p}')
        result.extend(Path(base) / name for name in files if not (Path(base) == directory and name == '.git'))
    return result

def footprint(directory):
    # Count symlink objects without following them while tests may exercise an
    # owned temporary fixture. Settled snapshots reject all remaining symlinks.
    logical = allocated = 0
    for base, dirs, files in os.walk(directory, followlinks=False):
        for p in [Path(base), *(Path(base) / name for name in files)]:
            try:
                info = p.lstat()
            except FileNotFoundError:
                continue  # An owned test temporary retired between samples.
            allocated += info.st_blocks * 512
            if not stat.S_ISDIR(info.st_mode):
                logical += info.st_size
        for name in dirs:
            p = Path(base) / name
            if p.is_symlink():
                try:
                    info = p.lstat()
                except FileNotFoundError:
                    continue
                allocated += info.st_blocks * 512
                logical += info.st_size
    return {'logical': logical, 'allocated': allocated}

def window_footprint(admin):
    source, metadata = footprint(WT), footprint(admin)
    temporary = footprint(TEMPORARY) if TEMPORARY else {'logical': 0, 'allocated': 0}
    return {'logical': source['logical'] + metadata['logical'] + temporary['logical'],
            'allocated': source['allocated'] + metadata['allocated'] + temporary['allocated']}

def generated_inventory(records):
    base = 'game/presentation/compiled/'
    manifest_path = WT / (base + 'manifest.json')
    if manifest_path.stat().st_size > 1024 * 1024:
        raise RuntimeError('Compiled ownership manifest exceeds this finite intake.')
    current = json.loads(manifest_path.read_bytes())
    rows = current.get('files')
    if current.get('format') != 'revealline-presentation-build.v1' or not isinstance(rows, list) or len(rows) != 130:
        raise RuntimeError('The reviewed 131-file compiler-owned output changed shape.')
    seen = {base + 'manifest.json'}
    assets = {}
    for row in rows:
        name = row['path']
        if name not in {'runtime.json', 'studio.json', 'theme.css'} and not re.fullmatch(r'assets/[a-f0-9]{64}\.(png|jpg|webp|ttf|otf|woff2|wav|ogg|mp3)', name):
            raise RuntimeError('Unmanaged compiled output path.')
        name = base + name
        if name in seen or name not in records or any(records[name][key] != row[key] for key in ['bytes', 'sha256']):
            raise RuntimeError('Compiled output is incomplete or differs from its actual manifest.')
        seen.add(name)
        if row['path'].startswith('assets/'):
            assets[row['sha256']] = row
    if seen != {name for name in records if name.startswith(base)}:
        raise RuntimeError('Compiled output contains an unlisted file.')
    ledger_path = 'authoring/library/fpv-field-kit/production.rltheme'
    if records[ledger_path]['bytes'] > 32 * 1024 * 1024:
        raise RuntimeError('Production ledger exceeds its existing 32 MiB limit.')
    body = (WT / ledger_path).read_bytes()
    if body[:8] != b'RLTHM1\r\n' or len(body) < 12:
        raise RuntimeError('Invalid production ledger envelope.')
    length = struct.unpack('>I', body[8:12])[0]
    if length > 4 * 1024 * 1024 or 12 + length > len(body):
        raise RuntimeError('Invalid production ledger manifest length.')
    transfer = json.loads(body[12:12 + length])
    originals = transfer['assets']
    if len(originals) != 127 or len(assets) != 127 or {row['sha256'] for row in originals} != set(assets):
        raise RuntimeError('The reviewed 127-original production envelope changed.')
    offset = 12 + length
    for row in originals:
        part = body[offset:offset + row['bytes']]
        if len(part) != row['bytes'] or hashlib.sha256(part).hexdigest() != row['sha256'] or row['bytes'] != assets[row['sha256']]['bytes']:
            raise RuntimeError('Historical ledger original differs from compiled original identity.')
        offset += row['bytes']
    if offset != len(body) or sum(row['bytes'] for row in originals) != 4007816:
        raise RuntimeError('Production original-byte envelope changed.')
    document = transfer['document']
    if current.get('source') != {'id': document['id'], 'revision': document['revision']}:
        raise RuntimeError('Compiled source and ledger identities disagree.')
    return {'ledgerSha256': records[ledger_path]['sha256'], 'ledgerBytes': len(body),
            'manifestSha256': records[base + 'manifest.json']['sha256'],
            'actualSource': current['source'], 'compiledFiles': 131,
            'originals': 127, 'originalBytes': 4007816,
            'scope': 'Exact current ownership and original bytes; no canonical-reproduction or quality approval inferred.'}

def same_inputs(before, after):
    # Allocation is measured separately; freed temporary directory blocks are
    # not source identity, nor are mutable Git cache allocation details.
    return {k: v for k, v in before.items() if k != 'windowFootprint'} == {k: v for k, v in after.items() if k != 'windowFootprint'}

def snapshot(admitted, package, extension):
    paths = physical_files(WT)
    names = {p.relative_to(WT).as_posix() for p in paths}
    if names != admitted:
        raise RuntimeError(f'Physical admission mismatch: missing={sorted(admitted-names)}, extra={sorted(names-admitted)}')
    rows = []
    for p in sorted(paths):
        info = p.stat()
        if not stat.S_ISREG(info.st_mode):
            raise RuntimeError(f'Non-ordinary input {p}')
        rows.append({'path': p.relative_to(WT).as_posix(), 'bytes': info.st_size,
                     'mode': oct(stat.S_IMODE(info.st_mode)), 'sha256': digest(p)})
    records = {row['path']: row for row in rows}
    for row in package:
        actual = records[row['path']]
        if any(actual[key] != row[key] for key in ['bytes', 'sha256']) or bool(int(actual['mode'], 8) & stat.S_IXUSR) != row['executable']:
            raise RuntimeError('Pinned Prettier dependency changed.')
    for row in extension['additionalSourcePaths']:
        if row['kind'] == 'immutable-fixture' and any(records[row['path']][key] != row[key] for key in ['bytes', 'sha256']):
            raise RuntimeError('Published production-history fixture changed.')
    generated = generated_inventory(records)
    total = sum(row['bytes'] for row in rows)
    admin = Path(git('rev-parse', '--absolute-git-dir').decode().strip())
    physical_files(admin)  # Reject non-ordinary/symlink administration at rest.
    window = window_footprint(admin)
    if max(window.values()) > CAP:
        raise RuntimeError(f'Worktree bytes including Git administration exceed {CAP}: {window}')
    if git('ls-files', '-u'):
        raise RuntimeError('Unresolved merge entries remain; do not test a partial composition.')
    index = git('ls-files', '-s', '-z')
    index_paths = []
    for row in index.split(b'\0'):
        if not row:
            continue
        metadata, name = row.split(b'\t', 1)
        if metadata.split()[-1] != b'0':
            raise RuntimeError('Nonzero-stage index entry.')
        index_paths.append(name)
    head_paths = [row for row in git('ls-tree', '-rz', '--name-only', 'HEAD').split(b'\0') if row]
    extra_index_paths = set(index_paths) - set(head_paths)
    explicit_new_paths = {row['path'].encode() for row in extension['additionalSourcePaths']}
    if len(index_paths) != len(set(index_paths)) or not set(head_paths) <= set(index_paths) or not extra_index_paths <= explicit_new_paths:
        raise RuntimeError('Full HEAD/index preservation or named extension admission failed.')
    return {'files': rows, 'inputBytes': total, 'windowFootprint': window,
            'headObservation': git('rev-parse', 'HEAD').decode().strip(),
            'headTreeObservation': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'indexSha256': hashlib.sha256(index).hexdigest(), 'fullIndexEntries': len(index_paths),
            'status': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
            'production': generated,
            'qualificationBasis': 'Actual 617 source/output/test files and 56 pinned package files; HEAD is an observation, not a claim that changed working bytes are committed.'}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--group', choices=['non-team', 'team', 'production'])
    parser.add_argument('--attempt')
    parser.add_argument('--node', choices=['20.19.5','22.22.2'])
    parser.add_argument('--files', nargs='+', help='Exact complete files within the selected group')
    parser.add_argument('--team-rebinding-reviewed', action='store_true')
    args = parser.parse_args()
    if digest(MANIFEST) != MANIFEST_SHA or digest(TEST_MANIFEST) != TEST_MANIFEST_SHA or digest(EXTENSION) != EXTENSION_SHA:
        raise RuntimeError('Reviewed source/package or complete-file test admission changed.')
    manifest = json.loads(MANIFEST.read_text())
    tests = json.loads(TEST_MANIFEST.read_text())['minimumCompleteTests']
    extension = json.loads(EXTENSION.read_text())
    production = extension['completeTests']
    source_paths = {row['path'] for row in manifest['sourceFiles']}
    extension_paths = {row['path'] for row in extension['additionalSourcePaths']}
    if len(extension_paths) != 3 or source_paths & extension_paths or production != ['game/test/presentation-production-history.test.mjs']:
        raise RuntimeError('Unexpected production group extension.')
    source_paths |= extension_paths
    package = manifest['prettierFiles']
    package_paths = {row['path'] for row in package}
    admitted = source_paths | package_paths
    if len(tests) != 39 or len(set(tests)) != 39 or len(source_paths) != 617 or len(package) != 56 or len(package_paths) != 56 or len(admitted) != 673 or not set(tests) <= source_paths:
        raise RuntimeError('Unexpected complete test/source/package inventory.')
    team = [p for p in tests if Path(p).name.startswith('coop-') or Path(p).name in {'couch-reading.test.mjs', 'couch-audio-master.test.mjs'}]
    other = [p for p in tests if p not in team]
    if len(team) != 9 or len(other) != 30 or not set(production) <= source_paths:
        raise RuntimeError('Unexpected whole-file group split.')
    plan = {'status': 'PREPARED_NOT_EXECUTED', 'worktree': str(WT), 'manifestSha256': MANIFEST_SHA,
            'testManifestSha256': TEST_MANIFEST_SHA, 'extensionSha256': EXTENSION_SHA, 'physicalPaths': 673,
            'groups': {'non-team': other, 'team': team, 'production': production},
            'nodes': [{'version': v, 'path': str(p), 'bytes': n, 'sha256': h} for v,p,n,h in NODES],
            'scope': '39 retained complete files plus one explicitly admitted production-history file, with the current expanded production inputs, sequential runtime groups; no browser, generation, hardware or phase acceptance.'}
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return 0
    if not args.group or not args.attempt or not re.fullmatch('[a-z0-9][a-z0-9-]{0,63}', args.attempt):
        raise RuntimeError('Execution requires an explicit group and a fresh bounded attempt name.')
    if args.group == 'team' and not args.team_rebinding_reviewed:
        raise RuntimeError('Team is held until parent review of actual strict theme/production rebinding.')
    out = HERE / 'attempts' / args.attempt
    out.parent.mkdir(exist_ok=True)
    out.mkdir()  # Never overwrite an original attempt, even one that failed.
    global TEMPORARY
    TEMPORARY = out / 'tmp'
    TEMPORARY.mkdir()
    write(out / 'plan.json', plan)
    write(out / 'runner.json', {'path': str(Path(__file__)), 'sha256': digest(Path(__file__))})
    results = []
    try:
        initial = snapshot(admitted, package, extension)
        write(out / 'before-all.json', initial)
        (out / 'full-index.before.txt').write_bytes(git('ls-files', '-s', '-z'))
        selected = args.files or plan['groups'][args.group]
        if len(selected) != len(set(selected)) or not set(selected) <= set(plan['groups'][args.group]):
            raise RuntimeError('Requested files must be unique complete files in the reviewed group.')
        selected_nodes = [row for row in NODES if not args.node or row[0] == args.node]
        write(out / 'selected-scope.json', {'files': selected, 'nodes': [row[0] for row in selected_nodes]})
        environment = os.environ.copy()
        removed = {}
        for name in ['NODE_OPTIONS', 'NODE_PATH', 'NODE_COMPILE_CACHE']:
            if name in environment:
                removed[name] = 'Removed; original value intentionally not recorded.'
                del environment[name]
        for name in ['TMPDIR', 'TMP', 'TEMP']:
            environment[name] = str(TEMPORARY)
        write(out / 'environment.json', {'removed': removed, 'forcedModuleInferenceFlags': [],
              'ownedTemporaryDirectory': str(TEMPORARY), 'temporaryBytesIncludedInCap': True})
        for version, node, size, sha in selected_nodes:
            if node.is_symlink() or node.stat().st_size != size or digest(node) != sha:
                raise RuntimeError(f'Node {version} executable differs from reviewed original.')
            actual_version = subprocess.check_output([str(node), '--version'], env=environment).decode().strip()
            if actual_version != 'v' + version:
                raise RuntimeError(f'Unexpected Node version: {actual_version}')
            before = snapshot(admitted, package, extension)
            write(out / f'node{version}.before.json', before)
            if not same_inputs(before, initial):
                raise RuntimeError('Physical inputs or source index changed between runtime runs.')
            command = [str(node), '--test', '--test-concurrency=1', '--test-reporter=tap', *selected]
            stdout_path = out / f'node{version}.stdout.log'
            stderr_path = out / f'node{version}.stderr.log'
            start = time.monotonic()
            termination = None
            admin = Path(git('rev-parse', '--absolute-git-dir').decode().strip())
            peak = dict(before['windowFootprint'])
            samples = 0
            with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
                process = subprocess.Popen(command, cwd=WT, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
                try:
                    while process.poll() is None:
                        window = window_footprint(admin)
                        samples += 1
                        peak = {key: max(peak[key], window[key]) for key in peak}
                        if max(window.values()) > CAP:
                            termination = '100 MiB worktree/admin bound exceeded at an in-run sample'
                        if time.monotonic() - start > 900:
                            termination = '900 second group timeout'
                        if stdout_path.stat().st_size + stderr_path.stat().st_size > OUTPUT_CAP:
                            termination = '16 MiB raw output bound exceeded'
                        if termination:
                            os.killpg(process.pid, signal.SIGTERM)
                            try:
                                process.wait(timeout=5)
                            except subprocess.TimeoutExpired:
                                os.killpg(process.pid, signal.SIGKILL)
                                process.wait()
                            break
                        time.sleep(0.5)
                finally:
                    if process.poll() is None:
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
                code = process.wait()
            write(out / f'node{version}.exit.json', {'command': command, 'exit': code, 'termination': termination, 'seconds': time.monotonic()-start})
            after = snapshot(admitted, package, extension)
            temporary_empty = not any(TEMPORARY.iterdir())
            write(out / f'node{version}.after.json', after)
            counts = {}
            for line in stdout_path.read_text(errors='replace').splitlines():
                match = re.fullmatch(r'# (tests|pass|fail|cancelled|skipped|todo) (\d+)', line)
                if match:
                    counts[match[1]] = int(match[2])
            passed = code == 0 and not termination and temporary_empty and same_inputs(before, after) and counts.get('tests', 0) > 0 and counts.get('tests') == counts.get('pass') and all(counts.get(k) == 0 for k in ['fail', 'cancelled', 'skipped', 'todo'])
            result = {'version': version, 'command': command, 'completeFiles': len(selected), 'exit': code,
                      'termination': termination, 'seconds': time.monotonic()-start, 'counts': counts,
                      'inputsUnchanged': same_inputs(before, after), 'passed': passed, 'ownedTemporariesRetired': temporary_empty,
                      'sampledPeakWindowBytes': peak, 'footprintSamples': samples,
                      'samplingLimit': 'Before/after exact source/admin/owned-temp footprints and in-run samples; not an unsampled transient-peak or RAM guarantee.',
                      'stdout': {'bytes': stdout_path.stat().st_size, 'sha256': digest(stdout_path)},
                      'stderr': {'bytes': stderr_path.stat().st_size, 'sha256': digest(stderr_path)}}
            write(out / f'node{version}.receipt.json', result)
            results.append(result)
            print(json.dumps(result), flush=True)
            if not passed:
                break
        final = snapshot(admitted, package, extension)
        write(out / 'after-all.json', final)
        (out / 'full-index.after.txt').write_bytes(git('ls-files', '-s', '-z'))
        success = len(results) == len(selected_nodes) and all(r['passed'] for r in results) and same_inputs(initial, final)
        write(out / 'result.json', {'status': 'PASS' if success else 'FAIL', 'group': args.group,
                                  'results': results, 'physicalInputsUnchanged': same_inputs(initial, final),
                                  'otherGroupsNotExecuted': [name for name in plan['groups'] if name != args.group],
                                  'phaseAccepted': False})
        return 0 if success else 1
    except BaseException as error:
        write(out / 'failure.json', {'status': 'FAIL_RETAINED', 'error': f'{type(error).__name__}: {error}', 'completedResults': results})
        raise

if __name__ == '__main__':
    sys.exit(main())
