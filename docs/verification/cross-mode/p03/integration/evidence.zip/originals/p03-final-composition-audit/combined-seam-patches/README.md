# Combined P03/P02 regression candidates

Prepared outside the integration worktree. **Not applied, not tested.** No product/runtime source, Git index, refs, browser, production output or release records were changed. The parent owns application and serial qualification after the current suite finishes.

Base is the completed integrated commit `bff9a1e1c1a6a320dd90bdbbe1d68ead9bb55295`. `base-pins.json` records the exact two original test bodies. `base/` preserves those originals; `candidate/` contains proposed whole-file results. `candidate-pins.json` records both independently applicable patches and resulting hashes.

## 01 — Shared sound edits through Help reading

`01-master-reading.patch` adds one parameterized actual-host journey to `game/test/couch-audio-master.test.mjs`: Versus and Team are two distinct test cases.

The journey starts and pauses the real attempt, edits the actual Mute and volume controls, closes Options, opens Help, enters reading, models native pan adoption, exits through the actual Escape handler, and returns to Options. It asserts unchanged saved preferences, paused state, ordinary action labels and feedback. Team additionally retains a nonempty storage-refusal warning and permanent explanation through reading, then clears only the warning after a successful real edit. Team still creates no audio/video/context. Versus retains the actual host-owned sound producer, music state/cursor, master mute and media Play count.

The existing finite keyboard-default adapter gains native Summary activation. It emits the click and toggles Details only after the actual shared keyboard handler leaves Enter unprevented; a prevented click cannot toggle it. This models browser behavior missing from the DOM fixture. It does not bypass production navigation or set a reader's private state.

All existing c930 sound-note, storage refusal/recovery, ordinary Mute/Unmute and presentation-readiness assertions remain. Neither the Team theme revision nor its actual presentation acquisition changes.

## 02 — Muted sound through interrupted Next and Help

`02-next-sound-reading.patch` adds two actual completed-round journeys to `game/test/couch-static-picture-host.test.mjs`: Cancel and decode refusal.

It forwards the existing `couchPage` audio/storage adapters through the original-picture fixture and observes the real Soundscape enable method while retaining its original implementation. An actual timed round completes; the test uses the real Mute button. A held next image is cancelled or refused while the prior Results and original image remain. Keyboard Help reading and return exercise the shared reader before confirming retained sound, result/checkpoint/score and picture-lease identities. Cancel also receives its obsolete decoder completion after the Help journey. A fresh Next preparation succeeds to Ready after a deliberate newer focus choice; it neither starts the new flight nor unmutes/restarts the song.

No nonexistent Versus music-Pause action is introduced. Muting keeps the playing transport intent. A separate explicit Studio-Pause journey would belong to Solo or the later P02-B transport work.

## Modeled boundaries and remaining gates

- The actual HTML, event handlers, controller navigation/reader, simulations, audio master, preference persistence, results and original-picture acquisition execute when these tests are run.
- Keyboard button/Summary defaults and native text scrolling are finite DOM boundary inputs. These tests do not certify real touch, controller hardware, native layout or focus visibility.
- Team checks real HUD/progress/paused/lobby state, not an exposed private checkpoint. Versus retains both authoritative checkpoints and exact round objects.
- Sound uses the already-admitted Web Audio/media harness with its controlled audio clock; this proves state and transport ownership, not audible quality, real MP3 decoding or speaker output.
- Original picture bytes and committed hashes remain verified by the existing fixture. Decoder completion/refusal and object URLs are explicitly modeled. No fabricated theme19 or dynamically weakened expected identity is used.
- The three added imports in the second patch (`soundtrack-audio.mjs`, `audio.mjs`, `audio-preferences.mjs`) are already included by the reviewed 398-path admission. No file or asset admission expansion is needed.
- Each existing complete test file must run after application; selecting only the new names would not qualify changed fixture behavior. The Team-dependent audio file remains held until final strict production/theme rebinding. Tests, source gates, production, browser/public and phase acceptance remain the parent's separate work.

Prettier parsed/formatted only the two external candidate copies using the existing project configuration. The first formatter invocation silently ignored `.cache`; its empty logs remain in `format.*`. The effective invocation uses an explicit `/dev/null` ignore file and is recorded in `format-explicit-cache.*`. No game tests or application modules were executed here.
