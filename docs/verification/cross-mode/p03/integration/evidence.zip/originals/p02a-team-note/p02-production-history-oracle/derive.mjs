import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
const root = '/Users/oleksandr.mekhovov/work/my_projects/go_test';
const out = path.join(root, '.cache/p02a-team-note/p02-production-history-oracle');
const source = 'c93019a344f6f4c6ac03940c77ea09c81122d911';
const ledgerPath = 'authoring/library/fpv-field-kit/production.rltheme';
const git = (...args) => execFileSync('git', args, { cwd: root, maxBuffer: 32 * 1024 * 1024 });
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const assert = (ok, message) => { if (!ok) throw new Error(message); };
const canonical = (value) => Array.isArray(value)
  ? `[${value.map(canonical).join(',')}]`
  : value !== null && typeof value === 'object'
    ? `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`
    : JSON.stringify(value);
function readLedger(revision) {
  const raw = git('show', `${revision}:${ledgerPath}`);
  assert(raw.subarray(0, 8).equals(Buffer.from('RLTHM1\r\n')), 'Exact binary signature');
  const length = raw.readUInt32BE(8);
  assert(length > 0 && length < raw.length - 12, 'Bounded manifest');
  const manifestBytes = raw.subarray(12, 12 + length);
  const manifest = JSON.parse(manifestBytes.toString('utf8'));
  assert(canonical(manifest) === manifestBytes.toString('utf8'), 'Original canonical manifest bytes');
  const payloads = [];
  const bodies = new Map();
  let offset = 12 + length;
  let last = '';
  for (const item of manifest.assets) {
    assert(/^[0-9a-f]{64}$/.test(item.sha256) && item.sha256 > last, 'Sorted unique original table');
    assert(Number.isSafeInteger(item.bytes) && item.bytes > 0 && offset + item.bytes <= raw.length, 'Payload size');
    const bytes = raw.subarray(offset, offset + item.bytes);
    assert(sha(bytes) === item.sha256, 'Each original payload hash');
    payloads.push([item.sha256, bytes.length]);
    bodies.set(item.sha256, bytes);
    offset += item.bytes;
    last = item.sha256;
  }
  assert(offset === raw.length, 'No trailing bytes');
  const fileFacts = new Map();
  for (const asset of manifest.document.assets) {
    if (!asset.file) continue;
    const fact = asset.file;
    assert(bodies.has(fact.sha256) && bodies.get(fact.sha256).length === fact.bytes, 'Every asset file binds exact original bytes');
    if (fileFacts.has(fact.sha256)) assert(fileFacts.get(fact.sha256).bytes === fact.bytes, 'Repeated file fact size');
    fileFacts.set(fact.sha256, fact);
  }
  assert(fileFacts.size === bodies.size, 'No unreferenced original payload');
  return { raw, manifest, manifestBytes, payloads, bodies };
}
function describe(revision, tag, ledger) {
  const { slots, assets, themes, collections, ...metadata } = ledger.manifest.document;
  const groups = Object.fromEntries(Object.entries({ slots, assets, themes, collections }).map(([name, values]) => [name, { count: values.length, sha256: sha(canonical(values)) }]));
  return {
    format: 'revealline-production-history-oracle.v1',
    provenance: {
      source: revision,
      tree: git('rev-parse', `${revision}^{tree}`).toString().trim(),
      tag,
      path: ledgerPath,
      bytes: ledger.raw.length,
      sha256: sha(ledger.raw),
      scope: 'Immutable published source oracle; scoped P02-A acceptance and P03 generation are separate.',
    },
    metadata,
    groups,
    payloads: { count: ledger.payloads.length, sha256: sha(canonical(ledger.payloads)) },
  };
}
const p01Original = git('show', `${source}:game/test/fixtures/production-p01-v0574.json`);
const p01 = JSON.parse(p01Original);
const prior = readLedger(p01.provenance.source);
const p01Derived = describe(p01.provenance.source, p01.provenance.tag, prior);
p01Derived.provenance.scope = p01.provenance.scope;
assert(canonical(p01Derived) === canonical(p01), 'Existing P01 oracle independently reproduced exactly');
const current = readLedger(source);
const oracle = describe(source, 'v0.58.1', current);
assert(oracle.provenance.tree === 'f6055cbcba92d45ef1da2b5d16e7e4f1158c8d2a', 'Published source tree');
assert(git('rev-parse', 'v0.58.1^{}').toString().trim() === source, 'Published immutable tag target');
assert(oracle.metadata.revision === 24 && oracle.groups.assets.count === 1082 && oracle.groups.themes.count === 25 && oracle.payloads.count === 127, 'Measured P02 structure');
const priorDocument = structuredClone(p01.metadata);
for (const [group, pin] of Object.entries(p01.groups)) {
  const prefix = current.manifest.document[group].slice(0, pin.count);
  assert(sha(canonical(prefix)) === pin.sha256, 'Exact P01 group prefix retained');
  priorDocument[group] = prefix;
}
const priorManifest = Buffer.from(canonical({ document: priorDocument, assets: current.manifest.assets }));
const header = Buffer.alloc(12);header.write('RLTHM1\r\n');header.writeUInt32BE(priorManifest.length, 8);
const reconstructedPrior = Buffer.concat([header, priorManifest, ...current.bodies.values()]);
assert(reconstructedPrior.equals(prior.raw), 'P01 reconstructed from published P02 exactly matches original published bytes');
assert(canonical(current.payloads) === canonical(prior.payloads), 'P01 and P02 payload sets are exact');
const outBytes = Buffer.from(JSON.stringify(oracle, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'production-p02-v0581.json'), outBytes, { flag: 'wx' });
fs.writeFileSync(path.join(out, 'production-p01-v0574.original.json'), p01Original, { flag: 'wx' });
const receipt = {
  status: 'PASS_IMMUTABLE_P02_ORACLE_DERIVATION',
  source, sourceTree: oracle.provenance.tree, ledgerPath,
  originalBundleBytes: current.raw.length, originalBundleSha256: sha(current.raw),
  manifestBytes: current.manifestBytes.length, manifestSha256: sha(current.manifestBytes),
  originalPayloads: current.payloads.map(([sha256, bytes]) => ({ sha256, bytes })),
  originalPayloadBytes: current.payloads.reduce((sum, [,bytes]) => sum + bytes, 0),
  all127PayloadLengthsAndHashesVerified: true,
  allAssetFileReferencesBindOriginalPayloads: true,
  p01OracleExactlyReproducedFromItsPublishedSource: true,
  p01BundleReconstructedFromP02PrefixExactly: true,
  p01OriginalBundleSha256: sha(prior.raw),
  p01OriginalOracleSha256: sha(p01Original),
  output: { path: 'production-p02-v0581.json', bytes: outBytes.length, sha256: sha(outBytes) },
  canonicalSourcePin: { path: 'game/data-json.mjs', sha256: sha(git('show', `${source}:game/data-json.mjs`)) },
  bundleFormatSourcePin: { path: 'game/presentation/bundle.mjs', sha256: sha(git('show', `${source}:game/presentation/bundle.mjs`)) },
  helper: { path: 'derive.mjs', sha256: sha(fs.readFileSync(new URL(import.meta.url))) },
  testsRun: false, productionGeneratorRun: false, p03InputsReadOrChanged: false,
  initialReadAttempt: 'An exploratory JSON.parse of the whole binary ledger stopped at UnicodeDecodeError before writing anything. Derivation instead uses exact RLTHM1 binary framing from published bundle.mjs. No original changes.',
};
fs.writeFileSync(path.join(out, 'derivation.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ status: receipt.status, output: receipt.output, source, bundleBytes: current.raw.length, bundleSha256: sha(current.raw), groups: oracle.groups, payloads: oracle.payloads }, null, 2));
