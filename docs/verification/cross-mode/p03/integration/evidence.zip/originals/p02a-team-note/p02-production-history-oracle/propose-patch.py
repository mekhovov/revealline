from pathlib import Path
import subprocess,difflib,json,hashlib
R=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test');O=R/'.cache/p02a-team-note/p02-production-history-oracle';file='game/test/presentation-production-history.test.mjs';source='c93019a344f6f4c6ac03940c77ea09c81122d911'
old=subprocess.check_output(['git','show',source+':'+file],cwd=R).decode();new=old
helper='''async function reconstructPublishedProduction(oracle, candidate) {
  const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
  const source = structuredClone(oracle.metadata);
  for (const [group, pin] of Object.entries(oracle.groups)) {
    const prefix = candidate.document[group].slice(0, pin.count);
    assert.equal(prefix.length, pin.count, `published ${group} count`);
    assert.equal(sha(canonicalJSON(prefix)), pin.sha256, `published ${group} bytes`);
    source[group] = prefix;
  }
  // Reuse records only after all immutable group hashes match the published oracle.
  const document = validateThemeBundle(source);
  const assets = new Map();
  for (const asset of document.assets) {
    if (!asset.file || assets.has(asset.file.sha256)) continue;
    const blob = candidate.assets.get(asset.file.sha256);
    assert.ok(blob, `published payload ${asset.file.sha256}`);
    const bytes = Buffer.from(await blob.arrayBuffer());
    assert.equal(bytes.length, asset.file.bytes);
    assert.equal(sha(bytes), asset.file.sha256);
    assets.set(asset.file.sha256, blob);
  }
  const payloads = [...assets].map(([hash, blob]) => [hash, blob.size]);
  payloads.sort(([a], [b]) => a.localeCompare(b));
  assert.equal(payloads.length, oracle.payloads.count);
  assert.equal(sha(canonicalJSON(payloads)), oracle.payloads.sha256);
  const raw = Buffer.from(await (await exportThemeBundle(document, assets)).arrayBuffer());
  assert.equal(raw.length, oracle.provenance.bytes);
  assert.equal(sha(raw), oracle.provenance.sha256, 'reconstructed published bundle');
  return { document, assets, raw };
}

'''
marker="test('P02 retains the published P01 history and appends audio7 under a new fpv24', async () => {"
assert new.count(marker)==1;new=new.replace(marker,helper+marker)
a="""  const raw = await fs.readFile(
    new URL('../../authoring/library/fpv-field-kit/production.rltheme', import.meta.url),
  );
  const candidate = await importThemeBundle(new Blob([raw]), { decodeImage: null });
"""
b="""  const currentRaw = await fs.readFile(
    new URL('../../authoring/library/fpv-field-kit/production.rltheme', import.meta.url),
  );
  const current = await importThemeBundle(new Blob([currentRaw]), { decodeImage: null });
  // Pin this historical test to published c930 P02, independent of current generation.
  const p02Oracle = JSON.parse(
    await fs.readFile(new URL('./fixtures/production-p02-v0581.json', import.meta.url), 'utf8'),
  );
  const candidate = await reconstructPublishedProduction(p02Oracle, current);
  const raw = candidate.raw;
"""
assert new.count(a)==1;new=new.replace(a,b)
a="""  const production = await createFieldKitProduction();
  const next = retainProductionHistory(production.document, prior);
"""
b="""  // The verified published P02 selections replay the immutable P01 -> P02 transition.
  // Current producer compatibility is exercised by the separate successor test below.
  const production = candidate;
  const next = retainProductionHistory(production.document, prior);
"""
assert new.count(a)==1;new=new.replace(a,b)
new=new.replace("assert.deepEqual(exported, raw, 'actual CLI ledger equals reproduced bundle');", "assert.deepEqual(exported, raw, 'published P02 ledger equals reproduced bundle');",1)
successor='''test('P03 reproduces the current ledger while preserving the published P02 history', async () => {
  const oracle = JSON.parse(
    await fs.readFile(new URL('./fixtures/production-p02-v0581.json', import.meta.url), 'utf8'),
  );
  const raw = await fs.readFile(
    new URL('../../authoring/library/fpv-field-kit/production.rltheme', import.meta.url),
  );
  const candidate = await importThemeBundle(new Blob([raw]), { decodeImage: null });
  const published = await reconstructPublishedProduction(oracle, candidate);
  const prior = published.document;
  const production = await createFieldKitProduction();
  const next = retainProductionHistory(production.document, prior);
  validateThemeBundle(next, { previous: prior, expectedRevision: oracle.metadata.revision });
  assert.ok(next.revision > prior.revision, 'P03 is an actual immutable successor');
  assert.equal(canonicalJSON(next), canonicalJSON(candidate.document));
  for (const [group, pin] of Object.entries(oracle.groups))
    assert.deepEqual(next[group].slice(0, pin.count), prior[group], `retained P02 ${group}`);
  const mergedAssets = new Map([...candidate.assets, ...production.assets]);
  for (const [hash, before] of published.assets)
    assert.deepEqual(
      Buffer.from(await mergedAssets.get(hash).arrayBuffer()),
      Buffer.from(await before.arrayBuffer()),
      `retained P02 payload ${hash}`,
    );
  const second = retainProductionHistory(production.document, next);
  assert.equal(canonicalJSON(second), canonicalJSON(next));
  const exported = Buffer.from(await (await exportThemeBundle(next, mergedAssets)).arrayBuffer());
  const repeated = Buffer.from(await (await exportThemeBundle(second, mergedAssets)).arrayBuffer());
  assert.deepEqual(exported, raw, 'current CLI ledger equals reproduced P03 successor');
  assert.deepEqual(repeated, exported, 'second export identical');
});

'''
marker='function desired(\n';assert new.count(marker)==1;new=new.replace(marker,successor+marker)
assert new[new.index(marker):]==old[old.index(marker):]
(O/'presentation-production-history.test.original.mjs').write_text(old)
(O/'presentation-production-history.test.proposed.mjs').write_text(new)
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+file,tofile='b/'+file));(O/'presentation-production-history.proposal.patch').write_text(patch)
sha=lambda b:hashlib.sha256(b).hexdigest()
(O/'proposal.json').write_text(json.dumps({'status':'PROPOSED_NOT_EXECUTED','source':source,'sourcePath':file,'sourceSha256':sha(old.encode()),'proposalSha256':sha(new.encode()),'patchSha256':sha(patch.encode()),'preserved':'Every existing historical fpv24/audio7 count/binding/payload/export/compiled-file/immutable-conflict assertion remains; generic tests after desired() are byte-identical.','changed':'Historical test reconstructs the published P02 ledger from independent hash oracle before replaying P01 -> P02. Current generation moves to a distinct P02 -> P03 successor/reproduction test.','pending':'After root runs actual final P03 generation, add its measured exact successor revision/changed role/count expectations to the new P03 test. No final P03 revision or asset count was guessed here.','testsRun':False,'producerRun':False,'p03SourceChanged':False},indent=2)+'\n')
print(patch)
