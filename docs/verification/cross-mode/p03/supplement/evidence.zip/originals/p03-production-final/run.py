from pathlib import Path
import hashlib, json, os, signal, subprocess, time

ROOT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
WT = ROOT / '.cache/worktrees/p03-final-integration'
HERE = Path(__file__).resolve().parent
OUT = HERE / 'attempt-1'
NODE = Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node')
CAP = 100 * 1024**2
sha = lambda body: hashlib.sha256(body).hexdigest()
git = lambda *args: subprocess.check_output(['git', '-C', str(WT), *args])
admin = Path(git('rev-parse', '--absolute-git-dir').decode().strip())

def save(name, data):
    (OUT / name).open('x').write(json.dumps(data, indent=2) + '\n')

def snapshot():
    rows = {}
    for p in WT.rglob('*'):
        assert not p.is_symlink(), p
        if p.is_file() and p.name != '.git':
            body = p.read_bytes()
            rows[str(p.relative_to(WT))] = {'bytes': len(body), 'sha256': sha(body)}
    assert len(rows) == 674
    return rows

def allocated():
    return sum(p.lstat().st_blocks * 512 for root in (WT, admin, OUT / 'tmp')
               for p in [root, *root.rglob('*')])

assert not OUT.exists()
assert sha(NODE.read_bytes()) == '5c899797c4eb8f1db5563eea56538342ddb3e9276ee1b04a5a1f0f1023d2b011'
assert subprocess.check_output([str(NODE), '--version']).decode().strip() == 'v22.22.2'
OUT.mkdir()
(OUT / 'tmp').mkdir()
index = git('ls-files', '-s', '-z')
before = snapshot()
save('before.json', before)
save('source.json', {'head': git('rev-parse', 'HEAD').decode().strip(),
                     'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
                     'logicalIndexSHA256': sha(index), 'helperSHA256': sha(Path(__file__).read_bytes()),
                     'basis': 'Actual working inputs, not a claim that they are committed.'})
assert allocated() + 25 * 1024**2 < CAP
environment = os.environ.copy()
for name in ['NODE_OPTIONS', 'NODE_PATH', 'NODE_COMPILE_CACHE']:
    environment.pop(name, None)
for name in ['TMPDIR', 'TMP', 'TEMP']:
    environment[name] = str(OUT / 'tmp')
results = []
for mode in ['write', 'check']:
    command = [str(NODE), 'scripts/produce-field-kit-theme.mjs', '--' + mode]
    start = time.monotonic()
    peak = allocated()
    with (OUT / (mode + '.stdout.log')).open('xb') as stdout, (OUT / (mode + '.stderr.log')).open('xb') as stderr:
        process = subprocess.Popen(command, cwd=WT, env=environment, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            while process.poll() is None:
                peak = max(peak, allocated())
                assert peak < CAP, '100 MiB sampled allocation bound exceeded'
                assert time.monotonic() - start < 900, '900 second limit exceeded'
                time.sleep(0.2)
        finally:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=5)
        code = process.wait()
    receipt = {'command': command, 'exit': code, 'seconds': time.monotonic()-start,
               'sampledPeakAllocatedBytes': peak, 'scope': 'Sampled disk allocation, not unsampled peak or RAM.'}
    for channel in ['stdout', 'stderr']:
        body = (OUT / f'{mode}.{channel}.log').read_bytes()
        receipt[channel] = {'bytes': len(body), 'sha256': sha(body)}
    save(mode + '.receipt.json', receipt)
    results.append(receipt)
    assert code == 0
    current = snapshot()
    if mode == 'write':
        written = current
        save('after-write.json', current)
    else:
        assert current == written, 'Canonical check changed physical inputs'
    assert not any((OUT / 'tmp').iterdir()), 'Producer left temporary files'
after = snapshot()
assert git('ls-files', '-s', '-z') == index
changed = [name for name in before if before[name] != after[name]]
expected = {'authoring/library/fpv-field-kit/production.rltheme',
            'game/presentation/compiled/manifest.json',
            'game/presentation/compiled/runtime.json',
            'game/presentation/compiled/studio.json'}
assert set(changed) == expected, changed
save('after.json', after)
save('receipt.json', {'status': 'PASS_CANONICAL_WRITE_AND_CHECK', 'changed': changed,
                      'originalAssetsUnchanged': True, 'logicalIndexUnchanged': True,
                      'runs': results, 'phaseAccepted': False})
print((OUT / 'receipt.json').read_text())
