# P03 finite native-browser admission proposal

**Fits:** the observed worktree plus the 32 missing files for ordinary Title → Solo / Versus / Team and Library / Settings / Help journeys, including all eight current bundled packs, totals **90,918,416 bytes (86.71 MiB)**. Cap: **104,857,600 bytes (100 MiB)**; remaining headroom: **13,939,184 bytes**.

This is a read-only dependency inventory, not browser or production acceptance. No source files/assets were populated, no source/index/planning files changed, and no server/browser/runtime suite was run.

## Authority and exact files

Captured 2026-09-16T06:55:49.480982+00:00. HEAD **beb0140eff7315b63269ee78ded07155de3e7084**, plus the working `fpv@25` presentation and strict Team bindings. Directory name retains the original 902bd window ID. Source modules changed to beb0140 while inventory was being assembled; the guard refused the old snapshot and the literal closure was re-derived against beb0140. Root owns the pending presentation/history changes.

- [admission.json](admission.json): every admitted path, actual bytes, SHA-256, HEAD blob, present/absent and working-vs-HEAD status; separate cohort costs.
- [missing-paths.tsv](missing-paths.tsv): **32 exact missing paths**, **34,669,519 bytes**, Git blob IDs and SHA-256.
- [http-allowlist.txt](http-allowlist.txt): **427** reviewed project-relative HTTP paths, **65,835,356 bytes** in total; no full-checkout assumption.
- [present-current.json](present-current.json): current resident files and hashes, including unused resident source/tests and Prettier in the capacity calculation.
- [static-closure.json](static-closure.json), [content-paths.json](content-paths.json): source derivation and conditional content evidence. The content report retains its earlier 902bd/working snapshot; admission.json refreshes actual file hashes and HEAD authority.

| Missing family | Files | Bytes |
|---|---:|---:|
| Original role craft | 7 | 5,772,788 |
| Compact Atlas / FPV actor exports | 13 | 854,581 |
| Motion Lab source bodies | 10 | 5,537,872 |
| Current Frontier / Equipment packs | 2 | 22,504,278 |
| **Total** | **32** | **34,669,519** |

The 27 selectable-body rows and seven enemy rows share paths: union before adding packs is **30** missing files, **12,165,241 bytes**, not 34. `setLook()` still requests original craft files even with a compiled appearance, so omitting those can test fallback/warnings instead of normal behavior. All **263** literal HTML/CSS/module dependency files and all **124** compiled image/font URLs (**2,304,880 bytes**) are already present. The actual vendored Phaser is included. No unavoidable third-party request was found for these ordinary fresh routes.

Current resident count is **674 files / 56,248,897 bytes**: 616 tracked-at-HEAD files, one new source fixture, 56 Prettier files (**8,458,264 bytes**), and the 96-byte `.git` control file. This reconciles the source owner's 617-source + 56-Prettier count. No symlinks were present. Available disk was **40,190,738,432 bytes**, above the **2,147,483,648-byte** floor. These are logical file-byte counts; browser profiles, logs and other external work remain additional disk use.

## Required revalidation before root-owned browser work

1. Re-read HEAD, working status, admitted hashes and physical bytes. Do not replace root's working files from HEAD. In this snapshot HEAD's older compiled/binding revisions are not the approved working combination. Working runtime SHA-256: `07f0f26947fbcc356f6bde5c1bb2e5982970aec10cb1dfc0616ebe11d652c26a`; strict Team binding SHA-256: `dc439f7399d13847f0017908f6f79ac0a00a771f3e32e6209750f2cd2d140e8d`. Recheck revision coherence and actual decoding in the browser.
2. After root review, admit only the explicit missing blobs into their original project-relative paths; verify their lengths and SHA-256. This audit has not done so. Recompute cap/free-space immediately before population and after it; do not consume all nominal headroom with logs/caches.
3. Root's HTTP harness should bind to loopback on a fresh port and serve these physical paths from this finite worktree, preserving `/game/` and `/authoring/`. Resolve `/game/` to `game/index.html` and `/game/couch/` to `game/couch/index.html`; Team is `/game/couch/relay-rescue.html`. Serve correct JS/MJS, CSS, JSON, PNG and WOFF2 MIME types, use `Cache-Control: no-store`, and record requested path/status/body length/hash. Reject paths outside the allowlist, traversal, symlinks and missing bodies. Do not supply Git/remote fallback bytes or invented fixtures on unexpected requests.
4. Perform actual native-browser navigation and reading journeys after code final. An unexpected missing asset or a caught fallback is a finding, not a successful ordinary-path result. Confirm full decoded boards, active controls and focus at ordinary and 200% reading, then root's keyboard/touch/controller and foreground/pause cases. This inventory proves neither those interactions nor physical-device behavior.

## Intentional source boundaries and extra cohorts

- `game/build-info.json` is release-generated and absent in source. Solo's caught probe keeps DEV. Do not synthesize a release identity to hide that distinction.
- Source HTML lacks the packaged offline marker; ordinary Settings should truthfully show offline preparation as unavailable for this source preview. Offline cold start and public bytes require the real packaged release later.
- `native/bridge.mjs` is conditional iOS-only and is not requested on this ordinary local HTTP origin.
- The static analyzer's `./compiled/` and catalogue `../` references are URL bases, not missing file requests. The nonliteral boot import is the included `game/app.mjs`; Couch direct imports come from actual HTML `data-module` values and are included.
- Fresh Versus eagerly fetches the real **11,708,176-byte R5 pack** and decodes its three embedded originals before Start. It is resident. Embedded originals are pack bytes, not invented standalone HTTP files.
- All eight current bundled pack installs are in the recommended cohort. The two missing packs are Frontier (**11,377,254 bytes**) and Equipment (**11,127,024 bytes**).
- All four archives together would raise the resident total to **137,739,963 bytes**; all five optional original packs to **147,343,460 bytes**. Neither fits the 100 MiB window. Each individually fits alongside the current eight, but with only about 1.6–3.6 MB nominal headroom; use separately reviewed cohorts and preserve installed media/state. No deletion or cohort rotation is authorized/performed by this inventory.
- The **32 generated external release pack/media endpoints** do not exist as source blobs. Source catalogue inspection does not qualify their Download & play. Use the real packaged release for that check.
- Installed packs, managed originals and saved soundtrack selections depend on actual IndexedDB/local storage state. A fresh origin cannot prove their historical restoration. Do not replace those with static JSON.

This proposal leaves P03 native acceptance, P04/P06 installed-content checks, P08-A complete cross-mode visual parity, physical-device qualification, offline and public release acceptance open.
