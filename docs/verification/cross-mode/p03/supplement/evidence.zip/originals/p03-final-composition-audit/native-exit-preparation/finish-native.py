"""Audit captured native HTTP evidence, then retire only its exact sparse additions."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import socket
import subprocess

ROOT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
WT = ROOT / '.cache/worktrees/p03-final-integration'
HERE = Path(__file__).resolve().parent
OUT = HERE / 'execution'
BINDING_SHA = 'a92ab53b1268f94c8eebd7d50a3f531987a03cafc824bfb89b833921a23fed9e'
SHA = lambda raw: hashlib.sha256(raw).hexdigest()
ENV = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}


def read(path, limit=32 * 1024**2):
    assert path.is_file() and not any(p.is_symlink() for p in [path, *path.parents]), path
    assert path.stat().st_size <= limit, path
    return path.read_bytes()


def write_json(name, value):
    (OUT / name).open('x').write(json.dumps(value, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args], env=ENV)


def verify_row(base, row):
    name = row['path']
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    raw = read(base / name)
    assert len(raw) == row['bytes'] and SHA(raw) == row['sha256'], name
    return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    binding_raw = read(HERE / 'binding.json')
    assert SHA(binding_raw) == BINDING_SHA
    binding = json.loads(binding_raw)
    if not args.execute:
        print(json.dumps({'status': 'PREPARED_NOT_EXECUTED', 'output': str(OUT),
                          'retireFiles': 32, 'sourceRemaining': 617, 'prettierRemaining': 56,
                          'requiresServerStopped': binding['serverPID'],
                          'auditBeforeSparseChange': True, 'phaseAcceptance': False}, indent=2))
        return
    assert not OUT.exists(), 'Keep an earlier attempt; another execution needs a reviewed output.'
    # Parent must stop its own server first. Never signal it or reuse a live PID.
    try:
        os.kill(binding['serverPID'], 0)
    except ProcessLookupError:
        pass
    else:
        raise AssertionError('The observed server PID still exists; root must stop/review it.')
    # Refuse another listener and reserve the stopped port through retirement.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as guard:
        guard.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        guard.bind(('127.0.0.1', binding['serverPort']))
        guard.listen(1)
        OUT.mkdir()
        write_json('state.json', {'status': 'SERVER_STOPPED_AUDIT_STARTING',
                                 'serverPIDAbsent': True, 'portReserved': 8897,
                                 'phaseAcceptance': False})
        pinned = {}
        for row in binding['originals']:
            raw = verify_row(ROOT, row)
            pinned[row['path']] = raw
            target = OUT / 'originals' / row['path'].removeprefix('.cache/')
            target.parent.mkdir(parents=True, exist_ok=True)
            target.open('xb').write(raw)
        admission = json.loads(pinned['.cache/p03-native-admission-902bd/admission.json'])
        resident = json.loads(pinned['.cache/p03-native-admission-902bd/present-current.json'])
        original_receipt = json.loads(pinned['.cache/p03-native-integration/admission-receipt.json'])
        assert admission['head'] == binding['head'] == git('rev-parse', 'HEAD').decode().strip()
        index = git('ls-files', '-s', '-z')
        assert SHA(index) == binding['indexSHA256'] == original_receipt['fullIndexSHA256']
        expanded = read(HERE / 'expanded-patterns.txt')
        restore = read(HERE / 'restore-patterns.txt')
        assert SHA(expanded) == binding['expandedPatterns']['sha256']
        assert SHA(restore) == binding['restorePatterns']['sha256']
        assert git('sparse-checkout', 'list') == expanded
        retire = binding['retireFiles']
        assert retire == [r for r in admission['allowlist'] if not r['present']]
        assert len(retire) == 32 and sum(r['bytes'] for r in retire) == 34669519
        retire_names = {r['path'] for r in retire}
        kept_names = {r['path'] for r in resident['files']}
        assert len(kept_names) == 674 and not kept_names & retire_names
        source_names = {n for n in kept_names if n != '.git' and not n.startswith('node_modules/')}
        assert len(source_names) == 617
        assert len([n for n in kept_names if n.startswith('node_modules/')]) == 56
        assert set(restore.decode().splitlines()) == {'/' + n for n in source_names}
        assert set(expanded.decode().splitlines()) == {'/' + n for n in source_names | retire_names}
        # The Git operation has only explicit regular-file patterns, never wildcards/directories.
        assert all(not any(c in n for c in '*?![') for n in expanded.decode().splitlines())
        for row in resident['files']:
            verify_row(WT, row)
        for row in admission['allowlist']:
            verify_row(WT, row)
        stage = {}
        for entry in index.split(b'\0'):
            if entry:
                description, name = entry.split(b'\t', 1)
                stage[name.decode()] = description.decode().split()
        for row in retire:
            assert stage[row['path']] == ['100644', row['gitBlob'], '0']
            assert git('rev-parse', 'HEAD:' + row['path']).decode().strip() == row['gitBlob']
        actual = {str(p.relative_to(WT)) for p in WT.rglob('*') if p.is_file()}
        assert actual == kept_names | retire_names, 'Unmodeled physical files; do not retire.'
        assert not any(p.is_symlink() for p in WT.rglob('*'))
        log = read(ROOT / binding['httpLog'], binding['maxLogBytes'])
        assert log.endswith(b'\n'), 'Partial final HTTP row.'
        (OUT / 'http.original.jsonl').open('xb').write(log)
        rows = [json.loads(line) for line in log.splitlines()]
        assert 0 < len(rows) <= binding['maxLogRows']
        allow = {r['path']: r for r in admission['allowlist']}
        assert len(allow) == 427
        errors, absent, observed = [], [], set()
        get_count = head_count = get_bytes = head_bytes = 0
        for number, row in enumerate(rows, 1):
            common = (set(row) == {'time', 'method', 'path', 'status', 'bytes', 'sha256'}
                      and row['method'] in ['GET', 'HEAD']
                      and isinstance(row['time'], (int, float)))
            if common and row['status'] == 200 and row['path'] in allow:
                pin = allow[row['path']]
                if row['bytes'] != pin['bytes'] or row['sha256'] != pin['sha256']:
                    errors.append({'line': number, 'reason': 'Wrong 200 source pin', 'row': row})
                    continue
                observed.add(row['path'])
                if row['method'] == 'GET':
                    get_count += 1
                    get_bytes += row['bytes']
                else:
                    head_count += 1
                    head_bytes += row['bytes']
            elif (common and row['status'] == 404 and row['path'] in binding['expected404']
                  and row['path'] not in allow and row['bytes'] == 38 and row['sha256'] is None):
                absent.append({'line': number, **row})
            else:
                errors.append({'line': number, 'reason': 'Unmodeled response, including any 409', 'row': row})
        audit = {'status': 'FAIL' if errors else 'PASS_SOURCE_BOUND_HTTP_LOG',
                 'logBytes': len(log), 'logSHA256': SHA(log), 'rows': len(rows),
                 'allowedFilesSourceRehashed': 427, 'observedSuccessfulPaths': len(observed),
                 'unrequestedAllowedPaths': sorted(set(allow) - observed),
                 'successfulGETRows': get_count, 'successfulHEADRows': head_count,
                 'getDeclaredResponseBytes': get_bytes, 'headDeclaredResponseBytes': head_bytes,
                 'expectedAbsentSourceEndpoints': absent, 'errors': errors,
                 'boundary': 'Server records pinned response attempts, not client receipt, visual review, complete coverage, offline or public qualification.',
                 'phaseAcceptance': False}
        write_json('http-audit.json', audit)
        assert not errors, 'HTTP audit failed; originals retained and sparse state untouched.'
        assert read(ROOT / binding['httpLog']) == log
        write_json('before-retirement.json', {'head': binding['head'], 'logicalIndexSHA256': SHA(index),
                                            'residentFilesVerified': 674, 'nativeOnlyFilesVerified': 32,
                                            'retireBytes': 34669519, 'httpAuditPassed': True})
        (OUT / 'full-index.before.z').open('xb').write(index)
        (OUT / 'expanded-patterns.original.txt').open('xb').write(expanded)
        (OUT / 'restore-patterns.reviewed.txt').open('xb').write(restore)
        assert git('rev-parse', 'HEAD').decode().strip() == binding['head']
        assert git('ls-files', '-s', '-z') == index
        # One exact sparse operation is the only source-window mutation. Never unlink/rmtree.
        command = ['git', '-c', 'core.hooksPath=/dev/null', '-C', str(WT), 'sparse-checkout',
                   'set', '--no-cone', '--no-sparse-index', '--stdin']
        write_json('retire-command.json', {'command': command, 'stdinSHA256': SHA(restore)})
        with (OUT / 'retire.stdout').open('xb') as stdout, (OUT / 'retire.stderr').open('xb') as stderr:
            result = subprocess.run(command, input=restore, env=ENV, stdout=stdout, stderr=stderr)
        write_json('retire-exit.json', {'exit': result.returncode})
        assert result.returncode == 0, 'Retirement failed; keep all original records and inspect state.'
        assert git('ls-files', '-s', '-z') == index
        assert git('rev-parse', 'HEAD').decode().strip() == binding['head']
        assert git('sparse-checkout', 'list') == restore
        for row in resident['files']:
            verify_row(WT, row)
        assert all(not (WT / name).exists() for name in retire_names)
        assert {str(p.relative_to(WT)) for p in WT.rglob('*') if p.is_file()} == kept_names
        assert not any(p.is_symlink() for p in WT.rglob('*'))
        assert read(ROOT / binding['httpLog']) == log
        for path, raw in pinned.items():
            assert read(ROOT / path) == raw
        admin = Path(git('rev-parse', '--absolute-git-dir').decode().strip())
        allocated = sum(p.lstat().st_blocks * 512 for root in (WT, admin) for p in [root, *root.rglob('*')])
        assert allocated < binding['sourceWorktreeCapBytes']
        write_json('receipt.json', {'status': 'PASS_HTTP_AUDIT_AND_EXACT_SPARSE_RETIREMENT',
                                   'head': binding['head'], 'logicalIndexSHA256': SHA(index),
                                   'remainingSourceFiles': 617, 'remainingPrettierFiles': 56,
                                   'retiredFiles': 32, 'retiredBytes': 34669519,
                                   'allocatedWorktreeAndGitBytes': allocated,
                                   'originalsUnchanged': True, 'testsRun': False, 'browserRun': False,
                                   'generated': False, 'remoteMutation': False, 'phaseAcceptance': False})
        evidence = []
        for p in sorted(OUT.rglob('*')):
            if p.is_file():
                raw = read(p)
                evidence.append({'path': str(p.relative_to(OUT)), 'bytes': len(raw), 'sha256': SHA(raw)})
        write_json('retained-manifest.json', {'files': evidence})
        assert sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file()) <= binding['evidenceCapBytes']
        print((OUT / 'receipt.json').read_text())


if __name__ == '__main__':
    main()
