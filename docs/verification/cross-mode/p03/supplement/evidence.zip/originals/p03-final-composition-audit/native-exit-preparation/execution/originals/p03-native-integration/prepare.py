from pathlib import Path
import hashlib, json, os, shutil, subprocess

ROOT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
WT = ROOT / '.cache/worktrees/p03-final-integration'
HERE = Path(__file__).resolve().parent
INTAKE = ROOT / '.cache/p03-native-admission-902bd'
digest = lambda b: hashlib.sha256(b).hexdigest()
admission = json.loads((INTAKE / 'admission.json').read_bytes())
resident = json.loads((INTAKE / 'present-current.json').read_bytes())
git = lambda *args, **kwargs: subprocess.check_output(['git', '-C', str(WT), *args], **kwargs)
assert git('rev-parse', 'HEAD').decode().strip() == admission['head']
assert not (HERE / 'admission-receipt.json').exists()
index = git('ls-files', '-s', '-z')
before = {}
for row in resident['files']:
    p = WT / row['path']
    assert not p.is_symlink() and p.is_file()
    b = p.read_bytes()
    assert len(b) == row['bytes'] and digest(b) == row['sha256'], row['path']
    before[row['path']] = (len(b), digest(b))
missing = [row for row in admission['allowlist'] if not row['present']]
assert len(missing) == 32 and sum(row['bytes'] for row in missing) == 34669519
admin = Path(git('rev-parse', '--absolute-git-dir').decode().strip())
def footprint():
    return sum(p.lstat().st_blocks * 512 for root in (WT, admin) for p in [root, *root.rglob('*')])
assert footprint() + sum(((row['bytes'] + 4095) // 4096) * 4096 for row in missing) + 2*1024**2 < 100*1024**2
assert shutil.disk_usage(WT).free > 2*1024**3 + 100*1024**2
for row in missing:
    assert not (WT / row['path']).exists()
    body = git('cat-file', 'blob', row['gitBlob'])
    assert len(body) == row['bytes'] and digest(body) == row['sha256']
    assert git('rev-parse', 'HEAD:' + row['path']).decode().strip() == row['gitBlob']
patterns = git('sparse-checkout', 'list').decode().splitlines()
patterns = sorted(set(patterns + ['/' + row['path'] for row in missing]))
subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', '-C', str(WT), 'sparse-checkout', 'set', '--no-cone', '--no-sparse-index', '--stdin'], input=('\n'.join(patterns)+'\n').encode(), check=True)
assert git('ls-files', '-s', '-z') == index
for name, pin in before.items():
    b = (WT / name).read_bytes()
    assert (len(b), digest(b)) == pin, name
for row in admission['allowlist']:
    b = (WT / row['path']).read_bytes()
    assert len(b) == row['bytes'] and digest(b) == row['sha256'], row['path']
allocated = footprint()
assert allocated < 100*1024**2
receipt = {'status':'ADMITTED_PHYSICAL_ORIGINALS_ONLY', 'head':admission['head'], 'existingFilesUnchanged':len(before), 'addedFiles':len(missing), 'addedBytes':sum(row['bytes'] for row in missing), 'httpFiles':len(admission['allowlist']), 'allocatedWorktreeAndGitBytes':allocated, 'fullIndexSHA256':digest(index), 'generated':False, 'nativeVerified':False}
(HERE / 'admission-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
