"""Read-only admission calculation. Writes metadata beside this script only."""
import datetime
import hashlib
import json
import os
import pathlib
import posixpath
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
REPO = OUT.parents[1]
WT = REPO / '.cache/worktrees/p03-final-integration'
load = lambda name: json.loads((OUT / name).read_text())
tree = load('head-tree.json')
HEAD, TREE = tree['head'], tree['paths']
git = lambda *args: subprocess.check_output(['git', '-C', str(WT), *args])
assert git('rev-parse', 'HEAD').decode().strip() == HEAD, 'New HEAD needs a new source inventory'
status_before = git('status', '--porcelain=v1').decode()
static = load('static-closure.json')
content = load('content-paths.json')
current = load('catalog-payloads.json')
archives = load('archive-catalog-payloads.json')
runtime_bytes = (WT / 'game/presentation/compiled/runtime.json').read_bytes()
runtime = json.loads(runtime_bytes)
reasons = {}

def include(path, reason):
    assert not path.startswith('/') and '..' not in pathlib.PurePosixPath(path).parts
    reasons.setdefault(path, set()).add(reason)

for row in static['files']:
    include(row['path'], 'HTML/CSS/module literal closure')
for key in ('bootAndMetadata', 'cssFonts', 'sourceBodiesBySelection', 'enemyBodiesByRenderedType', 'catalogueOnlyOnMoreWorlds'):
    for row in content[key]:
        include(row['path'], key)
include(content['eagerVersusPack']['path'], 'Eager real Versus R5 pack with embedded original PNGs')
compiled = {}
for sha, url in runtime['urls'].items():
    path = posixpath.normpath(posixpath.join('game/presentation/compiled', url))
    include(path, 'Working compiled runtime image/font URL')
    compiled[path] = sha

render = load('render-paths.json') if (OUT / 'render-paths.json').exists() else None
# Renderer report is independently reviewed. Its compact required/fallback rows
# join here only when explicitly marked for the bounded ordinary journeys.
if render:
    for row in render.get('admissionRows', []):
        include(row['path'], 'Independent renderer admission review')

core = set(reasons)
for row in current:
    include(row['path'], 'Explicit install of current bundled pack: ' + row['id'])
broad = set(reasons)
all_additional = {r['path'] for r in archives + content['explicitOptionalDownloads']}

present = []
symlinks = []
for base, dirs, files in os.walk(WT, followlinks=False):
    for name in list(dirs):
        p = pathlib.Path(base) / name
        if p.is_symlink():
            symlinks.append(str(p.relative_to(WT)))
            dirs.remove(name)
    for name in files:
        p = pathlib.Path(base) / name
        rel = str(p.relative_to(WT))
        if p.is_symlink():
            symlinks.append(rel)
        else:
            data = p.read_bytes()
            present.append({'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'trackedAtHEAD': rel in TREE})
physical = {r['path']: r for r in present}
assert not symlinks, 'Symlinks require separate admission review'
rows = {}
for path in sorted(broad | all_additional):
    meta = TREE.get(path)
    assert meta and meta['kind'] == 'blob', path
    p = WT / path
    data = p.read_bytes() if p.is_file() else git('cat-file', 'blob', meta['gitBlob'])
    blob = subprocess.check_output(['git', 'hash-object', '--stdin'], input=data)
    sha = hashlib.sha256(data).hexdigest()
    if path in compiled:
        assert sha == compiled[path], 'Compiled URL/body hash mismatch: ' + path
    if path in physical:
        assert physical[path]['sha256'] == sha, 'Source changed while inventory was being captured: ' + path
    rows[path] = {'path': path, 'bytes': len(data), 'sha256': sha, 'gitBlob': meta['gitBlob'], 'headBytes': meta['bytes'], 'present': p.is_file(), 'matchesHEAD': blob.decode().strip() == meta['gitBlob'], 'reasons': sorted(reasons.get(path, {'Explicit separate download cohort'}))}

baseline = sum(r['bytes'] for r in present)
CAP = 100 * 1024**2
def cohort(name, paths):
    missing = sorted(p for p in paths if not rows[p]['present'])
    extra = sum(rows[p]['bytes'] for p in missing)
    return {'name': name, 'allowlistFiles': len(paths), 'allowlistBytes': sum(rows[p]['bytes'] for p in paths), 'missingFiles': len(missing), 'missingBytes': extra, 'residentProjectedBytes': baseline + extra, 'capBytes': CAP, 'headroomBytes': CAP - baseline - extra, 'fits': baseline + extra <= CAP, 'missingPaths': missing}

cohorts = [cohort('ordinary routes + all selectable source bodies and compiled art', core), cohort('ordinary routes + all eight current bundled packs', broad)]
cohorts += [cohort('current eight + archive ' + r['id'], broad | {r['path']}) for r in archives]
cohorts += [cohort('current eight + optional ' + r['chapterId'], broad | {r['path']}) for r in content['explicitOptionalDownloads']]
cohorts += [cohort('current eight + all four archives', broad | {r['path'] for r in archives}), cohort('current eight + all five optional originals', broad | {r['path'] for r in content['explicitOptionalDownloads']})]
stat = os.statvfs(WT)
drift = []
for row in static['files']:
    if rows[row['path']]['sha256'] != row['sha256']:
        drift.append(row['path'])
assert not drift, 'Re-run literal closure after source changed: ' + str(drift)
assert (WT / 'game/presentation/compiled/runtime.json').read_bytes() == runtime_bytes, 'Runtime changed during admission'
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('status', '--porcelain=v1').decode() == status_before, 'Working file set changed during admission'
result = {'format': 'revealline-source-browser-admission.v1', 'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': HEAD, 'worktree': str(WT), 'authority': 'Observed working bytes over pinned HEAD; NOT final committed or runtime-qualified source', 'theme': runtime['resolved']['theme'], 'runtimeSHA256': hashlib.sha256(runtime_bytes).hexdigest(), 'status': status_before.splitlines(), 'resident': {'files': len(present), 'bytes': baseline, 'trackedAtHEADFiles': sum(r['trackedAtHEAD'] for r in present), 'gitControlBytes': physical.get('.git', {}).get('bytes', 0), 'prettierFiles': sum(r['path'].startswith('node_modules/prettier/') for r in present), 'prettierBytes': sum(r['bytes'] for r in present if r['path'].startswith('node_modules/prettier/')), 'symlinks': symlinks}, 'disk': {'availableBytes': stat.f_bavail * stat.f_frsize, 'floorBytes': 2 * 1024**3}, 'compiled': {'files': len(compiled), 'bytes': sum(rows[p]['bytes'] for p in compiled), 'allPresent': all(rows[p]['present'] for p in compiled)}, 'rendererReportAvailable': bool(render), 'cohorts': cohorts, 'recommended': cohorts[1]['name'], 'allowlist': [rows[p] for p in sorted(broad)], 'separateCohortAssets': [rows[p] for p in sorted(all_additional)], 'unresolvedStaticEdges': static['unresolved'], 'actionsPerformed': ['Read source/Git blob bytes and filesystem metadata', 'Hash/union dependency inventory', 'Write metadata only to owned audit cache'], 'actionsNotPerformed': ['Populate source/assets', 'Modify source/index/planning files', 'Start HTTP server/browser', 'Run runtime suites', 'Qualify native/physical-device/release/offline journeys']}
(OUT / 'present-current.json').write_text(json.dumps({'head': HEAD, 'recordedAt': result['recordedAt'], 'files': sorted(present, key=lambda r: r['path'])}, indent=2) + '\n')
(OUT / 'admission.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'missing-paths.tsv').write_text('bytes\tgit_blob\tsha256\tpath\n' + ''.join(f"{rows[p]['bytes']}\t{rows[p]['gitBlob']}\t{rows[p]['sha256']}\t{p}\n" for p in cohorts[1]['missingPaths']))
(OUT / 'http-allowlist.txt').write_text('\n'.join(sorted(broad)) + '\n')
print(json.dumps({k: result[k] for k in ('recordedAt', 'resident', 'disk', 'compiled', 'rendererReportAvailable')}, indent=2))
print(json.dumps(cohorts, indent=2))
