"""Package supplementary original P03 evidence in cache; never run tests or modify Git."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import zipfile

ROOT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
HERE = Path(__file__).resolve().parent
OUT = HERE / 'delivery'
LIMIT = 5 * 1024**2
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda obj: (json.dumps(obj, indent=2, ensure_ascii=False) + '\n').encode()


def read(path):
    assert path.is_file() and not path.is_symlink(), path
    assert not any(p.is_symlink() for p in path.parents), path
    assert path.stat().st_size <= 2 * 1024**2, path
    return path.read_bytes()


def load(path):
    return json.loads(read(path))


def pin(path):
    raw = read(path)
    return {'sourcePath': str(path.relative_to(ROOT)), 'bytes': len(raw), 'sha256': sha(raw)}


def verified(row):
    raw = read(ROOT / row['sourcePath'])
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['sourcePath']
    return raw


def review_attempt(folder, expected_status, expected_runs=None):
    result = load(folder / 'result.json')
    assert result['status'] == expected_status and result['phaseAccepted'] is False
    assert result['physicalInputsUnchanged'] is True
    observed = []
    for run in result['results']:
        prefix = 'node' + run['version']
        assert load(folder / (prefix + '.receipt.json')) == run
        exit_record = load(folder / (prefix + '.exit.json'))
        assert all(exit_record[k] == run[k] for k in ['command', 'exit', 'termination'])
        assert run['inputsUnchanged'] and run['termination'] is None
        for stream in ['stdout', 'stderr']:
            raw = read(folder / (prefix + '.' + stream + '.log'))
            assert {'bytes': len(raw), 'sha256': sha(raw)} == run[stream]
        tap = read(folder / (prefix + '.stdout.log')).decode()
        counts = {k: int(re.findall(r'^# ' + k + r' (\d+)\s*$', tap, re.M)[-1])
                  for k in ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']}
        assert counts == run['counts']
        if expected_status == 'PASS':
            assert run['exit'] == 0 and run['passed'] and counts['tests'] == counts['pass']
            assert not any(counts[k] for k in ['fail', 'cancelled', 'skipped', 'todo'])
        before = load(folder / (prefix + '.before.json'))
        after = load(folder / (prefix + '.after.json'))
        assert {k: v for k, v in before.items() if k != 'windowFootprint'} == {
            k: v for k, v in after.items() if k != 'windowFootprint'}
        observed.append({'node': run['version'], 'completeFiles': run['completeFiles'], 'counts': counts})
    if expected_runs is not None:
        assert observed == expected_runs
    return {'attempt': str(folder.relative_to(ROOT)), 'status': result['status'],
            'runs': observed, 'phaseAccepted': False}


def review_production(folder):
    result = load(folder / 'receipt.json')
    assert result['status'] == 'PASS_CANONICAL_WRITE_AND_CHECK' and result['phaseAccepted'] is False
    assert result['originalAssetsUnchanged'] and result['logicalIndexUnchanged']
    source = load(folder / 'source.json')
    assert sha(read(folder.parent / 'run.py')) == source['helperSHA256']
    assert len(result['runs']) == 2
    for mode, run in zip(['write', 'check'], result['runs']):
        assert load(folder / (mode + '.receipt.json')) == run
        assert run['exit'] == 0 and run['command'][-1] == '--' + mode
        for stream in ['stdout', 'stderr']:
            raw = read(folder / (mode + '.' + stream + '.log'))
            assert {'bytes': len(raw), 'sha256': sha(raw)} == run[stream]
        observed = load(folder / (mode + '.stdout.log'))
        assert observed['source'] == 'field-kit' and observed['revision'] == 26
        assert observed['files'] == 131 and observed['assetBytes'] == 4007816
    before = load(folder / 'before.json')
    after = load(folder / 'after.json')
    assert after == load(folder / 'after-write.json') and len(before) == len(after) == 674
    assert set(before) == set(after)
    changed = sorted(name for name in before if before[name] != after[name])
    assert changed == sorted(result['changed']) == sorted([
        'authoring/library/fpv-field-kit/production.rltheme',
        'game/presentation/compiled/runtime.json', 'game/presentation/compiled/studio.json',
        'game/presentation/compiled/manifest.json'])
    return {'result': result, 'source': source, 'after': after}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    intake = load(HERE / 'intake.json')
    if not args.execute:
        print(json.dumps({'status': 'PREPARED_NOT_PACKAGED', 'output': str(OUT),
                          'originalsPinned': len(intake['originals']),
                          'separatePriorArchive': intake['separatePriorArchive'],
                          'compressedLimitBytes': LIMIT, 'phaseAccepted': False}, indent=2))
        return
    assert not OUT.exists(), 'Do not overwrite a previous delivery.'
    rows = list(intake['originals'])
    for row in rows:
        verified(row)
    verified(intake['separatePriorArchive'])  # Rehash only; never add its bytes to members.
    summaries = [review_attempt(ROOT / a['path'], a['expectedStatus'], a['runs'])
                 for a in intake['completedAttempts']]
    production = review_production(ROOT / intake['productionAttempt'])

    native = ROOT / intake['nativeExecution']
    retained = load(native / 'retained-manifest.json')
    native_names = {str(p.relative_to(native)) for p in native.rglob('*') if p.is_file()}
    assert native_names == {r['path'] for r in retained['files']} | {'retained-manifest.json'}
    for row in retained['files']:
        raw = read(native / row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    native_receipt = load(native / 'receipt.json')
    assert native_receipt['status'] == 'PASS_HTTP_AUDIT_AND_EXACT_SPARSE_RETIREMENT'
    assert native_receipt['phaseAcceptance'] is False and native_receipt['originalsUnchanged']
    index_hash = sha(read(native / 'full-index.before.z'))
    assert index_hash == native_receipt['logicalIndexSHA256'] == production['source']['logicalIndexSHA256']
    audit = load(native / 'http-audit.json')
    log = read(native / 'http.original.jsonl')
    assert audit['status'] == 'PASS_SOURCE_BOUND_HTTP_LOG' and audit['phaseAcceptance'] is False
    assert len(log) == audit['logBytes'] and sha(log) == audit['logSHA256']
    assert len(log.splitlines()) == audit['rows'] == 1022
    assert audit['successfulGETRows'] == 1019 and audit['observedSuccessfulPaths'] == 343
    assert audit['errors'] == [] and len(audit['expectedAbsentSourceEndpoints']) == 3

    review_root = ROOT / intake['scopedReview']
    first_review = load(review_root / 'review.json')
    final_review = load(review_root / 'final-review.json')
    assert final_review['originalReviewSHA256'] == sha(read(review_root / 'review.json'))
    assert first_review['phaseAcceptance'] is False and final_review['phaseAcceptance'] is False
    assert first_review['ledger']['revision'] == 26
    assert first_review['ledger']['sha256'] == production['after']['authoring/library/fpv-field-kit/production.rltheme']['sha256']
    rows.extend(pin(HERE / name) for name in ['package-evidence.py', 'intake.json', 'README.md'])
    assert len(rows) == len({r['sourcePath'] for r in rows})
    assert not any(r['sourcePath'] == intake['separatePriorArchive']['sourcePath'] for r in rows)
    assert not any('/tmp/' in r['sourcePath'] for r in rows)

    members = {}
    exact_bodies = {}
    for row in sorted(rows, key=lambda r: r['sourcePath']):
        raw = verified(row)
        member = exact_bodies.setdefault((row['bytes'], row['sha256']),
                                        'originals/' + row['sourcePath'].removeprefix('.cache/'))
        if member in members:
            assert members[member] == raw
        else:
            members[member] = raw
        row['member'] = member
    for a in intake['completedAttempts']:
        folder = ROOT / a['path']
        runner = load(folder / 'runner.json')
        assert any(r['sha256'] == runner['sha256'] and r['sourcePath'].endswith('.py') for r in rows)
        assert read(folder / 'full-index.before.txt') == read(folder / 'full-index.after.txt')
        assert sha(read(folder / 'full-index.before.txt')) == index_hash
        after = load(folder / 'after-all.json')
        records = {r['path']: r for r in after['files']}
        for name in production['result']['changed']:
            assert {k: records[name][k] for k in ['bytes', 'sha256']} == production['after'][name]

    readme = read(HERE / 'README.md').replace(
        b'@@BUNDLE_STATE@@', b'Packaged original evidence; independent review and P03 acceptance remain separate.')
    manifest = {'format': 'revealline-integration-evidence.v1', 'phase': 'P03', 'phaseAcceptance': False,
                'scope': 'Supplementary original production, source-browser observation/HTTP retirement, scoped review and focused test evidence. Not final-source/public/full-phase qualification.',
                'attempts': summaries, 'files': sorted(rows, key=lambda r: r['sourcePath']),
                'originalFiles': len(rows), 'originalBytes': sum(r['bytes'] for r in rows),
                'uniqueStoredOriginalFiles': len(members), 'uniqueStoredOriginalBytes': sum(map(len, members.values())),
                'duplicatePolicy': 'Identical original bytes stored once; each original path maps to its exact member. No original modified or removed.',
                'separatePriorArchive': intake['separatePriorArchive'],
                'production': {'revision': 26, 'status': production['result']['status'],
                               'sourceObservation': production['source'], 'changed': production['result']['changed']},
                'native': {'observationFile': '.cache/p03-native-integration/observations.md',
                           'servedThemeRevision': 25, 'rows': 1022, 'successfulGETRows': 1019,
                           'successfulUniquePaths': 343, 'missingSourceRequests': 3,
                           'localScreenshotArtifacts': False, 'scope': audit['boundary']},
                'fullIndexSha256': index_hash,
                'documentation': {'path': 'README.md', 'bytes': len(readme), 'sha256': sha(readme)}}
    encoded = encode(manifest)
    members.update({'manifest.json': encoded, 'README.md': readme})
    OUT.mkdir()
    archive = OUT / 'evidence.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, raw in sorted(members.items()):
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, raw)
    assert archive.stat().st_size <= LIMIT
    with zipfile.ZipFile(archive) as z:
        assert len(z.infolist()) == len(members) and set(z.namelist()) == set(members)
        for name, raw in members.items():
            assert z.read(name) == raw
        for row in rows:
            assert z.read(row['member']) == verified(row)
    verified(intake['separatePriorArchive'])
    (OUT / 'manifest.json').open('xb').write(encoded)
    (OUT / 'README.md').open('xb').write(readme)
    receipt = {'status': 'PASS_ORIGINAL_SUPPLEMENT_BYTES_ONLY', 'phaseAcceptance': False,
               'archiveBytes': archive.stat().st_size, 'archiveSha256': sha(archive.read_bytes()),
               'archiveMembers': len(members), 'originalFiles': len(rows),
               'manifestSha256': sha(encoded), 'readmeSha256': sha(readme),
               'everyOriginalAndZipMemberRehashed': True, 'gitOrSourceMutation': False,
               'priorArchiveUnchangedAndNotIncluded': True,
               'testsExecutedByPackager': False, 'independentReviewPending': True}
    (OUT / 'receipt.json').open('xb').write(encode(receipt))
    assert sum(p.stat().st_size for p in OUT.iterdir()) <= LIMIT
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
