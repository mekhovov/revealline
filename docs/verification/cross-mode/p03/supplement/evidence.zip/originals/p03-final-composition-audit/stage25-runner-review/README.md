# Runner extension for the measured fpv25 history fixture

Prepared only; not executed. `run-cohort.diff` contains the complete change from the preserved expanded runner. The changes are the new cache output location, extension hash, exact 618/674 counts and the diagnostic word “Pinned” (the new historical checkpoint is not published). Exact reverse substitution reproduces the original runner bytes, so all execution, full-index, source snapshot, generated-original, timeout, temporary-file, package and 100 MiB guards remain unchanged.

`extension.diff` adds only `game/test/fixtures/production-p03-source-fpv25.json`, 1,517 bytes, SHA-256 `e0300153ae13a816fe0ed94bb41cd0cb0114a9d8f0eecf06ba6e183122816486`, plus truthful extension status/counts. Existing fixture pins and whole-file groups remain intact. The applied fixture matched that exact original during preparation. Actual producer/test/ledger bodies are recorded at execution; no eventual revision or approval fingerprint is guessed.

After root formatting and canonical generation, run from the repository root:

```sh
python3 .cache/p03-final-composition-audit/stage25-runner-review/run-cohort.py --execute --group production --attempt production-history-reviewed
```

This runs the complete `game/test/presentation-production-history.test.mjs` sequentially on Node 20.19.5 and 22.22.2. It writes fresh evidence under this directory's `attempts/`; the earlier runner and attempts remain unchanged. The command is a prepared instruction, not an executed test or approval.
