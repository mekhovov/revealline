# P03 native exit preparation

Prepared for parent review only. The helper has not run. No browser, server, tests, source, index or remote state has been changed by preparation.

The current source is `beb0140eff7315b63269ee78ded07155de3e7084` plus the original admitted working-file hashes. `binding.json` pins the admission, all 19 original metadata/helper/receipt files, current exact sparse patterns and the 32 native-only tracked files. Its HTTP log remains live until the parent stops the server; no final request count or log hash is inferred from an intermediate read.

## Execution, after parent review

1. Finish and record browser observations. Stop the parent's existing server session 51719 on port 8897; its observed OS PID is 76119. The helper never stops or signals a server. Leave the source and index at the reviewed identity.
2. Run `python3 .cache/p03-final-composition-audit/native-exit-preparation/finish-native.py --execute` from the repository root. Without that flag, it prints the plan only. Use the reviewed helper and binding hashes; do not alter constants to fit a changed source.
3. Inspect `execution/http-audit.json`, `retire-exit.json`, `receipt.json` and `retained-manifest.json`. Keep all original files and any failed attempt. A retry requires a separately reviewed output, rather than deleting the first attempt.

The helper first requires the observed PID to be absent, then reserves the stopped local port through its work. It copies all admitted metadata and the complete final HTTP log to a fresh cache directory. It validates all 427 admitted current source-file hashes, all 674 resident files (617 source, 56 Prettier, one `.git` control file), HEAD and the full logical index.

Each logged 200 must match an allowed method, path, size and SHA-256. Only the exact source-only `favicon.ico` and `game/build-info.json` 404s are accepted separately, with the original 38-byte response and null file hash. Any 409, other status/path, malformed record or source mismatch stops the helper before sparse retirement. The report distinguishes GET, HEAD, unique observed paths and unrequested allowlist members. These are server response-attempt records; the server catches broken connections, so its log cannot prove that clients received every body, that all 427 files were requested, or that a screen was visually accepted.

After a passing audit, one Git sparse operation changes the reviewed 649 exact file patterns to the prior 617 exact file patterns. All 32 removed paths must still be unchanged regular tracked files at their original Git blobs. There are no wildcards, directory patterns, `unlink`, recursive deletion or clean/reset operations. Before and after checks preserve all resident bytes, HEAD and `git ls-files -s -z` records. Sparse checkout necessarily changes skip-worktree bookkeeping; the claim is unchanged logical index entries, not identical raw `.git/index` bytes. The final physical inventory must contain only the original 617 source files, 56 tool files and `.git` control file. Current worktree/Git allocation remains below 100 MiB.

All retirement stdout, stderr, exit and before/after identities are kept. Failure does not trigger automatic rollback or broader cleanup. The evidence output has a 24 MiB cap; the HTTP input has a 16 MiB/20,000-row cap. No generation, tests, source commit or native/public phase acceptance follows from a successful exit.

## Browser evidence when image export is unavailable

Do not invent a PNG path, original-image hash, screenshot archive or raw accessibility export. The current parent reports that CUA image export is unsupported and screenshots are available inline in its tool transcript only. Retain that failed/unsupported export observation as a limitation.

A useful finite delivery can contain:

- The original admission files, source pins, HTTP log and exit audit, each byte-hashed in the retained manifest.
- A parent-authored observation table. Mark it explicitly as a transcription/summary of the parent tool transcript, rather than raw CUA output. Each row identifies the actual journey, source/origin, viewport, input used, expected behavior, observed focus/paused state, outcome and available tool-call locator. Do not fill missing timestamps, measurements or tool locators by inference.
- A visual-review table naming which actual inline screenshot the parent inspected and what it supports. Use `retention: inline tool transcript only; no exported original` and `imageSha256: unavailable`. A screenshot shows its captured moment; checkpoint equality, physical controllers/touch and acoustic listening require their own evidence.
- Explicit failed and untested rows, including unsuccessful capture/export attempts, uncompleted navigation paths, source-only expected 404s and unresolved layout observations. Keep these separate from product regression failures.

For the current foreground fix, relevant observations are live flight → foreground loss → paused return → explicit Resume, and paused Help reader → foreground loss → retired reader → return → Back → explicit Resume. Document only journeys actually performed. A BFCache/history-return row is separate and remains pending if no persisted return was observed. Controller fixtures do not substitute for physical hardware, and resized desktop viewports do not certify phones.

Original HTTP bytes and authored observation summaries have different provenance. Packaging both together does not convert a summary into a raw capture. No entire P03 or native-store completion claim is implied by this scoped evidence scheme.
