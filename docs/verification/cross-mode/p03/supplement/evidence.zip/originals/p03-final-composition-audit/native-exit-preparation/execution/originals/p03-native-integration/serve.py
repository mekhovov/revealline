from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, unquote
import hashlib, json, mimetypes, threading, time

ROOT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
WT = ROOT / '.cache/worktrees/p03-final-integration'
HERE = Path(__file__).resolve().parent
ADMISSION = json.loads((ROOT / '.cache/p03-native-admission-902bd/admission.json').read_bytes())
FILES = {row['path']: row for row in ADMISSION['allowlist']}
LOCK = threading.Lock()
LOG = HERE / 'http.jsonl'
assert not LOG.exists(), 'Retain the earlier native server log; use a new run.'
LOG.touch()
mimetypes.add_type('text/javascript', '.mjs')
mimetypes.add_type('font/woff2', '.woff2')
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_GET(self): self.serve(False)
    def do_HEAD(self): self.serve(True)
    def serve(self, head):
        name = unquote(urlsplit(self.path).path).lstrip('/')
        if name.endswith('/') or not name: name += 'index.html'
        p = WT / name
        status, body, sha = 404, b'Not in this source-browser admission.\n', None
        if name in FILES and '..' not in Path(name).parts and p.is_file() and not any(x.is_symlink() for x in [p,*p.parents]):
            body = p.read_bytes()
            sha = hashlib.sha256(body).hexdigest()
            row = FILES[name]
            if len(body) == row['bytes'] and sha == row['sha256']: status = 200
            else: status, body = 409, b'Source changed; stop and review a fresh browser run.\n'
        self.send_response(status)
        self.send_header('Content-Type', mimetypes.guess_type(name)[0] or 'application/octet-stream')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        if not head:
            try: self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError): pass
        with LOCK:
            with LOG.open('a') as log:
                log.write(json.dumps({'time':time.time(),'method':self.command,'path':name,'status':status,'bytes':len(body),'sha256':sha})+'\n')
ThreadingHTTPServer(('127.0.0.1', 8897), Handler).serve_forever()
