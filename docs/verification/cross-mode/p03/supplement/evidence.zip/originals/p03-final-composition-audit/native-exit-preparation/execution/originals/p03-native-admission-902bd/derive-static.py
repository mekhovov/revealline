from pathlib import Path, PurePosixPath
import subprocess, json, re, posixpath, hashlib

REPO=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
WT=REPO/'.cache/worktrees/p03-final-integration'
OUT=REPO/'.cache/p03-native-admission-902bd'
inventory=json.loads((OUT/'head-tree.json').read_text())
HEAD=inventory['head']; TREE=inventory['paths']
seeds=['game/index.html','game/app.mjs','game/couch/index.html','game/couch/relay-rescue.html']
todo=list(seeds); seen={}; edges=[]; unresolved=[]; remote=[]
text_ext={'.mjs','.js','.css','.html','.json'}
def read(path):
    p=WT/path
    if p.is_file():return p.read_bytes()
    return subprocess.check_output(['git','-C',str(WT),'show',HEAD+':'+path])
def resolve(parent,spec):
    spec=spec.split('#')[0].split('?')[0]
    if not spec or spec.startswith(('data:','blob:','#')):return None
    if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',spec) or spec.startswith('//'):return ('remote',spec)
    if '${' in spec:return ('dynamic',spec)
    path=posixpath.normpath(posixpath.join(posixpath.dirname(parent),spec)) if not spec.startswith('/') else spec[1:]
    if path.endswith('/') or path in {'.','..'}:path=path.rstrip('/')+'/index.html'
    if path in TREE:return ('local',path)
    if path+'/index.html' in TREE:return ('local',path+'/index.html')
    return ('missing',path)
def add(parent,spec,kind,line):
    base='game/app.mjs' if kind=='literal-fetch' and parent.startswith('game/ui/') else parent
    found=resolve(base,spec)
    if not found:return
    typ,path=found; row={'importer':parent,'specifier':spec,'kind':kind,'line':line,'resolution':typ,'path':path,'resolutionBase':base}
    edges.append(row)
    if typ=='local' and path not in seen:todo.append(path)
    elif typ in {'missing','dynamic'}:unresolved.append(row)
    elif typ=='remote':remote.append(row)
while todo:
    path=todo.pop(0)
    if path in seen:continue
    data=read(path); actual=hashlib.sha256(data).hexdigest(); meta=TREE[path]
    p=WT/path
    same_git=subprocess.check_output(['git','hash-object','--stdin'],input=data,text=False).decode().strip()==meta['gitBlob']
    seen[path]={'path':path,'bytes':len(data),'headBytes':meta['bytes'],'gitBlob':meta['gitBlob'],'sha256':actual,'present':p.is_file(),'matchesHEAD':same_git}
    ext=PurePosixPath(path).suffix
    if ext not in text_ext:continue
    text=data.decode('utf-8')
    matches=[]
    if ext in {'.mjs','.js'}:
        patterns=[('module-import',r'\b(?:import|export)\s+(?:[^;]*?\s+from\s*)?[\"\']([^\"\']+)[\"\']'),('literal-import',r'\bimport\s*\(\s*[\"\']([^\"\']+)[\"\']'),('module-url',r'new URL\(\s*[\"\']([^\"\']+)[\"\']\s*,\s*import\.meta\.url'),('literal-fetch',r'\b(?:fetch|getJSON)\s*\(\s*[\"\']([^\"\']+)[\"\']')]
        for kind,pattern in patterns:
            for m in re.finditer(pattern,text):matches.append((m.start(),m.group(1),kind))
        # A non-literal import needs manual URL ownership review.
        for m in re.finditer(r'\bimport\s*\(\s*(?![\"\'])([^\n;]+)',text):
            unresolved.append({'importer':path,'line':text.count('\n',0,m.start())+1,'kind':'dynamic-import-review','expression':m.group(1)[:200]})
    if ext=='.css':
        for m in re.finditer(r'url\(\s*[\"\']?([^\"\')]+)[\"\']?\s*\)',text):matches.append((m.start(),m.group(1),'css-url'))
        for m in re.finditer(r'@import\s+[\"\']([^\"\']+)[\"\']',text):matches.append((m.start(),m.group(1),'css-import'))
    if ext=='.html':
        for m in re.finditer(r'<(?:script|link|img)\b[^>]*>',text,re.S|re.I):
            tag=m.group(0)
            for name,value in re.findall(r'\b(src|href|data-boot-href|data-module)=[\"\']([^\"\']+)[\"\']',tag):matches.append((m.start(),value,'html-'+name))
    for start,spec,kind in matches:add(path,spec,kind,text.count('\n',0,start)+1)
# Known nonliteral boot URL uses the classic script's own URL.
add('game/boot.mjs','./app.mjs','reviewed-boot-app-url',7)
if todo:
    raise RuntimeError('Boot seed must be added before closure; repeat with app seed')
result={'scope':'literal runtime module/HTML/CSS graph plus directly reviewable URL literals; dynamic assets reviewed separately','head':HEAD,'seeds':seeds,'files':sorted(seen.values(),key=lambda r:r['path']),'edges':edges,'unresolved':unresolved,'remote':remote}
(OUT/'static-closure.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'paths':len(seen),'bytes':sum(r['bytes'] for r in seen.values()),'missingPhysical':sum(not r['present'] for r in seen.values()),'missingPhysicalBytes':sum(r['bytes'] for r in seen.values() if not r['present']),'unresolved':unresolved,'remote':remote},indent=2))
