# P03 production-history correction proposal

Prepared in cache only. No test, producer, formatter, browser, source edit or index operation was executed. `preserve-stage25.patch` changes the history test and adds one 1,517-byte fixture; `before.test.mjs` and `candidate.test.mjs` retain the exact compared bodies.

The measured working ledger is revision 25: 6,849,997 bytes, SHA-256 `25602d3d50dcf5f3c0071d0c2b265d593db8becd0620a6bc71bb27f80e4aa901`. It is not the ledger committed at observed HEAD `beb0140eff7315b63269ee78ded07155de3e7084`. The fixture explicitly records an uncommitted source-stage observation, not a published source. It pins canonical group hashes, complete reconstructed bundle bytes and the original payload set.

Actual structure: 293 slots, 1,096 assets, 26 themes and one collection. The published P02 prefixes are exact. Fourteen assets are appended: seven screen recipes at revision 13 and seven rotor recipes at revision 6, all **source** quality. Their parents remain screen@12 and rotor@5; fpv25 has parent fpv24 and only those fourteen bindings, with no token changes. All 127 original payloads / 4,007,816 bytes are unchanged and individually verified. No binary ledger copy is needed.

The patch does three things:

1. Preserves the independent published P01 → P02 test, including explicit audio7/fpv24 counts, exports, compiled changes and immutable-history rejection. Its only change is the helper's generalized name; helper diagnostics now say “pinned” because the new checkpoint is not published.
2. Adds a historical fpv25 checkpoint test: reconstruct the exact measured stage from the current ledger, verify P02 prefixes, the fourteen source assets and parents, unchanged payloads and exact theme bindings. Any later review must retain these original records.
3. Makes current reproduction match the CLI: call `retainProductionHistory` with the **complete current ledger** as prior, then demand the same revision, canonical document and repeat-export bytes. Reconstructing directly from P02 would flatten intermediate stages. Reproducing from fpv25 alone would have the same problem after multiple later successors. The full-ledger approach accommodates measured successors without guessing fpv26 or any future counts.

`validateThemeBundle({previous: ...})` requires exactly one revision advance. It cannot validate an unchanged reproduction. The new idempotence check uses `{expectedRevision: prior.revision}` without `previous`; the separate actual P02 → fpv25 transition retains the one-step validation.

The existing current motion/effects test incorrectly expects changed rotors to retain their old v0.54 review. The patch keeps the ten unchanged feedback recipes under that exact approval and moves all seven rotors into explicit historical source-stage assertions. It does **not** grant current P03 review approval. After actual source/native review, retain measured approval text and fingerprints and add the scoped current-approval assertions as part of that review delivery. Final readiness remains a separate gate. Existing UI/audio review, source-invalidation and capacity tests remain byte-identical.

One additional finite source admission is required before the whole-file run: `game/test/fixtures/production-p03-source-fpv25.json` (SHA-256 `e0300153ae13a816fe0ed94bb41cd0cb0114a9d8f0eecf06ba6e183122816486`). Extend the runner's explicit source/fixture manifest from 617 to 618 paths; do not silently relax its physical-file check. Run the complete `game/test/presentation-production-history.test.mjs` after parent application/formatting and canonical generation. No passing result is claimed here.
