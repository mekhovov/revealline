from pathlib import Path
import sys,json,subprocess,time,hashlib,os,shutil
runtime=sys.argv[1]
node=f'/Users/oleksandr.mekhovov/.local/share/mise/installs/node/{runtime}/bin/node'
roots=[f'game/test/{name}.test.mjs' for name in ['coop-actor-presentation','actor-presentation','coop-view-presentation','coop-host','coop-picture-host','display-preferences-host','menu-style-host']]
if len(sys.argv)>2: roots=sys.argv[2:]
folder=Path('.cache/team-actors')
held=folder/'source-held-05.json'
assert shutil.disk_usage('.').free>256*1024*1024
for row in json.loads(held.read_text())['files']:
 b=Path(row['path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],row['path']
def pins():
 out=[]
 for directory in ['game','authoring']:
  for p in sorted(Path(directory).rglob('*')):
   if p.is_file():
    b=p.read_bytes();out.append(dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
 return out
before=pins(); label=os.environ.get('ACTOR_TEST_LABEL','whole-node'+runtime.split('.')[0]); log=folder/(label+'.log'); receipt=folder/(label+'.json')
assert not log.exists() and not receipt.exists()
started=time.monotonic();argv=[node,'--test','--test-concurrency=1',*roots]
with log.open('wb') as output: result=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT)
after=pins(); raw=log.read_bytes()
data=dict(base='d3ff0bc1e9948f5752e79c5b21c8207dd74c69e1',runtime=subprocess.check_output([node,'--version'],text=True).strip(),argv=argv,files=roots,elapsedSeconds=time.monotonic()-started,exitCode=result.returncode,log=dict(path=str(log),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),before=before,after=after,unchanged=before==after)
receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps({k:v for k,v in data.items() if k not in ['before','after']}));print(raw.decode(errors='replace')[-1800:]);sys.exit(result.returncode)
