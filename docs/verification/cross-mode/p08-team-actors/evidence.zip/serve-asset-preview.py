from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import hashlib,json
folder=Path(__file__).resolve().parent
body=(folder/'actor-source-preview.html').read_bytes()
expected='633321991603f73b998aaca474c73791d9a8a6baa0d9daf2a94ed5bac2ed8f95'
assert hashlib.sha256(body).hexdigest()==expected
class Handler(BaseHTTPRequestHandler):
 def do_HEAD(self):self.reply(False)
 def do_GET(self):self.reply(True)
 def reply(self,send):
  if self.path!='/team-actors' or self.headers.get('Host')!=f'127.0.0.1:{self.server.server_port}':self.send_error(404);return
  self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers()
  if send:self.wfile.write(body)
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
binding={'url':f'http://127.0.0.1:{server.server_port}/team-actors','htmlBytes':len(body),'htmlSha256':expected,'helperSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Immutable standalone source-asset contact sheet only; embedded exact PNG bodies. No application routes, state, runtime or image substitutions; root owns browser inspection.'}
with (folder/'asset-preview-binding.json').open('x') as f:json.dump(binding,f,indent=2);f.write('\n')
print(json.dumps(binding),flush=True)
server.serve_forever()
