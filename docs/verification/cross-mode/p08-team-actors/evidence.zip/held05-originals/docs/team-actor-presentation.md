# Team actor presentation candidate

This internal P08-A slice builds on the Team picture host checkpoint `d3ff0bc1e9948f5752e79c5b21c8207dd74c69e1`. It is a read-only drawing adapter, with no Team core, level, replay, scoring, host input, producer or compiled-registry change. It is not phase or release acceptance.

## Explicit roles and existing artwork

| Team presentation role | Prepared source slot                             | Retained Team meaning                                                                      |
| ---------------------- | ------------------------------------------------ | ------------------------------------------------------------------------------------------ |
| Pilot 1 and Pilot 2    | `player.scout.compact` / `player.scout.detailed` | Equal-capability players; number plus circle/diamond identification, downed and grace cues |
| Field-bouncer          | `enemy.bouncer`                                  | Actual Team drifter movement and contact radius                                            |
| Line-hunter            | `enemy.border-patrol`                            | Actual Team hunter; target lock, charge and recovery remain Team states                    |
| Stronghold core        | `enemy.relay-sentinel`                           | Stationary authored structure, shield, anchors and capture state                           |

The hunter reuses an existing coral quad image, not Solo border-patrol behavior. The pilot image does not adopt the Solo Scout class. These are five existing source frames, not new Team character sets. The exact `fpv@19` / null-collection compiled snapshot and PNG hashes are pinned in the source inventory and new test. No accepted source authority is broadened.

`coop-actor-presentation.mjs` borrows prepared images and geometry from the accepted page snapshot. It acquires, decodes and closes no resources. A replacement snapshot resets only cosmetic history. Missing images retain the prior geometric drawing; that fallback does not prove shared-art readiness. The accepted Team picture host still owns the candidate/accepted presentation boundary.

## Drawing and motion

The adapter reuses the shared actor sampler, body-size policy and prepared-image renderer. Position observations determine heading; Team ticks and elapsed active time drive cosmetic phases. Pause, downed state and reduced motion freeze the relevant accents. New attempts reset history. The shared renderer draws pilot rotors from prepared geometry; this slice does not add newly authored tread, hunter or stronghold animation sequences.

All body images are painted before functional overlays. Player numbers retain circle/diamond form cues, including the player number when downed. Required labels get a dark backing over artwork. Hunter lock/charge/recovery and slow labels clear the cosmetic body; grace and slow states retain dashed patterns. Stronghold art uses the shared boss-size policy beneath anchors and shield/capture labels, without creating a circular core hitbox. Player/enemy contact markers keep the real radii.

Compact/detailed source selection is separate from display scaling: microtile or a canvas below 480 CSS pixels selects the compact pilot frame. Shared CSS-size limits still apply. A 64-pixel source is not a 64-pixel rendered body or a larger hitbox. The sampled 16-pixel source preview does not establish detail readability; numbers, form and phase cues remain necessary.

## Evidence boundary

The standalone source sheet was visually reviewed at 1924×1356, DPR 2. At 32 pixels the tracked vehicle, quad and radar structure were distinct; 24 pixels retained coarse shapes. Fine details at 16 pixels cannot carry identity alone. This is source-sheet evidence, not actual-arena or motion acceptance.

New tests observe real Team run continuity, exact existing PNG hashes/headers, prepared image identity, geometry, sampled poses and canvas commands. Their image objects are modeled; they do not prove browser decode, bright-art contrast, clipped-border readability, physical devices or complete actor parity. Whole-file execution and actual-arena visual qualification remain pending at the initial source hold. No full Team win/rescue or all-character-set claim is added.

The initial whole Node 22 run exposed a real lookup omission: it used the source-image name `bouncer` instead of the strict Team type `drifter`. That failed 150/158 run is retained, and this successor preserves actual `drifter` identity while explicitly reusing the field-bouncer image. A separate minimum-radius regression reproduced the shared sampler's cosmetic clamp (0.05 versus Team's valid 0.01); Team frames now keep the actual radius. Source review alone did not establish these boundaries.

At phone widths the inherited 0.57/0.66-cell labels can render near three CSS pixels. Backing plates do not establish readability; actual-size player-number, hunter-warning, heading and shape checks against bright and dark revealed artwork remain required. Catalog `bodyRecord` surface-motion accents are not passed to the shared renderer in this slice; their explicit Team mapping remains P08-B work, without new loaders or behavior aliases.
