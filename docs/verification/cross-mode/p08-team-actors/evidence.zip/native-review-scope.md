# Actor review scope

Source: d3ff0bc Team picture host plus the two held actor overlays. Inspect actual arena drawing at desktop and portrait sizes, both dark/unrevealed and bright/revealed artwork; record the actual CSS canvas size and DPR. The five-source sheet is not arena or 16-pixel readability approval.

Check player 1/2 numbers with circle/diamond identity, edges and nearby actors; heading; warning/charge/recovery; downed/grace; slow pattern; stronghold anchors/shield/capture labels. Pause and reduced motion must retain functional cues. No native full-win/rescue or physical-input claim follows from these limited visual journeys. Existing bodyRecord enemy surface accents remain outside this slice.

Primary guidance independently opened 2026-09-16: [Xbox XAG102](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/102) calls for important gameplay elements to remain distinguishable across changing backgrounds; it discusses solid text backgrounds and borders. Test against the least favorable observed background, not only isolated palette values. [Xbox XAG103](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/103) supports additional ways of conveying cues instead of depending on color alone. Shape/number and phase/pattern evidence is separate from token contrast, and neither establishes full accessibility acceptance.

Current held labels still use inherited cell-sized text. At portrait scale they may be too small; capture the actual result before a bounded CSS-pixel-scaled cue successor. Source-only arithmetic and opaque backing do not prove text readability.
