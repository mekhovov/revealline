import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createCoop } from '../coop/core.mjs';
import { FIRST_CONNECTION } from '../coop/first-connection.mjs';
import { createCoopPainter } from '../couch/coop-view.mjs';
import { imagePresentation } from '../presentation/runtime.mjs';
import { validateCompiledPresentation } from '../presentation/host.mjs';

const compiled = validateCompiledPresentation(
  JSON.parse(await readFile(new URL('../presentation/compiled/runtime.json', import.meta.url))),
);
const palette = {
  ink: '#f6f3e8',
  paper: '#071527',
  muted: '#a8b8cc',
  accent: '#ffd64a',
  safe: '#67aaff',
  danger: '#ff7169',
  field: '#10243e',
  grid: '#182b43',
  sky: '#233950',
  land: '#526e67',
};
const snapshot = {
  canvas: { palette, motionScale: 1 },
  fonts: { ui: 'Prepared UI', numeric: 'Prepared Mono' },
  image(slot) {
    const asset = compiled.resolved.assets[slot];
    return asset ? { image: { slot }, geometry: imagePresentation(asset) } : null;
  },
};
function surface(width = 362) {
  const calls = [],
    stack = [];
  let state = {
    matrix: [1, 0, 0, 1, 0, 0],
    globalAlpha: 1,
    imageSmoothingEnabled: true,
    font: '10px sans-serif',
  };
  const multiply = ([a, b, c, d, e, f]) => {
    const [g, h, i, j, k, l] = state.matrix;
    state.matrix = [
      g * a + i * b,
      h * a + j * b,
      g * c + i * d,
      h * c + j * d,
      g * e + i * f + k,
      h * e + j * f + l,
    ];
  };
  const ctx = new Proxy(
    {},
    {
      get(_, name) {
        if (name in state) return state[name];
        return (...args) => {
          calls.push({ name, args, state: { ...state, matrix: [...state.matrix] } });
          if (name === 'save') stack.push({ ...state, matrix: [...state.matrix] });
          if (name === 'restore') state = stack.pop();
          if (name === 'translate') multiply([1, 0, 0, 1, ...args]);
          if (name === 'scale') multiply([args[0], 0, 0, args[1], 0, 0]);
          if (name === 'rotate') {
            const c = Math.cos(args[0]),
              s = Math.sin(args[0]);
            multiply([c, s, -s, c, 0, 0]);
          }
          if (name === 'measureText')
            return {
              width: String(args[0]).length * Number(state.font.match(/([\d.]+)px/)[1]) * 0.64,
            };
        };
      },
      set(_, name, value) {
        state[name] = value;
        return true;
      },
    },
  );
  return {
    canvas: { width: 1152, height: 576, clientWidth: width, getContext: () => ctx },
    calls,
    ctx,
  };
}
function bounds(call) {
  const [a, b, c, d, e, f] = call.state.matrix;
  const [, x, y, w, h] = call.args;
  const corners = [
    [x, y],
    [x + w, y],
    [x, y + h],
    [x + w, y + h],
  ].map(([px, py]) => [a * px + c * py + e, b * px + d * py + f]);
  return {
    left: Math.min(...corners.map((p) => p[0])),
    right: Math.max(...corners.map((p) => p[0])),
    top: Math.min(...corners.map((p) => p[1])),
    bottom: Math.max(...corners.map((p) => p[1])),
  };
}

test('portrait functional player numerals retain at least fourteen CSS pixels', () => {
  const run = createCoop(FIRST_CONNECTION),
    v = surface(),
    p = createCoopPainter(v.canvas);
  p.setPresentation(snapshot);
  p.paint(run);
  for (const id of ['1', '2']) {
    const label = v.calls.find((c) => c.name === 'fillText' && c.args[0] === id);
    assert.ok(label);
    const css = (Number(label.state.font.match(/([\d.]+)px/)[1]) * 362) / 72;
    assert.ok(css >= 14 - 1e-9, `${id} is ${css} CSS pixels`);
  }
});
test('pilot complete image frames remain within the arena at the true boundary', () => {
  const run = createCoop(FIRST_CONNECTION),
    v = surface(),
    p = createCoopPainter(v.canvas);
  run.players[0].x = 0.5;
  run.players[0].y = 0.5;
  run.players[1].x = 71.5;
  run.players[1].y = 35.5;
  const before = structuredClone(run);
  p.setPresentation(snapshot);
  p.paint(run);
  for (const call of v.calls.filter(
    (c) => c.name === 'drawImage' && c.args[0].slot.startsWith('player.'),
  )) {
    const b = bounds(call);
    assert.ok(b.left >= 0 && b.top >= 0 && b.right <= 1152 && b.bottom <= 576, JSON.stringify(b));
  }
  assert.deepEqual(run, before);
});
