from pathlib import Path
import json,hashlib,re,subprocess,shutil
folder=Path('.cache/team-actors')
assert shutil.disk_usage('.').free>256*1024*1024
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
held=folder/'source-held-06.json'; hold=json.loads(held.read_text())
for row in hold['files']+hold['inputs']:
 assert pin(Path(row['path']))==row,row['path']
results=[];common=None
for node in ['22','20']:
 p=folder/f'whole-03-node{node}.json';data=json.loads(p.read_text());assert data['exitCode']==0 and data['unchanged'] and data['before']==data['after']
 if common is None:common=data['before']
 else:assert common==data['before']
 log=Path(data['log']['path']);assert pin(log)==data['log']
 raw=log.read_text();summary={name:int(re.findall(r'^# '+name+r' (\d+)$',raw,re.M)[-1]) for name in ['tests','pass','fail','cancelled','skipped','todo']}
 assert summary=={'tests':167,'pass':167,'fail':0,'cancelled':0,'skipped':0,'todo':0}
 results.append(dict(runtime=data['runtime'],receipt=pin(p),log=pin(log),elapsedSeconds=data['elapsedSeconds'],files=data['files'],summary=summary))
result=dict(base=hold['base'],hold=pin(held),sourceFiles=hold['files'],inputs=len(common),inputBytes=sum(r['bytes'] for r in common),sameInputsAcrossBothRuntimes=True,results=results,predecessor=pin(folder/'verification-tests.json'),readabilityBaseline=pin(folder/'readability/before.json'),readabilityTargeted=pin(folder/'readability/layout-01.json'),scope='Held06 eight complete files:167/167 each Node; source/command and actual-host scopes only. Held05 seven-file159 pair and native readability failure retained separately; no additive phase total or native acceptance. Two original command failures0/2 and successor2/2 are characterization, not extra complete-file coverage.')
p=folder/'verification-readable-tests.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(receipt=pin(p),inputs=result['inputs'],inputBytes=result['inputBytes'],results=results),indent=2))
