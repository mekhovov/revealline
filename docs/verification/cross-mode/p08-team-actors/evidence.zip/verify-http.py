from pathlib import Path
import json,hashlib,subprocess,urllib.request,sys,time
folder=Path('.cache/team-actors');binding=json.loads((folder/'preview/binding.json').read_text());base=binding['base'];overlays={r['path']:r for r in binding['overlays']}
paths=list(overlays)+['game/couch/relay-rescue.mjs','game/couch/relay-rescue.html','game/couch/relay-rescue.css','game/presentation/compiled/runtime.json','game/ui/actor-presentation.mjs','game/ui/presentation-draw-image.mjs','game/coop/core.mjs','game/couch/coop-picture-bindings.mjs']
paths += [r['localPath'] for r in json.loads((folder/'actor-asset-inventory.json').read_text())['roles']]
rows=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
for path in paths:
 expected=Path(path).read_bytes() if path in overlays else subprocess.check_output(['git','show',base+':'+path])
 if path in overlays: assert len(expected)==overlays[path]['bytes'] and sha(expected)==overlays[path]['sha256']
 url=f'http://127.0.0.1:{binding["port"]}/{path}'
 with urllib.request.urlopen(url,timeout=20) as response: actual=response.read();status=response.status
 assert status==200 and actual==expected,path
 local=Path(path).read_bytes();assert local==expected,path
 rows.append({'path':path,'bytes':len(actual),'sha256':sha(actual),'authority':'held overlay' if path in overlays else 'exact Git '+base,'status':status,'httpAndLocalExact':True})
receipt={'base':base,'hold':binding['sourceHoldSha256'],'atUnix':time.time(),'binding':{'path':str(folder/'preview/binding.json'),'bytes':len((folder/'preview/binding.json').read_bytes()),'sha256':sha((folder/'preview/binding.json').read_bytes())},'helper':{'path':str(folder/'preview/serve.py'),'bytes':len((folder/'preview/serve.py').read_bytes()),'sha256':sha((folder/'preview/serve.py').read_bytes())},'rows':rows,'scope':'Exact 15 source/metadata/asset HTTP and local body checks. No browser/action/state/readability or phase acceptance.'}
p=folder/('http-'+sys.argv[1]+'.json');assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(p),'bytes':len(p.read_bytes()),'sha256':sha(p.read_bytes()),'rows':len(rows),'binding':receipt['binding'],'url':binding['url']}))
