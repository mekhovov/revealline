# Team actor adapter: bounded implementation plan

Base d3ff0bc1e9948f5752e79c5b21c8207dd74c69e1; separate finite p08-team-actors worktree. The incoming host checkpoint, its native originals and its incomplete full-win/device/actor gates remain unchanged.

| Team presentation role | Existing prepared image slot | Kept functional identity |
| --- | --- | --- |
| Pilot (both equal-capability seats) | player.scout.compact / player.scout.detailed | 1/2 plus circle/diamond cues; no Solo class adoption |
| Field-bouncer | enemy.bouncer | Team bouncer type, physical radius and motion |
| Line-hunter | enemy.border-patrol | Explicit Team hunter role; locked target, warning, charge/recovery text and slow cue; no border-patrol behavior/type alias |
| Stronghold core | enemy.relay-sentinel | Existing core/shield, anchor labels, warning lane and secured/capture cues; no new collision circle |

All five exact tuples and the compiled fpv19/null authority are in actor-asset-inventory.json. This is source-slot reuse, not a new Team character set or registration. Root reviewed the standalone sheet:32px bodies distinct,24px coarse shapes retained;16px detail cannot carry recognition alone. Sprite source resolution and CSS display scale stay separate. No new imagery is required for this bounded candidate.

Production scope: new game/couch/coop-actor-presentation.mjs and a small integration in coop-view.mjs. Reuse createActorPresentation, actorDiameter and drawPresentedActor from the existing shared module with the snapshot's already prepared image/geometry. Snapshot/page lifetime owns pixels; this adapter fetches/disposes nothing. No Team host, HTML/CSS, renderer registry, schema, core, replay, score or input edits. New adapter retains only cosmetic samples and current attempt identity; new attempt/presentation resets them. Tick/time deltas bound cosmetic motion, repeated paused frames cannot advance, reduced motion uses the shared freeze behavior. Active warning/recovery/slow/downed/grace and numbers remain foreground overlays independent of decorative animation.

Player and enemy art may be larger than the authoritative radius; contact cues retain the actual radius. Boss art uses the shared boss size policy. Render the stronghold art behind shield/anchor/phase annotations, with label clearance based on the chosen body envelope. Unknown/unavailable presentation keeps the existing honest geometric fallback, without pretending a missing Team role was acquired.

Tests: exact finite mapping and prepared asset identity; compact/detailed selection from actual CSS width; CSS frame-scale bounds distinct from physical radius; heading, paused/reduced clocks, repeated-tick and new-attempt reset; frozen source/run unchanged; no fetch/dispose ownership; actual painter drawImage calls plus preserved 1/2/form/locked/charge/recovery/slow/downed/grace/shield/anchor cues. Keep original frame/crop identity and no opaque fill over current picture. Whole affected painter/actor/presentation/host files on both Nodes only after source hold/peer. Source tests are not pixel/readability/device approval. Root must inspect both actual arenas over bright/dark revealed artwork and motion before checkpoint acceptance.
