from pathlib import Path
import subprocess,json,hashlib,os,re
b=Path(__file__).resolve().parents[2];c=b/'.cache/tour'
sha=lambda d:hashlib.sha256(d).hexdigest()
def git(*a):return subprocess.check_output(['git','--no-optional-locks','-C',str(b),*a])
base='1f3b9995af43879d54fb7b0053846f0723e2e069';assert git('rev-parse','HEAD').decode().strip()==base
inventory=b.parent/'p07-next-result-transaction/.cache/next-result/qualification-inputs-held07.json'
paths={r['path'] for r in json.loads(inventory.read_text())['inputs']}
# Literal import closure of all admitted JavaScript plus the new entry. The old
# fixture inventory supplies dynamic installed/R5 bodies; this adds newly inherited imports.
entries={}
for line in git('ls-tree','-r',base).decode().splitlines():
 mode,kind,rest=line.split(' ',2);oid,path=rest.split('\t',1);entries[path]=(mode,kind,oid)
modified={'game/couch/couch.mjs','game/couch/couch-shell.mjs','game/couch/couch-installed-chapters.mjs','game/couch/index.html','game/test/couch-static-picture-host.test.mjs'}
new={'game/couch/couch-progression.mjs','game/test/couch-progression.test.mjs','game/test/couch-progression-host.test.mjs'}
cache={}
def body(p):
 if p in modified or p in new:return (b/p).read_bytes()
 if p not in cache:cache[p]=git('cat-file','blob',entries[p][2])
 return cache[p]
queue=list(paths|new);seen=set();missing=[];edges=[]
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p)
 if p not in entries and p not in new:raise ValueError('No Git authority '+p)
 if not p.endswith(('.mjs','.js')):continue
 s=body(p).decode()
 refs=re.findall(r'(?:from\s*|import\s*\(?\s*)[\'\"](\.[^\'\"]+)[\'\"]',s)
 for ref in refs:
  q=os.path.normpath(str(Path(p).parent/ref)).split('?')[0]
  if q not in entries and q not in new:
   if q=='game/native/bridge.mjs':missing.append({'from':p,'path':q,'scope':'Generated native bridge, platform guard; not local web input.'});continue
   raise ValueError((p,ref,q))
  edges.append({'from':p,'to':q});paths.add(q);queue.append(q)
paths|=new
estimated=sum(len(body(p)) for p in paths)
physical=sum(p.stat().st_size for p in b.rglob('*') if p.is_file() and not p.is_symlink())
additional=sum(len(body(p)) for p in paths if not (b/p).exists())
free=os.statvfs(b).f_bavail*os.statvfs(b).f_frsize
assert physical+additional<100*1024**2,(physical,additional)
assert free-additional>=2*1024**3,free
before=git('ls-files','--stage','-z');rows=[]
for p in sorted(paths):
 d=body(p);target=b/p
 if p not in new:
  assert entries[p][0]=='100644' and entries[p][1]=='blob',p
 if target.exists():assert target.read_bytes()==d,p
 else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(d)
 rows.append({'path':p,'bytes':len(d),'sha256':sha(d),'gitBlob':entries.get(p,[None,None,None])[2],'workingCandidate':p in modified or p in new})
assert git('ls-files','--stage','-z')==before
result={'base':base,'sourceInventory':{'path':str(inventory),'sha256':sha(inventory.read_bytes())},'inputCount':len(rows),'inputBytes':estimated,'newBytes':additional,'ownedBytesBefore':physical,'freeBefore':free,'freeAfter':os.statvfs(b).f_bavail*os.statvfs(b).f_frsize,'canonicalIndexSha256':sha(before),'excluded':missing,'literalEdges':len(edges),'files':rows}
(c/'host-fixture-intake.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['inputCount','inputBytes','newBytes','freeAfter','literalEdges','excluded']}))
