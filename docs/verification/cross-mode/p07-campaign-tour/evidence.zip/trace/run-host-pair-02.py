#!/usr/bin/env python3
"""Run nine complete P07 host/progression files against an exact finite intake."""
from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, time

ROOT = Path(__file__).resolve().parents[2]
CACHE = ROOT / '.cache/tour'
OUT = CACHE / 'host-pair-02'
BASE = '1f3b9995af43879d54fb7b0053846f0723e2e069'
TREE = 'cd4fa75395f045ffa02375e1784072044c2020d4'
FLOOR = 2 * 1024 ** 3
NODES = [Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node') / v / 'bin/node'
         for v in ['22.22.2', '20.19.5']]

def sha(body): return hashlib.sha256(body).hexdigest()
def pin(path, name=None):
    body = path.read_bytes()
    return {'path': name or str(path), 'bytes': len(body), 'sha256': sha(body)}
def git(*args): return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=ROOT)
def require(ok, message):
    if not ok: raise RuntimeError(message)
def write(name, value): (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

OUT.mkdir(exist_ok=False)
held_path = CACHE / 'host-source-held-04.json'
inputs_path = CACHE / 'host-inputs-held04.json'
held = json.loads(held_path.read_text())
inputs = json.loads(inputs_path.read_text())
expected = inputs['files']
require(inputs['sourceHeldSha256'] == sha(held_path.read_bytes()), 'Source authority differs from intake')
require(held['base'] == inputs['base'] == BASE, 'Wrong admitted base')
index = git('ls-files', '--stage', '-z')
(OUT / 'canonical-index-before.bin').write_bytes(index)
tracked = git('diff', '--name-only')
require(set(tracked.decode().splitlines()) == {
    r['path'] for r in held['paths'] if r['path'] not in [
        'game/couch/couch-progression.mjs', 'game/test/couch-progression.test.mjs',
        'game/test/couch-progression-host.test.mjs']}, 'Unexpected changed tracked paths')
authorities = [pin(p) for p in [held_path, inputs_path, Path(__file__)]]
runtimes = [pin(p) for p in NODES]

def guard(label):
    free = shutil.disk_usage(ROOT).free
    require(free >= FLOOR, '2 GiB reserve unavailable')
    require(git('rev-parse', 'HEAD').decode().strip() == BASE, 'HEAD changed')
    require(git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE, 'Base tree changed')
    require(git('ls-files', '--stage', '-z') == index, 'Canonical index changed')
    require(not git('diff', '--cached', '--name-only'), 'Staged changes appeared')
    require(git('diff', '--name-only') == tracked, 'Tracked path list changed')
    require([pin(ROOT / r['path'], r['path']) for r in expected] == expected, 'Admitted input bytes changed')
    require([pin(Path(r['path'])) for r in authorities] == authorities, 'Qualification tools changed')
    require([pin(Path(r['path'])) for r in runtimes] == runtimes, 'Runtime changed')
    physical = sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file() and not p.is_symlink())
    require(physical < 100 * 1024 ** 2, 'Finite checkout exceeds 100 MiB')
    write(label + '.json', {'freeBytes': free, 'physicalBytes': physical,
        'canonicalIndexSha256': sha(index), 'inputs': expected})

write('authority.json', {'scope': 'Nine complete bounded P07 progression/Couch host files on two local Node runtimes. DOM/decode boundaries are modeled; no native or full-phase qualification.',
    'base': BASE, 'tree': TREE, 'authorities': authorities, 'runtimes': runtimes,
    'tests': held['suite'], 'inputCount': len(expected), 'inputBytes': sum(r['bytes'] for r in expected),
    'started': datetime.datetime.now(datetime.timezone.utc).isoformat()})
runs = []
try:
    guard('before')
    for node in NODES:
        version = subprocess.check_output([str(node), '--version'], text=True).strip()
        command = [str(node), '--test', '--test-reporter=tap', '--test-concurrency=1', *held['suite']]
        log = OUT / ('node' + version.split('.')[0][1:] + '.log')
        print('Starting ' + version + ' against ' + str(len(held['suite'])) + ' complete files.', flush=True)
        begin = time.monotonic()
        with log.open('xb') as output:
            completed = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, timeout=1200)
        summary = {key: int(value) for key, value in re.findall(
            r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$', log.read_text(), re.MULTILINE)}
        run = {'version': version, 'command': command, 'exitCode': completed.returncode,
            'elapsedSeconds': round(time.monotonic() - begin, 6), 'summary': summary, 'log': pin(log)}
        runs.append(run); write('runs.json', runs)
        guard('after-node' + version.split('.')[0][1:])
        require(completed.returncode == 0 and summary.get('tests', 0) > 0 and
            summary.get('tests') == summary.get('pass') and
            all(summary.get(key) == 0 for key in ['fail','cancelled','skipped','todo']),
            'Complete bounded suite failed: ' + version)
        print(json.dumps(run), flush=True)
    write('verification.json', {'status': 'passed', 'runs': runs, 'authority': pin(OUT / 'authority.json'),
        'limits': 'No browser, composed P02 source, full source gates or phase acceptance.'})
except Exception as error:
    write('failure.json', {'error': str(error), 'runs': runs,
        'time': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    raise
