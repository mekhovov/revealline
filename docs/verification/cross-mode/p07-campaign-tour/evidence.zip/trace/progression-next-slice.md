# P07 progression: finite next-slice proposal

Read-only design against `99f33086c5c381cd91459e59e672c4adba1fe18d`. The eleven inspected inputs are pinned in `progression-design-inputs.json`. No implementation or new behavioral execution is claimed. The future implementation base must include the reviewed P03/P05 composition and P07 transaction; this note does not authorize overwriting their shell, picture, or navigation owners.

## Existing authority and concrete gap

The approved register, `docs/cross-mode-execution.md:183`, explicitly says: “Default Versus is one race; optional first-to-two counts wins, not draws. An in-memory tour awards one point per mission win; rematch replaces its earlier result.” It also requires named successor mission/campaign or completion destination and independent Solo progress. This is the authority for changing the currently hard-coded default; it is not a newly inferred preference.

Versus currently has a single `won` array and a per-duel `finished` guard. The guard prevents repeated rendering of one terminal duel from incrementing the score again. `prepareNext()` at `couch.mjs:594` creates another duel from exactly the same `roundRecipe`; `resetWins` tests the literal threshold two. The finish block at line 1315 and shell title at `couch-shell.mjs:324` use the same threshold. Setup has no format control and its footnote explicitly advertises first-to-two. Thus the retained-results checkpoint makes Next safe but does not advance a mission or implement a tour.

The content already supplies ordered missions: First Signal revision 2 has twelve, beginning First Signal → Relay Orchard → Crosswind; Pressure Lines revision 1 has three, Orchard Crossing → Courtyard Exits → Night Crossfire. Installed rows follow each exact standard execution campaign's authored `levels` order. The combined map menu is featured maps, then base maps, then installed maps; that flattened menu order is not authority for a cross-campaign successor.

Solo already derives its next uncleared mission through `currentSelection()` / `createDifficultyNavigation().selection()` / `campaignSelection()`. Its result button says only “Next uncleared mission”; at completion it shows “View collection”. The continuation tests explicitly prohibit implicit first-level replay after completion. No successor-campaign field or order was found in the inspected campaign/pack navigation sources. Naming the already-resolved mission is a small separate copy/host slice; automatically choosing another campaign needs an explicit catalogue contract and is outside this proposal.

## Recommended player contract

Use one explicit Setup format choice with three named options: **One race** (default, per the approved contract), **First to two**, and **Campaign tour**. A tour is explicitly selected and runs one race per mission. Combining best-of-three and tours is not needed for this first bounded slice. All choices remain session memory and never write profile preferences or Solo awards.

- One race ends after one terminal duel, including a draw. Results offer **Rematch · [mission]**, View, and existing Setup. A draw grants no win.
- First to two retains the current same-mission series. Draws do not increment either side; before a winner, the action says **Next round · [mission]**. After two wins it says **Rematch match · [mission]**. Reset only when the new duel/image transaction commits.
- Campaign tour uses the exact campaign containing the chosen map. A new tour starts at that campaign's first authored mission; Setup must say **Start tour · [campaign] · [count] missions** and identify the first mission before activation. This avoids a hidden partial-tour interpretation when the map selector was previously on a later mission.
- A completed tour mission offers **Next · [exact next mission]** plus **Rematch · [current mission]** and View. At the final mission, show **Tour complete · [campaign]**, totals, and **Choose campaign** using the existing Setup transition; keep explicit rematch and View. Do not wrap silently or jump to another campaign.
- A tour awards one point per mission winner. Its total is derived from a finite per-mission result map. A completed rematch replaces that mission's prior winner, including removing the prior point when the rematch draws. While rematch preparation or play is pending, keep the previously completed tour record; replace it only on the new accepted terminal duel.

## Minimal ownership/API change

Introduce a small in-memory progression owner, separate from deterministic `multiplayer.mjs` and Solo progress. Suggested operations are `snapshot()`, `settle({duelId, winner})`, `plan(action)`, and `commit(plan, duelId)`. Exact signatures should be finalized in source review; no persistent version/schema is needed.

The host gives it a frozen ordered list of exact campaign choices and a session identity. Shipped choices receive the existing full campaign identity, and installed choices keep their checked execution key and original row object. Titles and a numeric menu index never authorize selection. Deduplicate or reject ambiguous identities at construction; do not merge installed and shipped rows merely because names match.

`settle` only accepts the current adopted duel once. It derives standalone/series/tour totals from owned results; renderer reentry cannot award again. `plan('next'|'rematch')` captures the exact source session, completed duel, target row, next cursor, and any reset. It does not mutate the cursor or totals. Repeated activation shares/refuses the current pending plan, as the existing transaction does.

Extend the retained Next candidate to carry that plan and its target recipe. Decode and installed confirmation still happen before publication. Commit the new duel, exact picture, selected map/recipe, and progression cursor together as plain state updates, then retire the previous image. Failure, explicit Cancel, pointer/version refusal, or a stale callback preserves the old Results, original, cursor, totals, and named action. Retry retains the captured target; a changed installed catalogue cannot silently substitute a same-named or same-ID newer row.

The existing live action lease remains the only authority for any automatic Start. Preserve shipped/installed and background behavior from `99f33086`; an automatic focus restore must not renew a retired gesture. Keep shell `focusTransition` default behavior and all composed resize/current-action reveal checks. Rematch and Next may share the transaction mechanics, not mutable action identity.

## Bounded implementation and qualification

Expected production scope: new `game/couch/couch-progression.mjs`; host `couch.mjs`; shell `couch-shell.mjs`; `couch/index.html`; and narrowly adding exact campaign metadata to installed rows if required. Keep picture-owner protocols, core simulation, Solo app/writers, Team host, registry and storage formats unchanged.

Meaningful new pure cases: default/format validation; draw behavior; threshold two; duplicate/stale terminal delivery; exact authored order; one-mission tour ending; mission credit replacement after rematch; pending plan without mutation; failed/cancelled commit; stale session/catalogue rejection. Use immutable result/state assertions, not copies of implementation arithmetic.

Actual host cases must exercise: explicit format control and default one-race result; real first-to-two with a draw; a legal win followed by a *different* mission/picture; rematch on the same mission replacing one recorded result; final-mission completion without wrap; Next failure and Cancel preserving prior cursor/results/View; retry retaining its target; installed final-confirmation refusal; background/fresh Start and a newer deliberate Help choice. Observe actual adopted run/level IDs, painter bindings, visible action labels, totals, and zero player-store writes. Do not call a small set of representative source tests full tour/native acceptance.

Candidate whole-file cohort (verify names on the eventual base): new `couch-progression.test.mjs` and `couch-progression-host.test.mjs`; existing `couch-static-picture-host.test.mjs`, `couch-installed-chapters.test.mjs`, `couch-shell.test.mjs`, `couch-navigation.test.mjs`, `couch-markup.test.mjs`, and `couch-initial-focus.test.mjs`. The prior two-round transaction case must explicitly select First to two rather than weakening its real-win/reset oracles. No tests run for this design; schedule the final finite pair after the shared slot is free.

Root native proof should cover one default race, a tour advance to the visibly named different mission, one rematch replacement, and failure/Cancel retention on that different target. Device/public/offline and complete P07 acceptance remain later gates.

## Separate follow-ups

1. Name Solo's already-authorized next mission from the same current selection that its click handler uses; retain difficulty/replay/campaign-complete boundaries and existing save authority. Do not add a next-campaign download as a copy change.
2. Dewey's independent source-only read is against the combined tree `def1186e23ca8ce668b362c0b001f2b039eb76e5`, whose Team host differs from this P07 base. The starter pack orders First Connection then Relay Yard, but boot/reset deliberately selects Relay Yard. The terminal overlay offers same-arena Retry and Change setup, with no Advance or ordered-completion policy. Current Retry correctly captures immutable `attemptLevel`/`attemptPack` plus seed, difficulty and configuration; current selection controls are not the running identity. The smallest later Team action is a won-only, explicitly named successor derived from that captured pack order, preserving candidate-picture/core preparation and a fresh Start. Keep the deliberate Relay Yard default unless an approved entry contract changes it; do not silently reinterpret it as first-in-campaign. No Team tests or native execution accompany this read.
