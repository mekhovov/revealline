# Pure campaign progression checkpoint

This is the independently reviewed in-memory owner and its unit boundary. It is not yet wired to the Couch host, menu, shell, artwork preparation or actual gameplay results.

The isolated branch remains based on `99f33086c5c381cd91459e59e672c4adba1fe18d`. The two new files are held by `source-held-01.json` (`8572566c`). Root and Dewey read the full owner and all sixteen cases without a blocker. The complete unit file then passed 16/16 on Node 22.22.2 and 16/16 on Node 20.19.5. The sealed receipt is `pure-pair-01/verification.json` (`cdebc41815c03280b44eaa9f0849f6dca48decb0bb85eb555095db699486e9f1`).

The run retained seven physical input pins, both actual Node binary pins, the runner and source authority, canonical stage-entry bytes, and raw index hashes. All remained unchanged before and after both executions. The final observed disk reserve was 3,911,979,008 bytes. No host, shell, markup or artwork was hydrated. The owner has no storage or DOM dependency.

The model makes one-race the default, keeps first-to-two draws scoreless, and follows copied authored order for a tour. Tour results remain in memory through pending and running rematches. Only a newly accepted terminal result replaces that mission's previous point; a draw removes the prior point. An accepted non-tour rematch starts a fresh one-race or completed first-to-two match. Opaque pending-plan identity and strictly newer round identity protect commit from cancellation, duplicate delivery and another owner.

Host integration waits for Lagrange's committed gameplay composition. His current diagnostic source tree is not the implementation base. When it is committed, first integrate that base, preserving current resize, navigation, picture transaction and focus owners; then wire exact campaign entries and the staged progression plan to the existing image transaction. No player journey, browser result or broader P07 completion follows from this pure model test.

The shared reserve remains 2 GiB until root changes that instruction. The historical design's 256 MiB floor is superseded for current execution. The worktree cap remains 100 MiB, and any later fixture admission must be measured before hydration.
