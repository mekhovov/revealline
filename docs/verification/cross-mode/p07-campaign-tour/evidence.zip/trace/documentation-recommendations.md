# Documentation updates needed with the eventual P07 delivery

These are proposed authoring/runtime guide updates, not delivered player documentation or phase acceptance.

- Explain Setup's three formats: One race (default), First to two, and Campaign tour. A tour begins at the exact authored campaign's first mission even when Setup previously selected a later mission. Its setup note names the campaign, mission count and first mission.
- Explain that a tour rematch replaces that mission's earlier point only when the rematch finishes. A pending, cancelled or failed picture preparation keeps the previous point, cursor, Results and image. A drawn rematch removes the previous winning point. Viewing pictures and rendering Results again never award another point.
- Explain the named primary action and explicit end: Next names the captured successor; the final mission offers Choose campaign. There is no implicit wrap into another campaign or installation.
- Describe installed-content Ready as an intentional second Start boundary after confirming an exact new original. Neither tab return nor completed decode may start it. Shipped auto-Start still requires its live explicit action lease.
- Document exact checked row/campaign ownership. Matching labels, level IDs alone, or positions in a flattened selector do not grant another installed campaign authority. A removed owner stays unavailable after refresh until a current selection is chosen.
- Keep browser/model evidence distinct. This fixture pair exercises real rules, terminal results, media hashes and pointer transactions with bounded DOM/decode models. It does not certify browser rendering, physical controller, touch, offline/public delivery or complete P07.
- Add a test-authoring reminder to validate fixture versions before constructing multi-mission campaigns: every campaign uses one simulation core, and supported cores fix board dimensions. Distinct tour routing can vary inside the grid; 48→72 transitions belong to explicit changes between different campaigns. The first failed fixture run is retained as the reason for this correction.
