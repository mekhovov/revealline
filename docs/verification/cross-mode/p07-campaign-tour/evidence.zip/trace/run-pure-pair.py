#!/usr/bin/env python3
"""Finite, source-bound pure progression qualification; no host hydration."""
import datetime
import hashlib
import json
import re
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CACHE = ROOT / '.cache/tour'
OUT = CACHE / 'pure-pair-01'
FLOOR = 2 * 1024 ** 3
BASE = '99f33086c5c381cd91459e59e672c4adba1fe18d'
TREE = '416eb1c98635ee7b0ea934a6427c30d46fa2b84b'
NODES = [Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node') / version / 'bin/node'
         for version in ['22.22.2', '20.19.5']]

def digest(body):
    return hashlib.sha256(body).hexdigest()

def pin(path, name=None):
    body = path.read_bytes()
    return {'path': name or str(path), 'bytes': len(body), 'sha256': digest(body)}

def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=ROOT)

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

OUT.mkdir(exist_ok=False)
admission = json.loads((CACHE / 'admission.json').read_text())
held = json.loads((CACHE / 'source-held-01.json').read_text())
expected = [{key: row[key] for key in ['path', 'bytes', 'sha256']}
            for row in admission['paths'] + held['paths']]
canonical = git('ls-files', '--stage', '-z')
(OUT / 'canonical-index-before.bin').write_bytes(canonical)
raw_index = Path(git('rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
runner_pin = pin(Path(__file__))
authority_pins = [pin(CACHE / name) for name in ['admission.json', 'source-held-01.json']]
runtime_pins = [pin(node) for node in NODES]

def guard(label):
    require(shutil.disk_usage(ROOT).free >= FLOOR, '2 GiB launch reserve unavailable')
    require(git('rev-parse', 'HEAD').decode().strip() == BASE, 'HEAD changed')
    require(git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE, 'base tree changed')
    require(git('ls-files', '--stage', '-z') == canonical, 'canonical index changed')
    require(not git('diff', '--cached', '--name-only'), 'staged changes appeared')
    require(not git('diff', '--name-only'), 'tracked changes appeared')
    actual = [pin(ROOT / row['path'], row['path']) for row in expected]
    require(actual == expected, 'finite input bytes changed')
    require(pin(Path(__file__)) == runner_pin, 'runner changed')
    require([pin(Path(row['path'])) for row in authority_pins] == authority_pins, 'authority changed')
    require([pin(node) for node in NODES] == runtime_pins, 'runtime changed')
    for name in ['game/couch/couch.mjs', 'game/couch/index.html', 'game/couch/shell.mjs']:
        require(not (ROOT / name).exists(), 'host input was hydrated: ' + name)
    result = {'label': label, 'inputs': actual, 'freeBytes': shutil.disk_usage(ROOT).free,
              'rawIndex': pin(raw_index), 'canonicalIndexSha256': digest(canonical)}
    write(label + '.json', result)
    return result

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
authority = {'scope': 'Pure in-memory progression owner only; complete 16-case file on each runtime.',
             'base': BASE, 'tree': TREE, 'inputs': expected, 'sourceHeld': authority_pins[1],
             'authorities': authority_pins, 'runner': runner_pin, 'runtimes': runtime_pins,
             'canonicalIndex': pin(OUT / 'canonical-index-before.bin'), 'reserveBytes': FLOOR,
             'started': started, 'tests': ['game/test/couch-progression.test.mjs']}
write('authority.json', authority)
runs = []
try:
    guard('before')
    for node in NODES:
        version = subprocess.check_output([str(node), '--version'], text=True).strip()
        command = [str(node), '--test', '--test-reporter=tap', '--test-concurrency=1',
                   'game/test/couch-progression.test.mjs']
        log = OUT / ('node' + version.split('.')[0][1:] + '.log')
        begin = time.monotonic()
        with log.open('xb') as output:
            result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
        raw = log.read_text()
        summary = {key: int(value) for key, value in re.findall(
            r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$', raw, re.MULTILINE)}
        run = {'version': version, 'command': command, 'exitCode': result.returncode,
               'elapsedSeconds': round(time.monotonic() - begin, 6), 'summary': summary,
               'rawLog': pin(log)}
        runs.append(run)
        write('runs.json', runs)
        guard('after-node' + version.split('.')[0][1:])
        require(result.returncode == 0 and summary == {
            'tests': 16, 'pass': 16, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0},
            'complete pure file did not pass: ' + version)
    result = {'status': 'passed', 'scope': authority['scope'], 'authority': pin(OUT / 'authority.json'),
              'runs': runs, 'before': pin(OUT / 'before.json'),
              'after': [pin(OUT / 'after-node22.json'), pin(OUT / 'after-node20.json')],
              'completed': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'limits': 'No host, browser, gameplay, composed-source or phase qualification.'}
    write('verification.json', result)
    print(json.dumps(result, indent=2))
except Exception as error:
    write('refusal-or-failure.json', {'error': str(error), 'runs': runs,
          'time': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    raise
