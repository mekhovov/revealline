#!/usr/bin/env python3
"""Package original P07 trace bytes without editing historical evidence."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[2]
TRACE = ROOT / '.cache/tour'
OUT = ROOT / 'docs/verification/cross-mode/p07-campaign-tour'
BASE = '1f3b9995af43879d54fb7b0053846f0723e2e069'
TREE = 'cd4fa75395f045ffa02375e1784072044c2020d4'

def sha(data): return hashlib.sha256(data).hexdigest()
def pin(path, name=None):
    body = path.read_bytes()
    return {'path': name or str(path), 'bytes': len(body), 'sha256': sha(body)}
def git(*args): return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT)
def require(ok, text):
    if not ok: raise RuntimeError(text)

require(git('rev-parse','HEAD').decode().strip() == BASE, 'Changed base')
require(git('rev-parse','HEAD^{tree}').decode().strip() == TREE, 'Changed base tree')
require(not git('diff','--cached','--name-only'), 'Do not package a staged candidate')
index = git('ls-files','--stage','-z')
held = json.loads((TRACE/'host-source-held-04.json').read_text())
inputs = json.loads((TRACE/'host-inputs-held04.json').read_text())
verification = json.loads((TRACE/'host-pair-02/verification.json').read_text())
require(inputs['sourceHeldSha256'] == sha((TRACE/'host-source-held-04.json').read_bytes()), 'Input/source mismatch')
for row in held['paths']:
    require(pin(ROOT/row['path'],row['path']) == row, 'Changed final tested source: '+row['path'])
for row in inputs['files']:
    require(pin(ROOT/row['path'],row['path']) == row, 'Changed final input: '+row['path'])
require(verification['status'] == 'passed' and len(verification['runs']) == 2, 'Final pair incomplete')
for run, version in zip(verification['runs'],['v22.22.2','v20.19.5']):
    require(run['version'] == version and run['exitCode'] == 0, 'Unexpected final runtime result')
    require(run['summary'] == {'tests':149,'pass':149,'fail':0,'cancelled':0,'skipped':0,'todo':0}, 'Incomplete final file set')
    require(pin(Path(run['log']['path'])) == run['log'], 'Changed final log')
for name in ['before','after-node22','after-node20']:
    check = json.loads((TRACE/f'host-pair-02/{name}.json').read_text())
    require(check['inputs'] == inputs['files'], 'Final runtime input guard differs')
    require(check['canonicalIndexSha256'] == sha(index), 'Final canonical index differs')
failed = json.loads((TRACE/'host-pair-01/runs.json').read_text())
require(len(failed)==1 and failed[0]['summary'] == {'tests':132,'pass':130,'fail':2,'cancelled':0,'skipped':0,'todo':0}, 'Failed cohort changed')
require(pin(Path(failed[0]['log']['path'])) == failed[0]['log'], 'Changed failed log')
failed_pins = {r['path']:r for r in json.loads((TRACE/'host-source-held-03.json').read_text())['paths']}
for name in ['couch-installed-chapters.test.mjs','couch-progression-host.test.mjs']:
    require(pin(TRACE/'host-pair-01/failed-fixture-originals'/name,'game/test/'+name) == failed_pins['game/test/'+name], 'Failed fixture differs')
files = [(p,'trace/'+str(p.relative_to(TRACE))) for p in sorted(TRACE.rglob('*'))
         if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts]
files.append((Path(__file__),'package/package.py'))
require(sum(p.stat().st_size for p,_ in files) < 4*1024**2, 'Unexpected evidence size')
require(shutil.disk_usage(ROOT).free >= 2*1024**3, '2 GiB reserve unavailable')
archive = OUT/'evidence.zip'
require(not archive.exists(), 'Archive already exists')
rows = []
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path, name in files:
        data = path.read_bytes()
        info = zipfile.ZipInfo(name,(2000,1,1,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
        rows.append({'member':name,'original':str(path),'bytes':len(data),'sha256':sha(data)})
with zipfile.ZipFile(archive) as z:
    require(z.namelist() == [r['member'] for r in rows], 'ZIP inventory differs')
    for row in rows:
        data = z.read(row['member'])
        require(data == Path(row['original']).read_bytes(), 'Original/ZIP mismatch')
        require(len(data) == row['bytes'] and sha(data)==row['sha256'],'ZIP digest mismatch')
evidence = {
    'format':'revealline-couch-tour-evidence.v1',
    'scope':'Internal P07 source/test checkpoint. No native, physical-device, current-P02 composition, full-source/public or phase acceptance.',
    'base':{'commit':BASE,'tree':TREE},
    'sourceHeld':'trace/host-source-held-04.json',
    'testedPaths':held['paths'],
    'finalQualification':{'member':'trace/host-pair-02/verification.json','files':held['suite'],
        'inputCount':len(inputs['files']),'inputBytes':sum(r['bytes'] for r in inputs['files']),
        'runs':[{'version':r['version'],'exitCode':r['exitCode'],'counts':r['summary'],
                 'elapsedSeconds':r['elapsedSeconds'],'logMember':'trace/host-pair-02/'+Path(r['log']['path']).name,
                 'logSha256':r['log']['sha256']} for r in verification['runs']]},
    'historicalScopes':[
        {'member':'trace/pure-pair-01/verification.json','scope':'Earlier 16-case pure-owner pair on predecessor99f33086; not added to final149 count.'},
        {'member':'trace/host-pair-01/runs.json','scope':'Failed Node22 eight-file run:130/132. Ten new host cases never entered because invalid mixed-grid fixture failed module initialization; separate installed reset used onclick-only helper for event listener.'},
        {'member':'trace/host-pair-01/failed-fixture-originals/README.md','scope':'Exact failed fixture bytes reconstructed by reversing only known edits after the failed run and verified against held03 pre-run SHA-256; reconstruction is explicitly disclosed.'},
        {'member':'trace/fixture-correction-held04.diff','scope':'Fixture-only correction: legal48×36 route variation and real reset click. No production relaxation; unchanged existing chapter file adds separate72→48 setup coverage.'},
        {'member':'trace/intake-preflight-refusal.json','scope':'Earlier finite intake refused before hydration. Retained as preparation history, not product failure.'}],
    'provenance':{'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'method':'Lossless ZIP copies of exact retained local evidence; fixed ZIP timestamps are packaging metadata, not execution dates. No source assets or log rewriting.',
        'canonicalIndexSha256':sha(index),'packager':pin(Path(__file__))},
    'archive':pin(archive,'evidence.zip'),
    'memberCount':len(rows),'originalBytes':sum(r['bytes'] for r in rows),'members':rows,
    'remaining':['Normal native One race/tour/Rematch and installed Ready journeys','Current-P02 composition and requalification','Solo/Team continuation and full P07 rewards/story gates','Public deployment, offline and physical-input acceptance']}
(OUT/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
require(git('ls-files','--stage','-z') == index, 'Canonical index changed during packaging')
physical = sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file() and not p.is_symlink())
require(physical < 100*1024**2,'Finite checkout exceeds100MiB')
print(json.dumps({'archive':evidence['archive'],'members':len(rows),'originalBytes':evidence['originalBytes'],
                  'evidence':pin(OUT/'evidence.json'),'physicalBytes':physical},indent=2))
