import datetime, hashlib, json, os, selectors, shutil, signal, subprocess, sys, time
from pathlib import Path
P = Path(__file__).resolve().parent
CAP = 2 * 1024**2
RESERVE = 512 * 1024**2
NODE = Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node/20.19.5/bin/node')
PATTERN = '^P03 screen and P08-A motion reviews bind only the inspected current inputs$'
assert sys.argv[1:] in [['targeted'], ['full']]
assert NODE.is_file()
mode = sys.argv[1]
phases = [('red', 1), ('green', 0)] if mode == 'targeted' else [('green-full', 0)]
(P / 'tmp').mkdir(exist_ok=True)
env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(P / 'tmp'), NODE_OPTIONS='')
env.pop('NODE_V8_COVERAGE', None)
sha = lambda b: hashlib.sha256(b).hexdigest()
def retained():
    return sum(f.lstat().st_size for f in P.rglob('*') if f.is_file() and not f.is_symlink())
results = []
for phase, expected in phases:
    assert retained() < CAP - 262144 and shutil.disk_usage(P).free > RESERVE + 262144
    out = P / 'runs' / phase
    out.mkdir(parents=True, exist_ok=False)
    variant = 'green' if phase == 'green-full' else phase
    command = [str(NODE), '--test', '--test-concurrency=1']
    if mode == 'targeted': command += ['--test-name-pattern', PATTERN]
    command += [str(P / variant / 'game/test/presentation-production-history.test.mjs')]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process = subprocess.Popen(command, cwd=P / variant, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    sel = selectors.DefaultSelector()
    sel.register(process.stdout, selectors.EVENT_READ, 'stdout')
    sel.register(process.stderr, selectors.EVENT_READ, 'stderr')
    buffers = {'stdout': bytearray(), 'stderr': bytearray()}
    deadline = time.monotonic() + (180 if mode == 'full' else 90)
    reason = None
    try:
        while sel.get_map():
            if time.monotonic() >= deadline: reason = 'timeout'; break
            if retained() > CAP - sum(map(len, buffers.values())) - 65536: reason = 'packet-cap'; break
            if shutil.disk_usage(P).free < RESERVE + sum(map(len, buffers.values())) + 65536: reason = 'reserve'; break
            for key, _ in sel.select(0.2):
                chunk = os.read(key.fileobj.fileno(), 8192)
                if not chunk: sel.unregister(key.fileobj); continue
                room = 131072 - len(buffers[key.data])
                buffers[key.data].extend(chunk[:max(0, room)])
                if len(chunk) > room: reason = 'output-cap'; break
            if reason: break
    finally:
        if reason and process.poll() is None: os.killpg(process.pid, signal.SIGKILL)
        code = process.wait(timeout=5)
        sel.close()
    for channel, body in buffers.items(): (out / (channel + '.log')).write_bytes(body)
    text = buffers['stdout'].decode(errors='replace')
    expected_failure = phase == 'red' and code == 1 and 'screen.missions.background' in text and 'ERR_ASSERTION' in text and 'not ok' in text
    passed = code == 0 and '# fail 0' in text
    matched = reason is None and (expected_failure if expected == 1 else passed)
    result = {'phase': phase, 'argv': command, 'startedAt': started, 'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exitCode': code, 'expectedExitCode': expected, 'terminationReason': reason, 'expectedOutcomeMatched': matched, 'logs': {key: {'bytes': len(body), 'sha256': sha(body)} for key, body in buffers.items()}, 'scope': 'Actual selected production-history tests with existing dependencies; read-only in-memory producer API, no generator CLI or production writes.'}
    (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    results.append(result)
    print(json.dumps({'phase': phase, 'exitCode': code, 'expectedOutcomeMatched': matched, 'terminationReason': reason, 'stdoutTail': text[-2400:]}), flush=True)
    if not matched: break
(P / ('checks-' + mode + '.json')).write_text(json.dumps(results, indent=2) + '\n')
assert all(r['expectedOutcomeMatched'] for r in results) and len(results) == len(phases)
