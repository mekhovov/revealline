from pathlib import Path
import re,json,subprocess,posixpath,hashlib
ROOT=Path(__file__).resolve().parents[2];CACHE=ROOT/'.cache/gameplay-composition';f=json.loads((CACHE/'fixture-inventory-held-01.json').read_text());tree=f['tree'];known={r['path'] for r in f['inputs']}
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
blobs={}
for entry in git('ls-tree','-rz',tree).split(b'\0'):
 if entry:
  meta,name=entry.split(b'\t',1);mode,kind,blob=meta.decode().split()
  if kind=='blob':blobs[name.decode()]=blob
roots=f['testFiles']+['game/app.mjs','game/couch/couch.mjs','game/couch/relay-rescue.mjs'];queue=list(roots);seen=set();edges=[];missing={};unresolved=[];directories=[];generatedNative=[]
patterns=[('esm',r'(?:\bfrom\s+|\bimport\s*\(?\s*)[\'\"](\.{1,2}/[^\'\"]+)[\'\"]'),('new-url',r'new\s+URL\(\s*[\'\"]([^\'\"]+)[\'\"]\s*,\s*import\.meta\.url\s*\)')]
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
while queue:
 p=queue.pop()
 if p in seen:continue
 seen.add(p);proc.stdin.write((blobs[p]+'\n').encode());proc.stdin.flush();head=proc.stdout.readline().decode().split();b=proc.stdout.read(int(head[2]));assert proc.stdout.read(1)==b'\n';s=b.decode()
 for kind,pattern in patterns:
  for match in re.finditer(pattern,s):
   spec=match.group(1)
   if re.match(r'^[a-z]+:',spec) or '${' in spec:continue
   target=posixpath.normpath(posixpath.join(posixpath.dirname(p),spec.split('?')[0].split('#')[0]));edge={'importer':p,'kind':kind,'specifier':spec,'resolved':target}
   if target not in blobs:
    if target=='.' or any(n.startswith(target.rstrip('/')+'/') for n in blobs):directories.append(edge)
    elif target=='native/bridge.mjs' and p=='game/platform.mjs':generatedNative.append({**edge,'reason':'Generated only in verified iOS packaging; iosBridge executes only behind nativePlatform(locationRef)===ios at platform.mjs40. No iOS stage is under this web-host cohort.'})
    else:unresolved.append(edge)
    continue
   edges.append(edge)
   if target not in known:missing.setdefault(target,[]).append(p)
   if target.endswith(('.mjs','.js')):queue.append(target)
proc.stdin.close();assert proc.wait()==0
rows=[]
for p,parents in sorted(missing.items()):
 b=git('show',tree+':'+p);rows.append({'path':p,'importers':sorted(set(parents)),'gitBlob':blobs[p],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
r={'tree':tree,'roots':roots,'scannedModules':len(seen),'edgeCount':len(edges),'missing':rows,'unresolved':unresolved,'directoryReferences':directories,'generatedNativeExclusions':generatedNative,'scope':'Read-only transitive literal ESM/new-URL graph from all19 test entries and actual Solo/Versus/Team hosts. Directory references do not authorize recursive hydration. Dynamic fixture authority remains the complete recorded P07/actor intake.'}
p=CACHE/'intake-required-graph.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
