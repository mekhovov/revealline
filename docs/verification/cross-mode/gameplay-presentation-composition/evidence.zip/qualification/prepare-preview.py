import pathlib,json,hashlib,subprocess,difflib
root=pathlib.Path.cwd();cache=root/'.cache/gameplay-composition';out=cache/'preview';out.mkdir(exist_ok=True)
old=(root.parent/'p03-collection-records-return/.cache/collection-records-return/preview/serve.py').read_text()
s=old.replace("'source-held-02.json'","'source-held-01.json'").replace("hold['files']","hold['paths']").replace('exact records-return successor tree','exact gameplay composition tree')
(out/'serve-normal.py').write_text(s)
p07=(root.parent/'p07-next-result-transaction/.cache/next-result/serve-next-transport.py').read_text()
t=s.replace('threading, re, shutil, argparse','threading, re, shutil, argparse, time\nfrom datetime import datetime, timezone')
t=t.replace("parser.add_argument('--qualification-sha256', required=True)","parser.add_argument('--qualification-sha256', required=True)\nparser.add_argument('--request-log', required=True)")
t=t.replace('(args.config, args.binding)', '(args.config, args.binding, args.request_log)')
t=t.replace('config_bytes = config_path.read_bytes()',"request_log_path = OUT / args.request_log\nif request_log_path.exists() or request_log_path.is_symlink():\n    raise RuntimeError('Use a fresh owned request log')\nconfig_bytes = config_path.read_bytes()")
transport=p07[p07.index('TRANSPORT = {'):p07.index('BASE = config.get')]
t=t.replace('TREE = config[\'tree\']',transport+"TREE = config['tree']")
logblock=p07[p07.index("fixture = git_body(TRANSPORT['path'])"):p07.index('class Handler(')]
t=t.replace('class Handler(',logblock+'class Handler(',1)
t=t.replace('            try:\n                body = git_body(name)','            ticket = None\n            try:\n                body = git_body(name)',1)
a=p07.index('                if send_body and name == TRANSPORT[\'path\']:');b=p07.index('                start, end, status',a)
t=t.replace('                start, end, status',p07[a:b]+'                start, end, status',1)
needle='                        self.wfile.write(memoryview(body)[offset:min(offset + 65536, end + 1)])'
t=t.replace(needle,needle+"\n                    if ticket is not None:\n                        record('response', httpStatus=status, originalBytes=end - start + 1, originalSha256=hashlib.sha256(body).hexdigest(), **ticket)",1)
t=t.replace('            except (BrokenPipeError, ConnectionResetError):\n                pass',"            except (BrokenPipeError, ConnectionResetError):\n                if ticket is not None:\n                    record('client-disconnected', **ticket)")
t=t.replace("'mode': 'normal',","'mode': 'First Signal GET1 normal / GET2 503 / GET3 six-second delay / later normal',\n           'transport': TRANSPORT, 'requestLog': args.request_log,")
t=t.replace('No working-file overlays, application state, clock, delay or network-fault fixture.','No working-file overlays, application state or clock fixture. Only the literal First Signal GET sequence changes: normal, 503, six-second delay, then normal. HEAD does not consume it.')
t=t.replace('    server.server_close()','    server.server_close()\n    request_log.close()')
(out/'serve-transport.py').write_text(t)
for name,froms,tos in [('normal-helper-reuse.diff',old,s),('transport-helper-reuse.diff',s,t)]:
 (out/name).write_text(''.join(difflib.unified_diff(froms.splitlines(True),tos.splitlines(True),fromfile='reviewed-parent',tofile=name)))
h=json.loads((cache/'source-held-01.json').read_text());roles=['combined-base','team-hud','team-actors','next-results'];common='3acce1941116d18f9e86dcfa26dea463433cd3b2'
identities=[{'role':role,'commit':commit,'tree':subprocess.check_output(['git','rev-parse',commit+'^{tree}'],text=True).strip()} for role,commit in zip(roles,h['parents'])]
identities.append({'role':'common-base','commit':common,'tree':subprocess.check_output(['git','rev-parse',common+'^{tree}'],text=True).strip()})
config={'schema':'revealline.gameplay-composition-preview.v1','status':'Unstarted; exact complete19-file pair and reviewed receipt hashes required.','head':h['head'],'tree':h['tree'],'indexTree':h['tree'],'predecessorTree':subprocess.check_output(['git','rev-parse',h['head']+'^{tree}'],text=True).strip(),'commonBase':common,'originalParents':h['parents'],'sourceIdentities':identities,'sourceHoldSha256':hashlib.sha256((cache/'source-held-01.json').read_bytes()).hexdigest(),'cohorts':{'union':h['testFiles']},'excluded':'P01/P02 integration, version/release/publication or phase acceptance.'}
(out/'normal-config.json').write_text(json.dumps(config,indent=2)+'\n')
oldcfg=json.loads((root.parent/'p07-next-result-transaction/.cache/next-result/preview-transport-held06-config.json').read_text());config['transport']=oldcfg['transport'];(out/'transport-config.json').write_text(json.dumps(config,indent=2)+'\n')
rows=[]
for p in sorted(out.iterdir()):
 if p.is_file():rows.append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
receipt={'status':'Prepared only, no helper executed or origin bound','sourceTree':h['tree'],'files':rows,'reuse':'Normal exact-tree Collection helper with held01 paths and gameplay scope; transport adds only prior P07 literal original GET sequence and append-only request/status log. No working-file overlays.'}
(out/'preparation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
