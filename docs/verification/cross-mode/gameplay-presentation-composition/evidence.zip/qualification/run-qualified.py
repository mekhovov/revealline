import json,hashlib,subprocess,time,shutil,os,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
CACHE=ROOT/'.cache/gameplay-composition'
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(path):
 h=hashlib.sha256();size=0
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk);size+=len(chunk)
 return {'bytes':size,'sha256':h.hexdigest()}
def git(*args):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT)
authorityPath=CACHE/'qualification-authority.json';authority=json.loads(authorityPath.read_text());authorityBytes=authorityPath.read_bytes()
fixturePath=CACHE/authority['fixtureInventory']['file'];fixture=json.loads(fixturePath.read_text())
assert pin(fixturePath)=={k:authority['fixtureInventory'][k] for k in ['bytes','sha256']}
runnerBytes=Path(__file__).read_bytes();results=[]
assert not (CACHE/'whole-receipt.json').exists()
def guard():
 assert git('rev-parse','HEAD').decode().strip()==authority['head']
 assert sha(git('ls-files','--stage','-z'))==authority['indexSha256']
 assert git('write-tree').decode().strip()==authority['tree']
 assert not git('diff','--name-only').strip()
 assert pin(CACHE/authority['sourceHold']['file'])=={k:authority['sourceHold'][k] for k in ['bytes','sha256']}
 assert Path(__file__).read_bytes()==runnerBytes and authorityPath.read_bytes()==authorityBytes
 assert shutil.disk_usage(ROOT).free>=256*1024**2
 owned=sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file() and not p.is_symlink());assert owned<=100*1024**2,owned
 rows=[]
 for expected in fixture['inputs']:
  actual={'path':expected['path'],**pin(ROOT/expected['path']),'gitBlob':expected['gitBlob']}
  assert actual==expected,expected['path'];rows.append(actual)
 for r in authority['runtimes']:assert pin(r['path'])=={k:r[k] for k in ['bytes','sha256']}
 return rows
before=guard();(CACHE/'whole-before.json').write_text(json.dumps(before,indent=2)+'\n')
for runtime in authority['runtimes']:
 label=runtime['label'];command=[runtime['path'],'--test','--test-concurrency=1',*authority['testFiles']]
 log=CACHE/f'whole-{label}.log';assert not log.exists();start=time.monotonic();env=dict(os.environ);env['PATH']=str(Path(runtime['path']).parent)+os.pathsep+env.get('PATH','')
 with log.open('xb') as out:result=subprocess.run(command,cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT)
 raw=log.read_bytes();summary={key:int(value) for key,value in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)\s*$',raw.decode(errors='replace'),re.M)}
 row={'runtime':runtime['version'],'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start,'log':{'file':log.name,**pin(log)},'summary':summary};results.append(row)
 # Retain the execution result before any post-run guard can refuse readiness.
 (CACHE/'whole-receipt.json').write_text(json.dumps({'head':authority['head'],'tree':authority['tree'],'authoritySha256':sha(authorityBytes),'runnerSha256':sha(runnerBytes),'inputCount':fixture['count'],'inputBytes':fixture['bytes'],'records':results,'postRunInputsVerified':False},indent=2)+'\n')
 print(json.dumps(row),flush=True)
 after=guard();(CACHE/f'whole-after-{label}.json').write_text(json.dumps(after,indent=2)+'\n');assert after==before
 (CACHE/'whole-receipt.json').write_text(json.dumps({'head':authority['head'],'tree':authority['tree'],'authoritySha256':sha(authorityBytes),'runnerSha256':sha(runnerBytes),'inputCount':fixture['count'],'inputBytes':fixture['bytes'],'records':results,'postRunInputsVerified':True},indent=2)+'\n')
 if result.returncode or not summary or summary.get('fail',0) or summary.get('cancelled',0):break
