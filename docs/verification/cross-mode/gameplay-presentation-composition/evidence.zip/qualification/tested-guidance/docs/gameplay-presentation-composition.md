# Gameplay and presentation source composition

This internal candidate starts at `356401f936578db5d3643e13cb6287e59535e853`, the four-parent cross-mode checkpoint with the Collection Flight records growth correction. It composes three existing checkpoints without changing versions, content identities, strict formats or publication:

| Input                        | Commit                                     | Preserved scope                                                                                                                               |
| ---------------------------- | ------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------- |
| Narrow Team HUD              | `61fb43b32974187fe664f130117465285223251b` | Two player columns plus full-width territory below at widths up to 600 CSS pixels.                                                            |
| Team actor presentation      | `d30f883df1e11d04fb8a5682e17171f98da67901` | Prepared sprite roles, CSS-sized cues and inward cosmetic offsets; actual actor state/contact stays authoritative.                            |
| Retained Results during Next | `99f33086c5c381cd91459e59e672c4adba1fe18d` | Staged picture/duel adoption preserves Results, original and View through failure or Cancel; explicit current action governs automatic Start. |

HUD CSS and actor modules/tests retain exact incoming bodies. P07's source and tests are also exact except the Couch shell: its default-true `focusTransition` flag controls the existing final transition reveal while the current-action resize handler remains intact. Both operate after synchronous layout publication; neither gives a stale or background action new focus authority. The Collection refresh owner and independent gallery/pager leases are unchanged.

Prompt and maintainer additions are combined, not replaced. Each checkpoint's original evidence stays unchanged. Historical prose keeps its source cutoff; the current register identifies which earlier exclusions are superseded. The final checkpoint must retain the base and all three input histories. Temporary merge objects are only preparation records.

The proposed whole-file union is the actor checkpoint's eight files and P07's twelve, deduplicated, plus the resize host file: 19 complete files. Exact finite asset/script/featured-pack inputs come from their recorded inventories, with changed source rebound to this tree. Source review precedes execution. Node 22 then Node 20 run serially after the shared slot is released. Prior 167/246/46/760/177/7 counts remain separate scoped evidence; no passing combined count is claimed yet.

Root's combined native review remains pending: clean narrow Team names, actor/head association and state cues with Options/explicit Resume; Versus Results and original through Next failure/Cancel/Retry; and final-results/resize visible focus. Actual request fixtures and imported data must stay distinct from real play. Existing incomplete captures and failures remain evidence.

This does not complete P03, P05, P07 or P08. Full progression, full Team completion/rescue, all edition/import bindings, complete bright-art readability, actual browser zoom, system/storage preference events and physical devices retain their existing gates. P01/P02 source integration and final CI/build/public acceptance follow separately.
