import pathlib,json,hashlib,urllib.request,datetime,sys
OUT=pathlib.Path(__file__).resolve().parent;ROOT=OUT.parents[2]
bindingName,outputName=sys.argv[1:]
assert pathlib.Path(bindingName).name==bindingName and pathlib.Path(outputName).name==outputName
bindingPath=OUT/bindingName;binding=json.loads(bindingPath.read_text());planPath=OUT/'http-plan.json';plan=json.loads(planPath.read_text())
assert binding['tree']==plan['tree'];target=binding.get('transport',{}).get('path');origin='http://127.0.0.1:'+str(binding['port']);rows=[]
pin=lambda p:{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for row in plan['files']:
 p=ROOT/row['path'];localExact=None
 if p.is_file():
  b=p.read_bytes();localExact=len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];assert localExact,row['path']
 method='HEAD' if row['path']==target else 'GET'
 with urllib.request.urlopen(urllib.request.Request(origin+'/'+row['path'],method=method),timeout=60) as response:
  assert response.status==200,(row['path'],response.status)
  assert int(response.headers['Content-Length'])==row['bytes'],row['path']
  body=response.read();exact=None if method=='HEAD' else len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
  if method=='GET':assert exact,row['path']
  rows.append({**row,'method':method,'httpStatus':response.status,'httpBodyExact':exact,'localBodyExact':localExact,'contentType':response.headers.get('Content-Type')})
receipt={'tree':plan['tree'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'origin':origin,'binding':pin(bindingPath),'plan':pin(planPath),'count':len(rows),'getCount':sum(r['method']=='GET' for r in rows),'headCount':sum(r['method']=='HEAD' for r in rows),'files':rows,'scope':'Exact immutable-tree body responses; local equality only where physically present. Fault-target HEAD checks headers without consuming GET ordinal and makes no HTTP body equality claim. No browser behavior or rendering exercised.'}
p=OUT/outputName
with p.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'file':outputName,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'GET':receipt['getCount'],'HEAD':receipt['headCount']}))
