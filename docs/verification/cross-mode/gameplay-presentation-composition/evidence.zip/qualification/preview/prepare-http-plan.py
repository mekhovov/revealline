import pathlib,json,zipfile,io,subprocess,hashlib
root=pathlib.Path(__file__).resolve().parents[3];out=pathlib.Path(__file__).resolve().parent
old=json.loads((root.parent/'p03-collection-records-return/.cache/collection-records-return/preview/http-source-before-native.json').read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
z=zipfile.ZipFile(io.BytesIO(git('show','d30f883:docs/verification/cross-mode/p08-team-actors/evidence.zip')))
a=json.loads(z.read('http-readable-before.json'));h=json.loads(git('show','61fb43:docs/verification/cross-mode/p05-team-hud/retained/http-before-native-02.json'))
paths={x['path'] for x in old['files']}|{x['path'] for x in a['rows']}|{x['path'] for x in h['rows']}
paths.add('game/couch/couch-installed-chapters.mjs')
config=json.loads((out/'transport-config.json').read_text());target=config['transport']['path'];paths.add(target)
rows=[]
for p in sorted(paths):
 b=git('show',config['tree']+':'+p);rows.append({'path':p,'gitBlob':git('rev-parse',config['tree']+':'+p).decode().strip(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'transportPrecheck':'HEAD only, do not consume original GET sequence' if p==target else 'GET'})
plan={'tree':config['tree'],'source':'Union of prior27 composition, final16 actor and5 HUD proof paths, installed owner and exact fault original; every body rebound to current immutable tree.','count':len(rows),'bytes':sum(x['bytes'] for x in rows),'files':rows,'scope':'Prepared only. Source/HTTP identity checks, not browser rendering, gameplay or total module graph qualification.'}
(out/'http-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(plan['count'],plan['bytes'])
