import pathlib,subprocess,json,hashlib,shutil
root=pathlib.Path.cwd();cache=root/'.cache/gameplay-composition';parent=root.parent.parent.parent
prep=parent/'.cache/cross-mode-gameplay-preparation';plan=json.loads((parent/'.cache/worktrees/p03-collection-records-return/.cache/collection-records-return/next-composition-intake.json').read_text())
def git(*a,data=None):return subprocess.check_output(['git',*a],input=data)
def text(*a):return git(*a).decode().strip()
sp=pathlib.Path(text('rev-parse','--absolute-git-dir'))/'info/sparse-checkout';s=sp.read_text();new='docs/gameplay-presentation-composition.md'
if '/'+new+'\n' not in s:sp.write_text(s+'/'+new+'\n')
git('add','--','docs/cross-mode-execution.md',new)
tree=text('write-tree');assert not text('diff','--name-only')
base=plan['baseCommit'];changed=text('diff-tree','--no-commit-id','--name-only','-r',base,tree).splitlines()
allowed={'game/couch/couch-shell.mjs','authoring/prompts/cross-mode-delivery.md','authoring/skills/xonix-runtime-maintainer/SKILL.md','docs/cross-mode-execution.md'}
expected={new};inherit=[]
for inc in plan['incoming']:
 for row in inc['files']:
  p=row['path'];expected.add(p);b=git('show',tree+':'+p)
  exact=len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
  assert exact or p in allowed,(p,inc['commit'])
  inherit.append({'input':inc['commit'],'path':p,'exactIncoming':exact,'composedBlob':text('rev-parse',tree+':'+p)})
assert set(changed)==expected,(set(changed)-expected,expected-set(changed))
assert text('rev-parse',tree+':game/app.mjs')==text('rev-parse',base+':game/app.mjs')
paths=[]
for p in changed:
 b=(root/p).read_bytes();assert b==git('show',tree+':'+p),p
 paths.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':text('rev-parse',tree+':'+p)})
material=json.loads((cache/'materialization.json').read_text());names={x['path'] for x in material['paths']}|{new}
inputs=[]
for p in sorted(names):
 b=(root/p).read_bytes();blob=text('rev-parse',tree+':'+p);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==blob,p
 inputs.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':blob})
fixture={'head':base,'tree':tree,'testFiles':plan['proposedTestFiles'],'count':len(inputs),'bytes':sum(x['bytes'] for x in inputs),'inputs':inputs,'source':'Exact P07 held07 physical path cohort, actor held06 cohort, resize whole file and exact incoming changed bodies; rebound to composed tree.'}
f=cache/'fixture-inventory-held-01.json';f.write_text(json.dumps(fixture,indent=2)+'\n')
hold={'status':'Source held for root and independent peer; no combined tests or native yet','head':base,'tree':tree,'parents':[base]+[x['commit'] for x in plan['incoming']],'paths':paths,'changedCount':len(paths),'changedBytes':sum(x['bytes'] for x in paths),'inherited':inherit,'sharedPaths':sorted(allowed),'fixtureInventory':{'path':str(f.relative_to(root)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()},'testFiles':plan['proposedTestFiles'],'scope':'HUD/actors/P07 composition preserving Collection return and resize; no P01/P02/version/phase/publication adoption.'}
p=cache/'source-held-01.json';p.write_text(json.dumps(hold,indent=2)+'\n')
for name,args in [('source.diff',['diff','--cached',base,'--','game']),('shared-hunks.diff',['diff','--cached',base,'--',*sorted(allowed)]),('shell-vs-p07.diff',['diff','99f33086',tree,'--','game/couch/couch-shell.mjs']),('source.stat',['diff','--cached','--stat',base])]:
 (cache/name).write_bytes(git(*args))
r=subprocess.run(['git','diff','--cached','--check'],capture_output=True);(cache/'diff-check.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0
owned=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink());assert owned<100*1024*1024
print(json.dumps({'tree':tree,'changed':len(paths),'changedBytes':hold['changedBytes'],'exactIncomingComparisons':sum(x['exactIncoming'] for x in inherit),'incomingComparisons':len(inherit),'fixtureCount':len(inputs),'fixtureBytes':fixture['bytes'],'holdBytes':p.stat().st_size,'holdSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'ownedBytes':owned,'freeBytes':shutil.disk_usage(root).free},indent=2))
