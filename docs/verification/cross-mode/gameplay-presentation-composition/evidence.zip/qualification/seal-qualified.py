import pathlib,json,hashlib,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[2];C=ROOT/'.cache/gameplay-composition'
sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):return {'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
a=json.loads((C/'qualification-recovery.json').read_text());hold=json.loads((C/'source-held-01.json').read_text());fixture=json.loads((C/a['fixtureInventory']['file']).read_text());r=json.loads((C/'recovery-receipt.json').read_text())
assert r['tree']==a['tree']==hold['tree'];assert r['postRunInputsVerified'];assert r['authoritySha256']==sha((C/'qualification-recovery.json').read_bytes());assert r['runnerSha256']==sha((C/'run-qualified-recovery.py').read_bytes())
assert len(r['records'])==2 and len(a['testFiles'])==19 and len(set(a['testFiles']))==19
before=(C/'recovery-before.json').read_bytes();assert before==(C/'recovery-after-node22.json').read_bytes()==(C/'recovery-after-node20.json').read_bytes();assert len(json.loads(before))==637
results=[]
for i,row in enumerate(r['records']):
 runtime=a['runtimes'][i];assert row['runtime']==runtime['version'];assert row['exitCode']==0;assert row['command']==[runtime['path'],'--test','--test-concurrency=1',*a['testFiles']]
 raw=(C/row['log']['file']).read_bytes();assert pin(C/row['log']['file'])==row['log'];s=raw.decode();summary={k:int(v) for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)\s*$',s,re.M)};assert summary==row['summary'];assert summary['tests']>0 and summary['pass']==summary['tests'];assert all(summary[k]==0 for k in ['fail','cancelled','skipped','todo'])
 results.append({'version':runtime['version'].removeprefix('v'),'runtime':runtime,'exitCode':0,'inputsUnchanged':True,'summary':summary,'elapsedSeconds':row['elapsedSeconds'],'rawTAPDurationMs':float(re.search(r'^# duration_ms ([\d.]+)$',s,re.M).group(1)),'log':row['log'],'command':row['command']})
assert sha(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT))==a['indexSha256'];assert subprocess.check_output(['git','write-tree'],cwd=ROOT,text=True).strip()==a['tree']
for row in fixture['inputs']:
 b=(ROOT/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
sourceHold=pin(C/'source-held-01.json')
v={'head':a['head'],'tree':a['tree'],'sourceHold':sourceHold,'testFiles':a['testFiles'],'completePair':True,'inputCount':fixture['count'],'inputBytes':fixture['bytes'],'inputsUnchanged':True,'inputSnapshots':[pin(C/n) for n in ['recovery-before.json','recovery-after-node22.json','recovery-after-node20.json']],'authority':pin(C/'qualification-recovery.json'),'runner':pin(C/'run-qualified-recovery.py'),'rawReceipt':pin(C/'recovery-receipt.json'),'results':results,'initialDiagnostic':pin(C/'initial-diagnostic.json'),'intakeRecovery':pin(C/'intake-recovery.json'),'staticChecks':pin(C/'static-checks.json'),'scope':'Complete19-file Node22 and20 pair on unchanged combined source. Original400/414 omission, extra exact5,039-byte module, and launcher priority pause remain separate evidence. No browser/native/phase or P01/P02 acceptance.'}
p=C/'verification-union.json';p.write_text(json.dumps(v,indent=2)+'\n')
w={'previewTree':a['tree'],'head':a['head'],'sourceHold':sourceHold,'cohorts':{'union':pin(p)},'scope':'Exact19-file complete pair permits source-bound normal and single-target transport previews. No native acceptance inferred.'};q=C/'verification.json';q.write_text(json.dumps(w,indent=2)+'\n')
print(json.dumps({'tree':a['tree'],'counts':[x['summary'] for x in results],'verification':pin(p),'previewGate':pin(q)},indent=2))
