import subprocess,pathlib,json,re,hashlib,os,shutil
root=pathlib.Path.cwd(); out=root/'.cache/cross-mode-gameplay-preparation'
base='356401f936578db5d3643e13cb6287e59535e853'
incoming=[('hud','61fb43b32974187fe664f130117465285223251b'),('actors','d30f883df1e11d04fb8a5682e17171f98da67901'),('next','99f33086c5c381cd91459e59e672c4adba1fe18d')]
allowed={'authoring/prompts/cross-mode-delivery.md','authoring/skills/xonix-runtime-maintainer/SKILL.md','docs/cross-mode-execution.md'}
def git(*a,data=None,env=None):return subprocess.check_output(['git',*a],input=data,env=env)
def text(*a,**kw):return git(*a,**kw).decode().strip()
assert shutil.disk_usage(root).free>280*1024*1024
current=base; records=[]
for label,inc in incoming:
 result=subprocess.run(['git','merge-tree','--write-tree','--name-only',current,inc],capture_output=True,text=True)
 assert result.returncode in (0,1),result.stderr
 (out/f'merge-{label}.txt').write_text(result.stdout+result.stderr)
 lines=result.stdout.splitlines();tree=lines[0];conflicts=[]
 if result.returncode:
  for p in lines[1:]:
   if not p:break
   conflicts.append(p)
 assert set(conflicts)<=allowed,conflicts
 index=out/f'index-{label}'; env=dict(os.environ,GIT_INDEX_FILE=str(index))
 git('read-tree',tree,env=env)
 resolved=[]
 for path in conflicts:
  original=git('show',tree+':'+path).decode()
  pattern=r'^<<<<<<< [^\n]+\n(.*?)^\|\|\|\|\|\|\| [^\n]+\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]+\n'
  pairs=[]
  def combine(m):
   ours,ancestor,theirs=m.groups(); assert not ancestor.strip(),(path,ancestor)
   pairs.append({'oursSha256':hashlib.sha256(ours.encode()).hexdigest(),'incomingSha256':hashlib.sha256(theirs.encode()).hexdigest(),'baseEmpty':True})
   return ours.rstrip()+'\n\n'+theirs.lstrip()
  body,n=re.subn(pattern,combine,original,flags=re.M|re.S)
  assert n and not re.search(r'^(<<<<<<<|=======|>>>>>>>|\|\|\|\|\|\|\|)',body,re.M),path
  blob=text('hash-object','-w','--stdin',data=body.encode())
  git('update-index','--add','--cacheinfo','100644',blob,path,env=env)
  resolved.append({'path':path,'blocks':pairs,'sha256':hashlib.sha256(body.encode()).hexdigest()})
 final=text('write-tree',env=env)
 diagnostic=text('commit-tree',final,'-p',current,'-p',inc,data=f'Unreferenced diagnostic merge for {label}; not a qualified checkpoint\n'.encode())
 records.append({'input':inc,'priorDiagnosticOrBase':current,'rawTree':tree,'resolvedTree':final,'conflicts':resolved,'diagnosticCommit':diagnostic})
 index.unlink();current=diagnostic
receipt={'base':base,'parents':[base]+[x[1] for x in incoming],'finalTree':records[-1]['resolvedTree'],'intermediateObjects':'Unreferenced diagnostic objects only; final approved checkpoint must retain all four original parents','merges':records}
(out/'composition.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
