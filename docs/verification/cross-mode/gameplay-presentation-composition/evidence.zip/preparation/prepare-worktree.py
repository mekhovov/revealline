import subprocess,pathlib,json,zipfile,io,hashlib,os,shutil
root=pathlib.Path.cwd();out=root/'.cache/cross-mode-gameplay-preparation'
base='356401f936578db5d3643e13cb6287e59535e853';tree=json.loads((out/'composition.json').read_text())['finalTree']
work=root/'.cache/worktrees/cross-mode-gameplay-integration';branch='codex/cross-mode-gameplay-integration'
def git(*a,cwd=root,data=None):return subprocess.check_output(['git',*a],cwd=cwd,input=data)
p07=json.loads((root/'.cache/worktrees/p07-next-result-transaction/.cache/next-result/qualification-inputs-held07.json').read_text())
z=zipfile.ZipFile(io.BytesIO(git('show','d30f883:docs/verification/cross-mode/p08-team-actors/evidence.zip')))
a=json.loads(z.read(next(n for n in z.namelist() if n.endswith('whole-03-node22.json'))))
plan=json.loads((root/'.cache/worktrees/p03-collection-records-return/.cache/collection-records-return/next-composition-intake.json').read_text())
paths={x['path'] for x in p07['inputs']}|{x['path'] for x in a['before']}|set(plan['proposedTestFiles'])
for entry in plan['incoming']:paths|={x['path'] for x in entry['files']}
rows={}
for entry in git('ls-tree','-rz','-l',tree).split(b'\0'):
 if not entry:continue
 meta,p=entry.split(b'\t',1);mode,typ,blob,size=meta.decode().split();name=p.decode()
 if name in paths:
  assert typ=='blob' and mode in ('100644','100755'),name
  rows[name]={'path':name,'mode':mode,'gitBlob':blob,'bytes':int(size)}
assert paths==rows.keys(),sorted(paths-rows.keys())
total=sum(x['bytes'] for x in rows.values());free=shutil.disk_usage(root).free
assert total+5*1024*1024<100*1024*1024,(total,free)
assert free-total-20*1024*1024>256*1024*1024,(total,free)
assert not work.exists(),work
receipt={'base':base,'tree':tree,'newWorktree':str(work),'branch':branch,'paths':list(sorted(rows.values(),key=lambda x:x['path'])),'count':len(rows),'bytes':total,'freeBefore':free,'testFiles':plan['proposedTestFiles'],'method':'No-checkout worktree; private index tree without checkout; own sparse flags; manually materialize only exact regular Git bodies. No common sparse config edits.'}
(out/'admission.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('ADMITTED',len(rows),total,'free',free,flush=True)
git('worktree','add','--no-checkout','-b',branch,str(work),base)
git('config','--worktree','core.sparseCheckout','true',cwd=work);git('config','--worktree','core.sparseCheckoutCone','false',cwd=work)
gitdir=pathlib.Path(git('rev-parse','--absolute-git-dir',cwd=work).decode().strip());(gitdir/'info').mkdir(exist_ok=True)
(gitdir/'info/sparse-checkout').write_text('\n'.join('/'+p for p in sorted(paths))+'\n')
git('read-tree',tree,cwd=work)
allpaths=git('ls-files','-z',cwd=work)
git('update-index','--skip-worktree','-z','--stdin',cwd=work,data=allpaths)
git('update-index','--no-skip-worktree','-z','--stdin',cwd=work,data=b'\0'.join(p.encode() for p in sorted(paths))+b'\0')
# One bounded Git pipe avoids thousands of child processes and body recopy races.
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for row in receipt['paths']:
 proc.stdin.write((row['gitBlob']+'\n').encode());proc.stdin.flush();head=proc.stdout.readline().decode().split();assert head[0]==row['gitBlob'] and head[1]=='blob' and int(head[2])==row['bytes']
 b=proc.stdout.read(row['bytes']);assert proc.stdout.read(1)==b'\n';assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['gitBlob']
 target=work/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 if row['mode']=='100755':target.chmod(0o755)
 row['sha256']=hashlib.sha256(b).hexdigest()
proc.stdin.close();assert proc.wait()==0
(work/'node_modules').symlink_to(root/'node_modules',target_is_directory=True)
cache=work/'.cache/gameplay-composition';cache.mkdir(parents=True)
receipt['freeAfter']=shutil.disk_usage(root).free;receipt['materializedBytes']=sum(p.stat().st_size for p in work.rglob('*') if p.is_file() and not p.is_symlink())
assert receipt['materializedBytes']<100*1024*1024 and receipt['freeAfter']>256*1024*1024
assert git('write-tree',cwd=work).decode().strip()==tree
assert not git('diff','--name-only',cwd=work).strip()
(out/'materialization.json').write_text(json.dumps(receipt,indent=2)+'\n')
(cache/'materialization.json').write_bytes((out/'materialization.json').read_bytes())
print(json.dumps({k:receipt[k] for k in ['tree','count','bytes','materializedBytes','freeAfter','newWorktree']},indent=2))
