# Combined gameplay review — in progress

Frozen source tree: `a20e424d31331221791ae429c2b8bcc39cfee5af`. Normal preview 59199; the separate 59207 preview changes only the recorded First Signal image GET response sequence. These are internal composition checks, not phase, public-release or physical-device acceptance.

## Team

- `team/01.jpg`: root inspected. Actual 760×351, DPR2, canvas 732×366 at x14/y−130.8046875; scrollY324.5. The top of the arena and HUD are outside the viewport. **Fail: short-landscape fit.** Existing input focus uses `preventScroll`; this evidence does not establish what caused the retained scroll. Source diagnosis and an isolated CSS correction are tracked separately. The frozen source stays unchanged.
- `team-portrait/01`: a requested viewport had not settled: capture is actually351×760, not390×844. Start was activated by pointer. A preceding unsupported `cua.keypress` call threw before any input. Do not count this as keyboard-only Start or the intended viewport.
- `team-portrait/02.jpg`: actual390×844, DPR1. Root inspected the complete, clean pause surface. Resume, Retry, Change setup, mode choices and collapsed Help/Options are visible.
- `team-portrait/03.jpg`: actual390×844. Root inspected the complete 362×181 arena at x14/y253.59375, two player identifiers, shared objective and Pause. Keyboard Resume and direction taps were sent; time advanced but coverage remained0%, so this is not capture or encounter acceptance. Actor scale remains subject to the wider P08 playing-size review.
- `team-portrait/04.jpg`: root inspected. Keyboard Tab navigation reached Options and Return expanded it. Its inner surface can scroll; the first settings and focused heading are visible. This does not qualify all lower options.
- `team-portrait/05`: Escape collapsed Options and retained its focus; the game remained paused at0:28. Explicit Resume remains required.

The portrait recorder is closed. The short-landscape finding is retained and cannot be hidden by the portrait pass. Physical touch and controllers were not used.

## Versus

`versus-transport` is closed, six observations/three images. Root inspected images02/03/05.

- Keyboard setup selected First Signal Tactical, Escape returned to Race setup, Shift+Tab/Return started the race and a direction tap completed a real cut:52.2%,3 lives,8160 points and1:0. Event01's provisional label says cut started, but the captured state is already the completed result.
- Next consumed the injected second image GET503. Result, score and View both boards remained available; the ordinary-language retry message and focused Next were visible. Image03 confirms this bounded failure behavior.
- Retrying consumed GET3's six-second delay and focused a reachable Cancel action (event04). **The cancellation attempt missed its timing window:** the next tool call arrived after loading completed, and event05 shows a legally started second round with1:0 and fresh board stats. It is not a cancellation pass or evidence of stale automatic start. Image05 and its misleading provisional label are retained unchanged.
- Escape paused the second round, focusing explicit Resume. A separate longer-delay successor will check actual cancellation without changing this preview or these observations.

`versus-cancel` on61504 is a retained invalid setup attempt: selecting the map and immediately issuing Back/Start before preparation settled consumed GET1 and a replacement GET2 during initial preparation. The20-second delay therefore occurred before a completed race. The later Return arrived after readiness and started the first round; it did not cancel anything. Three DOM events, no images, are retained. Root then paused the run. This attempt proves no Next cancellation behavior. The final successor uses multiple delayed ordinals and separates map readiness from Start to avoid this operator sequencing error.

`versus-cancel-final` on61886 is closed with nine events/one image. It uses unchangeda20e and a separately pinned response schedule; it does not overwrite the earlier attempts.

- Real keyboard map selection was allowed to reach ready before Start. A real cut earned52.2%,3 lives,8160 points and1:0 (event01).
- Next GET2 began01:48:42.945; focused Cancel was activated at01:48:43.368, well inside20seconds. Result and Next focus were restored. Root inspected image03: clean, ordinary cancellation message and all earned values visible.
- GET2 completed01:49:02.955; event04 at01:49:26 still had the same result and Next focus. No late start or duplicate point followed cancellation.
- GET3 retry was resized to measured433×938,DPR0.9. Cancel was inside818.14..866.14; immediate cancellation restored Next inside768.65..817.15, retaining all earned values. These are actual dimensions, not the requested390×844.
- GET4 was allowed to finish after resize to measured844×390,DPR0.9. Cancel stayed visible326.08..374.07 while pending. The still-owned shipped Next then legitimately adopted and started a fresh round, retained1:0, and focused an in-viewport canvas with scroll0. It did not require an installed-pack Ready action; that distinct path is not qualified here.
- Escape then paused the fresh round and restored explicit Resume (event09). No physical controller/touch or resized screenshot acceptance is claimed. The inherited full test pair and this bounded integration check are separate evidence.

The composition can be retained as an internal checkpoint with the Team short-landscape defect explicitly open. It is not complete P03/P05/P08/P07 or a public release. The separate CSS successor and final P02 composition still require their own gates.
