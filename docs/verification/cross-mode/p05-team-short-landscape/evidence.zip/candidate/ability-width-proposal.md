# Large touch pad intrinsic width

Held02 fixes the inner arena track. Root's actual 760 × 351 Large/shown
measurement instead exposes the existing pad constraint: `.race-pad` is 140 px
wide with two equal columns and a 4 px gap, leaving each ability button about
68 px. Boost and Support wrap and become 62.11 px tall. The full pad then needs
206.07 px, exceeding the 190.53 px arena row and overlapping its neighbours.

Proposed change is confined to the existing compact live shown-pad media block:

- Give each outer gutter its `max-content` width; keep the arena column
  `minmax(0, 1fr)`.
- Give `.race-pad` `width: max-content` and two
  `minmax(var(--fk-target-size), max-content)` columns. The cross retains its
  existing three 44 px columns, gaps and centred position.
- Keep direct ability labels on one line. Do not change font roles, line height,
  44 px minima, markup, target order, handlers, HUD contents or canvas ratio.

The two identical label sets produce matching intrinsic gutters. The arena
continues to contain its intrinsic 2:1 canvas in the remaining row and column.
This trades unused horizontal space for the label width instead of borrowing
height from the HUD or reducing text. Native must establish that both complete
pads fit their row at actual 760 × 351 and 844 × 390, with no overlap, and that
the complete arena and both players remain legible. Test Standard and Large,
shown and hidden pads; preserve the failed held02 observations.

Authority: current CSS 18,118 B / SHA-256
`13cdb8d4d017afddf3f3a96238d83f1958b61a1446e6a7c8d61ab547c22cc22d`;
root geometry `.cache/team-short-landscape-native-root/held02/02-large-shown-760x351.geometry.json`.
This is a proposal only. No source changed after held02 launch.
