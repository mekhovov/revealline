# Held CSS native boundary

The candidate changes only `game/couch/relay-rescue.css` over frozen composition
tree `a20e424d31331221791ae429c2b8bcc39cfee5af`. Root owns the browser. The
temporary base commit exists only to isolate this candidate; final composition
history remains separate.

At actual viewport 760 × 351 and 844 × 390, cover Standard and Large display text
with touch controls hidden and shown. Record viewport, DPR, current touch/text
preferences, active element, scroll position, and rectangles for the arena,
canvas, both player HUDs, objective, footer/Pause, and both visible input pads.
Keep the complete 2:1 canvas and both players visible; preserve 44 px touch
targets. Use real Start, Pause, Options, Back and Resume actions as needed.

The preceding 760 × 351 observation proves a width-derived 366 px canvas could
not fit the live HUD/arena. Its active canvas used `preventScroll`; the original
scroll source is unresolved. Do not attribute scroll to focus. If this CSS
candidate still leaves an otherwise fitting live layout offscreen, preserve the
observation and review a separate narrow correction before changing host code.

No mirrored CSS tests were added. The inherited 414-case pair qualifies the
unchanged composed runtime, not this candidate's geometry. These viewport
checks do not establish physical device, zoom, public or phase acceptance.

The preview freezes its single admitted CSS body at launch. Take post-HTTP and
local pins before changing source; any successor must use a fresh hold/origin.
