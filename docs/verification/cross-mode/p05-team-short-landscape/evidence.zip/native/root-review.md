# Compact Team CSS candidate — unresolved

Candidate4c3fc900 over frozena20e, preview61867. Source and HTTP bindings remain separate from earlier414-test runtime qualification.

Observation01 is a **failure** at measured844×390,DPR0.899999976 (not the requested760×351). The document scroll returned to0 and the outer grid fits390px, but its canvas overflows the allocated row.

Read-only DOM measurements immediately after01: `#coop-app` has390px height and grid rows62.6823/18.1944/251.155/43.9931px; `.arena-wrap` is820.451×251.155 at11.9965/88.8629, with an implicit internal grid row408.559px. Canvas is817.118×408.559 at13.6632/90.5295. Its computed max-height100% refers to an intrinsic auto grid track; it does not contain the canvas in the outer251px row. Footer/Pause sit at342.014 with43.993px height and are overlapped by the canvas. Root paused the game after measuring.

An explicit constrained inner grid track is under review. No transform/cropping/hitbox change is authorized as a substitute. This failed original is retained; the successor needs a new source hold/origin and actual measured viewport checks.

Root inspected image01: the in-app resized capture contains duplicated compositor bands, so it is not accepted as a clean visual comparison. The failure above is independently established by the measured live DOM rectangles. The recorder is closed.
