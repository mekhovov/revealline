# Held02 Team layout review — partial

Exact CSS13cdb8d4 overa20e, preview62425. Actualviewport760×351,DPR0.9 was measured rather than inferred from the requested size. Geometry JSONs retain every measured region/control; no images have been accepted for this successor.

- **Standard / Auto resolved hidden:** full421.858×210.929 arena at169.071/88.533 with2:1 ratio. Both player HUDs/objective and Pause fit. Scroll changed from the genuinely scrolled lobby365.56 to0 at Start. No host scroll change was needed.
- Keyboard Pause→Options selected Large and Show both players. Escape collapsed Options, six backward Tabs reached Resume, and Return explicitly resumed.
- **Large / shown pads: additional failure.** Outer viewport grid fits, and the canvas is correctly contained at374.392×187.196. But each side control stack is taller than the allocated190.53px row. Its top is100.503 while the arena row starts108.273 and the objective ends106.276. Wrapped Boost/Support buttons are62.109px high at68px width; they end306.571 while the footer starts300.799. Centre hit tests alone all pass and therefore miss this overlap. Full five-point hit tests and non-overlap rectangles are required in the successor.

Retain the corrected inner-track behavior. The remaining work is a Large-text touch-control budget correction, with unchanged type sizes and44px targets. No whole-phase, physical-touch/controller, or public acceptance follows from the partial geometry pass. The game is paused during source review.
