import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {performance} from 'node:perf_hooks';
import {fileURLToPath} from 'node:url';
import {createTransport} from '../../p01/public-v0574-offline-completion-r8/ws-transport.mjs';

const dir=path.dirname(fileURLToPath(import.meta.url));
const profile=path.join(dir,'profile');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const free=()=>{const s=fs.statfsSync(dir);return s.bavail*s.bsize;};
const args=['--headless=new','--remote-debugging-port=0','--enable-automation','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--disable-default-apps','--disable-gpu-shader-disk-cache','--enable-unsafe-swiftshader','--password-store=basic','--use-mock-keychain','--disk-cache-size=4194304','--media-cache-size=1048576','--window-size=760,351','--user-data-dir='+profile,'about:blank'];
const out={at:new Date().toISOString(),profile,pid:null,args,scope:'Team held04 CSS visual diagnostic: native Large/Show both, Relay Yard760x351 and First Connection844x390. Immediate clean running capture then native Pause, no steering/ability input. New unsaved Relay diagnostic attempt is discarded only through Change setup confirmation. No app/runtime/storage injection; native selections may normally persist display preferences. Runtime.evaluate observations only.',phases:[],actions:[],captures:[],limits:{totalMs:180000,operationalMs:168000,startupMs:60000,nativeInputs:100,pngs:4,freeFloorBytes:2*1024**3},freeBefore:free(),errors:[],eventsTruncated:false,chromeLogTruncated:false};
let chrome,sid,ws,seq=0,eventBytes=0,chromeLogBytes=0,phase='startup',fatal=null,exitCode=null,exitSignal=null,exited=false,childClosed=false,observationBytes=0,spawnError=null,events=null,chromeLog=null,resultFile=null,deadline,capacity,port=null;
const pending=new Map(),requestPhases=new Map();
const URL_EXPECTED='http://127.0.0.1:63822/game/couch/relay-rescue.html';
let viewport={width:760,height:351},runningSince=null;
const bindingPath='/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/p05-team-short-landscape/.cache/team-short-landscape/preview-held04/binding-normal.json';
let targetId=null,launchedAt=null,nativeInputs=0;
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const short=(value,limit=3000)=>String(value??'').slice(0,limit);
function errorNote(value){if(out.errors.length<32)out.errors.push(short(value));else out.errorsTruncated=true;}
function urlMetadata(value){
 const raw=String(value??'');let u;try{u=new URL(raw);}catch{}
 const metadata={scheme:u?.protocol??'invalid:',bytes:Buffer.byteLength(raw),sha256:crypto.createHash('sha256').update(raw).digest('hex')};
 if(u&&['http:','https:'].includes(u.protocol)){const address=u.origin+u.pathname;metadata.address=address.slice(0,2048);metadata.addressTruncated=address.length>2048;}
 return metadata;
}
function log(row){
 const b=JSON.stringify({at:new Date().toISOString(),observedPhase:phase,...row})+'\n';
 if(Buffer.byteLength(b)>64*1024||eventBytes+Buffer.byteLength(b)>4*1024**2){out.eventsTruncated=true;out.droppedEvents=(out.droppedEvents??0)+1;return;}
 if(events!==null){fs.writeSync(events,b);eventBytes+=Buffer.byteLength(b);}
}
function fail(message){fatal??=short(message);if(chrome?.pid&&!exited)chrome.kill('SIGTERM');}
function call(method,params={},sessionId=sid,timeout=10000){return new Promise((resolve,reject)=>{
 if(ws?.readyState!==1){reject(Error('CDP socket not open: '+method));return;}
 const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP deadline '+method));},timeout);
 pending.set(id,{resolve,reject,timer});
 try{ws.send(JSON.stringify({id,method,params,...sessionId?{sessionId}:{}}));}catch(error){clearTimeout(timer);pending.delete(id);reject(error);}
});}
async function read(expression){const r=await call('Runtime.evaluate',{expression,returnByValue:true});if(r.exceptionDetails)throw Error(short(JSON.stringify(r.exceptionDetails)));return r.result.value;}
function processAbsent(){if(!chrome?.pid)return true;try{process.kill(chrome.pid,0);return false;}catch(error){return error.code==='ESRCH';}}
function endpointClosed(){return new Promise(resolve=>{
 if(!port){resolve(null);return;}
 const socket=net.createConnection({host:'127.0.0.1',port});let settled=false;
 const done=value=>{if(settled)return;settled=true;socket.destroy();resolve(value);};
 socket.setTimeout(500,()=>done(false));socket.once('connect',()=>done(false));socket.once('error',error=>done(error.code==='ECONNREFUSED'));
});}
const observation=`(()=>{
 const rect=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height};};
 const info=e=>{if(!e)return null;const r=rect(e),c=getComputedStyle(e),visible=!e.closest('[hidden]')&&r.width>0&&r.height>0&&c.display!=='none'&&c.visibility!=='hidden';const hit=(x,y)=>{const t=document.elementFromPoint(x,y);return {x,y,id:t?.id??null,tag:t?.tagName??null,within:!!t&&(t===e||e.contains(t))};};return {id:e.id,tag:e.tagName,text:e.innerText?.slice(0,300),label:e.getAttribute('aria-label'),value:'value'in e?e.value:undefined,selectedText:e.tagName==='SELECT'?e.selectedOptions[0]?.textContent:undefined,hidden:e.hidden,disabled:!!e.disabled,inert:!!e.closest('[inert]'),visible,focused:e===document.activeElement,focusVisible:e.matches(':focus-visible'),rect:r,clientWidth:e.clientWidth,scrollWidth:e.scrollWidth,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,scrollTop:e.scrollTop,insideViewport:visible&&r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight,style:{fontFamily:c.fontFamily,fontSize:c.fontSize,lineHeight:c.lineHeight,fontWeight:c.fontWeight,overflowX:c.overflowX,overflowY:c.overflowY},hits:visible?[hit(r.x+r.width/2,r.y+r.height/2),hit(r.left+1,r.top+1),hit(r.right-1,r.top+1),hit(r.left+1,r.bottom-1),hit(r.right-1,r.bottom-1)]:[]};};
 const ids=['coop-menu','coop-start','coop-play','coop-canvas','coop-controls','coop-options-toggle','coop-text-size','coop-text-face','coop-touch','coop-level','coop-pause','coop-resume','coop-lobby','coop-discard-confirm','coop-discard-stay','coop-overlay','coop-overlay-title','coop-objective','coop-clock','coop-stage','coop-picture-status'];
 return {url:location.href,timeOrigin:performance.timeOrigin,now:performance.now(),visibility:document.visibilityState,hasFocus:document.hasFocus(),toolState:document.documentElement.dataset.toolState,bodyClass:document.body?.className,datasets:{...document.body?.dataset},viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},active:info(document.activeElement),elements:Object.fromEntries(ids.map(id=>[id,info(document.getElementById(id))])),optionsOpen:document.getElementById('coop-options')?.open,pictureState:document.getElementById('coop-picture-status')?.dataset.state,dialogs:[...document.querySelectorAll('dialog[open]')].map(e=>({id:e.id,rect:rect(e)})),arena:info(document.querySelector('.arena-wrap')),hud:info(document.querySelector('#coop-play .hud')),hudParts:[...document.querySelectorAll('#coop-play .hud .identity,#coop-play .hud .identity>*,#coop-play .team-status,#coop-play .team-status>*')].map(info),footer:info(document.querySelector('.board-footer')),pads:[...document.querySelectorAll('#coop-controls .race-pad')].map(info),padButtons:[...document.querySelectorAll('#coop-controls .race-pad button')].map(info)};
})()`;
function assert(condition,message){if(!condition)throw Error(message);}
function alive(){assert(!fatal&&!exited&&!spawnError,fatal||spawnError||'Owned Chrome stopped');assert(launchedAt===null||performance.now()-launchedAt<168000,'168s operation limit; 12s closure reserve');}
async function sample(label){
 alive();const value=await read(observation),bytes=Buffer.byteLength(JSON.stringify(value));observationBytes+=bytes;
 assert(bytes<=64*1024&&observationBytes<=4*1024**2,'Observation metadata budget');
 log({observation:label,url:value.url,timeOrigin:value.timeOrigin,viewport:value.viewport,activeId:value.active?.id,toolState:value.toolState,pictureState:value.pictureState,bodyClass:value.bodyClass,dialogs:value.dialogs.map(e=>e.id)});return value;
}
function guardValue(v){
 assert(v.url===URL_EXPECTED,'Unexpected page URL '+v.url);
 assert(v.viewport.width===viewport.width&&v.viewport.height===viewport.height&&v.viewport.dpr===1,'Viewport changed');
 assert(v.visibility==='visible'&&v.hasFocus,'Owned page not foreground/focused');
 if(runningSince!==null)assert(performance.now()-runningSince<8000,'8s running-capture bound');
 assert(v.dialogs.every(d=>['coop-discard-dialog'].includes(d.id)),'Unexpected dialog owner');
}
async function guarded(label){
 alive();const pages=(await call('Target.getTargets',{},null)).targetInfos.filter(t=>t.type==='page');
 assert(pages.length===1&&pages[0].targetId===targetId&&pages[0].url===URL_EXPECTED,'Owned target changed');
 const v=await sample(label);guardValue(v);return v;
}
async function key(key,shift=false){
 const before=await guarded('before-key-'+key);assert(!before.elements['coop-pause']?.visible||before.elements['coop-pause'].disabled,'Keyboard preference/traversal input refused during live Team');assert(++nativeInputs<=100,'Native input bound');
 const action={number:nativeInputs,at:new Date().toISOString(),kind:'key',key,shift,before};out.actions.push(action);
 const keys={Escape:['Escape',27],Tab:['Tab',9],Enter:['Enter',13],l:['KeyL',76],s:['KeyS',83],f:['KeyF',70]};
 assert(keys[key],'Key not permitted');const [code,windowsVirtualKeyCode]=keys[key];
 const params={key,code,windowsVirtualKeyCode,modifiers:shift?8:0};
 if(['l','s','f','Enter'].includes(key)){params.text=key==='Enter'?'\r':key;params.unmodifiedText=params.text;}
 await call('Input.dispatchKeyEvent',{type:params.text?'keyDown':'rawKeyDown',...params});
 await call('Input.dispatchKeyEvent',{type:'keyUp',key,code,windowsVirtualKeyCode,modifiers:shift?8:0});
 await sleep(120);action.after=await guarded('after-key-'+key);return action.after;
}
async function waitFor(label,predicate,ms=4000){
 const until=performance.now()+ms;let v;
 while(performance.now()<until){v=await guarded(label);if(predicate(v))return v;await sleep(120);}
 throw Error(label+' did not settle within '+ms+'ms; active='+v?.active?.id+' dialogs='+JSON.stringify(v?.dialogs));
}
async function tabTo(id,limit=32){
 let v=await guarded('seek-'+id);if(v.active?.id===id&&v.active.focusVisible)return v;
 // No fixed tab count: each actual destination is observed; reverse only after a full forward cycle.
 const seen=new Set();let reverse=false;
 for(let i=0;i<limit;i++){
  v=await key('Tab',reverse);if(v.active?.id===id&&v.active.focusVisible)return v;
  const marker=(v.active?.tag??'')+':'+(v.active?.id??'')+':'+(v.active?.text??'');
  if(!reverse&&seen.has(marker)){reverse=true;seen.clear();}seen.add(marker);
 }
 throw Error('Keyboard route did not reach '+id+' within '+limit+' observed Tab/Shift+Tab inputs');
}
async function clickVisible(id){
 assert(['coop-start','coop-pause','coop-lobby','coop-discard-confirm'].includes(id),'Mouse target not permitted');
 const before=await guarded(id+'-click-geometry'),c=before.elements[id];
 assert(c?.visible&&!c.disabled&&!c.inert&&c.insideViewport&&c.hits[0].within,id+' not currently clickable');
 await sleep(60);const settled=await guarded(id+'-click-settled'),fresh=settled.elements[id];
 assert(JSON.stringify(fresh.rect)===JSON.stringify(c.rect)&&fresh.hits[0].within&&!fresh.disabled,id+' target did not settle');
 assert(++nativeInputs<=100,'Native input bound');const a={number:nativeInputs,at:new Date().toISOString(),kind:'mouse',selector:'#'+id,before:settled};out.actions.push(a);
 if(id==='coop-start')runningSince=performance.now();
 const x=c.hits[0].x,y=c.hits[0].y;
 await call('Input.dispatchMouseEvent',{type:'mouseMoved',x,y});
 await call('Input.dispatchMouseEvent',{type:'mousePressed',x,y,button:'left',clickCount:1});
 await call('Input.dispatchMouseEvent',{type:'mouseReleased',x,y,button:'left',clickCount:1});
 await sleep(80);a.after=await guarded(id+'-click-after');return a.after;
}
async function capture(name,level){
 assert(out.captures.length<4,'Four screenshot maximum');
 const before=await guarded(name+'-before'),e=before.elements;
 assert(e['coop-level'].value===level&&before.datasets.textSize==='large'&&e['coop-touch'].value==='on'&&before.datasets.coopTouch==='visible','Actual requested arena/Large/Shown not observed');
 assert(!e['coop-overlay'].visible&&!e['coop-pause'].disabled&&before.pads.length===2&&before.pads.every(p=>p.visible),'Clean running arena and both pads required');
 const metricsBefore=await call('Page.getLayoutMetrics');
 const png=Buffer.from((await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64');
 assert(png.length<=2*1024**2&&png.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])),'PNG budget/signature');
 assert(png.readUInt32BE(16)===viewport.width&&png.readUInt32BE(20)===viewport.height,'Actual PNG viewport mismatch');
 const filename=name+'.png';fs.writeFileSync(path.join(dir,filename),png,{flag:'wx'});
 const after=await guarded(name+'-after'),metricsAfter=await call('Page.getLayoutMetrics');
 out.captures.push({name,path:filename,bytes:png.length,sha256:hash(png),png:{...viewport},before,after,metricsBefore,metricsAfter,scope:'Live clean arena snapshot; native mouse/keyboard input, not physical touch/gamepad qualification. Geometry/labels/fonts and five hit samples require visual review.'});
 assert(after.timeOrigin===before.timeOrigin&&!after.elements['coop-overlay'].visible&&after.datasets.coopTouch==='visible','Arena state changed during capture');
}
async function pauseTeam(){
 await clickVisible('coop-pause');
 const v=await waitFor('paused-after-capture',v=>v.elements['coop-overlay'].visible&&v.elements['coop-pause'].disabled&&v.elements['coop-overlay-title'].text==='Both players paused');
 out.pauses??=[];out.pauses.push({runningWindowMs:performance.now()-runningSince,observation:v});runningSince=null;return v;
}
async function ready(label,ms=20000){return waitFor(label,v=>v.toolState==='ready'&&v.pictureState==='ready'&&!v.elements['coop-start'].disabled&&!v.elements['coop-menu'].hidden,ms);}

try{
 if(fs.existsSync(profile)||free()<2*1024**3)throw Error('Fresh owned profile and 2GiB free-space floor required');
 const bindingBytes=fs.readFileSync(bindingPath),binding=JSON.parse(bindingBytes);
 assert(hash(bindingBytes)==='67c079d0dd06a82792f476337d96eb88a3f9eb8f041af226b702ac397a261de7','Held04 binding changed');
 assert(binding.temporaryBaseCommit==='33f733506a1f9236139370139c86a23a0a289f79'&&binding.tree==='a20e424d31331221791ae429c2b8bcc39cfee5af'&&binding.port===63822&&binding.url===URL_EXPECTED&&binding.overlays?.length===1&&binding.overlays[0].sha256==='77f7ffa62432a8d27143bdd5455f15e2df4e70eca04818e17ac1573b5ac75afe','Exact Team held04 identity required');
 out.sourceBinding={path:bindingPath,bytes:bindingBytes.length,sha256:hash(bindingBytes),value:binding};
 // Reserve exclusive evidence files before a child can exist; all later setup is protected.
 resultFile=fs.openSync(path.join(dir,'result.json'),'wx');
 events=fs.openSync(path.join(dir,'events.jsonl'),'wx');
 chromeLog=fs.openSync(path.join(dir,'chrome.log'),'wx');
 fs.mkdirSync(profile);
 launchedAt=performance.now();
 chrome=spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args,{stdio:['ignore','ignore','pipe']});
 out.pid=chrome.pid??null;
 chrome.on('error',error=>{spawnError=short(error);fail('Chrome child error: '+spawnError);});
 chrome.on('exit',(code,signal)=>{exited=true;exitCode=code;exitSignal=signal;});
 chrome.on('close',()=>{childClosed=true;});
 chrome.stderr.on('data',bytes=>{try{const room=1024**2-chromeLogBytes;if(bytes.length>room)out.chromeLogTruncated=true;if(room>0){const part=bytes.subarray(0,room);fs.writeSync(chromeLog,part);chromeLogBytes+=part.length;}}catch(error){fail('Chrome log write: '+error);}});
 deadline=setTimeout(()=>fail('168s operation bound; 12s reserved for closure within 180s total'),168000);
 capacity=setInterval(()=>{try{if(free()<2*1024**3)fail('2GiB free-space floor');}catch(error){fail('Capacity observation failed: '+error);}},5000);
 const portFile=path.join(profile,'DevToolsActivePort');
 for(let i=0;i<200&&!fs.existsSync(portFile);i++){if(fatal||exited||spawnError)throw Error(fatal||spawnError||'Chrome stopped');await sleep(100);}
 const [portText,route]=fs.readFileSync(portFile,'utf8').trim().split('\n');port=Number(portText);
 if(!Number.isInteger(port)||port<1||port>65535||!/^\/devtools\/browser\/[a-zA-Z0-9-]+$/.test(route))throw Error('Invalid owned DevTools endpoint');
 out.endpoint='ws://127.0.0.1:'+port+route;ws=createTransport(out.endpoint);
 ws.on('message',bytes=>{try{
  const m=JSON.parse(bytes);if(m.id){const p=pending.get(m.id);if(!p)return;clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(short(JSON.stringify(m.error)))):p.resolve(m.result);return;}
  if(m.sessionId!==sid)return;const p=m.params||{};
  if(m.method==='Network.requestWillBeSent'){
   if(!requestPhases.has(p.requestId)){if(requestPhases.size>=10000)throw Error('Request identity budget');requestPhases.set(p.requestId,phase);}
   log({method:m.method,requestId:p.requestId,requestPhase:requestPhases.get(p.requestId),url:urlMetadata(p.request.url),type:p.type,timestamp:p.timestamp,loaderId:p.loaderId,redirect:!!p.redirectResponse});
  }else if(m.method==='Network.responseReceived')log({method:m.method,requestId:p.requestId,requestPhase:requestPhases.get(p.requestId)??null,url:urlMetadata(p.response.url),status:p.response.status,type:p.type,timestamp:p.timestamp,fromDiskCache:p.response.fromDiskCache,fromServiceWorker:p.response.fromServiceWorker,timing:p.response.timing});
  else if(['Network.loadingFailed','Network.loadingFinished','Network.requestServedFromCache'].includes(m.method))log({method:m.method,requestId:p.requestId,requestPhase:requestPhases.get(p.requestId)??null,timestamp:p.timestamp,encodedDataLength:p.encodedDataLength,errorText:short(p.errorText),canceled:p.canceled,type:p.type});
  else if(m.method==='Runtime.exceptionThrown'){const d=p.exceptionDetails??{};log({method:m.method,text:short(d.text),url:urlMetadata(d.url),description:short(d.exception?.description),lineNumber:d.lineNumber,columnNumber:d.columnNumber});}
  else if(m.method==='Log.entryAdded')log({method:m.method,level:p.entry?.level,source:p.entry?.source,text:short(p.entry?.text),url:urlMetadata(p.entry?.url)});
  else if(['Page.domContentEventFired','Page.loadEventFired'].includes(m.method))log({method:m.method,timestamp:p.timestamp});
  else if(m.method==='Runtime.consoleAPICalled')log({method:m.method,type:p.type,args:(p.args??[]).slice(0,16).map(a=>({type:a.type,value:typeof a.value==='string'?short(a.value):typeof a.value==='number'||typeof a.value==='boolean'?a.value:undefined,description:short(a.description)})),argsTruncated:(p.args?.length??0)>16});
 }catch(error){errorNote(error);fail('CDP event collection failed: '+error);}});
 ws.on('error',e=>errorNote(e));ws.on('close',()=>{for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('Socket closed'));}pending.clear();});
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('WebSocket open deadline')),5000);ws.once('open',()=>{clearTimeout(timer);resolve();});ws.once('error',error=>{clearTimeout(timer);reject(error);});});
 const targets=(await call('Target.getTargets',{},null)).targetInfos.filter(t=>t.type==='page');if(targets.length!==1||targets[0].url!=='about:blank')throw Error('Owned blank target required');
 targetId=targets[0].targetId;out.targetId=targetId;
 sid=(await call('Target.attachToTarget',{targetId,flatten:true},null)).sessionId;
 for(const method of ['Page.enable','Runtime.enable','Log.enable','Network.enable','Performance.enable'])await call(method);
 await call('Emulation.setDeviceMetricsOverride',{...viewport,deviceScaleFactor:1,mobile:false});await call('Page.bringToFront');
 phase='team-lobby';const p={name:phase,startedAt:new Date().toISOString(),samples:[]};out.phases.push(p);
 p.navigationReply=await call('Page.navigate',{url:URL_EXPECTED});assert(!p.navigationReply.errorText,'Navigation failed');
 const startupUntil=launchedAt+60000;
 while(performance.now()<startupUntil){alive();let v;try{v=await sample('team-startup');}catch(error){if(/context|Cannot find/i.test(String(error))){await sleep(100);continue;}throw error;}p.samples.push(v);if(v.url===URL_EXPECTED&&v.toolState==='ready'&&v.pictureState==='ready'&&!v.elements['coop-start'].disabled){p.ready=v;break;}await sleep(200);}
 assert(p.ready,'Team boot and actual picture readiness exceeded60s');
 assert(p.ready.elements['coop-level'].value==='relay-yard','Default authored Relay Yard not selected');
 phase='native-options';await tabTo('coop-options-toggle');await key('Enter');await waitFor('options-open',v=>v.optionsOpen);
 await tabTo('coop-text-size');await key('l');await key('Tab');await waitFor('large-selected',v=>v.datasets.textSize==='large'&&v.elements['coop-text-size'].value==='large');
 await tabTo('coop-touch');await key('s');await key('Tab');await waitFor('show-both-selected',v=>v.elements['coop-touch'].value==='on');
 await key('Escape');await waitFor('options-closed',v=>!v.optionsOpen);
 phase='relay-760';await ready('relay-picture-ready');await tabTo('coop-start');await clickVisible('coop-start');
 await waitFor('relay-started',v=>!v.elements['coop-play'].hidden&&!v.elements['coop-overlay'].visible&&!v.elements['coop-pause'].disabled&&v.datasets.coopTouch==='visible',4000);
 await capture('01-relay-yard-large-shown-760x351','relay-yard');await pauseTeam();
 phase='change-setup';await tabTo('coop-lobby');await clickVisible('coop-lobby');await waitFor('discard-confirmation',v=>v.dialogs.some(d=>d.id==='coop-discard-dialog'));
 await tabTo('coop-discard-confirm');await clickVisible('coop-discard-confirm');await ready('returned-lobby');
 viewport={width:844,height:390};await call('Emulation.setDeviceMetricsOverride',{...viewport,deviceScaleFactor:1,mobile:false});await sleep(150);
 await tabTo('coop-level');await key('f');await key('Tab');await waitFor('first-connection-selected',v=>v.elements['coop-level'].value==='first-connection');await ready('first-connection-picture-ready');
 phase='first-connection-844';await tabTo('coop-start');await clickVisible('coop-start');
 await waitFor('first-connection-started',v=>!v.elements['coop-play'].hidden&&!v.elements['coop-overlay'].visible&&!v.elements['coop-pause'].disabled&&v.datasets.coopTouch==='visible',4000);
 await capture('02-first-connection-large-shown-844x390','first-connection');await pauseTeam();
 out.diagnosticCompleted=true;
 out.omitted='Optional Standard/Hidden omitted to keep exactly two requested arena cases; no direction, Boost, Support, physical touchscreen or controller actions.';

}catch(e){out.status='FAILED_RETAINED';out.error=short(e.stack,8000);process.exitCode=1;}
finally{
 phase='cleanup';
 try{if(ws?.readyState===1)await call('Browser.close',{},null,2000);}catch(e){out.closeError=short(e);}
 for(let i=0;i<30&&chrome?.pid&&!exited;i++)await sleep(100);
 if(chrome?.pid&&!exited){out.cleanupSignal='SIGTERM';chrome.kill('SIGTERM');for(let i=0;i<20&&!exited;i++)await sleep(100);}
 if(chrome?.pid&&!exited){out.cleanupSignal='SIGKILL';chrome.kill('SIGKILL');for(let i=0;i<20&&!exited;i++)await sleep(100);}
 for(let i=0;i<10&&chrome?.pid&&!childClosed;i++)await sleep(100);
 clearInterval(capacity);clearTimeout(deadline);
 if(ws&&ws.readyState!==3)ws.terminate();for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('Diagnostic cleanup'));}pending.clear();
 out.exitCode=exitCode;out.exitSignal=exitSignal;out.spawnError=spawnError;out.browserExited=exited;out.pidAbsent=processAbsent();out.endpointClosed=await endpointClosed();out.childClosed=childClosed;out.browserClosed=Boolean(chrome?.pid&&exited&&childClosed&&out.pidAbsent&&out.endpointClosed===true);out.capacityFailure=fatal;out.freeAfter=free();out.finishedAt=new Date().toISOString();out.eventBytes=eventBytes;out.chromeLogBytes=chromeLogBytes;out.observationBytes=observationBytes;
 out.elapsedMs=launchedAt===null?null:performance.now()-launchedAt;
 out.status=out.diagnosticCompleted&&!out.error&&!fatal&&out.browserClosed&&exitCode===0&&out.elapsedMs<=180000?'COMPLETED_TWO_TEAM_CAPTURES_VISUAL_REVIEW_REQUIRED':'FAILED_RETAINED';
 out.evidenceComplete=!out.eventsTruncated&&!out.errorsTruncated&&!out.chromeLogTruncated;
 if(!out.evidenceComplete)out.status='FAILED_RETAINED';
 if(out.status!=='COMPLETED_TWO_TEAM_CAPTURES_VISUAL_REVIEW_REQUIRED')process.exitCode=1;
 let serialized=JSON.stringify(out,null,2)+'\n';
 if(Buffer.byteLength(serialized)>8*1024**2){out.status='FAILED_RETAINED';out.error='Result metadata exceeded8MiB; detailed samples omitted';out.evidenceComplete=false;for(const p of out.phases){p.omittedSampleCount=p.samples.length;p.samples=[];}serialized=JSON.stringify(out,null,2)+'\n';process.exitCode=1;}
 try{if(resultFile!==null)fs.writeFileSync(resultFile,serialized);else console.error(short(out.error??'Preflight refused'));}finally{for(const fd of [events,chromeLog,resultFile])if(fd!==null)fs.closeSync(fd);}
 console.log(JSON.stringify({status:out.status,error:out.error,captures:out.captures.map(p=>({name:p.name,path:p.path,sha256:p.sha256})),nativeInputs,elapsedMs:out.elapsedMs,exitCode,exitSignal,browserClosed:out.browserClosed,evidenceComplete:out.evidenceComplete,fatal}));
}
