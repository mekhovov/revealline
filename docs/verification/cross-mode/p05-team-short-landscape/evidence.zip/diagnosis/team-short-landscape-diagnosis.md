# Team short-landscape layout diagnosis

Read-only against frozen gameplay tree `a20e424d31331221791ae429c2b8bcc39cfee5af`, 16 September 2026. The companion JSON pins source and root's immutable Team observation 01. No preview or product files were changed.

**The primary defect is a missing height-constrained layout for hidden touch controls at the 760px width boundary.** In `game/couch/relay-rescue.css:72–80`, the non-touch arena height cap applies only at widths of at least 761px. The other short-landscape grid (`:729–795`) applies only when `data-coop-touch='visible'`. At 760×351 with pads hidden, neither applies: `canvas` is full width with a 2:1 ratio (`:365–370`). The 12px left/right page padding and 2px arena borders produce `(760 − 24 − 4) / 2 = 366px` of canvas height, exactly matching root's observation. That is already 15px taller than the viewport before HUD, objective, Pause/status or page padding.

Root observation 01 records canvas `(x14, y−130.8046875, width732, height366)` at actual 760×351, DPR2, with the canvas active. Root separately reported scrollY324.5. The input owner calls `arena.focus({preventScroll:true})` in `couch-input.mjs:498–500`; `relay-rescue.mjs:617` uses that owner after installing/rendering play. Therefore the evidence does **not** establish that focus caused the scroll. Retained lobby scroll and layout/scroll anchoring remain possible causes. The layout overflow is conclusive independently of that attribution.

## Height and existing contract

| Viewport/path | Source conclusion, distinct from a new native check |
| --- | --- |
| 760×351, hidden pads | Actual observed failure. Full-width canvas alone cannot fit. |
| 760×390, hidden pads | Same uncapped 366px canvas; only 24px remains, so the required HUD and Pause cannot also fit. Source projection only. |
| 844×390, hidden pads | The ≥761px rule caps wrapper width to 300px from `(390−240)×2`; this reduces the board but does not budget actual HUD/footer heights or retained document scroll. The existing HUD guide explicitly records scrolling/Pause as still open at this size. |
| 760×351 or 844×390, visible pads | Existing 140px side gutters and a minimum 188px center row preserve 44px touch controls, but the auto HUD/objective/footer rows plus safe padding can exceed the available height, especially with Large text or wrapped live messages. This path needs its own actual measurement; hidden-pad evidence does not qualify it. |

The shipped Team page has **no explicit minimum supported viewport height, rotation warning, or undersize play gate**. The 188px grid row and 240px arena-width floor are local layout constraints, not a user-facing support contract. Searches of the Team source and current primary layout guidance found no numeric height exclusion that would classify 351px as unsupported. `docs/relay-rescue-plan.md:5–7` permits scrolling in narrower layouts rather than shrinking touch targets and specifies side gutters in short landscape; the newer execution register requires the whole board, critical HUD and both control sets usable together (`:221–223`). `docs/shared-display-preferences.md:178–180` explicitly leaves wider short landscape scrolling/Pause unresolved. Do not turn the 390px historical test size into an unapproved minimum or use a new rotation warning to dismiss the 351px finding.

## Proposed isolated correction

Keep this a **CSS-first Team-only candidate**, based on the eventual committed composition. Initial production ownership is `game/couch/relay-rescue.css`; keep host, input, painter, board geometry, keyboard routing and core unchanged while testing the layout fix.

1. Extend the existing landscape/min-width640/max-height500 live-layout boundary to both hidden and visible pad modes. Give the running app a definite safe-area-adjusted viewport height and a definite remaining arena row. Hide the redundant masthead only in this live compact layout, as the existing touch branch already does. Keep lobby and paused/result reading surfaces independent.
2. Retain all player identity/status/Support text and the objective. Compact vertical padding and gaps and allocate HUD/footer columns before reducing text. Keep Pause at the shared target minimum. The live message must wrap within its assigned row without silently enlarging the page or displacing Pause. Standard/Large and both long objective variants are part of this budget.
3. Keep the actual canvas intrinsically 2:1 and contained by both the available row height and center width; no CSS transform, cropped overflow, stretched arena or gameplay-coordinate change. Hidden pads use the full center width. Shown pads retain the two 140px side gutters and real 44px controls; their roughly 188px control stack is a budget constraint to honor, not a reason to let the grid exceed the viewport. At 351px, first recover space through the common header/padding/gap/HUD allocation. Do not simply remove the 761px condition and keep the old hard-coded 240px subtraction.
4. Recheck retained lobby scroll after the bounded layout is in place. A viewport-sized non-overflowing live document should naturally constrain old scroll. Keep the existing `preventScroll` input focus. Only if a real successor journey still retains offscreen live content should a separate Team-local Start/Resume reveal be proposed, guarded by the current run, foreground and actual canvas focus. Do not apply a global scroll-to-top or alter unrelated menu restoration.

If the required controls and unchanged Large text still cannot fit after that measured allocation, report the exact limiting rectangles before choosing any new minimum-height/warning policy. Such a policy is not present today and is not part of this proposed automatic fix.

## Bounded acceptance

At **760×351 and 844×390**, check explicit controls Hidden and Shown plus Auto's actual resolved mode, Standard/Large and both starter arenas. Enter Start from a genuinely scrolled lobby; capture scroll before/after, canvas/HUD/objective/footer rectangles, both players' controls, target centers and actual viewport/DPR. Require the full 2:1 arena, complete critical labels and Pause within the viewport, no overlap/horizontal overflow and 44px actual targets. Inspect 760/761px neighbors to close the discontinuity.

Exercise keyboard Start → real movement → Pause → Options/Back → explicit Resume, then visible touch controls through their real click/pointer path. Also resize a paused run between the two sizes without changing its identity/time. Root owns native geometry and images; desktop pointer/viewport checks remain distinct from physical touch, hardware, zoom and general device acceptance. CSS static checks alone cannot prove fit. Run complete host files only if a host/focus hunk becomes necessary; do not add tests that merely restate CSS strings.
