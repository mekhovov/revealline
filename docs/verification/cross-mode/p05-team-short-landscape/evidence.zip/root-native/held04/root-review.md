# Team compact landscape — held04 root review

The root exercised the held04 CSS candidate `77f7ffa62432a8d27143bdd5455f15e2df4e70eca04818e17ac1573b5ac75afe` through the real browser UI. This is a narrow presentation checkpoint, not P05 completion or public release acceptance.

All sixteen recorded landscape cases pass: First Connection and Relay Yard; actual 760×351 and 844×390 viewports; Standard and Large text; touch controls shown and hidden. Each case retains the complete 2:1 arena, keeps the canvas within the arena region, and separates HUD, objective, arena and footer. Every visible control passes center and four inset hit checks. Nominal 44px targets measure approximately 43.993px at the browser's 90% zoom; the check tolerates only that subpixel rounding. Document overflow is zero. `geometry-review.json` and the individual case records retain actual measurements rather than requested viewport dimensions.

The root used ordinary Pause, Options, Back and explicit Resume while changing preferences. Both players' direction buttons changed their status to Line exposed; the observed later losses consumed reserves. Both Support buttons produced separate visible cooldowns. These are pointer-driven browser observations, not a claim of a win, physical touch, hardware controller use, or comprehensive Support behavior qualification.

A separate portrait spot check at actual 390×844 retained the complete 2:1 arena. Rotation did not resume the paused game; explicit Resume was required. Portrait is one spot check, not a complete device matrix.

The retained in-app JPG contains compositor bands after viewport changes. It was personally inspected but is not clean image evidence. The separate bounded clean-image check is still required for visual acceptance. Earlier held01–held03 overflow, wrapping and width-cap failures remain retained unchanged.

The post-run ten served-body pins passed in `.cache/worktrees/p05-team-short-landscape/.cache/team-short-landscape/preview-held04/http-after-root-native.json` (SHA-256 `b4b1a3ab2dfb6b4dd2889b3775d7a4c371dca1a98eb8a3df6dda8ba6add3c980`). There were no simulation, collision, input-adapter or historical format changes in this CSS candidate.

## Independent clean-image closure

The root subsequently read the combined R1/R2 review, verified all thirteen originals (12,760,673 bytes) in manifest `4a5f34ea8548d78d8ff63fdf61e0ba8657261d7ec4de1b94cc1ea1b96e90f8ef`, and personally viewed both original PNGs. At 760×351 Relay Yard and 844×390 First Connection, Large text and both pads fit with the complete arena, HUD, objective, footer and Pause. There are no compositor bands. The recorded thirteen controls pass 44px and five-point hit checks. These images concern initial presentation, not later threat or artwork states.

R1's overall status remains FAILED_RETAINED: its observation metadata hit the 4MiB cap during later setup traversal, after the Relay image and ordinary Pause were recorded. R2 used a fresh bounded browser to complete only the missing First Connection case. The failed R1 trace is retained rather than relabelled as a complete successful run. Both browsers closed; each live window was under 0.4 seconds with no steering or abilities. Root's earlier separate pointer observations supply the stated control-action evidence.

Disposition: geometry and these two clean visual cases pass. Approve the narrow CSS candidate for evidence packaging and reviewed internal checkpoint. The integrated phase, other live visual states, real touch/controller hardware, public and offline qualification remain open.
