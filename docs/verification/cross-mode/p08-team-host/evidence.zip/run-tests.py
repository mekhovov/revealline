from pathlib import Path
import sys,json,subprocess,time,hashlib,os
runtime=sys.argv[1]
node=f'/Users/oleksandr.mekhovov/.local/share/mise/installs/node/{runtime}/bin/node'
roots=json.loads(Path('.cache/team-host/qualified-test-inputs.json').read_text())['roots']
if len(sys.argv)>2:roots=sys.argv[2:]
def pins():
 out=[]
 for directory in ['game','authoring']:
  for p in sorted(Path(directory).rglob('*')):
   if p.is_file():
    b=p.read_bytes();out.append(dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
 return out
before=pins();label=os.environ.get('TEAM_TEST_LABEL','whole-node'+runtime.split('.')[0])
folder=Path('.cache/team-host');log=folder/(label+'.log');receipt=folder/(label+'.json')
assert not log.exists() and not receipt.exists()
started=time.monotonic()
with log.open('wb') as output:
 result=subprocess.run([node,'--test','--test-concurrency=1',*roots],stdout=output,stderr=subprocess.STDOUT)
after=pins();raw=log.read_bytes()
data=dict(base='063ff5d650b6e071d2b59e89fa6e9fb5058b3f08',runtime=subprocess.check_output([node,'--version'],text=True).strip(),files=roots,elapsedSeconds=time.monotonic()-started,exitCode=result.returncode,log=dict(path=str(log),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),before=before,after=after,unchanged=before==after)
receipt.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:v for k,v in data.items() if k not in ['before','after']}));print(raw.decode(errors='replace')[-1200:])
sys.exit(result.returncode)
