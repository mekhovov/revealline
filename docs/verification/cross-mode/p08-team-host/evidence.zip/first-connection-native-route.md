# First Connection: source route for native observation

Read-only against held Team host on Git063ff5d. The existing accepted legal-win reference is `game/test/helpers/coop-route-search.mjs:122` (`coverageOpening`) and `:139` (`coverageClear`), exercised by `game/test/coop-balanced-routes.test.mjs:45`. It uses public commands and waypoint feedback. It is a rehearsed simulation proof, not a prior native keyboard clear; the unrelated host self-crossing/loss examples use edited empty imported arenas and must not be used as the built-in completion recipe. No route test or app-state injection was run for this note.

Select **First Connection**, **Full teamwork**, **Gentle**, wait for the picture to be Ready, then Start. Seed17 and full teamwork match the host and reference defaults. The accepted Gentle route uses Boost for both seats; the complete route also passes its existing replay with Support bits removed (`coop-balanced-routes.test.mjs:85–94`). Standard/Expert are not covered by that no-Support simplification. Do not infer that a slower or interrupted native execution will preserve the rehearsed threat timing.

The authored arena is72×36 cells, with Sunflower at(0.5,18.5), Skyline at(71.5,18.5), and a65% coverage goal (`game/coop/recipes.mjs:64–68,150–151`). Canvas is2:1. Convert logical positions using the actual visible canvas content bounds: left + width*x/72, top + height*y/36. Use observed positions/banked safe ground; no fixed wall-clock delays are a proof. Nominal speed is8 cells/s, or12 with Boost, before collision/banking/frame effects.

| Step | Sunflower / Skyline direction | Observable waypoint or bank |
| --- | --- | --- |
|1|W / Up|Up both outer borders to y12.5.|
|2|D / Left|Inward until the first Joint Cut banks the upper field.|
|3|A / Right|Spread on the new safe line to x26.5 / x45.5.|
|4|S / Down|Down those columns until both bank against the bottom safe border (reference y≥34.99).|
|5|W / Up|Up the earned columns to y22.5.|
|6|D / Left|Inward until another central Joint Cut banks.|
|7|A / Right|Spread again to x26.5 / x45.5.|
|8|S / Down|Down the earned columns to y26.5.|
|9|D / Left|Final inward Joint Cut; verify actual completed state and≥65%, not merely a drawn crossing.|

Input source is `game/couch/couch-input.mjs:5–19`: W/A/S/D for Sunflower, arrows for Skyline, LeftShift/RightShift Boost. Verify the native tool can distinguish both Shift codes before relying on boosted timing. Q/Enter are Support. Directions are continuous; releasing a direction key does not serve as the route planner's neutral command. Banking and Pause clear host input. Release held controls and give fresh gestures after a bank or explicit Resume. If using Pause to inspect a waypoint, keep its changed threat timing explicit; Resume is separate and must not be described as a replay of the uninterrupted reference.
