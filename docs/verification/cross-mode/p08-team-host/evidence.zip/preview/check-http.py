from pathlib import Path
import urllib.request,hashlib,json,subprocess,sys
out=Path(__file__).resolve().parent; root=out.parents[2]
binding=json.loads((out/'binding.json').read_text()); rows={x['path']:x for x in binding['overlays']}
paths=list(rows)+['game/coop/core.mjs','game/coop/library.mjs','game/presentation/page.mjs','game/presentation/compiled/runtime.json','game/ui/controller-navigation.mjs','game/ui/menu-appearance.css','game/presentation/compiled/assets/53f1206a11a8791892f5c844c0641529acbc2c09c8d558676d0d801d72113850.png','game/presentation/compiled/assets/d76f309d8385cd5d20fc2fff72b7f3abc19299cccdde767d76dd9f4a4960929d.png']
checks=[]
for path in paths:
 expected=(root/path).read_bytes() if path in rows else subprocess.check_output(['git','show',binding['base']+':'+path],cwd=root)
 if path in rows:assert hashlib.sha256(expected).hexdigest()==rows[path]['sha256']
 with urllib.request.urlopen(f"http://127.0.0.1:{binding['port']}/{path}") as response:
  actual=response.read();headers=dict(response.headers)
 assert actual==expected,path
 checks.append(dict(path=path,bytes=len(actual),sha256=hashlib.sha256(actual).hexdigest(),source='held overlay' if path in rows else binding['base'],contentType=headers.get('Content-Type'),cacheControl=headers.get('Cache-Control')))
result=dict(base=binding['base'],sourceHold=binding['sourceHoldSha256'],bindingSha256=hashlib.sha256((out/'binding.json').read_bytes()).hexdigest(),checks=checks,passAll=True,scope='HTTP body identity only; no application state or native interaction.')
p=out/(sys.argv[1] if len(sys.argv)>1 else 'http-source-before.json');assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),checks=len(checks)))
