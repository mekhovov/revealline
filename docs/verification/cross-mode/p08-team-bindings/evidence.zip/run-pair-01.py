from pathlib import Path
import hashlib,json,subprocess,time,shutil
root=Path.cwd();cache=root/'.cache/team-bindings'
plan=json.loads((cache/'test-plan.json').read_text());hold=json.loads((cache/'source-held-01.json').read_text())
def pin(p):
 b=p.read_bytes();return {'path':str(p.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def inputs():
 return [pin(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink() and '.cache' not in p.relative_to(root).parts and '.git' not in p.relative_to(root).parts]
before=inputs();(cache/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
for r in hold['files']+hold['preservedBaseline']+hold['historicalExactFiles']:assert pin(root/r['path'])==r
assert shutil.disk_usage(root).free>256*1024**2
results=[]
for version in ['22.22.2','20.19.5']:
 node=f'/Users/oleksandr.mekhovov/.local/share/mise/installs/node/{version}/bin/node'
 command=[node,'--test',*plan['files']]; logfile=cache/f'whole-node{version.split(".")[0]}.log'
 start=time.monotonic()
 with logfile.open('wb') as output:done=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 after=inputs();same=before==after;assert same
 result={'node':version,'command':command,'exitCode':done.returncode,'elapsedSeconds':round(time.monotonic()-start,3),'inputsUnchanged':same,'log':pin(logfile)}
 results.append(result);(cache/f'whole-node{version.split(".")[0]}.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result),flush=True);print(logfile.read_text()[-1300:],flush=True)
 if done.returncode:raise SystemExit(done.returncode)
(cache/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
report={'base':hold['base'],'sourceHold':pin(cache/'source-held-01.json'),'sourceFiles':hold['files'],'results':results,'beforeInputs':pin(cache/'inputs-before.json'),'afterInputs':pin(cache/'inputs-after.json'),'inputCount':len(before),'scope':'Nine complete files on both supported Nodes. Actual picture bytes validated; finite decoder and modeled hosts, no native/public or overall P08 acceptance.'}
(cache/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(pin(cache/'verification.json')),flush=True)
