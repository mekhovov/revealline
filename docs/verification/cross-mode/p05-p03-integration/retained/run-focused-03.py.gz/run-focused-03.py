from pathlib import Path
import subprocess,json,hashlib,time,sys,shutil
root=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
node=sys.argv[1];label=sys.argv[2]
files=['display-preferences.test.mjs','display-preferences-host.test.mjs','text-face-host.test.mjs','text-size-host.test.mjs','title-mode-departure-host.test.mjs','title-entry-host.test.mjs','mode-return-host.test.mjs','library-launch-host.test.mjs','coop-host.test.mjs','couch-shell.test.mjs','couch-navigation.test.mjs','modal-navigation.test.mjs','modal-tab-boundary.test.mjs','controller-navigation.test.mjs']
if len(sys.argv)>3: files=sys.argv[3:]
def pins():
 return [{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((root/'game').rglob('*')) if p.is_file()]
assert shutil.disk_usage(root).free>256*1024*1024
held=json.loads((out/'source-held-03.json').read_text())
for r in held['files']:
 b=(root/r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],r['path']
before=pins();(out/(label+'-inputs-before.json')).write_text(json.dumps(before,indent=2)+'\n')
args=[node,'--test','--test-concurrency=1','--test-reporter=tap',*['game/test/'+f for f in files]]
start=time.monotonic()
with (out/(label+'.log')).open('wb') as log:
 try: result=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=360);code=result.returncode
 except subprocess.TimeoutExpired: code=124
elapsed=time.monotonic()-start;after=pins();(out/(label+'-inputs-after.json')).write_text(json.dumps(after,indent=2)+'\n')
receipt={'base':held['base'],'sourceHoldSha256':hashlib.sha256((out/'source-held-03.json').read_bytes()).hexdigest(),'command':args,'nodeVersion':subprocess.check_output([node,'--version'],text=True).strip(),'exitCode':code,'seconds':elapsed,'inputsUnchanged':before==after,'files':files,'log':{'path':label+'.log','bytes':(out/(label+'.log')).stat().st_size,'sha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()}}
(out/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print('\n'.join((out/(label+'.log')).read_text().splitlines()[-10:]));sys.exit(code or (0 if before==after else 2))
