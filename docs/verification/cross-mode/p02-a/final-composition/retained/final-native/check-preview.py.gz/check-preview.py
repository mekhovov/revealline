"""After root-authorized launch only: exact small local HTTP pins, no body retention."""
from pathlib import Path
import argparse, hashlib, json, mimetypes, subprocess, urllib.request
ROOT=Path(__file__).resolve().parents[2];CACHE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--binding',required=True);p.add_argument('--out',required=True);a=p.parse_args()
source=CACHE/a.binding;out=CACHE/a.out
if source.parent!=CACHE or out.parent!=CACHE or out.exists():raise RuntimeError('Direct cache paths and fresh output required')
binding_bytes=source.read_bytes();binding=json.loads(binding_bytes)
config_path=CACHE/binding['config']['path'];config_bytes=config_path.read_bytes()
if hashlib.sha256(config_bytes).hexdigest()!=binding['config']['sha256']:raise RuntimeError('Config changed')
config=json.loads(config_bytes)
if binding['head']!=config['head'] or binding['tree']!=config['tree'] or binding['overlays']:
    raise RuntimeError('Wrong final Git identity')
if hashlib.sha256((CACHE/'serve-preview.py').read_bytes()).hexdigest()!=binding['helperSha256']:
    raise RuntimeError('Preview helper changed')
base='http://127.0.0.1:'+str(binding['port'])
if binding['url']!=base+'/game/':raise RuntimeError('Local preview origin differs')
rows=[];error=None
try:
    for name in config['httpCheckPaths']:
        if name.startswith('/') or '..' in name.split('/'):raise RuntimeError('Invalid check path')
        expected=subprocess.check_output(['git','show',binding['head']+':'+name],cwd=ROOT)
        if len(expected)>1024*1024:raise RuntimeError('Unexpected large HTTP check body')
        url=base+'/'+name
        with urllib.request.urlopen(url,timeout=20) as response:
            body=response.read(1024*1024+1)
            row={'path':name,'url':url,'status':response.status,'finalURL':response.geturl(),
                 'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),
                 'mime':response.headers.get_content_type()}
        expected_mime='text/javascript' if name.endswith('.mjs') else mimetypes.guess_type(name)[0] or 'application/octet-stream'
        row['matchesGit']=body==expected and row['status']==200 and row['finalURL']==url and row['mime']==expected_mime
        rows.append(row)
        if not row['matchesGit']:raise RuntimeError('HTTP/Git mismatch: '+name)
except BaseException as exc:
    error=type(exc).__name__+': '+str(exc)
finally:
    with out.open('x') as stream:
        json.dump({'head':binding['head'],'tree':binding['tree'],'bindingSha256':hashlib.sha256(binding_bytes).hexdigest(),
                   'mode':binding['mode'],'paths':rows,'error':error,'passed':error is None and len(rows)==len(config['httpCheckPaths']),
                   'scope':'Only exact small local source/JSON HTTP pins; no native actions or public audit. No HTTP bodies retained.'},stream,indent=2);stream.write('\n')
if error:raise RuntimeError(error)
print(json.dumps({'passed':True,'paths':len(rows),'out':str(out)}))
