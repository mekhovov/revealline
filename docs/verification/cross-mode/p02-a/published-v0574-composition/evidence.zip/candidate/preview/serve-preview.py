from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlsplit
from collections import OrderedDict
import subprocess, mimetypes, hashlib, json, os, threading, re, shutil, argparse, time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--config', required=True)
parser.add_argument('--binding', required=True)
args = parser.parse_args()
config_path = OUT / args.config
binding_path = OUT / args.binding
if config_path.parent != OUT or binding_path.parent != OUT or binding_path.exists():
    raise RuntimeError('Use direct owned configuration and a fresh binding name')
config_bytes = config_path.read_bytes()
config = json.loads(config_bytes)
BASE = config.get('head')
if not isinstance(BASE, str) or not re.fullmatch('[0-9a-f]{40}', BASE):
    raise RuntimeError('Final merged head remains unbound')
if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() != BASE:
    raise RuntimeError('Final head differs at preview launch')
LIMIT = 64 * 1024 * 1024
if shutil.disk_usage(OUT).free < 256 * 1024 * 1024:
    raise RuntimeError('Insufficient metadata reserve')
tree = subprocess.check_output(['git', 'rev-parse', BASE + '^{tree}'], cwd=ROOT, text=True).strip()
if tree != config.get('tree'):
    raise RuntimeError('Final tree binding differs')
index_bytes = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT)
if hashlib.sha256(index_bytes).hexdigest() != config['indexEntriesSHA256']:
    raise RuntimeError('Candidate index snapshot changed')
if subprocess.check_output(['git', 'rev-parse', 'MERGE_HEAD'], cwd=ROOT, text=True).strip() != config['mergeHead']:
    raise RuntimeError('Incoming candidate source changed')
regular = {}
for line in index_bytes.split(b'\0'):
    if not line:
        continue
    meta, name = line.split(b'\t', 1)
    mode, oid, stage = meta.decode().split()
    if stage != '0':
        raise RuntimeError('Unresolved candidate index entry')
    name = name.decode()
    if mode in ('100644', '100755') and name.startswith(('game/', 'authoring/', 'docs/')):
        regular[name] = oid
for name, expected in config['metadata'].items():
    if name not in ('.cache/p02a-final-v0574/source-held-01.json', '.cache/p02a-final-v0574/generated.json'):
        raise RuntimeError('Unexpected candidate metadata')
    body = (ROOT / name).read_bytes()
    if len(body) != expected['bytes'] or hashlib.sha256(body).hexdigest() != expected['sha256']:
        raise RuntimeError('Candidate metadata changed')
for row in config['httpChecks']:
    if regular.get(row['path']) != row['blob']:
        raise RuntimeError('Candidate check body is not the staged blob')
    body = subprocess.check_output(['git', 'cat-file', 'blob', row['blob']], cwd=ROOT)
    if len(body) != row['bytes'] or hashlib.sha256(body).hexdigest() != row['sha256']:
        raise RuntimeError('Candidate body identity changed')
if subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=ROOT) != index_bytes:
    raise RuntimeError('Candidate index changed during admission')
cache = OrderedDict()
cache_bytes = 0
cache_lock = threading.Lock()
requests = threading.BoundedSemaphore(4)

def git_body(name):
    global cache_bytes
    with cache_lock:
        if name in cache:
            body = cache.pop(name)
            cache[name] = body
            return body
        oid = regular[name]
        size = int(subprocess.check_output(['git', 'cat-file', '-s', oid], cwd=ROOT, stderr=subprocess.DEVNULL))
        if size > LIMIT:
            raise ValueError('Per-file limit')
        while cache and cache_bytes + size > LIMIT:
            _, old = cache.popitem(last=False)
            cache_bytes -= len(old)
        body = subprocess.check_output(['git', 'cat-file', 'blob', oid], cwd=ROOT, stderr=subprocess.DEVNULL)
        if len(body) != size:
            raise ValueError('Git body size mismatch')
        cache[name] = body
        cache_bytes += size
        return body

class Handler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.serve(False)
    def do_GET(self):
        self.serve(True)
    def serve(self, send_body):
        with requests:
            if self.headers.get('Host') != '127.0.0.1:' + str(self.server.server_port):
                self.send_error(403)
                return
            name = unquote(urlsplit(self.path).path).lstrip('/')
            if not name:
                self.send_response(302)
                self.send_header('Location', '/game/')
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            if name.endswith('/'):
                name += 'index.html'
            if '\\' in name or any(ord(ch) < 32 for ch in name) or any(part in ('.', '..', '.git', 'node_modules') for part in name.split('/')) or name not in regular:
                self.send_error(404)
                return
            try:
                body = git_body(name)
                length = len(body)
                start, end, status = 0, length - 1, 200
                requested = self.headers.get('Range')
                if requested:
                    match = re.fullmatch(r'bytes=(\d*)-(\d*)', requested)
                    if not match or not any(match.groups()):
                        raise ValueError('Invalid range')
                    low, high = match.groups()
                    if low:
                        start = int(low)
                        end = min(int(high), length - 1) if high else length - 1
                    else:
                        start = max(0, length - int(high))
                    if start > end or start >= length:
                        self.send_response(416)
                        self.send_header('Content-Range', 'bytes */' + str(length))
                        self.send_header('Content-Length', '0')
                        self.end_headers()
                        return
                    status = 206
                kind = 'text/javascript' if name.endswith('.mjs') else mimetypes.guess_type(name)[0] or 'application/octet-stream'
                self.send_response(status)
                self.send_header('Content-Type', kind)
                self.send_header('Content-Length', str(end - start + 1))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Accept-Ranges', 'bytes')
                if status == 206:
                    self.send_header('Content-Range', f'bytes {start}-{end}/{length}')
                self.end_headers()
                if send_body:
                    for offset in range(start, end + 1, 65536):
                        self.wfile.write(memoryview(body)[offset:min(offset + 65536, end + 1)])
            except (KeyError, ValueError, subprocess.CalledProcessError):
                self.send_error(404)
            except (BrokenPipeError, ConnectionResetError):
                pass
    def log_message(self, format, *args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
server.daemon_threads = True
binding = {'head': BASE, 'tree': tree, 'overlays': [],
           'pid': os.getpid(), 'port': server.server_port,
           'url': f'http://127.0.0.1:{server.server_port}/game/',
           'gitBlobCacheBytes': LIMIT, 'maxConcurrentRequests': 4,
           'config': {'path': args.config, 'bytes': len(config_bytes),
                      'sha256': hashlib.sha256(config_bytes).hexdigest()},
           'mode': 'normal', 'delay': None,
           'mergeHead': config['mergeHead'], 'indexEntriesSHA256': config['indexEntriesSHA256'],
           'helperSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'scope': 'Uncommitted candidate: every served byte is an immutable regular Git blob from the frozen stage-0 index snapshot. Head/tree identify the cbc baseline, not a final qualified commit. All regenerated ledger/output bodies are admitted by exact pins. No live source reads, source copies, app state, timing fixture or public acceptance. LRU bounds stored Git blobs, not total process RSS.'}
with binding_path.open('x') as file:
    json.dump(binding, file, indent=2)
    file.write('\n')
print(json.dumps(binding), flush=True)
try:
    server.serve_forever()
finally:
    server.server_close()
