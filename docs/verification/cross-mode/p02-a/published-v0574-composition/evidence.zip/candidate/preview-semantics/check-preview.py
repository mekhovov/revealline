"""Verify the immutable local candidate origin; no native action or retained bodies."""
from pathlib import Path
import argparse
import hashlib
import json
import mimetypes
import subprocess
import urllib.request

ROOT = Path(__file__).resolve().parents[3]
CACHE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--out', required=True)
args = parser.parse_args()
out = CACHE / args.out
if out.parent != CACHE or out.exists():
    raise RuntimeError('Fresh direct output required')
sha = lambda body: hashlib.sha256(body).hexdigest()
binding_bytes = (CACHE / 'binding.json').read_bytes()
binding = json.loads(binding_bytes)
config_bytes = (CACHE / binding['config']['path']).read_bytes()
if sha(config_bytes) != binding['config']['sha256']:
    raise RuntimeError('Changed configuration')
config = json.loads(config_bytes)
for field in ['head', 'tree', 'mergeHead', 'indexEntriesSHA256']:
    if binding[field] != config[field]:
        raise RuntimeError('Source binding mismatch')
if binding['mode'] != 'normal' or binding['overlays'] or binding['delay'] is not None:
    raise RuntimeError('Unexpected preview mode')
if sha((CACHE / 'serve-preview.py').read_bytes()) != binding['helperSha256']:
    raise RuntimeError('Changed helper')
origin = 'http://127.0.0.1:' + str(binding['port'])
if binding['url'] != origin + '/game/':
    raise RuntimeError('Unexpected origin')
rows = []
error = None
try:
    for pin in config['httpChecks']:
        name = pin['path']
        if name.startswith('/') or '..' in name.split('/') or pin['bytes'] > 8 * 1024**2:
            raise RuntimeError('Unbounded check')
        expected = subprocess.check_output(['git', 'cat-file', 'blob', pin['blob']], cwd=ROOT)
        if len(expected) != pin['bytes'] or sha(expected) != pin['sha256']:
            raise RuntimeError('Expected Git body changed')
        url = origin + '/' + name
        with urllib.request.urlopen(url, timeout=30) as response:
            body = response.read(8 * 1024**2 + 1)
            row = {'path': name, 'blob': pin['blob'], 'url': url,
                   'status': response.status, 'finalURL': response.geturl(),
                   'bytes': len(body), 'sha256': sha(body),
                   'mime': response.headers.get_content_type()}
        mime = 'text/javascript' if name.endswith('.mjs') else mimetypes.guess_type(name)[0] or 'application/octet-stream'
        row['matchesFrozenGit'] = body == expected and row['status'] == 200 and row['finalURL'] == url and row['mime'] == mime
        rows.append(row)
        if not row['matchesFrozenGit']:
            raise RuntimeError('HTTP body mismatch: ' + name)
except BaseException as exc:
    error = type(exc).__name__ + ': ' + str(exc)
finally:
    with out.open('x') as output:
        json.dump({'scope': '147 exact local HTTP/Git body pins; no native/public acceptance and no retained HTTP bodies',
                   'head': config['head'], 'mergeHead': config['mergeHead'],
                   'indexEntriesSHA256': config['indexEntriesSHA256'],
                   'bindingSHA256': sha(binding_bytes), 'paths': rows, 'error': error,
                   'passed': error is None and len(rows) == len(config['httpChecks'])}, output, indent=2)
        output.write('\n')
if error:
    raise RuntimeError(error)
print(json.dumps({'passed': True, 'paths': len(rows), 'out': str(out)}))
