import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time

ROOT = Path.cwd()
CACHE = ROOT / '.cache/p02a-final-v0574'
CACHE = ROOT / '.cache/p02a-final-v0574/aria-successor'
HOLD = json.loads((CACHE / 'source-held-04.json').read_text())
PRIOR = json.loads((CACHE / 'source-held-02.json').read_text())
TESTS = HOLD['proposedWholeTests']
assert len(TESTS) == len(set(TESTS)) == 2


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pins():
    rows = []
    for name in subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0'):
        file = ROOT / name
        if name and file.is_file():
            body = file.read_bytes()
            rows.append({'path': name, 'bytes': len(body), 'sha256': sha(body)})
    return rows


def write_new(name, value):
    with (CACHE / name).open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')


def capacity():
    free = shutil.disk_usage(ROOT).free
    used = int(subprocess.check_output(['du', '-sk', str(ROOT)]).split()[0]) * 1024
    return free, used


for row in HOLD['files']:
    body = (ROOT / row['path']).read_bytes()
    assert len(body) == row['bytes'] and sha(body) == row['sha256'], row['path']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip() == PRIOR['head']
assert subprocess.check_output(['git', 'rev-parse', 'MERGE_HEAD']).decode().strip() == PRIOR['mergeHead']
baseline = pins()
write_new('status-inputs-prepared.json', baseline)
records = []
for version in ['22.22.2', '20.19.5']:
    free, used = capacity()
    assert free >= 288 * 1024**2 and used < 100 * 1024**2, (free, used)
    prefix = 'status-node' + version.split('.')[0]
    before = pins()
    assert before == baseline
    write_new(prefix + '-before.json', before)
    node = '/Users/oleksandr.mekhovov/.local/share/mise/installs/node/' + version + '/bin/node'
    argv = [node, '--test', '--test-concurrency=1', *TESTS]
    print(json.dumps({'starting': prefix, 'files': len(TESTS), 'freeBytes': free}), flush=True)
    start = time.monotonic()
    stopped = None
    with (CACHE / (prefix + '.log')).open('xb') as output:
        child = subprocess.Popen(argv, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        while child.poll() is None:
            time.sleep(5)
            free, used = capacity()
            if free < 256 * 1024**2 or used >= 100 * 1024**2:
                stopped = {'reason': 'capacity reserve', 'freeBytes': free, 'worktreeBytes': used}
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                break
    after = pins()
    write_new(prefix + '-after.json', after)
    raw = (CACHE / (prefix + '.log')).read_bytes()
    summary = dict(re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$', raw.decode(errors='replace'), re.M))
    record = {
        'node': version, 'argv': argv, 'exitCode': child.returncode,
        'seconds': time.monotonic() - start, 'inputCount': len(before),
        'inputBytes': sum(row['bytes'] for row in before), 'inputsUnchanged': after == before == baseline,
        'logBytes': len(raw), 'logSHA256': sha(raw), 'summary': summary, 'stopped': stopped,
        'scope': 'Two complete affected host files on held status-renderer successor; no full CI/native/public acceptance',
    }
    write_new(prefix + '.json', record)
    records.append(record)
    print(json.dumps(record), flush=True)
    if child.returncode or not record['inputsUnchanged']:
        break
write_new('status-execution.json', {'sourceHoldSHA256': sha((CACHE / 'source-held-04.json').read_bytes()), 'results': records})
