import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { importThemeBundle } from '../../game/presentation/bundle.mjs';
import { canonicalJSON } from '../../game/data-json.mjs';

const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const raw = await fs.readFile(new URL('../p02a-history-model-856/prior-p01.rltheme', import.meta.url));
assert.equal(raw.length, 6808841);
assert.equal(sha(raw), 'f0e8f98c63b6871a6c3ab60eaef7d265912e370db3522b336cc60a408ac92b4a');
const prior = await importThemeBundle(new Blob([raw]), { decodeImage: null });
const metadata = structuredClone(prior.document);
const groups = {};
for (const group of ['slots', 'assets', 'themes', 'collections']) {
  groups[group] = { count: metadata[group].length, sha256: sha(canonicalJSON(metadata[group])) };
  delete metadata[group];
}
const payloads = [];
for (const [hash, blob] of prior.assets) {
  const bytes = Buffer.from(await blob.arrayBuffer());
  assert.equal(sha(bytes), hash);
  payloads.push([hash, bytes.length]);
}
payloads.sort(([a], [b]) => a.localeCompare(b));
const oracle = {
  format: 'revealline-production-history-oracle.v1',
  provenance: {
    source: '856850ce8d4597c1fb6e8bb28ddb8a63db337a8c',
    tree: '4cd7f24680af174ea35773d28e07e54e5f39e01f',
    tag: 'v0.57.4',
    path: 'authoring/library/fpv-field-kit/production.rltheme',
    bytes: raw.length,
    sha256: sha(raw),
    scope: 'Immutable published source oracle; public P01 acceptance is separate.',
  },
  metadata,
  groups,
  payloads: { count: payloads.length, sha256: sha(canonicalJSON(payloads)) },
};
const output = new URL('../../game/test/fixtures/production-p01-v0574.json', import.meta.url);
await fs.mkdir(new URL('./', output), { recursive: true });
await fs.writeFile(output, JSON.stringify(oracle, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(oracle, null, 2));
