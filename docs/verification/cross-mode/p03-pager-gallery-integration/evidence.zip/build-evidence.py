from pathlib import Path
import argparse
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
DEST = ROOT / 'docs/verification/cross-mode/p03-pager-gallery-integration'
parser = argparse.ArgumentParser()
parser.add_argument('--native-review', required=True)
args = parser.parse_args()
review = OUT / args.native_review
if review.parent != OUT / 'native-root' or not review.is_file():
    raise RuntimeError('A closed root native review must be supplied')
if shutil.disk_usage(ROOT).free < 256 * 1024 * 1024:
    raise RuntimeError('Insufficient reserve')

names = [
    'prepare.py', 'admission.json', 'source-held-01.json', 'source-held-01.diff',
    'source-held-02.json', 'source-held-03.json', 'library-vs-gallery.diff',
    'library-vs-pager.diff', 'run-whole-pair.py', 'run-whole-pair-02.py',
    'diagnostic-01-verification.json', 'modal-navigation-before.mjs',
    'modal-navigation-before.json', 'fixture-successor.diff',
    'modal-close-successor-node22.log', 'verification-tests-final.json',
    'serve-composed.py', 'preview-config.json', 'preview-binding.json',
    'preview-preparation.json', 'preview-helper-reuse.diff', 'http-pins-before.json',
    'http-pins-after.json', 'generate-native-library.mjs', 'pager-library-fixture.json',
    'native-fixture-provenance.json', 'fixture-reuse.json', 'status-snapshot.diff',
    'verification-native-final.json', 'build-evidence.py',
]
paths = [OUT / name for name in names]
for folder in ['conflicts', 'whole-pair-01', 'whole-pair-02', 'native-root']:
    paths.extend(path for path in sorted((OUT / folder).rglob('*')) if path.is_file())
paths = sorted(set(paths))
if len(paths) > 200:
    raise RuntimeError('Finite evidence member bound exceeded')
total = sum(path.stat().st_size for path in paths)
if total > 20 * 1024 * 1024 or shutil.disk_usage(ROOT).free < 256 * 1024 * 1024 + total:
    raise RuntimeError('Finite evidence/reserve byte bound exceeded')

def sha(body):
    return hashlib.sha256(body).hexdigest()

DEST.mkdir(parents=True, exist_ok=True)
archive = DEST / 'evidence.zip'
rows = []
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as store:
    for source in paths:
        if source.is_symlink() or not source.is_file():
            raise RuntimeError('Invalid evidence source: ' + str(source))
        body = source.read_bytes()
        if len(body) > 4 * 1024 * 1024:
            raise RuntimeError('Per-member evidence bound exceeded')
        member = str(source.relative_to(OUT))
        item = zipfile.ZipInfo(member, date_time=(2026, 9, 15, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        item.external_attr = 0o100644 << 16
        store.writestr(item, body)
        rows.append({'source': str(source.relative_to(ROOT)), 'member': member,
                     'bytes': len(body), 'sha256': sha(body)})
with zipfile.ZipFile(archive) as store:
    if store.testzip() is not None or len(store.namelist()) != len(rows):
        raise RuntimeError('Archive integrity failure')
    for row in rows:
        body = store.read(row['member'])
        if body != (ROOT / row['source']).read_bytes() or sha(body) != row['sha256']:
            raise RuntimeError('Evidence source changed: ' + row['source'])
archive_body = archive.read_bytes()
record = {'scope': 'Lossless originals for the finite ec288/row/pager/gallery composition. '
                   'Predecessor interruption, fixture correction and final test/native records remain distinct. '
                   'No broad phase, physical-device or public acceptance.',
          'archive': {'path': 'evidence.zip', 'bytes': len(archive_body), 'sha256': sha(archive_body)},
          'memberCount': len(rows), 'decodedBytes': sum(row['bytes'] for row in rows),
          'files': rows}
(DEST / 'evidence.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'files'}))
