from pathlib import Path
import hashlib,json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[2]
DEST=ROOT/'.cache/worktrees/p03-pager-gallery-integration'
BASE='ec288a4e96d13e5a8fda51dff759838af96b46fe'
BRANCH='codex/p03-pager-gallery-integration'
COMMITS=['87f0f49c84e2f92bceb24b0a317d5e6c79e64ac6','0368f58f8b866d9ae9e716536e7b914d4a6af818','7fedeef11991ed7be19bdb1d5841f6aed00dfb09']
SOURCE=ROOT/'.cache/worktrees/p03-gallery-return/.cache/gallery-return/admission.json'
FLOOR=256*1024*1024
CAP=100*1024*1024

def git(*args,cwd=ROOT): return subprocess.check_output(['git','--no-optional-locks',*args],cwd=cwd)
def run(*args,cwd=ROOT,data=None):subprocess.run(['git',*args],cwd=cwd,input=data,check=True)
def pin(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
assert not DEST.exists()
assert shutil.disk_usage(ROOT).free>=FLOOR+CAP
assert git('config','--get','extensions.worktreeConfig').strip()==b'true'
assert subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+BRANCH],cwd=ROOT).returncode==1
paths={row['path'] for row in json.loads(SOURCE.read_text())['paths']}
for commit in COMMITS:
 paths.update(git('diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines())
paths.add('authoring/prompts/navigation-qualification.md')
base_rows={}
for item in git('ls-tree','-rlz',BASE).split(b'\0'):
 if not item:continue
 meta,name=item.split(b'\t'); mode,kind,oid,size=meta.decode().split();name=name.decode()
 if name in paths:
  assert mode=='100644' and kind=='blob',name
  base_rows[name]={'path':name,'mode':mode,'gitBlob':oid,'bytes':int(size)}
# Missing inputs are introduced by the three explicitly admitted commits.
incoming={}
for commit in COMMITS:
 for name in paths-base_rows.keys():
  out=git('ls-tree','-l',commit,'--',name).decode().strip()
  if out:
   meta,actual=out.split('\t');mode,kind,oid,size=meta.split();assert actual==name and mode=='100644' and kind=='blob'
   incoming[name]={'path':name,'gitBlob':oid,'bytes':int(size),'sourceCommit':commit}
assert paths==base_rows.keys()|incoming.keys()
assert sum(x['bytes'] for x in base_rows.values())+sum(x['bytes'] for x in incoming.values())<CAP-8*1024*1024
run('worktree','add','--no-checkout','-b',BRANCH,str(DEST),BASE)
run('config','--worktree','core.sparseCheckout','true',cwd=DEST)
run('config','--worktree','core.sparseCheckoutCone','false',cwd=DEST)
info=Path(git('rev-parse','--git-path','info/sparse-checkout',cwd=DEST).decode().strip())
if not info.is_absolute():info=DEST/info
info.parent.mkdir(parents=True,exist_ok=True);info.write_text('\n'.join('/'+name for name in sorted(paths))+'\n')
run('-c','core.sparseCheckout=false','read-tree',BASE,cwd=DEST)
all_names=git('ls-files','-z',cwd=DEST);assert len(all_names)<8*1024*1024
run('update-index','--skip-worktree','-z','--stdin',cwd=DEST,data=all_names)
selected=b''.join(name.encode()+b'\0' for name in sorted(base_rows))
run('update-index','--no-skip-worktree','-z','--stdin',cwd=DEST,data=selected)
run('checkout-index','--force','-z','--stdin',cwd=DEST,data=selected)
for name,row in base_rows.items():
 body=(DEST/name).read_bytes();assert len(body)==row['bytes'];assert git('hash-object','--stdin',cwd=DEST).strip() if False else True
 assert hashlib.sha1(f'blob {len(body)}\0'.encode()+body).hexdigest()==row['gitBlob']
 row['sha256']=hashlib.sha256(body).hexdigest()
(DEST/'node_modules').symlink_to(ROOT/'node_modules',target_is_directory=True)
OUT=DEST/'.cache/pager-gallery-integration';OUT.mkdir(parents=True)
receipt={'base':BASE,'tree':git('rev-parse',BASE+'^{tree}').decode().strip(),'branch':BRANCH,'worktree':str(DEST),'sourceAdmission':{'path':str(SOURCE),**pin(SOURCE.read_bytes())},'method':'Metadata-only index; worktree-scoped sparse flags/patterns and finite checkout-index. No common config or other worktree edits.','paths':list(sorted(base_rows.values(),key=lambda x:x['path'])),'pendingIncoming':list(sorted(incoming.values(),key=lambda x:x['path'])),'bytes':sum(x['bytes'] for x in base_rows.values()),'plannedIncomingBytes':sum(x['bytes'] for x in incoming.values()),'cap':CAP,'floor':FLOOR,'afterFree':shutil.disk_usage(ROOT).free}
(OUT/'admission.json').write_text(json.dumps(receipt,indent=2)+'\n');(OUT/'prepare.py').write_bytes(Path(__file__).read_bytes())
assert not git('diff','--name-only',cwd=DEST);assert not git('diff','--cached','--name-only',cwd=DEST)
print(json.dumps({k:v for k,v in receipt.items() if k not in ('paths','pendingIncoming')}));print('Physical paths',len(base_rows),'planned incoming',len(incoming))
