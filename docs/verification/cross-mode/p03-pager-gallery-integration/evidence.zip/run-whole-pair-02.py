from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
HEAD = 'ec288a4e96d13e5a8fda51dff759838af96b46fe'
TREE = '5c75a470429dff36be6048d0ded38d5225d3e5a4'
TESTS = ['game/test/library-pager-host.test.mjs', 'game/test/gallery-return-host.test.mjs', 'game/test/gallery-focus.test.mjs', 'game/test/collection-context-host.test.mjs', 'game/test/main-menu-collection-host.test.mjs', 'game/test/gallery-difficulty.test.mjs', 'game/test/difficulty-host.test.mjs', 'game/test/library-row-focus-host.test.mjs', 'game/test/operation-focus-host.test.mjs', 'game/test/modal-navigation.test.mjs']
FLOOR = 256 * 1024 * 1024


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=ROOT)


def pin(path):
    body = path.read_bytes()
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def inventory():
    paths = []
    for directory in ['game', 'authoring']:
        for path in sorted((ROOT / directory).rglob('*')):
            if path.is_symlink():
                raise RuntimeError('Unexpected linked participating input: ' + str(path))
            if path.is_file() and (directory == 'game' or path.suffix in {'.mjs', '.js', '.json'}):
                paths.append(path)
    paths.append(ROOT / 'package.json')
    return [{'path': str(path.relative_to(ROOT)), **pin(path)} for path in paths]


def guard(expected_inputs, canonical_index, runner, held_pin, staged_tree):
    if shutil.disk_usage(ROOT).free < FLOOR:
        raise RuntimeError('Insufficient metadata/test reserve')
    if git('rev-parse', 'HEAD').decode().strip() != HEAD or git('rev-parse', 'HEAD^{tree}').decode().strip() != TREE:
        raise RuntimeError('Base source authority changed')
    if git('ls-files', '--stage', '-z') != canonical_index:
        raise RuntimeError('Index content changed')
    if git('write-tree').decode().strip() != staged_tree or git('diff', '--name-only'):
        raise RuntimeError('Composed index or unstaged source changed')
    if pin(OUT / 'source-held-02.json') != held_pin:
        raise RuntimeError('Source hold changed')
    if pin(Path(__file__)) != runner:
        raise RuntimeError('Runner source changed')
    if inventory() != expected_inputs:
        raise RuntimeError('Participating physical inputs changed')


def main():
    if os.environ.get('NODE_OPTIONS'):
        raise RuntimeError('Unexpected NODE_OPTIONS')
    held_path = OUT / 'source-held-02.json'
    held = json.loads(held_path.read_text())
    held_pin = pin(held_path)
    if held['base'] != HEAD:
        raise RuntimeError('Wrong pager source hold')
    for row in held['paths']:
        if pin(ROOT / row['path']) != {'bytes': row['bytes'], 'sha256': row['sha256']}:
            raise RuntimeError('Held input differs: ' + row['path'])
    for name in TESTS:
        if not (ROOT / name).is_file():
            raise RuntimeError('Missing complete test file: ' + name)
    run = OUT / 'whole-pair-02'
    run.mkdir(exist_ok=False)
    before = inventory()
    canonical_index = git('ls-files', '--stage', '-z')
    if len(canonical_index) > 8 * 1024 * 1024:
        raise RuntimeError('Canonical index exceeds metadata bound')
    (run / 'index-stage-before.bin').write_bytes(canonical_index)
    runner = pin(Path(__file__))
    runtimes = [Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node') / version / 'bin/node' for version in ['22.22.2', '20.19.5']]
    authority = {
        'head': HEAD,
        'tree': TREE,
        'held': {'path': str(held_path.relative_to(ROOT)), **held_pin},
        'stagedTree': held['stagedTree'],
        'runner': {'path': str(Path(__file__).relative_to(ROOT)), **runner},
        'runtimes': [{'path': str(node), 'version': subprocess.check_output([str(node), '--version'], text=True).strip(), **pin(node)} for node in runtimes],
        'testFiles': TESTS,
        'indexStageBytes': len(canonical_index),
        'indexStageSha256': hashlib.sha256(canonical_index).hexdigest(),
        'scope': 'Ten complete affected files on held ec288/row/pager/gallery composition; no full build, native, device or phase qualification inferred.',
    }
    write(run / 'authority.json', authority)
    write(run / 'inputs-before.json', before)
    results = []
    for node, runtime in zip(runtimes, authority['runtimes']):
        guard(before, canonical_index, runner, held_pin, held['stagedTree'])
        if pin(node) != {'bytes': runtime['bytes'], 'sha256': runtime['sha256']}:
            raise RuntimeError('Runtime changed')
        label = 'node' + runtime['version'].split('.')[0].lstrip('v')
        command = [str(node), '--test', '--test-concurrency=2', '--test-reporter=tap', *TESTS]
        start = time.monotonic()
        log = run / (label + '.log')
        with log.open('xb') as stream:
            try:
                code = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=480).returncode
            except subprocess.TimeoutExpired:
                code = 124
        after = inventory()
        write(run / (label + '-inputs-after.json'), after)
        record = {'command': command, 'exitCode': code, 'elapsedSeconds': time.monotonic() - start, 'inputsUnchanged': before == after, 'log': {'path': str(log.relative_to(ROOT)), **pin(log)}}
        write(run / (label + '.json'), record)
        results.append(record)
        print(json.dumps(record), flush=True)
        print('\n'.join(log.read_text().splitlines()[-10:]), flush=True)
        guard(before, canonical_index, runner, held_pin, held['stagedTree'])
        if code:
            break
    write(run / 'completion.json', {'authority': pin(run / 'authority.json'), 'results': results, 'wholePairPassed': len(results) == 2 and all(result['exitCode'] == 0 and result['inputsUnchanged'] for result in results)})


if __name__ == '__main__':
    main()
