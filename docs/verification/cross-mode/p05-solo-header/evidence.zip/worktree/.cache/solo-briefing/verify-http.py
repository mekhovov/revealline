from pathlib import Path
import urllib.request,subprocess,json,hashlib,time,sys
folder=Path('.cache/solo-briefing');preview=sys.argv[1];label=sys.argv[2];p=folder/preview;binding=json.loads((p/'binding.json').read_text());base=binding['base'];overlay={r['path']:r for r in binding['overlays']};sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['game/index.html','game/app.mjs','game/ui/game-shell.mjs','game/ui/device-controls.css','game/ui/game-shell.css','game/ui/pixel-theme.css','game/ui/field-kit-components.css','game/ui/field-kit-tokens.css','game/ui/field-kit-compiled.css','game/style.css','game/ui/field-kit-surfaces.css','game/presentation/host.mjs','game/presentation/compiled/runtime.json','game/presentation/compiled/theme.css','game/ui/field-kit-fonts.css'];rows=[]
for name in paths:
 expected=Path(name).read_bytes() if name in overlay else subprocess.check_output(['git','show',base+':'+name])
 if name in overlay:assert sha(expected)==overlay[name]['sha256'] and len(expected)==overlay[name]['bytes']
 with urllib.request.urlopen(f'http://127.0.0.1:{binding["port"]}/{name}',timeout=30) as response:body=response.read();status=response.status
 assert status==200 and body==expected,name
 rows.append({'path':name,'bytes':len(body),'sha256':sha(body),'authority':'held CSS overlay' if name in overlay else 'exact Git '+base,'httpExact':True})
receipt={'base':base,'sourceHold':binding['sourceHoldSha256'],'atUnix':time.time(),'binding':{'path':str(p/'binding.json'),'bytes':len((p/'binding.json').read_bytes()),'sha256':sha((p/'binding.json').read_bytes())},'helper':{'path':str(p/'serve.py'),'bytes':len((p/'serve.py').read_bytes()),'sha256':sha((p/'serve.py').read_bytes())},'rows':rows,'scope':'Fifteen exact source/style/compiled-input HTTP comparisons; zero native input or rendered-geometry claim.'};dest=folder/f'http-{preview}-{label}.json';assert not dest.exists();dest.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(dest),'sha256':sha(dest.read_bytes()),'rows':len(rows),'url':binding['url']}))
