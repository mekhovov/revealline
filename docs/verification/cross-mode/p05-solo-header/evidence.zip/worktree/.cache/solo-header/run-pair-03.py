from pathlib import Path
import subprocess,json,hashlib,time,shutil,sys
out=Path('.cache/solo-header');held=json.loads((out/'source-held-02.json').read_text());admission=json.loads((out/'admission.json').read_text());roots=['game/test/device-controls-host.test.mjs','game/test/field-kit-surfaces.test.mjs'];sha=lambda b:hashlib.sha256(b).hexdigest()
def pins():
 return [{'path':r['path'],'bytes':Path(r['path']).stat().st_size,'sha256':sha(Path(r['path']).read_bytes())} for r in admission['files']+json.loads((out/'fixture-admission.json').read_text())['files']]
for version in ['22.22.2','20.19.5']:
 for r in held['files']:
  b=Path(r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
 assert shutil.disk_usage('.').free>256*1024**2
 node=f'/Users/oleksandr.mekhovov/.local/share/mise/installs/node/{version}/bin/node';label='whole-03-node'+version.split('.')[0];before=pins();(out/(label+'-inputs-before.json')).write_text(json.dumps(before,indent=2)+'\n');log=out/(label+'.log');assert not log.exists();args=[node,'--test','--test-concurrency=1','--test-reporter=tap',*roots];start=time.monotonic()
 with log.open('wb') as stream:
  try: code=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=600).returncode
  except subprocess.TimeoutExpired: code=124
 after=pins();(out/(label+'-inputs-after.json')).write_text(json.dumps(after,indent=2)+'\n');raw=log.read_bytes();r={'base':held['base'],'hold':sha((out/'source-held-02.json').read_bytes()),'node':subprocess.check_output([node,'--version']).decode().strip(),'argv':args,'seconds':time.monotonic()-start,'exitCode':code,'inputsUnchanged':before==after,'inputCount':len(before),'log':{'path':str(log),'bytes':len(raw),'sha256':sha(raw)}};(out/(label+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True);print(raw.decode(errors='replace')[-1500:],flush=True)
 if code or before!=after:sys.exit(code or 2)
