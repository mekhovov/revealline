import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {performance} from 'node:perf_hooks';
import {fileURLToPath} from 'node:url';
import {createTransport} from '../../p01/public-v0574-offline-completion-r8/ws-transport.mjs';

const dir=path.dirname(fileURLToPath(import.meta.url));
const profile=path.join(dir,'profile');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const free=()=>{const s=fs.statfsSync(dir);return s.bavail*s.bsize;};
const args=['--headless=new','--remote-debugging-port=0','--enable-automation','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','--disable-default-apps','--disable-gpu-shader-disk-cache','--enable-unsafe-swiftshader','--password-store=basic','--use-mock-keychain','--disk-cache-size=4194304','--media-cache-size=1048576','--window-size=844,390','--user-data-dir='+profile,'about:blank'];
const out={at:new Date().toISOString(),profile,pid:null,args,scope:'Bounded independent native-input Solo header diagnostic at 844x390 DPR1, non-running Standard then Large/Plain. Two screenshots; no gameplay, application setters, synthetic DOM events or storage injection. Runtime.evaluate is observation only. This is a CSS overlay diagnostic, not release or broad accessibility acceptance.',phases:[],actions:[],captures:[],limits:{totalMs:180000,operationalMs:168000,startupMs:60000,nativeInputs:100,pngs:2,freeFloorBytes:2*1024**3},freeBefore:free(),errors:[],eventsTruncated:false,chromeLogTruncated:false};
out.predecessor={"status":"FAILED_RETAINED","causeDisposition":"Confirmed native Enter dispatch discrepancy: r1 lacked carriage-return text. Product causality is not established by the failed attempt alone. R2 changes only CDP keyboard text/type; source, limits and two-capture scope are unchanged.","files":[{"path":"/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p05-preparation/header-90e8-r1/diagnose.mjs","bytes":23061,"sha256":"27a5c2c70057c46df369db771d86c963c3f4803bf5fe3fd9d79b7c599e4583f5"},{"path":"/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p05-preparation/header-90e8-r1/result.json","bytes":523000,"sha256":"3b5cdbc61b20a0cdd635dbf54bde7f15945843c65549ac729cc9a7c80a2a6b64"},{"path":"/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p05-preparation/header-90e8-r1/events.jsonl","bytes":1214623,"sha256":"bb92f748601f83f03264fd5ec7a070bd0bfa874870afa0c2fa41599d14161839"},{"path":"/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p05-preparation/header-90e8-r1/01-standard-header-settings-focus.png","bytes":22044,"sha256":"72191b107204c0c07fa0a996b798ca0d0f13cd03a1b5b693ceceb04dd8263a46"},{"path":"/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p05-preparation/header-90e8-r1/source-binding.json","bytes":2232,"sha256":"4c21bf9363e6c129055ff746c771be59dca568bd7c246d4b5790d43779639d1e"}]};
let chrome,sid,ws,seq=0,eventBytes=0,chromeLogBytes=0,phase='startup',fatal=null,exitCode=null,exitSignal=null,exited=false,childClosed=false,observationBytes=0,spawnError=null,events=null,chromeLog=null,resultFile=null,deadline,capacity,port=null;
const pending=new Map(),requestPhases=new Map();
const URL_EXPECTED='http://127.0.0.1:50576/game/';
const bindingPath='/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/p05-solo-header/.cache/solo-header/preview/binding.json';
let targetId=null,launchedAt=null,nativeInputs=0;
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const short=(value,limit=3000)=>String(value??'').slice(0,limit);
function errorNote(value){if(out.errors.length<32)out.errors.push(short(value));else out.errorsTruncated=true;}
function urlMetadata(value){
 const raw=String(value??'');let u;try{u=new URL(raw);}catch{}
 const metadata={scheme:u?.protocol??'invalid:',bytes:Buffer.byteLength(raw),sha256:crypto.createHash('sha256').update(raw).digest('hex')};
 if(u&&['http:','https:'].includes(u.protocol)){const address=u.origin+u.pathname;metadata.address=address.slice(0,2048);metadata.addressTruncated=address.length>2048;}
 return metadata;
}
function log(row){
 const b=JSON.stringify({at:new Date().toISOString(),observedPhase:phase,...row})+'\n';
 if(Buffer.byteLength(b)>64*1024||eventBytes+Buffer.byteLength(b)>4*1024**2){out.eventsTruncated=true;out.droppedEvents=(out.droppedEvents??0)+1;return;}
 if(events!==null){fs.writeSync(events,b);eventBytes+=Buffer.byteLength(b);}
}
function fail(message){fatal??=short(message);if(chrome?.pid&&!exited)chrome.kill('SIGTERM');}
function call(method,params={},sessionId=sid,timeout=10000){return new Promise((resolve,reject)=>{
 if(ws?.readyState!==1){reject(Error('CDP socket not open: '+method));return;}
 const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP deadline '+method));},timeout);
 pending.set(id,{resolve,reject,timer});
 try{ws.send(JSON.stringify({id,method,params,...sessionId?{sessionId}:{}}));}catch(error){clearTimeout(timer);pending.delete(id);reject(error);}
});}
async function read(expression){const r=await call('Runtime.evaluate',{expression,returnByValue:true});if(r.exceptionDetails)throw Error(short(JSON.stringify(r.exceptionDetails)));return r.result.value;}
function processAbsent(){if(!chrome?.pid)return true;try{process.kill(chrome.pid,0);return false;}catch(error){return error.code==='ESRCH';}}
function endpointClosed(){return new Promise(resolve=>{
 if(!port){resolve(null);return;}
 const socket=net.createConnection({host:'127.0.0.1',port});let settled=false;
 const done=value=>{if(settled)return;settled=true;socket.destroy();resolve(value);};
 socket.setTimeout(500,()=>done(false));socket.once('connect',()=>done(false));socket.once('error',error=>done(error.code==='ECONNREFUSED'));
});}
const observation=`(()=>{
 const rect=e=>{if(!e)return null;const r=e.getBoundingClientRect();return {x:r.x,y:r.y,left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height};};
 const info=e=>{if(!e)return null;const r=rect(e),c=getComputedStyle(e),visible=!e.hidden&&r.width>0&&r.height>0&&c.display!=='none'&&c.visibility!=='hidden';const point=(x,y)=>{const h=document.elementFromPoint(x,y);return {x,y,id:h?.id??null,tag:h?.tagName??null,within:!!h&&(h===e||e.contains(h))};};return {id:e.id,tag:e.tagName,text:e.innerText?.slice(0,200),value:'value'in e?e.value:undefined,selectedText:e.tagName==='SELECT'?e.selectedOptions[0]?.textContent:undefined,hidden:e.hidden,disabled:!!e.disabled,inert:!!e.closest('[inert]'),tabIndex:e.tabIndex,visible,focused:e===document.activeElement,focusVisible:e.matches(':focus-visible'),rect:r,insideViewport:visible&&r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight,clientWidth:e.clientWidth,scrollWidth:e.scrollWidth,clientHeight:e.clientHeight,scrollHeight:e.scrollHeight,style:{fontSize:c.fontSize,fontFamily:c.fontFamily,outline:c.outline,outlineOffset:c.outlineOffset,boxShadow:c.boxShadow,overflowX:c.overflowX,overflowY:c.overflowY},hits:visible?[point(r.x+r.width/2,r.y+r.height/2),point(r.left+1,r.top+1),point(r.right-1,r.top+1),point(r.left+1,r.bottom-1),point(r.right-1,r.bottom-1)]:[]};};
 const b=document.getElementById('boot-screen'),h=document.getElementById('shell-home');return {url:location.href,timeOrigin:performance.timeOrigin,now:performance.now(),visibility:document.visibilityState,hasFocus:document.hasFocus(),readyState:document.readyState,boot:document.documentElement.dataset.bootState,bootHidden:b?.hidden,bootText:b?.innerText?.slice(0,1200),homeOpen:h?.open,homeVisible:info(h)?.visible,bodyClass:document.body?.className,datasets:{...document.body?.dataset},viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},active:info(document.activeElement),header:info(document.querySelector('.shell-bar')),headerControls:[...document.querySelectorAll('.shell-bar button,.shell-bar .shell-edition')].map(info),dialogs:[...document.querySelectorAll('dialog[open]')].map(e=>({id:e.id,rect:rect(e)})),displayHidden:document.getElementById('settings-panel-display')?.hidden,displayTab:info(document.getElementById('settings-tab-display')),textFace:info(document.getElementById('text-face')),textSize:info(document.getElementById('text-size'))};})()`;
function assert(condition,message){if(!condition)throw Error(message);}
function alive(){assert(!fatal&&!exited&&!spawnError,fatal||spawnError||'Owned Chrome stopped');assert(launchedAt===null||performance.now()-launchedAt<168000,'168s operation limit; 12s closure reserve');}
async function sample(label){
 alive();const value=await read(observation),bytes=Buffer.byteLength(JSON.stringify(value));observationBytes+=bytes;
 assert(bytes<=64*1024&&observationBytes<=4*1024**2,'Observation metadata budget');
 log({observation:label,value});return value;
}
function guardValue(v){
 assert(v.url===URL_EXPECTED,'Unexpected page URL '+v.url);
 assert(v.viewport.width===844&&v.viewport.height===390&&v.viewport.dpr===1,'Viewport changed');
 assert(v.visibility==='visible'&&v.hasFocus,'Owned page not foreground/focused');
 assert(v.datasets.flightState!=='running','Unexpected gameplay; native input refused');
 assert(v.dialogs.every(d=>['shell-home','settings-dialog'].includes(d.id)),'Unexpected dialog owner');
}
async function guarded(label){
 alive();const pages=(await call('Target.getTargets',{},null)).targetInfos.filter(t=>t.type==='page');
 assert(pages.length===1&&pages[0].targetId===targetId&&pages[0].url===URL_EXPECTED,'Owned target changed');
 const v=await sample(label);guardValue(v);return v;
}
async function key(key,shift=false){
 const before=await guarded('before-key-'+key);assert(++nativeInputs<=100,'Native input bound');
 const action={number:nativeInputs,at:new Date().toISOString(),kind:'key',key,shift,before};out.actions.push(action);
 const keys={Escape:['Escape',27],Tab:['Tab',9],Enter:['Enter',13],ArrowRight:['ArrowRight',39],p:['KeyP',80],l:['KeyL',76]};
 assert(keys[key],'Key not permitted');const [code,windowsVirtualKeyCode]=keys[key];
 const params={key,code,windowsVirtualKeyCode,modifiers:shift?8:0};
 if(key==='p'||key==='l'||key==='Enter'){params.text=key==='Enter'?'\r':key;params.unmodifiedText=params.text;}
 await call('Input.dispatchKeyEvent',{type:params.text?'keyDown':'rawKeyDown',...params});
 await call('Input.dispatchKeyEvent',{type:'keyUp',key,code,windowsVirtualKeyCode,modifiers:shift?8:0});
 await sleep(120);action.after=await guarded('after-key-'+key);return action.after;
}
async function waitFor(label,predicate,ms=4000){
 const until=performance.now()+ms;let v;
 while(performance.now()<until){v=await guarded(label);if(predicate(v))return v;await sleep(120);}
 throw Error(label+' did not settle within '+ms+'ms; active='+v?.active?.id+' dialogs='+JSON.stringify(v?.dialogs));
}
async function tabTo(id,limit=32){
 let v=await guarded('seek-'+id);if(v.active?.id===id&&v.active.focusVisible)return v;
 // No fixed tab count: each actual destination is observed; reverse only after a full forward cycle.
 const seen=new Set();let reverse=false;
 for(let i=0;i<limit;i++){
  v=await key('Tab',reverse);if(v.active?.id===id&&v.active.focusVisible)return v;
  const marker=(v.active?.tag??'')+':'+(v.active?.id??'')+':'+(v.active?.text??'');
  if(!reverse&&seen.has(marker)){reverse=true;seen.clear();}seen.add(marker);
 }
 throw Error('Keyboard route did not reach '+id+' within '+limit+' observed Tab/Shift+Tab inputs');
}
async function clickDisplay(){
 const before=await guarded('display-click-geometry');const c=before.displayTab;
 assert(c?.visible&&!c.disabled&&!c.inert&&c.insideViewport&&c.hits[0].within,'Display tab not currently clickable');
 await sleep(120);const settled=await guarded('display-click-settled');
 assert(JSON.stringify(settled.displayTab.rect)===JSON.stringify(c.rect)&&settled.displayTab.hits[0].within,'Display target did not settle');
 assert(++nativeInputs<=100,'Native input bound');const a={number:nativeInputs,at:new Date().toISOString(),kind:'mouse',selector:'#settings-tab-display',before:settled};out.actions.push(a);
 const x=c.hits[0].x,y=c.hits[0].y;
 await call('Input.dispatchMouseEvent',{type:'mouseMoved',x,y});
 await call('Input.dispatchMouseEvent',{type:'mousePressed',x,y,button:'left',clickCount:1});
 await call('Input.dispatchMouseEvent',{type:'mouseReleased',x,y,button:'left',clickCount:1});
 await sleep(120);a.after=await guarded('display-click-after');return a.after;
}
async function capture(name){
 const before=await guarded(name+'-capture-before');
 assert(before.dialogs.length===0&&before.active?.id==='shell-settings'&&before.active.focusVisible,'Header capture requires genuine keyboard Settings focus');
 const metricsBefore=await call('Page.getLayoutMetrics');
 const png=Buffer.from((await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64');
 assert(png.length<=2*1024**2&&png.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])),'PNG bounds/signature');
 assert(png.readUInt32BE(16)===844&&png.readUInt32BE(20)===390,'PNG dimensions differ from requested viewport');
 const filename=name+'.png';fs.writeFileSync(path.join(dir,filename),png,{flag:'wx'});
 const after=await guarded(name+'-capture-after'),metricsAfter=await call('Page.getLayoutMetrics');
 assert(after.timeOrigin===before.timeOrigin&&after.active?.id==='shell-settings'&&after.active.focusVisible,'Capture document/focus changed');
 out.captures.push({name,path:filename,bytes:png.length,sha256:hash(png),png:{width:844,height:390},before,after,metricsBefore,metricsAfter});
}

try{
 if(fs.existsSync(profile)||free()<2*1024**3+256*1024**2)throw Error('Fresh owned profile and 2GiB + 256MiB initial reserve required');
 const bindingBytes=fs.readFileSync(bindingPath),binding=JSON.parse(bindingBytes);
 assert(binding.base==='90e8bc8102cc71a992a57aa1f41d7cdcd6659b3e'&&binding.port===50576&&binding.url===URL_EXPECTED&&binding.overlays?.length===1&&binding.overlays[0].sha256==='fc691f850e0cd7931307aaf3b561855a9c4f2b279887e5eeb97cb6b1b7c9f9f1','Expected 90e8 Solo header overlay binding required');
 out.sourceBinding={path:bindingPath,bytes:bindingBytes.length,sha256:hash(bindingBytes),value:binding};
 // Reserve exclusive evidence files before a child can exist; all later setup is protected.
 resultFile=fs.openSync(path.join(dir,'result.json'),'wx');
 events=fs.openSync(path.join(dir,'events.jsonl'),'wx');
 chromeLog=fs.openSync(path.join(dir,'chrome.log'),'wx');
 fs.mkdirSync(profile);
 launchedAt=performance.now();
 chrome=spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args,{stdio:['ignore','ignore','pipe']});
 out.pid=chrome.pid??null;
 chrome.on('error',error=>{spawnError=short(error);fail('Chrome child error: '+spawnError);});
 chrome.on('exit',(code,signal)=>{exited=true;exitCode=code;exitSignal=signal;});
 chrome.on('close',()=>{childClosed=true;});
 chrome.stderr.on('data',bytes=>{try{const room=1024**2-chromeLogBytes;if(bytes.length>room)out.chromeLogTruncated=true;if(room>0){const part=bytes.subarray(0,room);fs.writeSync(chromeLog,part);chromeLogBytes+=part.length;}}catch(error){fail('Chrome log write: '+error);}});
 deadline=setTimeout(()=>fail('168s operation bound; 12s reserved for closure within 180s total'),168000);
 capacity=setInterval(()=>{try{if(free()<2*1024**3)fail('2GiB free-space floor');}catch(error){fail('Capacity observation failed: '+error);}},5000);
 const portFile=path.join(profile,'DevToolsActivePort');
 for(let i=0;i<200&&!fs.existsSync(portFile);i++){if(fatal||exited||spawnError)throw Error(fatal||spawnError||'Chrome stopped');await sleep(100);}
 const [portText,route]=fs.readFileSync(portFile,'utf8').trim().split('\n');port=Number(portText);
 if(!Number.isInteger(port)||port<1||port>65535||!/^\/devtools\/browser\/[a-zA-Z0-9-]+$/.test(route))throw Error('Invalid owned DevTools endpoint');
 out.endpoint='ws://127.0.0.1:'+port+route;ws=createTransport(out.endpoint);
 ws.on('message',bytes=>{try{
  const m=JSON.parse(bytes);if(m.id){const p=pending.get(m.id);if(!p)return;clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(short(JSON.stringify(m.error)))):p.resolve(m.result);return;}
  if(m.sessionId!==sid)return;const p=m.params||{};
  if(m.method==='Network.requestWillBeSent'){
   if(!requestPhases.has(p.requestId)){if(requestPhases.size>=10000)throw Error('Request identity budget');requestPhases.set(p.requestId,phase);}
   log({method:m.method,requestId:p.requestId,requestPhase:requestPhases.get(p.requestId),url:urlMetadata(p.request.url),type:p.type,timestamp:p.timestamp,loaderId:p.loaderId,redirect:!!p.redirectResponse});
  }else if(m.method==='Network.responseReceived')log({method:m.method,requestId:p.requestId,requestPhase:requestPhases.get(p.requestId)??null,url:urlMetadata(p.response.url),status:p.response.status,type:p.type,timestamp:p.timestamp,fromDiskCache:p.response.fromDiskCache,fromServiceWorker:p.response.fromServiceWorker,timing:p.response.timing});
  else if(['Network.loadingFailed','Network.loadingFinished','Network.requestServedFromCache'].includes(m.method))log({method:m.method,requestId:p.requestId,requestPhase:requestPhases.get(p.requestId)??null,timestamp:p.timestamp,encodedDataLength:p.encodedDataLength,errorText:short(p.errorText),canceled:p.canceled,type:p.type});
  else if(m.method==='Runtime.exceptionThrown'){const d=p.exceptionDetails??{};log({method:m.method,text:short(d.text),url:urlMetadata(d.url),description:short(d.exception?.description),lineNumber:d.lineNumber,columnNumber:d.columnNumber});}
  else if(m.method==='Log.entryAdded')log({method:m.method,level:p.entry?.level,source:p.entry?.source,text:short(p.entry?.text),url:urlMetadata(p.entry?.url)});
  else if(['Page.domContentEventFired','Page.loadEventFired'].includes(m.method))log({method:m.method,timestamp:p.timestamp});
  else if(m.method==='Runtime.consoleAPICalled')log({method:m.method,type:p.type,args:(p.args??[]).slice(0,16).map(a=>({type:a.type,value:typeof a.value==='string'?short(a.value):typeof a.value==='number'||typeof a.value==='boolean'?a.value:undefined,description:short(a.description)})),argsTruncated:(p.args?.length??0)>16});
 }catch(error){errorNote(error);fail('CDP event collection failed: '+error);}});
 ws.on('error',e=>errorNote(e));ws.on('close',()=>{for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('Socket closed'));}pending.clear();});
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('WebSocket open deadline')),5000);ws.once('open',()=>{clearTimeout(timer);resolve();});ws.once('error',error=>{clearTimeout(timer);reject(error);});});
 const targets=(await call('Target.getTargets',{},null)).targetInfos.filter(t=>t.type==='page');if(targets.length!==1||targets[0].url!=='about:blank')throw Error('Owned blank target required');
 targetId=targets[0].targetId;out.targetId=targetId;
 sid=(await call('Target.attachToTarget',{targetId,flatten:true},null)).sessionId;
 for(const method of ['Page.enable','Runtime.enable','Log.enable','Network.enable','Performance.enable'])await call(method);
 await call('Emulation.setDeviceMetricsOverride',{width:844,height:390,deviceScaleFactor:1,mobile:false});await call('Page.bringToFront');
 phase='title-startup';const p={name:phase,startedAt:new Date().toISOString(),samples:[]};out.phases.push(p);
 p.navigationReply=await call('Page.navigate',{url:URL_EXPECTED});assert(!p.navigationReply.errorText,'Navigation failed');
 const startupUntil=launchedAt+60000;
 while(performance.now()<startupUntil){
  alive();let v;try{v=await sample('title-startup');}catch(error){if(/context|Cannot find/i.test(String(error))){await sleep(100);continue;}throw error;}
  p.samples.push(v);
  if(v.url===URL_EXPECTED&&v.boot==='ready'&&v.bootHidden&&v.homeOpen&&v.homeVisible&&v.bodyClass.split(' ').includes('game-shell')){p.ready=v;p.elapsedMs=performance.now()-launchedAt;break;}
  await sleep(250);
 }
 assert(p.ready,'Title readiness exceeded 60s including browser startup');
 phase='standard';await key('Escape');
 await waitFor('title-dismissed',v=>!v.homeOpen&&v.dialogs.length===0);
 await tabTo('shell-settings');let v=await guarded('standard-values');
 assert(v.textSize?.value==='standard'&&v.datasets.textSize==='standard','Fresh Standard preset not observed');
 await capture('01-standard-header-settings-focus');
 phase='display-preferences';await key('Enter');await waitFor('settings-open',v=>v.dialogs.length===1&&v.dialogs[0].id==='settings-dialog');
 await clickDisplay();await waitFor('display-panel-visible',v=>v.displayHidden===false);
 await tabTo('text-face');await key('p');await key('Tab');
 await waitFor('plain-selected',v=>v.textFace?.value==='plain'&&v.datasets.textFace==='plain');
 await tabTo('text-size');await key('l');await key('Tab');
 await waitFor('large-plain-selected',v=>v.textSize?.value==='large'&&v.datasets.textSize==='large'&&v.textFace?.value==='plain'&&v.datasets.textFace==='plain');
 await key('Escape');await waitFor('settings-closed',v=>v.dialogs.length===0);
 phase='large-plain';await tabTo('shell-settings');v=await guarded('large-plain-header');
 assert(v.datasets.textSize==='large'&&v.datasets.textFace==='plain','Preferences changed before final capture');
 await capture('02-large-plain-header-settings-focus');
 out.diagnosticCompleted=true;
 out.geometryFindings=out.captures.map(c=>({name:c.name,headerInsideViewport:c.before.header?.insideViewport,visibleControls:c.before.headerControls.filter(e=>e.visible).map(e=>({id:e.id,insideViewport:e.insideViewport,centerHit:e.hits[0]?.within,focused:e.focused,focusVisible:e.focusVisible,rect:e.rect})),scope:'Observed bounds/hits only; screenshots require independent visual assessment, including focus outline.'}));
}catch(e){out.status='FAILED_RETAINED';out.error=short(e.stack,8000);process.exitCode=1;}
finally{
 phase='cleanup';
 try{if(ws?.readyState===1)await call('Browser.close',{},null,2000);}catch(e){out.closeError=short(e);}
 for(let i=0;i<30&&chrome?.pid&&!exited;i++)await sleep(100);
 if(chrome?.pid&&!exited){out.cleanupSignal='SIGTERM';chrome.kill('SIGTERM');for(let i=0;i<20&&!exited;i++)await sleep(100);}
 if(chrome?.pid&&!exited){out.cleanupSignal='SIGKILL';chrome.kill('SIGKILL');for(let i=0;i<20&&!exited;i++)await sleep(100);}
 for(let i=0;i<10&&chrome?.pid&&!childClosed;i++)await sleep(100);
 clearInterval(capacity);clearTimeout(deadline);
 if(ws&&ws.readyState!==3)ws.terminate();for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('Diagnostic cleanup'));}pending.clear();
 out.exitCode=exitCode;out.exitSignal=exitSignal;out.spawnError=spawnError;out.browserExited=exited;out.pidAbsent=processAbsent();out.endpointClosed=await endpointClosed();out.childClosed=childClosed;out.browserClosed=Boolean(chrome?.pid&&exited&&childClosed&&out.pidAbsent&&out.endpointClosed===true);out.capacityFailure=fatal;out.freeAfter=free();out.finishedAt=new Date().toISOString();out.eventBytes=eventBytes;out.chromeLogBytes=chromeLogBytes;out.observationBytes=observationBytes;
 out.elapsedMs=launchedAt===null?null:performance.now()-launchedAt;
 out.status=out.diagnosticCompleted&&!out.error&&!fatal&&out.browserClosed&&exitCode===0&&out.elapsedMs<=180000?'COMPLETED_TWO_HEADER_CAPTURES_VISUAL_REVIEW_REQUIRED':'FAILED_RETAINED';
 out.evidenceComplete=!out.eventsTruncated&&!out.errorsTruncated&&!out.chromeLogTruncated&&!out.phases.some(p=>p.resources?.truncated);
 if(out.status!=='COMPLETED_TWO_HEADER_CAPTURES_VISUAL_REVIEW_REQUIRED')process.exitCode=1;
 let serialized=JSON.stringify(out,null,2)+'\n';
 if(Buffer.byteLength(serialized)>8*1024**2){out.status='FAILED_RETAINED';out.error='Result metadata exceeded8MiB; detailed samples omitted';out.evidenceComplete=false;for(const p of out.phases){p.omittedSampleCount=p.samples.length;p.samples=[];}serialized=JSON.stringify(out,null,2)+'\n';process.exitCode=1;}
 try{if(resultFile!==null)fs.writeFileSync(resultFile,serialized);else console.error(short(out.error??'Preflight refused'));}finally{for(const fd of [events,chromeLog,resultFile])if(fd!==null)fs.closeSync(fd);}
 console.log(JSON.stringify({status:out.status,error:out.error,captures:out.captures.map(p=>({name:p.name,path:p.path,sha256:p.sha256})),nativeInputs,elapsedMs:out.elapsedMs,exitCode,exitSignal,browserClosed:out.browserClosed,evidenceComplete:out.evidenceComplete,fatal}));
}
