# Root review of independent clean header captures

Root inspected both images from `go_test_cross_mode/.cache/cross-mode/p05-preparation/header-90e8-r2` on16 September2026. The source is the existing90e8 baseline plus the heldfc691 header CSS; no runtime correction was made for the first harness's incomplete Enter protocol.

At actual844×390,DPR1, Standard and Large/Plain both display all header controls inside the viewport. Settings has visible cyan inset keyboard focus. Independent measurements report every header control at y1..45,height44,min-width60 with five hitpoints. This closes the previously inconclusive candidate header image check within its narrow scope; it does not qualify all player screens or hardware.

**Separate failure retained:** the Large/Plain briefing title “Clear a path.” is clipped at its bottom above the Read details panel. The clean second PNG makes this visible. Track and correct the briefing layout in P05; do not count the header fix as full Large text acceptance. The earlier banded captures, wrong viewport attempts and first Enter harness attempt remain unchanged.
