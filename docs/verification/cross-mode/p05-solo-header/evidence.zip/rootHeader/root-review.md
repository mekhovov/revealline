# Solo header review

Baseline clean screenshot and DOM reproduce top clipping at actual844×390/DPR1: Settings y=-1.296875, height48.59375. Candidate full header and five hit samples are inside actual844×390 in Standard and Large/Plain; computed minimum height44px. Measured Large y1.1631945,height43.9930573 under DPR0.9 rounding. Keyboard opens Settings and Escape restores its opener. At actual390×844, compact Menu/Fullscreen remain inside; keyboard Menu→Settings→Back returns to the correct menu action. No simulation ran.

Candidate screenshot captures are distorted by the in-app viewport compositor; no visual acceptance is claimed from them. Original candidate and baseline diagnostic captures remain alongside the clean baseline. Candidate visual acceptance remains outstanding. This is browser geometry/input evidence, not real touch/controller, browser zoom certification, or final P01 recovery-host composition. Viewport reset after the run.
