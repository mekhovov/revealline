# Ready briefing R4 — root review

Reviewed 2026-09-16. This is a narrow CSS checkpoint review, not acceptance of P05, a release, or the later composed game.

The root independently read the R4 review and source binding, verified all eleven manifest entries (10,889,841 bytes), and visually inspected all four original PNGs. Manifest SHA-256: `93aad8d257df595b261ce8b1cb6c4dfc59a46e468d17bea0764acd47f60e4b1d`. Review SHA-256: `b7506bf628d0fcffb32ce80e1689f6a152b978037a8defb820294480a373759a`.

The exact preview combines Git `90e8bc8102cc71a992a57aa1f41d7cdcd6659b3e`, header CSS `fc691f850e0cd7931307aaf3b561855a9c4f2b279887e5eeb97cb6b1b7c9f9f1`, and Ready surfaces CSS `c0d3f671828537178bfe2a85887339b053def3002631c47abfe86cbacafb0f18`. Fifteen actual served bodies were pinned independently. The post-run HTTP comparison must remain exact before packaging.

At 844×390, Standard and Large/Plain headings fit at the initial scroll position. All four resting actions fit before and after Done. The recorded native keyboard traversal reaches each action after ordinary reading exit; each passes its 44px target, ancestor clipping and five-point hit checks. The actual PNGs show enough clearance between reading text and the painted scrollbar. PageDown reaches the measured end, and Done restores focus to Read details.

While expanded reading hints are active, the lower actions are outside the action viewport. The demonstrated ordinary Tab exit restores their reachability; this review does not claim that every action remains simultaneously visible during reading. Deliberately scrolling moves the heading partly out of view and is not initial-heading clipping.

The four PNGs are clean, without the in-app viewport compositor bands that invalidated earlier visual evidence. Icons finish loading by the fourth frame; earlier frames are not asset-readiness evidence. There were no runtime exceptions or console errors, but one cancelled fetch and two preview 404s remain recorded. This is not a blanket network-clean claim.

R3 failures and originals remain unchanged. The remaining wrong-device reading instruction belongs to the separate P03 prompt correction. Other viewport sizes, zoom, physical touch/controller use, the integrated source, public deployment and offline behavior remain outside this review.

Disposition: approve this narrow corrected briefing/header candidate for evidence packaging and a reviewed internal checkpoint. Preserve the above limits and the failed predecessor evidence.
