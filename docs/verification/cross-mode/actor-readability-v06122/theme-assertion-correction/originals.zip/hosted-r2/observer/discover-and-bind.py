from pathlib import Path
import subprocess,threading,json,datetime,hashlib,shutil,os
H=Path(__file__).resolve().parent;R=H.parents[3];O=H/'hosted-observation-r1';O.mkdir();source='80efcc3ddda302a014c3409c248892f36b3a12a9';tree='28710b13cedc3bf2a7a1f4ec7bbfeb9282f83947';repo='mekhovov/revealline';start=datetime.datetime.now(datetime.timezone.utc).isoformat()
def put(p,b):
 assert not p.exists() and len(b)<=2000000;assert shutil.disk_usage(H).free>=512*1024**2+len(b);assert sum(x.stat().st_size for x in H.rglob('*') if x.is_file())+len(b)<32*1024**2;p.write_bytes(b)
def get(endpoint,name):
 assert endpoint.startswith('repos/'+repo+'/actions/runs');cmd=['gh','api','--method','GET',endpoint];p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timer=threading.Timer(60,p.kill);timer.start()
 try:
  body=p.stdout.read(2000001);err=p.stderr.read(100001);code=p.wait(timeout=60);assert len(body)<=2000000 and len(err)<=100000
 finally:
  timer.cancel()
  if p.poll() is None:p.kill();p.wait()
 put(O/(name+'.json'),body);put(O/(name+'.stderr'),err);put(O/(name+'.receipt.json'),(json.dumps({'command':cmd,'exit':code,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bodySHA256':hashlib.sha256(body).hexdigest(),'automaticRetry':False},indent=2)+'\n').encode());assert code==0;return json.loads(body)
runs=get(f'repos/{repo}/actions/runs?head_sha={source}&per_page=20','runs-list');assert runs['total_count']==len(runs['workflow_runs'])<=20
bound={}
for family,event,path in [('manual','workflow_dispatch','.github/workflows/qualify-release-source.yml'),('pr-source','pull_request','.github/workflows/deploy-pages.yml')]:
 matches=[x for x in runs['workflow_runs'] if x['head_sha']==source and x['event']==event and x['path']==path];assert len(matches)==1,(family,len(matches));v=get(f'repos/{repo}/actions/runs/{matches[0]["id"]}',family+'-initial');assert v['head_commit']['tree_id']==tree and v['run_attempt']==1 and v['head_branch']=='codex/p08-actor-minimum-next';bound[family]={'id':v['id'],'attempt':v['run_attempt'],'createdAt':v['created_at']}
for name in ['push.receipt.json','request.json','dispatch-correct-workflow.receipt.json']:
 v=json.loads((H.parent/name).read_text())
 if name.endswith('receipt.json'):assert v['exit']==0
 if name=='request.json':assert v=={'ref':'codex/p08-actor-minimum-next','inputs':{'operation':'qualify','freeze_snapshot':True}}
completed=datetime.datetime.now(datetime.timezone.utc).isoformat();put(O/'runs-initial.receipt.json',(json.dumps({'startedAt':start,'completedAt':completed,'source':source,'scope':'Original exact-run GET discovery; no final qualification.'},indent=2)+'\n').encode())
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
files=sorted(p for p in H.parent.iterdir() if p.is_file())+sorted(p for p in O.iterdir() if p.is_file());b=json.loads((H/'intake-binding.proposed.json').read_text());b['status']='DELEGATED_READ_ONLY_INTAKE_BINDING_NOT_FINAL_ROOT_QUALIFICATION';b['runs']=bound;b['rootDispatchOriginalPins']=[pin(p) for p in files];put(H/'intake-binding.json',(json.dumps(b,indent=2)+'\n').encode());print(json.dumps({'source':source,'runs':bound,'binding':pin(H/'intake-binding.json')}))
