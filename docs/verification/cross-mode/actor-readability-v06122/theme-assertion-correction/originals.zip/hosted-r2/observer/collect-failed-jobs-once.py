import datetime,json,gzip
from collect_hosted import HERE,BIND,SOURCE,RUNS,OUT,api,put,objput,sha
rows=[]
for family,jid in [('manual',105651357292),('pr-source',105651126674)]:
 folder=OUT/'hosted'/family;assert not (folder/f'job-{jid}.json').exists()
 meta=api(f"repos/{BIND['repository']}/actions/jobs/{jid}",1000000);job=json.loads(meta);assert job['run_id']==RUNS[family] and job['head_sha']==SOURCE and job['run_attempt']==1 and job['name']=='test (1)' and job['status']=='completed' and job['conclusion']=='failure';put(folder/f'job-{jid}.json',meta)
 log=api(f"repos/{BIND['repository']}/actions/jobs/{jid}/logs",20000000);compressed=gzip.compress(log,mtime=0);put(folder/f'job-{jid}.log.gz',compressed)
 objput(folder/f'job-{jid}-receipt.json',{'status':'ORIGINAL_COMPLETED_JOB_COLLECTED','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':RUNS[family],'attempt':1,'job':jid,'family':family,'name':job['name'],'conclusion':'failure','source':SOURCE,'apiBytes':len(meta),'apiSHA256':sha(meta),'rawLogBytes':len(log),'rawLogSHA256':sha(log),'gzipBytes':len(compressed),'gzipSHA256':sha(compressed),'scope':'Original terminal job; whole run still active. No qualification or public acceptance.'})
 lines=log.decode().splitlines();selected=[]
 for i,line in enumerate(lines):
  if 'not ok ' in line:
   selected.append({'line':i+1,'context':lines[max(0,i-2):i+24]})
 row={'family':family,'job':jid,'failedTests':selected,'failedSteps':[s['name'] for s in job['steps'] if s.get('conclusion')=='failure']};rows.append(row)
objput(HERE/'failed-shard1-diagnosis.json',{'source':SOURCE,'jobs':rows,'scope':'Read-only extraction from two actual completed failing jobs; source unchanged and family4/terminal still pending.'})
print(json.dumps(rows,indent=2))
