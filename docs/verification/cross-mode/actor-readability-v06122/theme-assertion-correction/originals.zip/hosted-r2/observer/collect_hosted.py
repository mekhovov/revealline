#!/usr/bin/env python3
"""One bounded GET-only intake of the two actual P08 actor-size correction hosted runs; no polling or dispatch.
Retains failed terminal originals too; never emits qualification or reviewed bindings.
"""
from pathlib import Path
import argparse, base64, datetime, gzip, hashlib, io, json, re, subprocess, shutil, threading

HERE = Path(__file__).resolve().parent
from prepared_binding import BIND, SOURCE, TREE, ROOT, WT, RUNS, RUN_RECORDS
REPO = BIND['repository']
OUT = HERE / 'intake'
FLOWS = {'manual': ('.github/workflows/qualify-release-source.yml', 'workflow_dispatch'),
         'pr-source': ('.github/workflows/deploy-pages.yml', 'pull_request')}
FILES = ['.github/workflows/deploy-pages.yml', '.github/workflows/publish-frozen-pages.yml',
         'scripts/run-test-shard.mjs', 'scripts/check-source-identity.mjs']
sha = lambda b: hashlib.sha256(b).hexdigest()

def check_path(path):
    assert path.is_relative_to(HERE) and not any(p.is_symlink() for p in [path, *path.parents])

def put(path, body):
    check_path(path)
    assert len(body) <= 20_000_000
    if path.exists():
        assert path.read_bytes() == body, f'Refusing changed retained bytes: {path}'
        return
    used = sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())
    assert used + len(body) <= 32 * 1024**2, 'Prospective cache write exceeds intake cap'
    assert shutil.disk_usage(HERE).free >= 512 * 1024**2 + len(body) + 65536, 'Prospective write breaches reserve'
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream: stream.write(body)
    assert sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file()) <= 32 * 1024**2
    assert shutil.disk_usage(HERE).free >= 512 * 1024**2

def objput(path, value): put(path, (json.dumps(value, indent=2) + '\n').encode())
def load(path):
    check_path(path); assert path.is_file() and path.stat().st_size <= 20_000_000
    return json.loads(path.read_bytes())
def api(endpoint, limit=2_000_000):
    assert endpoint.startswith('repos/' + REPO + '/')
    proc = subprocess.Popen(['gh', 'api', '--method', 'GET', endpoint], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    timer = threading.Timer(60, proc.kill); timer.start()
    try:
        body = proc.stdout.read(limit + 1)
        assert len(body) <= limit, 'Original response exceeds bounded intake'
        err = proc.stderr.read(100_001)
        assert len(err) <= 100_000
        code = proc.wait(timeout=60)
        if code != 0:
            stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
            failed = OUT / 'failed-original-gets' / stamp
            put(failed / 'response.body', body)
            put(failed / 'response.stderr', err)
            objput(failed / 'receipt.json', {'endpoint': endpoint, 'method': 'GET', 'exitCode': code,
                'bodyBytes': len(body), 'bodySha256': sha(body), 'stderrBytes': len(err), 'stderrSha256': sha(err),
                'automaticRetry': False, 'scope': 'Original failed GET; no synthetic log or success record.'})
        assert code == 0, err[:2000].decode(errors='replace')
        assert body
        return body
    finally:
        timer.cancel()
        if proc.poll() is None: proc.kill(); proc.wait()
def git(*args): return subprocess.check_output(['git', '-C', str(WT), *args])
def decoded(path):
    check_path(path)
    with gzip.GzipFile(fileobj=io.BytesIO(path.read_bytes())) as stream: raw=stream.read(20_000_001)
    assert len(raw) <= 20_000_000
    return raw

def collect(family):
    rid = RUNS[family]; folder = OUT/'hosted'/family
    # One snapshot only. Nonterminal snapshots never occupy the terminal run.json path.
    raw = api(f'repos/{REPO}/actions/runs/{rid}')
    run = json.loads(raw)
    assert run['id'] == rid and run['head_sha'] == SOURCE
    assert run['created_at']==RUN_RECORDS[family]['createdAt'], 'Actual run must match the retained exact root dispatch/PR discovery'
    assert (run['path'], run['event']) == FLOWS[family]
    attempt = run['run_attempt']; assert attempt == RUN_RECORDS[family]['attempt']
    if run['status'] != 'completed':
        stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        put(OUT/'observations'/f'{family}-{stamp}.json', raw)
        print(json.dumps({'family':family,'run':rid,'attempt':attempt,'status':run['status'],'collectedTerminal':False}))
        return
    if git('rev-parse','HEAD').decode().strip() != SOURCE or git('status','--porcelain','--untracked-files=no') != b'':
        assert run['conclusion'] == 'failure', 'Edited worktree permits failed original retention only'
    put(folder/'run.json', raw)
    jobsraw = api(f'repos/{REPO}/actions/runs/{rid}/attempts/{attempt}/jobs?per_page=100')
    jobs = json.loads(jobsraw)
    assert jobs['total_count'] == len(jobs['jobs']) <= 20
    expected = {'qualify' if family == 'manual' else 'preflight', 'freeze' if family == 'manual' else 'build', *[f'test ({i})' for i in range(1,5)]}
    by_name = {j['name']: j for j in jobs['jobs']}
    assert len(by_name) == len(jobs['jobs'])
    extras_allowed = {'inspect-artifact', 'upload-originals'} if family == 'manual' else {'release_gate'}
    if run['conclusion'] == 'success':
        assert expected <= set(by_name)
        extras = set(by_name) - expected
        assert extras <= extras_allowed
        assert all(by_name[name]['status'] == 'completed' and by_name[name]['conclusion'] == 'skipped' for name in extras)
    else:
        # Failed preflights can collapse an unstarted matrix to one skipped test job.
        # Preserve those terminal originals; success derivation still requires all four shards.
        assert set(by_name) <= expected | extras_allowed | {'test'}
        assert ('qualify' if family == 'manual' else 'preflight') in by_name
        assert all(job['status'] == 'completed' for job in jobs['jobs'])
    put(folder/'jobs.json', jobsraw)
    for summary in jobs['jobs']:
        jid = summary['id']; jp = folder/f'job-{jid}.json'
        if jp.exists():
            meta = jp.read_bytes()
        else: meta = api(f'repos/{REPO}/actions/jobs/{jid}', 1_000_000)
        job = json.loads(meta)
        assert job['run_id'] == rid and job['head_sha'] == SOURCE and job['run_attempt'] == attempt
        assert job['name'] == summary['name'] and job['status'] == 'completed' and job['conclusion'] == summary['conclusion']
        put(jp, meta)
        lp=folder/f'job-{jid}.log.gz'; rp=folder/f'job-{jid}-receipt.json'
        if lp.exists():
            log=decoded(lp); compressed=lp.read_bytes()
            receipt=load(rp)
            assert receipt['apiSHA256']==sha(meta) and receipt['rawLogSHA256']==sha(log) and receipt['gzipSHA256']==sha(compressed)
            continue
        # A skipped job has no actual job log and is retained as metadata only; derivation refuses it.
        if job['conclusion'] == 'skipped': continue
        log=api(f'repos/{REPO}/actions/jobs/{jid}/logs',20_000_000)
        compressed=gzip.compress(log,mtime=0); put(lp,compressed)
        objput(rp,{'status':'ORIGINAL_COMPLETED_JOB_COLLECTED','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'run':rid,'attempt':attempt,'job':jid,'family':family,'name':job['name'],'conclusion':job['conclusion'],'source':SOURCE,
            'apiBytes':len(meta),'apiSHA256':sha(meta),'rawLogBytes':len(log),'rawLogSHA256':sha(log),
            'gzipBytes':len(compressed),'gzipSHA256':sha(compressed),'scope':'Original terminal job; not source qualification or public acceptance.'})
    if family == 'manual':
        artifacts=api(f'repos/{REPO}/actions/runs/{rid}/artifacts?per_page=100')
        value=json.loads(artifacts); assert value['total_count']==len(value['artifacts'])<=20
        put(folder/'artifacts-final.json',artifacts)
    print(json.dumps({'family':family,'run':rid,'attempt':attempt,'status':run['status'],'conclusion':run['conclusion'],'jobs':len(jobs['jobs']),'collectedTerminal':True}))

def automation():
    h=OUT/'hosted'; jobs=load(h/'pr-source/jobs.json')['jobs']
    matches=[j for j in jobs if j['name']=='preflight']; assert len(matches)==1
    jid=matches[0]['id']; relative=f'../pr-source/job-{jid}.log.gz'
    lines=decoded(h/'pr-source'/f'job-{jid}.log.gz').decode().splitlines()
    candidates=[]
    for i,line in enumerate(lines):
        m=re.search(r'\bref: ([0-9a-f]{40})$',line)
        if m and any('path: .source-gate-automation' in x for x in lines[i+1:i+5]): candidates.append((i+1,m.group(1)))
    assert len(candidates)==1
    refline, auto=candidates[0]
    hits=[i+1 for i,line in enumerate(lines) if line.endswith('Z '+auto) and i and 'git log -1 --format=%H' in lines[i-1]]
    assert len(hits)==1
    identities=[json.loads(line[line.index('{'):]) for line in lines if 'revealline-source-identity.v1' in line]
    assert len(identities)==2 and identities[0]==identities[1] and identities[0]['sourceRevision']==SOURCE and identities[0]['sourceTree']==TREE
    ap=h/'pr-automation'; sp=h/'source-executed'; records=[]
    original=api(f'repos/{REPO}/git/commits/{auto}'); commit=json.loads(original); assert commit['sha']==auto
    put(ap/'commit.json',original)
    for path in FILES:
        original=api(f'repos/{REPO}/contents/{path}?ref={auto}'); value=json.loads(original)
        assert value['path']==path and value['encoding']=='base64' and value['html_url']==f'https://github.com/{REPO}/blob/{auto}/{path}'
        data=base64.b64decode(value['content']); source=git('show',SOURCE+':'+path); blob=git('rev-parse',SOURCE+':'+path).decode().strip()
        assert data==source and value['sha']==blob, 'Executed automation differs from reviewed source: '+path
        name=path.replace('/','__'); put(ap/(name+'.api.json'),original); put(ap/name,data); put(sp/name,source)
        records.append({'path':path,'gitBlob':blob,'bytes':len(data),'sha256':sha(data),'byteEqualToPinnedProductSource':True})
    objput(ap/'receipt.json',{'observedAutomationRef':auto,'observedAutomationTree':commit['tree']['sha'],
        'observedInLog':relative,'observedAtLine':refline,'actualCheckoutCommitLine':hits[0],
        'workflowShaBasis':'Actual preflight checkout ref and git log result; distinct from product source and later main merge.',
        'sourceUnderTest':SOURCE,'sourceTree':TREE,'preflightIdentityObservations':identities,'files':records})
    objput(sp/'receipt.json',{'sourceRevision':SOURCE,'sourceTree':TREE,'files':records,
        'scope':'Exact Git bodies equal actual executed automation API originals; no local helper execution.'})
    print(json.dumps({'status':'ACTUAL_AUTOMATION_RETAINED','source':SOURCE,'automation':auto,'automationTree':commit['tree']['sha']}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['manual','pr-source','automation']);args=p.parse_args()
    assert git('rev-parse',SOURCE+'^{tree}').decode().strip()==TREE
    unchanged = git('rev-parse','HEAD').decode().strip()==SOURCE and git('status','--porcelain','--untracked-files=no')==b''
    if args.action=='automation':
        assert unchanged, 'Successful qualification requires the unchanged exact source'
        automation()
    else:
        if not unchanged:
            # A reviewed correction may proceed while the last failed-attempt shard finishes.
            # Only retain that already-proven failed family; never derive success from it.
            failure = load(HERE/'failed-shard1-diagnosis.json')
            assert failure['source']==SOURCE
            proof=[row for row in failure['jobs'] if row['family']==args.action]
            assert len(proof)==1 and proof[0]['failedTests']
            job=load(OUT/'hosted'/args.action/f'job-{proof[0]["job"]}.json')
            assert job['head_sha']==SOURCE and job['run_id']==RUNS[args.action] and job['run_attempt']==RUN_RECORDS[args.action]['attempt'] and job['status']=='completed' and job['conclusion']=='failure'
        collect(args.action)
