"""Root-delegated actor correction GET-only intake; no final/public acceptance."""
from pathlib import Path
import hashlib,json,subprocess,shutil,os
HERE=Path(__file__).resolve().parent
BIND=json.loads((HERE/'intake-binding.json').read_bytes())
assert BIND['status']=='DELEGATED_READ_ONLY_INTAKE_BINDING_NOT_FINAL_ROOT_QUALIFICATION'
ROOT=Path(BIND['repositoryRoot']);WT=Path(BIND['sourceWorktree'])
SOURCE=BIND['source']['commit'];TREE=BIND['source']['tree'];VERSION=BIND['source']['version']
assert SOURCE=='80efcc3ddda302a014c3409c248892f36b3a12a9' and TREE=='28710b13cedc3bf2a7a1f4ec7bbfeb9282f83947' and VERSION=='v0.61.22'
assert HERE==ROOT/'.cache/p08-actor-minimum-next/source-qualification-v06122-r2/observer'
assert not any(p.is_symlink() for p in [HERE,*HERE.parents,WT])
assert BIND['rootDispatchOriginalPins'], 'Bind actual root dispatch and discovery first'
for row in BIND['rootDispatchOriginalPins']:
 p=Path(row['path']);assert p.is_relative_to(ROOT/'.cache/p08-actor-minimum-next/source-qualification-v06122-r2') and p.is_file() and not p.is_symlink()
 raw=p.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
assert BIND['branch']=='codex/p08-actor-minimum-next' and BIND['pullRequest']==139
RUN_RECORDS=BIND['runs'];assert set(RUN_RECORDS)=={'manual','pr-source'}
for family,event,path in [('manual','workflow_dispatch','.github/workflows/qualify-release-source.yml'),('pr-source','pull_request','.github/workflows/deploy-pages.yml')]:
 record=RUN_RECORDS[family];assert type(record['id']) is int and record['id']>0 and record['attempt']==1
 run=json.loads((HERE/'hosted-observation-r1'/(family+'-initial.json')).read_bytes())
 assert run['id']==record['id'] and run['created_at']==record['createdAt'] and run['run_attempt']==record['attempt']
 assert run['head_sha']==SOURCE and run['head_commit']['tree_id']==TREE and run['head_branch']==BIND['branch']
 assert run['event']==event and run['path']==path
RUNS={k:v['id'] for k,v in RUN_RECORDS.items()};assert len(set(RUNS.values()))==2
assert subprocess.check_output(['git','-C',str(WT),'rev-parse',SOURCE+'^{tree}'],env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0'}).decode().strip()==TREE
assert BIND['limits']=={'cacheBytes':33554432,'freeReserveBytes':536870912}
assert shutil.disk_usage(HERE).free>=BIND['limits']['freeReserveBytes']
assert sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())<=BIND['limits']['cacheBytes']
