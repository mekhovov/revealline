"""One finite, spaced observer of two exact attempts; GET-only originals, no retries."""
from pathlib import Path
import datetime,json,os,subprocess,sys,time,traceback
from collect_hosted import HERE,BIND,SOURCE,TREE,RUN_RECORDS,RUNS,api,put,objput,load
OBS=HERE/'observations'
UTC=datetime.timezone.utc
FLOWS={'manual':('workflow_dispatch','.github/workflows/qualify-release-source.yml'),'pr-source':('pull_request','.github/workflows/deploy-pages.yml')}
START=HERE/'hosted-observation-r1/runs-initial.receipt.json'
MIN_SECONDS=180
MAX_OBSERVATIONS=12

def invoke(name,args,where):
 command=[sys.executable,str(HERE/name),*args]
 result=subprocess.run(command,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_NO_LAZY_FETCH':'1'})
 put(where/'stdout',result.stdout);put(where/'stderr',result.stderr)
 objput(where/'command.json',{'command':command,'exitCode':result.returncode,'at':datetime.datetime.now(UTC).isoformat()})
 assert result.returncode==0, f'{name} {args} failed; originals retained under {where}'

previous=[p for p in OBS.glob('*/summary.json')] if OBS.exists() else []
assert len(previous)<MAX_OBSERVATIONS, 'Finite observation budget already consumed'
for observation in range(len(previous)+1,MAX_OBSERVATIONS+1):
 summaries=[load(p) for p in OBS.glob('*/summary.json')] if OBS.exists() else []
 latest=max([datetime.datetime.fromisoformat(load(START)['completedAt'])]+[datetime.datetime.fromisoformat(s['completedAt']) for s in summaries])
 while (remaining:=MIN_SECONDS-(datetime.datetime.now(UTC)-latest).total_seconds())>0:
  time.sleep(min(60,remaining))
 now=datetime.datetime.now(UTC);slot=OBS/now.strftime('%Y%m%dT%H%M%S%fZ');states={}
 for family,rid in RUNS.items():
  terminal=HERE/'intake/hosted'/family/'run.json'
  if terminal.exists():
   run=load(terminal);jobs=load(terminal.parent/'jobs.json')
  else:
   raw=api(f"repos/{BIND['repository']}/actions/runs/{rid}");put(slot/(family+'-run.json'),raw);run=json.loads(raw)
   assert run['id']==rid and run['head_sha']==SOURCE and run['head_commit']['tree_id']==TREE
   assert run['run_attempt']==RUN_RECORDS[family]['attempt'] and run['created_at']==RUN_RECORDS[family]['createdAt']
   assert (run['event'],run['path'])==FLOWS[family]
   raw=api(f"repos/{BIND['repository']}/actions/runs/{rid}/attempts/{run['run_attempt']}/jobs?per_page=100");put(slot/(family+'-jobs.json'),raw);jobs=json.loads(raw)
   assert jobs['total_count']==len(jobs['jobs'])<=20
   assert all(j['run_id']==rid and j['head_sha']==SOURCE and j['run_attempt']==run['run_attempt'] for j in jobs['jobs'])
   if run['status']=='completed':invoke('collect_hosted.py',[family],slot/('collect-'+family))
  states[family]={'run':rid,'attempt':run['run_attempt'],'status':run['status'],'conclusion':run['conclusion'],'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion']}for j in jobs['jobs']]}
 summary={'observation':observation,'completedAt':datetime.datetime.now(UTC).isoformat(),'source':SOURCE,'tree':TREE,'families':states,'minSpacingSeconds':MIN_SECONDS,'maximumObservations':MAX_OBSERVATIONS}
 objput(slot/'summary.json',summary)
 print(json.dumps(summary),flush=True)
 if all(s['status']=='completed' for s in states.values()):
  if all(s['conclusion']=='success' for s in states.values()):
   invoke('collect_hosted.py',['automation'],slot/'collect-automation')
   invoke('derive-hosted-evidence.py',[],slot/'derive-hosted')
  objput(HERE/'terminal-observation.json',{'completedAt':datetime.datetime.now(UTC).isoformat(),'source':SOURCE,'tree':TREE,'families':states,'scope':'Original terminal intake; no frozen inspection, final qualification or public acceptance.'})
  break
else:
 objput(HERE/'finite-window-complete.json',summary)
