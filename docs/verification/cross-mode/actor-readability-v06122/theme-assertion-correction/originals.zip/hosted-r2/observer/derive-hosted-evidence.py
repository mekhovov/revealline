"""Derive new P08 actor-size correction hosted source records from completed original bodies. No tests/builds/network/qualification assembly."""
from pathlib import Path
import subprocess as s,json,gzip,re,hashlib,datetime
from collect_hosted import HERE, WT as wt, OUT, SOURCE as source, TREE as tree, RUNS as runs, sha, load, git, decoded, objput
h=OUT/'hosted';auto=load(h/'pr-automation/receipt.json')['observedAutomationRef']
assert git('rev-parse','HEAD').decode().strip()==source
assert git('rev-parse',source+'^{tree}').decode().strip()==tree
paths=sorted(p for p in git('ls-tree','-r','--name-only','-z',source).decode().split('\0') if any(p.startswith(r) for r in ['scripts/','game/','authoring/motion-lab/','platforms/desktop/test/','platforms/ios/test/']) and re.search(r'(?:^|/)(?:test-[^/]+|[^/]+\.test)\.mjs$',p))
expected={'sourceRevision':source,'sourceTree':tree,'runnerSha256':sha(git('show',source+':scripts/run-test-shard.mjs')),'count':len(paths),'shards':[{'shard':i,'total':4,'files':paths[i-1::4]} for i in range(1,5)]}
objput(h/'expected-test-partitions.json',expected)
preflight=[j for j in load(h/'pr-source/jobs.json')['jobs'] if j['name']=='preflight'];assert len(preflight)==1
observed_nodes=set(re.findall(r'node: (v[0-9.]+)',decoded(h/'pr-source'/f'job-{preflight[0]["id"]}.log.gz').decode()))
assert len(observed_nodes)==1
node=next(iter(observed_nodes));assert re.fullmatch(r'v20\.19\.\d+',node)
keys=['tests','pass','fail','cancelled','skipped','todo'];families={};alljobs={};identities=[];manualrows=[];prrows=[];totals={};steps=[]
def plain(raw):return re.sub(r'^\d{4}-\d\d-\d\dT[\d:.]+Z ','',re.sub(r'\x1b\[[0-9;]*m','',raw.decode()),flags=re.M)
def exact_step(job,name):
 found=[x for x in job['steps'] if x['name']==name];assert len(found)==1 and found[0]['status']=='completed' and found[0]['conclusion']=='success';return found[0]
for family,rid in runs.items():
 run=load(h/family/'run.json');jobs=load(h/family/'jobs.json');assert run['id']==rid and run['head_sha']==source and type(run['run_attempt']) is int and run['run_attempt']>0 and run['status']=='completed' and run['conclusion']=='success';assert jobs['total_count']==len(jobs['jobs']);by={j['name']:j for j in jobs['jobs']};assert len(by)==len(jobs['jobs']);families[family]=by
 total=dict.fromkeys(keys,0)
 names=[('qualify' if family=='manual' else 'preflight'),*([f'test ({i})' for i in range(1,5)]),('freeze' if family=='manual' else 'build')]
 for name in names:
  job=by[name];assert job['run_id']==rid and job['head_sha']==source and job['status']=='completed' and job['conclusion']=='success';alljobs[job['id']]=job
  path=h/family/f'job-{job["id"]}.log.gz';gz=path.read_bytes();raw=decoded(path);assert len(raw)<=20000000;text=plain(raw);lines=raw.decode().splitlines();relative=str(path.relative_to(h));steps.append({'family':family,'jobId':job['id'],'name':name,'steps':job['steps']})
  if family=='pr-source':
   assert auto in text
   exact_step(job,'Verify exact tracked source before commands');exact_step(job,'Verify tracked source after '+('preflight' if name=='preflight' else 'build' if name=='build' else 'test shard'))
   seen=[]
   for idx,line in enumerate(lines,1):
    if 'revealline-source-identity.v1' in line:
     value=json.loads(line[line.index('{'):]);assert value['sourceRevision']==source and value['sourceTree']==tree and value['allTrackedSourceContentsAndModesMatch'] is True;seen.append({'path':relative,'line':idx,'identity':value,'matchesExpected':True})
   assert len(seen)==2 and seen[0]['identity']==seen[1]['identity'];identities.extend(seen)
  assert set(re.findall(r'^node: (v[0-9.]+)$',text,re.M))=={node}
  match=re.fullmatch(r'test \((\d)\)',name)
  if match:
   i=int(match.group(1));files=next(x['files'] for x in expected['shards'] if x['shard']==i);count={k:int(re.findall(r'^# '+k+r' (\d+)$',text,re.M)[-1]) for k in keys};assert count['tests']==count['pass']>0 and all(count[k]==0 for k in keys[2:])
   for k in keys:total[k]+=count[k]
   marker=f'Running {len(files)}/{expected["count"]} test files in shard {i}/4.';assert marker in text;step=exact_step(job,f'Run test shard {i}/4')
   if family=='manual':
    ordered=[l for l in text.splitlines() if l in set(files)];assert ordered==files
    manualrows.append({'shard':i,'jobId':job['id'],'count':len(files),'exactOrderedFileListMatchesPinnedGit':True,'files':files})
   else:
    prrows.append({'shard':i,'jobId':job['id'],'conclusion':'success','count':len(files),'runnerSelectionMatchesPinnedGit':True,'files':files,'log':relative,'gzipCarrierSha256':sha(gz),'rawLogSha256':sha(raw),'actualRunnerMarkerLine':next(idx+1 for idx,line in enumerate(lines) if marker in line),'actualStep':step})
 totals[family]=total
assert totals['manual']==totals['pr-source'];assert len(identities)==12
withoutroot=lambda x:{k:v for k,v in x.items() if k!='root'};reference=withoutroot(identities[0]['identity']);assert all(withoutroot(x['identity'])==reference for x in identities)
for family,names in [('manual',['Validate source','Lint source','Check formatting','Check native formatting','Check motion lab syntax','Reproduce production collection when available','Require reviewed production slots in the committed ledger']),('pr-source',['Validate, lint, and format source','Verify Field Kit production ledger and compiled output','Verify immutable production sources first'])]:
 job=families[family]['qualify' if family=='manual' else 'preflight']
 for name in names:exact_step(job,name)
exact_step(families['pr-source']['build'],'Build pull-request artifact')
for name in ['Freeze the exact qualified commit','Retain original release assets']:exact_step(families['manual']['freeze'],name)
# Assertions above complete before exclusive new derived records are written.
def put(name,value):
 p=h/name;assert not p.exists();objput(p,value)
put('source-identities.json',identities)
put('partition-coverage.json',{'sourceRevision':source,'count':expected['count'],'allFourShardsExactlyMatch':True,'shards':sorted(manualrows,key=lambda x:x['shard'])})
put('pr-partition-coverage.json',{'format':'revealline-pr-partition-review.v1','sourceRevision':source,'sourceTree':tree,'automationRevision':auto,'count':expected['count'],'allFourRunnerSelectionsMatch':True,'runnerSha256':expected['runnerSha256'],'shards':sorted(prrows,key=lambda x:x['shard']),'scope':'Actual completed PR steps/start markers, exact executed runner bytes and before/after tracked identities establish deterministic source selections. File lists are inferred from the pinned runner contract, not PR per-file event traces. Manual partition proof separately verifies explicit ordered file lists.'})
put('job-step-records.json',steps)
put('review.json',{'sourceRevision':source,'sourceTree':tree,'sourceRunsCompleted':True,'allSourceRunGatesPassed':True,'allObservedIdentitiesMatch':True,'sourceIdentityObservations':len(identities),'sourceTestTotals':totals,'testFiles':expected['count'],'hostedNodeVersion':node,'ordinaryBuildPassed':True,'freezePassed':True,'scope':'Actual terminal source APIs/logs and source partitions only. Frozen original inspection, final source qualification, release and public acceptance remain separate.'})
rows=[]
for p in sorted(h.rglob('*')):
 if p.is_file():
  b=p.read_bytes();rows.append({'path':str(p.relative_to(h)),'bytes':len(b),'sha256':sha(b)})
put('final-evidence-manifest.json',{'count':len(rows),'bytes':sum(x['bytes'] for x in rows),'files':rows,'scope':'Exact retained original/derived hosted evidence; not a source qualification receipt.'})
print(json.dumps({'status':'HOSTED_EVIDENCE_DERIVED_NOT_QUALIFIED','sourceRevision':source,'sourceTree':tree,'files':expected['count'],'totals':totals,'sourceIdentityBoundaries':len(identities),'retainedFiles':len(rows)}))
