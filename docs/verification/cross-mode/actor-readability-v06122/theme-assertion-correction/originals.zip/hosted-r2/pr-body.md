Narrow fitted boards could shrink actors below their intended displayed size or clip the Solo/Versus craft at arena edges. Preserve the CSS minimum and keep the craft illustration inside the arena while leaving contact, trail/head, collision, simulation and saves unchanged.

Version0.61.22 includes the runtime tests, rendering contract and animation prompts. The production ledger now appends the source and scoped-reviewed motion revisions, retains127 original payloads and previous approvals, and keeps Team artwork bindings strict. Failed initial preflights and their correction are preserved in indexed original evidence.

The100 affected rendering tests passed on Node20/22; scoped native edge/cut checks passed. Production reproduction and exact committed-ledger readiness pass on both runtimes at80efcc3ddda302a014c3409c248892f36b3a12a9. Full source CI/freeze and deployed acceptance remain required. Large HUD, all-role visual review, physical hardware and whole P08 remain open.
