import {readFileSync} from 'node:fs';
export async function load(url,context,next) {
 if (url === "file:///Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/p08-actor-minimum-next/game/ui/render.mjs") return {format:'module',shortCircuit:true,source:readFileSync("/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/p08-actor-minimum-next/inset-successor-r3/pre-inset-render.original.mjs",'utf8')};
 return next(url,context);
}
