# Solo / Versus craft inset

The exact v0.61.21 painter and the minimum-size candidate both place the craft at the true simulation point. A top safe-cell center is eight logical pixels inside the canvas, less than half of the displayed body. The inherited placement clips the source rectangle and rotors at the canvas edge. Native screenshots 02 and 03 retain this limitation; they do not establish a baseline native comparison.

Use the actual paintCharacter transform: fitted contained image, presentation pivot, heading plus body heading offset, and shear/bank (not Team’s diagonal scaling). A pure layout helper encloses the source rectangle, center mark, full rotor sweep, fallback marker, shadow and complete recipe attachment envelopes. Apply only the smallest inward translation of that conservative envelope, with one CSS pixel margin. Keep contact, active cut/head, shield/ability centers, core/checkpoints/saves and artwork unchanged. A thin muted connector underneath the craft relates the moved illustration to its exact contact ring.

Tests must inspect actual painter commands after transforms, all edges/corners, cardinal and diagonal headings, both bank signs, compact/detailed/asymmetric/missing images, rotor phases and reduced motion. Interior placement must remain exact. Native recognition and body/contact association after this successor remain unverified.
