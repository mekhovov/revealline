from pathlib import Path
import os,json,hashlib,subprocess,shutil,datetime
root=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test');wt=root/'.cache/worktrees/p08-actor-minimum-next';c=root/'.cache/p08-actor-minimum-next/production-correction';env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0'}
def git(*args):return subprocess.check_output(['git',*args],cwd=wt,env=env)
def pin(p):
 raw=p.read_bytes();return {'path':str(p.relative_to(root)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(name,obj):
 p=c/name;assert not p.exists();p.write_text(json.dumps(obj,indent=2)+'\n');return pin(p)
source='307f46382a580b877a99123b3a7df7d9bc53dd40';assert git('rev-parse','HEAD').decode().strip()==source
assert not git('diff','--cached','--name-only')
paths=sorted(git('diff','--name-only').decode().splitlines()+git('ls-files','--others','--exclude-standard').decode().splitlines())
expected=['authoring/library/fpv-field-kit/production.rltheme','game/couch/coop-picture-bindings.mjs','game/presentation/compiled/manifest.json','game/presentation/compiled/runtime.json','game/presentation/compiled/studio.json','game/test/presentation-production-history.test.mjs','scripts/produce-field-kit-theme.mjs','docs/actor-size-recipe-review.md'];assert paths==sorted(expected),paths
rows=[]
for p in paths:
 raw=(wt/p).read_bytes();old=git('show',source+':'+p) if p!='docs/actor-size-recipe-review.md' else None
 rows.append({'path':p,'mode':'100644','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'priorSHA256':hashlib.sha256(old).hexdigest() if old else None,'binary':p.endswith('.rltheme')})
patch=git('diff','--binary','--full-index','--',*paths)
p='docs/actor-size-recipe-review.md';add=subprocess.run(['git','diff','--no-index','--','/dev/null',p],cwd=wt,env=env,capture_output=True);assert add.returncode==1
patch+=add.stdout;assert len(patch)<1024**2;(c/'source.patch').write_bytes(patch)
manifest=put('candidate-pins.json',{'source':source,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'paths':rows})
checks=[]
for label in ['check-node20','check-node22','final-ledger-audit','focused-node20','focused-node22','focused-current-authority-node20','focused-current-authority-node22','committed-readiness-expected-refusal','lint','test-lint','final-format-check','final-diff-check']:
 r=json.loads((c/label/'receipt.json').read_text());expected_exit=1 if label in ['focused-node20','focused-node22','committed-readiness-expected-refusal'] else 0;assert r['exit']==expected_exit,(label,r['exit']);checks.append({'label':label,'receipt':pin(c/label/'receipt.json'),'exit':r['exit'],'outputs':[pin(c/label/n) for n in ['stdout','stderr']]})
audit=json.loads((c/'final-ledger-audit/stdout').read_text());assert audit['readiness']['passed'] is True
checks_pin=put('checks.json',{'checks':checks,'focusedSummary':'Each Node: original 57 passing cases plus the corrected exact-authority case passes; 58 distinct passing cases across retained cohorts, not a single green 58-case rerun. Node20 selected rerun reports 10 intentionally skipped nonmatching cases.','committedGate':'Expected refusal until root commits exact ledger; not claimed passing.','preservation':{'priorLedgerSHA256':audit['ledgerBeforeSHA256'],'ledgerSHA256':audit['ledgerAfterSHA256'],'beforeRevision':28,'afterRevision':30,'preservedPayloads':127,'actorRuntimePathsUnchanged':audit['actorPathsUnchanged'],'workingReadiness':audit['readiness']}})
free=shutil.disk_usage(root).free;assert free>512*1024**2
ready=put('ready.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'Local uncommitted correction ready for root hunk review; independent peer review pending','worktree':str(wt),'source':source,'sourceTree':git('rev-parse','HEAD^{tree}').decode().strip(),'pathCount':len(rows),'changedBytes':sum(x['bytes'] for x in rows),'candidatePins':manifest,'patch':pin(c/'source.patch'),'checks':checks_pin,'scope':'Append production fpv29 source stage and fpv30 scoped-reviewed motion successor; preserve prior approvals and all payloads; strict Team consumers use30; current authority test matches new exact digest. No actor runtime/simulation/version edits.','open':['Root must commit exact bytes then run committed-ledger readiness and full exact-source CI.','No additional native/public/whole-phase acceptance inferred; narrow Large HUD overflow remains separate.'],'freeBytes':free,'reserveBytes':512*1024**2,'indexUnchanged':True,'ownedDependencyLinkRemoved':pin(c/'dependency-link-cleanup.json')});print(json.dumps(ready,indent=2))
