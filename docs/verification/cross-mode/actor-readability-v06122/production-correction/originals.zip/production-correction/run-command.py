from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys, time

cache = Path(__file__).resolve().parent
root = cache.parents[2]
worktree = root / '.cache/worktrees/p08-actor-minimum-next'
env = {**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_OPTIONAL_LOCKS': '0'}
label, *command = sys.argv[1:]
assert command and not (cache / label).exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, env=env).decode().strip() == '307f46382a580b877a99123b3a7df7d9bc53dd40'
assert shutil.disk_usage(root).free > 512 * 1024**2 + 48 * 1024**2
started = time.monotonic()
try:
    result = subprocess.run(command, cwd=worktree, env=env, capture_output=True, timeout=180)
    stdout, stderr, status = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as error:
    stdout, stderr, status = error.stdout or b'', error.stderr or b'', 'timeout'
assert len(stdout) + len(stderr) <= 2 * 1024**2
assert shutil.disk_usage(root).free > 512 * 1024**2 + len(stdout) + len(stderr)
out = cache / label
out.mkdir()
(out / 'stdout').write_bytes(stdout)
(out / 'stderr').write_bytes(stderr)
receipt = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'command': command, 'exit': status, 'elapsedSeconds': time.monotonic() - started,
           'source': '307f46382a580b877a99123b3a7df7d9bc53dd40',
           'outputs': {name: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
                       for name, raw in [('stdout', stdout), ('stderr', stderr)]}}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
print(stdout.decode()[-2400:])
print(stderr.decode()[-2400:])
