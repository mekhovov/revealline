import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

const root = fileURLToPath(new URL('../../../', import.meta.url));
const worktree = path.join(root, '.cache/worktrees/p08-actor-minimum-next');
const source = '307f46382a580b877a99123b3a7df7d9bc53dd40';
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const git = (...args) => execFileSync('git', args, {
  cwd: worktree, maxBuffer: 32 * 1024 ** 2,
  env: { ...process.env, GIT_NO_LAZY_FETCH: '1', GIT_OPTIONAL_LOCKS: '0' },
});
assert.equal(git('rev-parse', 'HEAD').toString().trim(), source);
const { importThemeBundle } = await import(pathToFileURL(path.join(worktree, 'game/presentation/bundle.mjs')));
const { checkFieldKitReadiness } = await import(pathToFileURL(path.join(worktree, 'scripts/check-field-kit-readiness.mjs')));
const ledger = 'authoring/library/fpv-field-kit/production.rltheme';
const original = git('show', `${source}:${ledger}`);
const current = await fs.readFile(path.join(worktree, ledger));
const before = await importThemeBundle(new Blob([original]), { decodeImage: null });
const after = await importThemeBundle(new Blob([current]), { decodeImage: null });
const retained = {};
for (const key of ['slots', 'assets', 'themes', 'collections']) {
  assert.deepEqual(after.document[key].slice(0, before.document[key].length), before.document[key]);
  retained[key] = { before: before.document[key].length, after: after.document[key].length };
}
for (const [sha, body] of before.assets) {
  assert.ok(after.assets.has(sha));
  assert.deepEqual(Buffer.from(await body.arrayBuffer()), Buffer.from(await after.assets.get(sha).arrayBuffer()));
}
assert.equal(after.assets.size, before.assets.size);
const oldManifest = JSON.parse(git('show', `${source}:game/presentation/compiled/manifest.json`));
const newManifest = JSON.parse(await fs.readFile(path.join(worktree, 'game/presentation/compiled/manifest.json')));
assert.deepEqual(newManifest.files.map((row) => row.path), oldManifest.files.map((row) => row.path));
let preservedPayloads = 0;
for (const row of oldManifest.files.filter((entry) => entry.path.startsWith('assets/'))) {
  const bytes = await fs.readFile(path.join(worktree, 'game/presentation/compiled', row.path));
  assert.equal(bytes.length, row.bytes);
  assert.equal(hash(bytes), row.sha256);
  assert.deepEqual(newManifest.files.find((entry) => entry.path === row.path), row);
  preservedPayloads++;
}
const candidate = JSON.parse(await fs.readFile(path.join(root, '.cache/p08-actor-minimum-next/inset-successor-r3/source-manifest.json')));
const actorPaths = ['game/ui/actor-presentation.mjs', 'game/ui/render.mjs', 'game/ui/player-body-layout.mjs'];
for (const name of actorPaths) {
  const row = candidate.paths.find((entry) => entry.path === name);
  assert.equal(hash(await fs.readFile(path.join(worktree, name))), row.sha256);
  assert.equal(hash(git('show', `${source}:${name}`)), row.sha256);
}
let readiness;
try {
  readiness = { passed: true, result: await checkFieldKitReadiness(new Blob([current])) };
} catch (error) {
  readiness = { passed: false, error: error.message,
    unresolved: (error.unresolved ?? []).map((row) => ({ slotId: row.slotId, stage: row.stage, asset: row.asset && { id: row.asset.id, revision: row.asset.revision } })) };
}
console.log(JSON.stringify({ source, ledgerBeforeSHA256: hash(original), ledgerAfterSHA256: hash(current),
  beforeRevision: before.document.revision, afterRevision: after.document.revision,
  beforeSelection: before.document.selection, afterSelection: after.document.selection,
  retained, preservedPayloads, immutableAssetBodies: before.assets.size,
  additions: after.document.assets.slice(before.document.assets.length),
  actorPathsUnchanged: actorPaths, readiness,
  scope: 'Working ledger declaration and exact original preservation; committed-source readiness remains a subsequent root gate.' }, null, 2));
