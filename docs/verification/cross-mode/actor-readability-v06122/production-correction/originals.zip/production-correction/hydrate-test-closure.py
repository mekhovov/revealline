from pathlib import Path
import os,re,json,hashlib,subprocess,posixpath,shutil
root=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test'); wt=root/'.cache/worktrees/p08-actor-minimum-next'; out=root/'.cache/p08-actor-minimum-next/production-correction'
env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0'}
def git(*args):return subprocess.check_output(['git',*args],cwd=wt,env=env)
assert git('rev-parse','HEAD').decode().strip()=='307f46382a580b877a99123b3a7df7d9bc53dd40'
tracked=set(git('ls-tree','-r','--name-only','HEAD').decode().splitlines()); todo=['game/test/'+x for x in ['coop-picture-bindings.test.mjs','coop-picture-host.test.mjs','presentation-production-history.test.mjs','presentation-readiness.test.mjs']];seen=set();missing=[]
while todo:
 p=todo.pop()
 if p in seen:continue
 seen.add(p);raw=git('show','HEAD:'+p)
 if not (wt/p).exists():missing.append((p,raw))
 if p.endswith(('.mjs','.js','.html')):
  text=raw.decode()
  specs=re.findall(r'(?:from\s*|import\s*\(|import\s*|new URL\s*\()\s*[\"\'](\.[^\"\']+)[\"\']',text)
  for spec in specs:
   path=posixpath.normpath(posixpath.join(posixpath.dirname(p),spec.split('?')[0]))
   if path in tracked and not path.endswith('.rltheme'):todo.append(path)
assert sum(len(raw) for _,raw in missing)<4*1024**2
assert shutil.disk_usage(root).free>512*1024**2+sum(len(raw) for _,raw in missing)
sp=Path(git('rev-parse','--git-path','info/sparse-checkout').decode().strip());sp=sp if sp.is_absolute() else wt/sp
before=sp.read_bytes();(out/'sparse-before-test-closure.txt').write_bytes(before)
sp.write_bytes(before+b''.join(('/'+p+'\n').encode() for p,_ in missing))
rows=[]
for p,raw in missing:
 dest=wt/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);rows.append({'path':p,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
record={'source':git('rev-parse','HEAD').decode().strip(),'closurePaths':len(seen),'newFiles':len(rows),'newBytes':sum(r['bytes'] for r in rows),'files':rows,'freeAfter':shutil.disk_usage(root).free}
(out/'test-hydration.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='files'}))
