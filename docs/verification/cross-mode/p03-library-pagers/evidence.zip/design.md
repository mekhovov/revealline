# Stable Library pager owner

Base87f integrates9d43 row source with7958 composed guidance. Production boundary is Library pager state/paginate/renderScores and populateGallery/renderGallery completion only. No operation-focus helper, gallery-view close/finishReturn, core, profile or schema change.

Cache Previous/count/Next nodes per existing #score-pages and #gallery-pages. Update page/callback/disabled state; keep an enabled focused control untouched. Resolve a current owned unavailable action to opposite enabled pager, then #score-search or #gallery-search. Gallery single-page collapse hides and detaches cached controls; later expansion reuses them.

Capture focus before render/read. An automatic newer read transfers the exact same lease and its retired state through a pager-local ticket; stale completion loses its focus reference. A fresh actual focused pager activation alone captures new permission. Recheck accepted render generation and exact current library identity before draw/focus, plus helper post-resolver same-root/connected/visible/foreground checks. No fallback executes an action.

The adjacent gallery-view finishReturn stale focus gap is being addressed separately in another worktree. Preserve this pager owner while composing that return owner. Later main ec288a4 adds qualification-prompt guidance and must be merged by hunk, not overwritten.
