import { readFile } from 'node:fs/promises';
const target = "file:///Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/p03-library-pagers/game/ui/library-panel.mjs";
export async function load(url, context, nextLoad) {
 if (url === target) return {format:'module', shortCircuit:true, source:await readFile(new URL('./baseline-library-panel.mjs', import.meta.url), 'utf8')};
 return nextLoad(url, context);
}
