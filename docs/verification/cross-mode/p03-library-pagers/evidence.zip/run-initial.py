from pathlib import Path
import subprocess,hashlib,json,time
r=Path(__file__).resolve().parents[2];c=Path(__file__).resolve().parent
pin=lambda p:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def inventory():
 return [{'path':str(p.relative_to(r)),**pin(p)} for p in sorted((r/'game').rglob('*')) if p.is_file() and not p.is_symlink()]
before=inventory();(c/'initial-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
cmd=['/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node','--test','--test-concurrency=1','game/test/library-pager-host.test.mjs','game/test/gallery-focus.test.mjs']
t=time.monotonic()
with (c/'initial-node22.log').open('xb') as f: result=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,timeout=180)
after=inventory();(c/'initial-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
record={'command':cmd,'exitCode':result.returncode,'seconds':time.monotonic()-t,'inputsUnchanged':before==after,'log':pin(c/'initial-node22.log'),'runner':pin(Path(__file__))}
(c/'initial-node22.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
print('\n'.join((c/'initial-node22.log').read_text().splitlines()[-12:]),flush=True)
