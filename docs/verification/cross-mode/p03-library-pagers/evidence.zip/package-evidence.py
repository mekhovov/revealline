from pathlib import Path
import hashlib,json,zipfile,shutil
ROOT=Path(__file__).resolve().parents[2]
CACHE=Path(__file__).resolve().parent
DEST=ROOT/'docs/verification/cross-mode/p03-library-pagers'
FLOOR=256*1024*1024

def digest(b): return hashlib.sha256(b).hexdigest()
def main():
    if shutil.disk_usage(ROOT).free<FLOOR: raise RuntimeError('Reserve is below256MiB')
    review=CACHE/'native-verification.json'
    if not review.is_file(): raise RuntimeError('Native record must be closed and verified before packaging')
    files=[]
    for p in sorted(CACHE.rglob('*')):
        if p.is_symlink(): raise RuntimeError('Unexpected linked cache member')
        if not p.is_file() or '__pycache__' in p.parts: continue
        if p.name.startswith(('package-held','package-check','commit-receipt','staged-review')): continue
        if p.suffix not in {'.mjs','.json','.py','.diff','.txt','.log','.bin','.md','.png','.html'}: continue
        if p.stat().st_size>8*1024*1024: raise RuntimeError('Oversized evidence member')
        files.append(p)
    if sum(p.stat().st_size for p in files)>16*1024*1024: raise RuntimeError('Evidence scope too large')
    rows=[]
    zpath=DEST/'evidence.zip'
    with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for p in files:
            b=p.read_bytes(); member=str(p.relative_to(CACHE))
            info=zipfile.ZipInfo(member,(2026,9,15,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            archive.writestr(info,b)
            rows.append({'source':str(p.relative_to(ROOT)),'member':member,'bytes':len(b),'sha256':digest(b)})
    with zipfile.ZipFile(zpath) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist())==len(set(archive.namelist()))==len(rows)
        for row in rows:
            b=archive.read(row['member']);assert b==(ROOT/row['source']).read_bytes() and digest(b)==row['sha256']
    b=zpath.read_bytes()
    mapping={'scope':'Lossless originals for the isolated pager candidate. Native recorder was closed before intake. Simulated import fixture, native UI, source tests and failed diagnostics remain distinct. No artwork/browser profile copied.', 'archive':{'path':'evidence.zip','bytes':len(b),'sha256':digest(b),'members':len(rows),'decodedBytes':sum(r['bytes'] for r in rows)},'files':rows}
    (DEST/'evidence.json').write_text(json.dumps(mapping,indent=2)+'\n')
    print(json.dumps(mapping['archive']))
if __name__=='__main__':main()
