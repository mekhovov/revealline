from pathlib import Path
import json, hashlib, subprocess, time, datetime
wt=Path.cwd(); cache=wt/'.cache/couch-visible-focus/order-successor'
files=['game/test/couch-shell.test.mjs','game/test/couch-navigation.test.mjs']
admission=json.loads((cache.parent/'admission.json').read_text())
def pin(path):
 b=(wt/path).read_bytes(); return {'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def inputs(): return [pin(row['path']) for row in admission['paths']]
before=inputs(); (cache/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
results=[]
for version in ['22.22.2','20.19.5']:
 node=Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node')/version/'bin/node'
 command=[str(node),'--test',*files]; log=cache/f'whole-node{version.split(".")[0]}.log'; start=time.monotonic()
 with log.open('wb') as out: process=subprocess.run(command,cwd=wt,stdout=out,stderr=subprocess.STDOUT)
 result={'node':version,'command':command,'exitCode':process.returncode,'wallSeconds':round(time.monotonic()-start,3),'log':pin(str(log.relative_to(wt)))}; results.append(result); print(json.dumps(result),flush=True)
 if process.returncode: break
checks=[]
if all(r['exitCode']==0 for r in results) and len(results)==2:
 for name,command in [('lint',[str(Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node')),'node_modules/eslint/bin/eslint.js','game/couch/couch-shell.mjs','game/test/couch-shell.test.mjs']),('format',[str(Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node')),'node_modules/prettier/bin/prettier.cjs','--check','game/couch/couch-shell.mjs','game/test/couch-shell.test.mjs']),('diff',['git','diff','--check'])]:
  log=cache/f'{name}.log'
  with log.open('wb') as out: process=subprocess.run(command,cwd=wt,stdout=out,stderr=subprocess.STDOUT)
  checks.append({'name':name,'command':command,'exitCode':process.returncode,'log':pin(str(log.relative_to(wt)))})
after=inputs(); (cache/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt={'base':admission['base'],'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Two complete test files. Finite admitted physical input list, not a claimed complete runtime import graph or native geometry proof.','sourceHold':pin('.cache/couch-visible-focus/source-held-02.json'),'results':results,'checks':checks,'inputsUnchanged':before==after,'inputCount':len(before),'inputBytes':sum(p['bytes'] for p in before),'manifests':[pin('.cache/couch-visible-focus/order-successor/inputs-before.json'),pin('.cache/couch-visible-focus/order-successor/inputs-after.json')]}
(cache/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps({'receipt':pin('.cache/couch-visible-focus/order-successor/verification.json'),'inputsUnchanged':before==after,'checks':checks}),flush=True)
