# Final bounded Studio F2 qualification

The release owner allocated the complete twelve-file affected cohort on Node 20 and 22 at 100 MiB, plus explicit changed-file formatting and syntax checks. Both owned processes are terminal. No full suite, build, server, native browser, source/index mutation or publication ran in this packet.

| Check | Result | Evidence |
| --- | --- | --- |
| Node 22.22.2, sequential test files | 96/96 behaviors pass; zero groups/fail/skip/cancel/todo | [Log](proposal-node22.log), [command and hash](proposal-node22.json) |
| Node 20.19.5, same files and cases | 96/96 behaviors pass; zero groups/fail/skip/cancel/todo | [Log](proposal-node20.log), [command and hash](proposal-node20.json) |
| Explicit formatting | All eleven changed files pass | [Log](format-check.log), [command](format-check.json) |
| Syntax | Nine changed MJS files pass on both runtimes: eighteen checks | [Results](syntax-checks.json) |
| Final source identity | All 278 captured files unchanged; 134 baseline files match exact Git source; three match the qualified font overlay | [Pre-run inputs](inputs.json), [post-run and layer verification](input-verification.json) |

The 96 behaviors include nine new Interface authority tests, twelve new motion ownership tests and an extended actual Studio host test. The latter verifies live preferences during pending initialization, prepared source/preview identity, focus, unsaved sprite state, modeled persisted navigation and the permitted storage-write ledger. Remaining cases cover font cache/specimens, loading, picture context, audio, geometry, rotors, components and the shared preference authority. Genuine fixtures plus modeled DOM/media APIs do not prove native font matching, decoding, layout, touch or BFCache admission.

## Failure history and correction

1. [Attempt 1](../runtime-attempt1/proposal-node22.json) reported 93 passing behavior rows and two process failures. The isolated tree lacked committed motion-lab presets and an audio fixture. Exact original resources, including the referenced theme catalogue, were added to both trees; see [resource pins](../runtime-attempt1/fixture-correction.json). Node 20 was not started. The storage-write ledger was hardened after peer review so caught storage errors cannot hide an unexpected write.
2. [Attempt 2](../runtime-attempt2/proposal-node22.json) reported 95 passes and one actual host test failure before Studio could import. The closure collector had missed a query-isolated dynamic Studio entry and three committed dependencies. The [exact-source closure correction](../runtime-attempt2/dynamic-host-closure-correction.json) added them to both trees. No production behavior was changed for either fixture correction; Node 20 was not started on this failed attempt.
3. Attempt 3 ran every complete affected test file on Node 22 and then Node 20. Both passed. Formatting/syntax checks and final hash checks use those same candidate bytes.

Earlier logs and manifests were preserved. Failed harness/import starts are not passing behavior evidence, and the two runtimes do not double the distinct cases. The [candidate receipt](../candidate-receipt.json) binds this result to the eleven-path patch against the layered baseline.
