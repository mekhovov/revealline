# P05 Studio interface — implemented; bounded checks pass

17 September 2026. This isolated candidate adds readable Studio interface text, shared Interface preferences and live preview reduction. The complete twelve-file affected cohort passes **96 behavior cases on each of Node 20.19.5 and 22.22.2**, at the existing 100 MiB heap limit. There are no parent groups, failed, skipped, cancelled or todo cases. These are the same 96 cases run twice; the earlier 33-case font cohort is included, not additional coverage.

The candidate is based on committed `76dc4bf36baec11ce4dff6ca49773d3b9d6c0ae5` plus the separately qualified [font specimen/cache correction](../p05-font-cache-fix-76dc4bf3/README.md). The Studio increment has **eleven changed paths: eight production files and three test files**, including 21 new preference/motion cases and one extended actual Studio host journey. Adopting both font and Studio changes relative to bare 76dc affects thirteen paths, including the two inherited new font tests. Review the [exact incremental patch](proposal.diff), [candidate receipt](candidate-receipt.json) and [qualification record](runtime-attempt3/README.md).

## Resulting behavior

- Host body/control/secondary text uses 18/16/14px, or 22/20/18px in Large. Plain uses platform interface faces. Captions, instructions, recovery and technical metadata remain readable independently of preview theme overrides.
- Font, component and artwork specimens retain the selected theme identity. An authored validation-error example remains specimen content; the ordinary not-saved disclaimer remains host explanation.
- Interface controls use the existing shared display authority and remain available during authoring operations. Explicit choices update existing DOM without recreating the inspector, drafts, prepared media, sprite history or audio.
- Effective motion changes cancel or resume only owned preview frames. System reduction caps the retained local choice. Releasing the cap resumes Playing with a reset clock; local Paused or Reduced does not become Playing. Retired callbacks cannot restart an old preview.
- Persisted navigation retains the preference authority while existing Studio handlers retire and rebuild preview views. Terminal navigation disposes the authority. Modeled events verify ownership; actual BFCache admission and convergence remain untested here.

## Evidence and preserved failures

Explicit formatting passes for all eleven changed files; eighteen syntax checks pass across the two runtimes. All **137 baseline and 141 proposal files** still match their captured hashes. The baseline is independently checked as 134 exact committed files plus three exact qualified font-overlay files. No inherited simulation, audio or preference authority module is changed.

Two preceding attempts exposed incomplete isolated fixtures/import closure. Their raw failures and corrections remain under `runtime-attempt1/` and `runtime-attempt2/`; they do not establish product defects. Attempt 1 also prompted a test-only improvement to record storage-write attempts before validating the permitted key. See the [full test account](runtime-attempt3/README.md). Original static descriptions remain under `pre-runtime-update/`; `source-inputs.json` and `affected-cohort-inputs.json` retain their original capture-time status.

## Remaining acceptance

Follow the [native and integration checklist](native-acceptance.md) for actual computed fonts/sizes, EN/UA glyphs, theme isolation, contrast, wrapping, keyboard/touch/controller behavior, portrait/short landscape/zoom and real restoration/edit preservation. None of those are inferred from Node tests. The [lifecycle research](lifecycle-research.md) records why event ordering and unsaved local intent require actual browser checks.

This candidate covers Studio only. Team cues, font readiness, other P05 routes, Ukrainian palettes/components and full typography acceptance remain open. The release owner must compose reviewed hunks onto its current source, retain the independently prepared P04 preview repairs and qualify that combined result. The old P04 and current P05 test receipts cannot be combined into a new source pass. Proposed [maintainer and prompt additions](maintainer-prompt-addendum.md) travel with integration.

No owner checkout/index, version, historical candidate or release was changed. Exact committed-source gates, ordinary build, immutable release, Pages deployment and public play remain required before acceptance.
