# Final Studio F2 evidence review

**Verdict: pass for the exact captured bounded Node evidence.** I independently read the final raw logs and current sources, rehashed both trees, compared source layers with the exact Git commit and inherited font packet, and checked the final formatting/syntax/source-verification records. I ran no Node, formatter, browser, build or release command and changed no implementation or owner source/index.

## Sources and change scope

The captured baseline has exactly **137 files** and the proposal **141**, with no extra/missing files or hash changes from `runtime-attempt3/inputs.json`. The baseline contains 134 files identical to committed `76dc4bf36baec11ce4dff6ca49773d3b9d6c0ae5`, plus the three-file previously qualified font overlay. All 109 files inherited from that earlier candidate are unchanged. The final source-layer verification agrees with this independent comparison.

The Studio increment changes **11 paths: eight production and three test files**, including four new files. Its `proposal.diff` reconstructs exactly from the current baseline/proposal trees and matches the recorded patch hash. A combined adoption relative to bare `76dc` has **13 distinct paths: eight production and five tests**, because the two inherited new font test files remain part of that combined change; the shared preview file is already counted among the eleven Studio paths.

The font cache and selected-file specimen branches remain byte-identical within the modified preview file. Both inherited font tests also remain byte-identical. Their assertions were rerun against this composed Studio proposal on both runtimes, rather than borrowing the previous packet's pass status.

## Final results

| Runtime | Individual cases | Passed | Failed | Groups / skipped / cancelled / todo |
|---|---:|---:|---:|---:|
| Node 22.22.2 | 96 | 96 | 0 | 0 / 0 / 0 / 0 |
| Node 20.19.5 | 96 | 96 | 0 | 0 / 0 / 0 / 0 |

Both logs contain the same 96 numbered top-level subtest/result pairs and matching receipt summaries, with no nested group-result rows, assertion failures, process failures or harness crashes. Commands use the same twelve complete test files with `--max-old-space-size=100 --test --test-concurrency=1`. All log hashes agree with their metadata.

The 96 cases comprise six audio-master, two context-geometry, 15 font-cache, eight font-specimen, **one actual Studio host**, nine Interface adapter, six loading, four picture-context, 12 preview-motion, one rotor, 26 shared-display-authority, and six component-specimen cases. The host case's extra assertions and modeled persisted navigation are not counted as additional tests.

The prior review recommendations are now reflected in the executed source: live-generation stale-frame fencing and initial reduced-motion coverage are present; the host storage ledger records each attempted write before key validation and subsequently checks the whole ledger. The final host check therefore cannot silently omit a forbidden write merely because production code catches the thrown storage error.

## Format, syntax and limits

The explicit formatter check covers exactly the eleven changed paths, exits zero, and has a matching raw log/hash. Eighteen recorded syntax checks cover all nine changed MJS files on both Node versions, all exit zero. Post-run hashes remain equal to pre-run inputs. These commands were reviewed, not rerun here.

This is **candidate-only F2 evidence**; it does not claim a before/after F2 baseline execution. Earlier failed or incomplete attempts are historical evidence, excluded from the final counts. The older static reviews remain unchanged and describe their original source snapshots; this review acknowledges the subsequently implemented recommendations and exact executed source.

Modeled DOM, fonts, audio, storage and lifecycle tests do not prove native rendering, glyph coverage, computed CSS, contrast, reflow, real audio output, physical input/devices or BFCache storage convergence. The actual shared authority has no pageshow storage reread; native frozen-page event delivery remains an explicit journey to qualify. The cohort does not accept every Studio state, the whole P05 phase, full source gates, build, integration, version/commit, freeze, Pages or public play. The isolated packet still needs those applicable acceptance steps.

Exact reviewed hashes, source-layer comparisons, change scope, command lines and case names are in [final-evidence-review.json](final-evidence-review.json).
