# P05 Studio interface — implementation in progress

This isolated feature adds readable host text, one shared Interface preference view and live preview reduction. It is based on committed76dc4bf36baec11ce4dff6ca49773d3b9d6c0ae5 plus the separately qualified [font specimen/cache candidate](../p05-font-cache-fix-76dc4bf3/README.md). The owner's worktree was rechecked at that commit with clean status during this preparation.

The source candidate is still being composed. No new Node, formatter, syntax, build, native browser or public check has run for this feature; the earlier33-pass font result does not qualify these changed files.

## Intended behavior

- Interface body/control/secondary text resolves at the host to18/16/14px, or22/20/18px in Large. Plain uses host platform faces. Captions, instructions, loading/recovery and technical metadata remain readable even inside a preview with different theme tokens.
- Actual font, component and artwork specimens retain their selected theme identity. The authored validation-error example is specimen content; the ordinary not-saved disclaimer is host explanation.
- Interface controls reuse the existing display authority, write only on explicit choices and stay usable during authoring work. Changes update existing DOM rather than recreating inspectors, drafts, selection, prepared media, sprite history or audio.
- A live effective-motion observer owns only animation frames. Enabling reduction paints essential state once and cancels frames. Releasing it resumes only a retained local Playing choice with a reset clock. Paused and local Reduced remain their own choices. Obsolete callbacks cannot schedule new frames after cleanup.
- Persisted navigation retains preference ownership; terminal navigation disposes it. Existing preview retirement/return behavior remains in Studio. [Current lifecycle research](lifecycle-research.md) defines the real browser evidence still needed, including queued storage notifications and unsaved local intent.

## Remaining qualification

Complete static source composition/review, add the actual shared-preference and motion tests, close finite imports/resources and run the affected combined cohort on both supported runtimes when the release owner allocates the lane. Include existing font/cache/loading/picture/component behavior; count actual cases separately from fixture/process failures. Formatting, syntax and exact input receipts follow any corrections.

Native review must establish actual computed host sizes/fonts under saved/draft themes, EN/UA glyphs, contrast and wrapping, Standard/Large, Theme/Plain, effective reduction, keyboard/touch targets, portrait/short landscape/zoom, real restoration and editing-state preservation. This feature covers Studio; Team cues and all other P05 surfaces remain explicit separate requirements. Integration, version/commit, six source gates, ordinary build, immutable freeze, Pages and public-play checks remain release-owner work.

No owner checkout/index or historical candidate/release bytes are changed by this packet. Earlier P04 preview repairs must be composed separately by reviewed hunks and tested on the resulting combined source.
