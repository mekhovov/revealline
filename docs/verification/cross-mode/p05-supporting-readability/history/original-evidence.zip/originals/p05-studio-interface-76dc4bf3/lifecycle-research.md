# Shared preferences and restored Studio pages

Primary sources checked17 September2026. The HTML Living Standard page was last updated16 September2026. These refine the native acceptance journey; they do not prove browser behavior in this candidate.

The [HTML Web Storage broadcast algorithm](https://html.spec.whatwg.org/multipage/webstorage.html#the-storage-interface) queues notifications for equivalent remote storage objects. Its associated document may be inactive; notification handling waits until it becomes fully active. We therefore retain the existing page-owned subscription during persisted navigation. This is consistent with the standard, not evidence that every browser dispatches the pending events before Studio's `pageshow` handler runs.

Google's [back/forward-cache guidance](https://web.dev/articles/bfcache#update-stale-or-sensitive-data-after-bfcache-restore) recommends checking restored state during a persisted `pageshow` and updating it in place. Its [testing guidance](https://web.dev/articles/bfcache#test-to-ensure-your-pages-are-cacheable) also distinguishes an actual cache restoration from ordinary back navigation. A Back button journey alone cannot be labelled a BFCache pass.

Native qualification must record the following:

1. Start with an edited Studio draft and a Playing preview; navigate away so `pagehide.persisted` is recorded. Change the shared preference in another same-origin page, then Back.
2. Record `pageshow.persisted`, event order, stored record, authority snapshot, body attributes, controls and effective preview reduction. Let queued storage notifications settle; preserve the exact draft, focus/selection and prepared media.
3. Repeat with two writes while away. The current authority deliberately rejects stale events whose value no longer matches storage; the latest valid record must win.
4. Repeat after an explicit local save failure. Unsaved local preference intent must survive external events; display the existing session-only warning.
5. Repeat as an ordinary cold/back reload and on a browser where BFCache admission is denied. Report those as separate journeys.

If a real restoration misses the latest preference, fix reconciliation in the shared authority with explicit unsaved-intent tests. Do not add a second host-side storage parser or pretend `snapshot()` is a storage reread. The current static candidate adds no resync API and does not mark this acceptance item complete.
