# Studio preview motion: independent static review

**Verdict: no blocking implementation defect found in the reviewed controller and scene-loop wiring. Runtime acceptance remains open.** This review read the source and compared the scene integration to its baseline; it executed no Node, formatter, browser, build, or release command and changed no implementation or owner source/index.

## Ownership and transitions

- `own(dispose)` is installed before subscribing or painting. An already retired owner returns without acquiring a frame or preference observer. Disposal is idempotent, invalidates the generation, cancels the current frame and removes the preference observer.
- The authority's actual `subscribe` contract is synchronous. A draw that retires the owner before `subscribe` returns is handled by the final `if (!alive) stopPreferences()` check. The real shared authority also deletes a listener when its initial callback throws; a simplified test mock that does not do this must not be used to infer a production subscription leak.
- A queued obsolete callback checks liveness/generation **before** setting `frame = null`, so it cannot erase a replacement frame handle. The post-draw generation check prevents reentrant cap changes from adding a second obsolete frame. The reentrant cap-change test exercises this latter property.
- Effective reduction is the union of local Reduced inspection and the shared authority's already resolved effective cap. The shared source owns user/system policy; the controller does not write preferences. Standalone callers use a live system media listener with modern and legacy listener removal paths.
- Paused inspection never queues animation, even after a cap is released. Local Reduced inspection stays reduced when the shared cap is removed. A retained Playing choice resumes only when its effective cap clears. Each cap transition repaints once with zero elapsed time and resets the frame clock, preventing a post-pause time jump. A text-only preference notification changes neither pending frame nor clock.
- The three scene loops—player recipe, board context and effect recipe—receive the read-only motion source through `drawAssetPreview` options. Their draw closures keep the existing decoded artwork, fixture, animation/effect clock and painter. A cap change only redraws these retained objects; it does not repeat fixture loading, decoding, draft changes or audio actions. Host text-role additions in the scene diff are separate from this lifecycle change.

## Test review and remaining evidence

The ten current top-level controller tests assert observable frame counts, elapsed values, reduced flags, observer removal and stale-callback effects. They cover live reduction/resumption, Paused, local Reduced, text-only updates, cleanup, an already retired owner, standalone system changes, initial synchronous retirement, a cap change during drawing, and unavailable system querying. They call the new controller with modeled host APIs; no runtime result is claimed here.

Two useful missing regression scenarios should be added before qualification:

1. Capture an old frame callback, enable reduction to cancel it, clear reduction so a replacement frame exists, then invoke the old callback. Assert no extra paint and that the replacement frame handle and next elapsed interval remain intact. The existing stale-callback case only exercises disposal, not the live generation guard after a cap transition.
2. Mount Playing with shared `effectiveReducedEffects: true` (and ideally the standalone system flag already true). Assert that the first draw is reduced with `dt=0` and no frame is queued; clearing the cap then produces the expected single resumed frame. Existing cases mainly switch from an initially unrestricted state.

No defect is asserted for those source paths: they appear correct by inspection. These tests protect branches central to the new behavior rather than reproducing incidental implementation details. A long-frame/clamped-delta check can be included if the clock contract is qualified separately.

The ten controller definitions do not establish the final Studio preference adapter, actual scene rendering, browser lifecycle/BFCache, native reduced-motion changes, glyph/CSS behavior, storage persistence, downloads, or public release readiness. The preference adapter was pending separate work at review time. Compose that adapter, recheck exact source hashes, and run the authorized affected cohort before using this review for integration.

## Exact reviewed inputs

Reviewed at 2026-09-17T04:11:46.537989+00:00.

| Tree | File | Bytes | SHA256 |
|---|---|---:|---|
| proposal | `authoring/asset-studio/preview-motion.mjs` | 2687 | `47a4997907dd8de80791a6662ec3e0bb46f31c2e57481930c60222448ed4e1b2` |
| baseline | `authoring/asset-studio/scene-preview.mjs` | 18029 | `89e48861d360c68aaf6d396980f477816059c327ad96b08c26b54e98c6e66937` |
| proposal | `authoring/asset-studio/scene-preview.mjs` | 17885 | `98d25310750d8b2639a43f83f5c95e95d6f3e488a1aa6800f8fcf7fe2abcf260` |
| proposal | `game/test/asset-studio-preview-motion.test.mjs` | 6067 | `9672ddc6511d5258593de9e179bd4e5117164affa4cb6454f6efd688b67179b8` |
| proposal | `game/display-preferences.mjs` | 7319 | `923bff19b744069eddee0735de2716674278d28ca3e00441ad5bf984a081a576` |
| proposal | `authoring/asset-studio/preview.mjs` | 19676 | `81c0947700d566e2af69dec0647d35e78c27caf654efc8b3678469a204884a7a` |
| proposal | `authoring/asset-studio/studio.mjs` | 43868 | `adafd731781816374831c23d5291d53cecdbd7b73ae90e342e82f98a238ce598` |
