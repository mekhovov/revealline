# Studio Interface adapter: independent static review

**Verdict: no blocking implementation defect found in the reviewed adapter, host wiring and test definitions. Execution and native qualification remain open.** This review read current source and compared the modified host paths to their isolated baseline. No Node, formatter, browser, build, source/index or release operation was run; no implementation file was edited.

## Shared authority and authoring preservation

The adapter uses the existing, unchanged `game/display-preferences.mjs` authority. It does not add a Studio preference store, read the Solo profile, write a theme revision, replace a Blob, or refresh any authoring view. Mount resolves the existing shared record or readable defaults and subscribes without invoking `set`; malformed/unavailable storage therefore causes no read-time repair write.

Only the three explicit change handlers call the authority's validated `set` operation. The adapter updates body datasets, existing control values and dedicated notices in place. It never calls `refresh`, `refreshPreviews`, `stage`, sprite reset, or collection loading. The `motion` view exposes only snapshot/subscribe, so preview consumers have no shared-preference mutation method.

Failed persistence is handled by the existing authority: accepted local choices remain applied, a save warning is shown and `unsaved` prevents subsequent storage events from overwriting that intent. Successful explicit saves clear the warning. The adapter's catch path restores the current control choice when validation/application throws and uses a dedicated Interface status rather than replacing the active Studio operation message. Storage failure itself is already caught by the authority and is not falsely presented as a rejected local choice.

Raw Reduced effects intent is bound to the checkbox; the body effect flag and preview observer use `effectiveReducedEffects`. A system-only cap is explained separately. System changes and valid external storage updates therefore apply without saving a new preference or replacing unrelated controls. Actual shared `subscribe` delivers an immediate snapshot and returns an unsubscribe function; the adapter follows that contract.

## Host and lifecycle integration

The Interface controls appear outside the authoring mutation regions that become inert during operations. They remain disabled in initial HTML until the Studio module adopts the existing startup controls, and the adapter mounts before normal workspace loading begins. Both Saved and Draft preview options receive the same page-owned read-only motion view.

On terminal pagehide, existing preview cleanup happens before adapter disposal. Disposal is idempotent, removes the three control listeners, removes the host view subscription and disposes the underlying storage/media authority. On persisted pagehide, preview loops retire but the authority and user intent are retained; persisted pageshow rebuilds previews through the existing path. Neither path stages a revision or discards unsaved sprite pixels solely because an interface preference changed.

**Native convergence is still an explicit open item.** The modeled persisted journey demonstrates retained authority usability, not browser BFCache admission or event delivery. The existing shared authority has no pageshow storage reread. If a browser does not deliver a preference change made while this document is frozen, the model used here cannot prove convergence on return. Do not claim that cross-page/frozen-document scenario is qualified by these tests.

## Test meaning and scope

The nine new adapter cases call the real adapter and real shared authority with modeled DOM, events and storage. They assert mount without writes; explicit shared-only writes; current versus stale/malformed storage events; malformed initial data without repair; denied storage; write failure preserving local intent; live system cap without changing raw intent; disposal; and invalid-value recovery. The preserved draft node, draft contents, child identities and focus assertions guard against an implementation that rebuilds the host on preference changes.

The augmented actual Studio host case imports the actual Studio module against parsed production HTML and existing storage/upload/sprite fixtures. New assertions verify startup control ownership, availability during an in-flight startup operation, preservation of that operation's message, unchanged prepared metadata/source-image node/current-and-draft preview markers/focus, and retention of unsaved sprite edits. Its storage stub rejects writes outside the shared display key; the existing byte assertions still verify exact source asset persistence in the Studio database. The final modeled persisted hide/show retains edited-pixel save protection and allows another explicit interface change. This is materially stronger than a source-string or isolated adapter-only assertion.

One test-hardening gap remains in the host fixture: `localStorage.setItem` asserts the allowed key **before** appending to its ledger. A production caller that catches storage exceptions could swallow that assertion, so the final ledger would omit the forbidden attempt. Record every attempted key first and assert the complete ledger after the actions when claiming that no non-display write was attempted. The adapter unit fixture already records before simulating write failure and checks all keys. This is a coverage issue, not evidence of a Solo-write path in the reviewed adapter source.

The host test is still **one top-level case** with additional assertions; do not count each assertion or modeled lifecycle step as another executed test. None of these definitions has been executed by this review. They do not establish native font rendering, CSS cascade/reflow, physical input, browser storage semantics, real BFCache behavior or release acceptance. The final composed affected cohort still needs execution on exact formatted source.

## Motion recommendation follow-up

The current motion test source now contains 12 top-level definitions. Both earlier recommendations are implemented as meaningful cases: a stale callback after a live cap transition cannot consume the resumed frame, and an initially capped Playing preview queues no animation until the cap clears. This acknowledges source coverage only; it does not retroactively change the historical [motion static review](motion-static-review.md) or claim that these cases passed.

## Exact reviewed inputs

Reviewed at 2026-09-17T04:15:50.441238+00:00.

| Tree | File | Bytes | SHA256 |
|---|---|---:|---|
| proposal | `authoring/asset-studio/interface-preferences.mjs` | 2699 | `0fee8df458716a828e4f5562c412fd284c54af1b60c955b1c01b47be41153790` |
| proposal | `game/test/asset-studio-interface-preferences.test.mjs` | 7754 | `c33186e7e33eb00af635e29e4ba2307fba69c1ffb7ac4853ed6b5a54e86af1e7` |
| baseline | `game/test/asset-studio-host-loading.test.mjs` | 9708 | `ff6a517224afbf8dcfcb7ca73d64a235471542a65badd39e6690cb33505b9064` |
| proposal | `game/test/asset-studio-host-loading.test.mjs` | 12844 | `08b7668249635d143d50dfe8486ffb0c77e7758b0919856358af7026581ba73e` |
| baseline | `authoring/asset-studio/studio.mjs` | 43188 | `135e5f30e114c3841928cf548a133aa43a33b17e9ff1cb923c32218060c89579` |
| proposal | `authoring/asset-studio/studio.mjs` | 43875 | `788935c24d2a81e7694ac82c3368372f66cd08947203b75e96fc02a4c3b3c6dd` |
| proposal | `game/display-preferences.mjs` | 7319 | `923bff19b744069eddee0735de2716674278d28ca3e00441ad5bf984a081a576` |
| proposal | `authoring/asset-studio/index.html` | 27771 | `91d04d23995ee30fc1062818bfd67ac937c4d2f0a4818db2f52165603d01bd31` |
| proposal | `game/test/asset-studio-preview-motion.test.mjs` | 7245 | `e1d147d7655adffe0375f286403506437df675ae29f0efd6d9a1b58dffbd5a65` |
