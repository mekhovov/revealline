# Static integration review checklist

1. The source-of-truth preference remains `game/display-preferences.mjs`, with historical Theme value `pixel`, Plain value `plain`, sizes `standard`/`large` and raw boolean `reducedEffects`. No Studio storage record or Solo profile writer is introduced.
2. One page authority owns current state. The host subscriber changes only body datasets/control values/notices. Preview subscribers filter unchanged effective reduction and own only frames. Text changes do not call Studio refresh routines.
3. Inline theme variables on preview surfaces must not change body-resolved host aliases. Conversely, host Plain/Large must not change an actual selected-file specimen or authored component's intentional content.
4. Dynamic statuses/captions get explicit host roles when created, not after asynchronous completion through a global rescan. Shared operation-status live-region ownership stays unchanged.
5. Preview cleanup precedes terminal authority disposal. Persisted navigation keeps the authority and retires previews through existing handlers; returning rebuilds the existing preview views. A native BFCache pass requires `pageshow.persisted`, not merely clicking Back.
6. Body `data-effects="reduced"` governs shared DOM transitions, including narrowly overriding the two inline preview timing variables. Canvas loops consume the live read-only motion view. Audio remains governed by existing audio preferences.
7. The font cache/specimen code must retain the qualified behavior after composition. That requires new execution against these files, not reuse of the old candidate receipt.
8. Fresh source/index/version/commit/public qualification belongs to the release owner. All current files here are isolated preparation until explicitly adopted and tested.
