# Initial Studio font-cache implementation — static peer review

**Scoped source pass under the ordinary native FontFace API contract.** No new production blocker identified. The104 captured baseline objects match exact committed`76dc4bf36baec11ce4dff6ca49773d3b9d6c0ae5` and their hashes. The reviewed runtime is19430bytes, SHA-256`81e49a8d66335b307fb6c90680eb6abfe0c92a6d4ed0787393847827e290f64f`. This review concerns the actual initial runtime; the parent owns the separate test-definition review and final capture.

## Contract implementation

- `prepareFont:466–468` computes a fresh owned numeric request range synchronously. It no longer discovers the role only after delayed byte reading, and it does not mutate the resolved snapshot.
- `481–499` assigns the promise and publishes the entry before the queued continuation can call `blob.arrayBuffer()`. Reentrant or overlapping byte reads therefore see the complete shared entry/promise. Requests made before construction update its range; the constructor reads that accumulated range at488.
- `471–477` merges requested bounds monotonically. Once a face exists, weight assignment happens before committing expanded bounds. A native setter exception leaves the old successful descriptor/cache metadata available and reaches the requesting preview's existing error handling; it does not evict another usable consumer.
- The same face remains available while its load is pending or after it is registered. Narrower/equal requests neither shrink it nor create another face. Successful reuse avoids duplicate reads, construction and registration.
- `494–496` evicts failed attempts only by entry identity. Different hashes are isolated. Failure permits a fresh attempt; “one face” means one successful cached registration/live attempt per file, not that a rejected attempt can never be reconstructed.
- Preview cancellation does not alter shared cache lifetime. Existing currentness checks after preparation still prevent stale samples/status/focus adoption. A cancelled request may contribute a retained wider range; the contract is monotonic observed demand, not a reference-counted union of only active previews.

The unchanged successful cache remains document-lifetime storage; no additional per-role registrations or buffers are introduced. Plain/native family selection, file identity, role-slot binding and the T01 sample treatment remain distinct. No schema, media revision, source bytes, simulation or save state changes occur.

## Reentrancy boundary

The source correctly handles the requested reentrant/held **blob-read** boundary and widening during an outstanding native load. Native constructor and descriptor setters do not expose a script callback in the ordinary contract.

It is not designed to withstand arbitrary JavaScript-reentrant FontFace shims. If a test shim invokes another role request from inside its constructor, the nested demand can widen entry bounds after constructor arguments were already evaluated but before`entry.face` is assigned. Similarly, a nested request from a weight-setter shim can update bounds that the outer setter caller subsequently overwrites. Those are concrete limitations of such injected reentrancy, not observed browser failures. Either keep those shims outside the current contract or explicitly design reconciliation for them; do not claim comprehensive arbitrary API-hook reentrancy from the blob-read test.

The failure-preservation reasoning also assumes the specified setter behavior: invalid assignment throws without accepting that value. A mock that mutates the underlying weight and then throws represents a stronger, different fault model. No exception swallowing or silent fallback should be added to make such a test pass.

## Required verification before accepting

The parent should retain the planned sequential expansion, held byte-read expansion, held FontFace-load expansion, shared-to-narrower with two active surfaces, cancel/supersede, failed-load Retry, and setter-failure cases. Check actual face identity, registration count, byte-read count, resulting weight and each preview's status/focus. Repeated/equal requests and another hash should remain unaffected. A test proving only entry bounds or constructor count does not establish the current registered descriptor.

One document-wide registration is appropriate for this module's Studio-document lifecycle. If the same module is later reused across documents or FontFaceSets, cache ownership must be keyed/captured accordingly; reading ambient`document.fonts` after an await is not a general cross-document contract. This was already the baseline ownership model.

The CSS Font Loading specification supports mutable weight descriptors, used in matching; it does not prove this implementation's native rendering. Actual variable-font weight changes, simultaneous consumers, specimen layout, fallback and glyph readability remain native qualification requirements. [CSS Font Loading draft](https://www.w3.org/TR/css-font-loading-3/#fontface-interface), [descriptor-update WPT source](https://github.com/web-platform-tests/wpt/blob/master/css/css-font-loading/fontface-descriptor-updates.html).

No Node, test, syntax/format check, browser, server, CI/status inspection or external call ran during this concrete source review. No candidate, owner source or index was modified. No test pass, native result or phase/release acceptance is claimed.
