# Independent inventory-row focus delta review

**No actionable issue found in the bounded correction.** Keep this review separate from full F2/P05 acceptance.

Reviewed `proposal/authoring/asset-studio/studio.mjs:193–207` and the actual-host regression. The handler records foreground focus ownership before synchronous replacement. A successful desktop selection focuses only the current selected replacement row when its removed trigger owned focus. Foreground narrow activation retains the deliberate Inspector handoff, and background activation does neither. Restoration is synchronous, so a settling preview cannot later steal focus.

`requireSettled` runs before selected/sprite/DOM changes (`studio.mjs:115–124`, `:147–151`). Both a prepared replacement and dirty sprite reject the selection before node replacement; the catch reports the instruction without running restoration. No new media, storage, selection-persistence or display-authority writer is added.

The actual-host tests model removal of a focused subtree, same-row reselection, unfocused/background activation, narrow handoff, deferred completion and both rejection paths. The original and corrected runtime use byte-identical augmented test definitions; baseline 95/96 versus corrected 96/96 is a single assertion failure, not 96 additional cases. Test execution was not repeated here.

Independently verified the 282 captured baseline/proposal files, 141 unchanged F2 parent files, two changed-file pins, patch hash, four runtime receipts/logs and eight retained native runtime override pins. Native binding/request-log hashes match their final/closed records. Read the retained native observations; no browser or visual acceptance was executed independently.

The separate native packet records actual second-row Enter/Tab, repeat activation, 390px Inspector handoff and prepared-font rejection on these exact bytes. Its limitations remain: background and dirty-sprite rejection were modeled, browser version was not independently recorded, and emulated viewport/pointer checks are not physical-device acceptance. Its cold Back selection/filter mismatch and Discard slot draft focus-to-BODY follow-ups remain owned by P04. The runtime receipt's historical “native pending” label does not negate or expand the later separate native record.

No source, index, remotes, original candidate files or tests were changed. Integrated-source qualification/public release remain open.
