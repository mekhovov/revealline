# Studio inventory focus — native correction check

17 September 2026. The isolated [correction](../p05-studio-inventory-focus-76dc4bf3/README.md) passed the following actual browser journeys. It remains a local candidate; integration and release qualification are open.

## Exact source and observed interaction

The separate server used committed `76dc4bf36baec11ce4dff6ca49773d3b9d6c0ae5` plus the eight F2 runtime overrides, replacing only `studio.mjs` with SHA256 `2def0bc48bea7573be54aa917e52e6636da98d27314f8fa009056cfa60bf8c4e`. See [binding](binding.json), [request log](requests.jsonl) and [verified served bytes](final-verification.json). The original failed native candidate was not modified. No production source, index, player origin or public release was changed.

Browser: Codex in-app browser, through CUA controls and read-only DOM observations. A new, distinct loopback origin and temporary tab were used. Native here means actual browser interaction; it does not mean a physical phone/controller or native application. Browser version was not independently recorded.

| Journey | Observation |
| --- | --- |
| Compiled font inventory | Real release assets loaded; Kind=font gave Handjet, Exo 2 and Plex Mono rows. |
| Desktop second-row Enter | At 1280×720, Enter on Exo selected `font.ui` and activeElement was its new BUTTON, aria-pressed=true. Tab reached Include IBM Plex Mono numeric font in collection. |
| Matched desktop repeat | At 1440×900, reselecting Exo with Enter retained its replacement BUTTON. Tab again advanced to the IBM include checkbox. |
| Narrow keyboard | At 390×844, Enter on IBM selected `font.numeric`, focused SECTION#inspector and document scrollWidth was 390. |
| Narrow pointer | Clicking Exo selected `font.ui` and deliberately focused #inspector. This is pointer emulation, not physical touch. |
| Prepared replacement rejection | At 1440×900, the actual file chooser prepared the captured Exo WOFF2 (76,652 bytes). Enter on IBM then showed the stage/discard instruction, preserved `font.ui` and the Exo source filename, and retained focus on the unselected IBM BUTTON. |
| Local cleanup | Discard slot draft removed the temporary prepared upload. Warning/error log sample returned no entries. Viewport reset; all three root-owned test tabs closed. Both original and corrected servers exited and their ports are closed. |

The attempted read-only `document.hasFocus()` query was unsupported by the CUA observation scope. It made no app mutation and is not used as browser evidence. Actual focus claims above come from activeElement reads plus native AX focus reports. AX represents toggle buttons as checkboxes; the DOM readings identify the actual BUTTON element.

The original [failure observations](../p05-studio-interface-native-76dc4bf3/observations.md) remain separate. The before/after modeled cohort reproduced the focus assertion on both original runtimes and passed all 96 cases on both corrected runtimes. Background/unfocused desktop activation, delayed completion and rejected dirty-sprite selection were modeled; no native background-focus or dirty-sprite rejection proof is claimed here.

## Remaining scope

These checks close the bounded inventory Enter/Tab and narrow-handoff defect on these exact candidate bytes. They do not accept complete Studio keyboard navigation. The cold Back selection/filter mismatch remains a P04 follow-up. Discarding a prepared slot disables its triggering button and the observed focus falls to BODY; include this separately in P04 mutation-command focus handling. Do not expand the row-selection correction or describe either later item as resolved.

S1–S10 retain their partial statuses: full contrast/zoom, font binary validation and adverse native cache transitions, complete authoring round trips, admitted BFCache, OS motion caps, physical devices/controllers and exact integrated public/offline release remain open. No additional case counts are claimed for the individual native assertions.

The [final verification](final-verification.json) validates all 243 successful recorded requests across 243 unique paths against the source pins. The only missing request was favicon.ico. The [closed receipt](closed-receipt.json) pins the complete log. This proves the served source and cleanup, not a public deployment.
