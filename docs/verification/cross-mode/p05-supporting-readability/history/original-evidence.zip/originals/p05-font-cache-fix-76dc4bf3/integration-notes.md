# Integration and maintainer prompt

This candidate has three intended source paths and exact bounded test evidence in `runtime-final/`. The owner should reconcile against the then-current reviewed source, preserve navigation fixes, and compose the separate P04 picture-context change by actual hunks. All earlier candidate identities and failed logs remain immutable.

Proposed maintainer guidance to adopt with the actual code:

> Studio font previews select the actual bound file and requested role. Keep Display/UI/Numeric specimens separate from host Plain/Large preferences. A hash family may serve multiple roles; accumulate compatible weight demands before/during/after preparation. Keep one successful registration, never narrow or remove it when another current consumer still needs it, and preserve the loaded entry on descriptor-update failure. Read/load failures must allow real visible Retry. Test simultaneous consumers and cancellation at both asynchronous boundaries. Native font matching and shipped English/Ukrainian glyphs require separate browser/derivative verification.

Copyable integration prompt:

> Reconcile the P05 selected-font/cache candidate with the current reviewed Reveal Line source. Preserve current navigation fixes, existing immutable releases, exact source artwork and any pending P04 picture-context hunk. Inspect the three-path diff and qualify the resulting combined source; do not transfer independent candidate passes. Run the affected font-cache, specimen, loading and picture-context files on supported Node20/22, explicit format/syntax checks, then actual font matching and EN/UA specimens in simultaneous Studio previews. Exercise shared file role expansion, narrowing, cancellation and Retry with native fonts. Check Standard/Large, Theme/Plain, long text and responsive/zoom layout while preserving asset identity. Update implemented maintainer guidance. Complete the usual version, staged-hunk review, exact committed source gates, build, freeze, deployment and public-play evidence before accepting the release.

The runtime lane was returned to the release owner after all local sessions finished. No phase/version/public acceptance is implied by this handoff.
