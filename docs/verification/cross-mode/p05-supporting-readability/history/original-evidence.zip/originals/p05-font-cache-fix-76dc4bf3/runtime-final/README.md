# Final bounded qualification

Source input: `76dc4bf36baec11ce4dff6ca49773d3b9d6c0ae5`. The candidate remains isolated; no owner source/index change or public acceptance occurred.

- [Original runtime, Node22](baseline-node22.json): 33 tests, 15 pass, 18 fail; [log](baseline-node22.log).
- [Corrected runtime, Node22](proposal-node22.json): 33 tests, all pass; [log](proposal-node22.log).
- [Original runtime, Node20](baseline-node20.json): the same 18 failures; [log](baseline-node20.log).
- [Corrected runtime, Node20](proposal-node20.json): 33 tests, all pass; [log](proposal-node20.log).
- [Explicit format and six syntax checks](format-syntax.json): all exit zero.
- [Pre-run 109+109 input hashes](inputs.json) and [post-run verification](input-verification.json): unchanged; 107 baseline source objects matched exact Git contents.

The commands use `--max-old-space-size=100 --test --test-concurrency=1` and the same four complete test files. Zero groups, cancellations, skips or todos are reported. The original failures divide into ten cache cases and eight specimen cases; the remaining five cache cases and ten existing loading/picture cases pass. The final source changes after attempt2 removed only the historical “NOT EXECUTED” test comment; all four runs were repeated against those final bytes.

These are actual-handler tests using genuine font bytes with modeled font decoding/DOM, not native browser or physical-device evidence. Full source gates, build, integration, native typography and public release remain open. Earlier failed fixture attempts are retained and excluded from behavior acceptance.
