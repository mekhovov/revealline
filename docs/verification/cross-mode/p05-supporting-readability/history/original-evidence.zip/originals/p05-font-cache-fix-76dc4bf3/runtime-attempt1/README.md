# P05 font preview/cache qualification — in progress

The release owner explicitly allocated this isolated affected Node20/22 cohort after the controller-practice cohort finished. Full source gates/builds, owner source/index, CI dispatch and the shared native browser remain outside this allocation. All results here apply to the captured76dc-compatible overlay, not an integrated/public release.

## Retained first runs

| Run | Observed result | Interpretation |
| --- | --- | --- |
| Original baseline on Node22, initial fixture | Eight specimen behavior cases fail; six existing loading cases pass. Cache test process hits100MiB heap limit; picture test cannot read missing `classic-lab.json`. | Specimen failures expose the original role treatment. The two process/setup failures do not establish cache behavior. Full log and command retained in `baseline-node22.*`. |
| Original baseline on Node22, fingerprint-only fixture correction | Ten existing loading/picture cases pass; eight specimen cases fail. Cache test process still exceeds100MiB, now while serializing fingerprint input. | The exact pack dependency is corrected. Replacing redundant graph copies alone did not qualify the cache fixture. See `baseline-corrected-fixture-node22.log` and `corrected-fixture-results.json`. |
| Corrected preview on Node22, existing loading/picture plus specimen files | **18 behaviors pass**, no failure/cancellation/skip. | Confirms this bounded subset on source SHA256 `81e49a8d66335b307fb6c90680eb6abfe0c92a6d4ed0787393847827e290f64f`. It does not include the15 new cache-transition cases or native fonts. See `proposal-existing-and-specimen-node22.json`. |

The first OOM stack contains StructuredClone/ValueDeserializer; the second contains JsonStringify/ArrayMap. These identify allocation operations, not an exact JavaScript line or a failure of the proposed cache behavior. The original fixture and its first fingerprint-only correction are retained independently. No heap-limit increase or production-source reduction has been applied.

The cache fixture is being revised to construct full real revisions stepwise, retain only the actual snapshots needed by each behavior, stream mutation fingerprints and prevent cached mock faces from retaining an entire test harness. All15 behaviors and full relevant catalogue data remain required. Execution must prove that this setup completes; its design alone is not a pass.

## Next required results

Rerun the baseline and corrected complete four-file cohort using final identical test definitions and captured inputs. Compare the original behavior failures with the corrected result on both supported runtimes. Perform bounded explicit format/syntax checks, recheck final file hashes, then return the lane and evidence to the release owner. Actual FontFace rendering, glyphs, font matching, native layout/input and public release remain unqualified by this Node work.


Update: the stepwise full-registry fixture subsequently completed the same four-file cohort under the same 100 MiB limit. Final exact-byte results are in [runtime-final](../runtime-final/README.md). No failed log or initial fixture was rewritten.
