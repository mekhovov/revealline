# P05 font specimens and shared-font cache — qualified candidate

17 September 2026. The isolated candidate is based on exact committed source `76dc4bf36baec11ce4dff6ca49773d3b9d6c0ae5`. Its affected cohort passes on Node 22.22.2 and 20.19.5. Integration, native rendering and public-release acceptance remain open.

The correction makes Studio font samples show the selected file at the intended role sizes and weights. It also fixes a shared-font registration defect: assigning a variable file first to Display 600 and subsequently to UI 400–600 previously kept the cached face at 600. The corrected registration widens for both current consumers, preserves an existing loaded face if a descriptor update fails, and supports visible Retry without duplicating a successful registration. Cancellation cannot remove a face still used by another preview.

## Verified result

| Exact final cohort | Original runtime | Corrected runtime |
| --- | --- | --- |
| Node 22.22.2, 100 MiB heap | 15 pass, 18 fail | 33 pass, 0 fail |
| Node 20.19.5, 100 MiB heap | 15 pass, 18 fail | 33 pass, 0 fail |

Each row contains 33 behavior tests and zero grouping rows: 15 cache cases, eight specimens, six existing loading cases and four existing picture-context cases. Both original runs reproduce the same ten cache failures and eight specimen failures. The final runs have no cancelled, skipped or todo cases and no harness failure. All three changed files pass explicit formatting; all three parse on both Node versions. See [final receipts and logs](runtime-final/README.md) and [exact candidate manifest](candidate-receipt.json).

All 107 captured source files were compared to their committed Git objects after execution. The baseline and proposal each contain those source inputs plus the same two new test files. Only `authoring/asset-studio/preview.mjs` differs between runtime trees. [Post-run verification](runtime-final/input-verification.json) confirms all 218 tree-file hashes remained unchanged.

## Adoption scope

The [proposal diff](proposal.diff) contains exactly three intended source paths:

- `authoring/asset-studio/preview.mjs`: selected-role specimens and compatible weight-range accumulation.
- `game/test/asset-studio-font-cache.test.mjs`: shared consumers, pending read/load, cancellation, narrowing, failure and Retry.
- `game/test/asset-studio-font-specimen.test.mjs`: actual file identity, selected role and late completion ownership.

The runtime preview hash is `81e49a8d66335b307fb6c90680eb6abfe0c92a6d4ed0787393847827e290f64f`. Font bytes/provenance are unchanged. The [source review](review-notes.md), [implementation peer review](../p05-font-cache-review-76dc4bf3/peer-review.md) and [fixture peer review](../p05-font-cache-fixture-peer-76dc4bf3/review.md) describe the contract and limits.

The P04 picture-context correction also changes this file and is deliberately not composed into this candidate. Adopt the actual nonoverlapping hunks against the current reviewed source, retain subsequent navigation changes, and qualify that resulting source anew. Independent P04 and P05 candidate passes cannot be added together as an integrated pass.

## Remaining release requirements

Native FontFace matching, actual English/Ukrainian glyphs and axes, simultaneous before/after font previews, long text, Standard/Large, Theme/Plain, zoom and responsive layout require browser review. The model assertions do not establish their appearance. Broader P05 host readability, shared preferences, Team text, palette/component coverage and the full surface matrix also remain open.

No owner source/index, version, commit, CI, build, browser, server or public release was changed by this candidate. The release owner retains adoption and publication. P05 is not accepted by these checks alone.

## Preserved investigation

The first fixture exhausted the 100 MiB test heap and lacked one exact pack resource. A fingerprint-only fixture still exhausted the heap. Both failed attempts are retained in [runtime-attempt1](runtime-attempt1/README.md), and neither is counted as a product behavior failure. The final fixture keeps the complete 293-slot registry, genuine font bytes and all 15 cache behaviors while releasing unused revision graphs and isolating mock font closures. [Attempt 2](runtime-attempt2/inputs.json) first completed all behaviors; final qualification follows removal of a stale test comment. No heap increase or runtime simplification was used.

The preceding static-only documents and receipts are preserved in [pre-qualified-revision](pre-qualified-revision/README.md). Earlier T01/P04 packets remain unchanged. The full P00–P18 scope and 132-mission delivery goal remain active.
