# P05 font-role specimen and cache correction

Isolated implementation pinned to committed `76dc4bf36baec11ce4dff6ca49773d3b9d6c0ae5`. The release owner's worktree was clean at the initial local Git read. This does not establish hosted/public qualification; the owner retains the release and has allocated the local test lane to another correction.

## Problem and intended behavior

The current Studio caches font preparation using only its exact file hash. When a variable font first serves Display600, then the same bytes are assigned to UI400–600 in a later valid theme snapshot, the cached registration keeps its original600 descriptor. A specimen can request the intended weight while the registered face still declares the earlier range.

The proposal keeps one registration for each hash family within the Studio document. Each request contributes its role's minimum/maximum weight. Demands accumulate before byte reading and font construction; later demands widen the existing FontFace descriptor. A narrower or cancelled preview never shrinks or deletes a registration used by another current consumer. The selected specimen still uses its exact file family and role-specific size/weights from the preceding T01 proposal.

The font bytes and original provenance remain unchanged. This is compatible weight expansion for the existing `normal`/`swap` descriptor contract, not a general cache for arbitrary future font styles or variation settings.

## Implementation boundaries

- Publish the cache entry and its pending promise before byte I/O starts, so a concurrent/reentrant consumer cannot duplicate preparation or receive an absent promise.
- Construct the face from the latest accumulated weight range after reading bytes.
- If a face already exists, set its new weight before updating cached bounds. A setter failure leaves the earlier registration and its current consumers usable, while the new request receives the existing visible error/Retry flow.
- Retain successful registrations for the Studio document lifetime, matching existing ownership. Do not tie their removal to one preview's cleanup. Cumulative distinct-file retention remains an existing limitation; this change does not claim a new eviction policy.
- Read, construction or load failure removes only the matching failed entry. Retry may then create a new face. Existing preview currentness fences still prevent stale rendering/status/focus changes.
- Keep one successful FontFace, byte read and registration per distinct hash across successful role expansion/narrowing. Failed attempts are distinguished from successful reusable registrations.

The [CSS Font Loading specification](https://www.w3.org/TR/css-font-loading-3/#fontface-interface) defines mutable weight descriptors used in font matching. This supports the chosen mechanism; it does not prove that the actual shipped fonts render each expanded weight correctly. Native verification remains required.

## Source and composition

The initial104 baseline files were captured from exact76dc Git objects. Closing the new test imports adds two exact source files, for106 source inputs and108 files in each comparison tree, recorded in [source-capture.json](source-capture.json). The old T01 preview baseline is byte-identical to this committed preview, allowing its selected-specimen hunk to be composed explicitly. Its eight unexecuted test definitions are copied unchanged into both local trees for before/after execution. Earlier T01 and P04 packets remain untouched.

Only `authoring/asset-studio/preview.mjs` is an intended runtime change in this candidate. The initial diff is [retained](initial-candidate.diff); the [composed diff](proposal.diff) also includes both new test files. The independent [cache regression proposal](../p05-font-cache-regression-76dc4bf3/README.md) supplies15 unexecuted cases, alongside the earlier eight specimens. The [candidate receipt](candidate-receipt.json) records all108 file hashes. The P04 picture-context correction in the same file is not composed here and must be merged by its actual hunk with fresh qualification later.

The [implementation peer review](../p05-font-cache-review-76dc4bf3/peer-review.md) found no static blocker within ordinary single-document native FontFace behavior. The [root test/source review](review-notes.md) records fixture checks and remaining execution limits. Neither review is a parse, test or native rendering result.

## Required evidence, not yet executed

Sequential and held-read/held-load expansion; distinct simultaneous consumers; cancellation of either consumer; narrowing/repeated requests; read/load failure and Retry; injected descriptor-setter failure. Verify current nodes/status/focus and exact file identity, not cache internals alone. Execute the current specimen tests and applicable existing loading/picture/font checks on both supported Node runtimes after allocation, then format/syntax checks on the final exact files.

Native review must inspect the real variable Exo file before and after role reassignment, with simultaneous current previews, actual weight matching/glyphs, cancellation/Retry, long EN/UA specimens, Standard/Large, Theme/Plain and zoom/reflow. Property assertions in a modeled FontFace do not prove this appearance.

No Node, formatter, tests, native decoder, browser, server, owner source/index change, commit or public release ran for this candidate. It is implementation under review, not an accepted P05 feature. The complete P00–P18 goal,132missions and cross-mode/public qualification remain open.
