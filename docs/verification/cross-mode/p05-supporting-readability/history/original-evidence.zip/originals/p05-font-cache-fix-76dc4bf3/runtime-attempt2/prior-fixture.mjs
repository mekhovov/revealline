import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { Document, Element } from './helpers/couch-dom.mjs';
import { createDefaultThemeBundle } from '../presentation/catalog.mjs';
import { resolvePresentation, validateAssetRevision } from '../presentation/model.mjs';
import { reviseStudioTheme } from '../presentation/studio-session.mjs';

// Prepared, NOT EXECUTED. The owner must compose these definitions with the
// reviewed preview implementation before running the complete file.
// The real handler and validated revisions use genuine committed variable Exo
// bytes. DOM, FontFace decoding and FontFaceSet registration are explicitly
// modeled. No native font selection, glyph, axis, CSS, reflow or release proof.
const options = { concurrency: false, timeout: 10000 };
const deferred = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => {
    resolve = yes;
    reject = no;
  });
  return { promise, resolve, reject };
};
const statusText = (target) => target.querySelector('.operation-status-label').textContent;
// These validated objects contain only ordinary JSON data. Compare each complete
// input at teardown without retaining a second full graph of every revision.
const fingerprint = (value) => createHash('sha256').update(JSON.stringify(value)).digest('hex');
let moduleId = 0;
let fontInput;

async function exoInput() {
  fontInput ||= (async () => {
    const provenance = JSON.parse(
      await readFile(new URL('../ui/fonts/field-kit/provenance.json', import.meta.url), 'utf8'),
    );
    const row = provenance.fonts.find((entry) => entry.role === 'ui');
    assert.equal(row.family, 'Exo 2');
    assert.deepEqual(row.outputAxes.wght, [400, 400, 600]);
    const bytes = await readFile(new URL(`../ui/fonts/field-kit/${row.file}`, import.meta.url));
    assert.equal(bytes.length, row.bytes);
    assert.equal(createHash('sha256').update(bytes).digest('hex'), row.sha256);
    return { row, bytes };
  })();
  return fontInput;
}

class PreviewElement extends Element {
  constructor(doc, tag) {
    super(doc, tag);
    this.style.getPropertyValue = (name) => this.style[name] || '';
    this.style.getPropertyPriority = () => '';
    this.style.removeProperty = (name) => delete this.style[name];
  }
}

async function harness(t) {
  const { row, bytes } = await exoInput();
  const base = createDefaultThemeBundle();
  const baseResolved = resolvePresentation(base);
  const font = validateAssetRevision({
    ...baseResolved.assets['font.display'],
    id: 'font.shared.exo',
    revision: 1,
    kind: 'font',
    description: 'Genuine Exo 2 variable font for compatible role-transition tests.',
    provenance: {
      creator: 'Exo 2 upstream authors',
      source: row.sourceUrl,
      license: row.license,
      prompt: '',
      parent: null,
    },
    recipe: null,
    file: {
      sha256: row.sha256,
      bytes: bytes.length,
      mime: 'font/woff2',
      width: null,
      height: null,
    },
  });
  const ref = { id: font.id, revision: font.revision };
  const narrowDocument = reviseStudioTheme(base, {
    assets: [font],
    bindings: { 'font.display': ref },
  });
  const wideDocument = reviseStudioTheme(narrowDocument, {
    bindings: { 'font.ui': ref },
  });
  const originalUI = baseResolved.assets['font.ui'];
  const narrowedDocument = reviseStudioTheme(wideDocument, {
    bindings: { 'font.ui': { id: originalUI.id, revision: originalUI.revision } },
  });
  const snapshots = {
    narrow: resolvePresentation(narrowDocument),
    wide: resolvePresentation(wideDocument),
    narrowed: resolvePresentation(narrowedDocument),
  };
  assert.equal(snapshots.narrow.assets['font.ui'].kind, 'recipe');
  assert.equal(snapshots.wide.assets['font.ui'].file.sha256, font.file.sha256);
  assert.equal(snapshots.narrowed.assets['font.ui'].kind, 'recipe');
  const documents = [base, narrowDocument, wideDocument, narrowedDocument];
  const beforeDocuments = documents.map(fingerprint);
  const beforeSnapshots = Object.fromEntries(
    Object.entries(snapshots).map(([name, snapshot]) => [name, fingerprint(snapshot)]),
  );
  const gates = [],
    pending = [],
    surfaces = [];
  let nextRead = null,
    nextLoad = null,
    weightFailure = null;
  const calls = { reads: 0, loads: 0 };
  class FontBlob extends Blob {
    async arrayBuffer() {
      calls.reads++;
      const gate = nextRead;
      nextRead = null;
      if (gate) {
        gate.started.resolve();
        await gate.completed.promise;
      }
      return super.arrayBuffer();
    }
  }
  // One Blob is shared by every valid revision/surface within this case.
  const blob = new FontBlob([bytes], { type: 'font/woff2' });
  const blobs = new Map([[row.sha256, blob]]);
  const doc = new Document();
  doc.createElement = (tag) => new PreviewElement(doc, tag);
  const registered = new Set(),
    registrations = [],
    deletions = [],
    constructed = [];
  doc.fonts = {
    add(face) {
      assert.equal(face.status, 'loaded');
      registered.add(face);
      registrations.push(face);
      return this;
    },
    delete(face) {
      deletions.push(face);
      return registered.delete(face);
    },
    has: (face) => registered.has(face),
    values: () => registered.values(),
    [Symbol.iterator]: () => registered[Symbol.iterator](),
  };
  class FixtureFontFace {
    constructor(family, source, descriptors = {}) {
      assert.equal(family, `RLAsset-${row.sha256}`);
      assert.deepEqual(Buffer.from(source), bytes, 'The handler passes the complete genuine font.');
      this.family = family;
      this.weight = descriptors.weight || 'normal';
      this.style = descriptors.style || 'normal';
      this.display = descriptors.display || 'auto';
      this.status = 'unloaded';
      this.gate = nextLoad;
      nextLoad = null;
      this.promise = null;
      constructed.push(this);
    }
    get weight() {
      return this.currentWeight;
    }
    set weight(value) {
      if (weightFailure) {
        const error = weightFailure;
        weightFailure = null;
        throw error;
      }
      this.currentWeight = String(value);
    }
    load() {
      calls.loads++;
      if (!this.promise) {
        this.status = 'loading';
        this.promise = (async () => {
          try {
            if (this.gate) {
              this.gate.started.resolve(this);
              await this.gate.completed.promise;
            }
            this.status = 'loaded';
            return this;
          } catch (error) {
            this.status = 'error';
            throw error;
          }
        })();
      }
      return this.promise;
    }
  }
  const previous = new Map(
    ['document', 'FontFace'].map((name) => [
      name,
      Object.getOwnPropertyDescriptor(globalThis, name),
    ]),
  );
  Object.defineProperty(globalThis, 'document', { configurable: true, writable: true, value: doc });
  Object.defineProperty(globalThis, 'FontFace', {
    configurable: true,
    writable: true,
    value: FixtureFontFace,
  });
  const focus = doc.createElement('input');
  doc.body.append(focus);
  focus.focus();
  t.after(async () => {
    for (const surface of surfaces) surface.element.previewCleanup?.();
    for (const gate of gates) gate.completed.resolve();
    await Promise.allSettled(pending);
    for (const [name, descriptor] of previous) {
      if (descriptor) Object.defineProperty(globalThis, name, descriptor);
      else delete globalThis[name];
    }
    assert.deepEqual(documents.map(fingerprint), beforeDocuments);
    assert.deepEqual(
      Object.fromEntries(
        Object.entries(snapshots).map(([name, snapshot]) => [name, fingerprint(snapshot)]),
      ),
      beforeSnapshots,
    );
    assert.equal(blobs.size, 1);
    assert.equal(blobs.get(row.sha256), blob);
    assert.equal(
      createHash('sha256')
        .update(Buffer.from(await Blob.prototype.arrayBuffer.call(blob)))
        .digest('hex'),
      row.sha256,
    );
  });
  // Isolate cases, but retain THIS module/cache across all revisions and both
  // independently current surfaces in each case. No import between transitions.
  const { drawAssetPreview } = await import(
    `../../authoring/asset-studio/preview.mjs?font-role-cache=${++moduleId}`
  );
  const addSurface = (label) => {
    const element = doc.createElement('div'),
      status = doc.createElement('p'),
      cancel = doc.createElement('button');
    doc.body.append(element, status, cancel);
    const surface = { element, status, cancel, label };
    surfaces.push(surface);
    return surface;
  };
  const a = addSurface('Saved font preview'),
    b = addSurface('Draft font preview');
  const draw = (surface, snapshot, role = 'display') => {
    const slot = base.slots.find((entry) => entry.id === `font.${role}`);
    const result = drawAssetPreview(
      surface.element,
      slot,
      snapshot.assets[slot.id],
      snapshot,
      blobs,
      {
        mode: 'native',
        background: 'checker',
        geometry: false,
        motion: 'paused',
        statusTarget: surface.status,
        cancelButton: surface.cancel,
        label: surface.label,
      },
    );
    pending.push(result);
    return result;
  };
  const delay = (boundary) => {
    const gate = { started: deferred(), completed: deferred() };
    gates.push(gate);
    if (boundary === 'bytes') nextRead = gate;
    else nextLoad = gate;
    return gate;
  };
  const remember = (result) => {
    pending.push(result);
    return result;
  };
  const rejectNextWeightUpdate = () => {
    weightFailure = new DOMException('Fixture font weight update was rejected.', 'SyntaxError');
  };
  return {
    a,
    b,
    snapshots,
    draw,
    delay,
    remember,
    rejectNextWeightUpdate,
    calls,
    doc,
    focus,
    registered,
    registrations,
    deletions,
    constructed,
    family: `RLAsset-${row.sha256}`,
  };
}

function assertCoverage(face, low, high) {
  const weights = String(face.weight).trim().split(/\s+/).map(Number);
  assert.ok(
    weights.length === 1 || weights.length === 2,
    'A single weight or range is registered.',
  );
  assert.ok(
    weights.every((weight) => Number.isFinite(weight) && weight >= 400 && weight <= 600),
    'Descriptor remains within this actual Exo fixture’s supported 400–600 range.',
  );
  const min = weights[0],
    max = weights.at(-1);
  assert.ok(min <= low && max >= high, `Registered ${face.weight} must cover ${low}–${high}.`);
}
function assertSharedFace(view, low = 400, high = 600) {
  assert.equal(view.registered.size, 1, 'One successful font is registered for this hash.');
  assert.equal(
    view.registrations.length,
    1,
    'A compatible role change does not register a competing face.',
  );
  assert.equal(view.deletions.length, 0, 'A shared live face is not removed.');
  const face = [...view.registered][0];
  assert.equal(face.family, view.family);
  assert.equal(face.style, 'normal');
  assertCoverage(face, low, high);
  return face;
}
function assertReady(view, surface) {
  assert.equal(surface.status.dataset.state, 'ready');
  assert.match(statusText(surface.status), /ready\./);
  assert.equal(surface.element.getAttribute('aria-busy'), 'false');
  const samples = surface.element.querySelectorAll('.font-file-sample');
  assert.ok(samples.length > 0, 'The actual handler renders the current font sample.');
  for (const sample of samples) assert.equal(sample.style.fontFamily, view.family);
  assert.equal(view.doc.activeElement, view.focus);
}
function frozenSurface(surface) {
  return {
    children: [...surface.element.children],
    text: surface.element.textContent,
    message: statusText(surface.status),
    state: surface.status.dataset.state,
    busy: surface.element.getAttribute('aria-busy'),
    cancelText: surface.cancel.textContent,
    cancelHidden: surface.cancel.hidden,
  };
}
function assertUnchanged(view, surface, before) {
  assert.deepEqual(
    frozenSurface(surface),
    before,
    'Late work cannot mutate an abandoned surface, status or recovery action.',
  );
  assert.equal(view.doc.activeElement, view.focus);
}
async function overlapping(view, boundary) {
  const gate = view.delay(boundary);
  const older = view.draw(view.a, view.snapshots.narrow);
  const reached = await Promise.race([
    gate.started.promise.then(() => true),
    older.then(() => false),
  ]);
  assert.ok(reached, `The actual handler must reach the held ${boundary} boundary.`);
  const newer = view.draw(view.b, view.snapshots.wide, 'ui');
  assert.equal(view.a.element.getAttribute('aria-busy'), 'true');
  assert.equal(view.b.element.getAttribute('aria-busy'), 'true');
  assert.match(statusText(view.b.status), /reading and decoding/);
  return { gate, older, newer };
}

test(
  'sequential same-file role expansion widens the one face while both previews remain current',
  options,
  async (t) => {
    const view = await harness(t);
    await view.draw(view.a, view.snapshots.narrow);
    assertReady(view, view.a);
    const face = assertSharedFace(view, 600, 600);
    const original = frozenSurface(view.a);
    await view.draw(view.b, view.snapshots.wide, 'ui');
    assertReady(view, view.b);
    assert.equal(assertSharedFace(view), face);
    assertUnchanged(view, view.a, original);
  },
);

for (const boundary of ['bytes', 'load']) {
  test(
    `same-file widening during pending ${boundary} serves both current surfaces`,
    options,
    async (t) => {
      const view = await harness(t);
      const { gate, older, newer } = await overlapping(view, boundary);
      gate.completed.resolve();
      await Promise.all([older, newer]);
      assertReady(view, view.a);
      assertReady(view, view.b);
      assertSharedFace(view);
      assert.equal(
        view.constructed.length,
        1,
        'The two current consumers share the same compatible face.',
      );
    },
  );
}

test(
  'a later narrow snapshot cannot shrink a face still serving a wider current surface',
  options,
  async (t) => {
    const view = await harness(t);
    await view.draw(view.b, view.snapshots.wide, 'ui');
    const face = assertSharedFace(view),
      wider = frozenSurface(view.b);
    await view.draw(view.a, view.snapshots.narrowed);
    assertReady(view, view.a);
    assert.equal(assertSharedFace(view), face);
    assertUnchanged(view, view.b, wider);
  },
);

for (const boundary of ['bytes', 'load']) {
  for (const cancelled of ['narrow', 'wide']) {
    for (const outcome of ['success', 'failure']) {
      test(
        `cancel ${cancelled} consumer during shared ${boundary}; late ${outcome} respects both owners`,
        options,
        async (t) => {
          const view = await harness(t);
          const { gate, older, newer } = await overlapping(view, boundary);
          const abandoned = cancelled === 'narrow' ? view.a : view.b;
          const live = cancelled === 'narrow' ? view.b : view.a;
          abandoned.cancel.onclick();
          assert.equal(abandoned.status.dataset.state, 'detached');
          assert.equal(abandoned.element.getAttribute('aria-busy'), 'false');
          const kept = frozenSurface(abandoned);
          if (outcome === 'failure')
            gate.completed.reject(new Error('Fixture font preparation failed.'));
          else gate.completed.resolve();
          await Promise.all([older, newer]);
          assertUnchanged(view, abandoned, kept);
          if (outcome === 'success') {
            assertReady(view, live);
            assertSharedFace(view);
          } else {
            assert.equal(live.status.dataset.state, 'error');
            assert.match(statusText(live.status), /Fixture font preparation failed/);
            assert.equal(live.cancel.textContent, 'Retry preview');
            assert.equal(live.element.getAttribute('aria-busy'), 'false');
            assert.equal(view.registered.size, 0);
            // Real recovery action, not a cache reset or new module import.
            await view.remember(live.cancel.onclick());
            assertReady(view, live);
            assertSharedFace(view, cancelled === 'narrow' ? 400 : 600, 600);
            assertUnchanged(view, abandoned, kept);
          }
          // The cancelled observer can deliberately retry after shared settlement.
          await view.remember(abandoned.cancel.onclick());
          assertReady(view, abandoned);
          assertReady(view, live);
          assertSharedFace(view);
        },
      );
    }
  }
}

test(
  'a failed shared FontFace.load can retry without cache reset and register one successful face',
  options,
  async (t) => {
    const view = await harness(t);
    const { gate, older, newer } = await overlapping(view, 'load');
    gate.completed.reject(new Error('Fixture font decoder rejected the bytes.'));
    await Promise.all([older, newer]);
    for (const surface of [view.a, view.b]) {
      assert.equal(surface.status.dataset.state, 'error');
      assert.match(statusText(surface.status), /Fixture font decoder rejected/);
      assert.equal(surface.element.getAttribute('aria-busy'), 'false');
    }
    assert.equal(view.registrations.length, 0);
    await view.remember(view.b.cancel.onclick());
    assertReady(view, view.b);
    const face = assertSharedFace(view),
      wider = frozenSurface(view.b);
    await view.remember(view.a.cancel.onclick());
    assertReady(view, view.a);
    assert.equal(assertSharedFace(view), face);
    assertUnchanged(view, view.b, wider);
  },
);

test(
  'a rejected weight setter preserves the loaded narrow face and permits a real widening Retry',
  options,
  async (t) => {
    const view = await harness(t);
    await view.draw(view.a, view.snapshots.narrow);
    const face = assertSharedFace(view, 600, 600),
      older = frozenSurface(view.a);
    const priorWeight = face.weight,
      priorCalls = { ...view.calls };
    view.rejectNextWeightUpdate();
    await view.draw(view.b, view.snapshots.wide, 'ui');
    assert.equal(view.b.status.dataset.state, 'error');
    assert.match(statusText(view.b.status), /Fixture font weight update was rejected/);
    assert.equal(view.b.cancel.textContent, 'Retry preview');
    assert.equal(view.b.element.querySelectorAll('.font-file-sample').length, 0);
    assert.equal(
      face.weight,
      priorWeight,
      'A rejected API update preserves the loaded descriptor.',
    );
    assert.equal(assertSharedFace(view, 600, 600), face);
    assertUnchanged(view, view.a, older);
    await view.remember(view.b.cancel.onclick());
    assertReady(view, view.b);
    assert.equal(
      assertSharedFace(view),
      face,
      'Retry widens the existing successful registration.',
    );
    assert.deepEqual(
      view.calls,
      priorCalls,
      'A descriptor retry does not reread or reload these bytes.',
    );
    assertUnchanged(view, view.a, older);
  },
);

test(
  'repeated equal and narrower role requests reuse the loaded face without another byte read or load',
  options,
  async (t) => {
    const view = await harness(t);
    await view.draw(view.b, view.snapshots.wide, 'ui');
    const face = assertSharedFace(view),
      wider = frozenSurface(view.b);
    const priorCalls = { ...view.calls };
    for (const [snapshot, role] of [
      [view.snapshots.narrow, 'display'],
      [view.snapshots.wide, 'ui'],
      [view.snapshots.narrowed, 'display'],
      [view.snapshots.narrowed, 'display'],
      [view.snapshots.wide, 'ui'],
    ]) {
      await view.draw(view.a, snapshot, role);
      assertReady(view, view.a);
      assert.equal(assertSharedFace(view), face);
      assert.deepEqual(view.calls, priorCalls);
      assertUnchanged(view, view.b, wider);
    }
  },
);
