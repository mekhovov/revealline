# Static source and test review

The root reviewed the actual proposed source, complete15-case test file, prior eight-case specimen file, schema/revision helper and committed provenance. No Node, syntax checker, formatter, test, browser or font decoder ran. Definitions remain unexecuted.

## Implementation

Only the actual font-file specimen branch and font-preparation/cache region differ from the committed preview. [Static segment checks](source-scope-review.json) confirm the intervening preview branches and following drawing functions are unchanged; the specimen segment is byte-identical to the preserved T01 proposal. The independent peer review confirms the shared-request publication, pre-construction accumulation, setter-before-bounds update, identity-checked failure eviction and retained successful registration.

The mechanism assumes ordinary synchronous native FontFace construction/setters and one Studio document per module instance. It deliberately supports concurrent preview consumers and a reentrant/asynchronous blob-read boundary. It does not claim arbitrary JavaScript-reentrant constructor/setter shims, cross-document module reuse or an eviction policy for many distinct files. Those are not silently introduced as requirements of this compatible-weight correction.

## Regression definitions

- The15 new cases call `drawAssetPreview` in the same imported module across actual successive theme revisions. The immutable theme/revision and asset validation helpers are used, rather than replacing the runtime cache with a test implementation. Their execution has not occurred; source inspection alone does not establish successful fixture validation.
- Font input is the exact76,652-byte Exo2 WOFF2 and committed provenance. Its recorded `wght` axis is400–600. The file hash was checked during preparation; native axis/glyph inspection has not been renewed.
- The fixture's kind, MIME, revision binding and size are consistent with the inspected schema. Font slots allow this file type and have a2MiB budget. Theme inheritance preserves unchanged bindings across narrow→wide→narrow revisions.
- The finite FontFace model observes descriptor, load/status and document registration behavior. Assertions check successful current samples, actual file-family identity, one successful shared registration, readable operation state/Retry ownership and no stale focus/node changes. They do not prove browser font matching or CSS layout.
- The cancellation matrix has eight cases: two asynchronous boundaries, either consumer cancelled, and late success/failure. Because both consumers share one load, there are not two independent load-completion orders to count. The test definitions cover shared failed-load recovery and setter failure separately.
- Teardown retires surfaces, settles controlled gates, awaits tracked draw/Retry handlers and restores global descriptors. Original theme/snapshot/blob state is checked after the modeled interactions. This static review did not identify an obvious unsettled-load path; only execution can establish that the harness completes under both runtimes.

## Preparation correction and closure

The original104-file specimen capture did not include the newly imported `studio-session.mjs` or the additional existing picture-context test. Both are now captured from the same exact76dc source. The revised literal import review visits100 module/test paths with no missing captured targets; non-relative imports are Node built-ins. Explicit query-isolated imports still target the real preview file. Resource/provenance inputs are captured separately.

An initial broad import regex mistakenly read an in-string `from` token as a bare import. The corrected review restricts declaration matching and records the earlier metadata in `pre-closure-review-source-capture.json`. No runtime/source bytes changed in that correction. This is a finite source-dependency check, not JavaScript parsing or proof of all dynamic resources.

## Next allocated execution

Run the exact four-file cohort in `candidate-receipt.json`, with the new definitions on the original baseline for before/after discrimination. Record baseline behavior failures separately from harness failures, then correct and rerun the affected complete files. Run the candidate on both supported Node versions and explicit formatting/syntax checks, recapturing any changed bytes. Native actual-font, simultaneous-preview, EN/UA, contrast/reflow and public checks remain required afterward.

Do not describe23 new definitions as23 passes. Do not transfer the earlier P04 results or source76dc hosted outcomes to this changed preview. The owner must reconcile/adopt the final tested hunks and qualify the resulting release source separately.
