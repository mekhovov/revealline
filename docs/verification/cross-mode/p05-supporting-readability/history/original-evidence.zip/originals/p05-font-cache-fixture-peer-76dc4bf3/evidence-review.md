# Final P05 font evidence review

**Verdict: pass for the stated bounded Node evidence.** No discrepancy was found between the final sources, raw logs, input captures and candidate receipt. This is an independent read-only evidence review; I did not rerun Node or operate a browser, build, release, owner checkout or Git index.

## Source identity

The 107 baseline source files match the exact bytes, SHA256 and Git blob identities from `76dc4bf36baec11ce4dff6ca49773d3b9d6c0ae5`. Both trees contain exactly the captured 109 files, with no extra or missing files and no changed hashes. The two new test definitions are identical in the baseline and proposal; `authoring/asset-studio/preview.mjs` is the only runtime difference. The current source-capture and candidate-receipt hashes also match the post-run input-verification receipt.

The final preview is `81e49a8d66335b307fb6c90680eb6abfe0c92a6d4ed0787393847827e290f64f`; the cache test is `3bbe2c50ad70df6a90ccbb063703d9a3058138c2d60da88379007c9eb069428e`; the specimen test is `0e8d870cea4fa5cf412556fae6b4c9acd57cfab9341658ca4f1aed17d165503b`.

## Actual behavior results

| Runtime | Original preview | Corrected preview |
|---|---:|---:|
| Node 22.22.2 | 15 pass, 18 fail | 33 pass, 0 fail |
| Node 20.19.5 | 15 pass, 18 fail | 33 pass, 0 fail |

All four raw TAP logs contain the same 33 named top-level cases and matching subtest/result rows: 15 font-cache, eight font-specimen, six existing loading, and four existing picture-context cases. There are zero nested result/group rows, cancellations, skips, todos or process/harness failures. Recorded command lines use the same four files, `--max-old-space-size=100` and `--test-concurrency=1`. The four log hashes and summaries match their receipts.

The same 18 original-preview cases fail on both runtimes, all with `ERR_ASSERTION`: nine failures expose a cached `600` registration that cannot cover a later `400–600` requirement; one exposes the absent descriptor-update error/retry path; eight expose the missing role-specific specimen formatting. These are repeated scenario failures, not 18 independently identified bugs. In particular, the four original specimen cancellation/supersession cases reach their final sample assertions; their failures do not show that the original ownership fence failed.

The corrected cache exercises actual preview handlers across real validated revisions, shared concurrent surfaces, pending bytes and pending load, both observer cancellations, success/failure and actual Retry, widening, no narrowing, and equal/narrow reuse. It does not reset the module cache between transitions. The specimen checks use genuine committed font bytes and verify selected-family/style assignments and realistic English/Ukrainian text. The full default registry remains in the cache fixture's real setup path; the harness memory changes remove redundant retention rather than reducing those 15 definitions.

## Formatting and limits

The recorded explicit three-file formatting check exits zero, and the raw formatter log reports that all matched files use the configured style. Six recorded syntax checks cover those three files on Node 20 and 22, all exit zero. This review did not repeat those commands.

FontFace decoding, font registration, DOM and CSS are modeled. These results do **not** establish actual glyph/axis coverage, native font matching, computed cascade, reflow, visual readability, browser/device behavior, full-suite memory or performance, full source gates, integration, build, deployment, or public phase acceptance. The separate P04 recipe-context correction is not composed here. Earlier failed fixture attempts remain preserved and are excluded from these final counts.

Existing `review.md`, `review-receipt.json`, `follow-up.md` and `follow-up-receipt.json` are unchanged. Exact reviewed artifact hashes, all failed case names, command lines and scope are recorded in [evidence-review.json](evidence-review.json).
