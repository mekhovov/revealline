# Execution wording follow-up

The static verdict is unchanged. The root subsequently reported the baseline Node22 four-file cohort completed at the existing 100MiB heap limit: 33 behavior cases, 15 passed and 18 failed, including ten cache and eight specimen failures, with no harness process failure. This agent did not execute that run. Corrected Node22 and Node20 outcomes remain outside this review.

The root's formatted candidate cache test has SHA256 `f417c9d631fc2dc459e1325f8ccd387a17bafb205c249316402c3c37093d1c15` (independently read here). The original agent proposal hash is retained in the static receipt.

Before integration, remove the candidate test header's historical “Prepared, NOT EXECUTED” wording once the exact-source qualification is recorded. Keep the precise modeled/native scope statement. Preserve old proposal packets and receipts as historical inputs rather than rewriting them; final candidate source and qualification receipts must agree.
