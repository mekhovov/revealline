# P05 font-cache fixture static review

Verdict: no blocking defect found in the reviewed stepwise fixture. This is a read-only source review, not a runtime, native font, memory-budget, browser, integration or release acceptance.

## Behavioral fidelity

The 15 behavior definitions remain meaningful and unchanged from the prior fixture, apart from requesting only the snapshots used by two cases: sequential same-file widening (1); overlap at byte-read and FontFace.load boundaries (2); no narrowing beneath a still-current wider consumer (1); cancellation at both boundaries, of either consumer, with either late outcome and actual Retry (8); shared decoder failure and Retry (1); rejected descriptor mutation and Retry (1); equal/narrow reuse without rereading/reloading (1).

All transitions within each case use one imported real preview module and its cache. Separate current surfaces, one authenticated real Exo Blob, validated revision/resolve paths, stable hash-derived family, one successful face, readiness/error/detach states, unchanged abandoned/current neighbors and focus remain asserted. The wider descriptor is tested independently of the sample's visible font family. No test import or cache reset masks a transition. Mocks explicitly do not establish native decoding, glyph selection, supported axes or layout.

## Memory changes

The full default registry still enters every case. Source documents are now transient setup inputs, checked for mutation immediately after each real revision/resolution, rather than all retained until teardown. Resolved snapshots required by the case are still checked for mutation after handler execution. Fingerprints traverse the same validated ordinary JSON structure without an additional full serialization string. The helper intentionally assumes JSON-only validated values; it is not a general JavaScript object hash.

The separate FontFace/Blob factory closes over font bytes, family and boundary state only. This removes the avoidable route from a query-isolated preview module's permanent font cache through a mock class closure to the complete harness snapshots/DOM. Cached faces still retain small per-case gate/counter/constructed-face state; that is bounded test scaffolding and not full-registry retention. Explicit snapshot/map/array cleanup follows assertions. Actual peak memory and heap-limit compliance remain the root's runtime evidence to establish.

## Teardown

Teardown first fences both surfaces, resolves all held gates and awaits every recorded initial draw and actual Retry. Only after settlement does it restore prior global document/FontFace descriptors. It then verifies snapshot immutability, Blob ownership/identity and the actual bytes, and clears retained snapshot references. These steps cover early assertion failures while a byte/load boundary remains held.

Nonblocking hardening opportunity: wrap global restoration/reference clearing in `finally` so an unexpected exception in previewCleanup, fingerprinting, or a nonmutation assertion cannot prevent later cleanup. Current supplied cleanup functions and valid fixture values do not throw on their normal path. This is not a finding against the runtime cache correction and does not replace runtime results.

## Scope and provenance

Reviewed only the listed exact inputs and their diff. No Node, browser, build, test runner, owner checkout or Git index operation was performed. The root owns the bounded Node20/22 cohort; its results must be recorded separately. The proposal's prepared/not-executed comment describes this source packet; an executed composed candidate needs its own receipt, not a retroactive rewrite of old evidence.
