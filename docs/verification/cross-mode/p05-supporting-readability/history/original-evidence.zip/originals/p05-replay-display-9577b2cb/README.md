# Replay Theater shared display — isolated, locally qualified candidate

17 September 2026. Base **9577b2cbe9ac7072c5b75714fc4d37066a6964d6**. This eight-path proposal is independent of the earlier Studio/font/focus packets. It changes five production paths and three test paths. It has not been integrated, committed, versioned, built, browser-qualified or deployed. The release owner retains those operations.

## Result

Replay adopts shared Theme/Plain, Standard/Large and Reduced effects before async startup; its canvas receives the effective motion cap and text face. Preference edits preserve recording identity, paused/playing intent and exact checkpoints. Loading failure leaves reading controls available; terminal exit rejects late startup. The shared authority now refreshes current preferences/system reduction after a persisted return while retaining failed-save intent and suppressing duplicate notifications. No new profile storage or replay-format fields are introduced.

[Final patch](final.patch) · [exact changed-file pins](final-pins.json) · [independent static review](review/static-review.md) · [test summaries](test-summary.json)

Patch SHA-256: `25fbd32beebe2e508fb78555be4cc2c83415cf2af3d81822a52100a8a4f85349`. It applies cleanly with `git apply --check` to the captured exact baseline. The initial agent hunk and its hashes remain historical, before parent formatting and scoped CSS corrections.

## Executed verification

| Cohort | Node 20.19.5 | Node 22.22.2 | Scope |
| --- | --- | --- | --- |
| Eight complete affected files at 100 MiB | 81 pass | 81 pass | Shared authority, real Replay host, wide artwork, navigation, replay player/verification, shared surfaces, direct-tool loading |
| Complete unchanged display-preferences-host file at owner-allocated 160 MiB | 9 reported passes | 9 reported passes | Eight leaf behaviors plus one parent group: Solo, Team and Versus preferences, paused state and controller handling |
| Augmented authority test against original production source | 27 pass / 4 expected failures | 27 pass / 4 expected failures | Four missing-restoration assertions discriminate the correction; all 26 pre-existing cases and ordinary/disposed guard pass |

The corrected nine-file cohort therefore reports **90 passes per runtime: 89 leaf behaviors plus one parent group**, not 180 independent behaviors. Five new authority cases and four new actual-host cases are included. Same final proposal bytes were used throughout the accepted runs, with recorded pre/post input pins. No test filtering or assertion weakening was used. [Formatting and twelve syntax checks](runs/final-static/receipt.json) pass; the format check explicitly names eight paths.

The initial attempt had missing exact-source archive/build-reference inputs and a host process heap failure. The second, after adding those exact Git resources, had 89 reported passes and one process failure at 100 MiB. The existing final Versus fixture exhausted that heap while decoding artwork. Both failed logs are preserved under `runs/proposal-node22-01/` and `runs/proposal-node22-02/`; they are not assertion passes. The owner then allocated 160 MiB solely for the complete unchanged host file on each runtime. All other files stayed at 100 MiB. No production/test source correction was made to bypass the memory failure.

For baseline discrimination only, the augmented authority test temporarily overlaid the original test in `baseline/`; its original bytes are retained under `baseline-original/` and restored after the runs. [Overlay identity](baseline-test-overlay.json) and each run's inputs record this explicitly. `baseline/` again contains 767 exact Git files. The proposal contains 769 captured source/resource files; these are inventory counts, not test counts.

## What remains before shipping

- Compose these hunks with the owner's current source and the earlier Studio/font/focus candidates. The shared-authority hunk overlaps that work: reconcile its ownership and requalify the combined source; do not add independent test totals into an integrated result.
- Actual computed/font-decoded Standard/Large and Theme/Plain rendering, late fonts, EN/UA text, 200% zoom, portrait/short-landscape, 44px targets and readable canvas labels.
- Real keyboard, touch and supported-controller operation of Interface/summary/selects/checkbox; focus, playback shortcuts and explicit resume. The old navigation cohort passes, but it does not prove the new controls on physical devices.
- Real delayed/failed boot with genuinely inert main, cross-tab updates, denied storage and browser Back/Forward. Modeled persisted events prove handlers, not actual BFCache admission.
- Exact committed source gates, ordinary build/readiness/integrity, immutable release and deployed bytes/play. No P05 phase acceptance follows from this local packet.

The new host fixture imports the actual application and real replay verifier/player, checking exact checkpoints and attempted writes. Its finite DOM is flattened and painter calls are observed through a mock, so it does not prove native layout, inert behavior, visible motion or font selection. The independent review records these limits.

All runtime processes are terminal. This lane opened no browser/server and changed no original workspace source/index/version or remote state.
