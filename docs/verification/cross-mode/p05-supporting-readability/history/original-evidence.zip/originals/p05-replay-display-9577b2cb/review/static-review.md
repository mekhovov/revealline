# Replay shared-display candidate: independent static review

Baseline: `9577b2cbe9ac7072c5b75714fc4d37066a6964d6`. All **767 baseline files** match their exact Git blobs. The proposal has769 files and changes8 paths:5 production and3 test paths. Exact sizes/hashes are in `static-source-pins.json`; no other proposal differences were found. These are source inventory counts, not runtime test counts.

**Result: no unresolved correctness defect found in the reviewed patch.** No Node tests, browser checks, formatter, build or source edits were performed by this reviewer. Root owns runtime and native qualification.

## Correctness and ownership

- The earlier delayed-storage duplicate is corrected. `display-preferences.mjs` validates the event key/area/current raw bytes, marks the record stored, then skips an identical raw state. Restored-page processing refreshes the current system cap, adopts changed valid storage only when there is no unsaved explicit choice, and never writes. Identical pageshow/storage/media delivery cannot manufacture another revision or notification.
- Invalid/deleted storage retains current intent; current system reduction still applies. A cap-only change does not advance the intent revision. Failed-save intent/warnings survive restoration. Reentrant observer changes remain authoritative. Disposal removes the new pageshow listener along with storage/media listeners.
- `replay-theater/display.mjs` is a page-owned adapter over that shared authority. It controls only three preferences, body presentation attributes and its status text. It displays the raw reduced-effects choice separately from the effective system cap. It does not load player profiles, recordings, assets or drafts; it does not manipulate playback, focus, or preview ownership.
- `app.mjs` mounts reading controls before awaiting startup dependencies. Exit during either awaited startup stage is fenced. Terminal pagehide closes display/presentation/status owners, while persisted pagehide retains them. Existing replay navigation still pauses on suspension, clears input, cancels pending imports and owns RAF/native subscription teardown after startup.
- The replay simulation/import/verification/transport functions are unchanged. The new render arguments are current effective reduction and text face. Theme choice, recording contents, seed, checkpoint computation, speed, grid and explicit Play/Step behavior remain separate. Interface changes do not call pause, reset, load or advance.
- The HTML removes the previous competing data-field-kit text-size control and leaves one shared owner. Interface controls sit in the header outside the boot-inert main region; failure can retain them. CSS uses existing token roles, Plain font variables and responsive one-column fields. New checkbox/readout/textarea selectors are sufficiently specific to override the inspected shared defaults. Computed native geometry remains a separate acceptance item.

## Regression-test quality

The5 new preference cases discriminate restored storage/cap behavior, denied-save preservation, malformed/deleted data, ordinary pageshow/disposal, and reentrant explicit choice. The first case now includes pageshow→late current storage→unchanged media ordering with stable notification and revision counts, directly addressing the review finding.

The4 new host cases import the actual app, run the actual replay preparation/simulation/checkpoint path, and inspect the real authority/adapter. They cover delayed startup, Plain/Large and raw/effective motion, unchanged paused and active playback checkpoints, final checkpoint equivalence, failed-save/persisted return, boot failure, and terminal exit during startup. The write ledger records attempted rejected writes and asserts the separate display key. Player-profile and suspended-flight sentinels stay untouched. Existing wide-artwork tests retain their assertions; the new window boundary and explicit pagehide cleanup support the new owner without weakening them.

These tests do not prove native rendering: the DOM is a boundary double, controls are flattened under main in the fixture, painting/font decoding are mocked, and persisted events are modeled. Therefore their startup-control assertions alone cannot prove native inert behavior, and modeled persisted return cannot prove that a browser actually admitted the page to its back-forward cache. Those limitations are appropriate to record, not implementation defects.

## Native/release evidence still required

- Actual computed Standard/Large and Theme/Plain font roles, late release-font application, realistic EN/UA specimens,200% zoom, portrait/short landscape reflow, minimum44px targets, and readable canvas labels.
- Keyboard/touch/controller navigation of the native details/summary, selects and reduced-effects checkbox; focus persistence; no competing handlers; playback shortcuts and explicit resume.
- Delayed/failed boot with genuinely inert main and usable header controls; cross-tab updates; failed storage; actual browser lifecycle/back-forward navigation where available. Report BFcache admission separately from cold navigation and modeled persisted events.
- Affected runtime cohorts and exact-source production/release gates, artifact/public bytes and deployed play. This static review neither grants release acceptance nor claims whole P05/F1.4 completion.
