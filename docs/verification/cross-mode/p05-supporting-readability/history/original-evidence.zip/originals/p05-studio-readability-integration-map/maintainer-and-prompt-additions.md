# Proposed guidance additions — not applied

These additions are for **P05 Studio readability, font specimens and selection focus**. They supersede only the older candidate handoff prompts that required composing unrelated P04 repairs or waiting for complete P05 before any scoped release. Preserve those historical packet originals unchanged. This map excludes P04.

## Maintainer contract

- One Studio-owned `createDisplayPreferences` instance owns the existing `revealline.display.v1` record. Only explicit Interface controls write it. Host subscribers update existing datasets, control values and notices; do not rebuild the inspector, draft, pending media, sprite history or audio. Studio never writes Solo progress.
- Keep serialized `pixel`/`plain`, `standard`/`large` and raw boolean reduction. The UI calls `pixel` Theme. Effective motion is the raw choice OR the system cap; clearing the cap resumes only the retained local Playing mode, with a reset clock.
- Resolve host font/palette aliases on the body and tag real host roles at creation. Selected uploaded-font and authored-component specimens retain their exact source identity. The font cache is keyed by original byte hash and accumulates compatible requested weight ranges; a failed descriptor update retains a usable previous registration and Retry must not duplicate a successful load.
- Preview subscriptions are read-only. Dispose owned frames/subscriptions, fence retired callbacks and avoid restarting motion on text-only changes. Persisted navigation may rebuild existing owned previews; preference changes themselves may not.
- Inventory selection replaces rows synchronously. Capture whether the activating foreground button owned focus before selection. On successful desktop selection focus its equivalent current selected button; retain foreground narrow Inspector handoff. Rejected prepared-upload or dirty-sprite selection preserves the original connected trigger and work. Never restore selection focus later from a Promise, timer or RAF.
- Stage only the three packets' related hunks plus current guidance/evidence. Do not replace the Studio tree, import P04 context repairs, reinterpret historical receipts or claim complete P05. Qualify the resulting exact source again.

## Implementation prompt

> Integrate the named P05 Studio readability, font specimens and selection focus subphase onto the current reviewed release source. Use the pinned integration map: font-cache, Studio F2, then inventory-focus; thirteen unique runtime/test paths. Recheck each old/context line against the chosen base. Preserve newer work and fail on an unexpected preimage. Keep original packet receipts and failed attempts unchanged. Exclude P04 picture-context, cold Back filter/selection and mutation-command focus changes. Apply the shared Interface, exact selected-font specimen/cache and synchronous inventory focus contracts. Update only the related guide, execution register, maintainer/asset skills and prompt hunks. Then run the complete affected cohort and normal source/build/production gates on the resulting committed source, followed by actual native/public checks. Do not allocate a version until the release owner reaches that gate; no prior source result qualifies this composition.

## Browser preservation prompt

> On the exact integrated source, record the actual served modules/font hashes and browser/version. Toggle Theme/Plain and Standard/Large while a real uploaded replacement is prepared, while a sprite is dirty and while encode is pending. Verify original upload bytes, selected slot, staged/undo history, preview identity and focus are preserved; the dirty sprite still requires Prepare. Verify selected-file EN/UA specimens at their actual weights and dimensions independently of host text. Exercise second filtered row Enter→Tab, repeat selection, narrow Inspector handoff and rejected prepared selection. Change local Playing/Paused/Reduced plus the real OS cap without time jumps or extra loops. Record true persisted Back/Forward and a second-tab storage change separately from cold reload. Do not count modeled events, emulated pointer/viewport, or an unadmitted BFCache return as physical-device or lifecycle acceptance.

## Keep separate

The retained native focus packet already observes corrected desktop Enter/Tab, repeated selection, narrow Inspector handoff and real prepared-font rejection on its own candidate. It does not qualify the newly integrated source or every Studio action. Cold Back filter/selection mismatch and successful Discard slot draft focus-to-BODY remain P04 work; neither is fixed by the inventory row handler. Complete Team/player presentation, 200%/contrast, broader controller/device coverage and full P05 remain separate.
