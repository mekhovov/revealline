# P05 Studio readability — exact integration map

**Ready for scoped hunk adoption against source206c; not applied or accepted.** Named scope: **Studio readability, font specimens and selection focus**. No new canonical phase ID, version or commit is allocated.

Authority: `206c4b9bdd7bc53aecf818f85a1cbf680814a4e5`, tree `8c999d0d381b4a8c57bb153512d341377aee210d`. The supplied publisher abbreviation `5419` is not a locally resolved Git object; no equivalence is inferred. Recheck any chosen later integration base before adoption.

## Exact composition

1. Qualified font specimen/cache packet: three paths; two preview hunks plus two new complete test files.
2. Studio F2 packet: eleven paths layered on that exact font result.
3. Inventory-focus packet: two overlapping paths layered on exact F2.

The union is **13 paths: eight production and five test files; seven modifications and six additions**. All **101 original unified hunks** matched exact old/context lines with zero offset in an in-memory composition. Each complete result matched its reviewed packet, and all thirteen final files match the final focus packet's captured tree. All 134 captured committed dependency files remain exact at206c. No conflicting hunk was found.

| Path | Operation | Owning layers | Applicability |
| --- | --- | --- | --- |
| authoring/asset-studio/component-specimens.mjs | modify | studio-f2 | clean |
| authoring/asset-studio/index.html | modify | studio-f2 | clean |
| authoring/asset-studio/interface-preferences.mjs | add | studio-f2 | clean |
| authoring/asset-studio/preview-motion.mjs | add | studio-f2 | clean |
| authoring/asset-studio/preview.mjs | modify | font-cache → studio-f2 | clean |
| authoring/asset-studio/scene-preview.mjs | modify | studio-f2 | clean |
| authoring/asset-studio/studio.css | modify | studio-f2 | clean |
| authoring/asset-studio/studio.mjs | modify | studio-f2 → inventory-focus | clean |
| game/test/asset-studio-font-cache.test.mjs | add | font-cache | clean |
| game/test/asset-studio-font-specimen.test.mjs | add | font-cache | clean |
| game/test/asset-studio-host-loading.test.mjs | modify | studio-f2 → inventory-focus | clean |
| game/test/asset-studio-interface-preferences.test.mjs | add | studio-f2 | clean |
| game/test/asset-studio-preview-motion.test.mjs | add | studio-f2 | clean |

The composed `.proposed.diff` is a cache-only review artifact generated from exact206c bytes and exact reviewed final bytes. No patch was applied to any source/index/worktree. `diff-check.json` documents the precise in-memory method; this is not a Git apply receipt, test pass or composed-source qualification. `proposed-paths.json` pins every input/result and the three original receipts. Exact receipt copies are retained in `original-receipts/`; their originals were not changed.

## Required related delivery

`required-guidance-paths.json` identifies seven existing guide/skill/prompt paths and one proposed evidence directory. `maintainer-and-prompt-additions.md` provides scoped text and examples. Those are a map only; current source guidance is untouched. In particular, update the older handoff instruction to compose P04: this subphase excludes those unrelated repairs. Keep current release facts and historical reports intact.

## Excluded work

- P04 picture-context/preview corrections and their separate receipts.
- Cold Back selection/filter restoration and focus after a successful mutation disables its trigger.
- New assets, font binaries/provenance, recipe approval mutations, gameplay/simulation/save changes, audio ownership, Team/player styling, campaign content or production-art generation.
- Full P05 completion, physical hardware/controller certification, online or native-store claims.

## Finite adoption/verification handoff

Recheck current-base equality and adopt only the thirteen reviewed hunks plus related documentation/evidence. Preserve source records for font33, F2 96 and focus original95/96→corrected96/96; these overlap and must not be summed. Run the complete twelve-file affected cohort on the combined source, then exact source/static/production/build gates. Carry S1–S10 forward with new exact-source bindings, distinguishing retained candidate observations from new passes. Native input/media preservation, actual fonts/EN-UA, reflow/zoom, system/storage lifecycle and real-device gaps remain visible. The later release owner handles version allocation, reviewed commit/PR, frozen publication and actual public-byte/journey acceptance. No current result in this map closes those gates.
