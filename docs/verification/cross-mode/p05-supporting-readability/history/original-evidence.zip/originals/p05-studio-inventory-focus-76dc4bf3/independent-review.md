# Independent inventory-focus correction review

17 September 2026. **Pass for the bounded implementation and original-versus-corrected evidence. No blocking defect found in the reviewed synchronous focus correction.** Native keyboard/touch behavior, source adoption and public acceptance remain separate. This review read source, test definitions, raw logs and receipts and rehashed the three captured trees; it ran no Node, tests, formatter, browser, build, source/index or remote operation.

## Implementation meaning

The old activating button's focus ownership is captured before `selectSlot()` replaces the inventory. `selectSlot()` calls `requireSettled()` before changing selection, clearing sprite state or refreshing, so either prepared-image or unsaved-sprite rejection leaves the original connected button and editing state intact.

After a successful synchronous selection, the current document must still be foreground. Desktop restoration then requires that the original trigger owned focus; it focuses the replacement selected button in the inventory, not a specimen button elsewhere. The selection changes no filter or asset binding, so the equivalent selected row remains part of the same filtered list. Reselecting the current item receives the same repair. An unfocused desktop trigger does not steal focus from a filter or another control.

Foreground narrow activation retains the existing deliberate Inspector handoff at `(max-width: 700px)`, including activation when the button did not own focus. Both narrow and desktop handoffs are vetoed in a background document. This is the documented chosen navigation policy, not an accidental requirement that every activation restore the list row.

No promise, animation frame or timer restores focus. Preview work may finish after the user has focused another control without taking focus back. The correction makes no storage, artwork, simulation, font, Interface preference or motion-policy change.

## Test quality and observed results

The augmented test imports the actual Studio module against parsed production HTML and the established storage/upload/sprite fixtures. Its local `StudioElement.remove()` models focus falling back to the body when a connected focused subtree is removed; no shared test helper was changed. That addition exposes the original failure instead of letting a detached node remain the mock's active element.

The assertions cover focused desktop selection and reselect, focus moved elsewhere before late completion, unfocused desktop activation, background desktop activation, foreground narrow activation with and without prior button focus, background narrow activation, and both prepared-image and unsaved-sprite rejection paths. Original upload/save-byte, preference ownership and lifecycle assertions remain in the corrected host case.

| Runtime | Original runtime, identical augmented test | Corrected runtime, identical augmented test |
| --- | --- | --- |
| Node 22.22.2 | 95 pass / 1 fail | 96 pass / 0 fail |
| Node 20.19.5 | 95 pass / 1 fail | 96 pass / 0 fail |

I independently read all four logs and matched their hashes to the receipts. Each contains the same 96 ordered top-level results from the same twelve complete test files at 100 MiB and concurrency 1, with no groups, skipped/cancelled/todo or process/harness failures. Both original failures are exactly **“Desktop activation retains the selected row.”** in the actual Studio host case. Both corrected runs pass that entire case. The original case stops at that first assertion; its later assertions are not claimed as baseline results.

The focus scenarios extend one existing test rather than adding more counted cases. The source fixture honestly selects the same three font slots by `recipe` plus `font.` because compiled release assets are absent. The earlier missing-row fixture admission failure is preserved and excluded from defect reproduction. Neither `.click()` nor the focus mock proves actual Enter/Tab ordering or native compiled Kind=font behavior; the parent's separate native retest must supply that evidence.

## Source and receipt integrity

All 141 baseline files, 141 corrected proposal files and 141 parent F2 files match their respective captured hashes; no extra or missing files were found. The baseline differs from the qualified parent only by the augmented host test. The corrected proposal differs from that parent only by `studio.mjs` and that same test. The only difference between the two tested trees is the runtime Studio module, so the before/after discrimination does not swap test definitions.

The two-file patch reconstructs byte-for-byte from the parent and corrected trees. Its SHA256 is `7b5b52bb32af921924e38f5118e8e0d004fd5729df2bbb82777a850cf5f9fc41`. The runtime source hash is `2def0bc48bea7573be54aa917e52e6636da98d27314f8fa009056cfa60bf8c4e`; final host test hash is `f5a180f5192dee490d98a09795b9b8ed81bd6595a08f06b3065df5f36ccbb995`.

The explicit two-path formatting log matches its receipt hash and successful exit. All four recorded syntax checks cover the two changed MJS files on both runtimes and exit zero. These commands were reviewed, not rerun. The adjacent [JSON review receipt](independent-review.json) records independently checked hashes, deltas, commands, case order and result counts.

## Integration cautions and remaining native work

- Adopt the small selection-handler hunk after or together with the F2 candidate. Do not overwrite a newer whole `studio.mjs`: the owner's source or other pending P04 work may contain unrelated protection, transfer or authoring changes. Preserve the host-role annotations, Interface authority, operation ownership, preview lifecycle and augmented host assertions already in F2.
- The older P04 picture-context repair belongs to the preview/owner-context path. This focus hunk does not overlap that logic, include the repair, or qualify it. F2 itself changes `preview.mjs` for host annotations, motion propagation and font behavior; composing the separate P04 repair must preserve authenticated owner-context loading, current/abort fences, exact picture identity/fitting and those F2 changes. Run the relevant combined regression and native journeys on the resulting exact source; this 96-case focus receipt cannot be borrowed for a changed composition.
- The restoration relies deliberately on synchronous `selectSlot()`. If installation, selection or refresh later becomes asynchronous, re-review focus intent/currentness instead of moving this focus call into a late completion that can steal focus.
- Finish native second-row Enter→Tab, repeated activation, foreground/background/unfocused desktop behavior and the narrow Inspector handoff using these exact corrected runtime bytes. Check visible focus and scroll position at the relevant breakpoints. Native compiled font-file selection remains distinct from the source-recipe fixture.
- Cold-return inventory selection/filter restoration remains a separate open finding. No full Studio/P05/P03 acceptance, source adoption, version/commit, release gates, freeze, Pages or public play is established by this correction packet.
