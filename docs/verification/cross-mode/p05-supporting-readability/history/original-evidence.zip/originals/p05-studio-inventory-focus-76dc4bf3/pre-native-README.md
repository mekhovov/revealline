# Studio inventory focus correction

The native Studio review found that selecting the second filtered font with Enter rebuilt the inventory, left focus on the body and sent the next Tab back to the first row. This isolated correction preserves the selected desktop row after a successful synchronous selection.

## Behavior

- Capture whether the activating asset button owns focus before selection.
- After successful selection, focus its replacement selected button on desktop only when that original button owned focus and the document is still foreground.
- Preserve the existing foreground narrow-screen Inspector handoff at `(max-width: 700px)`, including deliberate activation without prior button focus. Background documents receive neither handoff.
- Leave rejected selections untouched: prepared replacements and unsaved sprite edits retain the original connected button, selection and preview markers.
- Perform no delayed focus restoration. Moving focus elsewhere while previews settle remains respected.

The implementation changes only `authoring/asset-studio/studio.mjs`; the regression extends the existing actual Studio host case in `game/test/asset-studio-host-loading.test.mjs`. Source context is the exact 141-file qualified Studio F2 candidate, itself layered on 76dc and the font correction. The original F2 packet, native server source, owner checkout and index remain unchanged.

## Qualification

| Runtime | Original runtime with augmented test | Corrected runtime with identical test |
|---|---:|---:|
| Node 22.22.2 | 96 cases: 95 pass, 1 focus assertion failure | 96 pass, 0 fail |
| Node 20.19.5 | 96 cases: 95 pass, 1 focus assertion failure | 96 pass, 0 fail |

Final [runtime-attempt2](runtime-attempt2/) contains raw logs and command receipts. Every run used the same 12 complete affected test files, 100 MiB old-space and concurrency 1. There are no nested groups, skips, cancellations, todos or harness/process failures. The host focus scenarios are assertions within one existing case; they are not counted as additional tests.

The explicit two-file formatter check and four syntax checks passed. All 282 captured baseline/proposal input hashes remain unchanged, and the parent 141 files still match the original F2 manifest. [Input verification](runtime-attempt2/input-verification.json), [candidate receipt](candidate-receipt.json) and [reviewed patch](proposal.diff) pin the result.

The first attempt failed before the focus assertion because this source-only host fixture exposes font recipes, not compiled font-file assets. Its inputs, exact failed test source and logs remain in [runtime-attempt1](runtime-attempt1/); it is excluded from production-defect reproduction. The corrected fixture filters the same three font slots by their actual recipe kind and `font.` query. The native compiled Kind=font journey remains separate.

## Handoff and acceptance

Source SHA256: `2def0bc48bea7573be54aa917e52e6636da98d27314f8fa009056cfa60bf8c4e`.

Final host test SHA256: `f5a180f5192dee490d98a09795b9b8ed81bd6595a08f06b3065df5f36ccbb995`.

Patch SHA256: `7b5b52bb32af921924e38f5118e8e0d004fd5729df2bbb82777a850cf5f9fc41`.

Candidate receipt SHA256: `c9ca7c7bfe3501821db24a046b4107813be2d6ba1ac4ce9a1fa2cf62340e0628`.

The bounded execution lane is returned; all sessions are terminal. Native retest must use these corrected runtime bytes and exercise second-row Enter→Tab, repeated activation, background/unfocused desktop behavior and the narrow Inspector handoff. No native acceptance, source adoption, version/commit, full release gates, build, freeze, Pages deployment or public play is claimed by this packet. Cold-return inventory selection/filter restoration is a separate finding and is not changed here.

Maintainer guidance for integration: when synchronous list replacement destroys the activating node, preserve keyboard focus on the equivalent current item only if the old trigger owned it; keep deliberate mode/layout navigation policy explicit. Never repair this with a late Promise, timer or frame callback that can take focus back after the player has moved on.
