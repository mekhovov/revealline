# Preserved fixture admission failure

Node22 baseline ran96cases:95pass,1fail. The failure was before focus behavior at the missing font.ui filtered-row assertion. This source-host fixture intentionally serves404 for published assets, so its font slots are recipes and Kind=font matches none. This result does not reproduce the production focus bug. The next fixture revision filters the same three source font slots by their actual recipe kind and font. search query.
