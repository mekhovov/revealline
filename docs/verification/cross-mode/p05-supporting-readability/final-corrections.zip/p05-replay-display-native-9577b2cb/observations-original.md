# Native observations — original qualified Replay candidate

Observed in Codex in-app browser on isolated `http://127.0.0.1:53962/`, exact9577 plus the five pinned production overrides. Browser interaction, viewport emulation and read-only DOM observations; not physical-device evidence. Original candidate bytes are unchanged.

## Confirmed journeys

- At1440×900, keyboard Tab→Interface→Enter opens the disclosure. Native selects require Space to open, then arrows/Enter to choose. Plain/Large and raw Reduced effects apply; focus stays on the operated element and Copper Crossing stays paused at tick0. Closed disclosure children leave keyboard order.
- At390×844 Plain/Large, both selects are324×45.5CSSpx, checkbox44×44; document width390. Layout stacks, explanatory text wraps, no horizontal clipping observed. At1440×900 selects430×45.5. Plain controls compute20px; Theme/Standard controls compute16px.
- Keyboard navigation reaches Step; three activations yield Copper tick3/1305, paused. Interface changes, viewport changes and second-tab changes preserve tick3 and visible lives/score/coverage. No implicit Play is observed.
- At844×390 Plain/Large, full legacy board328×246 at(150,110.65625), Play96×47 at(595,169.15625), Restart96×47, Step96×74 and Speed96×45.5. All board/transport controls fit; document width844. Readouts remain below this position in the scrollable tool. This is not a couch/touch-layout qualification.
- A fresh second tab cold-adopts saved Plain/Large while real themes/presets requests are held. Boot text remains “Preparing the theater…”, main has `inert` and aria-busy=true; header controls are enabled and reachable with keyboard. Changing to Theme/Standard/reduction while held retains those choices when original responses resume and Copper loads paused. The first tab adopts the changes and retains tick3.
- Explicit startup503 responses produce the real “The theater could not start: Presentation assets could not load. Reload the page to try again.” error. Main remains inert, header controls still accept keyboard Plain/Large. Restoring original bytes and Reload recovers to a paused recording with saved choices.
- Actual Copper playback at2× finishes tick1305,74.1% coverage,3lives,12590 recorded points, with `Final checkpoint matches · 861a6de2ffd7e119 · No progress awarded.`
- A real Back-to-game→browser-Back journey reinitializes the Replay UI. Switchyard example selection is restored by the browser, but its playback resets from tick3 to tick0. Current Theme/Standard/rawOff choices from the second tab appear correctly. There is no observed `pageshow.persisted` or browser BFCache admission report: this is history/cold-start evidence only, not successful cached-state preservation. The checklist's assumption that all cold returns must select Copper is too narrow; browser form restoration can retain the example.

## Native defects requiring a successor

1. **Jump focus:** activating “Jump to playback” scrolls to `#playback` but leaves BODY focused. The next real Tab goes to `#return-game`, so keyboard users return to the page header. Reproduced via keyboard activation and pointer activation followed by Tab.
2. **Counter role:** `.readouts` computes14px Standard/18px Large instead of intended16/20, despite tokens20/18 in Large. The later surfaces `:is(...)` list includes `.face-buttons span`, giving maximum specificity(0,3,1) and tying the proposed Replay selector; the later rule wins. A Replay-only stronger scope is prepared separately.
3. **Completion focus:** after Play finishes the recording, actual DOM activeElement is BODY (empty id), phase complete/tick1305. The next Tab goes to `#return-game`. A conditional handoff to Restart must apply only when the newly disabled transport control owned focus, preserving unrelated editors/background work.

## Evidence limits and tool observations

Real OS cap transitions, denied browser storage,200% browser zoom, physical touch/gamepad, exhaustive glyph/native-font matching, offline and public release were not performed. Read-only `document.fonts` iteration returned an empty tool result and is not used as proof of loaded or missing fonts. Computed family names and served WOFF2 hashes alone are not binary/native-selection proof. `main.inert` was not exposed by the read-only bridge, so the actual inert attribute and absent native main controls were used. Exact-label lookup for Text style had no match; observed IDs and real keyboard controls worked. These tool limitations are not product defects.

The old 90-result modeled cohort and this bounded native review remain distinct. Native failures are retained even though the prior model cohort passed.
