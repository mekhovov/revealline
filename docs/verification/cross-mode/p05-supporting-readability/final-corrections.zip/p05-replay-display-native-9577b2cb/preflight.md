# Native Replay preflight

Base: `9577b2cbe9ac7072c5b75714fc4d37066a6964d6`. Observed origin/main: `5419c020b79b9712f5986699c76f2df9d0f981d0`. Git diff reports no changes between them under game, authoring, scripts, package files or workflows; main has advanced through the v0.59.1 publishing PR. The original mixed workspace remains at677b and was not used as content input.

The local server is prepared but has not yet been started. It serves exact Git blobs plus the five qualified production overrides from [runtime-overrides.json](runtime-overrides.json); no test fixture or developer shortcut is inserted into the page. Every response body is hashed. `boot-policy.json` can hold or fail the two startup content requests to exercise the actual loader and early Interface controls. Fault responses are explicitly distinguished from production source in its ledger. Real data/model fields will only be inspected through rendered UI or permitted read-only browser observations.

Planned evidence categories: native browser interaction/layout, exact loaded resource identity, and visual review. Emulated viewport sizes are not physical touch/controller devices. A successful back navigation is not automatically evidence of BFCache admission. Exact simulation checkpoints are established separately by the existing model tests; the browser can verify displayed playback phase/tick/checkpoint and unchanged recording identity.

Production source and prior receipts remain immutable. Browser allocation is coordinated with the release owner's public work; this packet does not own source staging, versions, release tags or publishing.
