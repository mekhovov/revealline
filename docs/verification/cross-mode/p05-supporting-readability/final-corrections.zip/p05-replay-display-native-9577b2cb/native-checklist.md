# Replay candidate — bounded native acceptance checklist

Prepared 17 September 2026 from the actual candidate HTML, application, navigation, display adapter, shared authority and winning CSS. **This document specifies checks; none was executed by its author.** The parent owns the served-byte map, native browser lane, network conditions and evidence recording.

Candidate: [Replay packet](../p05-replay-display-9577b2cb/README.md), exact base `9577b2cbe9ac7072c5b75714fc4d37066a6964d6` plus [final patch](../p05-replay-display-9577b2cb/final.patch), SHA-256 `25fbd32beebe2e508fb78555be4cc2c83415cf2af3d81822a52100a8a4f85349`. The CSS includes the final scoped readout/textarea specificity correction. These checks do not cover the separate Studio candidate or complete P05.

## Preparation and evidence rules

- Serve the captured exact candidate on one isolated local origin. Use that same scheme/host/port for both tabs. Open `/game/replay-theater/`. Parent records exact source/resource pins and checks successful served responses against them. Do not silently replace missing data/artwork with mock content.
- Use ordinary keyboard, pointer/touch, browser navigation and an actual supported controller where available. No synthetic keyboard/gamepad/storage/pageshow events, direct storage writes, DOM state mutation, private app objects, fake painter or bypassed input handlers.
- Read-only DOM/AX inspection may corroborate visible values, active element, open/disabled/inert state, computed styles and element rectangles. Screenshots/visible behavior remain necessary for clipping, contrast and animation. Requested CSS families or downloaded font files alone do not prove native font selection.
- Record original preferences and OS motion state, use only the isolated origin, then restore deliberately changed settings at the end. Real system accessibility settings are preferred for the cap test. If only an explicitly supported browser media-emulation facility is used, identify it as emulated media policy, not a physical OS check. If unavailable, leave the cap transition open.
- Every row records URL, browser/platform, viewport, zoom/DPR, exact input method, start/end values, screenshot or visible readout, pass/fail/not-executed and limitations. Distinguish native browser resizing from a physical phone, native pointer from touch, and a real gamepad from modeled controller coverage.

## Visible observables

| UI | Observable and intended meaning |
| --- | --- |
| Header **Interface** | `details.replay-interface` / its `summary`; real native disclosure outside `main[inert]`. Closed on a cold page. |
| **Text style** | `#replay-text-face`: Theme (`pixel`) / Plain (`plain`). Native value and actual host appearance change; body `data-text-face` corroborates. |
| **Text size** | `#replay-text-size`: Standard / Large. Body `data-text-size` corroborates. |
| **Reduced effects** | `#reduced.checked` is **raw saved choice**, not the effective cap. An unchecked box with reduction active is correct when the system cap is on. |
| System-cap explanation | `#replay-system-reduction` shows “Your system requests reduced motion. Replay effects remain reduced; your saved choice is unchanged.” when cap forces reduction over raw Off. Body `data-effects="reduced"` corroborates; inspect visible canvas motion separately. |
| Save/application warning | `#replay-display-status` is a live status. It is normally hidden. A real denied save should explain session-only behavior; absence of a storage-denial facility means this remains untested. |
| Startup | `#boot-status`: “Preparing the theater…” then clears; ordinary failure says “The theater could not start: … Reload the page to try again.” Main remains inert until initialization succeeds. |
| Recording preparation | `#import-status` shows reading/verifying/artwork preparation and completion or error; `#cancel-load` is available during a pending recording load. This is distinct from initial boot, which has no Cancel action. |
| Recording identity/state | `#recording-name`, `#playback-phase`, `#tick-readout`, `#time-readout`, `#run-readout`, `#timeline[value]`, events and canvas. These are the accessible paused-state comparison; there is no public mid-recording checkpoint hash. |
| Playback | `#play-pause` says **Play** when paused; **Pause** while playing. Restart explicitly resets tick zero. **Step 1 tick** advances exactly one recorded tick and stays paused. The timeline is a progress element, **not a seek slider**. |
| Completion | `#checkpoint` displays “Final checkpoint matches · [hash] · No progress awarded.” and transport says recording complete. The pinned default Copper Crossing asset's hash is `861a6de2ffd7e119`; compare only when that exact asset is served. |
| Navigation | `#navigation-status` gives keyboard/controller hints and controller-edit confirmation/cancellation. `#return-game` is the ordinary Back link. |

## Shortest useful journeys

### N1 — save through UI, then cold Plain/Large and cap

1. At a ready Replay page, open Interface; choose **Plain**, **Large**, and Reduced effects **Off** using native controls. Record that no save warning appears. Close this tab or open a new same-origin Replay tab; do not use Back for this cold test.
2. On the fresh page, open Interface. Plain/Large must already be selected when the adapter attaches, before initial theme/preset loading finishes. Until the adapter attaches, disabled controls and boot feedback are expected; HTML alone does not read preferences. Inspect that late release-font arrival does not switch the host back to Theme/Standard.
3. With the actual system cap enabled, keep raw Reduced effects Off. Check the visible explanation, unchecked box, reduced body state and restrained canvas effects. Switch the OS cap off: raw choice stays Off; cap message clears; no Play command or tick jump occurs. Set raw On, then toggle the system cap on/off: raw On and effective reduction must remain On. Restore the requested setting.
4. At Standard versus Large, inspect computed/readable control and counter sizing: native controls/readouts 16→20px, supporting notes/technical textarea 14→18px, body roles 18→22px. The three loaded CSS layers must not downgrade readouts to secondary text. Verify actual rendered appearance and no clipped labels; these role checks do not establish every font glyph or canvas label.

### N2 — keyboard-only Interface and safe return

1. Focus the visible **Back to the game** link using ordinary Tab. Tab to **Interface**; Enter opens it. Traverse Text style → Text size → Reduced effects with Tab/Shift+Tab. Arrow keys must operate focused native selects; confirm by the browser's normal Enter/Tab behavior. Space toggles the checkbox once. Focus stays on the operated control, with a visible outline.
2. Shift+Tab back to the summary and close it with Enter/Space. Its hidden selects/checkbox must disappear from tab order. Reopen and verify values persist. Arrow-key navigation outside native editors must not trap or overwrite a select's native editing.
3. Use **Jump to playback**, then focus the canvas or ordinary transport controls. On the canvas, Space plays/pauses and Right Arrow steps one tick while paused. The same arrow in a select must change that choice rather than step the replay. Press Escape outside an active native browser picker: playback pauses and the exact Back link receives visible focus; it does not navigate until activated.
4. Record native focus (`activeElement`/AX) and visible values; do not infer keyboard reachability from a successful pointer click or from DOM containment alone.

### N3 — real controller-only reachability, edit/commit/cancel

1. After normal startup and recording preparation, use an actual supported controller: release all controls, press a face button to join, release again. Joining should not also activate Play. Record the real controller and connection/hint state. If no controller is available, leave this row open; do not inject gamepad state.
2. From the current focus, use D-pad navigation to the **Interface** summary, then South to open it. Navigate to Text style, South to begin the adapter's choice editing, D-pad to preview another value, then East to cancel. The visible value and saved choice remain unchanged; this edit cancellation must not follow the Back link.
3. Repeat and commit with South. Do the same for Text size. On Reduced effects, South toggles once. The controller's edit hint must be readable and the selected control/focus marker visible after reflow. Menu pauses and returns focus to transport; ordinary East outside editing pauses and focuses Back.
4. Close Interface with South; hidden children must not remain controller targets. Reopen. Disconnect/reconnect the controller: pause/neutral release still apply, with no automatic Play or duplicate activation. A keyboard or pointer assist in this journey must be disclosed rather than labeled controller-only.

### N4 — paused state, live preferences, completion

1. Let the default Copper Crossing load automatically. Use Step 1 tick three times, or Play briefly then Pause. Record recording name, tick, time, coverage/lives/score, selected presentation theme/speed/grid and visible canvas. Expand Recorded events if populated.
2. Change Plain↔Theme, Standard↔Large and raw Reduced effects in Interface without changing presentation theme. Wait long enough to compare the visible tick twice. All recorded state and selected theme/speed/grid remain identical, and Play remains available. Focus stays on the changed control. Do not claim an internal mid-recording checksum from these visible comparisons.
3. While still paused, change the **Presentation theme** deliberately once. Existing behavior is to keep the recording paused at the same tick and report “Presentation changed. The recording remains paused at the same tick.” This distinguishes intended theme preparation from Interface changes, which must not trigger a reload/preparation notice.
4. Choose Play explicitly, optionally set Speed 2× through its normal control, and let the default recording finish. Read the final matching hash and no-progress message. One visible full completion complements, but does not replace, the model suite's exact checkpoint comparisons.
5. For visible motion policy, also inspect a running interval with reduction on/off, preserving raw/system distinction. If moving to another native window pauses playback, resume explicitly before comparing effects; do not misattribute normal blur pause to the preference change.

### N5 — two exact responsive viewports

Use the same paused recording from N4; resizing must not load another recording. Record browser viewport dimensions, not the outer window size.

- **390×844, 100%:** open Interface in Plain/Large. Its fields should become one column, with complete labels, explanation and any warning wrapping without document horizontal scrolling. Scroll by ordinary means to playback; the full board preserves 4:3 (or the loaded recording's actual ratio), transport/readouts are reachable, no actions disappear. Measure summary/select/checkbox hit rectangles at least44CSSpx. Switch back to Theme/Standard and repeat the crucial controls.
- **844×390, 100%:** use Jump to playback. The short-landscape CSS places the stage beside a two-column transport bank. Inspect full uncropped board and all Play/Restart/Step/Speed controls together at the playback position; then inspect header Interface separately in its three-column layout. Plain/Large must not clip controls or force them off the side. Browser chrome/safe areas and actual screenshots determine fit, not CSS declarations alone.
- Rotate/resize between these two while paused: identity/tick remains, no automatic Play, focus remains reachable. Replay is a scrollable supporting tool; this check does not qualify simultaneous two-player gameplay HUD/touch banks.
- **200% zoom follow-up:** inspect Interface, notes, long error text and transport with Plain/Large at a recorded viewport. Allow vertical document scroll; no clipped commands or prose requiring horizontal pan. Do not label desktop pointer operation as touch-only. Actual touch/phone acceptance remains a separate row unless executed.

### N6 — delayed/failed boot through real requests

Parent may use the candidate server's explicit delay/failure facility or a supported browser network UI. Do not intercept fetch in application JavaScript or alter its response parsing. Record the exact affected URL and returned status/body; controlled failures are scenario evidence, not successful pinned resources.

1. Cold-load while **`/game/content/themes.json`** is held (alternatively `/authoring/motion-lab/presets.json`). This holds the application's initial data await after the display adapter has attached. Boot status remains visible; Interface is enabled outside main; Tab can operate it; native focus/activation cannot enter the inert playback/main controls. Save Plain/Large during the delay. Release the original bytes; the chosen values persist, normal setup completes, the example loads paused and no action is automatically played.
2. Repeat with one initial data URL returning a visible failure such as503. The exact boot error appears; main remains inert; Interface and Back remain usable. Restore original serving and use normal Reload to retry. **Do not invent a Retry or Cancel button for initial boot.** Separately delaying the app/module itself should leave Interface disabled until its owner loads, while direct-tool loading feedback remains visible.
3. Navigate away during the held initial request: follow the real Back link before release; release the request afterward. Observe that the destination is not replaced or focused by late completion, and a fresh visit initializes normally. Count this as a terminal-exit observation only when supported lifecycle evidence shows a non-persisted departure; a cached departure retains its owner intentionally and belongs to N8. This visible check cannot prove disposal of an unreachable page's RAF/listeners; retained model evidence covers that internal ownership.
4. Optional recording-load distinction: once ready, change the example, press Load example with that JSON response held, then use the real Cancel load action. The previous recording remains paused with its identity/tick. This is separate from initial boot and does not justify claiming initial boot cancellation support.

### N7 — cross-tab policy, with normal blur pause accounted for

1. Keep tab A paused at a nonzero tick with Interface open. Open tab B at the **same origin** Replay route. In B use its real Interface controls to choose the opposite text style/size and raw reduction. Return to A; its controls, appearance and effective policy match, while recording/tick and paused intent remain.
2. Reverse direction with a new native choice in A; verify B adopts it without a reload or preparation notice. A working storage event is demonstrated by visible convergence; no direct dispatch/storage write is allowed.
3. If an available browser storage policy can genuinely deny writes on this isolated origin, test a native preference edit: session appearance changes and the explicit save warning appears. Another tab's update must not erase that unsaved local intent. Otherwise mark denied-save native evidence open rather than replacing localStorage or its methods.

### N8 — real Back/Forward and cold history fallback

1. In A choose the **Switchyard Circuit** example, press Load example, then Step three times and leave it paused. Record its non-default recording name/tick and Interface choices. Follow Back to the game to leave the document. In B change shared preferences through its real Interface. Use the browser's actual Back command in A; do not invoke application methods.
2. Determine the restoration category using supported browser-native lifecycle evidence, such as a genuine BFCache restoration report or an observed real `pageshow.persisted` event supplied by the browser tooling. **Do not dispatch an event, add an app probe, or treat Navigation Timing `back_forward` alone as proof of BFCache admission.** If the available native tools cannot expose the distinction, record “history return, cache mechanism unverified.”
3. **Actual cached restoration:** A retains Switchyard and its paused tick, adopts B's current shared values/system cap, and does not auto-Play. Its Interface can change values once again. Repeat Forward/Back once to check that controls remain usable and focus is reachable.
4. **Cold history fallback:** an actual document reload may return to the auto-loaded default Copper Crossing at tick zero because Replay has no persistent recording/session save. That is not cached restoration and must not be reported as a BFCache preservation failure or pass. Saved display choices should still be correct, startup status honest and playback paused. Record the mechanism and leave real cached restoration open if not achieved.
5. An uncontrolled inability to enter BFCache is not fixed by faking persisted events. Preserve browser evidence/reasons and report the exact unexecuted claim.

## Stop/fix and remaining boundaries

Block native candidate acceptance for a dropped/incorrect saved choice, raw/effective confusion, inaccessible actual Interface control, clipped critical action, unintended recording/tick reset or auto-Play caused by preferences, late preparation replacing the current view, or missing/untruthful failure feedback. Record the failing source/route/state, make any correction in a separately owned candidate, then repeat affected modeled and native checks against its new pins.

This checklist does not establish full font production readiness, exhaustive EN/UA glyph coverage, all replay formats/examples/themes, imported file-picker paths, offline startup, long-session memory, physical controller/touch/TV ergonomics, combined Studio integration, source/build/release gates or public deployment. The nine-file local test count remains90 reported passes per runtime (89 leaf behaviors plus one parent group); native journey counts must not be added to that as identical evidence. Close temporary tabs/servers after the lane and record cleanup separately.
