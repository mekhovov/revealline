import sys, json, subprocess, time, hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
label, runtime, operation, *files=sys.argv[1:]
node=Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node')/runtime/'bin/node'
root=p/('baseline' if label.startswith('baseline') else 'proposal')
out=p/'runs'/label
out.mkdir(parents=True, exist_ok=False)
pins={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*') if f.is_file()}
(out/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
if operation=='format':
 argv=[str(node),'--max-old-space-size=100','/Users/oleksandr.mekhovov/work/my_projects/go_test/node_modules/prettier/bin/prettier.cjs','--write','--ignore-path','/dev/null','--config',str(root/'.prettierrc.json'),*files]
elif operation in ['test','test160']:
 if operation=='test160': assert files==['game/test/display-preferences-host.test.mjs']
 argv=[str(node),'--max-old-space-size='+('160' if operation=='test160' else '100'),'--test','--test-concurrency=1',*files]
else: raise ValueError(operation)
started=time.time()
with (out/'output.log').open('wb') as log:
 result=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
after={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*') if f.is_file()}
raw=(out/'output.log').read_bytes()
receipt=dict(label=label,argv=argv,cwd=str(root),exitCode=result.returncode,elapsedSeconds=round(time.time()-started,3),inputCount=len(pins),inputsUnchanged=pins==after,changed=[key for key in set(pins)|set(after) if pins.get(key)!=after.get(key)],logSha256=hashlib.sha256(raw).hexdigest())
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
print(raw.decode(errors='replace')[-5500:])
sys.exit(result.returncode)
