# Replay native focus and counter corrections — qualified successor

17 September 2026. Five-path successor to the original eight-path Replay display candidate. **Ready for release-owner composition and review; not a released feature or full P05 acceptance.**

- [Final patch](final.patch), SHA-256 `f639deb38aa1a3a8bfcc4c1e616826013cff80470211bb637857b513ea2b7842`.
- [Exact preimages and final bytes](final-pins.json): `index.html`, `navigation.mjs`, `app.mjs`, `theater.css`, `replay-theater-navigation.test.mjs`. Preimages are the original qualified `p05-replay-display-9577b2cb/proposal`, already reported integrated by the release owner; they are not the mixed checkout or bare9577.
- [Final source checks](final-checks.json): all five files formatted, three modules parsed by Node20/22; final769-file captured closures identical across both runtime tests.
- Final whole-file cohort: [Node20 receipt](runs/proposal20-02/receipt.json), [Node22 receipt](runs/proposal22-02/receipt.json): **56/56 passes per runtime**, seven complete files,100MiB sequential execution, no filters/skips or altered simulation assertions.
- Original production plus the final augmented navigation fixture: [Node20](runs/baseline20-augmented-02/receipt.json), [Node22](runs/baseline22-augmented-02/receipt.json):8passes/5expected focus failures per runtime. Corrected navigation passes13/13 within the final cohort. Baseline files have been restored to their exact preimages.
- [Independent static review](review/static-review.md); [plan refinement](review/plan-refinement.md).
- [Original native findings](../p05-replay-display-native-9577b2cb/observations-original.md), [successor native results](../p05-replay-jump-focus-native-9577b2cb/observations.md), [served representation checks](../p05-replay-jump-focus-native-9577b2cb/representation-checks.json).

## Change and reason

Native fragment Jump formerly left BODY focused, making nextTab return to the header. The owned deferred handoff retains the anchor's browser scrolling/history and moves to a usable playback control only while the original intent still owns focus. New input, newer focus, background/suspension/disposal, modified links and later click cancellation veto it.

Completion formerly disabled focused Play/Step and stranded keyboard focus on BODY. The conditional handoff keeps focus on Restart only when the completing transport owned it; unrelated editor/header/background focus stays untouched. Actual Copper completion remains `861a6de2ffd7e119`.

The Replay counter rule tied a later shared selector and lost16/20px sizes to14/18px. The stronger Replay-only selector restores the intended control/telemetry role. Native Standard16px and Large20px are observed.

## Preserved failures and qualification boundaries

The first baseline discrimination run hit a100MiB process OOM while formatting cyclic fake-DOM assertion failures. Its [log and failed receipt](runs/baseline22-augmented/receipt.json) remain intact; it is not an assertion pass. Subsequent test-only refinement compares unique exact focus IDs, assigns fixture IDs to BODY/anonymous Interface, locates the real old Jump anchor when testing preimage markup, and adds target/download/changed-href/later-cancellation cases. Final diagnostics and input hashes are independently recorded. Production bytes remained unchanged through this refinement.

Native checks include keyboard Jump→Play→Restart, Play completion→Restart→Speed, preserved JSON-editor focus, exact checkpoint,390×844 and844×390 layouts, and computed counter sizes. They do not establish final-Step native completion, physical touch/controllers, actual BFCache restoration,200%zoom, system preference transitions, denied storage, offline or public deployment. Original delayed/failure boot and cross-tab observations remain predecessor evidence. Completed Play's amber disabled treatment remains a P05 component-state follow-up.

All owned tabs were closed and viewport reset. Both server processes are terminal: [original closure](../p05-replay-display-native-9577b2cb/closed-receipt.json), [successor closure](../p05-replay-jump-focus-native-9577b2cb/closed-receipt.json). No original source/index/version/remote changes, builds or full gates were run in this lane. Release owner must compare preimages, compose, qualify exact source and complete commit/version/freeze/deploy/public acceptance.
