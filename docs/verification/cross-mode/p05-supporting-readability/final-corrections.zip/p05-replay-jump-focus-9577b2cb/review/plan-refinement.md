# P05 refinement: qualify the next usable action after browser transitions

The Replay correction closes two observed focus breaks and a readout-size conflict in this bounded successor. It does not close P05 or the full redesign. The native results below were reported by the parent reviewer on 17 September 2026; this note is an independent planning synthesis, not another browser run. The parent owns the final evidence and source binding.

## Evidence that changes the plan

- Native keyboard Jump now focuses Play; the next Tab reaches Restart. Actual Copper completion focuses Restart; the next Tab reaches Speed. The final checkpoint remains `861a6de2ffd7e119`. A second completion preserves focus in the replay-text editor.
- At 390×844 with Plain/Large, selects measure 324×45.5 CSS pixels and the checkbox 44×44; readouts compute 20px and document width remains 390. At 844×390, the 328×246 board and transport fit within width 844. Standard readouts compute 16px. These are browser/emulated-layout observations, not physical-device qualification.
- The original native review found BODY focus after fragment navigation and after disabling completed Play, although the earlier modeled cohort passed. Preserve those failures and the corrected results together; passing handler/closure tests alone cannot establish browser default-action behavior. [Original observations](../../p05-replay-display-native-9577b2cb/observations-original.md)

## Acceptance refinement for existing phases

Add a **post-transition focus check** to the existing P05, navigation, continuation, and remaining-screen matrices. For each applicable jump, modal return, load/cancel, retry/next, completion, and control-disable transition, perform the real action, let the browser default action and state change finish, record the active element, then perform the next normal keyboard/controller navigation command. Acceptance requires a predictable usable destination, visible focus, and no unintended activation or loss of unrelated editing. Retain input/recording/save invariants alongside the focus result. This is a test-method refinement, not additional gameplay scope.

W3C focus-order guidance requires sequential navigation to preserve meaning and operability; logical order matters more than one prescribed visual sequence. [W3C: Focus Order](https://www.w3.org/WAI/WCAG22/Understanding/focus-order.html)

Xbox guidance similarly calls for predictable focus, consistent interaction across screens, keyboard and digital-controller operation, and navigation that follows layout changes. Apply that guidance to the next action after a transition as well as the initial screen. [Xbox Accessibility Guideline 112](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/112)

Keep modeled cancellation/lifecycle/state tests and native journeys as separate evidence. Test native fragment/default-action ordering and disabled-control blur explicitly; do not substitute a synthetic click or a timer-completion assertion. Actual controller, touch, assistive-technology, and physical-device coverage remain separately qualified.

## Remaining follow-ups

- **BFCache remains unverified.** The real history return restored the browser-selected Switchyard example at tick 0, not its earlier tick 3. Without observed `pageshow.persisted` or equivalent admission evidence, classify this as cold/history return. A later true cached return must prove the intended retained recording and preference behavior. Do not call browser form restoration a successful BFCache test or infer a defect from an unpromised cold-return checkpoint.
- **Disabled component appearance remains a P05 follow-up.** Native inspection found disabled Play still amber while disabled Step appeared gray. Review their disabled-state hierarchy together: the primary action must visibly communicate unavailability while keeping its label readable. Check the final cascade and normal/focused/pressed/disabled states, including Plain/Large and high-contrast preferences. No production styling change is included in this refinement.
- Full P05 acceptance still requires the outstanding route, font/glyph, motion, zoom, lifecycle, input, integration, and release gates. This successor's focused native checks do not establish offline/public deployment or acceptance of other phases.

Sources were opened on 17 September 2026. No Node, formatter, browser, server, production/source/index edit, or release operation was performed while writing this note.
