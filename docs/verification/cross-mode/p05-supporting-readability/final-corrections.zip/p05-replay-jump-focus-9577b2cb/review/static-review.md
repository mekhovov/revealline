# Replay jump-focus correction — independent static review

No blocking defect was identified in the current five-path correction. This is a source review, not test, browser, or release acceptance. Exact reviewed bytes are recorded in [static-inputs.json](static-inputs.json); the parent is qualifying the candidate separately.

## Reviewed behavior

- The anchor keeps its native fragment URL and gains only an ID. The handler does not cancel its click default, change history, or issue a transport command. The timeout performs the handoff after the click stack; browser ordering still requires native confirmation.
- Jump uses the existing preferred-control decision: pending → Cancel load; ready → Play; completed → Restart; no usable player → Load example. A handler reference to `preferred()` remains live, so state changes before the timer fires choose a currently appropriate target rather than a captured disabled control.
- The callback checks both the initial and later `defaultPrevented` value. Modifiers, nonprimary buttons, alternate href, `download`, and alternate target bypass the behavior. New key/pointer input cancels the timer. Current focus on another control, lost foreground, visibility, generation changes, persisted suspension, and terminal disposal prevent deferred focus adoption.
- The timer and added listeners belong to the existing navigation lifetime. `destroy()` calls `suspend()` before removing listeners; the pending timer is cancelled. Cached suspension preserves handlers but cancels pending focus; wake clears navigation/router state. This does not prove real BFCache admission.
- Completion records ownership before disabling controls, then focuses Restart only for a complete, nonpending, foreground, live player whose focused Play/Step still owns focus or was blurred to BODY/null by disabling. Existing unrelated editor/header focus is not selected. No simulation input, replay checkpoint, player timing, rate, save, or profile path was changed.
- External programmatic focus is visible to the existing controller adapter through its `focusin` listener. An engaged controller should move its marker with the handoff; its actual click/default-action ordering still needs the planned native check.
- The readout correction has specificity `(0,4,1)`, above the later shared font-size selector `(0,3,1)`. The shared high-specificity font-family rule still wins independently, but supplies the same `--fk-font-mono` value. The change remains scoped to Replay readouts and does not modify tokens or other pages.

## Test coverage and limits

The six added actual-application tests meaningfully exercise ready/running/completed Jump, paused checkpoint preservation, pending import and rejection, empty initial replay rejection, newer focus/input, modified buttons, suspension/disposal, native-style disabled-button blur, final Play/Step completion, and unrelated editor/background ownership. They use the real application, router, verifier/player and simulation; painter/DOM/device and browser defaults remain modeled.

Nonblocking coverage gaps in the added cases:

1. `target`, `download`, and changed-`href` bypass branches are implemented but not directly exercised. The ordinary-click helper currently models a fragment default without inspecting those attributes, so attribute cases should use a suitable separate dispatch/default model if added.
2. A later bubbling listener calling `preventDefault()` is guarded in the implementation but the test only supplies an already-prevented event. A focused test could exercise the deferred recheck directly.
3. The new Jump cases activate the link through the keyboard helper plus a synthetic click; controller link activation/marker transfer and actual browser fragment scheduling require native coverage. The existing controller cases do not prove this new link journey.
4. Two rapid successive Jump requests and direct `visibilitychange` while a handoff is pending are not singled out, although generation cancellation and suspend paths are reviewed and adjacent lifecycle cases exercise the shared cancellation function.

The header Jump handler is attached only after initial theme/preset startup succeeds. A failed or held startup therefore retains the old native anchor behavior; this correction does not claim a functional Jump into the inert workspace during that stage. Interface controls remain the separately implemented available startup controls.

## Required parent follow-through

Retain the original failed native observations. Confirm native keyboard and pointer Jump → preferred control → local Tab, completed Play and final Step → Restart → Speed, preserved unrelated text input focus, and readout sizes 16/20 under the actual stylesheet order. Run the original-versus-corrected bounded cohort and both supported Node runtimes against the final composed bytes. Retain public/offline/device/font and full-phase limits separately.

No Node, formatter, browser, server, build, source/index change, remote operation, or release-status poll was performed by this reviewer. Only this review directory was written.


## Final test-only follow-up — 2026-09-17T05:53:24.159319+00:00

Reviewed the delta from the prior test recorded in `static-inputs.json` (`1286d880906989575c1df3415d110616205b575506ec9dff5508317d9d3ab981`) to the final formatted proposal: **4bb6dbbb5a9ebdacb4d58ce2be47eb3f2e56e7c6295956cc25dac65af251f0ca**, **25716 bytes**. The prior test was reconstructed in memory from the preserved original test plus `focus-hunk.diff`, and its hash matched the prior reviewed pin exactly. All previously pinned proposal production/context files remain byte-identical to the initial review. This follow-up changes no production assessment.

The exact-ID focus assertions retain the meaningful target checks in this harness. Expected named destinations remain distinct (`play-pause`, `restart`, `speed`, `cancel-load`, `load-example`, `jump-playback`, and `replay-text`); formerly anonymous BODY and Interface summary receive stable test-only IDs. A missing active element or wrong target still fails. This avoids formatting a cyclic DOM graph on a failed assertion without weakening the checkpoint, phase, default-prevention, current-editor-value, or next-Tab checks. The assertions now prove destination identity by the fixture's unique IDs; they do not independently promise DOM-node lifetime identity, which is outside these focus-transition cases.

The baseline anchor fallback resolves the original real fragment anchor and assigns its diagnostic ID only after application/navigation initialization. It therefore does not install or repair a missing production Jump handler and still discriminates the original focus failure. No simulation data, time advancement, or default-action model was relaxed.

The added target/download/changed-href cases dispatch a click without pretending to open a browser tab, download a file, or navigate a different fragment. An erroneous handoff would move focus to the enabled preferred control, causing each exact-ID assertion to fail. Attributes are restored between cases. The later document bubbling listener runs after the target handler; the deferred cancellation assertion specifically tests the callback's second `defaultPrevented` check, and the listener is removed in `finally`. These additions close static review coverage gaps 1 and 2 above at the modeled-behavior level.

No blocking test defect identified. The controller/default-action native evidence, rapid repeated requests, direct visibility edge, and BFCache limits remain as described in the original review and parent qualification. Reported baseline/proposal runtime outcomes are parent-owned; this reviewer did not rerun or independently qualify them. Only this append-only review update was written.
