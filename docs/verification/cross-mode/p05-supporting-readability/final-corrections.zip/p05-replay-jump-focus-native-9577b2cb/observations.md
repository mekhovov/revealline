# Replay successor: native correction review

17 September 2026. Exact source: original qualified Replay candidate plus five-path successor. [Binding](binding.json) pins Git base/tree and six production overrides. [Served representations](representation-checks.json) match every override. No source file/index/version/remote was changed by this native lane.

## Observed correction results

1. **Keyboard Jump:** on ready Copper Crossing, three actual Tab presses reach Jump; Return retains the native `#playback` URL and focuses Play. Next Tab focuses Restart. Recording remains paused at tick0.
2. **Completed transport:** actual keyboard Play at1× finishes Copper Crossing at tick1305,74.1% coverage,3lives,12590 points, with `Final checkpoint matches · 861a6de2ffd7e119 · No progress awarded.` Focus becomes Restart; next Tab reaches Speed. This replaces the original BODY/header failure.
3. **Unrelated focus:** Restart, Play and pointer focus on the real replay JSON textarea produces the same exact completed checkpoint and leaves `replay-text` focused. The completion handoff does not interrupt editing.
4. **Typography:** computed counters are16px Standard and20px Large, replacing14/18 on the original candidate.
5. **Portrait390×844, Plain/Large:** selects324×45.5CSSpx and checkbox44×44; control text20px; document width390. Actual screenshot shows wrapping without horizontal overflow. Jump on the completed recording focuses Restart; the board, controls and enlarged counters remain readable in this scrollable tool.
6. **Short landscape844×390, Plain/Large:** entire board328×246 at(150,110.65625); Play/Restart96×47, Step96×74, Speed96×45.5; document width844. Screenshot confirms board and all transport controls fit together. Counters continue below in the scrollable tool; this is not a Team HUD qualification.

## Remaining P05 observations and limits

Completed Play is disabled in the accessibility tree but still amber-filled, whereas disabled Step has the muted/dashed treatment. Record this as a shared component-state review item; the bounded focus patch does not close P05.

Modeled pending/error/stale/modified/background/Step-completion checks remain distinct from the native subset above. Actual final-Step completion, controller-specific focus marking, physical touch/controller devices,200%zoom, system reduced-motion transitions, denied storage, verified BFCache admission, offline and public release remain unqualified here. The original candidate's delayed/failing boot and cross-tab checks remain applicable predecessor evidence, not falsely repeated successor runs.

Screenshots were rendered in the browser tool; no standalone screenshot artifact was saved. One read-only DOM probe requested an absent `tick` ID and threw; the following probe used observed readout markup and returned the values above. It did not mutate the app or indicate a product failure.

## Resource closure

Original comparison tabs4/5 and server53962 were closed before successor review. Successor temporary tab6 was closed, browser viewport override reset, and server55170 stopped. [Close receipt](closed-receipt.json) records the server and request log hash. No user/public tabs were changed.
