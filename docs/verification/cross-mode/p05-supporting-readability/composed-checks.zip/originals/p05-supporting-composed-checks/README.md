# P05 supporting-screen composed checks

17 September 2026. Isolated source worktree `codex/p05-studio-readability`, main cutoff10df6751, with Studio13 + Replay8 paths and the composed Studio return regression. No version or commit yet.

`attempt-1/inputs.json` pins795 physically present tracked/new source/resource files. Both Node20.19.5 and22.22.2 passed the complete19-file deduplicated core cohort (151 cases) at100MiB and the unchanged shared host file at160MiB (9 reported results:8 leaves plus1 parent). Total159 leaf behaviors per runtime, not320 distinct behaviors. Raw TAP and command receipts are retained. All inputs unchanged through every run.

`static-1/` records explicit formatting of21 changed code/style/HTML/test paths; passed. Source remains sparse; these are affected checks, not the full six gates or ordinary build. Native Replay's Jump focus/readout-size corrections are subsequent work and are not covered by these inputs.

Initial Replay patch application was refused because four exact tracked files were outside sparse checkout. No patch applied. Hydrating exactHEAD replay-theater and tests made git apply --check pass; the original patch then applied without conflict. This was missing checkout content, not a product failure.
