# Composed Studio / Replay static review

Reviewed the production/test composition at `10df6751b0f31d3f8ed68ee0132c830b6eefbec8` in the isolated Studio worktree. **One new CSS issue was found and corrected by the owner during review; no additional unresolved production defect found.** The known Replay jump-focus and readout-specificity successors remain outside this reviewed snapshot.

`observed-inputs.json` pins all 21 production/test files (300,709 bytes); `observed-production-test.diff` preserves their exact reviewed differences, including additions. Documentation was excluded. This review made no source changes and ran no tests, build or browser.

## Finding and correction

**R1 — Preserve multiline authoring controls (corrected, static).** Initially, `studio.css`'s new `body.field-kit [data-studio-host]` reset set `white-space: normal` on textareas marked `control`. That includes the readonly multiline generated prompt and “Review evidence (one concrete check per line)” (`index.html:607–630`); the existing `technical` exception did not match them. The original candidate CSS is retained unchanged in the earlier Studio packet, SHA256 `8f2dcb5f4fc0881e4a59055688b5edcb222864cc7fcc4eeb7a745661d5fd509d`.

The owner's correction adds `body.field-kit textarea[data-studio-host] { white-space: pre-wrap; }` at final `studio.css:823–825`. It has higher specificity than the blanket reset, preserves hard breaks and wrapping, and leaves specimen text and other host roles unchanged. The corrected final CSS is included in this review's input pins. This is a CSS-semantic finding and static correction review, not a native reproduction claim.

## Production review

- **HTML/CSS roles:** Studio's body-resolved host aliases keep the interface independent of each preview's inline theme. Real guidance/actions receive host roles; font/component/bitmap specimens keep their selected-theme identity. Plain/Large changes flow through the aliases without replacing nodes. New status regions and early Interface controls remain outside the operation-locked workspace. No additional conflicting selector or role found after R1's correction.
- **Font registration:** cache ownership is published before reading bytes. Shared role requests widen one face's valid weight range even during byte/load waits. The loaded face is retained if a descriptor update throws, and range metadata advances only after successful assignment. Failed loads evict only their own entry; cancellation of one preview does not remove another consumer's face. The selected font file and slot own specimen family, size and weights. Reviewed tests cover those boundaries without changing font bytes or provenance.
- **Studio lifetime/focus:** shared preference changes update current attributes/controls rather than refreshing inventory/drafts. Only selected-slot activation restores the replacement row, synchronously and while foreground; rejected activation retains the connected trigger. Preview subscriptions ignore text-only/unchanged-cap updates. Persisted return refreshes authority before existing preview-lease recreation; terminal exit disposes owners. Preview markers are intentionally not preserved across the existing return refresh.
- **Shared authority:** current storage is validated, duplicate state is suppressed, unsaved explicit intent and warnings survive restoration, and current system reduction still applies. Restoration does not persist or increment intent for cap-only changes. Reentrant explicit writes remain authoritative. Disposal removes the added observer.
- **Replay:** display controls mount before asynchronous boot and survive boot failure. Terminal exit is guarded after both awaited startup stages and cleanup is idempotent across display/navigation/presentation ownership. Persisted navigation retains authority while the existing transport suspends. Render receives only presentation options; replay formats, simulation, import verification, recorded inputs and checkpoint semantics are unchanged.

## Test review and pending successors

The composed return regression uses the real Studio host/authority/editor/store. It follows a prepared original through stage/save/exact-byte restore; then exercises failed preference persistence while retaining selection, focus and dirty sprite, followed by explicit retry and restored sharing. It does not assert private implementation flags. Its motion boundary and storage denial are finite external doubles. This reviewer authored that test packet earlier; its production integration is reviewed here, not presented as an independent second test author.

The owner reports 151 passes in the 19-file composed cohort and nine reported passes (eight leaf behaviors plus parent) in the unchanged game-host file on each of Node20.19.5/22.22.2. Those runs were not repeated or independently reclassified here; CSS R1 was corrected afterward and has no new runtime/native claim in this review.

Known UX-owned work still pending in the pinned source: keyboard/controller focus for “Jump to playback”, and readout CSS specificity. Review their actual successor bytes and run the affected checks before release. No additional broad acceptance checklist is introduced by this review.
