# Composed Studio persisted-return regression

**One test-file patch, statically reviewed and unexecuted.** Base is the reviewed Studio font/F2/focus candidate's `game/test/asset-studio-host-loading.test.mjs` (SHA256 `f5a180f5192dee490d98a09795b9b8ed81bd6595a08f06b3065df5f36ccbb995`). Apply after that packet and use the Replay candidate's corrected shared display authority. This patch does not change production source or add another test case; it extends the existing actual-host case.

`proposal.diff` and `candidate.json` contain the patch and exact inputs/results. The candidate copy is under `proposal/game/test/asset-studio-host-loading.test.mjs`. Original packet bytes are unchanged.

The fixture adds a mutable system-motion boundary, shared by the host and global `matchMedia`, plus a denied-write switch that records attempted saves before rejecting them. It does not mock the preference authority, Studio host, sprite editor, authoring operations or IndexedDB store.

Three linked journeys exercise the missing composition:

1. While an actual image replacement is prepared, model pagehide, change shared storage and system reduction without delivering their normal events, then pageshow. Verify current preferences/cap with no implicit save, the same selected row and editor focus, original canvas/crop/metadata/file, and enabled staging. Continue the existing real stage/save/IndexedDB restore and exact original-byte assertion, so labels alone cannot establish preservation. Preview lease markers are deliberately not expected to survive: Studio already rebuilds those leases on return.
2. With the actual sprite editor dirty, deny an explicit Plain preference save. Model another return with conflicting remote text preferences and a changed system cap. Assert local text intent and its warning survive, the effective cap refreshes, no retry writes occur, and the same selected row, focus, canvas, cursor and undo availability remain. A real Save still rejects the dirty sprite.
3. Retry the preference explicitly after storage recovers; verify the exact saved fields and cleared warning. A further return can now adopt newer shared text/cap values, without saving again or losing the dirty editor. All attempted preference writes remain restricted to the shared display key.

Static discrimination: without the Replay authority correction, the first restoration should retain Plain/full instead of the newly stored Theme/reduced state. This is a predicted failure, not an executed baseline result. The denied-save branch also verifies that adding restoration cannot overwrite unsaved local intent. No implementation revision counters, private flags or listener counts are asserted.

Next: the owner should inspect/adopt this single-file patch and run the complete affected host file plus the deduplicated composed cohort, retaining any failure honestly. No tests, syntax checks, formatter, build, browser, source-worktree or remote operation were run here. Native BFCache admission, visible rendering and physical input remain separate.
