from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlsplit
from collections import OrderedDict
import subprocess, mimetypes, hashlib, json, os, threading, re, shutil, argparse

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--config', required=True)
parser.add_argument('--binding', required=True)
parser.add_argument('--config-sha256', required=True)
args = parser.parse_args()
if not all(re.fullmatch(r'[a-z0-9][a-z0-9.-]*', value) for value in (args.config, args.binding)):
    raise RuntimeError('Use direct owned filenames')
config_path = OUT / args.config
binding_path = OUT / args.binding
if config_path.is_symlink() or binding_path.exists():
    raise RuntimeError('Use a regular owned configuration and a fresh binding name')
config_bytes = config_path.read_bytes()
if hashlib.sha256(config_bytes).hexdigest() != args.config_sha256:
    raise RuntimeError('Reviewed configuration differs')
config = json.loads(config_bytes)
TREE = config['tree']
if not re.fullmatch('[0-9a-f]{40}', TREE):
    raise RuntimeError('Exact source tree required')
GIT_ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1')
def git(*argv):
    return subprocess.check_output(['git', '--no-optional-locks', *argv], cwd=ROOT,
                                   env=GIT_ENV, stderr=subprocess.DEVNULL)
def checked(record):
    path = Path(record['path'])
    if path.is_symlink():
        raise RuntimeError('Authority must be a regular file')
    body = path.read_bytes()
    if len(body) != record['bytes'] or hashlib.sha256(body).hexdigest() != record['sha256']:
        raise RuntimeError('Pinned authority differs: ' + str(path))
    return json.loads(body)
if git('rev-parse', 'HEAD').decode().strip() != config['head']:
    raise RuntimeError('Temporary candidate base changed')
if git('rev-parse', 'HEAD^{tree}').decode().strip() != TREE:
    raise RuntimeError('Temporary candidate tree changed')
if git('rev-parse', 'HEAD^').decode().strip() != config['temporaryParent']:
    raise RuntimeError('Temporary candidate parent changed')
if hashlib.sha256(git('ls-files', '--stage', '-z')).hexdigest() != config['indexSha256']:
    raise RuntimeError('Candidate canonical index changed')
if git('diff', '--name-only').decode().splitlines() != ['game/couch/relay-rescue.css']:
    raise RuntimeError('Only the held CSS may differ')
hold = checked(config['sourceHold'])
baseline_binding = checked(config['baselineBinding'])
baseline_verification = checked(config['baselineVerification'])
baseline_union = checked(config['baselineUnion'])
if (hold['base'] != config['head'] or hold['tree'] != TREE
        or baseline_binding['tree'] != TREE
        or baseline_verification['previewTree'] != TREE
        or baseline_union['tree'] != TREE
        or baseline_verification['cohorts']['union']['sha256'] != config['baselineUnion']['sha256']
        or baseline_union['completePair'] is not True
        or len(baseline_union['testFiles']) != 19
        or [row['version'] for row in baseline_union['results']] != ['22.22.2', '20.19.5']):
    raise RuntimeError('Frozen baseline identities differ')
for row in baseline_union['results']:
    summary = row['summary']
    if (row['exitCode'] != 0 or row['inputsUnchanged'] is not True
            or summary['tests'] != 414 or summary['pass'] != 414
            or any(summary[name] for name in ['fail', 'cancelled', 'skipped', 'todo'])):
        raise RuntimeError('Frozen baseline qualification differs')
if config['overlay'] != 'game/couch/relay-rescue.css' or len(hold['files']) != 1:
    raise RuntimeError('Only the reviewed Team CSS overlay is allowed')
row = hold['files'][0]
if row['path'] != config['overlay']:
    raise RuntimeError('Unexpected overlay path')
path = ROOT / row['path']
if path.is_symlink():
    raise RuntimeError('Overlay must be a regular owned file')
body = path.read_bytes()
if len(body) != row['bytes'] or hashlib.sha256(body).hexdigest() != row['sha256']:
    raise RuntimeError('Held CSS differs')
# Freeze the admitted body once. Later working-file edits cannot retarget this origin.
overlays = {row['path']: body}
LIMIT = 64 * 1024 * 1024
if shutil.disk_usage(OUT).free < 2 * 1024 * 1024 * 1024:
    raise RuntimeError('Insufficient 2 GiB browser reserve')
regular = {}
for line in git('ls-tree', '-r', '-z', TREE).split(b'\0'):
    if not line:
        continue
    meta, name = line.split(b'\t', 1)
    mode, kind, oid = meta.decode().split()
    name = name.decode()
    if mode in ('100644', '100755') and kind == 'blob' and name.startswith(('game/', 'authoring/', 'docs/')):
        regular[name] = oid
cache = OrderedDict()
cache_bytes = 0
cache_lock = threading.Lock()
requests = threading.BoundedSemaphore(4)

def git_body(name):
    global cache_bytes
    if name in overlays:
        return overlays[name]
    with cache_lock:
        if name in cache:
            body = cache.pop(name)
            cache[name] = body
            return body
        oid = regular[name]
        size = int(git('cat-file', '-s', oid))
        if size > LIMIT:
            raise ValueError('Per-file limit')
        while cache and cache_bytes + size > LIMIT:
            _, old = cache.popitem(last=False)
            cache_bytes -= len(old)
        body = git('cat-file', 'blob', oid)
        if len(body) != size or hashlib.sha1(b'blob ' + str(size).encode() + b'\0' + body).hexdigest() != oid:
            raise ValueError('Git body identity mismatch')
        cache[name] = body
        cache_bytes += size
        return body

class Handler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.serve(False)
    def do_GET(self):
        self.serve(True)
    def serve(self, send_body):
        with requests:
            if self.headers.get('Host') != '127.0.0.1:' + str(self.server.server_port):
                self.send_error(403)
                return
            name = unquote(urlsplit(self.path).path).lstrip('/')
            if not name:
                self.send_response(302)
                self.send_header('Location', '/game/')
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            if name.endswith('/'):
                name += 'index.html'
            if '\\' in name or any(ord(ch) < 32 for ch in name) or any(part in ('.', '..', '.git', 'node_modules') for part in name.split('/')) or name not in regular:
                self.send_error(404)
                return
            try:
                body = git_body(name)
                length = len(body)
                start, end, status = 0, length - 1, 200
                requested = self.headers.get('Range')
                if requested:
                    match = re.fullmatch(r'bytes=(\d*)-(\d*)', requested)
                    if not match or not any(match.groups()):
                        raise ValueError('Invalid range')
                    low, high = match.groups()
                    if low:
                        start = int(low)
                        end = min(int(high), length - 1) if high else length - 1
                    else:
                        start = max(0, length - int(high))
                    if start > end or start >= length:
                        self.send_response(416)
                        self.send_header('Content-Range', 'bytes */' + str(length))
                        self.send_header('Content-Length', '0')
                        self.end_headers()
                        return
                    status = 206
                kind = 'text/javascript' if name.endswith('.mjs') else mimetypes.guess_type(name)[0] or 'application/octet-stream'
                self.send_response(status)
                self.send_header('Content-Type', kind)
                self.send_header('Content-Length', str(end - start + 1))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Accept-Ranges', 'bytes')
                if status == 206:
                    self.send_header('Content-Range', f'bytes {start}-{end}/{length}')
                self.end_headers()
                if send_body:
                    for offset in range(start, end + 1, 65536):
                        self.wfile.write(memoryview(body)[offset:min(offset + 65536, end + 1)])
            except (KeyError, ValueError, subprocess.CalledProcessError):
                self.send_error(404)
            except (BrokenPipeError, ConnectionResetError):
                pass
    def log_message(self, format, *args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
server.daemon_threads = True
binding = {'temporaryBaseCommit': config['head'], 'tree': TREE,
           'temporaryParent': config['temporaryParent'],
           'sourceIdentities': baseline_binding['sourceIdentities'],
           'originalParents': baseline_binding['originalParents'],
           'baselineBinding': config['baselineBinding'],
           'baselineUnion': config['baselineUnion'],
           'sourceHold': config['sourceHold'],
           'pid': os.getpid(), 'port': server.server_port,
           'url': f'http://127.0.0.1:{server.server_port}/game/couch/relay-rescue.html',
           'gitBlobCacheBytes': LIMIT, 'maxConcurrentRequests': 4,
           'config': {'path': args.config, 'bytes': len(config_bytes),
                      'sha256': hashlib.sha256(config_bytes).hexdigest()},
           'helperSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'overlays': hold['files'],
           'scope': config['scope']}
with binding_path.open('x') as file:
    json.dump(binding, file, indent=2)
    file.write('\n')
print(json.dumps(binding), flush=True)
try:
    server.serve_forever()
finally:
    server.server_close()
