from pathlib import Path
import subprocess,json,hashlib,difflib,ast
root=Path.cwd();c=root/'.cache/reading-prompts';out=c/'preview';out.mkdir(exist_ok=True)
prior=root.parent/'p05-team-short-landscape/.cache/team-short-landscape/preview/serve.py'
s=prior.read_text();(out/'serve-before-reading.py').write_text(s)
start=s.index("if git('rev-parse', 'HEAD').decode().strip()")
end=s.index('LIMIT = 64 * 1024 * 1024',start)
block='''if git('rev-parse', 'HEAD').decode().strip() != config['baseCommit']:
    raise RuntimeError('Reading base commit changed')
if git('rev-parse', 'HEAD^{tree}').decode().strip() != TREE:
    raise RuntimeError('Reading base tree changed')
if git('write-tree').decode().strip() != config['candidateTree']:
    raise RuntimeError('Staged reading candidate changed')
if hashlib.sha256(git('ls-files', '--stage', '-z')).hexdigest() != config['indexSha256']:
    raise RuntimeError('Candidate canonical index changed')
if git('diff', '--name-only').decode().splitlines():
    raise RuntimeError('Candidate has unstaged tracked changes')
hold = checked(config['sourceHold'])
package = checked(config['packageHold'])
verification = checked(config['verification'])
authority = checked(verification['authority'])
before = checked(verification['before'])
if (hold['base'] != config['baseCommit'] or package['tree'] != config['candidateTree']
        or authority['head'] != config['baseCommit']
        or authority['sourceHold'] != config['sourceHold']
        or verification['completePair'] is not True
        or authority['testFiles'] != hold['testFiles']
        or len(hold['testFiles']) != 3
        or len(verification['runs']) != 2):
    raise RuntimeError('Reading qualification identities differ')
for run, version in zip(verification['runs'], ['22.22.2', '20.19.5']):
    counts = run['counts']
    if (Path(run['runtime']).parent.parent.name != version
            or run['command'] != [run['runtime'], '--test', '--test-concurrency=1', *hold['testFiles']]
            or run['exitCode'] != 0 or run['inputsUnchanged'] is not True
            or counts['tests'] != 78 or counts['pass'] != 78
            or any(counts[name] for name in ['fail', 'cancelled', 'skipped', 'todo'])
            or checked(run['after']) != before):
        raise RuntimeError('Reading complete-file qualification differs')
allowed = ['game/app.mjs', 'game/ui/controller-navigation.mjs', 'game/ui/controller-reading.mjs']
if config['overlays'] != allowed or len(hold['files']) != 6:
    raise RuntimeError('Only three reviewed reading runtime overrides are allowed')
changed_runtime = [p for p in git('diff-tree', '--no-commit-id', '--name-only', '-r', TREE,
                    config['candidateTree'], '--', 'game/').decode().splitlines()
                   if not p.startswith('game/test/')]
if sorted(changed_runtime) != allowed:
    raise RuntimeError('Unreviewed runtime change in candidate tree')
qualified = {row['path']: row for row in before}
overlays = {}
for row in hold['files']:
    path = ROOT / row['path']
    if path.is_symlink():
        raise RuntimeError('Held source must be a regular owned file')
    body = path.read_bytes()
    if (len(body) != row['bytes'] or hashlib.sha256(body).hexdigest() != row['sha256']
            or qualified.get(row['path']) != row
            or git('show', config['candidateTree'] + ':' + row['path']) != body):
        raise RuntimeError('Held/tested reading source differs')
    if row['path'] in allowed:
        # Freeze admitted overrides. Later edits cannot retarget this origin.
        overlays[row['path']] = body
'''
s=s[:start]+block+s[end:]
start=s.index("binding = {'temporaryBaseCommit'")
end=s.index("with binding_path.open('x')",start)
s=s[:start]+'''binding = {'baseCommit': config['baseCommit'], 'baseTree': TREE,
           'candidateTree': config['candidateTree'],
           'sourceHold': config['sourceHold'], 'packageHold': config['packageHold'],
           'verification': config['verification'],
           'pid': os.getpid(), 'port': server.server_port,
           'url': f'http://127.0.0.1:{server.server_port}/game/',
           'gitBlobCacheBytes': LIMIT, 'maxConcurrentRequests': 4,
           'config': {'path': args.config, 'bytes': len(config_bytes),
                      'sha256': hashlib.sha256(config_bytes).hexdigest()},
           'helperSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'overlays': [row for row in hold['files'] if row['path'] in allowed],
           'scope': config['scope']}
'''+s[end:]
ast.parse(s);helper=out/'serve.py';helper.write_text(s)
def pin(p):
 b=Path(p).read_bytes();return {'path':str(Path(p).resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
config={'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'candidateTree':subprocess.check_output(['git','write-tree'],text=True).strip(),'indexSha256':hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'])).hexdigest(),'sourceHold':pin(c/'source-held-01.json'),'packageHold':pin(c/'package-held.json'),'verification':pin(c/'focused-verification.json'),'overlays':['game/app.mjs','game/ui/controller-navigation.mjs','game/ui/controller-reading.mjs'],'scope':'Normal immutable exact1f3 Git preview with only three tested reading runtime overrides. No timing/network fault, app/state/clock fixture or native acceptance. Candidate remains staged; existing controls/handlers unchanged.'}
configp=out/'config.json';configp.write_text(json.dumps(config,indent=2)+'\n')
diff=''.join(difflib.unified_diff(prior.read_text().splitlines(True),s.splitlines(True),fromfile='reviewed-team-css/serve.py',tofile='reading-prompts/serve.py'));(out/'helper-reuse.diff').write_text(diff)
prep={'status':'Prepared only; no helper import, server launch, HTTP or browser. Root peer required before launch.','priorHelper':pin(prior),'helper':pin(helper),'config':pin(configp),'reuseDiff':pin(out/'helper-reuse.diff'),'candidateTree':config['candidateTree'],'testReceipt':config['verification'],'sourceHold':config['sourceHold'],'command':['python3',str(helper),'--config','config.json','--binding','binding.json','--config-sha256',pin(configp)['sha256']]};(out/'preparation.json').write_text(json.dumps(prep,indent=2)+'\n');print(json.dumps(prep,indent=2))
