from pathlib import Path
import subprocess,json,hashlib,shutil,time,re
root=Path(__file__).resolve().parents[2]; c=root/'.cache/reading-prompts'
held=json.loads((c/'source-held-01.json').read_text()); admission=json.loads((c/'admission.json').read_text())
paths=sorted({r['path'] for r in admission['inputs']}|{r['path'] for r in held['files']})
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(name,x):
 p=c/name;p.write_text(json.dumps(x,indent=2)+'\n');return pin(p)
def snapshot():return [pin(root/p)|{'path':p} for p in paths]
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
index=sha(git('ls-files','-s','-z')); before=snapshot(); expected={r['path']:r for r in before}
for r in held['files']:
 assert expected[r['path']]['sha256']==r['sha256']
assert git('rev-parse','HEAD').decode().strip()==held['base']
before_pin=write('focused-before.json',before)
nodes=[Path('/Users/oleksandr.mekhovov/.local/share/mise/installs/node')/v/'bin/node' for v in ['22.22.2','20.19.5']]
authority=write('focused-authority.json',{'sourceHold':pin(c/'source-held-01.json'),'runner':pin(__file__),'indexSha256':index,'head':held['base'],'nodes':[pin(n) for n in nodes],'testFiles':held['testFiles'],'inputs':len(before),'bytes':sum(r['bytes'] for r in before)})
r={'scope':'Three complete affected reading/navigation/actual-Solo-host files, serial runtimes and concurrency1. Modelled browser boundaries only.','authority':authority,'before':before_pin,'runs':[],'completePair':False}
for node in nodes:
 major=node.parent.parent.name.split('.')[0]
 owned=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
 assert owned<100*1024**2 and shutil.disk_usage(root).free>256*1024**2
 cmd=[str(node),'--test','--test-concurrency=1',*held['testFiles']]
 log=c/f'focused-node{major}.log';start=time.time()
 with log.open('wb') as out: result=subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT)
 after=snapshot();after_pin=write(f'focused-after-node{major}.json',after)
 raw=log.read_text();counts={k:int(v) for k,v in re.findall(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',raw,re.M)}
 same=after==before and sha(git('ls-files','-s','-z'))==index
 r['runs'].append({'runtime':str(node),'command':cmd,'exitCode':result.returncode,'wallSeconds':round(time.time()-start,3),'counts':counts,'inputsUnchanged':same,'after':after_pin,'log':pin(log)})
 write('focused-verification.json',r)
 print(json.dumps(r['runs'][-1]),flush=True)
 if result.returncode or not same or counts.get('fail')!=0:break
else:
 r['completePair']=True;write('focused-verification.json',r)
print(json.dumps({'completePair':r['completePair'],'receipt':pin(c/'focused-verification.json')}),flush=True)
