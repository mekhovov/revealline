# P03 B — one deliberate title Start/Continue

Base c7f4faae318d58eacab140c1b2913e620e15efb7. Separate from A2 departure/R3 Library owners.

The title Start launches the actual prepared/remembered mission shown in its destination label; it no longer silently selects Pressure Lines and opens a second Missions screen. Missions remains the explicit selection action. Continue prefers the unfinished in-memory flight, otherwise verifies the exact captured saved bytes before adopting and starting. A corrupt/unavailable saved flight stays available for Library recovery; Start cannot silently overwrite it. Generic Library/Load saved flight remains paused.

The shell supplies a bounded current-title/visit predicate and synchronous close action; the host captures run, recorder, runId, selection, library generation and saved slot before asynchronous preparation. The host owns audio activation, preparation, cancellation and final Resume. An optional beforeAdopt guard plus returned adopted identity extends restoreAttempt without changing default restore behavior. No simulation/save format changes.

Preparation status and Cancel live in the active title. Another menu action, Back, blur, hidden, pagehide, selection changes, changed saved slot or library and competing operation invalidate the intent. Late completion may leave original media prepared but cannot adopt a saved run or start. Failure remains visible, old run and saved bytes remain, and focus is not stolen from a newer screen. A restored run that becomes stale after adoption stays paused. Title never grants unmute.

Source tests must exercise actual fresh/memory/saved runs, both steering policies, delayed picture/restore, cancellation/background, newer slot/selection, malformed saves, no duplicate held Confirm and unchanged ordinary restore/Back. Native checks are separate. P03 title mode links/common Couch lobby and physical-device certification remain open.

References: W3C APG modal dialog keyboard/return focus https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/ and Xbox XAG112 consistent input journeys https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/112 (read 2026-09-15). These guide interaction behavior; tests do not claim conformance.
