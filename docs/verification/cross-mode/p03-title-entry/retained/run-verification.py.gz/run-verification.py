from pathlib import Path
import subprocess,json,hashlib,time
cache=Path('.cache/p03b-title-entry')
files=['game/test/title-entry-host.test.mjs','game/test/field-kit-flow.test.mjs','game/test/flight-pictures-host.test.mjs','game/test/initial-focus-host.test.mjs','game/test/mission-replacement-host.test.mjs','game/test/starting-setup-host.test.mjs','game/test/restart-navigation-host.test.mjs','game/test/course-selection-host.test.mjs','game/test/mode-return-host.test.mjs','game/test/storage-retention-host.test.mjs','game/test/sessions-continuous.test.mjs']
for f in files:
 if not Path(f).exists():Path(f).write_bytes(subprocess.check_output(['git','show','HEAD:'+f]))
source=['game/app.mjs','game/index.html','game/ui/game-shell.mjs','game/ui/field-kit-copy.mjs']
pins={f:{'bytes':Path(f).stat().st_size,'sha256':hashlib.sha256(Path(f).read_bytes()).hexdigest()} for f in source+files}
results=[]
for version,label in [('22.22.2','node22'),('20.19.5','node20')]:
 argv=[f'/Users/oleksandr.mekhovov/.local/share/mise/installs/node/{version}/bin/node','--test','--test-concurrency=2',*files]
 log=cache/f'whole-{label}.log';start=time.monotonic()
 with log.open('wb') as out:result=subprocess.run(argv,stdout=out,stderr=subprocess.STDOUT)
 summary={line.split()[1]:line.split()[2] for line in log.read_text().splitlines() if line.startswith(('# tests ','# pass ','# fail ','# cancelled ','# skipped ','# todo ','# duration_ms '))}
 unchanged=all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==v['sha256'] for f,v in pins.items())
 results.append({'version':version,'argv':argv,'exitCode':result.returncode,'seconds':time.monotonic()-start,'summary':summary,'sourcePinsUnchanged':unchanged,'log':log.name,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (cache/'verification.json').write_text(json.dumps({'base':'c7f4faae318d58eacab140c1b2913e620e15efb7','pins':pins,'results':results},indent=2)+'\n');print(json.dumps(results[-1]),flush=True)
 if result.returncode or not unchanged:raise SystemExit(1)
