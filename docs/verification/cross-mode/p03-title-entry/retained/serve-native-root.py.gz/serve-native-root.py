from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlsplit
import subprocess, mimetypes, hashlib, json, time

ROOT = Path.cwd()
BASE = 'c7f4faae318d58eacab140c1b2913e620e15efb7'
OVERLAYS = {
 'game/app.mjs': (ROOT / 'game/app.mjs', '2781cea918d2b62e74cac015d62658d8750712b60b3debb3b0a3dde88178fa91'),
 'game/index.html': (ROOT / 'game/index.html', '538e4c50d24666fb3d34d6ddd69db1e72e623e842b5cebed645fff33880a3547'),
 'game/ui/game-shell.mjs': (ROOT / 'game/ui/game-shell.mjs', '8e5442e6ee9d5768a472af447c44469c8b5d4c822a51eec707c5f5069b7a7afe'),
 'game/ui/field-kit-copy.mjs': (ROOT / 'game/ui/field-kit-copy.mjs', 'f3ac3bed3a344934cf72990c1a9b37833320ecee1e05393cc1cc42166fe1ae23'),
}

for path, expected in OVERLAYS.values():
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, path

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = unquote(urlsplit(self.path).path).lstrip('/')
        if not path or path.endswith('/'):
            path += 'index.html'
        if any(p in ('.', '..', '.git', 'node_modules') for p in Path(path).parts) or not path.startswith(('game/', 'authoring/', 'docs/')):
            self.send_error(404)
            return
        try:
            if path in OVERLAYS:
                local, expected = OVERLAYS[path]
                body = local.read_bytes()
                if hashlib.sha256(body).hexdigest() != expected:
                    raise ValueError('Held preview input changed')
            else:
                size = int(subprocess.check_output(['git', 'cat-file', '-s', BASE + ':' + path], stderr=subprocess.DEVNULL))
                if size > 64 * 1024 * 1024:
                    raise ValueError('Bounded preview file limit')
                body = subprocess.check_output(['git', 'show', BASE + ':' + path], stderr=subprocess.DEVNULL)
            kind = mimetypes.guess_type(path)[0] or 'application/octet-stream'
            if path.endswith('.mjs'):
                kind = 'text/javascript'
            self.send_response(200)
            self.send_header('Content-Type', kind)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)
        except (OSError, ValueError, subprocess.CalledProcessError):
            self.send_error(404)
    def log_message(self, format, *args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 59387), Handler)
binding = {'base': BASE, 'overlays': {key: {'path': str(value[0]), 'sha256': value[1]} for key, value in OVERLAYS.items()}, 'port': server.server_port, 'scope': 'Title Start/Continue held four runtime files over exactc7f. Fresh owned59387 origin, actual UI navigation. No timing or game-state fixture.'}
(ROOT / '.cache/p03b-title-entry/native-preview-binding.json').write_text(json.dumps(binding, indent=2) + '\n')
print('Held title entry preview: http://127.0.0.1:59387/game/', flush=True)
server.serve_forever()
