# Deterministic recovery-return setup proposal

No browser GO. Bind execution to the committed v0.57.4 source and wait for Archive17 browser closure. Keep the prior r1–r5 evidence unchanged.

Use normal **More worlds → Install** for **FPV Front · Illustrated Pressure** before browser history. Installation preserves the current flight and does not select or materialize the newly installed FPV chapter. This removes the timing assumption about initial First Signal prewarm. Ukraine selection and original deletion are unnecessary.

1. Fresh profile, actual source hash check, featured Pressure Lines Orchard readiness. Perform one bounded native Deploy/direction/Escape sequence; retain paused save and original endpoint.
2. Main menu → Missions → More worlds. Click only `#optional-worlds-install-original-fpv-pressure` (actual visible enabled native control). Wait for exact installed status; **do not Choose**. No external-pair/file-input/import controls. The original immutable10,719,959-byte catalogue pack is fetched by the product.
3. Read actual storage before history. Assert the new pack is installed and its first level is eligible, while `original-fpv-pressure-lines/1/b86804fb3ab94151 / original-fpv-orchard-crossing / 1 / fpv` has no managed current-picture presentation/owner. The embedded pack original may exist; that is distinct from its unmaterialized published Field Kit picture. Keep raw saved Orchard/checkpoint and original digests. Stop if the premise is false.
4. Close More worlds normally, native Release explorer link then real Back. Require trusted persisted pagehide/pageshow and same timeOrigin; do not infer BFCache. Retain return endpoint.
5. Use normal More worlds → `#optional-worlds-choose-original-fpv-pressure`. It verifies the installed pack and selects its unlocked first level; no new installation is needed after writer release. After the card closes, use the actually visible Start mission control (#start-button), or visible Deploy if a Missions dialog is open, and require the exact writer-required picture recovery. If prewarm only records pending, Deploy must trigger the terminal; never allow a second actual flight or choose other candidates.
6. Record recovery and endpoints; native Export game data → Library Saves → Escape. Require visible enabled Export with restored focus, visible Reload and unchanged terminal feedback; no Check picture detour. Then click the actual Reload saved profile control directly and verify fresh page identity plus retained original saved flight.
7. Optional shortlandscape sample only if the required flow already reached and action budget remains. Close/reap exact owned browser/server/driver, rehash source/tools and retain endpoint/limits.

Keep all existing60action/900s/10sflight/6PNG/10MiBevidence/60MiBprofile/512MiBreserve guards. Count any supplemental native key as an action; this setup needs no new type-ahead helper. Report source/native scopes separately and do not mark P01 or public acceptance.

Source fact and exact baseline pins are in `source-facts.json`. No new runtime code, artificial progress unlock, storage injection, transport delay, or asset substitution is needed.

Operational requirements: exec_command uses tty:true for driver; send navigate immediately after ready. Do not invoke public-only read/solo; read/history captures actual DEV keys. Before each native click inspect actual ready/visible target; native Tab/PageDown may scroll ordinary content, no scripted scroll or focus. Initial optional card is first catalogue row. Stop on a failed premise or required error; do not search other packs.
