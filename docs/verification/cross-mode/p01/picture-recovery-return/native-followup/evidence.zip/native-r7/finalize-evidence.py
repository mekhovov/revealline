from pathlib import Path
import json,hashlib,datetime,struct
P=Path(__file__).resolve().parent;R=P/'run'
def h(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 assert p.is_file() and not p.is_symlink();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def data(n):return json.loads((R/f'action-{n:03}.json').read_text())
def result(n):return data(n)['result']
def storeDigest(d):return h(json.dumps(d['databases'],sort_keys=True,separators=(',',':')).encode())
def write(name,d):
 with (R/name).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
A={n:result(n) for n in [23,27,39,46,52]};events=[json.loads(s) for s in (R/'events.jsonl').read_text().splitlines()]
url=A[27]['url'];history=[x['measurement'] for x in events if x.get('method')=='DOM.event' and x['measurement'].get('url')==url]
hide=next(x for x in history if x['type']=='pagehide' and x.get('persisted'))
show=next(x for x in history if x['type']=='pageshow' and x.get('persisted'))
assert hide['isTrusted'] and show['isTrusted'] and hide['timeOrigin']==show['timeOrigin']==A[23]['timeOrigin']==A[27]['timeOrigin']
assert A[23]['databases']==A[27]['databases']
saved='revealline.suspended.dev.v1';a=json.loads(A[23]['storage'][saved]);b=json.loads(A[27]['storage'][saved]);beforeAt=a.pop('savedAt');afterAt=b.pop('savedAt');assert a==b
for k in A[23]['storage']:
 if k!=saved:assert A[23]['storage'][k]==A[27]['storage'][k]
for n in [39,46,52]:assert A[27]['storage']==A[n]['storage'] and A[27]['databases']==A[n]['databases']
assert A[52]['timeOrigin']!=A[46]['timeOrigin'] and result(51)['navigation'][0]['type']=='reload'
assert result(54)['pictureState']=='ready' and 'Continue · FPV Front · Pressure Lines · Orchard Crossing' in result(54)['body']
assert 'library-dialog' in result(42)['dialogs'] and result(44)['active']=='picture-export-data' and not result(44)['dialogs']
for n in [44,48]:
 for id in ['picture-export-data','picture-reload']:
  c=next(x for x in result(n)['controls'] if x['id']==id);assert c['fullyInViewport'] and c['centerHit'] and not c['disabled']
assert data(50)['command']=={'action':'click','arg':'#picture-reload'}
for n in range(37,56):assert data(n)['command']!={'action':'click','arg':'#start-button'}
# Original raw endpoints remain the evidence; these are reproducible compact comparisons.
endpoints=[]
for n,d in A.items():
 s=json.loads(d['storage'][saved]);endpoints.append({'action':n,'pin':pin(R/f'action-{n:03}.json'),'timeOrigin':d['timeOrigin'],'rawLocalStorage':[{'key':k,'bytes':len(v.encode()),'sha256':h(v.encode())} for k,v in sorted(d['storage'].items())],'allObservedIdbRowsSha256':storeDigest(d),'checkpoint':s['replay']['checkpoint'],'replayTicks':s['replay']['ticks'],'picturePins':s['presentationPins']})
write('endpoint-invariants.json',{'status':'PASS_SCOPED_OBSERVED_ENDPOINTS','endpoints':endpoints,'comparisons':{'23to27':'All IDB rows/digests unchanged. Last selection unchanged. Suspended save differs only savedAt during ordinary pre-navigation close/menu/save; full checkpoint/replay/pins unchanged.','27to39to46to52':'Raw localStorage values and all observed IDB store rows/digests equal through failed new-picture selection, Export/Library/Escape, and direct Reload.'},'preNavigationSavedAt':{'before':beforeAt,'after':afterAt},'history':{'pagehide':hide,'pageshow':show},'boundary':'Read-only existing-store endpoint comparison and native DOMStorage events, not a complete transient IndexedDB transaction trace.'})
shotpins=[]
for p in sorted(R.glob('*.png')):
 b=p.read_bytes();shotpins.append({**pin(p),'width':struct.unpack('>I',b[16:20])[0],'height':struct.unpack('>I',b[20:24])[0],'visuallyInspected':True})
capacity=[json.loads(s) for s in (R/'capacity.jsonl').read_text().splitlines()]
errors=[x for x in events if x.get('method') in ['Runtime.exceptionThrown','Network.loadingFailed','Page.backForwardCacheNotUsed']]
changes=[x for x in events if x.get('method','').startswith('DOMStorage.')];afterChanges=[x for x in changes if x['at']>='2026-09-15T21:50:17.668Z'];assert not afterChanges
write('review.json',{'status':'PASS_BOUNDED_CHANGED_FLOW_NOT_PHASE_ACCEPTANCE','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':{'commit':'114a5eb42083009db6865d50bcbb53a8e7592b53','tree':'8426fbca5d5ad5506e4a0e969a623560794f1468','version':'0.57.4','channel':'dev','pinnedSourceRows':110,'sourcePin':pin(P/'input-pins.json'),'actualServedFiveFileCheck':pin(R/'action-002.json'),'sourceAnd15ToolsUnchangedAtFinalCapacity':True},'ownership':{'server':json.loads((R/'server.json').read_text()),'browserPid':7722,'controllerPid':8187,'cdpPort':52397,'target':'511B6A8B930B425299CCA2C157AC81AB','closure':pin(R/'closure.json'),'profileRetainedExcludedFromEvidence':True},'scope':'Finite exact-source Install-only missing-owner premise, genuine persisted Explorer Back, writer-required recovery, native Export game data to Library Saves, Escape with visible focused opener, direct product Reload; no Check picture detour, no second live flight.','decisiveActions':{'normalFlight':{'action':6,'nativeDurationMs':569,'replayTicks':17,'replaySeconds':17/120},'install':{'nativeTabFocus':15,'stableInspect':[16,17],'nativeEnterNoObservedActivation':18,'nativeStablePointerActivation':21,'installedAbsentOwnerPremise':pin(R/'installed-absent-owner-premise.json')},'history':{'explorerClick':25,'actualBack':26,'persistedReturn':27},'choose':{'nativeFocusedChoose':35,'visibleInspection':36,'stablePointerActivation':37,'writerRequiredRecovery':38},'library':{'exportClick':41,'savesOpen':42,'nativeEscape':43,'focusedExportAndReloadControls':44},'directReload':{'click':50,'freshReloadNavigation':51,'retainedEndpoint':52,'readyTitleWithContinue':54}},'invariants':pin(R/'endpoint-invariants.json'),'geometry':[{'action':n,'viewport':result(n)['viewport'],'active':result(n)['active'],'controls':[{k:c[k] for k in ['id','text','disabled','rect','fullyInViewport','centerHit']} for c in result(n)['controls'] if c['id'] in ['picture-export-data','picture-reload']]} for n in [44,48]],'screenshots':shotpins,'counts':{'actions':55,'pngs':4,'allActionGuardsPassed':True,'ordinaryFlights':1,'historyBacks':1,'productReloads':1,'downloads':0,'maxRestarts':0},'capacityFinal':capacity[-1],'recorder':{'eventBytes':(R/'events.jsonl').stat().st_size,'final':events[-1],'runtimeExceptionCount':sum(x.get('method')=='Runtime.exceptionThrown' for x in errors),'retainedNetworkErrors':errors,'noObservedLocalStorageChangesAfterPersistedReturn':True},'limitations':['Native Enter on the stable focused Install produced no observed activation; retained without attribution. Parent-authorized stable pointer fallback succeeded for Install and Choose.','This is unchanged exact-source DEV served with public-style cache headers and actual local Explorer, not public frozen v0.57.4 bytes or a full P01 acceptance.','Suspended savedAt changed before history while ordinary menu/Explorer navigation saved; checkpoint/replay/pins remained identical. No false pre-navigation raw-byte equality claim.','Terminal feedback remained in the DOM. Portrait and landscape screenshot claims concern retained visible Export/Reload and opener focus; no claim that the run-message text below the viewport is visible.','At844x390 other narrow overlay buttons have cramped/clipped labels. Export/Reload are fully visible and hit-tested; no broader layout or Large/native zoom claim.','One canceled Document net::ERR_ABORTED is retained at direct Reload; no Runtime.exceptionThrown or recorder cap/socket failure observed. No causal claim beyond its timing.','No complete transient IndexedDB write trace, backup download, restored original injection, physical controller/audibility check, or additional Resume/flight after Reload.','Public-only read/solo observer was never used. No game state/clock/lifecycle/storage injection; observed persisted history events include actual top document only for the proof.','Prior r1-r6 failures/partial outcomes remain immutable.'], 'parentAuthorization':pin(P/'root-authorization.json'),'parentReview':pin(P/'parent-review.json')})
files=[]
for p in sorted(P.rglob('*')):
 if not p.is_file() or p.is_symlink() or p.is_relative_to(R/'profile') or '__pycache__' in p.parts or p.name=='manifest.json' and p.parent==R:continue
 files.append(pin(p))
write('manifest.json',{'status':'CLOSED_SCOPED_PASS','root':str(P),'files':files,'count':len(files),'bytes':sum(r['bytes'] for r in files),'excludes':['run/profile/**','__pycache__/**'],'claim':'Selected exact originals for bounded local source recovery-return proof; not phase/public acceptance.'})
for name in ['endpoint-invariants.json','review.json','manifest.json']:print(json.dumps(pin(R/name)))
print('selected',len(files),sum(r['bytes'] for r in files))
