import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import test from 'node:test';

const source=fs.readFileSync(new URL('./driver.mjs',import.meta.url),'utf8');
const start=source.indexOf('async function stableClickTarget(read){');
const end=source.indexOf('\nasync function click(selector)',start);
assert(start>=0&&end>start);
const stableClickTarget=vm.runInNewContext('('+source.slice(start,end)+' )',{performance,setTimeout,clearTimeout});
const target=y=>({matches:1,id:'install',tag:'BUTTON',type:'button',href:null,disabled:false,hit:true,visible:true,rect:{x:20,y,width:120,height:44},x:80,y:y+22,hitId:'install'});

test('actual driver helper settles geometry and refuses covered or stalled reads before input',async()=>{
 let inputs=0,reads=0;
 const moving=(async()=>{
  const began=performance.now();
  const result=await stableClickTarget(async()=>target(++reads===1?287:120));
  inputs++;
  assert.equal(result.rect.y,120);
  assert.equal(result.stability.observations,3);
  assert(result.stability.matchingObservationGapMs>=300);
  assert(result.stability.elapsedMs>=600&&result.stability.elapsedMs<3000);
  assert(performance.now()-began>=600);
 })();
 let coveredReads=0,coveredInput=0;
 const covered=(async()=>{
  const began=performance.now();
  await assert.rejects(async()=>{
   await stableClickTarget(async()=>{coveredReads++;return {...target(15),hit:false};});
   coveredInput++;
  },/not observed within 3000ms/);
  assert.equal(coveredInput,0);assert(coveredReads>=2);
  assert(performance.now()-began<3400);
 })();
 let stalledInput=0;
 const stalled=(async()=>{
  const began=performance.now();
  await assert.rejects(async()=>{
   await stableClickTarget(()=>new Promise(()=>{}));stalledInput++;
  },/not observed within 3000ms/);
  assert.equal(stalledInput,0);assert(performance.now()-began<3400);
 })();
 await Promise.all([moving,covered,stalled]);
 assert.equal(inputs,1);
 // Existing mouse dispatch remains after the actual helper and URL guard.
 const click=source.slice(end,source.indexOf('\nasync function key',end));
 assert(click.indexOf('await stableClickTarget(')<click.indexOf("await call('Input.dispatchMouseEvent'"));
 assert(click.indexOf("throw Error('Unplanned navigation')")<click.indexOf("await call('Input.dispatchMouseEvent'"));
});
