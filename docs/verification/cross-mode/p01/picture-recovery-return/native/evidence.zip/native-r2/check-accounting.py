from pathlib import Path
import tempfile,stat,os,json,hashlib,ast
P=Path(__file__).resolve().parent
source=(P/'capacity.py').read_text();ast.parse(source)
start=source.index(' profile=evidence=allocated=0;profileLinks=[]')
end=source.index(" l=C['limits']",start)
block='\n'.join(line[1:] for line in source[start:end].splitlines())
results=[]
with tempfile.TemporaryDirectory(prefix='guard-fixture-',dir=P) as tmp:
 root=Path(tmp);run=root/'run';profile=run/'profile';profile.mkdir(parents=True)
 outside=root/'outside';outside.mkdir();(outside/'unread-payload').write_bytes(b'x'*4096)
 (profile/'ordinary').write_bytes(b'ok')
 for name in ['SingletonLock','SingletonCookie','SingletonSocket']:(profile/name).symlink_to(outside,target_is_directory=True)
 env={'R':run,'stat':stat};exec(compile(block,'actual-capacity-scan','exec'),env)
 assert len(env['profileLinks'])==3 and env['profile']==2+sum(os.lstat(profile/n).st_size for n in ['SingletonLock','SingletonCookie','SingletonSocket'])
 results.append({'case':'three direct named Singleton directory links counted by lstat; target tree not traversed','passed':True,'links':env['profileLinks'],'profileBytes':env['profile']})
 for name,where in [('Unexpected',profile),('SingletonLock',run)]:
  link=where/name;link.symlink_to(outside,target_is_directory=True)
  try:exec(compile(block,'actual-capacity-scan','exec'),{'R':run,'stat':stat})
  except AssertionError as e:results.append({'case':'reject '+str(link.relative_to(run)),'passed':True,'error':str(e).replace(str(root),'<fixture>')})
  else:raise AssertionError('Unexpected symlink accepted')
  link.unlink()
print(json.dumps({'status':'PASS_SYNTHETIC_ACCOUNTING_ONLY','capacitySha256':hashlib.sha256(source.encode()).hexdigest(),'actualScanBlockSha256':hashlib.sha256(block.encode()).hexdigest(),'cases':results,'browser':False,'network':False,'sourceTests':False},indent=2))
