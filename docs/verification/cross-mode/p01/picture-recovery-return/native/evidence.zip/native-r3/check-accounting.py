from pathlib import Path
import tempfile,stat,os,json,hashlib,ast
P=Path(__file__).resolve().parent;source=(P/'capacity.py').read_text();ast.parse(source)
a=source.index(' profile=evidence=allocated=0;profileLinks=[]');b=source.index(" l=C['limits']",a);block='\n'.join(x[1:] for x in source[a:b].splitlines());results=[]
with tempfile.TemporaryDirectory(prefix='fixture-',dir=P) as t:
 root=Path(t);R=root/'run';profile=R/'profile';(profile/'nested').mkdir(parents=True);outside=root/'outside';outside.mkdir();(outside/'payload').write_bytes(b'x'*4096);(profile/'normal').write_bytes(b'abc');(R/'evidence.json').write_bytes(b'ok')
 (profile/'RunningChromeVersion').symlink_to(outside/'payload');(profile/'nested/socket').symlink_to(outside,target_is_directory=True)
 env={'R':R,'stat':stat,'os':os,'Path':Path};exec(compile(block,'actual-capacity-scan','exec'),env)
 expected=3+os.lstat(profile/'RunningChromeVersion').st_size+os.lstat(profile/'nested/socket').st_size
 assert env['profile']==expected and env['evidence']==2 and len(env['profileLinks'])==2
 results.append({'case':'top-level file and nested directory profile links counted by lstat, external payload not traversed; ordinary profile/evidence totals exact','passed':True,'profileBytes':env['profile'],'evidenceBytes':env['evidence']})
 link=R/'evidence-link';link.symlink_to(outside,target_is_directory=True)
 try:exec(compile(block,'actual-capacity-scan','exec'),{'R':R,'stat':stat,'os':os,'Path':Path})
 except AssertionError:results.append({'case':'evidence link outside profile refused','passed':True})
 else:raise AssertionError('Evidence link accepted')
 link.unlink();(profile/'RunningChromeVersion').unlink();(profile/'nested/socket').unlink();(profile/'normal').unlink();(profile/'nested').rmdir();profile.rmdir();profile.symlink_to(outside,target_is_directory=True)
 try:exec(compile(block,'actual-capacity-scan','exec'),{'R':R,'stat':stat,'os':os,'Path':Path})
 except AssertionError:results.append({'case':'profile root link refused','passed':True})
 else:raise AssertionError('Profile root link accepted')
print(json.dumps({'status':'PASS_SYNTHETIC_ACCOUNTING_ONLY','capacitySha256':hashlib.sha256(source.encode()).hexdigest(),'cases':results,'browser':False,'network':False,'sourceTests':False},indent=2))
