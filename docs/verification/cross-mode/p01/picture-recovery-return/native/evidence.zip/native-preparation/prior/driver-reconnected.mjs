import fs from 'node:fs';import path from 'node:path';import readline from 'node:readline';
import {R,P,config,launch,server,call,attach,evaluate,foreground,events,close,allowedUrl,ws} from './cdp.mjs';
const {sessionId:sid,target}=await attach();
const eventFile=fs.openSync(path.join(R,'events-reconnected.jsonl'),'wx');let eventBytes=0;
const log=v=>{const s=JSON.stringify({at:new Date().toISOString(),...v})+'\n';eventBytes+=Buffer.byteLength(s);if(eventBytes>1048576)throw Error('One MiB event bound');fs.writeSync(eventFile,s);};
events.push(m=>{
 if(m.method==='Runtime.consoleAPICalled'&&m.sessionId===sid){for(const a of m.params.args||[])if(typeof a.value==='string'&&a.value.startsWith('P01_HISTORY '))log({method:'DOM.event',measurement:JSON.parse(a.value.slice(12))});}
 else if(m.method?.startsWith('DOMStorage.domStorage')){const p={...m.params};for(const k of ['oldValue','newValue'])if(typeof p[k]==='string')p[k]=p[k].length;log({method:m.method,params:p});}
 else if(['Page.backForwardCacheNotUsed','Runtime.exceptionThrown','Network.loadingFailed','Inspector.detached','Target.detachedFromTarget'].includes(m.method))log(m);
});
await call('Page.enable',{},sid);await call('Runtime.enable',{},sid);await call('DOMStorage.enable',{},sid);await call('Network.enable',{},sid);
const observe=`(()=>{const record=e=>console.info('P01_HISTORY '+JSON.stringify({type:e.type,persisted:e.persisted,url:location.href,timeOrigin:performance.timeOrigin,at:performance.now(),isTrusted:e.isTrusted,visibility:document.visibilityState,focus:document.hasFocus(),active:document.activeElement?.id}));for(const n of ['pagehide','pageshow','error','unhandledrejection'])window.addEventListener(n,record);document.addEventListener('visibilitychange',record);})();`;
await call('Page.addScriptToEvaluateOnNewDocument',{source:observe},sid);
await call('Emulation.setDeviceMetricsOverride',{width:1280,height:800,deviceScaleFactor:1,mobile:false},sid);
await evaluate(observe,sid);
log({ready:true,pid:process.pid,target,sessionId:sid});console.log(JSON.stringify({ready:true,pid:process.pid,target:target.targetId}));
let number=fs.readdirSync(R).filter(n=>/^action-\d+\.json$/.test(n)).length,done=false;ws.addEventListener('close',e=>log({socketClosed:true,code:e.code,reason:e.reason,clean:e.wasClean}));ws.addEventListener('error',e=>log({socketError:String(e.message||e)}));const heartbeat=setInterval(()=>{log({heartbeat:true,socketState:ws.readyState});call('Browser.getVersion').then(v=>log({alive:true,product:v.product})).catch(e=>log({aliveError:String(e)}));},3000);
function finish(){if(done)return;done=true;clearInterval(heartbeat);log({closed:true});fs.closeSync(eventFile);close();}
process.on('SIGTERM',()=>{finish();process.exit(0)});process.on('SIGINT',()=>{finish();process.exit(0)});
const lines=readline.createInterface({input:process.stdin});
for await(const line of lines){let receipt={at:new Date().toISOString(),pid:launch.pid,profile:launch.profile,targetId:target.targetId};
 try{const command=JSON.parse(line),{action,arg,hold=0}=command;receipt.command=command;
  if(action==='close'){await call('Browser.close');receipt.ok=true;}
  else{
   const targets=(await call('Target.getTargets')).targetInfos;receipt.targets=targets;
   if(targets.some(t=>t.type==='page'&&t.targetId!==target.targetId))throw Error('Unidentified extra page; stop and preserve');
   const current=targets.find(t=>t.targetId===target.targetId);if(!current||!allowedUrl(current.url))throw Error('Owned target route changed');
   await call('Page.bringToFront',{},sid);receipt.before=await foreground(sid);
   if(action==='read')receipt.result=await evaluate(arg,sid);
   else if(action==='storage')receipt.result=await evaluate(fs.readFileSync(path.join(P,'read-storage.js'),'utf8'),sid);
   else if(action==='shot'){
    if(!/^[a-z0-9-]+$/.test(arg)||fs.readdirSync(R).filter(n=>n.endsWith('.png')).length>=6)throw Error('Screenshot cap');
    const r=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false},sid);const file=path.join(R,arg+'.png');fs.writeFileSync(file,Buffer.from(r.data,'base64'),{flag:'wx'});receipt.output=file;
   }else if(action==='click'){
    const r=await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(arg)});if(!e)return null;const r=e.getBoundingClientRect(),x=Math.max(1,Math.min(innerWidth-1,r.x+r.width/2)),y=Math.max(1,Math.min(innerHeight-1,r.y+r.height/2)),h=document.elementFromPoint(x,y);return {disabled:e.disabled,rect:r.toJSON(),text:e.innerText,x,y,hit:h===e||e.contains(h),visible:r.width>0&&r.height>0&&r.top>=0&&r.bottom<=innerHeight}})()`,sid);receipt.element=r;
    if(!r||r.disabled||!r.hit||!r.visible)throw Error('Actual visible enabled target refused');
    for(const type of ['mouseMoved','mousePressed','mouseReleased'])await call('Input.dispatchMouseEvent',{type,x:r.x,y:r.y,...(type==='mouseMoved'?{}:{button:'left',clickCount:1})},sid);
   }else if(action==='key'){
    const keys={Escape:27,Tab:9,Enter:13,ArrowDown:40,ArrowUp:38,ArrowLeft:37,ArrowRight:39};if(!keys[arg]||hold<0||hold>350)throw Error('Key bound');const key={key:arg,code:arg,windowsVirtualKeyCode:keys[arg]};await call('Input.dispatchKeyEvent',{type:'keyDown',...key},sid);if(hold)await new Promise(r=>setTimeout(r,hold));await call('Input.dispatchKeyEvent',{type:'keyUp',...key},sid);
   }else if(action==='back'){
    const h=await call('Page.getNavigationHistory',{},sid),entry=h.entries[h.currentIndex-1];receipt.history=h;if(!entry||!allowedUrl(entry.url))throw Error('Invalid history return');await call('Page.navigateToHistoryEntry',{entryId:entry.id},sid);
   }else throw Error('Unknown action');
   receipt.after=await foreground(sid);receipt.ok=true;
  }
 }catch(e){receipt.ok=false;receipt.error=String(e.stack);}
 const filename=`action-${String(++number).padStart(3,'0')}.json`;fs.writeFileSync(path.join(R,filename),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({receipt:filename,ok:receipt.ok,...(receipt.result?{result:receipt.result}:{}),...(receipt.error?{error:receipt.error}:{})}));
 if(receipt.command?.action==='close'||!receipt.ok){finish();break;}
}
finish();
