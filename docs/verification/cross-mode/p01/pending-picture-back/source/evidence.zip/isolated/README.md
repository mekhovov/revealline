# Pending picture Back correction

The six-line app change handles keyboard Escape and modeled controller Back at the existing shared owner boundary. Native dialogs and course handling retain precedence. Only a current picture launch delegates to the existing Cancel action and returns focus to Start; restore work, unrelated modal work and terminal recovery remain outside this branch.

The original app fails both mounted pending Start regression routes. With the correction, the complete flight picture host file passes 19/19 and exits naturally. The prior six-file run retained 157/157 unaffected passing cases, including navigation, input, export/backup ownership and the strengthened terminal recovery case. Its two Retry failures came from the fixture demanding exactly one held decode; the observed two overlapping decode owners invalidate that premise. The corrected test accepts at least one held decode, still requires current busy ownership, and releases/rejects all held work together.

Start, settled-results Retry and confirmed saved Restart check cancelled status, focus, no late resume, checkpoint, saved bytes, selected content and original identities. Keyboard late success and controller late failure are both covered. Ordinary ready Back remains unchanged. ESLint, formatting and diff checks pass.

No deadline was increased: settle still delegates to the existing 5,000 ms waitFor default. Retry duration includes the real modeled victory setup. Earlier idle-run interpretations are corrected additively: the existing export object-URL revocation timeout lasts 60 seconds. Those stopped originals remain retained; the final 19-case run completed naturally in 167,112.083708 ms.

This is scoped source evidence. No browser, physical-controller claim, full suite, build, version change, commit or cross_mode edit was made. Parent owns any subsequent prewarm-feedback correction and final integration.

`review.json` pins the result, `candidate.patch` contains the exact three-file change, and `manifest.json` preserves every original in this directory, including failed observations.
