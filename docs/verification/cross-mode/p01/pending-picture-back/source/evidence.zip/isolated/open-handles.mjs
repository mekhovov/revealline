setTimeout(() => {
  process.stderr.write(JSON.stringify({ diagnostic: 'open-resources-after-cases', resources: process.getActiveResourcesInfo(), handles: process._getActiveHandles().map((h) => ({ type: h.constructor?.name, fd: h.fd })), requests: process._getActiveRequests().map((h) => h.constructor?.name) }) + '\n');
}, 8000).unref();
