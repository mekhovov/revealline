import datetime,hashlib,json,pathlib,shutil,socket,subprocess,zipfile
ROOT=pathlib.Path('/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode')
P=ROOT/'.cache/cross-mode/p01/v0572-library-boundary/public-transfer-recovery'
def read(p): return json.loads(p.read_text())
def pin(p,base=P):
 b=p.read_bytes(); return {'path':str(p.relative_to(base)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,d):
 with p.open('x') as f: f.write(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
for row in read(P/'input-pins.json')['source']:
 assert pin(ROOT/row['path'],ROOT)==row,row['path']
for row in read(P/'tool-pins.json')['files']:
 assert pin(P/row['path'])==row,row['path']
pids=[65463,65682,68122,72102]
proc=subprocess.run(['ps','-p',','.join(map(str,pids)),'-o','pid=,command='],capture_output=True,text=True)
assert not proc.stdout.strip(),proc.stdout
sock=socket.socket();sock.settimeout(1);rc=sock.connect_ex(('127.0.0.1',63566));sock.close();assert rc==61,rc
before=read(P/'run/action-061.json')['result'];after=read(P/'run/action-069.json')['result'];old=read(P/'run/action-007.json')['result']
assert before['storage']==after['storage'];assert before['databases']==after['databases']
oldkey='revealline.suspended.release-v0.42.0.v1';newkey='revealline.suspended.release-v0.57.2.v1'
old_paused=json.loads(old['storage'][oldkey]); old_closed=json.loads(before['storage'][oldkey]); assert {k:v for k,v in old_paused.items() if k!='savedAt'}=={k:v for k,v in old_closed.items() if k!='savedAt'}
fixture=read(ROOT/read(P/'fixtures.json')[2]['path'])
assert fixture['format']=='xonix-backup.v2' and fixture['externalChapters']=={'format':'revealline-external-chapter-index.v1','chapters':[]}
assert fixture['packs']['packs']==[]
olds=read(P/'run/action-007.json')['result']['storage']; oldsave=json.loads(olds[oldkey]);newsave=json.loads(before['storage'][newkey])
profile=json.loads(before['storage']['revealline.library.release-v0.57.2.v1'])
assets=before['databases'][0]['stores'][0]
assert 'revealline.library.release-v0.57.2.v1.external-chapter-index.v1' in assets['keys']
assert not any('release-v0.42.0' in k for k in assets['keys'])
media=next(s for d in before['databases'] for s in d['stores'] if s['name']=='mediaBlobs')
assert before['readBlobBytes']==1202909
assert {x['sha256'] for x in media['originals']}=={'0233c5f399b93700594af044a5f56687a0742333d32b7bc54ef7122173f1dc65','7f851f9806a1be994b2279f3d1acc4f2f39884ac6cf2fdf6b8a7813e61c73745','d643a6ebbf92b93dc57a0cfe65ca4bcf484ceecd8ed632ed6476707ec720e85a'}
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
closure={'at':now,'scope':'Stopped public transfer attempt only; profile retained for separately authorized independent continuation.','pidsAbsent':pids,'psExitCode':proc.returncode,'debugPort':63566,'connectErrno':rc,'freeBytes':shutil.disk_usage(P).free,'browserExit':read(P/'run/exit.json'),'allInputAndInitialToolPinsUnchanged':True,'downloadFiles':len(list((P/'run/downloads').iterdir())),'observerLogsClosed':[f for f in ['events.jsonl','events-current.jsonl','events-continued.jsonl'] if read(P/'run/exit.json') and json.loads((P/'run'/f).read_text().splitlines()[-1]).get('closed') is True]}
write(P/'run/closure.json',closure)
review={'at':now,'status':'FAIL_REQUIRED_TRANSFER_COPY','phaseAccepted':False,'scope':'Native public desktop transfer prerequisite and stopped Copy attempt; no corrected-source or phase acceptance.','identity':{'version':'v0.57.2','source':'cc9f8ffcc3be246f53ca0df7f068476d8401d040','publisher':'d0288c502620bfa7a4a0861fbdbce1a60be183c5','url':'https://mekhovov.github.io/revealline/releases/v0.57.2/site/game/','oldVersion':'v0.42.0','oldSource':'e9928cdaad2f55d912aadd2ef25f635fb99e938c','oldUrl':'https://mekhovov.github.io/revealline-archive-10/releases/v0.42.0/site/game/','authority':pin(P/'authority.json'),'criticalBodyScope':'Five canonical bodies checked against frozen manifests; not another complete public audit.'},'nativeScope':{'browser':'Chrome 153.0.8010.37','viewport':[1280,800],'input':'Scoped native CDP mouse, keys and actual file inputs; read-only DOM/storage observations.','oldPageClosedBeforeNewSchemaWrites':True,'oldPageReopened':False,'historicalClosure':['run/action-009.json','run/closed-historical-target-observation.json','run/historical-page-closed.json','run/action-010.json']},'passedPrerequisites':[{'case':'Authentic v0.42 Start, brief border motion and Pause','actions':[1,4,5,6,7,8]},{'case':'Picture original review, explicit restore and saved-media reload','actions':[17,26,27,28,29,30,31,32]},{'case':'Incoming story binding review and explicit restore','actions':[36,39,41,42,43,44,45,46]},{'case':'Authentic earned backup import, saved flight and one earned picture visible','actions':[59,60,61]},{'case':'Earlier-release source review reports verified and enables Copy','actions':[64,65,66]}],'failure':{'action':67,'terminalEvidence':'run/action-068.json','screenshot':'run/03-transfer-copy-refused.png','message':read(P/'run/action-068.json')['result']['status'],'sourcePreview':read(P/'run/action-066.json')['result']['preview'],'causeScope':'Source diagnosis: prepareProfileTransfer chooses backup.v1 for a verified absent historical external index. Current target has an explicit indexed chapter companion; strict backup.v2 guard correctly rejects the incomplete candidate. Parent owns bounded adaptation; no guard weakening.'},'sourceSnapshot':{'channel':'release-v0.42.0','profileAbsent':not any(k=='revealline.library.release-v0.42.0.v1' for k in olds),'runId':oldsave['runId'],'campaignKey':oldsave['campaignKey'],'checkpoint':oldsave['replay']['checkpoint'],'externalChapterIndexAbsent':True,'packsAbsent':True,'ordinaryCloseSavedAtChange':{'paused':old_paused['savedAt'],'afterClose':old_closed['savedAt']},'allOtherSavedFieldsUnchangedSinceHistoricalPause':True},'targetSnapshot':{'channel':'release-v0.57.2','generation':profile['generation'],'runId':newsave['runId'],'checkpoint':newsave['replay']['checkpoint'],'galleryCount':len(profile['library']['gallery']),'campaignCount':len(profile['library']['campaigns']),'assetStore':assets,'originals':media['originals'],'readBlobBytes':before['readBlobBytes'],'indexValueAuthority':'Verified imported authentic backup.v2 fixture has explicit empty chapters; native snapshot independently records key presence and whole-store digest, not separately serialized index content.'},'preservation':{'before':'run/action-061.json','after':'run/action-069.json','allRawLocalStorageEqual':True,'allDatabaseStoreKeysCountsDigestsAndBlobsEqual':True,'limits':'Endpoint equality of read-only snapshots, not a complete IndexedDB transaction trace. Undo visible after failure belongs to prior successful import.'},'notExecuted':['Successful Copy and copied-flight resume','Copy Undo','Collection/story/thumbnail after reload','Settings recovery review of closed v0.42 channel','Direct original review, verification and download','Native input cancel and responsive/mobile/controller cases'],'toolingRefusals':[{'path':'initial-old-route-refusal.json','reason':'Initial obsolete blueprint URL omitted /releases/ and returned 404; canonical route verified before browser.'},{'action':9,'reason':'Asynchronous target-close observation refused before new navigation; actual old-target absence proved separately before continuation.'},{'actions':[20,33],'reason':'Offscreen pointer hit-test refusals sent no click; subsequent native keyboard scrolling used visible controls.'},{'action':71,'reason':'Final read-only diagnostic expression had a SyntaxError (await in non-async expression); no app-state mutation or product exception inferred.'}],'limits':['No state injection, fixture mutation, legacy page reopen or new win.','Coverage fixture differs from later game fixture; no exact five-file export-set claim.','No physical hardware, audibility, touch-only, gamepad, responsive or full public acceptance claim.','One canceled media request observed; no recorded product Runtime exception.','Independent remaining hosts may be resumed under separate authorization without retrying known-failed Copy.'],'closure':pin(P/'run/closure.json'),'continuedTools':[pin(P/n) for n in ['driver-current.mjs','driver-continued.mjs','closed-transition-continuation.json','visible-control-continuation.json']]}
write(P/'review.json',review)
files=sorted([x for x in P.iterdir() if x.is_file() and x.name not in ['evidence-manifest.json','evidence.zip','evidence-record.json']]+list((P/'authority').rglob('*'))+[x for x in (P/'run').iterdir() if x.is_file()])
files=[x for x in files if x.is_file()]
rows=[pin(x) for x in files]
manifest={'format':'revealline-evidence-selection.v1','at':now,'status':'FAIL_REQUIRED_TRANSFER_COPY','files':rows,'fileCount':len(rows),'bytes':sum(x['bytes'] for x in rows),'excluded':['run/profile/**','run/downloads/** (empty)','__pycache__/**','authentic source fixtures (existing originals referenced by unchanged pins)']}
assert manifest['bytes']<10*1024*1024
write(P/'evidence-manifest.json',manifest)
with zipfile.ZipFile(P/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in rows+[pin(P/'evidence-manifest.json')]:
  info=zipfile.ZipInfo(row['path'],(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,(P/row['path']).read_bytes())
with zipfile.ZipFile(P/'evidence.zip') as z:
 assert len(z.namelist())==len(rows)+1 and z.testzip() is None
 for row in rows+[pin(P/'evidence-manifest.json')]:
  b=z.read(row['path']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];assert b==(P/row['path']).read_bytes()
record={'at':now,'status':'FAIL_REQUIRED_TRANSFER_COPY','review':pin(P/'review.json'),'manifest':pin(P/'evidence-manifest.json'),'archive':pin(P/'evidence.zip'),'sourceFileCount':len(rows),'sourceBytes':manifest['bytes'],'archiveMemberCount':len(rows)+1,'archiveRehashedAgainstOriginals':True,'scope':'Stopped attempt only; no passing transfer/phase claim.'}
write(P/'evidence-record.json',record)
print(json.dumps(record,indent=2))
