(async()=>{
 const hash=async b=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(x=>x.toString(16).padStart(2,'0')).join('');
 let blobBytes=0;
 const simplify=async v=>{
  if(v instanceof Blob){blobBytes+=v.size;if(blobBytes>8388608)throw Error('Read-only original budget');return{blobBytes:v.size,type:v.type,sha256:await hash(await v.arrayBuffer())};}
  if(v instanceof ArrayBuffer){blobBytes+=v.byteLength;if(blobBytes>8388608)throw Error('Read-only byte budget');return{bytes:v.byteLength,sha256:await hash(v)};}
  if(Array.isArray(v))return await Promise.all(v.map(simplify));
  if(v&&typeof v==='object'){const out={};for(const k of Object.keys(v).sort())out[k]=await simplify(v[k]);return out;}
  return v;
 };
 const entries=await indexedDB.databases();if(entries.length>5)throw Error('Database count');const databases=[];
 for(const entry of entries){if(!['revealline-assets-v1','revealline-soundtrack-v1'].includes(entry.name))throw Error('Unplanned database');
  const db=await new Promise((resolve,reject)=>{const r=indexedDB.open(entry.name,entry.version);r.onupgradeneeded=()=>{r.transaction.abort();reject(Error('No database creation'));};r.onerror=()=>reject(r.error);r.onsuccess=()=>resolve(r.result);});
  try{const names=[...db.objectStoreNames];const values=await new Promise((resolve,reject)=>{const tx=db.transaction(names,'readonly');const out={};for(const name of names){const s=tx.objectStore(name);out[name]={};const k=s.getAllKeys(undefined,33),v=s.getAll(undefined,33);k.onsuccess=()=>out[name].keys=k.result;v.onsuccess=()=>out[name].values=v.result;}tx.oncomplete=()=>resolve(out);tx.onerror=()=>reject(tx.error);});
   const stores=[];for(const name of names){const {keys,values:rows}=values[name];if(keys.length>32)throw Error('Read-only row count');const normalized=await simplify(rows);stores.push({name,count:keys.length,keys,sha256:await hash(new TextEncoder().encode(JSON.stringify(normalized))),originals:normalized.filter(v=>v&&v.sha256&&v.blobBytes!==undefined)});}databases.push({name:entry.name,version:entry.version,stores});
  }finally{db.close();}
 }
 const storage=Object.fromEntries(Object.entries(localStorage));return{url:location.href,timeOrigin:performance.timeOrigin,viewport:[innerWidth,innerHeight],visibility:document.visibilityState,hasFocus:document.hasFocus(),body:document.body.innerText,storage,databases,readBlobBytes:blobBytes};
})()
