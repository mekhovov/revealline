import fs from 'node:fs';import path from 'node:path';import readline from 'node:readline';
import {R,P,config,launch,call,attach,evaluate,foreground,events,close,allowedUrl,ws} from './cdp.mjs';
let {sessionId:sid,target}=await attach({initial:false});
const eventFile=fs.openSync(path.join(R,'events-reconnected.jsonl'),'wx');let eventBytes=0,logClosed=false;
const log=v=>{if(logClosed)return;const s=JSON.stringify({at:new Date().toISOString(),...v})+'\n';eventBytes+=Buffer.byteLength(s);if(eventBytes>1048576)throw Error('One MiB event bound');fs.writeSync(eventFile,s);};
events.push(m=>{
 if(m.method==='Runtime.consoleAPICalled'&&m.sessionId===sid){for(const a of m.params.args||[])if(typeof a.value==='string'&&a.value.startsWith('P01_HISTORY '))log({method:'DOM.event',measurement:JSON.parse(a.value.slice(12))});}
 else if(m.method?.startsWith('DOMStorage.domStorage')){const p={...m.params};for(const k of ['oldValue','newValue'])if(typeof p[k]==='string')p[k]=p[k].length;log({method:m.method,params:p});}
 else if(m.method?.startsWith('Browser.download'))log(m);
 else if(['Page.backForwardCacheNotUsed','Runtime.exceptionThrown','Network.loadingFailed','Inspector.detached','Target.detachedFromTarget'].includes(m.method))log(m);
});
await call('Page.enable',{},sid);await call('Runtime.enable',{},sid);await call('DOMStorage.enable',{},sid);await call('Network.enable',{},sid);
const observe=`(()=>{const record=e=>console.info('P01_HISTORY '+JSON.stringify({type:e.type,persisted:e.persisted,url:location.href,timeOrigin:performance.timeOrigin,at:performance.now(),isTrusted:e.isTrusted,visibility:document.visibilityState,focus:document.hasFocus(),active:document.activeElement?.id}));for(const n of ['pagehide','pageshow','error','unhandledrejection'])window.addEventListener(n,record);document.addEventListener('visibilitychange',record);})();`;
await call('Page.addScriptToEvaluateOnNewDocument',{source:observe},sid);
await call('Emulation.setDeviceMetricsOverride',{width:1280,height:800,deviceScaleFactor:1,mobile:false},sid);
// Initial driver already navigated before closed stdin; same exact owned target.
log({ready:true,pid:process.pid,target,sessionId:sid});console.log(JSON.stringify({ready:true,pid:process.pid,target:target.targetId}));
let number=fs.readdirSync(R).filter(n=>/^action-\d+\.json$/.test(n)).length,done=false;ws.addEventListener('close',e=>log({socketClosed:true,code:e.code,reason:e.reason,clean:e.wasClean}));ws.addEventListener('error',e=>log({socketError:String(e.message||e)}));const heartbeat=setInterval(()=>{log({heartbeat:true,socketState:ws.readyState});call('Browser.getVersion').then(v=>log({alive:true,product:v.product})).catch(e=>log({aliveError:String(e)}));},3000);
function finish(){if(done)return;done=true;clearInterval(heartbeat);log({closed:true});logClosed=true;fs.closeSync(eventFile);close();}
process.on('SIGTERM',()=>{finish();process.exit(0)});process.on('SIGINT',()=>{finish();process.exit(0)});
fs.mkdirSync(path.join(R,'downloads'),{recursive:true});await call('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:path.join(R,'downloads'),eventsEnabled:true});
const lines=readline.createInterface({input:process.stdin});
for await(const line of lines){let receipt={at:new Date().toISOString(),pid:launch.pid,profile:launch.profile,targetId:target.targetId};
 try{const command=JSON.parse(line),{action,arg,hold=0}=command;receipt.command=command;
  if(action==='close'){await call('Browser.close');receipt.ok=true;}
  else{
   const targets=(await call('Target.getTargets')).targetInfos;receipt.targets=targets;
   if(targets.some(t=>t.type==='page'&&t.targetId!==target.targetId))throw Error('Unidentified extra page; stop and preserve');
   const current=targets.find(t=>t.targetId===target.targetId);if(!current||!allowedUrl(current.url))throw Error('Owned target route changed');
   await call('Page.bringToFront',{},sid);receipt.before=await foreground(sid);
   if(action==='read')receipt.result=await evaluate(arg,sid);
   else if(action==='storage')receipt.result=await evaluate(fs.readFileSync(path.join(P,'read-storage.js'),'utf8'),sid);
   else if(action==='shot'){
    if(!/^[a-z0-9-]+$/.test(arg)||fs.readdirSync(R).filter(n=>n.endsWith('.png')).length>=config.limits.maxScreenshots)throw Error('Screenshot cap');
    const r=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false},sid);const file=path.join(R,arg+'.png');fs.writeFileSync(file,Buffer.from(r.data,'base64'),{flag:'wx'});receipt.output=file;
   }else if(action==='click'||action==='upload'||action==='wheel'){
    if(arg.includes('transfer-copy'))throw Error('Known failed Copy is excluded');
    const r=await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(arg)});if(!e)return null;const r=e.getBoundingClientRect(),x=Math.max(1,Math.min(innerWidth-1,r.x+r.width/2)),y=Math.max(1,Math.min(innerHeight-1,r.y+r.height/2)),h=document.elementFromPoint(x,y);return {disabled:e.disabled,rect:r.toJSON(),text:e.innerText,x,y,hit:h===e||e.contains(h),intersects:r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight,visible:r.width>0&&r.height>0&&r.top>=0&&r.bottom<=innerHeight}})()`,sid);receipt.element=r;
    if(!r||r.disabled||!r.hit||!(action==='wheel'?r.intersects:r.visible))throw Error('Actual visible enabled target refused');
    if(action==='click'){for(const type of ['mouseMoved','mousePressed','mouseReleased'])await call('Input.dispatchMouseEvent',{type,x:r.x,y:r.y,...(type==='mouseMoved'?{}:{button:'left',clickCount:1})},sid);}
    else if(action==='wheel'){const deltaY=Number(command.delta);if(!Number.isFinite(deltaY)||Math.abs(deltaY)>1200)throw Error('Wheel bound');await call('Input.dispatchMouseEvent',{type:'mouseWheel',x:r.x,y:r.y,deltaX:0,deltaY},sid);}
    else {const fixture=config.fixtures.find(f=>f.path===command.file);if(!fixture)throw Error('Unapproved fixture');const file=path.resolve(config.sourceRoot,fixture.path),bytes=fs.readFileSync(file);const {createHash}=await import('node:crypto');if(bytes.length!==fixture.bytes||createHash('sha256').update(bytes).digest('hex')!==fixture.sha256)throw Error('Fixture changed');const {root}=await call('DOM.getDocument',{},sid),{nodeId}=await call('DOM.querySelector',{nodeId:root.nodeId,selector:arg},sid);const type=await evaluate(`document.querySelector(${JSON.stringify(arg)})?.type`,sid);if(type!=='file'||!nodeId)throw Error('Actual file input required');await call('DOM.setFileInputFiles',{nodeId,files:[file]},sid);receipt.fixture=fixture;}
   }else if(action==='key'){
    const keys={Escape:27,Tab:9,Enter:13,ArrowDown:40,ArrowUp:38,ArrowLeft:37,ArrowRight:39,Home:36,End:35,PageDown:34,PageUp:33};if(!keys[arg]||hold<0||hold>350)throw Error('Key bound');const key={key:arg,code:arg,windowsVirtualKeyCode:keys[arg]};await call('Input.dispatchKeyEvent',{type:'keyDown',...key},sid);if(hold)await new Promise(r=>setTimeout(r,hold));await call('Input.dispatchKeyEvent',{type:'keyUp',...key},sid);
   }else if(action==='type') {
    if(!/^[a-zA-Z0-9 .-]{1,30}$/.test(arg))throw Error('Native text bound');const focused=await evaluate('({tag:document.activeElement.tagName,type:document.activeElement.type})',sid);if(!['INPUT','SELECT'].includes(focused.tag))throw Error('Focused native input/select required');for(const char of arg){const key={key:char,code:/[a-z]/i.test(char)?'Key'+char.toUpperCase():'Digit'+char,windowsVirtualKeyCode:char.toUpperCase().charCodeAt(0),text:char,unmodifiedText:char};await call('Input.dispatchKeyEvent',{type:'keyDown',...key},sid);await call('Input.dispatchKeyEvent',{type:'keyUp',...key},sid);}
   }else if(action==='viewport'){const [width,height]=arg.split('x').map(Number);if(![[1280,800],[390,844],[844,390]].some(v=>v[0]===width&&v[1]===height))throw Error('Viewport bound');await call('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false},sid);
   }else if(action==='advance-current'){throw Error('Historical navigation is excluded');

    if(current.url!==config.initialUrl||fs.existsSync(path.join(R,'historical-page-closed.json')))throw Error('Old page close order');
    const oldTarget=target.targetId,newTarget=await call('Target.createTarget',{url:'about:blank'});const ended=await call('Target.closeTarget',{targetId:oldTarget});if(!ended.success)throw Error('Historical page failed to close');const next=(await call('Target.getTargets')).targetInfos;if(next.some(t=>t.targetId===oldTarget))throw Error('Historical target remains');target=next.find(t=>t.targetId===newTarget.targetId&&t.url==='about:blank');if(!target)throw Error('New blank target missing');sid=(await call('Target.attachToTarget',{targetId:target.targetId,flatten:true})).sessionId;fs.writeFileSync(path.join(R,'historical-page-closed.json'),JSON.stringify({at:new Date().toISOString(),oldTarget,newTarget:target.targetId,closedBeforeNewNavigation:true},null,2)+'\n',{flag:'wx'});for(const domain of ['Page','Runtime','DOMStorage','Network'])await call(domain+'.enable',{},sid);await call('Page.addScriptToEvaluateOnNewDocument',{source:observe},sid);await call('Emulation.setDeviceMetricsOverride',{width:1280,height:800,deviceScaleFactor:1,mobile:false},sid);await call('Page.bringToFront',{},sid);await call('Page.navigate',{url:config.currentUrl},sid);receipt.newTarget=target.targetId;
   }else if(action==='navigate-current'){if(!config.allowedUrls.includes(arg)||arg===config.initialUrl)throw Error('Direct current recovery route only');await call('Page.navigate',{url:arg},sid);
   }else if(action==='back'){
    const h=await call('Page.getNavigationHistory',{},sid),entry=h.entries[h.currentIndex-1];receipt.history=h;if(!entry||!allowedUrl(entry.url))throw Error('Invalid history return');await call('Page.navigateToHistoryEntry',{entryId:entry.id},sid);
   }else throw Error('Unknown action');
   receipt.after=await foreground(sid);receipt.ok=true;
  }
 }catch(e){receipt.ok=false;receipt.error=String(e.stack);}
 const filename=`action-${String(++number).padStart(3,'0')}.json`;fs.writeFileSync(path.join(R,filename),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({receipt:filename,ok:receipt.ok,...(receipt.result?{result:receipt.result}:{}),...(receipt.error?{error:receipt.error}:{})}));
 if(receipt.command?.action==='close'||(!receipt.ok&&!receipt.error?.includes('Actual visible enabled target refused'))){finish();break;}
}
finish();
