from pathlib import Path
import datetime,hashlib,json,socket,subprocess,zipfile
P=Path(__file__).resolve().parent;ROOT=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode')
def read(p):return json.loads(p.read_text())
def pin(p,base=P):
 b=p.read_bytes();return {'path':str(p.relative_to(base)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,obj):
 with p.open('x') as f:f.write(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
for row in read(P/'input-pins.json')['source']:assert pin(ROOT/row['path'],ROOT)==row
for row in read(P/'tool-pins.json')['files']:assert pin(P/row['path'])==row
ps=subprocess.run(['ps','-p','80169,80595,80969,81426','-o','pid=,command='],capture_output=True,text=True);assert not ps.stdout.strip()
s=socket.socket();s.settimeout(1);rc=s.connect_ex(('127.0.0.1',64560));s.close();assert rc==61
r={n:read(P/f'run/action-{n:03}.json')['result'] for n in [2,6,11,13,27,30,39,43,45,46,51,56,58,64,66]}
assert r[2]['build']['sourceRevision']=='cc9f8ffcc3be246f53ca0df7f068476d8401d040'
assert r[2]['build']['version']=='v0.57.2'
assert r[13]['video'][0]['paused'] is False and r[13]['video'][0]['time']>0 and r[13]['video'][0]['ready']==4
assert r[30]=={'open':False,'settings':True,'focus':'profile-recovery-open'}
key='revealline.library.release-v0.57.2.v1';lk='revealline.suspended.release-v0.42.0.v1'
a,b,c=[json.loads(r[n]['storage'][key]) for n in [39,43,46]]
assert a['library']==b['library']==c['library']
assert len({a['generation'],b['generation'],c['generation']})==3
assert {k:v for k,v in r[39]['storage'].items() if k!=key}=={k:v for k,v in r[46]['storage'].items() if k!=key}
assert r[39]['databases']==r[43]['databases']==r[46]['databases']==r[66]['databases']
assert r[46]['storage']==r[66]['storage']
assert r[39]['storage'][lk]==read(P.parent/'run/action-069.json')['result']['storage'][lk]
files=list((P/'run/downloads').iterdir());assert len(files)==1
png=pin(files[0]);assert png['bytes']==442522 and png['sha256']=='7f851f9806a1be994b2279f3d1acc4f2f39884ac6cf2fdf6b8a7813e61c73745'
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
closure={'at':now,'pidsAbsent':[80169,80595,80969,81426],'psExitCode':ps.returncode,'port':64560,'connectErrno':rc,'launcherExit':read(P/'run/exit.json'),'observerClosed':json.loads((P/'run/events-reconnected.jsonl').read_text().splitlines()[-1]).get('closed') is True,'initialInputPinsUnchanged':True,'initialToolPinsUnchanged':True,'profileRetained':True,'historicalPageReopened':False}
assert closure['observerClosed'];write(P/'run/closure.json',closure)
review={'at':now,'status':'COMPLETE_WITH_STALE_VERIFICATION_COPY_FINDING','phaseAccepted':False,'scope':'Independent remaining hosts on immutable public v0.57.2 after stopped Copy failure; known failed Copy never retried. No upcoming source or whole-phase acceptance.','identity':r[2]['build'],'url':r[2]['url'],'viewport':[1280,800],'input':'Native scoped CDP mouse/key/actual file inputs in same retained isolated profile; no state or fixture injection.','passed':[{'case':'Earned thumbnail and gallery reopen after browser restart','evidence':['run/action-006.json','run/01-earned-thumbnail-after-reload.png'],'observed':'Ready gallery canvas depicts authenticated Dawn original;1picture/8160score/gold metadata retained.'},{'case':'Retained earned story playback','evidence':['run/action-011.json','run/action-013.json','run/02-earned-story-playing.png'],'observed':r[13],'limit':'No audibility or physical-device claim; actual master mute retained.'},{'case':'Settings Find/Review of closed v0.42 channel and Back','evidence':['run/action-025.json','run/action-027.json','run/action-030.json','run/03-settings-recovery-closed-v042.png'],'observed':r[27],'focusReturn':r[30]},{'case':'Authentic backup reimport and normal Undo','evidence':['run/action-039.json','run/action-041.json','run/action-042.json','run/action-043.json','run/action-044.json','run/action-045.json','run/action-046.json','run/04-game-backup-undo.png'],'observed':r[45],'generations':[a['generation'],b['generation'],c['generation']],'logicalLibraryEqualBeforeImportAndAfterUndo':True,'otherRawStorageAndAllDbDigestsEqual':True,'limit':'Reimported authentic backup has same logical content as current target; proves native commit/Undo transitions and preservation, not a differing-content rollback or successful earlier-release Copy.'},{'case':'Direct recovery selected original review/verify/download','evidence':['run/action-049.json','run/action-051.json','run/action-056.json','run/action-058.json','run/action-064.json','run/action-065.json','run/action-066.json'],'selectedOriginal':r[56]['summary'],'verifiedStatus':r[58]['status'],'download':png,'readOnlyEndpointsEqual':True,'limit':'Read-only endpoint snapshots and recorded localStorage events; not full IndexedDB write tracing. Shared original availability is not proof that v0.42 earned it.'}],'finding':{'kind':'STALE_VERIFICATION_SUMMARY','evidence':['run/action-058.json','run/action-064.json','run/05-direct-original-verified.png'],'message':'After successful Verify, main status says verified but option/summary still say available unverified / Bytes are available but have not been verified. Prepared download succeeds and its bytes independently match original.','source':'game/ui/profile-recovery.mjs: drawOriginal uses inventory availability, while Verify only assigns separate verified result and status.','recommendedCorrection':'Reflect the current verified result in current selected-original label/summary; clear it on reselection/new review/cancel according to existing owner semantics. Do not mutate stored descriptors or broaden recovery.'},'retainedRefusals':[{'file':'stdin-continuation.json','scope':'First non-PTY driver observed startup then closed with stdin before input; same target resumed.'},{'file':'identity-probe-refusal.json','action':1,'scope':'Read-only wrong relative build-info probe returned HTML404; correct ./build-info.json succeeded before game input.'},{'action':35,'scope':'Guessed nonexistent Library tab id refused before input; actual observed data-library-panel button used.'},{'action':60,'scope':'Original preparation button below viewport refused before pointer input; native End exposed it normally.'}],'notClaimed':['Earlier-release Copy success/Copy Undo (required public defect remains).','Native input cancel timing, delayed recovery cancellation, physical devices, touch/controller-only use or responsive matrix.','Any current upcoming source correction, full P01 or complete recovery/migration acceptance.'],'closure':pin(P/'run/closure.json'),'priorFailure':pin(P.parent/'review.json',P.parent)}
write(P/'review.json',review)
paths=sorted([p for p in P.iterdir() if p.is_file() and p.name not in ['evidence-manifest.json','evidence.zip','evidence-record.json']]+[p for p in (P/'run').rglob('*') if p.is_file()])
rows=[pin(p) for p in paths];assert sum(r['bytes'] for r in rows)<10*1024*1024
manifest={'at':now,'files':rows,'fileCount':len(rows),'bytes':sum(r['bytes'] for r in rows),'excluded':['Retained prior profile outside this directory','Prior failed Copy originals (separate immutable archive)']};write(P/'evidence-manifest.json',manifest)
with zipfile.ZipFile(P/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in rows+[pin(P/'evidence-manifest.json')]:
  info=zipfile.ZipInfo(row['path'],(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,(P/row['path']).read_bytes())
with zipfile.ZipFile(P/'evidence.zip') as z:
 assert len(z.namelist())==len(rows)+1 and z.testzip() is None
 for row in rows+[pin(P/'evidence-manifest.json')]:
  b=z.read(row['path']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];assert b==(P/row['path']).read_bytes()
record={'at':now,'review':pin(P/'review.json'),'manifest':pin(P/'evidence-manifest.json'),'archive':pin(P/'evidence.zip'),'sourceFileCount':len(rows),'sourceBytes':manifest['bytes'],'members':len(rows)+1,'allRehashed':True,'status':review['status'],'phaseAccepted':False};write(P/'evidence-record.json',record);print(json.dumps(record,indent=2))
