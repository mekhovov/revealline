from pathlib import Path
import json,hashlib,datetime,subprocess,socket
R=Path(__file__).resolve().parent;P=R.parent;S=Path(json.loads((P/'config.json').read_text())['sourceRoot'])
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(name,j):
 with (R/name).open('x') as f:json.dump(j,f,indent=2);f.write('\n')
def read(n):return json.loads((R/n).read_text())
now=datetime.datetime.now(datetime.timezone.utc).isoformat();pids=[20522,20005,20969,21950,26081,34262,37560,40488]
proc=subprocess.run(['ps','-p',','.join(map(str,pids)),'-o','pid=,command='],text=True,capture_output=True);assert not proc.stdout.strip()
ports={}
for port in [54882,54887]:
 with socket.socket() as s:s.settimeout(.2);ports[str(port)]=s.connect_ex(('127.0.0.1',port))!=0
assert all(ports.values())
put('closure.json',{'at':now,'ownedPids':pids,'allOwnedPidsAbsent':True,'portsClosed':ports,'browserClose':pin(R/'browser-close.json'),'browserExit':read('exit.json'),'serverExit':read('server-exit.json'),'otherBrowsersUntouched':True,'profilePreservedExcluded':True})
inputs=json.loads((P/'input-pins.json').read_text());rows=[]
for x in inputs['source']+inputs['fixtures']:
 q=pin(S/x['path']);assert q['bytes']==x['bytes'] and q['sha256']==x['sha256'],x['path'];rows.append(q)
put('source-closure.json',{'at':now,'sourceAndFixturePinsUnchanged':True,'files':rows,'preparation':pin(P/'manifest.json'),'authorization':pin(P/'root-authorization.json')})
events=[json.loads(l) for l in (R/'events.jsonl').read_text().splitlines()];cancel=[e for e in events if e.get('measurement',{}).get('type')=='cancel'];put('cancel-observations.json',cancel)
caps=[json.loads(l) for l in (R/'capacity.jsonl').read_text().splitlines()]
review={'at':now,'scope':'Working DEV source only. No release/public/physical-device qualification.','status':'PARTIAL_REQUIRED_REPLAY_LAYOUT_FAILURE','sourceUnchanged':True,'cases':[
{'host':'Still Media','status':'PASS','viewport':[390,844],'proof':['action-011.json','action-015.json','action-018.json','01-still-retained.png','02-still-corrected-escape-focus.png'],'result':'Trusted same-file cancel retains reviewed bundle/file/status/Restore/focus. Genuine Escape returns exact enabled visible44px Open invoker with :focus and hit-test true. No restore committed.'},
{'host':'More Worlds','status':'PASS','viewport':[390,844],'proof':['action-036.json','action-038.json','action-041.json','03-worlds-retained.png'],'result':'Trusted same-file cancel retains one selected gameplay file, open disclosure, status and focus; empty localStorage unchanged. No install attempted. Escape returns focused Home Deploy.'},
{'host':'Library','status':'INCONCLUSIVE_CHILD_CANCEL_ESCAPE_PASS','viewport':[390,844],'proof':['action-050.json','action-051.json','action-052.json','action-055.json','04-library-empty-selection.png'],'result':'One visible native empty selection emitted no input cancel. Unchanged dialog/empty selection/localStorage observed; genuine Escape closes and focuses Settings Saves. No synthetic event or arbitrary file fallback.'},
{'host':'Enemy Catalog','status':'SAME_FILE_PASS_AUTO_ENTRY_FOCUS_LIMIT','viewport':[844,390],'proof':['action-067.json','action-069.json','action-072.json','action-076.json','05-enemy-retained-landscape.png','06-enemy-auto-open-escape-body.png'],'result':'Actual811B catalog native export/import draft, trusted same-file cancel keeps file/fields/status/empty localStorage. Initial automatic-open Escape closes to BODY. Normal visible Open then Escape returns exact focused hit-testable44px opener. No Apply.'},
{'host':'Replay export','status':'FAIL_INITIAL_STATUS_VISIBILITY_NATIVE_DOWNLOAD_AND_RETURN_PASS_LARGE_INCONCLUSIVE','viewport':[844,390],'textSize':'standard','proof':['action-098.json','action-103.json','action-106.json','action-107.json','action-112.json','08-replay-landscape-button.png','09-replay-landscape-terminal-before-scroll.png','10-replay-terminal-after-native-scroll.png','11-replay-settled-return.png','download-review.json'],'result':'Real133tick1.108s safe-input flight, Pause→Main menu→Workshop original export yields4042B native download with verified exact checkpoint. Terminal status y435.046875..455.34375 lies below initial390px viewport at scrollTop0; bottom Download/Close starts394.046875. TopClose44px remains visible/focused. Escape returns exact enabled Export with center hit true. No painted-busy claim.'}],
'largeSelection':{'status':'INCONCLUSIVE_DRIVER_SELECTION','proof':['action-057.json','action-085.json','action-086.json','07-native-selection-remained-standard.png'],'result':'Both native End/Enter and separately authorized ArrowDown/Enter leave actual select/body Standard immediately and settled. No DOM value setter or injected change. No Large qualification or inferred product defect.'},
'limits':['Library native input cancel not emitted.','Enemy automatic entry had no clicked invoker and Escape leaves BODY; normal Open path passes.','Replay terminal visibility is a required correction; Download and Close remain native-scroll reachable.','No painted busy frame, pending durable-download cancellation, physical picker/controller, release or public claim.'],
'refusedActions':[{'file':f.name,'error':read(f.name).get('error')} for f in sorted(R.glob('action-*.json')) if not read(f.name).get('ok')],
'observerLimits':{'knownSameTargetReattachments':[20969,21950,26081,34262,37560,40488],'note':'Explicit same-owned-target reattachments after route changes; last game observer stopped receiving after featured preparation and was replaced before flight/export. Initial observer files retained. Generic DOM error events retained without attribution; no thrown runtime exception was observed by the subscribed observer.','runtimeExceptionCount':sum(e.get('method')=='Runtime.exceptionThrown' for e in events),'domErrorEvents':[e for e in events if e.get('measurement',{}).get('type') in ['error','unhandledrejection']]},
'downloadIntegrity':pin(R/'download-review.json'),'saveBytesCaveat':'First post-run verifier incorrectly expected raw saved bytes unchanged across export. Actual difference is only savedAt, refreshed by existing pause/export; run, replay, pins and every other field match. Original failed helper/log preserved; exact checkpoint/data assertions pass. No runtime changed.',
'resource':{'minimumProjectedReserveBytes':min(c['projectedReserveBytes'] for c in caps),'maximumAllocatedBytes':max(c['actualAllocatedBytes'] for c in caps),'last':caps[-1],'stoppedForResource':False},'closed':True}
put('review.json',review)
# Copy only the exact controlling preparation originals and root GO; profiles/cache excluded.
control=R/'controlling';control.mkdir()
for name in ['config.json','input-pins.json','manifest.json','root-authorization.json','PLAN.md','COMMANDS.md','capacity.py','serve-owned.py','launch-owned-chrome.py','cdp.mjs','native.mjs','observe.mjs']:(control/name).write_bytes((P/name).read_bytes())
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.is_relative_to(R/'profile') or p.name=='evidence-manifest.json':continue
 row=pin(p);row['path']=p.relative_to(R).as_posix();files.append(row)
put('evidence-manifest.json',{'at':now,'scope':review['scope'],'status':review['status'],'fileCount':len(files),'bytes':sum(x['bytes'] for x in files),'files':files,'excluded':['profile/ (preserved)','all unrelated sessions','runtime/build/media copies']})
print(json.dumps({'manifest':pin(R/'evidence-manifest.json'),'files':len(files),'bytes':sum(x['bytes'] for x in files),'review':pin(R/'review.json'),'closure':pin(R/'closure.json'),'downloads':read('download-review.json')['replay']['sha256']},indent=2))
