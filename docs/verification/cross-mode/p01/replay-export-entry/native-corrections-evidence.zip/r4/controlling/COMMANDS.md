# Commands after actual receipt binding and root GO only

No `run/`, root-authorization.json, endpoint, target or passing native report is created by this preparation. Root must fill a separate actual authorization from the template, review its four receipt pins and prep-manifest pin, and issue GO. Do not edit the original template into a fictional successful record.

Set cwd to this exact preparation folder. After GO create only fresh `run/`; rehash the source/fixture pins. Each following service is a separate retained tool session, with output inspected before proceeding:

```sh
python3 capacity.py before-server
python3 serve-owned.py
python3 launch-owned-chrome.py --go
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs init
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node observe.mjs
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs read '({url:location.href,viewport:[innerWidth,innerHeight],channel:document.querySelector("#version")?.textContent,visibility:document.visibilityState,focus:document.hasFocus()})'
```

Only after actual visible, enabled target measurement:

```sh
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs upload '#still-media-bundle-file' /Users/oleksandr.mekhovov/work/my_projects/go_test_p01_file_cancel/authoring/still-media/examples/dawn-signal/Dawn-Signal-originals.rlmedia
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs upload '#save-file' EMPTY
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs select-large '#text-size'
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs viewport 844x390
```

These are separate case commands, not a script to execute sequentially without navigation/state review. Scope Still links to Workshop to avoid the hidden footer duplicate. The observer is persistent; inspect/reap its exact PID before reattaching after a cross-document navigation. Do not copy any predecessor endpoint, target or profile. All input payloads omit nativeVirtualKeyCode. Native Large must actually confirm; Library missing native cancel can remain inconclusive. After completion/stop verify owned processes and listeners closed, rehash working source, verify actual downloads, and select originals excluding profile/cache. No resource waiver or automatic relaunch.

Stop policy is now explicit in config.json/PLAN.md: record isolated UX/focus failure and continue independent authorized cases; resource/deadline/ownership/security/data failures still close the run immediately. No helper action may bypass its visible/foreground guard.
