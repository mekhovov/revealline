from pathlib import Path
import json,subprocess,time,datetime,signal
from capacity import check
P=Path(__file__).resolve().parent;R=P/'run';C=json.loads((P/'config.json').read_text());check('before-server')
assert not (R/'server.json').exists()
f=(R/'server.log').open('x');proc=subprocess.Popen(C['serverCommand'],cwd=C['sourceRoot'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
def stop(*_):
 if proc.poll() is None:proc.terminate()
for s in [signal.SIGINT,signal.SIGTERM]:signal.signal(s,stop)
try:
 for line in proc.stdout:
  f.write(line);f.flush()
  if line.startswith('http://127.0.0.1:'):
   url=line.strip().rstrip('/');rec={'pid':proc.pid,'url':url,'root':C['sourceRoot'],'command':C['serverCommand'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};(R/'server.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
 proc.wait()
finally:
 stop();proc.wait(timeout=10);f.close();(R/'server-exit.json').write_text(json.dumps({'pid':proc.pid,'exitCode':proc.returncode})+'\n')
