# R3 DEV correction sample — closed with focus finding

Still Media same-file cancellation passed at390×844. A native458062-byte Dawn-originals selection was reviewed to ready, then reselected once. The browser emitted trusted bubbling noncancelable cancel on the input; the dialog, exact file, generation1 review, enabled Restore, status and focus on Restore remained unchanged. Nothing was restored. Screenshot01 and actions014–017 retain this result.

Genuine Escape emitted its own dialog cancel and closed correctly, but settled focus was BODY, with matches(:focus)false. The enabled opener remained visible atx12,y335.59375,161.234375×44. Actions019–021 and screenshot02 retain this failure. Read-only source inspection identifies the host disabling its opener before async readBase, while panel.open captures the later activeElement. No fix was applied during this run.

The run stopped on that required focus finding. More Worlds, Library, Enemy cancellation and Large landscape replay were not run. All29source/fixture pins match; own Chrome/server/observers are reaped and both ports closed. Resources stayed within guard. No restart, source/frozen/public acceptance, physical-device or OS-picker claim. The file input's small horizontal overflow remains the separately scoped P05 measurement because its controls worked.
