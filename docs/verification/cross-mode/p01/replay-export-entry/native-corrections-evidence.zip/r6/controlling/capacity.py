from pathlib import Path
import os,json,shutil,time,datetime,stat,hashlib,re
P=Path(__file__).resolve().parent;R=P/'run';C=json.loads((P/'config.json').read_text());A=json.loads((P/'root-authorization.json').read_text())

def authority_path(value):
 path=Path(value)
 return path if path.is_absolute() else Path(C['authorityRoot'])/path

def pinned_json(pin):
 assert isinstance(pin,dict) and isinstance(pin.get('path'),str), 'Actual receipt pin is unresolved'
 assert isinstance(pin.get('bytes'),int) and 0<pin['bytes']<=1048576 and re.fullmatch('[0-9a-f]{64}',pin.get('sha256','')), 'Invalid bounded receipt pin'
 data=authority_path(pin['path']).read_bytes()
 assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'], 'Pinned receipt changed'
 return json.loads(data)

def retirement_authority():
 assert A.get('status')=='AUTHORIZED_BOUNDED_WORKING_SOURCE_NATIVE_RUN' and A.get('attempt')==6, 'Fresh attempt6 root GO required'
 assert A.get('sourceRoot')==C['sourceRoot'] and A.get('expectedChannel')=='dev' and A.get('publicOrFrozenQualification') is False, 'Working DEV scope mismatch'
 pinned_json(A['preparationManifest'])
 pins=A['verifiedRetirement'];spec=C['retiredArtifact']
 source=pinned_json(pins['sourceUpload']);dist=pinned_json(pins['distributionUpload']);review=pinned_json(pins['releaseAssetsReview']);retired=pinned_json(pins['retirementReceipt'])
 assert review.get('status')=='VERIFIED_RELEASE_ASSETS' and review.get('releaseId')==spec['releaseId'] and review.get('tag')==spec['tag'] and review.get('sourceCommit')==spec['sourceCommit'], 'Release assets not actually verified for this source'
 expected_names={'source.tar','distribution.zip','manifest.json','release.json','distribution.zip.sha256','source-qualification.json','source-qualification-evidence.zip','verification.json','qualification-evidence-record.json'}
 assets=review.get('assets');assert isinstance(assets,list) and len(assets)==9 and {x['name'] for x in assets}==expected_names, 'Nine actual asset rows required'
 assert len({x['id'] for x in assets})==9, 'Duplicate release asset IDs'
 for x in assets:
  assert isinstance(x['id'],int) and x['id']>0 and isinstance(x['bytes'],int) and x['bytes']>0 and re.fullmatch('[0-9a-f]{64}',x['sha256']) and x['serverDigest']=='sha256:'+x['sha256'], 'Unverified release digest'
 metadata=pinned_json(review['originalReleaseMetadata'])
 assert metadata.get('id')==spec['releaseId'] and metadata.get('tag_name')==spec['tag'], 'Original release API binding mismatch'
 original=metadata.get('assets');assert isinstance(original,list) and len(original)==9, 'Original release metadata must expose all nine assets'
 for x in assets:
  match=[v for v in original if v['id']==x['id'] and v['name']==x['name']];assert len(match)==1, 'Actual release asset missing'
  v=match[0];assert v['size']==x['bytes'] and v['digest']==x['serverDigest'] and v['state']=='uploaded', 'Original API digest/size/state differs'
 for upload,name in [(source,'source.tar'),(dist,'distribution.zip')]:
  assert upload.get('status')=='UPLOADED_VERIFIED' and upload.get('releaseId')==spec['releaseId'] and upload.get('tag')==spec['tag'] and upload.get('sourceCommit')==spec['sourceCommit'] and upload.get('tagCommit')==spec['sourceCommit'] and upload.get('outerSha256')==spec['sha256'], 'Original member upload identity differs'
  assert upload.get('readBackVerified') is True and upload.get('postCount')==1 and upload.get('assetName')==name, 'Upload is incomplete or not verified'
  x=next(v for v in assets if v['name']==name)
  assert upload['assetId']==x['id'] and upload['bytes']==x['bytes'] and upload['sha256']==x['sha256'] and upload['serverDigest']==x['serverDigest'], 'Upload differs from all-assets receipt'
 assert retired.get('status')=='RETIRED_VERIFIED_ARTIFACT' and retired.get('removed') is True and retired.get('remainingPart') is False, 'Artifact retirement has not actually completed'
 assert str(authority_path(retired['path']))==spec['path'] and retired.get('bytes')==spec['bytes'] and retired.get('sha256')==spec['sha256'] and retired.get('releaseId')==spec['releaseId'] and retired.get('sourceCommit')==spec['sourceCommit'], 'Retired artifact identity mismatch'
 assert retired.get('assetVerification')==pins['releaseAssetsReview'], 'Retirement must bind the same verified all-assets receipt'
 assert not os.path.lexists(spec['path']) and not os.path.lexists(spec['partPath']), 'Retired artifact/partial path reappeared'
 return 0

def check(stage):
 remaining=retirement_authority()
 if stage in ('before-server','before-launch'):
  inputs=json.loads((P/'input-pins.json').read_text())
  for pin in inputs['source']+inputs['fixtures']:
   data=(Path(C['sourceRoot'])/pin['path']).read_bytes()
   assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'], 'Working source/fixture changed before launch'
 profile=evidence=downloads=allocated=0;count=0
 for p in R.rglob('*'):
  st=p.lstat()
  if not stat.S_ISREG(st.st_mode):continue
  allocated+=st.st_blocks*512
  if p.is_relative_to(R/'profile'):profile+=st.st_size
  elif p.is_relative_to(R/'downloads'):
   downloads+=st.st_size;count+=not p.name.endswith('.crdownload')
  else:evidence+=st.st_size
 limits=C['limits'];free=shutil.disk_usage(P).free
 allowance=max(0,limits['profileBytes']-profile)+max(0,limits['evidenceBytes']-evidence)+max(0,limits['downloadsBytes']-downloads)
 reserved=C['futureRootReservedBytes'];assert reserved==83886080;projected=free-remaining-allowance-reserved
 rec={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':stage,'freeBytes':free,'remainingRootArtifactBytes':remaining,'reservedRootBrowserBytes':reserved,'artifactRetirementVerified':True,'remainingBrowserAllowance':allowance,'projectedReserveBytes':projected,'profileLogicalBytes':profile,'evidenceLogicalBytes':evidence,'downloadBytes':downloads,'downloadFiles':count,'actualAllocatedBytes':allocated}
 with (R/'capacity.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 assert projected>=limits['minimumProjectedFreeBytes'],rec
 assert profile<=limits['profileBytes'] and evidence<=limits['evidenceBytes'] and downloads<=limits['downloadsBytes'] and count<=limits['downloadFiles'] and allocated<=limits['maximumActualNewDiskBytes'],rec
 if (R/'launch.json').exists():assert time.time()-json.loads((R/'launch.json').read_text())['startedAt']<=limits['browserSeconds'], 'Browser deadline'
 return rec
if __name__=='__main__':print(json.dumps(check(__import__('sys').argv[1] if len(__import__('sys').argv)>1 else 'explicit')))
