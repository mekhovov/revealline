# Prepared corrective browser tools — not launched

These tools supersede only the earlier PLAN's unimplemented tooling placeholders. The original PLAN, source-pins and identity template remain historical preparation against failed source69195ddd. Root reported its local production-history capacity failure; it cannot qualify or launch. `tools-identity-template.json` leaves replacement source/tree and all future release/build/public facts unset. **Do not use the historical identity template.** No run directory/profile exists, and no tool was executed beyond syntax parsing.

Before launch, root must review a new `verified-public-identity.json` derived from the new template, including the actual successful source qualification file/hash, actual inspected/published build+offline inventory, controller/deployment and public identity proof. `context.py` verifies these local originals and rejects69195 explicitly. Both Chrome and refusal proxy require `--root-go`; copied observers/actions require the resulting exact owned launch and unchanged identity pin. The phase/profile/session and512MiB projected reserve remain as PLAN. Future reserved bytes are a required launch argument, supplied from root's current pending transport/copy allocation.

Run from this preparation directory; use Node22 for `.mjs`. Commands below are future-only. All WebSocket, target IDs, indices, profile and scope values must come from the **current** receipts and observations, never examples or old sessions.

```sh
python3 tools/launch-owned-chrome.py --root-go --attempt online-1 --identity verified-public-identity.json --future-reserved-bytes "$P01_RESERVED_BYTES"
python3 tools/control.py connect "$P01_EXACT_BROWSER_WS"
node tools/foreground.mjs list
node tools/foreground.mjs bind "$P01_EXACT_BLANK_TARGET" about:blank blank
```

`foreground list` records all actual targets without picking one. `bind` requires the exact observed targetId+URL and an allowed role: blank, product, Explorer or refusal canary. It explicitly brings that page forward and checks visibility/focus. The registry is per attempt, so no stale targets cross whole-browser relaunches. An identified owned Chrome Help tab can be registered using its exact URL and an original target-list receipt:

```sh
node tools/foreground.mjs register-help "$P01_HELP_TARGET" "$P01_HELP_URL" run/online-1-targets-observed-ACTUAL.json
```

This accepts only an observed Help URL (`chrome://settings/help` or `chrome://help`) in the same owned browser/profile; it never activates Help. Unknown pages still stop input. A second ordinary product/Explorer target must be explicitly bound. If agent-browser's own selected tab differs, use the observed tab index once: `python3 tools/control.py tab "$P01_EXACT_TAB_INDEX"`. Its post-check must match the bound foreground page before any next native input. The wrapper performs a read-only driver URL/visibility/focus check too; Page.bringToFront alone is not proof that the CLI selected that page.

Start the checkpointed collector before public navigation, in a retained TTY tool session. Its endpoints, target, profile and scope must match the current launch and registered target. It passively records native requests/responses/failures, exceptions, worker attribution and bounded health. For the one exact bound Explorer CSS URL it captures the original native response body after loadingFinished, preserving bytes and checking expected size/SHA/status/CSS MIME; it issues no second fetch.

```sh
node tools/collect-checkpointed.mjs --endpoint "$P01_EXACT_BROWSER_WS" --target "$P01_EXACT_TARGET_ID" --profile "$P01_EXACT_PROFILE" --scope "$P01_EXACT_SCOPE" --output run/online-1-events.jsonl
python3 tools/checkpoint.py --events run/online-1-events.jsonl --target "$P01_EXACT_TARGET_ID" --out run/online-1-before-navigation-observer.json
python3 tools/control.py navigate "$P01_VERIFIED_GAME_URL" product
node tools/observe-operations.mjs correction-1
python3 tools/capture.py ready --kind solo
python3 tools/capture.py library-terminal --kind layout
python3 tools/capture.py applied --kind controller
python3 tools/capture.py preparing --kind offline
```

`navigate URL ROLE` validates a planned same-target URL before its ordinary open action, then explicitly rebinds the same target. Native clicks that open/navigate a target may stop the old route post-check; retain that attempt, list actual targets and bind the specific observed destination before continuing. No automatic first-target fallback occurs. A refused canary navigation can return an expected CLI failure and Chrome error document. Retain it, then bind that same observed target as `canary` with exact `chrome-error://chromewebdata/` URL and its matching native action log as a fourth argument. The guard checks the last action was that target's real refused-canary navigation. This is failure evidence, not a canary success assertion; matching proxy GET/CONNECT records remain required.

`observe-operations` copies the reviewed passive mutation/three-frame callback sampler. It requires an active foreground target and a fresh segment. It preserves immediate versus post-frame versus screenshot timestamps, native isTrusted input markers, stage/rail/cancel changes and body/selector geometry. Its12MiB cap is recorded; missing/late/capped observations remain limits. The sampler installs listeners only in its current document: after navigation/reload use a new explicit segment, never claim continuity through a lost observer. It configures native download output to this owned run's downloads folder; it does not change application APIs, cache or storage. `capture` refuses reused labels and copies original screenshot bytes. Measurement kinds are layout, Controller, offline, Solo and release-channel storage; the last two perform the previously reviewed read-only actual build-info fetch.

At each critical boundary, use a fresh checkpoint receipt and inspect final event gaps/caps/detach records. No healthy-boundary snapshot substitutes for whole-interval coverage. Stop extra trials according to PLAN. All CLI actions retain exact stdout/stderr, failures and pre-action identity in per-attempt logs.

For cold refusal, close the online browser and verify exit before starting the proxy/new process:

```sh
node tools/close-owned-browser.mjs run/online-1-launch.json run/online-1-close.json
python3 tools/verify-exit.py --attempt online-1
python3 tools/refusal_proxy.py --root-go --identity verified-public-identity.json --port 0 --events run/refusal-proxy.jsonl --ready run/refusal-proxy-ready.json
python3 tools/launch-owned-chrome.py --root-go --attempt refused-1 --identity verified-public-identity.json --future-reserved-bytes "$P01_RESERVED_BYTES" --proxy-ready run/refusal-proxy-ready.json
```

Repeat explicit connection/target binding and a new collector for refused-1. Keep the proxy alive until the refused browser is verified closed. Stop only its recorded owned process, then use restored-1 without proxy for the final online restoration. The same profile is retained, while each attempt requires a fresh browser PID/endpoint and exclusive launch/exit outputs. `Browser.close` is authoritative; `control close` only disconnects the named client. Cleanup remains possible if the identity file changes, but still verifies the exact owned profile/PID/endpoint. `verify-exit` records PID absence and closed CDP port; it never kills or reconnects.

No source/test/build/network/browser operation was performed during this preparation. Syntax results are in tools-syntax.json. The new actual-source binding, tool review and root GO remain prerequisites; later browser evidence must qualify the new frozen/public identity independently of this tooling preparation.
