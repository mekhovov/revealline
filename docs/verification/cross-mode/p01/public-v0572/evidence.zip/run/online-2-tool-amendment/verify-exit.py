#!/usr/bin/env python3
"""Record actual own process/port closure; never kill or reconnect."""
import argparse,json,os,socket,datetime
from pathlib import Path
from context import RUN,digest
p=argparse.ArgumentParser();p.add_argument('--attempt',required=True,choices=['online-1','refused-1','restored-1']);a=p.parse_args()
f=RUN/(a.attempt+'-launch.json');r=json.loads(f.read_text());assert r['rootGo'] is True and r['profile']==str(RUN/'profile')
try:os.kill(r['pid'],0);alive=True
except ProcessLookupError:alive=False
s=socket.socket();s.settimeout(.5);opened=s.connect_ex(('127.0.0.1',r['port']))==0;s.close()
value={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempt':a.attempt,'pid':r['pid'],'pidAlive':alive,'port':r['port'],'portOpen':opened,'passed':not alive and not opened,'launchSha256':digest(f)}
with (RUN/(a.attempt+'-exit-check.json')).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(value));raise SystemExit(0 if value['passed'] else 1)
