#!/usr/bin/env python3
"""Adapted direct Chrome launcher: explicit future public authority, one owned profile."""
import argparse,datetime,http.client,json,os,shutil,subprocess,time
from pathlib import Path
from urllib.parse import urlsplit
from context import P,RUN,identity,digest
p=argparse.ArgumentParser();p.add_argument('--root-go',action='store_true');p.add_argument('--attempt',required=True,choices=['online-1','refused-1','restored-1']);p.add_argument('--proxy-ready',type=Path);p.add_argument('--identity',required=True,type=Path);p.add_argument('--future-reserved-bytes',required=True,type=int);a=p.parse_args()
assert a.root_go and a.future_reserved_bytes>=0,'Explicit root GO and current capacity reservation required'
i=identity(a.identity);limit=i['inventoryBytes']+96*1024**2;assert limit<=256*1024**2,'Profile budget exceeds bounded plan'
assert (a.attempt=='refused-1')==bool(a.proxy_ready),'Only refused phase uses proxy'
RUN.mkdir(exist_ok=True);profile=RUN/'profile';receipt=RUN/(a.attempt+'-launch.json');ended=RUN/(a.attempt+'-exit.json')
assert not receipt.exists() and not ended.exists()
if a.attempt=='online-1':assert not profile.exists(),'Fresh online profile required'
else:
 previous='online-1' if a.attempt=='refused-1' else 'refused-1';old=json.loads((RUN/(previous+'-launch.json')).read_text());assert (RUN/(previous+'-exit.json')).is_file()
 try:os.kill(old['pid'],0)
 except ProcessLookupError:pass
 else:raise RuntimeError('Previous owned browser remains alive')
 assert profile.is_dir() and old['identitySha256']==digest(a.identity)
size=lambda:sum(x.stat().st_size for x in profile.rglob('*') if x.is_file()) if profile.exists() else 0
started=time.time();phase_limit={'online-1':1200,'refused-1':600,'restored-1':300}[a.attempt]
def capacity(stage):
 used=size();free=shutil.disk_usage(P).free;projected=free-a.future_reserved_bytes-max(0,limit-used)-32*1024**2
 row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':stage,'profileBytes':used,'profileLimit':limit,'freeBytes':free,'futureReservedBytes':a.future_reserved_bytes,'projectedReserveBytes':projected,'reserveBytes':512*1024**2}
 with (RUN/(a.attempt+'-capacity.jsonl')).open('a') as f:f.write(json.dumps(row)+'\n')
 assert used<=limit and projected>=512*1024**2,'Owned capacity bound reached'
 return row
capacity('before-launch')
args=['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--headless=new','--remote-debugging-port=0','--enable-automation','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-features=OptimizationGuideModelDownloading,OptimizationHintsFetching,OptimizationTargetPrediction,OptimizationHints','--disable-gpu-shader-disk-cache','--disable-default-apps','--disable-sync','--enable-unsafe-swiftshader','--password-store=basic','--use-mock-keychain','--disable-quic','--disable-extensions','--disk-cache-size=4194304','--media-cache-size=1048576','--window-size=390,844','--user-data-dir='+str(profile)]
if a.proxy_ready:
 proxyfile=a.proxy_ready.resolve();assert proxyfile.is_relative_to(RUN);proxy=json.loads(proxyfile.read_text());os.kill(proxy['pid'],0);url=urlsplit(proxy['proxy'])
 assert url.scheme=='http' and url.hostname=='127.0.0.1' and not url.username and url.port
 args+=['--proxy-server='+proxy['proxy'],'--proxy-bypass-list=<-loopback>']
else:args+=['--no-proxy-server']
args+=['about:blank'];proc=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 deadline=time.monotonic()+20;portfile=profile/'DevToolsActivePort'
 while True:
  if proc.poll() is not None:raise RuntimeError('Owned Chrome exited before endpoint receipt')
  if portfile.exists() and portfile.stat().st_mtime>=started:
   try:
    port=int(portfile.read_text().splitlines()[0]);c=http.client.HTTPConnection('127.0.0.1',port,timeout=1);c.request('GET','/json/version');version=json.loads(c.getresponse().read());c.close();break
   except (OSError,ValueError,IndexError):pass
  if time.monotonic()>deadline:raise RuntimeError('New owned Chrome endpoint not observed')
  time.sleep(.1)
 r={'attempt':a.attempt,'rootGo':True,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':proc.pid,'profile':str(profile),'arguments':args,'endpoint':version['webSocketDebuggerUrl'],'port':port,'version':version,'proxyMode':'refused' if a.proxy_ready else 'online','profileReset':False,'identityFile':str(a.identity.resolve()),'identitySha256':digest(a.identity),'sourceRevision':i['sourceRevision'],'sourceTree':i['sourceTree']}
 with receipt.open('x') as f:json.dump(r,f,indent=2);f.write('\n')
 (RUN/'active-launch.json').write_text(json.dumps({'file':receipt.name,'sha256':digest(receipt)},indent=2)+'\n');print(json.dumps(r),flush=True)
 while proc.poll() is None:
  assert time.time()-started<=phase_limit,'Owned phase duration cap reached'
  capacity('running');time.sleep(3)
 with ended.open('x') as f:json.dump({'attempt':a.attempt,'pid':proc.pid,'exitCode':proc.returncode,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},f,indent=2);f.write('\n')
except BaseException as error:
 with (RUN/(a.attempt+'-failure.json')).open('x') as f:json.dump({'type':type(error).__name__,'message':str(error),'pid':proc.pid},f,indent=2);f.write('\n')
 if proc.poll() is None:proc.terminate();proc.wait(timeout=10)
 raise
