/** Explicit target registry and foreground checks; never select first/all pages. */
import fs from 'node:fs';
import path from 'node:path';
import {currentLaunch,connect,registry,writeRegistry,active,R,sha} from './owned-context.mjs';
const [mode,...args]=process.argv.slice(2),launch=currentLaunch(),identity=JSON.parse(fs.readFileSync(launch.identityFile));
if(!['list','bind','register-help','bring','check'].includes(mode))throw Error('Explicit list/bind/register-help/bring/check required');
const {socket,call}=await connect(launch);
try{
 const targets=(await call('Target.getTargets')).targetInfos,r=registry(launch);
 if(mode==='list'){
  const file=path.join(R,launch.attempt+'-targets-observed-'+Date.now()+'.json');
  fs.writeFileSync(file,JSON.stringify({at:new Date().toISOString(),endpoint:launch.endpoint,profile:launch.profile,targets},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({file,targets}));
 }else{
  if(mode==='bind'||mode==='register-help'){
   const [targetId,url,roleOrEvidence]=args,t=targets.find(t=>t.type==='page'&&t.targetId===targetId&&t.url===url);
   if(!t)throw Error('Exact observed target/URL absent');
   const role=mode==='register-help'?'help':roleOrEvidence;
   let identifiedCanaryError=false;
   if(mode==='bind'&&role==='canary'&&url==='chrome-error://chromewebdata/'){
    const evidence=path.resolve(args[3]??'');if(!evidence.startsWith(R+path.sep))throw Error('Owned native canary attempt evidence required');
    const raw=fs.readFileSync(evidence),row=JSON.parse(raw.toString().trim().split('\n').at(-1));
    if(row.before?.owned?.targetId!==targetId||row.args?.[0]!=='navigate'||row.args?.[2]!=='canary'||!/^https?:\/\/p01-refusal\.invalid\//.test(row.args[1]))throw Error('Canary error must follow an exact retained native navigation');
    identifiedCanaryError=true;t.identification={path:evidence,bytes:raw.length,sha256:sha(raw),reason:'Native refused canary navigation reached Chrome error document; no success inferred'};
   }
   if(role==='help'){
    const f=path.resolve(roleOrEvidence);if(!f.startsWith(R+path.sep))throw Error('Owned original target evidence required');
    const b=fs.readFileSync(f),e=JSON.parse(b);
    if(e.endpoint!==launch.endpoint||e.profile!==launch.profile||!e.targets.some(x=>x.targetId===targetId&&x.url===url&&x.type==='page')||!/^chrome:\/\/(?:settings\/help|help)(?:[/?#]|$)/.test(url))throw Error('Help target requires exact owned observation and identified Chrome Help URL');
    t.identification={path:f,bytes:b.length,sha256:sha(b),reason:'Operator explicitly classified observed owned Chrome Help; no product input/claim'};
   }else if(!((role==='blank'&&url==='about:blank')||(role==='product'&&url.startsWith(identity.scope+'game/'))||(role==='explorer'&&/^https:\/\/mekhovov\.github\.io\/revealline\/releases\/(?:index\.html)?(?:[?#].*)?$/.test(url))||(role==='canary'&&(/^https?:\/\/p01-refusal\.invalid\//.test(url)||identifiedCanaryError))))throw Error('Route outside bounded plan');
   const row={targetId,url,role,...(t.identification?{identification:t.identification}:{})},index=r.targets.findIndex(x=>x.targetId===targetId);
   if(index<0)r.targets.push(row);else r.targets[index]=row;
   if(mode==='bind')r.activeTargetId=targetId;writeRegistry(launch,r);
   if(mode==='register-help'){console.log(JSON.stringify({registered:true,target:row}));socket.close();process.exit(0);}
  }
  const owned=active(launch),unknown=targets.filter(t=>t.type==='page'&&!r.targets.some(x=>x.targetId===t.targetId&&x.url===t.url));
  if(unknown.length){fs.appendFileSync(path.join(R,launch.attempt+'-foreground-checks.jsonl'),JSON.stringify({at:new Date().toISOString(),mode,owned,unknownPages:unknown})+'\n');throw Error('Unidentified owned page; classify from exact evidence before further input');}
  const target=targets.find(t=>t.type==='page'&&t.targetId===owned.targetId&&t.url===owned.url);if(!target)throw Error('Bound target changed/closed');
  const sid=(await call('Target.attachToTarget',{targetId:owned.targetId,flatten:true})).sessionId;
  if(mode==='bring'||mode==='bind')await call('Page.bringToFront',{},sid);
  const reply=await call('Runtime.evaluate',{expression:'({url:location.href,visibility:document.visibilityState,hasFocus:document.hasFocus(),active:{id:document.activeElement?.id,tag:document.activeElement?.tagName},at:Date.now()})',returnByValue:true},sid),state=reply.result?.value;
  fs.appendFileSync(path.join(R,launch.attempt+'-foreground-checks.jsonl'),JSON.stringify({at:new Date().toISOString(),mode,label:args[0]??mode,owned,state,targets,registered:r.targets})+'\n');
  const urlMatches=state?.url===owned.url||(owned.role==='canary'&&state?.url==='chrome-error://chromewebdata/');
  if(!urlMatches||state.visibility!=='visible'||state.hasFocus!==true)throw Error('Exact active page not foreground-visible; no automatic recovery');
  await call('Target.detachFromTarget',{sessionId:sid});console.log(JSON.stringify({passed:true,mode,owned,state}));
 }
}finally{socket.close();}
