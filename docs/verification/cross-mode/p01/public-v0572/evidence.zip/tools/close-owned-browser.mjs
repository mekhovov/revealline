/** Exact owned Browser.close; remains available for cleanup if identity file changes. */
import fs from 'node:fs';
import path from 'node:path';
import {currentLaunch,connect,ownOutput,R} from './owned-context.mjs';
const [file,out]=process.argv.slice(2),launch=currentLaunch({verifyIdentity:false});
if(path.resolve(file)!==path.join(R,launch.attempt+'-launch.json'))throw Error('Current owned attempt receipt required');
const selected=JSON.parse(fs.readFileSync(file));if(selected.pid!==launch.pid||selected.endpoint!==launch.endpoint||selected.profile!==launch.profile)throw Error('Launch differs');
const target=ownOutput(out),{socket,call,args}=await connect(launch);
fs.writeFileSync(target,JSON.stringify({time:new Date().toISOString(),pid:launch.pid,endpoint:launch.endpoint,profile:launch.profile,actualArguments:args,action:'Browser.close',profileReset:false},null,2)+'\n',{flag:'wx'});
try{await call('Browser.close');}catch(e){if(socket.readyState!==WebSocket.CLOSED)throw e;}finally{socket.close();}
