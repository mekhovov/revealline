import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {currentLaunch,connect,active,R} from './owned-context.mjs';
const [key,ms]=process.argv.slice(2), map={ArrowDown:40,ArrowUp:38,ArrowLeft:37,ArrowRight:39};
const duration=Number(ms);if(!map[key]||!Number.isFinite(duration)||duration<0||duration>2000)throw Error('Bounded arrow hold only');
const launch=currentLaunch();execFileSync(process.execPath,[new URL('foreground.mjs',import.meta.url).pathname,'check','native-hold']);
const owned=active(launch),{socket,call}=await connect(launch);let sid,down=false;
try{sid=(await call('Target.attachToTarget',{targetId:owned.targetId,flatten:true})).sessionId;const params={key,code:key,windowsVirtualKeyCode:map[key]};await call('Input.dispatchKeyEvent',{type:'rawKeyDown',...params},sid);down=true;await new Promise(r=>setTimeout(r,duration));await call('Input.dispatchKeyEvent',{type:'keyUp',...params},sid);down=false;fs.appendFileSync(path.join(R,launch.attempt+'-native-holds.jsonl'),JSON.stringify({at:new Date().toISOString(),owned,key,duration,kind:'CDP native keyboard input'})+'\n');await call('Target.detachFromTarget',{sessionId:sid});}finally{if(down)await call('Input.dispatchKeyEvent',{type:'keyUp',key,code:key,windowsVirtualKeyCode:map[key]},sid);socket.close();}
execFileSync(process.execPath,[new URL('foreground.mjs',import.meta.url).pathname,'check','after-native-hold']);
