#!/usr/bin/env python3
"""Guarded read-only measurements and original screenshot copy; no image editing."""
from pathlib import Path
import argparse,subprocess,json,re,hashlib,datetime
from context import RUN,launch
T=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--kind',choices=['layout','controller','offline','solo','storage'],default='layout');p.add_argument('--no-screenshot',action='store_true');a=p.parse_args()
assert re.fullmatch('[A-Za-z0-9_-]{1,80}',a.label);r=launch();stem=r['attempt']+'-'+a.label
for suffix in ['.json','.png']:assert not (RUN/(stem+suffix)).exists()
files={'layout':'measure.js','controller':'measure-controller.js','offline':'measure-offline.js','solo':'observe-solo.js','storage':'observe-channel-storage.js'}
v=subprocess.run(['python3',str(T/'control.py'),'eval',(T/files[a.kind]).read_text()],capture_output=True,text=True);assert v.returncode==0,(v.stdout,v.stderr)
value=json.loads(v.stdout)
with (RUN/(stem+'.json')).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
if not a.no_screenshot:
 s=subprocess.run(['python3',str(T/'control.py'),'screenshot'],capture_output=True,text=True);assert s.returncode==0,(s.stdout,s.stderr)
 match=re.search(r'(/Users/[^\n]+\.png)',s.stdout);assert match,s.stdout;source=Path(match[1]);assert '/.agent-browser/tmp/screenshots/' in str(source)
 raw=source.read_bytes()
 with (RUN/(stem+'.png')).open('xb') as f:f.write(raw)
 with (RUN/(r['attempt']+'-screenshot-origins.jsonl')).open('a') as f:f.write(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':stem,'original':str(source),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'measurementAndScreenshotAreSeparateSamples':True})+'\n')
print(json.dumps({'measurement':str(RUN/(stem+'.json')),'screenshot':None if a.no_screenshot else str(RUN/(stem+'.png'))}))
