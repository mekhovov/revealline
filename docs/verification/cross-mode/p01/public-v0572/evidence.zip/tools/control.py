#!/usr/bin/env python3
"""Native named-session input with CDP foreground and driver-page checks."""
import json,os,sys,subprocess,http.client,datetime,re
from pathlib import Path
from context import P,RUN,launch
T=Path(__file__).resolve().parent;node='/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node'
a=sys.argv[1:];assert a and not any(x in a for x in ['--all','--auto-connect','--fn','--session','--cdp','--config']),'Explicit bounded action required'
r=launch();c=http.client.HTTPConnection('127.0.0.1',r['port'],timeout=1);c.request('GET','/json/version');v=json.loads(c.getresponse().read());c.close();assert v['webSocketDebuggerUrl']==r['endpoint']
removed={'HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy'}
env={k:v for k,v in os.environ.items() if not k.startswith('AGENT_BROWSER_') and k not in removed}
cli=['/Users/oleksandr.mekhovov/.local/share/mise/installs/node/20.19.5/bin/agent-browser','--config',str(T/'agent-browser.json'),'--session','p01-public-v0572-correction']
def call(args):return subprocess.run(cli+args,env=env,capture_output=True,text=True)
def guard():return json.loads(subprocess.check_output([node,str(T/'foreground.mjs'),'check','native-action'],text=True))
def driver(owned):
 probe=call(['eval','({url:location.href,visibility:document.visibilityState,hasFocus:document.hasFocus()})'])
 assert probe.returncode==0,(probe.stdout,probe.stderr)
 value=json.loads(probe.stdout);url=value['url']==owned['url'] or (owned['role']=='canary' and value['url']=='chrome-error://chromewebdata/')
 assert url and value['visibility']=='visible' and value['hasFocus'] is True,'CLI page differs from explicitly foregrounded target'
 return value
if a[0]=='connect':
 assert a[1:]==[r['endpoint']];before=None
elif a[0]=='close':before=None
else:
 before=guard()
 if a[0]!='tab':driver(before['owned'])
 if a[0]=='tab':assert len(a)==2 and a[1].isdigit(),'Only explicit observed tab index allowed; no new/close/all tabs'
 if a[0]=='open':raise SystemExit('Use navigate EXACT_URL ROLE to bind an explicit same-target route transition')
original=list(a);navigate=a[0]=='navigate'
if navigate:
 assert len(a)==3;destination,role=a[1:];identity=json.loads(Path(r['identityFile']).read_text())
 allowed=(role=='product' and destination.startswith(identity['scope']+'game/')) or (role=='explorer' and re.fullmatch(r'https://mekhovov\.github\.io/revealline/releases/(?:index\.html)?(?:[?#].*)?',destination)) or (role=='canary' and re.match(r'https?://p01-refusal\.invalid/',destination))
 assert allowed,'Navigation outside bounded planned routes';a=['open',destination]
result=call(a)
with (RUN/(r['attempt']+'-actions.jsonl')).open('a') as f:f.write(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'args':original,'before':before,'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})+'\n')
print(result.stdout,end='');print(result.stderr,end='',file=sys.stderr)
if a[0] not in ['connect','close']:
 if navigate and result.returncode==0:subprocess.run([node,str(T/'foreground.mjs'),'bind',before['owned']['targetId'],destination,role],check=True,stdout=sys.stderr)
 after=guard();driver(after['owned'])
if a[0]!='close':launch()
raise SystemExit(result.returncode)
