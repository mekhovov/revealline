"""Local ownership/identity checks only; importing this module launches nothing."""
from pathlib import Path
import hashlib,json,re,os
P=Path(__file__).resolve().parent.parent
RUN=P/'run'
ROOT=P.parents[4]
FAILED_SOURCE='69195ddd1d21a7bc3f863cf7589069a735301a03'
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identity(path):
 path=Path(path).resolve();assert path==P/'verified-public-identity.json' and path.is_file() and not path.is_symlink()
 v=json.loads(path.read_text())
 assert v.get('authorizedPublicRun') is True and v.get('sourceQualificationPassed') is True and v.get('version')=='v0.57.2'
 for k in ['sourceRevision','sourceTree','controllerCommit','controllerTree']:assert re.fullmatch('[0-9a-f]{40}',v.get(k) or ''),k
 assert v['sourceRevision']!=FAILED_SOURCE,'Known failed preparation source cannot launch'
 for k in ['buildId','distributionManifestSha256','offlineManifestSha256','serviceWorkerSha256','publicIdentityReceiptSha256','catalogStylesheetSha256','sourceQualificationSha256']:assert re.fullmatch('[0-9a-f]{64}',v.get(k) or ''),k
 for k in ['releaseId','inventoryFiles','inventoryBytes','deploymentId','publicationRunId','catalogStylesheetBytes']:assert type(v.get(k)) is int and v[k]>0,k
 assert v.get('releasePublishedAt') and v.get('publicIdentityVerifiedAt')
 assert v.get('scope')=='https://mekhovov.github.io/revealline/releases/v0.57.2/site/' and v.get('url')==v['scope']+'game/'
 assert v.get('expectedSaveChannel')=='release-v0.57.2'
 assert v.get('catalogStylesheetURL')=='https://mekhovov.github.io/revealline/catalog-ui/game/ui/operation-status.css'
 proof=Path(v['publicIdentityReceiptPath']);proof=proof if proof.is_absolute() else ROOT/proof
 assert proof.is_relative_to(ROOT) and proof.is_file() and not proof.is_symlink() and digest(proof)==v['publicIdentityReceiptSha256']
 qpath=Path(v['sourceQualificationPath']);qpath=qpath if qpath.is_absolute() else ROOT/qpath
 assert qpath.is_relative_to(ROOT) and qpath.is_file() and not qpath.is_symlink() and digest(qpath)==v['sourceQualificationSha256']
 q=json.loads(qpath.read_text());assert q.get('passed') is True and q.get('version')==v['version'] and q.get('sourceRevision')==v['sourceRevision'] and q.get('sourceTree')==v['sourceTree']
 return v

def launch(alive=True):
 active=json.loads((RUN/'active-launch.json').read_text());p=RUN/active['file']
 assert p.parent==RUN and p.name.endswith('-launch.json') and digest(p)==active['sha256']
 v=json.loads(p.read_text());assert v.get('rootGo') is True and v['profile']==str(RUN/'profile')
 assert digest(v['identityFile'])==v['identitySha256'];identity(v['identityFile'])
 if alive:os.kill(v['pid'],0)
 return v
