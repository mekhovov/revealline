/** Cache-only exact browser identity; no connection is made on import. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
export const P=path.dirname(path.dirname(fileURLToPath(import.meta.url))), R=path.join(P,'run');
export const sha=b=>createHash('sha256').update(b).digest('hex');
export function currentLaunch({verifyIdentity=true}={}) {
 const a=JSON.parse(fs.readFileSync(path.join(R,'active-launch.json'))),f=path.join(R,a.file);
 if(path.dirname(f)!==R||!a.file.endsWith('-launch.json')||sha(fs.readFileSync(f))!==a.sha256)throw Error('Active launch pin differs');
 const v=JSON.parse(fs.readFileSync(f));
 if(v.rootGo!==true||v.profile!==path.join(R,'profile')||!/^ws:\/\/127\.0\.0\.1:\d+\/devtools\/browser\//.test(v.endpoint))throw Error('Wrong owned launch');
 process.kill(v.pid,0);
 if(verifyIdentity){
  const b=fs.readFileSync(v.identityFile),i=JSON.parse(b);
  if(v.identityFile!==path.join(P,'verified-public-identity.json')||sha(b)!==v.identitySha256||i.authorizedPublicRun!==true||i.sourceQualificationPassed!==true||i.version!=='v0.57.2'||i.sourceRevision==='69195ddd1d21a7bc3f863cf7589069a735301a03')throw Error('Future identity absent/changed or known failed source');
 }
 return v;
}
export function registry(launch){const f=path.join(R,launch.attempt+'-targets.json');return fs.existsSync(f)?JSON.parse(fs.readFileSync(f)):{endpoint:launch.endpoint,profile:launch.profile,activeTargetId:null,targets:[]};}
export function writeRegistry(launch,value){if(value.endpoint!==launch.endpoint||value.profile!==launch.profile)throw Error('Target registry launch mismatch');fs.writeFileSync(path.join(R,launch.attempt+'-targets.json'),JSON.stringify(value,null,2)+'\n');}
export function active(launch){const r=registry(launch),t=r.targets.find(t=>t.targetId===r.activeTargetId);if(!t||t.role==='help'||r.endpoint!==launch.endpoint||r.profile!==launch.profile)throw Error('No explicit active input target');return t;}
export async function connect(launch){
 const socket=new WebSocket(launch.endpoint);await new Promise((yes,no)=>{const timer=setTimeout(()=>no(Error('Owned connection timeout')),4000);socket.onopen=()=>{clearTimeout(timer);yes();};socket.onerror=e=>{clearTimeout(timer);no(e);};});
 let id=0;const pending=new Map();socket.onmessage=e=>{const v=JSON.parse(String(e.data)),p=pending.get(v.id);if(p){pending.delete(v.id);clearTimeout(p.timer);v.error?p.reject(Error(v.error.message)):p.resolve(v.result);}};
 const call=(method,params={},sessionId)=>new Promise((resolve,reject)=>{const n=++id,timer=setTimeout(()=>{pending.delete(n);reject(Error(method+' timeout'));},4000);pending.set(n,{resolve,reject,timer});socket.send(JSON.stringify({id:n,method,params,...(sessionId?{sessionId}:{})}));});
 try{const args=(await call('Browser.getBrowserCommandLine')).arguments;if(!args.includes('--user-data-dir='+launch.profile))throw Error('Actual profile differs');return {socket,call,args};}catch(e){socket.close();throw e;}
}
export function ownOutput(name){const f=path.resolve(name);if(!f.startsWith(R+path.sep)||fs.existsSync(f))throw Error('Fresh owned output required');return f;}
