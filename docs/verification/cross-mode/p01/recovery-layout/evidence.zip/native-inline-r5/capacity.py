from pathlib import Path
import json,shutil,time,datetime,stat,hashlib,subprocess,os
P=Path(__file__).resolve().parent;R=P/'run';C=json.loads((P/'config.json').read_text())
def raw(pin):
 p=Path(pin['path']);assert str(p)==str(p.resolve()) and p.is_file() and not p.is_symlink()
 b=p.read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],str(p);return b
def check(stage):
 A=json.loads((P/'root-authorization.json').read_text())
 assert A['status']=='AUTHORIZED_BOUNDED_SOURCE_RECOVERY_RETURN' and A['rootGo'] is True and A['sourceRoot']==C['sourceRoot']
 now=datetime.datetime.now(datetime.timezone.utc)
 assert datetime.datetime.fromisoformat(A['notBefore'].replace('Z','+00:00'))<=now<datetime.datetime.fromisoformat(A['expiresAt'].replace('Z','+00:00'))
 assert A['sourcePinsPin']['path']==str(P/'input-pins.json') and A['toolManifestPin']['path']==str(P/'tool-manifest.json')
 source=json.loads(raw(A['sourcePinsPin']));tools=json.loads(raw(A['toolManifestPin']));raw(A['priorBrowserClosurePin'])
 for row in tools['files']:
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
  raw({**row,'path':str(P/row['path'])})
 if stage in ['before-server','before-launch','final']:
  for row in source['source']:raw({**row,'path':str(Path(C['sourceRoot'])/row['path'])})
 if stage in ['before-server','before-launch']:
  live=subprocess.check_output(['ps','-axo','command='],text=True)
  others=[x for x in live.splitlines() if 'Google Chrome' in x and '--user-data-dir=' in x and '/.cache/cross-mode/p01/' in x and str(R/'profile') not in x]
  assert not others,'Another task P01 browser still owns a profile'
 R.mkdir(exist_ok=True)
 profile=evidence=allocated=0;profileLinks=[]
 for base,dirs,files in os.walk(R,followlinks=False):
  for name in dirs+files:
   f=Path(base)/name;st=f.lstat()
   if stat.S_ISLNK(st.st_mode):
    assert R/'profile' in f.parents,'Symlink outside exact owned profile: '+str(f)
    profileLinks.append({'path':str(f.relative_to(R)),'target':os.readlink(f),'logicalBytes':st.st_size,'allocatedBytes':st.st_blocks*512})
    profile+=st.st_size;allocated+=st.st_blocks*512
    continue # Account link metadata only; os.walk never follows directory links.
   if not stat.S_ISREG(st.st_mode):continue
   allocated+=st.st_blocks*512
   if f.is_relative_to(R/'profile'):profile+=st.st_size
   else:evidence+=st.st_size
 l=C['limits'];free=shutil.disk_usage(P).free;remaining=max(0,l['profileBytes']-profile)+max(0,l['evidenceBytes']-evidence);projected=free-remaining-C['futureRootReservedBytes']
 rec={'at':now.isoformat(),'stage':stage,'freeBytes':free,'projectedReserveBytes':projected,'profileBytes':profile,'evidenceBytes':evidence,'allocatedBytes':allocated,'peerReservedBytes':C['futureRootReservedBytes'],'profileLinks':profileLinks}
 with (R/'capacity.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 assert projected>=l['minimumProjectedFreeBytes'] and profile<=l['profileBytes'] and evidence<=l['evidenceBytes'] and allocated<=l['maximumActualNewDiskBytes'],rec
 if stage not in ['final','after-exit'] and (R/'launch.json').exists():assert time.time()-json.loads((R/'launch.json').read_text())['startedAt']<=l['browserSeconds'],'Browser deadline'
 return rec
if __name__=='__main__':print(json.dumps(check(__import__('sys').argv[1] if len(__import__('sys').argv)>1 else 'explicit')))
