"""One owned Chrome process, one fixed 20-second endpoint-readiness deadline."""
import http.client
import json
import time
from urllib.parse import urlparse


def probe_version(port, remaining):
    deadline = time.monotonic() + remaining
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=min(1, remaining))
    try:
        connection.request('GET', '/json/version')
        response = connection.getresponse()
        if response.status != 200:
            raise ValueError('Owned endpoint is not ready: HTTP ' + str(response.status))
        chunks = []
        count = 0
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('Owned endpoint response deadline')
            chunk = response.read1(min(8192, 65537 - count))
            if not chunk:
                break
            chunks.append(chunk)
            count += len(chunk)
            if count > 65536:
                raise ValueError('Owned endpoint response exceeds 64 KiB')
        return json.loads(b''.join(chunks))
    finally:
        connection.close()


def wait_for_owned_endpoint(profile, process, spawned_at, *, note,
                            monotonic=time.monotonic, sleep=time.sleep, probe=probe_version):
    started = monotonic()
    deadline = started + 20
    attempts = 0
    while monotonic() < deadline:
        code = process.poll()
        if code is not None:
            raise RuntimeError('Owned Chrome exited before readiness: ' + str(code))
        port_file = profile / 'DevToolsActivePort'
        if port_file.is_file() and not port_file.is_symlink() and port_file.stat().st_mtime >= spawned_at:
            attempts += 1
            try:
                raw = port_file.read_bytes()
                if len(raw) > 1024:
                    raise ValueError('Owned DevTools endpoint file too large')
                port = int(raw.splitlines()[0])
                if not 1 <= port <= 65535:
                    raise ValueError('Invalid owned endpoint port')
                version = probe(port, max(.001, deadline - monotonic()))
                endpoint = urlparse(version.get('webSocketDebuggerUrl', ''))
                if endpoint.scheme != 'ws' or endpoint.hostname != '127.0.0.1' or endpoint.port != port or not endpoint.path.startswith('/devtools/browser/'):
                    raise ValueError('Owned browser endpoint identity differs')
                if monotonic() >= deadline or process.poll() is not None:
                    raise RuntimeError('Owned endpoint readiness completed outside deadline/process lifetime')
                note({'state': 'ready', 'attempt': attempts, 'elapsedMs': (monotonic() - started) * 1000, 'port': port})
                return port, version
            except (TimeoutError, OSError, http.client.HTTPException, ValueError) as error:
                note({'state': 'not-ready', 'attempt': attempts, 'elapsedMs': (monotonic() - started) * 1000,
                      'errorType': type(error).__name__, 'message': str(error)[:240]})
        sleep(min(.1, max(0, deadline - monotonic())))
    raise TimeoutError('Owned endpoint was not ready within the original 20-second deadline')
