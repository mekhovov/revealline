import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const P=path.dirname(fileURLToPath(import.meta.url));
const pins=JSON.parse(fs.readFileSync(path.join(P,'ws-dependency-pins.json')));
const expected='/Users/oleksandr.mekhovov/.local/share/mise/installs/node/20.19.5/lib/node_modules/difit/node_modules/ws';
if(process.execPath!=='/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node'||pins.moduleRoot!==expected||pins.entry!=='index.js'||pins.version!=='8.19.0')throw Error('Pinned Node22/ws transport required');
for(const row of pins.files){
 if(path.isAbsolute(row.path)||row.path.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('Unsafe ws dependency pin');
 const file=path.join(expected,row.path);let at=file;while(at!==expected){if(fs.lstatSync(at).isSymbolicLink())throw Error('Symlink ws dependency');at=path.dirname(at);}
 const bytes=fs.readFileSync(file);if(bytes.length!==row.bytes||crypto.createHash('sha256').update(bytes).digest('hex')!==row.sha256)throw Error('Installed ws dependency changed: '+row.path);
}
const require=createRequire(path.join(expected,'index.js'));
for(const name of ['bufferutil','utf-8-validate']){let resolved=false;try{require.resolve(name);resolved=true;}catch(error){if(error.code!=='MODULE_NOT_FOUND')throw error;}if(resolved)throw Error('Unpinned optional ws dependency appeared: '+name);}
export const WebSocket=require(path.join(expected,'index.js'));
export const transportOptions=Object.freeze({perMessageDeflate:false,maxPayload:16*1024*1024});
export function createTransport(endpoint){
 const u=new URL(endpoint);if(u.protocol!=='ws:'||!['127.0.0.1','localhost'].includes(u.hostname)||u.username||u.password)throw Error('Transport requires exact owned loopback endpoint');
 return new WebSocket(endpoint,transportOptions);
}
