from pathlib import Path
import json,http.client,time,subprocess,datetime,hashlib
P=Path(__file__).resolve().parent;R=P/'run';L=json.loads((R/'launch.json').read_text());S=json.loads((R/'server.json').read_text());T=json.loads((R/'owned-target.json').read_text())
assert L['profile']==str(R/'profile') and L['port']>0
argv=subprocess.check_output(['ps','-p',str(L['pid']),'-o','command='],text=True);assert '--user-data-dir='+L['profile'] in argv
expected=S['url']+'/releases/';out=R/'settled-explorer-target.json';assert not out.exists()
start=time.monotonic();deadline=start+3;rows=[];prior=None;ok=False
try:
 while time.monotonic()<deadline:
  c=http.client.HTTPConnection('127.0.0.1',L['port'],timeout=max(.01,min(.8,deadline-time.monotonic())))
  c.request('GET','/json/list');r=c.getresponse();b=r.read(262145);c.close();assert r.status==200 and len(b)<=262144
  targets=json.loads(b);now=time.monotonic();pages=[v for v in targets if v.get('type')=='page'];valid=len(pages)==1 and pages[0]['id']==T['targetId'] and pages[0]['url']==expected
  rows.append({'elapsedMs':(now-start)*1000,'targets':targets,'valid':valid,'rawBytes':len(b),'rawSha256':hashlib.sha256(b).hexdigest()})
  if now>=deadline:break
  if valid and prior is not None and now-prior>=.3:ok=True;break
  prior=now if valid else None
  time.sleep(min(.3,max(0,deadline-time.monotonic())))
finally:
 out.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'SETTLED' if ok else 'REFUSED','pid':L['pid'],'targetId':T['targetId'],'expected':expected,'deadlineMs':3000,'elapsedMs':(time.monotonic()-start)*1000,'observations':rows,'nativeInputSent':False},indent=2)+'\n')
assert ok,'Exact owned Explorer target did not settle; no Back input authorized'
print(json.dumps({'status':'SETTLED','receipt':str(out),'observations':len(rows),'elapsedMs':(time.monotonic()-start)*1000}))
