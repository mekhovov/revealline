#!/usr/bin/env python3
from pathlib import Path
import json,subprocess,datetime,time,shutil
from startup_readiness import wait_for_owned_endpoint
P=Path(__file__).resolve().parent
C=json.loads((P/'config.json').read_text());RUN=P/'run'
if '--go' not in __import__('sys').argv: raise SystemExit('Prepared only. Explicit root GO is required before --go.')
assert (RUN/'server.json').is_file(), 'Start the owned overlay server only after GO'
from capacity import check as disk
profile=RUN/'profile'
C['maxBrowserSeconds']=C['limits']['browserSeconds']
disk('before-launch')
profile.mkdir(exist_ok=False)
args=['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--headless=new','--remote-debugging-port=0','--enable-automation','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-features=OptimizationGuideModelDownloading,OptimizationHintsFetching,OptimizationTargetPrediction,OptimizationHints','--disable-gpu-shader-disk-cache','--disable-default-apps','--disable-sync','--enable-unsafe-swiftshader','--password-store=basic','--use-mock-keychain','--disable-quic','--disable-extensions','--disk-cache-size=4194304','--media-cache-size=1048576','--window-size=390,844','--user-data-dir='+str(profile),'--no-proxy-server','about:blank']
started=time.time();proc=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 (RUN/'spawn.json').write_text(json.dumps({'startedAt':started,'pid':proc.pid,'profile':str(profile),'arguments':args,'readinessDeadlineSeconds':20,'browserStarts':1},indent=2)+'\n')
 def note(row):
  with (RUN/'readiness.jsonl').open('a') as output:output.write(json.dumps(row)+'\n')
 port,v=wait_for_owned_endpoint(profile,proc,started,note=note)
 receipt={'startedAt':started,'pid':proc.pid,'profile':str(profile),'arguments':args,'endpoint':v['webSocketDebuggerUrl'],'port':port,'version':v,'scope':C['scope']}
 (RUN/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 while proc.poll() is None:
  assert time.time()-started<=C['maxBrowserSeconds'],'Owned browser duration cap reached'
  disk('running');time.sleep(3)
 (RUN/'exit.json').write_text(json.dumps({'pid':proc.pid,'exitCode':proc.returncode,'capacity':disk('after-exit')},indent=2)+'\n')
except BaseException as e:
 cleanup={'pid':proc.pid,'initialExitCode':proc.poll(),'actions':[]}
 try:
  if proc.poll() is None:
   proc.terminate();cleanup['actions'].append('terminate')
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:proc.kill();cleanup['actions'].append('kill');proc.wait(timeout=5)
 finally:
  cleanup['finalExitCode']=proc.poll()
  (RUN/'startup-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
  (RUN/'launch-failure.json').write_text(json.dumps({'type':type(e).__name__,'message':str(e),'pid':proc.pid,'profile':str(profile)},indent=2)+'\n')
 raise
