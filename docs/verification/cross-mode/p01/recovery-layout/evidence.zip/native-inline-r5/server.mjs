import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { startServer } from '/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/scripts/game-cli.mjs';
import { publishedReleaseIndex } from '/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/publishing/pages-controller/catalog.mjs';
const P=path.dirname(new URL(import.meta.url).pathname),C=JSON.parse(await fs.readFile(path.join(P,'config.json')));
const root=C.sourceRoot;
const {execFileSync}=await import('node:child_process');execFileSync('python3',[path.join(P,'capacity.py'),'before-server'],{env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'}});
const catalog=JSON.parse(await fs.readFile(path.join(root,'publishing/pages-controller/catalog.json')));
const records=await Promise.all(catalog.releases.map(r=>fs.readFile(path.join(root,'publishing/pages-controller/metadata',r.version,'release.json'),'utf8').then(JSON.parse)));
const latest=records.map(r=>r.version).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true})).at(-1);
const index=publishedReleaseIndex(records,catalog.sourceRepository,latest,{}, {presentation:true});
await fs.writeFile(path.join(P,'run/explorer.html'),index.html,{flag:'wx'});
const upstream=await startServer({root,host:'127.0.0.1',port:0});
const server=http.createServer((req,res)=>{
 if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return;}
 if(req.url==='/releases/'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'max-age=600'});res.end(req.method==='HEAD'?undefined:index.html);return;}
 const route=req.url.startsWith('/catalog-ui/')?req.url.slice('/catalog-ui'.length):req.url;
 const proxy=http.request(new URL(route,upstream.url),{method:req.method},r=>{res.writeHead(r.statusCode,{...r.headers,'cache-control':'max-age=600'});r.pipe(res)});
 proxy.on('error',e=>{res.writeHead(502);res.end(String(e));});proxy.end();
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));console.log(`http://127.0.0.1:${server.address().port}/`);
for(const s of ['SIGTERM','SIGINT'])process.once(s,()=>{server.close();upstream.server.close();setTimeout(()=>process.exit(0),100).unref();});

setTimeout(()=>{server.close();upstream.server.close();setTimeout(()=>process.exit(0),100).unref();},(C.limits.browserSeconds+120)*1000).unref();
