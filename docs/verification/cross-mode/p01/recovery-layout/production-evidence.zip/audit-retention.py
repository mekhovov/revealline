from pathlib import Path
import copy,hashlib,json,struct,subprocess
R=Path.cwd();P=Path(__file__).resolve().parent;BASE='0b368297567c9fd6ede5254ab2be21033c0a2bfb'
def prior(rel):return subprocess.check_output(['git','show',BASE+':'+rel])
def bundle(b):
 assert b[:8]==b'RLTHM1\r\n';n=struct.unpack('>I',b[8:12])[0];assert 12+n<=len(b);m=json.loads(b[12:12+n]);assert set(m)=={'document','assets'};off=12+n;blobs={}
 for row in m['assets']:
  assert set(row)=={'bytes','sha256'} and type(row['bytes']) is int and row['bytes']>0 and row['sha256'] not in blobs
  raw=b[off:off+row['bytes']];assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'];blobs[row['sha256']]=raw;off+=len(raw)
 assert off==len(b);return m['document'],blobs,m['assets']
rel='authoring/library/fpv-field-kit/production.rltheme';before=prior(rel);after=(R/rel).read_bytes();old,ob,ot=bundle(before);new,nb,nt=bundle(after);assert new['revision']==old['revision']+1
assert set(old)==set(new)=={'format','id','revision','selection','assets','themes','collections','slots'}
assert old['format']==new['format'] and old['id']==new['id']=='field-kit'
selection=copy.deepcopy(old['selection']);selection['theme']['revision']+=1;assert new['selection']==selection
counts={}
for group in ['assets','themes','collections','slots']:
 index=lambda rows:{(r['id'],r.get('revision')):r for r in rows}
 a,b=index(old[group]),index(new[group]);assert len(a)==len(old[group]) and len(b)==len(new[group]) and all(b.get(k)==v for k,v in a.items()) and new[group][:len(old[group])]==old[group];counts[group]={'before':len(a),'after':len(b),'preserved':len(a)}
assert ot==nt and ob==nb and counts['assets']['after']-counts['assets']['before']==7 and counts['themes']['after']-counts['themes']['before']==1 and old['collections']==new['collections'] and old['slots']==new['slots']
a=json.loads(prior('game/presentation/compiled/runtime.json'));b=json.loads((R/'game/presentation/compiled/runtime.json').read_bytes());assert a['format']==b['format'] and a['urls']==b['urls'] and a['resolved']['tokens']==b['resolved']['tokens'] and a['resolved']['collection']==b['resolved']['collection']
assert set(a)==set(b)=={'format','source','resolved','urls'} and set(a['resolved'])==set(b['resolved'])=={'assets','bindings','collection','theme','tokens'}
assert a['source']=={'id':old['id'],'revision':old['revision']} and b['source']=={'id':new['id'],'revision':new['revision']}
theme=copy.deepcopy(a['resolved']['theme']);theme['revision']+=1;assert b['resolved']['theme']==theme and theme['revision']==new['selection']['theme']['revision']
assert set(a['resolved']['assets'])==set(b['resolved']['assets']) and set(a['resolved']['bindings'])==set(b['resolved']['bindings'])==set(a['resolved']['assets'])
expected={'screen.'+s+'.background' for s in ['collection','couch','hangar','missions','results','settings','studio']};changed={k for k,v in a['resolved']['assets'].items() if b['resolved']['assets'][k]!=v};assert changed==expected
successors={v['id']:v for v in new['assets'][len(old['assets']):]};assert set(successors)=={a['resolved']['assets'][k]['id'] for k in expected}
for k in changed:
 def content(value):
  v=copy.deepcopy(value);v.pop('revision');v.pop('quality');v['provenance'].pop('parent');v['provenance'].pop('source');return v
 assert content(a['resolved']['assets'][k])==content(b['resolved']['assets'][k])
 previous=a['resolved']['assets'][k];current=b['resolved']['assets'][k];assert current==successors[previous['id']] and current['revision']==previous['revision']+1 and current['provenance']['parent']=={'id':previous['id'],'revision':previous['revision']}
 assert b['resolved']['bindings'][k]=={'id':current['id'],'revision':current['revision']}
 assert b['resolved']['assets'][k]['quality']['stage']=='reviewed'
 assert b['resolved']['assets'][k]['provenance']['source']=='game/ui/field-kit-flow.css; game/ui/field-kit-surfaces.css; game/ui/field-kit-compiled.css; site/release-catalog.css sha256:dd485d897456b7eeea1e435cf44975ec785d8502177de655a57f5bfdbfb054f0'
unchanged=[k for k in a['resolved']['assets'] if k not in changed];assert all(a['resolved']['bindings'][k]==b['resolved']['bindings'][k] for k in unchanged)
newtheme=new['themes'][-1];oldtheme=next(t for t in old['themes'] if t['id']==old['selection']['theme']['id'] and t['revision']==old['selection']['theme']['revision'])
expectedtheme={**oldtheme,'revision':oldtheme['revision']+1,'parent':{'id':oldtheme['id'],'revision':oldtheme['revision']},'tokens':{},'bindings':{k:b['resolved']['bindings'][k] for k in expected}};assert newtheme==expectedtheme and {'id':newtheme['id'],'revision':newtheme['revision']}==new['selection']['theme']
result={'status':'PASS_APPEND_ONLY_SCOPED_RECIPE_REVISION','priorSource':BASE,'before':{'revision':old['revision'],'bytes':len(before),'sha256':hashlib.sha256(before).hexdigest()},'after':{'revision':new['revision'],'bytes':len(after),'sha256':hashlib.sha256(after).hexdigest()},'groups':counts,'originalBlobs':{'count':len(ob),'bytes':sum(map(len,ob.values())),'allBytesIdentical':True},'runtime':{'changedMetadataSlots':sorted(changed),'unchangedSlots':len(unchanged),'sameURLsTokensCollectionAndRecipeContent':True},'scope':'Retention and runtime metadata comparison; exact-source gates and public acceptance remain separate.'}
(P/'retention-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
