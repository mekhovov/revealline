from pathlib import Path
import copy,hashlib,json,struct,subprocess
R=Path.cwd();P=Path(__file__).resolve().parent;BASE='0b368297567c9fd6ede5254ab2be21033c0a2bfb'
def prior(rel):return subprocess.check_output(['git','show',BASE+':'+rel])
def bundle(b):
 assert b[:8]==b'RLTHM1\r\n';n=struct.unpack('>I',b[8:12])[0];m=json.loads(b[12:12+n]);off=12+n;blobs={}
 for row in m['assets']:
  raw=b[off:off+row['bytes']];assert hashlib.sha256(raw).hexdigest()==row['sha256'];blobs[row['sha256']]=raw;off+=len(raw)
 assert off==len(b);return m['document'],blobs
rel='authoring/library/fpv-field-kit/production.rltheme';before=prior(rel);after=(R/rel).read_bytes();old,ob=bundle(before);new,nb=bundle(after);assert new['revision']==old['revision']+1
counts={}
for group in ['assets','themes','collections','slots']:
 index=lambda rows:{(r['id'],r.get('revision')):r for r in rows}
 a,b=index(old[group]),index(new[group]);assert len(a)==len(old[group]) and len(b)==len(new[group]) and all(b.get(k)==v for k,v in a.items());counts[group]={'before':len(a),'after':len(b),'preserved':len(a)}
assert ob==nb and counts['assets']['after']-counts['assets']['before']==7 and counts['themes']['after']-counts['themes']['before']==1 and old['collections']==new['collections'] and old['slots']==new['slots']
a=json.loads(prior('game/presentation/compiled/runtime.json'));b=json.loads((R/'game/presentation/compiled/runtime.json').read_bytes());assert a['format']==b['format'] and a['urls']==b['urls'] and a['resolved']['tokens']==b['resolved']['tokens'] and a['resolved']['collection']==b['resolved']['collection']
expected={'screen.'+s+'.background' for s in ['collection','couch','hangar','missions','results','settings','studio']};changed={k for k,v in a['resolved']['assets'].items() if b['resolved']['assets'][k]!=v};assert changed==expected
for k in changed:
 def content(value):
  v=copy.deepcopy(value);v.pop('revision');v.pop('quality');v['provenance'].pop('parent');v['provenance'].pop('source');return v
 assert content(a['resolved']['assets'][k])==content(b['resolved']['assets'][k])
 assert b['resolved']['assets'][k]['quality']['stage']=='reviewed'
 assert b['resolved']['assets'][k]['provenance']['source'].endswith('sha256:dd485d897456b7eeea1e435cf44975ec785d8502177de655a57f5bfdbfb054f0')
unchanged=[k for k in a['resolved']['assets'] if k not in changed];assert all(a['resolved']['bindings'][k]==b['resolved']['bindings'][k] for k in unchanged)
result={'status':'PASS_APPEND_ONLY_SCOPED_RECIPE_REVISION','priorSource':BASE,'before':{'revision':old['revision'],'bytes':len(before),'sha256':hashlib.sha256(before).hexdigest()},'after':{'revision':new['revision'],'bytes':len(after),'sha256':hashlib.sha256(after).hexdigest()},'groups':counts,'originalBlobs':{'count':len(ob),'bytes':sum(map(len,ob.values())),'allBytesIdentical':True},'runtime':{'changedMetadataSlots':sorted(changed),'unchangedSlots':len(unchanged),'sameURLsTokensCollectionAndRecipeContent':True},'scope':'Retention and runtime metadata comparison; exact-source gates and public acceptance remain separate.'}
(P/'retention-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
