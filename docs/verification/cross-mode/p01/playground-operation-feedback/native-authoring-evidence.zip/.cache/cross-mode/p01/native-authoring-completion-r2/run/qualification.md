# DEV authoring correction, second run

The corrected editor rail passed native terminal visibility at 390 × 844 and 844 × 390. The original Generate control stayed clear; native Undo restored the exact imported Classic Lab level. Landscape status PageDown scrolled its full message by 7 px; clientWidth and scrollWidth both 785, so no horizontal overflow was observed. Each sampled operation had already completed: no painted busy/Cancel claim is made.

The separate replay operation failed placement. Its real fixture verified all 1,305 ticks successfully. At 844 × 390 the native file control was visible at top 324.8125 / bottom 368.8125, while the result appeared at top 527.59375 / bottom 554.59375, below the viewport. Screenshot 04 preserves the failure; the original older Generate message remains visible in the other owner’s rail. This is a required P01 feedback correction.

The run stopped and all three owned processes/ports closed. Music, Enemy, Atlas, refreshed preview and child Back were not run. Prior Studio audio/clipboard passes remain separate. One mistaken read-only #json selector is retained as a harness error; the actual #level-json read and Undo equality passed. No application state, delay, cache or clipboard permission was injected. This is working DEV evidence, not frozen/public acceptance.
