# Bounded DEV authoring completion, third preparation

Launch is held until the Music owner hands off stable source and fresh exact input pins/capacity checks complete. Parent authorized the finite remaining family, not a release or broad authoring review.

Reuse explicit Node22, one owned Chrome/profile/target, localhost source server and guarded CDP/native actions. Every action brings that target to front and checks actual visibility/focus/route. Profiles from earlier closed attempts remain untouched. Limits remain20minutes,60MiBprofile,10MiBevidence,1MiBdownloads,96MiBactualallocation,16screenshots; continuously reserve100MiBpeerallocation plus512MiBfloor. Stop a concrete required defect and close; never manufacture delayed app work.

Sequence: Playground native ClassicLab import, Generate/Undo and replay file verification with sharedrail geometry at390×844 and844×390; original Play configuration→actual child ready; actual Back to campaign and native history Back if stable. Music Settings→Music Studio→pinned silentMP3import→actual Audition/Finish, with status/focus bounds. Enemy originalOpen→Practice→actualready→Return to workshop. Atlas nativeCopy→actualclipboard success or truthfuldenial→Back. Prior Studio audio/clipboard passes carry separately.

`frame-click #catalog-practice #enemy-workshop-return` is a bounded new native pointer action. It only reads actual same-origin practice document and both child/parent hit geometry, then sends normal CDPmouse input. It cannot invoke handlers or assign state. There is no new popup/auto-connect or nativeVirtualKeyCode path. Existing read observes iframe readiness; no iframe-load-only pass.

All actual source/fixture bodies and pins will be frozen before launch; this preparation currently has no input-pins.json and therefore refuses launch. Original first/second native failures and tooling read-error remain separately retained.
