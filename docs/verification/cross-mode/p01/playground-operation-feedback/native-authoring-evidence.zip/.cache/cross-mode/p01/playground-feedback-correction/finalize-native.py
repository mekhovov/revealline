from pathlib import Path
import json,hashlib,struct,zipfile,datetime
ROOT=Path.cwd();BASE=ROOT/'.cache/cross-mode/p01';DEST=ROOT/'docs/verification/cross-mode/p01/playground-operation-feedback';DEST.mkdir(exist_ok=True)
def h(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':h(b)}
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
for suffix in ['-r3','-r4']:
 p=BASE/('native-authoring-completion'+suffix);r=p/'run';actions=[(f,json.loads(f.read_text())) for f in sorted(r.glob('action-*.json'))]
 sizes=[{'path':f.name,'width':struct.unpack('>II',f.read_bytes()[16:24])[0],'height':struct.unpack('>II',f.read_bytes()[16:24])[1],'sha256':h(f.read_bytes())} for f in sorted(r.glob('*.png'))]
 if suffix=='-r3':
  imported=next((f,a) for f,a in actions if a.get('result',{}).get('status','').startswith('Imported and decoded'))
  undo=next((f,a) for f,a in actions if a.get('result',{}).get('status','').startswith('Previous configuration'))
  assert imported[1]['result']['level']==undo[1]['result']['level']
  result={'status':'FUNCTIONAL_PASS_CAPTURE_LIMIT_RETAINED','scope':'WorkingDEV only; actual5target-size and5default-size later screenshots separately classified, not public acceptance','passed':['A43 real replay full1305tick verification; terminal visible in both requested Playground sizes','A48 authenticClassicLab import/Generate; Undo exactobservedlevel restoration','A48 native headerPlay changeschildrevision1to2; actualchildready; Backcampaign/historyBack','A37 native4170BMP3import/audio play/immediateFinish, nativeTabnextplaylist andEscapeopener','A51 actualpracticechildready/nativesame-draftReturn/Escapeopener','A54 nativeclipboardresolved afteropeningbrief; Back'], 'undo':{'import':str(imported[0].relative_to(ROOT)),'undo':str(undo[0].relative_to(ROOT)),'sha256':h(imported[1]['result']['level'].encode()),'equal':True},'limits':['PNG01–05 matchdeclaredtargetviewports;06/07/08/09/11 are500x701 and do not qualify requestedcapture sizes','Atlas10 is844x390 but depictsclosedbrief; refusedcopy retained and not a pass','Music06 capturedafter shortMP3 naturallyended; playingstate existsin earliernativeDOM/audio sample only','Playground historyBack reloaded a back_forwarddocument withinitiallevel; no nativepersistedBFCache orcrossnavigationdraftpreservationclaim','No paintedbusy/Cancel sampleforquickPlaygroundtasks','Two pre-connectcapacitywalkFileNotFoundError refusals whenChrome retiredcachefiles; immediatefreshcapacitypasses preceded any further action. Originaltooloutput remains in conversation; this receipt summarizes ratherthan pretendingto be rawstderr','Safe nativeguardrefusals forwrongMusicselectors, already-endedFinish, auto-openEnemy/nonvisibleTry andclosedAtlasbrief retained'], 'correctiveRetest':'native-authoring-completion-r4/run/review.json'}
 else:
  seq=json.loads((r/'music-sequence.json').read_text());assert seq['ok'] and 'finish' in seq and seq['playObservation']['audio'][0]['paused'] is False and seq['final']['audio'][0]['paused'] is True
  for f,a in actions:
   assert a['ok'],f
   if a['action']=='init':continue
   for k in ['before','after']:
    v=a[k];assert [v['innerWidth'],v['innerHeight']]==[v['expected']['width'],v['expected']['height']];assert v['metrics']['cssLayoutViewport']['clientWidth']==v['innerWidth'] and v['metrics']['cssLayoutViewport']['clientHeight']==v['innerHeight']
  assert [(s['width'],s['height']) for s in sizes]==[(390,844),(390,844),(390,844),(844,390)]
  result={'status':'PASS_BOUNDED_NATIVE_METRICS_CORRECTION','scope':'WorkingDEV only; threepreviouslyfunctionalhosts withactualtargetgeometry/PNG control; not frozen/public/P01 acceptance','passed':['A37 nativeMP3import/Audition/Finish at390x844: actualpaintedplayinglabel+44pxenabledFinish, realaudioduration0.260625s/readystate4/currentTime0.02322 thenpaused/readystate0; Tabnextvisibleplaylist, EscapevisibleMusicopener','A51 practicechild actualbootready; nativeiframeReturnsameworkshopdraft; rolefocus andEscapeopener at390x844','A54 nativeCopy success at844x390 withCopy223.90625–267.90625/status267.90625–307.90625, bothhit, retainedCopyfocus andBack'], 'actualViewportChecks':{'allActionBeforeAfterRuntimeAndPageMetrics':True,'actions':len(actions),'musicSameSessionPrePostMetrics':True,'allFourPNGHeadersExact':True},'limits':['No physicalaudibility/deviceclaim: fixtureisintentionallysilent','Music Finishbrieflydisablesfocusedbutton andactiveElementbecomesBODY; subsequentTabandClosebothfollowexpectedvisiblecontrols. Retainedobservation, not a claimednewfocuspolicy','No syntheticworkdelay, cache/state/clipboardpermissioninjection; nativepointer/file/key actions only','P01 public/frozen acceptance andotherrelease gates remainparentowned']}
 result['screenshots']=sizes;result['guardRefusals']=[{'path':str(f.relative_to(ROOT)),'action':a['action'],'arg':a.get('arg'),'error':a.get('error')} for f,a in actions if not a['ok']];result['closure']=pin(r/'closure.json');write(r/'review.json',result)
 (r/'qualification.md').write_text('# '+result['status']+'\n\n'+result['scope']+'\n\n'+ '\n'.join('- '+x for x in result['passed'])+'\n\nLimits retained:\n\n'+'\n'.join('- '+x for x in result['limits'])+'\n')
 files=[f for f in sorted(r.rglob('*')) if f.is_file() and 'profile' not in f.relative_to(r).parts and f.name!='manifest.json'];write(r/'manifest.json',{'format':'revealline-native-evidence-manifest.v1','status':result['status'],'files':[pin(f) for f in files]})
# Verify all original manifest rows before selecting any archive member.
roots=[BASE/('native-authoring-completion'+suffix) for suffix in ['', '-r2','-r3','-r4']]
for p in roots:
 for row in json.loads((p/'run/manifest.json').read_text())['files']:
  f=Path(row['path']);f=f if f.is_absolute() else ROOT/f
  b=f.read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256'],f
selected=[]
for p in roots:
 for f in sorted(p.rglob('*')):
  if not f.is_file() or any(k in {'profile','__pycache__'} for k in f.relative_to(p).parts):continue
  selected.append(f)
# Retain all focused logs and current controlling tests; no broadignored log omission.
p=BASE/'playground-feedback-correction'
selected += [f for f in sorted(p.iterdir()) if f.is_file() and f.name!='native-evidence-archive.json']
selected += [ROOT/x for x in ['game/playground/index.html','game/playground/playground.css','game/playground/playground.mjs','game/test/playground-import-host.test.mjs','game/test/playground-model.test.mjs','game/test/playground-viewport.test.mjs','game/test/helpers/couch-dom.mjs','game/test/helpers/media-fixtures.mjs']]
selected=sorted(set(selected));assert len(selected)<1000 and sum(f.stat().st_size for f in selected)<16*1024*1024
rows=[];zipPath=DEST/'native-authoring-evidence.zip'
with zipfile.ZipFile(zipPath,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in selected:
  b=f.read_bytes();member=str(f.relative_to(ROOT));z.writestr(member,b);rows.append({'source':member,'member':member,'bytes':len(b),'sha256':h(b)})
 z.writestr('evidence-manifest.json',json.dumps({'scope':'Allfourownednativeattempts, originalfailures/capturelimits + correctedworkingDEV proof; excludesprofiles andreleaseclaims','files':rows},indent=2)+'\n')
with zipfile.ZipFile(zipPath) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(rows)+1
 for row in rows:
  b=z.read(row['member']);assert len(b)==row['bytes'] and h(b)==row['sha256'];assert h((ROOT/row['source']).read_bytes())==row['sha256']
record={'status':'ARCHIVED_ALL_SELECTED_ORIGINALS_VERIFIED','scope':'FourworkingDEVnativeattempts plusfocused23testproof; originalfailuresandcapture-sizecorrection retained; no releaseacceptance','archive':pin(zipPath),'originalFiles':len(rows),'originalBytes':sum(row['bytes'] for row in rows),'membersIncludingManifest':len(rows)+1,'allOriginalAndArchiveBytesVerified':True,'allZIPCRCVerified':True,'excluded':['OwnedChromeprofiles/cache','No unrelatedsessions orruntimebuild/media copies','No credentials/authheaders orpublicpayload'],'runManifests':[pin(p/'run/manifest.json') for p in roots],'finalNativeReview':pin(roots[-1]/'run/review.json'),'sourceFocusedReceipt':pin(BASE/'playground-feedback-correction/ordered-owners-receipt.json')};write(DEST/'evidence-record.json',record);print(json.dumps(record,indent=2))
