# PASS_BOUNDED_NATIVE_METRICS_CORRECTION

WorkingDEV only; threepreviouslyfunctionalhosts withactualtargetgeometry/PNG control; not frozen/public/P01 acceptance

- A37 nativeMP3import/Audition/Finish at390x844: actualpaintedplayinglabel+44pxenabledFinish, realaudioduration0.260625s/readystate4/currentTime0.02322 thenpaused/readystate0; Tabnextvisibleplaylist, EscapevisibleMusicopener
- A51 practicechild actualbootready; nativeiframeReturnsameworkshopdraft; rolefocus andEscapeopener at390x844
- A54 nativeCopy success at844x390 withCopy223.90625–267.90625/status267.90625–307.90625, bothhit, retainedCopyfocus andBack

Limits retained:

- No physicalaudibility/deviceclaim: fixtureisintentionallysilent
- Music Finishbrieflydisablesfocusedbutton andactiveElementbecomesBODY; subsequentTabandClosebothfollowexpectedvisiblecontrols. Retainedobservation, not a claimednewfocuspolicy
- No syntheticworkdelay, cache/state/clipboardpermissioninjection; nativepointer/file/key actions only
- P01 public/frozen acceptance andotherrelease gates remainparentowned
