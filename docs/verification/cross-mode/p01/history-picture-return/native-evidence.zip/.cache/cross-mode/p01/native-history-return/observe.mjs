import fs from 'node:fs';import path from 'node:path';
import {R,call,attach,evaluate,foreground,events,close} from './cdp.mjs';
const out=fs.createWriteStream(path.join(R,'events.jsonl'),{flags:'wx'});let bytes=0;
const write=v=>{const row=JSON.stringify({at:new Date().toISOString(),...v})+'\n';bytes+=Buffer.byteLength(row);if(bytes>1048576)throw Error('Observer one MiB cap');out.write(row);};
const {sessionId:sid,target}=await attach();await foreground(sid);
events.push(m=>{
 if(m.method==='Runtime.consoleAPICalled'&&m.sessionId===sid){for(const a of m.params.args||[])if(typeof a.value==='string'&&a.value.startsWith('P01_HISTORY '))write({method:'DOM.event',measurement:JSON.parse(a.value.slice(12))});}
 else if(['DOMStorage.domStorageItemAdded','DOMStorage.domStorageItemUpdated','DOMStorage.domStorageItemRemoved','DOMStorage.domStorageItemsCleared'].includes(m.method)){const p={...m.params};for(const key of ['oldValue','newValue'])if(typeof p[key]==='string')p[key]=p[key].length;write({method:m.method,params:p});}
 else if(['Runtime.exceptionThrown','Network.loadingFailed','Page.backForwardCacheNotUsed','Target.detachedFromTarget','Inspector.detached'].includes(m.method))write(m);
});
await call('Runtime.enable',{},sid);await call('DOMStorage.enable',{},sid);await call('Page.enable',{},sid);await call('Network.enable',{},sid);
const expression=`(()=>{const record=e=>console.info('P01_HISTORY '+JSON.stringify({type:e.type,persisted:e.persisted,url:location.href,timeOrigin:performance.timeOrigin,at:performance.now(),isTrusted:e.isTrusted,visibility:document.visibilityState,focus:document.hasFocus(),active:document.activeElement?.id}));for(const n of ['pagehide','pageshow','error','unhandledrejection'])window.addEventListener(n,record);document.addEventListener('visibilitychange',record);})();`;
await call('Page.addScriptToEvaluateOnNewDocument',{source:expression},sid);await evaluate(expression,sid);write({ready:true,target,sessionId:sid});console.log(JSON.stringify({ready:true,pid:process.pid,target:target.targetId}));
const heartbeat=setInterval(()=>write({heartbeat:true}),5000);let done=false;
function stop(){if(done)return;done=true;clearInterval(heartbeat);write({closed:true});close();out.end(()=>process.exit(0));}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
