import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import {P,R,config,launch,server,call,attach,evaluate,foreground,close} from './cdp.mjs';
const [action,arg,extra]=process.argv.slice(2),number=fs.readdirSync(R).filter(n=>/^action-\d+\.json$/.test(n)).length+1;
const receipt={at:new Date().toISOString(),action,arg,extra,pid:launch.pid,profile:launch.profile};
try{
 const {sessionId:sid,target}=await attach({initial:action==='init'});receipt.target=target;receipt.before=action==='init'?null:await foreground(sid);
 if(action==='init'){await call('Page.navigate',{url:server.url+'/game/'},sid);await call('Emulation.setDeviceMetricsOverride',{width:1280,height:800,deviceScaleFactor:1,mobile:false},sid);}
 else if(action==='read'){receipt.result=await evaluate(arg,sid);}
 else if(action==='viewport'){const [width,height]=arg.split('x').map(Number);if(![[390,844],[844,390]].some(x=>x[0]===width&&x[1]===height))throw Error('Unplanned viewport');fs.writeFileSync(path.join(R,'viewport.json'),JSON.stringify({width,height}));await new Promise(r=>setTimeout(r,250));}
 else if(action==='download-dir'){fs.mkdirSync(path.join(R,'downloads'),{recursive:true});await call('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:path.join(R,'downloads'),eventsEnabled:true});}
 else if(action==='click'||action==='wheel'||action==='upload'){
  const selector=JSON.stringify(arg);const e=await evaluate(`(()=>{const e=document.querySelector(${selector});if(!e)return null;const r=e.getBoundingClientRect(),x=Math.max(1,Math.min(innerWidth-1,r.x+r.width/2)),y=Math.max(1,Math.min(innerHeight-1,r.y+r.height/2)),hit=document.elementFromPoint(x,y);return {disabled:e.disabled,type:e.type,rect:r.toJSON(),x,y,hit:!!hit&&(hit===e||e.contains(hit)),visible:r.width>0&&r.height>0&&r.bottom>0&&r.y<innerHeight}})()`,sid);receipt.element=e;
  if(!e||e.disabled||!e.visible||(action!=='wheel'&&!e.hit))throw Error('Visible enabled hit target refused');
  if(action==='click'){for(const type of ['mouseMoved','mousePressed','mouseReleased'])await call('Input.dispatchMouseEvent',{type,x:e.x,y:e.y,...(type==='mouseMoved'?{}:{button:'left',clickCount:1})},sid);}
  else if(action==='wheel'){const deltaY=Number(extra);if(!Number.isFinite(deltaY)||Math.abs(deltaY)>1600)throw Error('Wheel bound');await call('Input.dispatchMouseEvent',{type:'mouseWheel',x:e.x,y:e.y,deltaX:0,deltaY},sid);}
  else {if(e.type!=='file')throw Error('Not file input');let files=[];if(extra!=='EMPTY'){const absolute=path.resolve(extra),fixed=config.fixtures.find(f=>path.resolve(config.sourceRoot,f.path)===absolute),local=absolute.startsWith(path.join(R,'downloads')+path.sep);if(!fixed&&!local)throw Error('Unapproved file');const bytes=fs.readFileSync(absolute),sha256=crypto.createHash('sha256').update(bytes).digest('hex');if(fixed&&(bytes.length!==fixed.bytes||sha256!==fixed.sha256))throw Error('Fixture changed');if(local&&(bytes.length>1048576||!fs.readFileSync(path.join(R,'events.jsonl'),'utf8').includes(path.basename(absolute))))throw Error('Not observed bounded native download');receipt.file={path:absolute,bytes:bytes.length,sha256};files=[absolute];}const {root}=await call('DOM.getDocument',{},sid),{nodeId}=await call('DOM.querySelector',{nodeId:root.nodeId,selector:arg},sid);if(!nodeId)throw Error('Input disappeared');await call('DOM.setFileInputFiles',{nodeId,files},sid);}
 }
 else if(action==='key'){const map={ArrowDown:40,ArrowUp:38,ArrowLeft:37,ArrowRight:39,Enter:13,Escape:27,Tab:9,Space:32,PageDown:34,PageUp:33,End:35,Home:36};if(!map[arg])throw Error('Unplanned key');const duration=Number(extra||0);if(duration<0||duration>350)throw Error('Hold bound');const p={key:arg==='Space'?' ':arg,code:arg,windowsVirtualKeyCode:map[arg]};await call('Input.dispatchKeyEvent',{type:'keyDown',...p},sid);await new Promise(r=>setTimeout(r,duration));await call('Input.dispatchKeyEvent',{type:'keyUp',...p},sid);}
 else if(action==='type-key'){
  const expected={l:'#text-size',p:'#text-face'}[arg];if(!expected)throw Error('Only native Large/Plain type-ahead is planned');
  const e=await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(expected)});if(!e)return null;const r=e.getBoundingClientRect();return{tag:e.tagName,disabled:e.disabled,focused:e===document.activeElement&&e.matches(':focus'),value:e.value,rect:r.toJSON(),visible:r.top>=0&&r.bottom<=innerHeight&&r.width>0&&r.height>0}})()`,sid);
  receipt.selectionBefore=e;if(!e||e.tag!=='SELECT'||e.disabled||!e.focused||!e.visible)throw Error('Native type-ahead requires its visible focused select');
  const key={key:arg,code:arg==='l'?'KeyL':'KeyP',windowsVirtualKeyCode:arg==='l'?76:80};await call('Input.dispatchKeyEvent',{type:'keyDown',...key,text:arg,unmodifiedText:arg},sid);await call('Input.dispatchKeyEvent',{type:'keyUp',...key},sid);
 }
 else if(action==='select-large'){
  if(arg!=='#text-size')throw Error('Only native Large setting is planned');
  const before=await evaluate(`(()=>{const e=document.querySelector('#text-size');if(!e)return null;const r=e.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2,h=document.elementFromPoint(x,y);return{tag:e.tagName,disabled:e.disabled,value:e.value,options:[...e.options].map(o=>({value:o.value,disabled:o.disabled})),rect:r.toJSON(),x,y,hit:h===e,visible:r.width>0&&r.height>0&&r.top>=0&&r.bottom<=innerHeight&&r.left>=0&&r.right<=innerWidth}})()`,sid);
  receipt.selectionBefore=before;if(!before||before.tag!=='SELECT'||before.disabled||!before.visible||!before.hit||before.options.length!==2||before.options[0].value!=='standard'||before.options[1].value!=='large'||before.options.some(o=>o.disabled))throw Error('Visible enabled Standard/Large select changed');
  if(before.value!=='large'){
   for(const type of ['mouseMoved','mousePressed','mouseReleased'])await call('Input.dispatchMouseEvent',{type,x:before.x,y:before.y,...(type==='mouseMoved'?{}:{button:'left',clickCount:1})},sid);
   for(const [key,code] of [['End',35],['Enter',13]])for(const type of ['keyDown','keyUp'])await call('Input.dispatchKeyEvent',{type,key,code:key,windowsVirtualKeyCode:code},sid);
  }
  receipt.selectionAfter=await evaluate(`({value:document.querySelector('#text-size').value,bodySize:document.body.dataset.textSize,activeTag:document.activeElement.tagName,activeId:document.activeElement.id,focus:document.activeElement.matches(':focus'),fontSize:getComputedStyle(document.querySelector('#text-size')).fontSize,viewport:[innerWidth,innerHeight]})`,sid);
  if(receipt.selectionAfter.value!=='large'||receipt.selectionAfter.bodySize!=='large')throw Error('Native Large selection did not settle; no Large claim and no scripted fallback');
 }
 else if(action==='shot'){if(!/^[a-z0-9-]+$/.test(arg)||fs.readdirSync(R).filter(n=>n.endsWith('.png')).length>=config.limits.maxScreenshots)throw Error('Screenshot bound');const file=path.join(R,arg+'.png');const r=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false},sid);fs.writeFileSync(file,Buffer.from(r.data,'base64'),{flag:'wx'});receipt.output=file;}
 else if(action==='back'){const h=await call('Page.getNavigationHistory',{},sid),entry=h.entries[h.currentIndex-1];if(!entry||!allowed(entry.url))throw Error('History leaves allowed origin/route');await call('Page.navigateToHistoryEntry',{entryId:entry.id},sid);}
 else throw Error('Unknown action');
 if(action!=='init')receipt.after=await foreground(sid);receipt.ok=true;await call('Target.detachFromTarget',{sessionId:sid});
}catch(e){receipt.ok=false;receipt.error=String(e.stack);process.exitCode=1;}finally{fs.writeFileSync(path.join(R,`action-${String(number).padStart(3,'0')}.json`),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));close();}
function allowed(url){return config.allowedRoutes.some(p=>url===server.url+p);}
