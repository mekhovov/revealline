import { existsSync, readFileSync, appendFileSync, realpathSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const meta = JSON.parse(readFileSync(new URL('./manifest.json', import.meta.url)));
const sourceRoot = `${realpathSync(meta.root)}/after/`;
const prefix = pathToFileURL(sourceRoot).href;
const log = new URL('./loaded-modules.jsonl', import.meta.url);
const env = { ...process.env, GIT_NO_LAZY_FETCH: '1', GIT_OPTIONAL_LOCKS: '0' };
const baselineRuntime = process.env.ACTOR_A1_BASELINE === '1'
  ? new Set(meta.files.filter(({ path }) => !path.startsWith('game/test/') && !path.startsWith('docs/')).map(({ path }) => path))
  : new Set();

export async function resolve(specifier, context, nextResolve) {
  if (specifier.startsWith('.') || specifier.startsWith('file:')) {
    const url = new URL(specifier, context.parentURL).href;
    if (url.startsWith(prefix) && !url.includes('/node_modules/'))
      return { url, shortCircuit: true };
  }
  return nextResolve(specifier, context);
}

export async function load(url, context, nextLoad) {
  if (!url.startsWith(prefix) || url.includes('/node_modules/')) return nextLoad(url, context);
  const local = fileURLToPath(url);
  const relative = local.slice(sourceRoot.length);
  const overridden = existsSync(local) && !baselineRuntime.has(relative);
  const source = overridden
    ? readFileSync(local)
    : execFileSync('git', ['-C', meta.repo, 'show', `${meta.base}:${relative}`], {
        env,
        maxBuffer: 8 * 1024 * 1024,
      });
  appendFileSync(log, JSON.stringify({ path: relative, source: overridden ? 'temporary-file' : meta.base, sha256: createHash('sha256').update(source).digest('hex') }) + '\n');
  return { format: url.endsWith('.json') ? 'json' : 'module', source, shortCircuit: true };
}
