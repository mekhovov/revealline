import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {buildOptionalPractice} from '/private/tmp/fpv-delivery-review-20261004/scripts/build-optional-practice.mjs';
import {readEditionZip} from '/private/tmp/fpv-delivery-review-20261004/publishing/edition-zip.mjs';
const root='/private/tmp/fpv-delivery-review-20261004', baseline='0a1548fd29bd4f4fce741c2917d2c07d8bdbb63b', admitted='/private/tmp/fpv-visual-capacity-admission-d9ac';
const git=(...args)=>execFileSync('git',args,{cwd:root,env:{...process.env,GIT_NO_LAZY_FETCH:'1'},maxBuffer:25*1024*1024});
const hash=b=>createHash('sha256').update(b).digest('hex');
const staging=await fs.mkdtemp('/private/tmp/fpv-visual-baseline-inputs-');
const rows=[];
for(const packageId of ['civilian-flight','civilian-fpv','fpv-worlds']){
 const inventory=JSON.parse(await fs.readFile(path.join(admitted,`source-inventory-optional-${packageId}.json`),'utf8'));
 const differences=[];
 for(const item of inventory.inputs){
  const original=git('show',baseline+':'+item.path);
  const current=await fs.readFile(path.join(root,item.path));
  assert.equal(hash(current),item.sha256,item.path);
  if(!original.equals(current))differences.push(item.path);
  const target=path.join(staging,item.path);await fs.mkdir(path.dirname(target),{recursive:true});await fs.writeFile(target,original);
 }
 assert.deepEqual(differences,packageId!=='civilian-flight'?['optional-practice/civilian-fpv/world-visuals.mjs']:[]);
 const original=await buildOptionalPractice(staging,{packageId,basePath:'/revealline/',engineCommit:baseline,engineTree:git('rev-parse',baseline+'^{tree}').toString().trim()});
 const after=readEditionZip(await fs.readFile(path.join(admitted,`distribution-optional-${packageId}.zip`)));
 const before=new Map(original.entries.map(x=>[x.name,x.bytes]));
 assert.deepEqual([...before.keys()].sort(),[...after.keys()].sort());
 const changed=[];let unchanged=0;
 for(const [name,bytes] of before){if(bytes.equals(after.get(name)))unchanged++;else changed.push(name);}
 const generated=new Set(['optional-package.json','launcher/worker.js',original.manifest.entry.replace('index.html','worker.js')]);
 const unexpected=changed.filter(x=>!generated.has(x)&&x!=='optional-practice/civilian-fpv/world-visuals.mjs');
 assert.deepEqual(unexpected,[]);
 rows.push({packageId,sourceInputs:inventory.inputs.length,sourceDifferences:differences,sourceBytes:inventory.inputs.reduce((n,x)=>n+x.bytes,0),runtimeMembers:after.size,unchangedPayloadMembers:unchanged,changedMembers:changed,baselinePackageRevision:original.manifest.revision,candidateArchiveSHA256:hash(await fs.readFile(path.join(admitted,`distribution-optional-${packageId}.zip`)))});
}
console.log(JSON.stringify({format:'FPVWorldVisualPackageComparison.v1',baseline,candidate:git('rev-parse','HEAD').toString().trim(),baselineMethod:'Each original input read from exact baseline Git object; unchanged committed builder; comparison only, not a historical admission claim.',staging,packages:rows},null,2));
