import fs from 'node:fs/promises';
import {FPV_EXERCISE_CASES} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/observe-practice-first-flight.mjs';
const full=JSON.parse(await fs.readFile('/private/tmp/practice-current-production-directory-20261018-plan.json','utf8'));
const plan=Object.fromEntries(['bundle','envelopeSha256','sourceRevision','sourceTree','packageRevision'].map(k=>[k,full[k]]));
Object.assign(plan,{format:'revealline-practice-fpv-exercise-plan.v1',protocol:'practice-exercise-public-ui.fpv.v1',caseId:'integrated-3c6ac5ee0-fpv-eight-exercises',deviceLabel:'Local macOS arm64, Google Chrome 155.0.8059.85, headless 1440x900',quietWindow:'Local bounded exercise verification, not exclusive machine access or a performance-budget approval.',cases:FPV_EXERCISE_CASES.map(x=>x.id)});
await fs.writeFile('/private/tmp/practice-current-fpv-exercise-20261018-plan.json',JSON.stringify(plan,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({cases:plan.cases}));
