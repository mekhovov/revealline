import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
const distribution='/private/tmp/practice-tuning-upload-fixed-20261018-production';
const plan={
  format:'revealline-practice-directory-production-personal-appearance-plan.v2',
  protocol:'practice-directory-production-personal-appearance.v2',
  caseId:'integrated-3c6ac5ee0-production-six-routes',
  deviceLabel:'Local macOS arm64, installed Google Chrome 155.0.8059.85, headless 1440x900',
  quietWindow:'Local diagnostic window; no claim of exclusive machine resources or approved performance budget. Original output checked before/after; no publication.',
  cases:['en-civilian-flight','en-civilian-fpv','en-fpv-worlds','uk-civilian-flight','uk-civilian-fpv','uk-fpv-worlds'],
  bundle:'/Volumes/alex/CodexMigrationStaging/flight-practice-tuning-upload-fixed-20261018-candidate',
  envelopeSha256:'6e526b6438afd02cdad71e164af699c2c5cb15cc52a0dd90b65c3feed8f04f49',
  sourceRevision:'3c6ac5ee0f524a1c3a456316b978cf4e0043e06c',
  sourceTree:'ad8f538f6378cd22ea053fc1f56f0d0d370885af',
  packageRevision:'75a7f259037962508f8ca64a7208911fa75e50ac20de81d3898e1738e440a287',
  shellRevision:'3c6ac5ee0f524a1c3a456316b978cf4e0043e06c',
  shellTree:'ad8f538f6378cd22ea053fc1f56f0d0d370885af',
  observerRevision:'b8e0182de344fba5bf1541ddca753ac7769bdd60',
  observerTree:'98f8925d2d9825ef87d694eb42c196d55f8292a5',
  distribution,
  distributionManifestSha256:createHash('sha256').update(await fs.readFile(distribution+'/manifest.json')).digest('hex')
};
await fs.writeFile('/private/tmp/practice-current-production-directory-20261018-plan.json',JSON.stringify(plan,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(plan));
