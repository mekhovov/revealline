import fs from 'node:fs/promises';
import {GYM_EXERCISE_CASES} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/observe-practice-first-flight.mjs';
const plan=JSON.parse(await fs.readFile('/private/tmp/practice-current-fpv-exercise-20261018-plan.json','utf8'));
Object.assign(plan,{format:'revealline-practice-gym-exercise-plan.v1',protocol:'practice-exercise-public-ui.gym.v1',caseId:'integrated-3c6ac5ee0-gym-two-exercises',packageRevision:'9abf0c12a458534dd617d66be9b72852aa81aa46b87b5d60a96116fa4e774e4d',cases:GYM_EXERCISE_CASES.map(x=>x.id)});
await fs.writeFile('/private/tmp/practice-current-gym-exercise-20261018-plan.json',JSON.stringify(plan,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({cases:plan.cases}));
