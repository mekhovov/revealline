import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readEditionZip} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
const root='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const output='/private/tmp/practice-gym-active-upgrade-20261018';
const hash=b=>createHash('sha256').update(b).digest('hex');
const raw=await fs.readFile(output+'.json'),r=JSON.parse(raw),s=r.activeSession,w=s.browserConfiguration;
assert(r.passed&&!r.qualified&&!r.publicEligible&&r.cleanup.temporaryProfileRemoved);
assert.deepEqual(r.cleanup.errors,[]);assert.deepEqual(r.errors,[]);
assert.equal(r.sourceRevision,'3c6ac5ee0f524a1c3a456316b978cf4e0043e06c');
assert.equal(r.envelopeSha256,'6e526b6438afd02cdad71e164af699c2c5cb15cc52a0dd90b65c3feed8f04f49');
assert.equal(hash(await fs.readFile(root+'/scripts/observe-optional-installation.mjs')),r.harnessSha256);
assert.equal(hash(await fs.readFile(root+'/scripts/optional-installation-observer-helpers.mjs')),r.helperSha256);
assert.equal(hash(await fs.readFile(root+'/scripts/optional-installation-active-session.mjs')),s.sourceSha256);
assert(s.passed&&s.sourceStable&&s.cleanup.completed&&!s.cleanup.pendingOwned&&!s.cleanup.lateOwnershipFailure);
assert.equal(s.packageId,'civilian-flight');assert.equal(s.mode,'gym-v0.142.4-98ad851');
assert.equal(s.deadlineMs,30000);assert(s.witnesses.at(-1).elapsedMs<30000);
const transfer=s.witnesses.find(x=>x.kind.startsWith('natural transfer'));
const returned=s.witnesses.find(x=>x.kind==='return focus did not resume for 600ms');
const motion=s.witnesses.find(x=>x.kind==='explicit resumed motion after update');
assert(transfer&&!transfer.focused&&transfer.phase==='paused'&&transfer.height>0.2);
assert(returned?.focused&&returned.phase==='paused');assert.equal(returned.height,transfer.height);
assert(motion?.phase==='active'&&motion.height>=returned.height+0.099999);
assert(s.menuPauses.length===2&&s.menuPauses.every(x=>!x.numericMeasurement&&x.intervalMs===600&&x.before.homeVisible&&x.after.homeVisible));
assert.equal(s.update.activeVersion,'v0.151.1');assert.equal(s.update.previousVersion,'v0.142.4');
assert(w.activated&&w.returned&&w.configured&&w.standaloneObserved&&w.sourceStable&&w.cleanup.completed);
assert(w.operations.every(x=>!x.pending));assert(w.transfer.passed&&w.returnObservation.passed);
assert.notEqual(w.a.windowId,w.b.windowId);assert.equal(w.packageId,'civilian-flight');
assert(w.transfer.observations.some(x=>x.events.some(e=>e.trusted&&!e.focused&&e.at>=x.armedAt)));
assert.equal(hash(await fs.readFile(root+'/scripts/optional-installation-pwa-activation.mjs')),w.sourceSha256);
assert(r.migration.passed&&r.migration.sourceStable&&r.worldSeed.passed&&r.worldSeed.sourceStable);
for(const f of [...r.migration.authority,...r.historicalAuthority])assert.equal(hash(await fs.readFile(root+'/scripts/'+f.path)),f.sha256);
assert.equal(r.migration.checks.length,7);assert.equal(r.worldSeed.checks.length,7);assert.equal(r.checkpoints.length,10);
for(const c of r.migration.checks){assert.equal(c.proofSha256,r.proof.sha256);assert.equal(c.profileSha256,r.profiles.sha256);}
for(const c of r.worldSeed.checks){assert.deepEqual(c.card,r.worldSeed.baseline.card);assert.deepEqual(c.database,r.worldSeed.baseline.database);}
assert(r.proof.synthetic);assert.equal(r.profiles.radioVerified,false);
const eligible=new Map();let archiveMembers=0;
for(const base of ['/Volumes/alex/CodexMigrationStaging/flight-practice-previous-v01424-20261016-candidate','/Volumes/alex/CodexMigrationStaging/flight-practice-tuning-upload-fixed-20261018-candidate']){const e=JSON.parse(await fs.readFile(base+'/optional-packages.json'));for(const pkg of e.packages){const zip=await fs.readFile(path.join(base,pkg.distribution.path));assert.equal(hash(zip),pkg.distribution.sha256);for(const [name,b] of readEditionZip(zip)){for(const n of [`/revealline/practice/${pkg.id}/releases/${e.version}/site/${name}`,...(name.startsWith('launcher/')?[`/revealline/practice/${pkg.id}/app/${name.slice(9)}`]:[])]){const list=eligible.get(n)||[];list.push({bytes:b.length,sha256:hash(b)});eligible.set(n,list);}archiveMembers++;}}}
let cachedRows=0;
for(const check of r.migration.checks)for(const cache of check.cacheFingerprints)for(const f of cache.files){assert(eligible.get(new URL(f.url).pathname)?.some(x=>x.sha256===f.sha256&&x.bytes===f.bytes));cachedRows++;}
const image=await fs.readFile(s.screenshot.path);assert.equal(image.length,s.screenshot.bytes);assert.equal(hash(image),s.screenshot.sha256);
const log=await fs.readFile(output+'.log','utf8'),consoleReceipt=JSON.parse(log.trim());
assert(consoleReceipt.passed&&consoleReceipt.osApps.length===1);assert(consoleReceipt.osApps.every(x=>x.id==='civilian-flight'&&x.installed&&x.uninstalled&&x.window.standalone));
const result={format:'PracticeGymActiveUpgradeAudit.v1',passed:true,receiptSha256:hash(raw),observerSource:'b8e0182de344fba5bf1541ddca753ac7769bdd60',runtimeSource:r.sourceRevision,browser:r.browser,selectedActiveApp:'civilian-flight',nativeTrustedBlur:true,sameDocumentAndTimeOrigin:'Asserted by source-pinned helper before/after update; no raw identity token is exported.',visiblePausedHeight:transfer.height,resumedHeight:motion.height,activeSessionElapsedMs:s.witnesses.at(-1).elapsedMs,allPackageUpgradeRollbackCheckpoints:10,worldFingerprints:7,archiveMembersVerified:archiveMembers,cachedDependencyRowsPinned:cachedRows,osAppUninstalled:true,profileRemoved:true,syntheticSharedProofExplicit:true,scope:'Genuine old/new all-three migration and rollback, one installed historical Gym short-session continuity. No Worlds active-session, background-flight, exact-tick, physical input, human, performance or publication approval.'};
await fs.writeFile(output+'-audit.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
