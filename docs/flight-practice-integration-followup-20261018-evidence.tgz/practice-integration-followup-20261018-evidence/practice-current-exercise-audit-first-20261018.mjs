import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readEditionZip} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
import {verifyFrozenFPVExercise} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/practice-fpv-exercise-replay.mjs';
import {verifyFrozenGymTranscript} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/practice-exercise-replay.mjs';
const root='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const bundle='/Volumes/alex/CodexMigrationStaging/flight-practice-tuning-upload-fixed-20261018-candidate';
const hash=b=>createHash('sha256').update(b).digest('hex');
const envelope=JSON.parse(await fs.readFile(bundle+'/optional-packages.json'));
const maps=new Map();for(const p of envelope.packages){const b=await fs.readFile(path.join(bundle,p.distribution.path));assert.equal(hash(b),p.distribution.sha256);maps.set(p.id,readEditionZip(b));}
for(const kind of ['fpv','gym']){
 const out=`/private/tmp/practice-current-${kind}-exercise-20261018`,raw=await fs.readFile(out+'/observation.json'),r=JSON.parse(raw);
 assert(r.completed&&r.procedureComplete&&!r.qualified&&r.cleanup.completed);
 assert.equal(r.plan.sourceRevision,'3c6ac5ee0f524a1c3a456316b978cf4e0043e06c');
 assert.equal(r.cases.length,kind==='fpv'?8:2);
 for(const a of r.authority){assert.equal(hash(await fs.readFile(path.join(root,a.path))),a.sha256);assert.equal(hash(await fs.readFile(path.join(out,'authority',path.basename(a.path)))),a.sha256);}
 assert(r.resourceAcquisitions.every(x=>!x.pending&&!x.timedOut));
 const cases=[];
 for(const c of r.cases){assert(c.passed&&c.independentReplayVerified&&c.exercise.nativeCompleted);assert.deepEqual(c.errors,[]);assert(c.exercise.cleanup.keysReleased);assert.deepEqual(c.exercise.cleanup.errors,[]);
  const f=kind==='fpv'?c.export.file:c.exercise.transcript.exportedFile;
  const b=await fs.readFile(path.join(out,f.path));assert.equal(b.length,f.bytes);assert.equal(hash(b),f.sha256);
  const replay=kind==='fpv'?await verifyFrozenFPVExercise(maps.get(c.package),b.toString(),{packageId:c.package,mode:c.mode}):await verifyFrozenGymTranscript(maps.get(c.package),b.toString());
  assert(replay.verified);const old=kind==='fpv'?c.independentReplay:c.exercise.independentReplay;
  assert.deepEqual(replay.inputs,old.inputs);
  if(kind==='fpv'){assert.equal(replay.identity,old.identity);assert.equal(replay.frames,old.frames);assert.equal(replay.state.status,'complete');}else assert.equal(replay.snapshot.status,'complete');
  const image=await fs.readFile(path.join(out,c.completionScreenshot.path));assert.equal(hash(image),c.completionScreenshot.sha256);
  cases.push({id:c.id,package:c.package,locale:c.locale,mode:c.mode,nativeCompleted:true,actualExportSha256:f.sha256,independentlyReplayedAgain:true,replayDependencyCount:replay.inputs.length,completedState:kind==='fpv'?replay.state.status:replay.snapshot.status});
 }
 const result={format:'PracticeCurrentExerciseAudit.v1',passed:true,kind,source:r.plan.sourceRevision,receiptSha256:hash(raw),cases,scope:'Actual local-browser beginner exercise exports and exact-package independent replay. Vertical Acro exercise is not rotational proficiency, physical input or human learning. No origin-loss recovery, speech, performance-budget or public release approval.'};
 await fs.writeFile(out+'/audit.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({kind,passed:true,cases:cases.length,receiptSha256:result.receiptSha256}));
}
