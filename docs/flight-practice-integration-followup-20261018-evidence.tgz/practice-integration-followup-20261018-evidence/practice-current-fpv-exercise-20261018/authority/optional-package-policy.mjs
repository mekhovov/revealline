/** Explicit opt-in package admission. New packages need a reviewed policy entry;
 * an uploaded archive cannot widen its own executable dependency allowance. */
const SHARED_MISSION_BROWSER_LABELS = Object.freeze([
  'all',
  'allCampaigns',
  'allMissionsOneLibraryJourneyClassicAndCustomKeepTheir',
  'campaign',
  'clearSearch',
  'collection',
  'current',
  'detailedMissionCards',
  'downloadCancelledYourCurrentGameIsKept',
  'downloadPlay',
  'filters',
  'filtersActive',
  'findYourNextLine',
  'missionCampaignEditionOrTag',
  'missionNotOpenedYourCurrentGameIsKept',
  'mode',
  'noReadyLevelsMatchTheseFilters',
  'playRandomLevelFromVisibleResults',
  'preparing',
  'randomLevel',
  'searchAllMissions',
  'skippedTryAgain',
  'solo2',
  'team',
  'unknownMissionLibraryMode',
  'versus2',
]);
const BASE_OPTIONAL_PACKAGE_POLICIES = Object.freeze({
  'civilian-flight': Object.freeze({
    root: 'optional-practice/civilian-flight/',
    entry: 'optional-practice/civilian-flight/index.html',
    // The installed archive includes the reviewed launcher, access gate and
    // shared menu CSS, battlefield artwork and ambience closure. The runtime has 96 files; the
    // selected source archive adds two reviewed templates within this finite
    // envelope.
    limits: Object.freeze({ files: 98, bytes: 8 * 1024 * 1024 }),
    localFiles: Object.freeze([
      'index.html',
      'app.mjs',
      'audio.mjs',
      'model.mjs',
      'input.mjs',
      'catalogue.mjs',
      'copy.mjs',
      'offline.mjs',
      'style.css',
      'app.webmanifest',
      'README.md',
    ]),
    sharedFiles: Object.freeze([
      'game/ui/mode-play-shell.mjs',
      'game/ui/mode-play-shell.css',
      'game/ui/mode-choice.css',
      'game/ui/optional-practice-panel.css',
      'game/ui/pause-menu.css',
      'game/ui/mode-settings-view.css',
      'game/ui/global-settings-view.css',
      'game/ui/native-menu-icons.mjs',
      'optional-practice/civilian-fpv/input.mjs',
      'optional-practice/civilian-fpv/radio-profile.mjs',
      'optional-practice/civilian-fpv/flight-response.mjs',
      'optional-practice/civilian-fpv/rates.mjs',
      'optional-practice/civilian-fpv/world-audio.mjs',
      'optional-practice/civilian-fpv/flight-fullscreen.mjs',
      'optional-practice/civilian-fpv/flight-fullscreen.css',
      'optional-practice/civilian-fpv/sim-presentation.mjs',
      'optional-practice/civilian-fpv/math.mjs',
      'optional-practice/civilian-fpv/rotation-table.mjs',
      'optional-practice/civilian-fpv/world-themes.mjs',
      'game/presentation/theme-system.mjs',
      'game/ui/audio-output.mjs',
      'game/ui/audio-master.mjs',
      'game/audio-preferences.mjs',
      'game/audio/dialogue-mix.mjs',
      'game/ui/destruction-audio.mjs',
      'game/ui/encounter-audio.mjs',
      'game/ui/world-ambience.mjs',
      'game/ui/movement-audio.mjs',
      'game/ui/dialogue-channel.mjs',
      'optional-practice/install-context.mjs',
      'game/data-json.mjs',
      'game/key-bindings.mjs',
      'game/i18n/index.mjs',
      'game/i18n/bootstrap.mjs',
      'game/i18n/catalogs.mjs',
      'game/vendor/i18next-26.4.2.min.js',
      'game/vendor/I18NEXT-LICENSE.txt',
    ]),
    template: 'optional-practice/civilian-flight/worker-template.mjs',
    launcherTemplate: 'optional-practice/launcher-template.mjs',
    localeInputs: Object.freeze([
      'game/locales/en/errors.json',
      'game/locales/uk/errors.json',
      'game/locales/en/interface.json',
      'game/locales/uk/interface.json',
      'game/locales/en/common.json',
      'game/locales/uk/common.json',
    ]),
    localeKeys: Object.freeze({
      interface: Object.freeze([
        'audioVolumeMustBeBetweenZeroAndOne',
        'audioMuteMustBeABoolean',
        'audioMasterOutputCouldNotBeApplied',
        'audioMasterIsDisposed',
        'audioMasterListenerRequired',
        'audioMasterListenerAlreadySubscribed',
        'workshop.familyId',
        'workshop.arcadeArt',
        'workshop.existing',
        'workshop.industrial',
        'workshop.authored',
        'workshop.followGame',
        'workshop.highContrast',
        'workshop.opaqueHud',
        'workshop.help',
        'workshop.appearance',
        'workshop.ornaments',
        'workshop.followContext',
        'workshop.applyComplete',
        'workshop.previewThemes',
        'workshop.customize',
        'workshop.customized',
        'workshop.themeDetail',
        'workshop.detailOff',
        'workshop.detailSubtle',
        'workshop.detailRich',
        'workshop.description.military-field',
        'workshop.theme.military-field',
        'workshop.theme.legacy',
        'workshop.theme.industrial-workshop',
        'workshop.theme.ember-foundry',
        'workshop.description.ember-foundry',
        'workshop.theme.polar-relay',
        'workshop.description.polar-relay',
        'workshop.theme.vyshyvanka',
        'workshop.theme.dnipro-porcelain',
        'workshop.theme.tryzub',
        'workshop.theme.windows-classic',
        'workshop.theme.dos',
        'workshop.theme.orchard-workshop',
        'workshop.theme.neon-ruins',
        'workshop.description.industrial-workshop',
        'workshop.description.vyshyvanka',
        'workshop.description.dnipro-porcelain',
        'workshop.description.tryzub',
        'workshop.description.windows-classic',
        'workshop.description.dos',
        'workshop.description.orchard-workshop',
        'workshop.description.neon-ruins',
        'workshop.notice.stylesheetUnavailable',
        'workshop.notice.readOnly',
        'workshop.notice.saveFailed',
        'workshop.notice.simSaveFailed',
        'workshop.notice.themeUnavailable',
        'workshop.description.copper-observatory',
        'workshop.description.curated',
        'workshop.theme.copper-observatory',
        'workshop.description.sakura-station',
        'workshop.description.legacy',
        'workshop.theme.sakura-station',
        'workshop.description.pocket-lcd',
        'workshop.theme.pocket-lcd',
        'workshop.description.follow-game',
        'workshop.theme.obsidian-reliquary',
        'workshop.description.obsidian-reliquary',
        'workshop.theme.deep-space',
        'workshop.description.deep-space',
        'workshop.theme.moonlit-grove',
        'workshop.description.moonlit-grove',
        'workshop.materialPreview.mission',
        'workshop.materialPreview.launch',
        'workshop.materialPreview.hover',
        'workshop.materialPreview.pressed',
        'workshop.materialPreview.focus',
        'workshop.materialPreview.loading',
        'workshop.materialPreview.disabled',
        'workshop.materialPreview.detail',
        'workshop.materialPreview.balanced',
        'workshop.materialPreview.detailed',
        'workshop.materialPreview.telemetry',
      ]),
      common: Object.freeze([
        'menuSounds',
        'menuVolume',
        'radioSounds',
        'radioVolume',
        'movementSounds',
        'movementVolume',
      ]),
    }),
    licenses: Object.freeze([
      {
        dependency: 'i18next',
        version: '26.4.2',
        license: 'MIT',
        path: 'game/vendor/I18NEXT-LICENSE.txt',
      },
    ]),
  }),
  'civilian-fpv': Object.freeze({
    root: 'optional-practice/civilian-fpv/',
    entry: 'optional-practice/civilian-fpv/index.html',
    limits: Object.freeze({ files: 64, bytes: 8 * 1024 * 1024 }),
    localFiles: Object.freeze([
      'index.html',
      'app.mjs',
      'renderer.mjs',
      'world-visuals.mjs',
      'world-themes.mjs',
      'input.mjs',
      'copy.mjs',
      'style.css',
      'app.webmanifest',
      'README.md',
      'radio-controls.mjs',
      'radio-profile.mjs',
      'radio-runtime.mjs',
      'radio-session.mjs',
      'radio-setup.mjs',
      'radio-guide.mjs',
      'flight-fullscreen.mjs',
      'sim-presentation.mjs',
      'math.mjs',
      'rotation-table.mjs',
      'model.mjs',
      'flight-sectors.mjs',
      'flight-contact.mjs',
      'flight-support.mjs',
      'catalogue.mjs',
      'demonstrations.mjs',
      'attempts.mjs',
      'notebook.mjs',
      'studio.mjs',
      'offline.mjs',
      'vendor/three.core.js',
      'vendor/three.module.js',
      'vendor/LICENSE.txt',
    ]),
    sharedFiles: Object.freeze([
      'optional-practice/install-context.mjs',
      'game/data-json.mjs',
      'game/fpv-entry.mjs',
      // The renderer is shared with World Studio, including its optional hunt art.
      'game/hunt/actor-catalog.mjs',
      'game/hunt/preferences.mjs',
      'game/presentation/theme-system.mjs',
      'game/ui/native-menu-icons.mjs',
      'game/key-bindings.mjs',
      'game/i18n/index.mjs',
      'game/i18n/bootstrap.mjs',
      'game/i18n/catalogs.mjs',
      'game/vendor/i18next-26.4.2.min.js',
      'game/vendor/I18NEXT-LICENSE.txt',
      'game/profile-storage.mjs',
      'game/profile-database.mjs',
      'game/rewards/store.mjs',
      'game/rewards/model.mjs',
      'game/rewards/audio-groups.mjs',
      'game/rewards/exploration.mjs',
      'game/rewards/learning-profiles.mjs',
      'game/ui/reward-knowledge.mjs',
    ]),
    template: 'optional-practice/worker-template.mjs',
    launcherTemplate: 'optional-practice/launcher-template.mjs',
    localeInputs: Object.freeze([
      'game/locales/en/errors.json',
      'game/locales/uk/errors.json',
      'game/locales/en/interface.json',
      'game/locales/uk/interface.json',
      'game/locales/en/common.json',
      'game/locales/uk/common.json',
    ]),
    localeKeys: Object.freeze({
      interface: Object.freeze([
        'learningProfiles.choose',
        'workshop.familyId',
        'workshop.arcadeArt',
        'workshop.existing',
        'workshop.industrial',
        'workshop.authored',
        'workshop.followGame',
        'workshop.highContrast',
        'workshop.opaqueHud',
        'workshop.help',
        'workshop.appearance',
        'workshop.ornaments',
        'workshop.followContext',
        'workshop.applyComplete',
        'workshop.previewThemes',
        'workshop.customize',
        'workshop.customized',
        'workshop.themeDetail',
        'workshop.detailOff',
        'workshop.detailSubtle',
        'workshop.detailRich',
        'workshop.description.military-field',
        'workshop.theme.military-field',
        'workshop.theme.legacy',
        'workshop.theme.industrial-workshop',
        'workshop.theme.ember-foundry',
        'workshop.description.ember-foundry',
        'workshop.theme.polar-relay',
        'workshop.description.polar-relay',
        'workshop.theme.vyshyvanka',
        'workshop.theme.dnipro-porcelain',
        'workshop.theme.tryzub',
        'workshop.theme.windows-classic',
        'workshop.theme.dos',
        'workshop.theme.orchard-workshop',
        'workshop.theme.neon-ruins',
        'workshop.description.industrial-workshop',
        'workshop.description.vyshyvanka',
        'workshop.description.dnipro-porcelain',
        'workshop.description.tryzub',
        'workshop.description.windows-classic',
        'workshop.description.dos',
        'workshop.description.orchard-workshop',
        'workshop.description.neon-ruins',
        'workshop.notice.stylesheetUnavailable',
        'workshop.notice.readOnly',
        'workshop.notice.saveFailed',
        'workshop.notice.simSaveFailed',
        'workshop.notice.themeUnavailable',
        'workshop.description.copper-observatory',
        'workshop.description.curated',
        'workshop.theme.copper-observatory',
        'workshop.description.sakura-station',
        'workshop.description.legacy',
        'workshop.theme.sakura-station',
        'workshop.description.pocket-lcd',
        'workshop.theme.pocket-lcd',
        'workshop.description.follow-game',
        'workshop.theme.obsidian-reliquary',
        'workshop.description.obsidian-reliquary',
        'workshop.theme.deep-space',
        'workshop.description.deep-space',
        'workshop.theme.moonlit-grove',
        'workshop.description.moonlit-grove',
        'workshop.materialPreview.mission',
        'workshop.materialPreview.launch',
        'workshop.materialPreview.hover',
        'workshop.materialPreview.pressed',
        'workshop.materialPreview.focus',
        'workshop.materialPreview.loading',
        'workshop.materialPreview.disabled',
        'workshop.materialPreview.detail',
        'workshop.materialPreview.balanced',
        'workshop.materialPreview.detailed',
        'workshop.materialPreview.telemetry',
      ]),
      common: Object.freeze([
        'menuSounds',
        'menuVolume',
        'radioSounds',
        'radioVolume',
        'movementSounds',
        'movementVolume',
      ]),
    }),
    // Official npm tarball integrity verified before selecting these exact files.
    // Only these reviewed bytes may include dormant native network-loader code.
    vendorPins: Object.freeze([
      Object.freeze({
        path: 'optional-practice/civilian-fpv/vendor/three.core.js',
        bytes: 1458113,
        sha256: '9edde002b066a9a05676a6127f67735b62baf399bdea529f2f7e31657da769e6',
      }),
      Object.freeze({
        path: 'optional-practice/civilian-fpv/vendor/three.module.js',
        bytes: 662772,
        sha256: '9052042d676cb0fdc1ddfefe193053f34b7ac0513a616fdac4535d49987812ea',
      }),
      Object.freeze({
        path: 'optional-practice/civilian-fpv/vendor/LICENSE.txt',
        bytes: 1081,
        sha256: '8b378ebe60e2fe500158cb0ac71cb5e8b7d92953c2abcc63a0eb90499653b5bc',
      }),
    ]),
    licenses: Object.freeze([
      {
        dependency: 'Exo 2, Departure Mono, IBM Plex Mono and Handjet UI fonts',
        version: 'Exo 2 2.010 / Departure Mono 1.500 / IBM Plex Mono 2.3 / Handjet 2.003',
        license: 'OFL-1.1',
        path: 'optional-practice/civilian-fpv/README.md',
      },
      {
        dependency: 'Kenney Interface Sounds and UI Audio selected cues',
        version: 'RevealLine prepared bank 2026-09-29',
        license: 'CC0-1.0',
        path: 'optional-practice/civilian-fpv/README.md',
      },
      {
        dependency: 'i18next',
        version: '26.4.2',
        license: 'MIT',
        path: 'game/vendor/I18NEXT-LICENSE.txt',
      },
      {
        dependency: 'three',
        version: '0.186.1',
        license: 'MIT',
        path: 'optional-practice/civilian-fpv/vendor/LICENSE.txt',
        source: 'https://registry.npmjs.org/three/-/three-0.186.1.tgz',
        integrity:
          'sha512-blFeqb49wRCSGUGj7gtpfnSGHy2lwDk94RhUmS1c/hTby70kvChbWpkJ4Pm1390LqzzvTmzgXKHPEafJwCb8jA==',
      },
    ]),
  }),
});

// The legacy 8 MiB / 64-file package stays independent. The world runtime is a
// separately selected application with its own explicit executable closure.
const legacyFPV = BASE_OPTIONAL_PACKAGE_POLICIES['civilian-fpv'];
const RUNTIME_PACKAGE_POLICIES = Object.freeze({
  ...BASE_OPTIONAL_PACKAGE_POLICIES,
  'fpv-worlds': Object.freeze({
    ...legacyFPV,
    root: 'optional-practice/fpv-worlds/',
    entry: 'optional-practice/fpv-worlds/index.html',
    limits: Object.freeze({ files: 96, bytes: 16 * 1024 * 1024 }),
    localFiles: Object.freeze([
      'index.html',
      'advanced-worker.mjs',
      'response-bench-worker.mjs',
      'app.webmanifest',
      'README.md',
      'SCENERY-LICENSES.txt',
      'scenery-provenance.json',
    ]),
    sharedFiles: Object.freeze([
      ...legacyFPV.localFiles
        // World has its own UI copy and course editor; the Academy-only modules
        // are not reachable from this application's explicit dependency graph.
        .filter(
          (name) =>
            ![
              'index.html',
              'app.mjs',
              'app.webmanifest',
              'README.md',
              'copy.mjs',
              'studio.mjs',
            ].includes(name),
        )
        .map((name) => legacyFPV.root + name),
      // The FPV input runtime owns its bindings. This older helper is used only
      // by civilian-flight, whose independent package continues to admit it.
      ...legacyFPV.sharedFiles.filter((name) => name !== 'game/key-bindings.mjs'),
      'optional-practice/civilian-fpv/README.md',
      // World Studio renders the image wordmark; Academy uses its text brand.
      'game/ui/art/identity/fpv-line/wordmark.png',
      'game/ui/art/menu-scenes/fpv.webp',
      'game/ui/art/menu-scenes/fpv-portrait.webp',
      'game/hunt/actor-art.mjs',
      'game/presentation/actor-animation.mjs',
      'optional-practice/civilian-fpv/world-pursuit.mjs',
      'optional-practice/civilian-fpv/native-pursuit-courses.mjs',
      'game/hunt/presentation-catalog.mjs',
      'game/encounter-display-preferences.mjs',
      ...[
        'vendor/addons/loaders/GLTFLoader.js',
        'vendor/addons/controls/TransformControls.js',
        'vendor/addons/utils/BufferGeometryUtils.js',
        'vendor/addons/utils/SkeletonUtils.js',
        'vendor/addons/provenance.json',
        'world-app.mjs',
        // Explicit unscored regional review closure; no catalogue or source assets.
        'regional-session.mjs',
        'regional-locations.mjs',
        'regional-delivery.mjs',
        'regional-library.mjs',
        'regional/flight-prototype.mjs',
        'regional/frame-transaction.mjs',
        'regional/restore-containment.mjs',
        'regional/indexed-scenery-cell.mjs',
        'regional/region-manifest.mjs',
        'regional/region-motion-query.mjs',
        'regional/scenery-admission.mjs',
        'regional/scenery-cell.mjs',
        'regional/rgba-scenery-cell.mjs',
        'regional/scenery-surface.mjs',
        'regional/source-window.mjs',
        'regional/terrain-admission.mjs',
        'regional/terrain-cell.mjs',
        'regional/terrain-normals.mjs',
        'regional/terrain-surface.mjs',
        'regional/urban-ground-surface.mjs',
        'regional/railway-expanse-ground.mjs',
        'regional/hillside-ground-surface.mjs',
        'regional/verified-flight-geometry.mjs',
        'regional/verified-mixed-window.mjs',
        'regional/verified-scenery-window.mjs',
        'regional/verified-terrain-window.mjs',
        'industrial-environment.mjs',
        // Checked projection of shared reactions plus four canonical presentation utilities.
        // The bounded projection shares common utilities; native pursuit uses the reviewed 128-file / 20 MiB envelope.
        'world-reaction-runtime.mjs',
        'world-records.mjs',
        'world-store.mjs',
        'world-zip.mjs',
        'beginner-coach.mjs',
        'world-demonstrations.mjs',
        'world-assets.mjs',
        'world-editor.mjs',
        'content-definitions.mjs',
        'world-catalogue.mjs',
        'world-collision.mjs',
        'flight-contact.mjs',
        'flight-support.mjs',
        'world-model.mjs',
        'snake-hunt.mjs',
        'snake-hunt-catalogue.mjs',
        'expressive-hunt-courses.mjs',
        'snake-hunt-presentation.mjs',
        'world-content.mjs',
        'world-style.css',
        'playlists.mjs',
        'vendor/rapier/rapier.mjs',
        'vendor/rapier/LICENSE',
        'vendor/rapier/provenance.json',
      ].map((name) => legacyFPV.root + name),
    ]),
    vendorPins: Object.freeze([
      ...legacyFPV.vendorPins,
      Object.freeze({
        path: 'optional-practice/civilian-fpv/vendor/addons/loaders/GLTFLoader.js',
        bytes: 117586,
        sha256: '03952cb129d558f92b8e6c757fbf7c1f718b3126c4d34f264d574b40ea36054f',
      }),
      Object.freeze({
        path: 'optional-practice/civilian-fpv/vendor/addons/controls/TransformControls.js',
        bytes: 51722,
        sha256: '10f6d3e4c108dff62110f61a76749f9a1826c9781df9c3eb4ca0b5d9d2f5c4a8',
      }),
      Object.freeze({
        path: 'optional-practice/civilian-fpv/vendor/addons/utils/BufferGeometryUtils.js',
        bytes: 37728,
        sha256: '259085a7dac89e0840393a9347c77123fbc4206ec2146bf0c29ffc72e14a2800',
      }),
      Object.freeze({
        path: 'optional-practice/civilian-fpv/vendor/addons/utils/SkeletonUtils.js',
        bytes: 11551,
        sha256: '28017bf37d0ecb0c4be6048db759ff14df729a562464830b064d4cc239c5af17',
      }),
      {
        path: 'optional-practice/civilian-fpv/vendor/rapier/rapier.mjs',
        bytes: 4340292,
        sha256: '02dc6a4e2fffc013bab08fbb44fa68f501d8303615e9afe4c7d89ad4eedda0d0',
      },
      {
        path: 'optional-practice/civilian-fpv/vendor/rapier/LICENSE',
        bytes: 11343,
        sha256: '4c05555705e3efde601fb1252ae48f1d63992af8a8fb8947745b7fa834e8f519',
      },
    ]),
    licenses: Object.freeze([
      ...legacyFPV.licenses,
      {
        dependency: 'Kenney Retro Urban Kit',
        version: '2021-03-20',
        license: 'CC0-1.0',
        path: 'optional-practice/fpv-worlds/SCENERY-LICENSES.txt',
        source: 'https://opengameart.org/content/retro-urban-kit',
      },
      {
        dependency: 'Kenney City Kit Industrial',
        version: '2.0',
        license: 'CC0-1.0',
        path: 'optional-practice/fpv-worlds/SCENERY-LICENSES.txt',
        source: 'https://kenney.nl/assets/city-kit-industrial',
      },
      {
        dependency: '@dimforge/rapier3d-compat',
        version: '0.21.0',
        license: 'Apache-2.0',
        path: 'optional-practice/civilian-fpv/vendor/rapier/LICENSE',
        source: 'https://registry.npmjs.org/@dimforge/rapier3d-compat/-/rapier3d-compat-0.21.0.tgz',
        integrity:
          'sha512-tCl1HPGwOhn5aCQbgqWbOH+Nx/5fnr3IPAnzQuR7zIhC/raqi2yxC6LhvZqjdI2El5hQgY5RDAwDrAjAi2FdPA==',
      },
    ]),
  }),
});

// The worker entry must be listed explicitly: a URL passed to Worker is not an import.
const FPV_TUNING_FILES = Object.freeze([
  'rates.mjs',
  'flight-response.mjs',
  'tuning-library.mjs',
  'tuning-ui.mjs',
  'setup-draft.mjs',
  'setup-workbench.mjs',
  'aircraft-tuning-fields.mjs',
  'controller-tune-library.mjs',
  'controller-tune-panel.mjs',
  'response-bench.mjs',
  'response-bench-client.mjs',
  'response-bench-worker.mjs',
  'response-bench-panel.mjs',
  'tuning.css',
  'betaflight-import.mjs',
  'advanced-controller.mjs',
  'advanced-terrain.mjs',
  'advanced-simulation.mjs',
  'advanced-aircraft-runtime.mjs',
  'aircraft-physics.mjs',
  'aircraft-response.mjs',
  'aircraft-presets.mjs',
  'aircraft-appearance.mjs',
  'aircraft-preview.mjs',
  'aircraft-recording.mjs',
  'aircraft-terrain.mjs',
  'aircraft-course-session.mjs',
  'aircraft-mission-checkpoint.mjs',
  'aircraft-practice-controls.mjs',
  'aircraft-course-advice.mjs',
  'aircraft-archive.mjs',
  'aircraft-archive-controls.mjs',
  'aircraft-archive-verifier.mjs',
  'advanced-ghost-path.mjs',
  'propulsion-evidence.mjs',
  'propulsion-evidence-ui.mjs',
  'aircraft-challenge.mjs',
  'aircraft-challenge-ui.mjs',
  'advanced-worker.mjs',
  'advanced-worker-client.mjs',
  'advanced-practice.mjs',
  'sim-boot.mjs',
]);
const FPV_ADVANCED_ACADEMY_FILES = Object.freeze([
  'world-collision.mjs',
  'vendor/rapier/rapier.mjs',
  'vendor/rapier/LICENSE',
  'vendor/rapier/provenance.json',
]);

// Discovery assets are admitted source inputs, never arbitrary catalogue URLs.
// Pursuit, shared presentation and discovery additions retain finite reviewed envelopes.
export const OPTIONAL_PACKAGE_POLICIES = Object.freeze(
  Object.fromEntries(
    Object.entries(RUNTIME_PACKAGE_POLICIES).map(([id, policy]) => [
      id,
      Object.freeze({
        ...policy,
        // Original aggregate locale files are retained as source hashes, while
        // only selected messages ship. Academy's reviewed input inventory is
        // 13,156,199 bytes with the visual workbench and isolated response bench.
        // The 12 MiB + 704 KiB input allowance retains aggregate locale hashes;
        // those full locale inputs do not ship in standalone SIM archives.
        ...(id === 'civilian-fpv' ? { sourceInputBytes: 12 * 1024 * 1024 + 704 * 1024 } : {}),
        // The canonical browser is projected into an existing package module.
        // Admit only its message families, including plural and dynamic keys.
        localeKeyPrefixes: Object.freeze({
          errors: Object.freeze(['missionLibrary.']),
          interface: Object.freeze(['missionLibrary.', 'missionGoal.']),
          common: Object.freeze(['counts.missions', 'collections.']),
        }),
        localeKeys: Object.freeze({
          ...policy.localeKeys,
          interface: Object.freeze([
            ...new Set([...(policy.localeKeys?.interface ?? []), ...SHARED_MISSION_BROWSER_LABELS]),
          ]),
          common: Object.freeze([
            ...new Set([...(policy.localeKeys?.common ?? []), 'navigation.backToGame']),
          ]),
        }),
        // These optional tools belong to the installed core game, not the SIM
        // archive. Only this literal lazy import may cross that boundary. The
        // SIM keeps its own preferences/backup tools and a visible fallback
        // when the core game is absent or offline. Never admit arbitrary URLs.
        coreOnlyImports: Object.freeze(
          ['civilian-flight', 'civilian-fpv', 'fpv-worlds'].includes(id)
            ? [
                Object.freeze({
                  from: 'optional-practice/civilian-fpv/sim-presentation.mjs',
                  source: '../../game/ui/global-settings-tools.mjs',
                }),
                // Only a verified iOS stage supplies this bridge. Web packages
                // retain browser exports and never evaluate the iOS import.
                Object.freeze({
                  from: 'game/platform.mjs',
                  source: '../native/bridge.mjs',
                }),
              ]
            : [],
        ),
        licenses: Object.freeze([
          ...policy.licenses,
          ...(id === 'civilian-fpv'
            ? RUNTIME_PACKAGE_POLICIES['fpv-worlds'].licenses.filter(
                (license) => license.dependency === '@dimforge/rapier3d-compat',
              )
            : []),
          ...(id === 'civilian-flight'
            ? legacyFPV.licenses.slice(0, 2).map((license) => ({
                ...license,
                path: policy.root + 'README.md',
              }))
            : []),
        ]),
        vendorPins: Object.freeze([
          ...(policy.vendorPins ?? []),
          ...(id === 'civilian-fpv'
            ? RUNTIME_PACKAGE_POLICIES['fpv-worlds'].vendorPins.filter((pin) =>
                pin.path.startsWith('optional-practice/civilian-fpv/vendor/rapier/'),
              )
            : []),
        ]),
        limits: Object.freeze({
          ...policy.limits,
          // Includes tuning/worker, the native-safe boot and platform adapter;
          // The visual workbench and isolated response bench add nine explicit
          // files to each complete runtime/source envelope. The installed-core
          // Academy cache includes the shared full locale catalog; its measured
          // 12,976,707-byte closure requires a 512 KiB allowance above 12 MiB.
          // Standalone Academy remains below 12 MiB; World stays at 20 MiB.
          // World also admits its single Regional Advanced adapter.
          // Academy now carries the same pinned 4.35 MB Rapier build as World.
          files:
            id === 'civilian-fpv'
              ? 150
              : id === 'fpv-worlds'
                ? 210 // Includes World's same-scope flight and response-bench workers.
                : id === 'civilian-flight'
                  ? 98
                  : policy.limits.files,
          bytes:
            id === 'fpv-worlds'
              ? 20 * 1024 * 1024
              : id === 'civilian-fpv'
                ? 12 * 1024 * 1024 + 512 * 1024
                : policy.limits.bytes,
        }),
        localFiles: Object.freeze([
          ...policy.localFiles,
          ...(id === 'civilian-fpv' ? [...FPV_TUNING_FILES, ...FPV_ADVANCED_ACADEMY_FILES] : []),
          'package-info.json',
          'preview.png',
          'guide.html',
        ]),
        sharedFiles: Object.freeze([
          ...new Set([
            ...policy.sharedFiles,
            ...(id === 'fpv-worlds'
              ? [...FPV_TUNING_FILES, 'advanced-regional.mjs'].map(
                  (name) => `optional-practice/civilian-fpv/${name}`,
                )
              : []),
            ...(['civilian-fpv', 'fpv-worlds'].includes(id) ? ['game/platform.mjs'] : []),
            'game/access-gate.mjs',
            'game/access-gate.css',
            // The legacy civilian-flight archive also hosts the shared SIM
            // presentation. Its theme selector now imports the retained
            // industrial environment catalogue, so that closure must be
            // admitted for every package that ships the selector.
            ...(['civilian-flight', 'civilian-fpv', 'fpv-worlds'].includes(id)
              ? [
                  'game/presentation/industrial-materials.mjs',
                  'game/presentation/industrial-environments.mjs',
                  'game/presentation/industrial-environments-data.mjs',
                  'game/presentation/industrial-machinery.mjs',
                  'game/ui/art-review-navigation.mjs',
                  'game/ui/enemy-appearance-controls.mjs',
                  'game/hunt/industrial-soldier-kit.mjs',
                  'optional-practice/civilian-fpv/industrial-soldiers.mjs',
                  'optional-practice/civilian-fpv/industrial-vehicles.mjs',
                  // All three applications import the SIM profile catalogue.
                  // Its optional battlefield presets share the native painter,
                  // not the Overflight simulation, renderer or Creator app.
                  'optional-practice/civilian-fpv/battlefield-ground.mjs',
                  'game/overflight/worlds.mjs',
                  'game/overflight/terrain.mjs',
                  'game/presentation/overflight-world-art.mjs',
                  'game/presentation/overflight-world-slots.mjs',
                  'game/overflight/world-layout-presentation.mjs',
                  'game/presentation/overflight-world-art-v2.mjs',
                  'game/snake/classic-structure-art.mjs',
                ]
              : []),
            'optional-practice/guide.mjs',
            'optional-practice/navigation.mjs',
            'game/ui/menu-navigation-groups.mjs',
            'game/ui/art/identity/fpv-line/wordmark.png',
            'game/ui/art/menu-scenes/fpv.webp',
            'game/ui/art-review-navigation.mjs',
            'game/hunt/preferences.mjs',
            'game/hunt/copy.mjs',
            'game/hunt/actor-catalog.mjs',
            'game/ui/enemy-appearance-controls.mjs',
            'game/ui/defeat-sound-controls.mjs',
            'game/ui/destruction-audio.mjs',
            'game/ui/destruction-level.mjs',
            'game/ui/human-reaction-policy.mjs',
            'game/audio/human-reactions/portable.mjs',
          ]),
        ]),
      }),
    ]),
  ),
);

export function optionalRuntimePaths(policy, { launcher = false } = {}) {
  return [
    ...(launcher
      ? [
          'index.html',
          'app.mjs',
          'context.mjs',
          'navigation.mjs',
          'app.webmanifest',
          'worker.js',
          'icons/icon-192.png',
          'icons/icon-512.png',
          'access-gate.mjs',
          'access-gate.css',
        ].map((name) => 'launcher/' + name)
      : []),
    ...policy.localFiles.map((name) => policy.root + name),
    ...policy.sharedFiles,
    ...[192, 512].map((size) => `${policy.root}icons/icon-${size}.png`),
    `${policy.root}worker.js`,
  ].sort();
}
