import fs from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readEditionZip} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
import {directoryJourneyOverlay} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/observe-practice-directory-journey.mjs';
const out='/private/tmp/practice-current-production-directory-20261018';
const root='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const hash=b=>createHash('sha256').update(b).digest('hex');
const hashFile=async p=>{const h=createHash('sha256');for await(const b of createReadStream(p))h.update(b);return h.digest('hex');};
const receiptBytes=await fs.readFile(out+'/observation.json'),r=JSON.parse(receiptBytes),p=r.plan;
assert(r.completed&&r.procedureComplete&&!r.qualified&&r.cleanup.completed);
assert(r.observerSource.verifiedBefore&&r.observerSource.verifiedAfter);
assert.equal(r.observerSource.sourceRevision,'b8e0182de344fba5bf1541ddca753ac7769bdd60');
assert.equal(execFileSync('git',['rev-parse',`${p.shellRevision}^{tree}`],{cwd:root,encoding:'utf8'}).trim(),p.shellTree);
assert.equal(p.sourceRevision,'3c6ac5ee0f524a1c3a456316b978cf4e0043e06c');
assert.equal(hash(await fs.readFile(path.join(p.distribution,'manifest.json'))),p.distributionManifestSha256);
assert.equal(r.distribution.originalFiles.length,3558);
assert(r.distribution.originalsVerifiedBefore&&r.distribution.originalsVerifiedAfter);
let bytes=0;
for(const f of r.distribution.originalFiles){assert(!path.isAbsolute(f.path)&&!f.path.split('/').includes('..'));const file=path.join(p.distribution,f.path);assert.equal((await fs.stat(file)).size,f.bytes);assert.equal(await hashFile(file),f.sha256);bytes+=f.bytes;}
assert.equal(bytes,1074713915);
assert.equal(r.distributionIO.length,2);
for(const io of r.distributionIO){assert(io.completed&&io.cleanup.completed&&io.cleanup.openStreams===0);assert.equal(io.completedFiles,3558);assert.equal(io.completedBytes,bytes);}
for(const f of r.authority){assert.equal(await hashFile(path.join(root,f.path)),f.sha256);assert.equal(await hashFile(path.join(out,'authority',path.basename(f.path))),f.sha256);}
assert.deepEqual(r.servedSources,[]);
assert.deepEqual(r.requestFailures,[{path:'/favicon.ico',message:'Outside local fixture root.'}]);
assert(r.resourceAcquisitions.every(x=>!x.pending&&!x.timedOut));
assert(r.productionDelivery.cleared&&r.productionDelivery.pendingReads===0&&r.productionDelivery.remainingBytes===0);
assert(r.productionDelivery.selectedBytes<=134217728);
const overlay=new Map(r.overlay.map(f=>[f.path,f]));
const envelope=JSON.parse(await fs.readFile(p.bundle+'/optional-packages.json'));
assert.equal(await hashFile(p.bundle+'/optional-packages.json'),p.envelopeSha256);
let members=0,launchers=0;
for(const pkg of envelope.packages){const archive=await fs.readFile(path.join(p.bundle,pkg.distribution.path));assert.equal(hash(archive),pkg.distribution.sha256);for(const [name,b] of readEditionZip(archive)){const item=overlay.get(`practice/${pkg.id}/releases/${envelope.version}/site/${name}`);assert.equal(item?.sha256,hash(b));assert.equal(item.bytes,b.length);members++;if(name.startsWith('launcher/')){assert.equal(overlay.get(`practice/${pkg.id}/app/${name.slice(9)}`)?.sha256,hash(b));launchers++;}}}
const regenerated=await directoryJourneyOverlay(p);
assert.equal(regenerated.files.size,overlay.size);
for(const [name,b] of regenerated.files)assert.equal(overlay.get(name)?.sha256,hash(b));
assert.equal(r.cases.length,6);
let pngs=0;
for(const c of r.cases){assert(c.passed&&c.mainGameReturn&&c.standaloneDirectory);assert.deepEqual(c.errors,[]);assert.deepEqual(c.runtimeRequestsBeforePlay,[]);assert.equal(c.playActions,1);assert.equal(c.cardsVerified,3);assert.equal(c.app.locale,c.locale);assert.equal(c.app.phase,c.package==='civilian-fpv'?'disarmed':'ready');assert.equal(c.personalAppearance.app.family,'tryzub');assert.equal(c.guide.heading,c.locale==='uk'?'Ваш перший тренувальний політ':'Your first practice flight');for(const s of c.screenshots){const b=await fs.readFile(path.join(out,s.path));assert.equal(b.length,s.bytes);assert.equal(hash(b),s.sha256);pngs++;}}
const result={format:'PracticeCurrentProductionDirectoryAudit.v1',passed:true,receiptSha256:hash(receiptBytes),source:p.sourceRevision,observer:p.observerRevision,browser:r.browser,originalFiles:3558,originalBytesRehashed:bytes,zipMembersVerified:members,stableLauncherCopies:launchers,allOverlayFilesRegenerated:overlay.size,cases:6,onePlayEach:true,runtimeRequestsBeforePlay:0,screenshotsHashed:pngs,cleanupVerified:true,scope:'Local original full production six-route integration. Not flight/exercise, visual accessibility, human, hardware, performance budget or public release approval.'};
await fs.writeFile(out+'/audit.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result));
