import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const output = '/Volumes/alex/CodexMigrationStaging/practice-localization-external-profile-20261019';
const files = (await fs.readdir(output)).filter((name) => /^window-[1-3]\.cpuprofile$/.test(name)).sort();
const summaries = [];
for (const file of files) {
  const raw = await fs.readFile(`${output}/${file}`), p = JSON.parse(raw);
  const nodes = new Map(p.nodes.map((node) => [node.id, node]));
  const parents = new Map(p.nodes.flatMap((node) => (node.children || []).map((id) => [id, node.id])));
  const self = new Map(), inclusive = new Map(), frames = new Map();
  const keyOf = (id) => { const f = nodes.get(id).callFrame, key = JSON.stringify([f.url, f.functionName, f.lineNumber]); frames.set(key, f); return key; };
  const add = (map, key, ms) => map.set(key, (map.get(key) || 0) + ms);
  let totalMs = 0;
  for (let i = 0; i < p.samples.length; i++) {
    let id = p.samples[i];
    const ms = p.timeDeltas[i] / 1000, seen = new Set();
    totalMs += ms;
    add(self, keyOf(id), ms);
    while (id !== undefined) { const key = keyOf(id); if (!seen.has(key)) add(inclusive, key, ms); seen.add(key); id = parents.get(id); }
  }
  const top = (map, repoOnly = false) => [...map].filter(([key]) => !repoOnly || frames.get(key).url.includes(root)).sort((a, b) => b[1] - a[1]).slice(0, 18).map(([key, ms]) => ({ ms, percent: ms * 100 / totalMs, ...frames.get(key) }));
  summaries.push({ file, sha256: createHash('sha256').update(raw).digest('hex'), elapsedMs: (p.endTime - p.startTime) / 1000, totalSampledMs: totalMs, samples: p.samples.length, self: top(self), repoInclusive: top(inclusive, true) });
}
const report = { format: 'PracticeLocalizationCPUProfileSummary.v1', windows: summaries, scope: 'Only captured read-only validation windows; not whole-build attribution, a completed validation/build or accepted performance measurement.' };
await fs.writeFile(`${output}/summary-${files.length}-windows.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(report));
