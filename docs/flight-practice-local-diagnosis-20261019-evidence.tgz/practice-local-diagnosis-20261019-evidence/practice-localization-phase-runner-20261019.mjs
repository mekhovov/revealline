import fs from 'node:fs/promises';
import os from 'node:os';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { frozenSource } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
import { observeIndustrialPhase } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/verify-industrial-features.mjs';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const output = '/Volumes/alex/CodexMigrationStaging/practice-localization-phase-20261019';
await fs.mkdir(output);
const source = frozenSource(root), hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const report = { format: 'PracticeNonDebuggerLocalizationPhases.v1', source, node: process.version, startedAt: new Date().toISOString(), deadlineMs: 600000, buildPerformed: false, qualified: false, completed: false, system: { logicalCPUs: os.cpus().length, loadAverageBefore: os.loadavg() }, scope: 'Non-debugger read-only phase decomposition using original localization helpers and unchanged catalog byte comparisons. Not the original validator entry, full build, CI, performance budget, or simulator change.' };
const sample = setInterval(() => { report.system.loadAverageLatest = os.loadavg(); }, 10000);
try {
  report.result = await observeIndustrialPhase({ command: ['/private/tmp/practice-localization-phase-target-20261019.mjs'], cwd: root, log: `${output}/phases.jsonl`, deadlineMs: report.deadlineMs });
  const log = await fs.readFile(`${output}/phases.jsonl`);
  report.logSha256 = hash(log);
  report.events = log.toString().trim().split('\n').filter(Boolean).map((line) => JSON.parse(line));
  report.sourceAfter = frozenSource(root);
  assert.deepEqual(report.sourceAfter, source);
  report.sourceUnchanged = true;
  report.completed = report.result.exitCode === 0 && !report.result.timedOut && !report.result.interrupted && !report.result.executionError && report.events.at(-1)?.phase === 'isolated-localization-operations' && report.events.at(-1)?.state === 'complete';
} catch (error) { report.failure = error.message; }
finally {
  clearInterval(sample);
  report.finishedAt = new Date().toISOString();
  await fs.writeFile(`${output}/receipt.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ completed: report.completed, result: report.result, failure: report.failure, lastEvent: report.events?.at(-1), output }));
  if (!report.completed) process.exitCode = 1;
}
