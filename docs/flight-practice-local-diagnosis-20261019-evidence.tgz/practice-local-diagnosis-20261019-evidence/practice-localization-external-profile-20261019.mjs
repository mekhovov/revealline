import fs from 'node:fs/promises';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { frozenSource } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const output = '/Volumes/alex/CodexMigrationStaging/practice-localization-external-profile-20261019';
await fs.mkdir(output);
const source = frozenSource(root), started = performance.now();
const report = { format: 'PracticeExternallySupervisedLocalizationProfile.v1', source, requestedWindowMs: 30000, maximumWindows: 3, overallMs: 120000, windows: [], captureComplete: false, qualified: false, buildPerformed: false, scope: 'Read-only main-game localization validation under an owned debugger. Artificial pauses are diagnostic only, never build/app performance qualification. Source and validation logic unchanged.' };
const child = spawn(process.execPath, ['--inspect-brk=127.0.0.1:0', '/private/tmp/practice-localization-profile-target-20261019.mjs'], { cwd: root, detached: true, env: { PATH: process.env.PATH, TMPDIR: '/private/tmp', LANG: 'en_US.UTF-8' }, stdio: ['ignore', 'pipe', 'pipe'] });
let stderr = '', stdout = '', socket, next = 0, failure;
const pending = new Map(), scripts = new Map(), pauseQueue = [], pauseWaiters = [];
let debuggerResolve;
const debuggerURL = new Promise((resolve) => { debuggerResolve = resolve; });
child.stdout.on('data', (b) => { stdout += b; });
child.stderr.on('data', (b) => { stderr += b; const url = /Debugger listening on (ws:\/\/127\.0\.0\.1:\d+\/[^\s]+)/.exec(stderr)?.[1]; if (url) debuggerResolve(url); });
const closed = new Promise((resolve) => child.once('close', (code, signal) => { report.childExit = { code, signal }; resolve(); }));
const kill = () => { try { process.kill(-child.pid, 'SIGTERM'); } catch (error) { if (error.code !== 'ESRCH') throw error; } };
const limit = (promise, ms, label) => Promise.race([promise, new Promise((_, reject) => { const timer = setTimeout(() => reject(new Error(`${label} exceeded ${ms} ms`)), ms); timer.unref(); })]);
const send = (method, params = {}) => limit(new Promise((resolve, reject) => { const id = ++next; pending.set(id, { resolve, reject }); socket.send(JSON.stringify({ id, method, params })); }), 5000, method);
const nextPause = () => pauseQueue.length ? Promise.resolve(pauseQueue.shift()) : limit(new Promise((resolve) => pauseWaiters.push(resolve)), 5000, 'Debugger pause');
const overall = setTimeout(() => { failure = new Error('External 120-second diagnostic ceiling exceeded'); kill(); socket?.close(); }, report.overallMs);
try {
  const url = await limit(debuggerURL, 10000, 'Owned debugger startup');
  socket = new WebSocket(url);
  socket.addEventListener('message', (event) => {
    const m = JSON.parse(event.data);
    if (m.id) { const p = pending.get(m.id); pending.delete(m.id); if (m.error) p?.reject(new Error(JSON.stringify(m.error))); else p?.resolve(m.result); }
    if (m.method === 'Debugger.scriptParsed') scripts.set(m.params.scriptId, m.params.url);
    if (m.method === 'Debugger.paused') { const waiter = pauseWaiters.shift(); if (waiter) waiter(m.params); else pauseQueue.push(m.params); }
  });
  socket.addEventListener('close', () => { for (const p of pending.values()) p.reject(new Error('Owned debugger closed')); pending.clear(); });
  await limit(new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); }), 5000, 'Owned debugger connection');
  await send('Debugger.enable');
  await send('Profiler.enable');
  await send('Runtime.runIfWaitingForDebugger');
  await nextPause();
  for (let index = 1; index <= report.maximumWindows; index++) {
    await send('Profiler.start');
    const began = performance.now();
    await send('Debugger.resume');
    await Promise.race([new Promise((resolve) => setTimeout(resolve, report.requestedWindowMs)), closed]);
    if (report.childExit) throw new Error('Validation process exited before capture');
    await send('Debugger.pause');
    const paused = await nextPause();
    const { profile } = await send('Profiler.stop');
    assert(profile.samples?.length && profile.nodes?.length);
    const window = { index, externalElapsedMs: performance.now() - began, profileElapsedMs: (profile.endTime - profile.startTime) / 1000, samples: profile.samples.length, frames: paused.callFrames.map((f) => ({ functionName: f.functionName, url: f.url || scripts.get(f.location.scriptId), location: f.location })) };
    await fs.writeFile(`${output}/window-${index}.cpuprofile`, JSON.stringify(profile), { flag: 'wx' });
    report.windows.push(window);
    console.log(JSON.stringify({ captured: index, externalElapsedMs: window.externalElapsedMs, top: window.frames[0] }));
  }
  report.captureComplete = true;
} catch (error) { failure ??= error; }
finally {
  clearTimeout(overall);
  socket?.close();
  kill();
  await limit(closed, 5000, 'Owned child exit');
  let absent = false;
  for (let i = 0; i < 50; i++) { try { process.kill(-child.pid, 0); } catch (error) { assert.equal(error.code, 'ESRCH'); absent = true; break; } await new Promise((resolve) => setTimeout(resolve, 50)); }
  report.cleanup = { pgid: child.pid, absent };
  report.sourceAfter = frozenSource(root);
  assert.deepEqual(report.sourceAfter, source);
  report.sourceUnchanged = true;
  report.failure = failure?.message ?? null;
  report.totalElapsedMs = performance.now() - started;
  report.validationResult = await fs.readFile(`${output}/validation-result.json`, 'utf8').then(JSON.parse, () => null);
  await fs.writeFile(`${output}/target-stderr.log`, stderr, { flag: 'wx' });
  await fs.writeFile(`${output}/target-stdout.log`, stdout, { flag: 'wx' });
  await fs.writeFile(`${output}/receipt.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ captureComplete: report.captureComplete, windows: report.windows.length, sourceUnchanged: true, cleanup: report.cleanup, failure: report.failure, output }));
  if (failure || !absent) process.exitCode = 1;
}
