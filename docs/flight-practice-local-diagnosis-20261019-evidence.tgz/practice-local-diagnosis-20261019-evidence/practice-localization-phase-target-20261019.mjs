import fs from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
import { createHash } from 'node:crypto';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const started = performance.now();
const event = (phase, state, extra = {}) => console.log(JSON.stringify({ phase, state, elapsedMs: performance.now() - started, ...extra }));
const stage = async (name, run) => {
  event(name, 'start');
  const began = performance.now();
  try { const value = await run(); event(name, 'complete', { phaseElapsedMs: performance.now() - began }); return value; }
  catch (error) { event(name, 'failed', { message: error.message }); throw error; }
};
const tools = await stage('import-localization-tools', () => import(`${root}/scripts/localization.mjs`));
const resources = await stage('read-catalogs', () => tools.readCatalogs(root));
const references = await stage('extract-translations', () => tools.extractTranslations(root));
const errors = await stage('check-catalog-messages', () => tools.validateCatalogMessages(resources));
const messages = Object.values(resources.en).reduce((sum, entries) => sum + Object.keys(entries).length, 0);
for (const key of Object.keys(references)) {
  const [namespace, name] = key.split(':');
  if (!resources.en[namespace]?.[name] && !resources.en[namespace]?.[`${name}_other`]) errors.push(`Uncatalogued key: ${key}`);
}
const catalog = await stage('catalog-bundle', () => tools.catalogBundle(resources));
const catalogOriginal = await fs.readFile(`${root}/game/i18n/catalogs.mjs`, 'utf8');
event('catalog-original-byte-comparison', catalog === catalogOriginal ? 'equal' : 'different');
if (catalog !== catalogOriginal) errors.push('Catalog bundle differs from committed original.');
const content = await stage('content-bundle', () => tools.contentBundle(root, resources));
const contentOriginal = await fs.readFile(`${root}/game/i18n/content-registry.mjs`, 'utf8');
const equal = content === contentOriginal;
event('content-original-byte-comparison', equal ? 'equal' : 'different', { bytes: Buffer.byteLength(content), sha256: createHash('sha256').update(content).digest('hex') });
if (!equal) errors.push('Content bundle differs from committed original.');
event('isolated-localization-operations', errors.length ? 'failed' : 'complete', { messages, references: Object.keys(references).length, errors, scope: 'Read-only phase decomposition using maintained public helpers. Not the original validator entry, a normal build, CI, or performance approval.' });
if (errors.length) process.exitCode = 1;
