import test from 'node:test';
import assert from 'node:assert/strict';
import * as fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { request } from 'node:http';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { generatePackCatalogs } from './generate-pack-catalogs.mjs';
import { buildOfflineContent, buildOfflineInventory } from './offline-content.mjs';
import { downloadFiles } from '../game/download-catalogue.mjs';
import { LAUNCHER_CATALOG_KEYS, LAUNCHER_NAVIGATION_FILES } from './offline-launcher.mjs';
import {
  buildProject,
  collectBuildFiles,
  crc32,
  createZip,
  generateLevel,
  inspectBuildProject,
  main,
  parseArguments,
  PUBLIC_SECURITY_HEADERS,
  readBuildConfig,
  readTarEntries,
  releaseSnapshot,
  safeRelative,
  safeVersion,
  startServer,
  validateBuildReferences,
  validateLevels,
  validateThemes,
  validateClasses,
} from './game-cli.mjs';

const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
async function fixture(t) {
  const directory = await fs.realpath(await fs.mkdtemp(path.join(os.tmpdir(), 'xonix-tool-test-')));
  t.after(() => fs.rm(directory, { recursive: true, force: true }));
  const root = path.join(directory, 'project');
  await fs.mkdir(path.join(root, 'game'), { recursive: true });
  await fs.writeFile(
    path.join(root, 'game/index.html'),
    '<link href="./style.css" rel="stylesheet"><script type="module" src="./app.mjs"></script>',
  );
  await fs.writeFile(path.join(root, 'game/style.css'), 'body{color:navy}');
  await fs.writeFile(
    path.join(root, 'game/app.mjs'),
    'import { value } from "./core.mjs";\nexport const result = value;\n',
  );
  await fs.writeFile(path.join(root, 'game/core.mjs'), 'export const value = 3;\n');
  await fs.writeFile(
    path.join(root, 'game/build-config.json'),
    JSON.stringify({ version: '0.1.0', entry: 'game/index.html', include: ['game'] }),
  );
  return { root, directory, out: path.join(directory, 'dist') };
}

test('published FPV contact and support modules are included in main and optional package inputs', async () => {
  const root = fileURLToPath(new URL('../', import.meta.url));
  const config = JSON.parse(await fs.readFile(path.join(root, 'game/build-config.json'), 'utf8'));
  const { OPTIONAL_PACKAGE_POLICIES } = await import('../publishing/optional-package-policy.mjs');
  for (const module of ['flight-contact.mjs', 'flight-support.mjs']) {
    const name = `optional-practice/civilian-fpv/${module}`;
    assert.ok(config.include.includes(name), `main distribution must include ${module}`);
    assert.ok(
      OPTIONAL_PACKAGE_POLICIES['fpv-worlds'].sharedFiles.includes(name),
      `installed FPV package must include ${module}`,
    );
    assert.ok((await fs.stat(path.join(root, name))).isFile());
  }
});

test('published regional review modules match the installed FPV source closure', async () => {
  const root = fileURLToPath(new URL('../', import.meta.url));
  const config = JSON.parse(await fs.readFile(path.join(root, 'game/build-config.json'), 'utf8'));
  const { OPTIONAL_PACKAGE_POLICIES } = await import('../publishing/optional-package-policy.mjs');
  const regional = OPTIONAL_PACKAGE_POLICIES['fpv-worlds'].sharedFiles.filter(
    (name) =>
      name.endsWith('/regional-session.mjs') ||
      name.endsWith('/regional-locations.mjs') ||
      name.endsWith('/regional-delivery.mjs') ||
      name.includes('/civilian-fpv/regional/'),
  );
  assert.equal(
    regional.length,
    25,
    'the reviewed regional source closure includes RGBA, restore admission, saved places, Railway district and Hillside ground',
  );
  assert.ok(regional.includes('optional-practice/civilian-fpv/regional/rgba-scenery-cell.mjs'));
  assert.ok(regional.includes('optional-practice/civilian-fpv/regional/restore-containment.mjs'));
  assert.ok(regional.includes('optional-practice/civilian-fpv/regional-locations.mjs'));
  assert.ok(
    regional.includes('optional-practice/civilian-fpv/regional/hillside-ground-surface.mjs'),
  );
  assert.ok(
    regional.includes('optional-practice/civilian-fpv/regional/railway-expanse-ground.mjs'),
  );
  for (const name of regional) {
    assert.ok(config.include.includes(name), `main distribution must include ${name}`);
    assert.ok((await fs.stat(path.join(root, name))).isFile());
  }
});

test('build binds the same release version into Solo, Versus and Team landing HTML', async (t) => {
  const { root, out } = await fixture(t);
  await fs.mkdir(path.join(root, 'game/couch'));
  const pages = ['game/index.html', 'game/couch/index.html', 'game/couch/relay-rescue.html'];
  for (const page of pages)
    await fs.writeFile(
      path.join(root, page),
      '<html data-build-version="__REVEALLINE_VERSION__"><head></head><body>__REVEALLINE_VERSION__</body></html>',
    );
  await buildProject({ root, out, version: '0.142.1' });
  for (const page of pages) {
    const html = await fs.readFile(path.join(out, page), 'utf8');
    assert.ok(!html.includes('__REVEALLINE_VERSION__'), page);
    assert.match(html, /data-build-version="v0\.142\.1"/, page);
    assert.match(html, /<body>v0\.142\.1<\/body>/, page);
  }
});

test('strict command parsing rejects typos, duplicates and absent values', () => {
  assert.deepEqual(parseArguments(['build', '--version', '0.1.0']), {
    action: 'build',
    options: { version: '0.1.0' },
  });
  assert.equal(parseArguments(['--help']).action, 'help');
  for (const args of [
    ['deploy'],
    ['toString'],
    ['__proto__'],
    ['build', '--force', 'yes'],
    ['build', '--version'],
    ['serve', '--root', '.', '--root', 'other'],
    ['test', '--seed', 'one'],
    ['generate', '--seed', '--out', 'x'],
  ])
    assert.throws(() => parseArguments(args));
});

test('version and relative-path rules exclude traversal and command-like labels', () => {
  for (const v of ['0.1.0', 'round-09', 'v1.0.0-beta.1']) assert.equal(safeVersion(v), v);
  for (const v of [
    '../one',
    '.hidden',
    '--version',
    'a..b',
    'a/b',
    'x y',
    'x\n',
    '',
    'x'.repeat(65),
  ])
    assert.throws(() => safeVersion(v));
  for (const p of ['../one', '/etc/passwd', 'a/../b', 'a//b', 'C:/tmp', 'a\\b', 'a\0b'])
    assert.throws(() => safeRelative(p));
  assert.equal(safeRelative('game/my file.png'), 'game/my file.png');
});

test('snapshot rejects unsafe refs and index-conflicting labels before any Git command', async () => {
  await assert.rejects(releaseSnapshot({ ref: '--help', version: '1.0' }), /trusted local/);
  await assert.rejects(releaseSnapshot({ ref: 'HEAD', version: 'INDEX.HTML' }), /version index/);
  await assert.rejects(releaseSnapshot({ ref: 'HEAD', version: 'index.json' }), /version index/);
});

test('direct CLI invocation works through an aliased directory and reports command failures', async (t) => {
  const { directory } = await fixture(t);
  const scripts = path.dirname(fileURLToPath(import.meta.url));
  const alias = path.join(directory, 'scripts-alias');
  await fs.symlink(scripts, alias, 'dir');
  const entry = path.join(alias, 'game-cli.mjs');
  const help = spawnSync(process.execPath, [entry, 'help'], { encoding: 'utf8' });
  assert.equal(help.status, 0, help.stderr);
  assert.match(help.stdout, /Xonix game CLI/);
  const bad = spawnSync(process.execPath, [entry, 'not-a-command'], { encoding: 'utf8' });
  assert.equal(bad.status, 1);
  assert.match(bad.stderr, /Unknown command/);
});

test('real Git snapshot runs an older frozen entry through an aliased temp root and preserves immutable source', async (t) => {
  const { root, directory } = await fixture(t);
  const environment = Object.fromEntries(
    Object.entries(process.env).filter(([key]) => !key.startsWith('GIT_')),
  );
  Object.assign(environment, {
    GIT_CONFIG_GLOBAL: os.devNull,
    GIT_CONFIG_NOSYSTEM: '1',
    GIT_AUTHOR_NAME: 'Snapshot fixture',
    GIT_AUTHOR_EMAIL: 'fixture@example.invalid',
    GIT_COMMITTER_NAME: 'Snapshot fixture',
    GIT_COMMITTER_EMAIL: 'fixture@example.invalid',
    GIT_AUTHOR_DATE: '2026-09-12T12:00:00Z',
    GIT_COMMITTER_DATE: '2026-09-12T12:00:00Z',
  });
  const run = (binary, args, env = environment) => {
    const result = spawnSync(binary, args, { cwd: root, env, encoding: 'utf8' });
    assert.equal(result.status, 0, result.error?.message || result.stderr);
    return result.stdout;
  };
  const git = (...args) => run('git', args);
  const scripts = path.join(root, 'scripts');
  await fs.mkdir(scripts);
  await fs.copyFile(
    new URL('./game-cli.mjs', import.meta.url),
    path.join(scripts, 'build-implementation.mjs'),
  );
  await fs.writeFile(
    path.join(scripts, 'localization.mjs'),
    'export async function validateLocalization() { return { valid: true }; }\n',
  );
  await fs.mkdir(path.join(root, 'game/content'), { recursive: true });
  await fs.writeFile(
    path.join(root, 'game/content/soundtrack-catalogue.mjs'),
    'export const SOUNDTRACK_BUNDLED_ASSETS = [];\n',
  );
  await fs.mkdir(path.join(root, 'game/mission-library'), { recursive: true });
  await fs.writeFile(
    path.join(root, 'game/mission-library/included-bundled-pack.mjs'),
    'export function isIncludedBundledMission() { return false; }\n',
  );
  await fs.mkdir(path.join(root, 'game/i18n'), { recursive: true });
  await fs.writeFile(
    path.join(root, 'game/i18n/index.mjs'),
    'export function t(key) { return key; }\n',
  );
  // Archive the implementation's real metadata dependencies too. No module may
  // resolve back into the current working tree during the frozen build.
  for (const relative of [
    'scripts/access-pages.mjs',
    'scripts/pack-indexes.mjs',
    'scripts/brand-icons.mjs',
    'scripts/build-entry-writer.mjs',
    'publishing/vendor/acorn-8.18.0.mjs',
    'publishing/vendor/acorn-LICENSE.txt',
    'game/data-json.mjs',
    'game/content-launch.mjs',
  ]) {
    await fs.mkdir(path.dirname(path.join(root, relative)), { recursive: true });
    await fs.copyFile(new URL(`../${relative}`, import.meta.url), path.join(root, relative));
  }
  await fs.writeFile(
    path.join(root, 'scripts/offline-core-closure.mjs'),
    'export function isOptionalSpatialAudioBody() { return false; }\nexport function isOptionalReactionVoiceBody() { return false; }\n',
  );
  // Retain the historical argv/URL guard in the archived entry. The real build
  // implementation runs behind it, so fixing only the current entry guard would
  // still fail this old-revision snapshot when TMPDIR contains a symlink.
  const historicalEntry = [
    "import path from 'node:path';",
    "import { pathToFileURL } from 'node:url';",
    "import { main } from './build-implementation.mjs';",
    'if (pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) await main();',
    '',
  ].join('\n');
  await fs.writeFile(path.join(scripts, 'game-cli.mjs'), historicalEntry);
  await fs.writeFile(path.join(root, '.gitignore'), 'releases/\n');
  git('init', '--quiet');
  git('add', 'game', 'scripts', 'publishing', '.gitignore');
  git(
    '-c',
    'commit.gpgsign=false',
    '-c',
    `core.hooksPath=${os.devNull}`,
    'commit',
    '--quiet',
    '-m',
    'Frozen fixture',
  );
  git('tag', 'fixture-v1');
  const commit = git('rev-parse', 'fixture-v1^{commit}').trim();
  const oldCore = await fs.readFile(path.join(root, 'game/core.mjs'));
  await fs.writeFile(path.join(root, 'game/core.mjs'), 'export const value = 999;\n');
  await fs.writeFile(
    path.join(scripts, 'game-cli.mjs'),
    'throw new Error("Uncommitted CLI must not run");\n',
  );
  const statusBefore = git('status', '--porcelain');
  const tempRoot = path.join(directory, 'temporary-real');
  const tempAlias = path.join(directory, 'temporary-alias');
  await fs.mkdir(tempRoot);
  await fs.symlink(tempRoot, tempAlias, 'dir');
  const childEnvironment = { ...environment, TMPDIR: tempAlias, TEMP: tempAlias, TMP: tempAlias };
  const cliUrl = new URL('./game-cli.mjs', import.meta.url).href;
  const options = { root, ref: 'fixture-v1', version: 'fixture-v1' };
  const code = `import { releaseSnapshot } from ${JSON.stringify(cliUrl)}; console.log(JSON.stringify(await releaseSnapshot(${JSON.stringify(options)})));`;
  const release = JSON.parse(
    run(process.execPath, ['--input-type=module', '--eval', code], childEnvironment),
  );
  const destination = path.join(root, 'releases/fixture-v1');
  const site = path.join(destination, 'site');
  const archive = await fs.readFile(path.join(destination, 'source.tar'));
  const manifestBytes = await fs.readFile(path.join(site, 'manifest.json'));
  const manifest = JSON.parse(manifestBytes);
  const zip = await fs.readFile(path.join(site, 'distribution.zip'));
  const releaseBytes = await fs.readFile(path.join(destination, 'release.json'));
  assert.equal(release.sourceRevision, commit);
  assert.equal(release.directory, destination);
  assert.equal(release.sourceArchiveSha256, hash(archive));
  assert.equal(release.manifestSha256, hash(manifestBytes));
  assert.equal(release.distributionSha256, hash(zip));
  assert.deepEqual(
    JSON.parse(releaseBytes),
    Object.fromEntries(Object.entries(release).filter(([key]) => key !== 'directory')),
  );
  assert.equal(manifest.sourceRevision, commit);
  assert.equal(manifest.version, 'fixture-v1');
  const info = JSON.parse(await fs.readFile(path.join(site, 'game/build-info.json')));
  assert.equal(info.sourceRevision, commit);
  assert.equal(info.version, 'fixture-v1');
  assert.deepEqual(await fs.readFile(path.join(site, 'game/core.mjs')), oldCore);
  const sourceEntries = new Map(readTarEntries(archive).map((entry) => [entry.name, entry.bytes]));
  assert.deepEqual(sourceEntries.get('game/core.mjs'), oldCore);
  assert.equal(sourceEntries.get('scripts/game-cli.mjs').toString(), historicalEntry);
  assert.deepEqual(
    sourceEntries.get('publishing/vendor/acorn-8.18.0.mjs'),
    await fs.readFile(new URL('../publishing/vendor/acorn-8.18.0.mjs', import.meta.url)),
    'The frozen build uses its archived parser bytes without resolving host node_modules.',
  );
  assert.ok(
    ![...sourceEntries.keys()].some(
      (name) => name.startsWith('releases/') || name.startsWith('.git/'),
    ),
  );
  // Read the ZIP's actual stored entries independently of createZip's writer.
  const zipped = new Map();
  let offset = 0;
  while (zip.readUInt32LE(offset) === 0x04034b50) {
    assert.equal(zip.readUInt16LE(offset + 8), 0);
    const size = zip.readUInt32LE(offset + 18);
    const nameLength = zip.readUInt16LE(offset + 26);
    const extraLength = zip.readUInt16LE(offset + 28);
    const name = zip.subarray(offset + 30, offset + 30 + nameLength).toString();
    const start = offset + 30 + nameLength + extraLength;
    const bytes = zip.subarray(start, start + size);
    assert.equal(crc32(bytes), zip.readUInt32LE(offset + 14));
    assert.ok(!zipped.has(name));
    zipped.set(name, bytes);
    offset = start + size;
  }
  assert.equal(zip.readUInt32LE(offset), 0x02014b50);
  assert.equal(zip.readUInt32LE(zip.length - 22), 0x06054b50);
  assert.equal(zip.readUInt16LE(zip.length - 12), zipped.size);
  assert.deepEqual(zipped.get('manifest.json'), manifestBytes);
  assert.equal(zipped.size, manifest.files.length + 1);
  for (const entry of manifest.files) {
    const bytes = await fs.readFile(path.join(site, entry.path));
    assert.deepEqual(zipped.get(entry.path), bytes);
    assert.equal(hash(bytes), entry.sha256);
    assert.equal(bytes.length, entry.bytes);
  }
  assert.equal(
    await fs.readFile(path.join(site, 'distribution.zip.sha256'), 'utf8'),
    `${hash(zip)}  distribution.zip\n`,
  );
  const index = JSON.parse(await fs.readFile(path.join(root, 'releases/index.json')));
  assert.deepEqual(index.releases, [JSON.parse(releaseBytes)]);
  const { server, url } = await startServer({ root: path.join(root, 'releases'), port: 0 });
  try {
    assert.equal((await getRaw(url, '/fixture-v1/site/game/')).status, 200);
    assert.equal((await getRaw(url, '/fixture-v1/site/game/core.mjs')).body, oldCore.toString());
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
  await assert.rejects(releaseSnapshot(options), /already exists/);
  assert.deepEqual(await fs.readFile(path.join(site, 'distribution.zip')), zip);
  assert.deepEqual(await fs.readFile(path.join(destination, 'release.json')), releaseBytes);
  assert.equal(git('rev-parse', 'HEAD').trim(), commit);
  assert.equal(git('rev-parse', 'fixture-v1').trim(), commit);
  assert.equal(git('status', '--porcelain'), statusBefore);
  assert.deepEqual(await fs.readdir(tempRoot), []);
  assert.deepEqual((await fs.readdir(path.join(root, 'releases'))).sort(), [
    'fixture-v1',
    'index.html',
    'index.json',
  ]);

  // This is read after the TAR transfer but before publishing the new label.
  const broken = path.join(root, 'releases/broken');
  await fs.mkdir(broken);
  await fs.writeFile(path.join(broken, 'release.json'), '{');
  const failureCode = `import assert from 'node:assert/strict'; import { releaseSnapshot } from ${JSON.stringify(cliUrl)}; await assert.rejects(releaseSnapshot(${JSON.stringify({ ...options, version: 'fixture-failure' })}), SyntaxError);`;
  run(process.execPath, ['--input-type=module', '--eval', failureCode], childEnvironment);
  assert.deepEqual(await fs.readdir(tempRoot), []);
  assert.deepEqual((await fs.readdir(path.join(root, 'releases'))).sort(), [
    'broken',
    'fixture-v1',
    'index.html',
    'index.json',
  ]);
  assert.equal(await fs.readFile(path.join(broken, 'release.json'), 'utf8'), '{');
  assert.deepEqual(await fs.readFile(path.join(destination, 'source.tar')), archive);
  assert.deepEqual(await fs.readFile(path.join(destination, 'release.json')), releaseBytes);
  assert.deepEqual(await fs.readFile(path.join(site, 'distribution.zip')), zip);
  assert.deepEqual(JSON.parse(await fs.readFile(path.join(root, 'releases/index.json'))), index);
  assert.equal(git('status', '--porcelain'), statusBefore);
});

test('build is byte-reproducible and each manifest checksum covers exact output bytes', async (t) => {
  const { root, out, directory } = await fixture(t);
  const first = await buildProject({ root, out });
  const secondOut = path.join(directory, 'comparison');
  const second = await buildProject({ root, out: secondOut });
  assert.equal(first.sha256, second.sha256);
  assert.deepEqual(
    await fs.readFile(path.join(out, 'distribution.zip')),
    await fs.readFile(path.join(secondOut, 'distribution.zip')),
  );
  const manifest = JSON.parse(await fs.readFile(path.join(out, 'manifest.json'), 'utf8'));
  for (const entry of manifest.files) {
    const bytes = await fs.readFile(path.join(out, entry.path));
    assert.equal(hash(bytes), entry.sha256);
    assert.equal(bytes.length, entry.bytes);
  }
  assert.equal(
    manifest.totalBytes,
    manifest.files.reduce((sum, f) => sum + f.bytes, 0),
  );
  assert.equal(
    JSON.parse(await fs.readFile(path.join(out, 'game/build-info.json'), 'utf8')).version,
    '0.1.0',
  );
  assert.match(await fs.readFile(path.join(out, 'index.html'), 'utf8'), /\.\/game\/index.html/);
  assert.equal(
    await fs.readFile(path.join(root, 'game/core.mjs'), 'utf8'),
    'export const value = 3;\n',
  );
});

test('optional build progress preserves exact output bytes and reports preparation and replacement', async (t) => {
  const { root, out, directory } = await fixture(t);
  const original = await buildProject({ root, out });
  const phases = [];
  const observed = await buildProject({
    root,
    out: path.join(directory, 'observed'),
    onPhase: (phase) => phases.push(phase),
  });
  assert.equal(observed.sha256, original.sha256);
  assert.deepEqual(
    await fs.readFile(path.join(observed.out, 'distribution.zip')),
    await fs.readFile(path.join(out, 'distribution.zip')),
  );
  for (const phase of [
    'inputs',
    'references',
    'content-snapshots',
    'source-files',
    'offline-metadata',
    'manifest',
    'zip',
    'expanded-files',
    'zip-file',
    'replace-output',
  ])
    assert(phases.includes(phase), `Missing phase: ${phase}`);
  assert.equal(phases[0], 'inputs');
  assert.equal(phases.at(-1), 'replace-output');
  assert.equal(new Set(phases).size, phases.length);
});

test('progress errors remain visible and cannot replace a working output', async (t) => {
  const { root, out, directory } = await fixture(t);
  await buildProject({ root, out });
  const original = await fs.readFile(path.join(out, 'distribution.zip'));
  await fs.writeFile(path.join(root, 'game/core.mjs'), 'export const value = 99;\n');
  const failure = new Error('Progress destination unavailable');
  await assert.rejects(
    buildProject({
      root,
      out,
      onPhase: async (phase) => {
        if (phase === 'replace-output') throw failure;
      },
    }),
    (error) => error === failure,
  );
  assert.deepEqual(await fs.readFile(path.join(out, 'distribution.zip')), original);
  assert(!(await fs.readdir(directory)).some((name) => name.startsWith('.xonix-build-')));
  await assert.rejects(buildProject({ root, out, onPhase: 'stderr' }), /progress callback/i);
});

test('CLI progress accepts only the explicit stderr destination', async () => {
  assert.deepEqual(parseArguments(['build', '--progress', 'stderr']), {
    action: 'build',
    options: { progress: 'stderr' },
  });
  await assert.rejects(main(['build', '--progress', 'other']), /progress.*stderr/i);
});

test('manifest-only inspection shares exact build preparation without site or ZIP writes', async (t) => {
  const { root, out, directory } = await fixture(t);
  const before = await fs.readdir(directory);
  const sourceRevision = 'a'.repeat(40);
  const inspection = await inspectBuildProject({ root, sourceRevision, out });
  assert.deepEqual(await fs.readdir(directory), before);
  assert.equal(inspection.publicEligible, false);
  assert.equal(inspection.promotable, false);
  assert.equal(inspection.completeHostedOutput, false);
  assert.equal(inspection.sourceRevision, sourceRevision);
  assert.equal('entries' in inspection, false);
  await buildProject({ root, out, sourceRevision });
  const bytes = await fs.readFile(path.join(out, 'manifest.json'));
  assert.deepEqual(inspection.manifest, JSON.parse(bytes));
  assert.equal(inspection.manifestDescriptor.sha256, hash(bytes));
  assert.equal(inspection.manifestDescriptor.bytes, bytes.length);
  assert.equal(
    inspection.payloadBytesIncludingManifest,
    inspection.manifest.totalBytes + bytes.length,
  );
  assert.equal(
    await fs.readFile(path.join(root, 'game/core.mjs'), 'utf8'),
    'export const value = 3;\n',
  );
});

test('manifest-only inspection retains the ordinary reference and malformed-input gates', async (t) => {
  const { root, directory } = await fixture(t);
  await fs.writeFile(path.join(root, 'game/app.mjs'), 'import "./missing.mjs";');
  await assert.rejects(inspectBuildProject({ root }), /Missing distribution references/);
  await fs.writeFile(path.join(root, 'game/app.mjs'), 'import "unbundled-package";');
  await assert.rejects(inspectBuildProject({ root }), /bare import/);
  await fs.writeFile(path.join(root, 'game/app.mjs'), 'export {};');
  await fs.writeFile(path.join(root, 'game/invalid.json'), '{');
  await assert.rejects(inspectBuildProject({ root }), SyntaxError);
  assert.deepEqual(await fs.readdir(directory), ['project']);
});

test('an existing authoring dependency must be explicitly admitted without its neighboring originals', async (t) => {
  const { root, out } = await fixture(t);
  const model = 'authoring/company-studio/model.mjs';
  await fs.mkdir(path.join(root, 'authoring/company-studio'), { recursive: true });
  await fs.writeFile(path.join(root, model), 'export const draft = {};\n');
  await fs.writeFile(
    path.join(root, 'authoring/company-studio/unselected-original.txt'),
    'Not admitted',
  );
  await fs.writeFile(
    path.join(root, 'game/app.mjs'),
    'import { draft } from "../authoring/company-studio/model.mjs"; export { draft };\n',
  );
  await assert.rejects(inspectBuildProject({ root }), /Missing distribution references/);
  await assert.rejects(buildProject({ root, out }), /Missing distribution references/);
  const config = await readBuildConfig(root);
  config.include.push(model);
  await fs.writeFile(path.join(root, 'game/build-config.json'), JSON.stringify(config));
  const inspected = await inspectBuildProject({ root });
  await buildProject({ root, out });
  const actual = JSON.parse(await fs.readFile(path.join(out, 'manifest.json'), 'utf8'));
  assert.deepEqual(inspected.manifest, actual);
  assert.ok(actual.files.some((entry) => entry.path === model));
  assert.equal(
    actual.files.some((entry) => entry.path.endsWith('unselected-original.txt')),
    false,
  );
  await assert.rejects(
    fs.access(path.join(out, 'authoring/company-studio/unselected-original.txt')),
    /ENOENT/,
  );
});

test('owned rebuild replaces old outputs and changes checksums when source changes', async (t) => {
  const { root, out } = await fixture(t);
  const first = await buildProject({ root, out });
  await fs.writeFile(path.join(out, 'obsolete.txt'), 'generated old output');
  await fs.writeFile(path.join(root, 'game/core.mjs'), 'export const value = 4;');
  const second = await buildProject({ root, out, version: '0.1.1' });
  assert.notEqual(first.sha256, second.sha256);
  await assert.rejects(fs.access(path.join(out, 'obsolete.txt')));
  assert.equal(
    JSON.parse(await fs.readFile(path.join(out, 'manifest.json'), 'utf8')).version,
    '0.1.1',
  );
});

test('build refuses unrelated output, overlapping source and malformed revision', async (t) => {
  const { root, out } = await fixture(t);
  await fs.mkdir(out);
  await fs.writeFile(path.join(out, 'user.txt'), 'keep');
  await assert.rejects(buildProject({ root, out }), /not owned/);
  assert.equal(await fs.readFile(path.join(out, 'user.txt'), 'utf8'), 'keep');
  await assert.rejects(buildProject({ root, out: root }), /source directory/);
  await assert.rejects(buildProject({ root, out: path.join(root, 'game/output') }), /overlaps/);
  await assert.rejects(buildProject({ root, out, sourceRevision: 'HEAD' }), /full commit/);
});

test('missing dependencies and invalid JSON fail before replacing a working build', async (t) => {
  const { root, out } = await fixture(t);
  const result = await buildProject({ root, out });
  await fs.writeFile(path.join(root, 'game/app.mjs'), 'import "./missing.mjs";');
  await assert.rejects(buildProject({ root, out }), /Missing distribution references/);
  assert.equal(hash(await fs.readFile(path.join(out, 'distribution.zip'))), result.sha256);
  await fs.writeFile(path.join(root, 'game/app.mjs'), 'import "some-package";');
  await assert.rejects(buildProject({ root, out }), /bare import/);
  await fs.writeFile(path.join(root, 'game/app.mjs'), 'export {};');
  await fs.writeFile(path.join(root, 'game/bad.json'), '{');
  await assert.rejects(buildProject({ root, out }), SyntaxError);
});

test('build excludes private include paths and rejects symbolic source links', async (t) => {
  const { root, directory } = await fixture(t);
  await fs.writeFile(path.join(directory, 'secret.txt'), 'private');
  await fs.symlink(path.join(directory, 'secret.txt'), path.join(root, 'game/link.txt'));
  await assert.rejects(collectBuildFiles(root), /Symbolic links/);
  await fs.rm(path.join(root, 'game/link.txt'));
  await fs.writeFile(path.join(root, 'game/.env'), 'private');
  await assert.rejects(collectBuildFiles(root), /Private path/);
  await fs.writeFile(
    path.join(root, 'game/build-config.json'),
    JSON.stringify({ version: '0.1', entry: 'game/index.html', include: ['.git'] }),
  );
  await assert.rejects(readBuildConfig(root), /private\/generated/);
});

test('runtime builds omit source-only game tests while retaining ordinary game files', async (t) => {
  const { root, out } = await fixture(t);
  await fs.mkdir(path.join(root, 'game/test'));
  await fs.writeFile(
    path.join(root, 'game/test/source.test.mjs'),
    'import "../../scripts/source-only.mjs";',
  );
  await buildProject({ root, out });
  await assert.rejects(fs.access(path.join(out, 'game/test/source.test.mjs')));
  await fs.access(path.join(out, 'game/core.mjs'));
});

test('portable resource checks resolve nested relative imports and reject root-only URLs', async (t) => {
  const { root } = await fixture(t);
  const files = await collectBuildFiles(root);
  await validateBuildReferences(root, files);
  await fs.writeFile(
    path.join(root, 'game/index.html'),
    '<a href="./">Game</a><a href="../docs/research.md">Source notes</a>',
  );
  assert.deepEqual((await validateBuildReferences(root, files)).navigationWarnings, [
    'game/index.html → ../docs/research.md',
  ]);
  await fs.writeFile(path.join(root, 'game/index.html'), '<script src="/game/app.mjs"></script>');
  await assert.rejects(validateBuildReferences(root, files), /not portable/);
});

test('deferred module references and worker dependency closure are required before replacing a build', async (t) => {
  const { root, out } = await fixture(t);
  const result = await buildProject({ root, out });
  await fs.mkdir(path.join(root, 'game/ui'));
  await fs.writeFile(
    path.join(root, 'game/app.mjs'),
    'export const open = () => import( /* deferred */ "./ui/lazy.mjs");',
  );
  await assert.rejects(inspectBuildProject({ root }), /game\/app\.mjs → \.\/ui\/lazy\.mjs/);
  await fs.writeFile(
    path.join(root, 'game/ui/lazy.mjs'),
    'export const inspect = () => new Worker(new URL("../inspection-worker.mjs", import.meta.url), { type: "module" });',
  );
  await assert.rejects(
    buildProject({ root, out }),
    /game\/ui\/lazy\.mjs → \.\.\/inspection-worker\.mjs/,
  );
  await fs.writeFile(
    path.join(root, 'game/inspection-worker.mjs'),
    'import { value } from "./worker-helper.mjs"; postMessage(value);',
  );
  await assert.rejects(
    buildProject({ root, out }),
    /game\/inspection-worker\.mjs → \.\/worker-helper\.mjs/,
  );
  assert.equal(hash(await fs.readFile(path.join(out, 'distribution.zip'))), result.sha256);
  await fs.writeFile(path.join(root, 'game/worker-helper.mjs'), 'export const value = 1;');
  await buildProject({ root, out });
  for (const name of ['ui/lazy.mjs', 'inspection-worker.mjs', 'worker-helper.mjs'])
    await fs.access(path.join(out, 'game', name));
});

test('module references use syntax rather than commented examples and support static template imports', async (t) => {
  const { root } = await fixture(t);
  await fs.writeFile(
    path.join(root, 'game/app.mjs'),
    [
      '// import "./commented-missing.mjs";',
      'const example = `import("./example-missing.mjs")`;',
      'export const load = () => import(`./core.mjs`);',
      'export const computed = value => import(value);',
      'export { value } from "./core.mjs";',
    ].join('\n'),
  );
  const files = await collectBuildFiles(root);
  assert.equal((await validateBuildReferences(root, files)).literalReferencesValid, true);
  await fs.writeFile(
    path.join(root, 'game/app.mjs'),
    'export const load = () => import("unbundled-package");',
  );
  await assert.rejects(validateBuildReferences(root, files), /bare import/);
  await fs.writeFile(
    path.join(root, 'game/app.mjs'),
    'export const load = () => import("/game/core.mjs");',
  );
  await assert.rejects(validateBuildReferences(root, files), /not portable/);
});

test('literal worker URLs must be admitted even when files exist outside the build include', async (t) => {
  const { root } = await fixture(t);
  await fs.mkdir(path.join(root, 'tools'));
  await fs.writeFile(path.join(root, 'tools/worker.mjs'), 'export {};');
  const files = await collectBuildFiles(root);
  for (const constructor of ['Worker', 'SharedWorker', 'globalThis.Worker', 'WorkerClass']) {
    await fs.writeFile(
      path.join(root, 'game/app.mjs'),
      `new ${constructor}(new URL("../tools/worker.mjs", import.meta.url), { type: "module" });`,
    );
    await assert.rejects(
      validateBuildReferences(root, files),
      /game\/app\.mjs → \.\.\/tools\/worker\.mjs/,
    );
  }
  await fs.writeFile(
    path.join(root, 'game/app.mjs'),
    'new Worker(new URL("./core.mjs?worker=1", import.meta.url));',
  );
  assert.equal((await validateBuildReferences(root, files)).literalReferencesValid, true);
});

test('ZIP uses standard CRC, sorted names, fixed timestamps and stored data', () => {
  assert.equal(crc32(Buffer.from('123456789')), 0xcbf43926);
  const entries = [
    { name: 'b.txt', bytes: Buffer.from('B') },
    { name: 'a.txt', bytes: Buffer.from('A') },
  ];
  assert.deepEqual(createZip(entries), createZip(entries.toReversed()));
  const zip = createZip(entries);
  assert.equal(zip.readUInt32LE(0), 0x04034b50);
  assert.equal(zip.readUInt16LE(8), 0);
  assert.equal(zip.readUInt16LE(10), 0);
  assert.equal(zip.readUInt16LE(12), 33);
  assert.equal(zip.subarray(30, 35).toString(), 'a.txt');
  assert.equal(zip[35], 65);
  assert.throws(() => createZip([{ name: '../escape', bytes: Buffer.from('x') }]), /Unsafe/);
});

function getRaw(base, requested, method = 'GET') {
  return new Promise((resolve, reject) => {
    const url = new URL(base),
      req = request(
        { hostname: url.hostname, port: url.port, path: requested, method },
        (response) => {
          const chunks = [];
          response.on('data', (chunk) => chunks.push(chunk));
          response.on('end', () =>
            resolve({
              status: response.statusCode,
              headers: response.headers,
              body: Buffer.concat(chunks).toString(),
            }),
          );
        },
      );
    req.on('error', reject);
    req.end();
  });
}

test('static server supports portable nested paths, ESM MIME and HEAD', async (t) => {
  const { root } = await fixture(t);
  const { server, url } = await startServer({ root, port: 0 });
  t.after(() => new Promise((resolve) => server.close(resolve)));
  const page = await getRaw(url, '/game/');
  assert.equal(page.status, 200);
  assert.match(page.body, /app.mjs/);
  const script = await getRaw(url, '/game/app.mjs');
  assert.match(script.headers['content-type'], /javascript/);
  const head = await getRaw(url, '/game/app.mjs', 'HEAD');
  assert.equal(head.status, 200);
  assert.equal(head.body, '');
  assert.ok(Number(head.headers['content-length']) > 0);
  const redirect = await getRaw(url, '/game');
  assert.equal(redirect.status, 308);
  assert.equal(redirect.headers.location, '/game/');
  assert.equal((await getRaw(url, '//game')).headers.location, '/game/');
  assert.equal((await getRaw(url, '/game/', 'POST')).status, 405);
});

test('static server refuses traversal, hidden files, malformed paths and symlink escape', async (t) => {
  const { root, directory } = await fixture(t);
  await fs.writeFile(path.join(directory, 'secret.txt'), 'private');
  await fs.symlink(path.join(directory, 'secret.txt'), path.join(root, 'game/link.txt'));
  await fs.mkdir(path.join(root, '.git'));
  await fs.writeFile(path.join(root, '.git/config'), 'private');
  const { server, url } = await startServer({ root, port: 0 });
  t.after(() => new Promise((resolve) => server.close(resolve)));
  for (const input of ['/../secret.txt', '/%2e%2e/secret.txt', '/.git/config', '/game/link.txt'])
    assert.equal((await getRaw(url, input)).status, 403);
  for (const input of ['/%ZZ', '/%00', '/game%5clink.txt'])
    assert.equal((await getRaw(url, input)).status, 400);
  assert.equal((await getRaw(url, '/absent')).status, 404);
});

function tarRecord(name, data = '', type = '0') {
  const bytes = Buffer.from(data),
    header = Buffer.alloc(512);
  header.write(name, 0, 100);
  header.write('0000644\0', 100);
  header.write(`${bytes.length.toString(8).padStart(11, '0')}\0`, 124);
  header.write('00000000000\0', 136);
  header.fill(32, 148, 156);
  header.write(type, 156);
  header.write('ustar\0', 257);
  const checksum = header.reduce((sum, byte) => sum + byte, 0);
  header.write(`${checksum.toString(8).padStart(6, '0')}\0 `, 148);
  return Buffer.concat([header, bytes, Buffer.alloc((512 - (bytes.length % 512)) % 512)]);
}

test('Git archive reader extracts regular data and rejects links, traversal and duplicates', () => {
  const archive = Buffer.concat([
    tarRecord('game/', '', '5'),
    tarRecord('game/index.html', '<h1>Archived</h1>'),
    Buffer.alloc(1024),
  ]);
  const records = readTarEntries(archive);
  assert.equal(records.length, 1);
  assert.equal(records[0].name, 'game/index.html');
  assert.equal(records[0].bytes.toString(), '<h1>Archived</h1>');
  for (const archive of [
    tarRecord('../escape', 'x'),
    tarRecord('/absolute', 'x'),
    tarRecord('link', 'x', '2'),
    tarRecord('.git/config', 'x'),
    Buffer.concat([tarRecord('file', 'a'), tarRecord('file', 'b')]),
  ])
    assert.throws(() => readTarEntries(archive));
  const bad = tarRecord('file', 'a');
  bad[20] ^= 1;
  assert.throws(() => readTarEntries(bad), /checksum/);
  assert.throws(() => readTarEntries(tarRecord('file', 'more').subarray(0, 514)), /Truncated/);
});

test('generator produces deterministic explicit valid maps across seeds using the actual core', async () => {
  const core = await import('../game/core/index.mjs');
  const browserGenerator = await import('../game/generator.mjs');
  const a = await generateLevel('sunflower'),
    b = await generateLevel('sunflower');
  assert.deepEqual(a, b);
  assert.deepEqual(a, browserGenerator.generateLevel('sunflower'));
  const seen = new Set();
  for (const seed of [
    'sunflower',
    'night',
    'Київ',
    '0',
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
  ]) {
    const level = await generateLevel(seed);
    assert.equal(level.width, 48);
    assert.equal(level.height, 36);
    assert.equal(core.validateLevel(level).valid, true);
    seen.add(JSON.stringify(level.walls));
  }
  assert.ok(seen.size > 1);
  await assert.rejects(generateLevel(''), /Seed/);
});

test('campaign validation uses the core and rejects duplicate or malformed levels', async (t) => {
  const { root } = await fixture(t);
  await fs.mkdir(path.join(root, 'game/core'));
  await fs.mkdir(path.join(root, 'game/content'));
  const actualCore = path.resolve(
    path.dirname(fileURLToPath(import.meta.url)),
    '../game/core/index.mjs',
  );
  // The fixture delegates to the exact runtime validator; no duplicate validator is maintained.
  await fs.writeFile(
    path.join(root, 'game/core/index.mjs'),
    `export { validateLevel } from ${JSON.stringify(pathToFileURL(actualCore).href)};`,
  );
  const level = await generateLevel('campaign-fixture');
  const campaign = { version: 'xonix-campaign.v1', id: 'fixture', revision: '1', levels: [level] };
  const write = () =>
    fs.writeFile(path.join(root, 'game/content/campaign.json'), JSON.stringify(campaign));
  await write();
  assert.equal((await validateLevels(root)).levels, 1);
  campaign.levels.push(level);
  await write();
  await assert.rejects(validateLevels(root), /Duplicate/);
  campaign.levels = [{ ...level, width: 0 }];
  await write();
  await assert.rejects(validateLevels(root), /Invalid campaign/);
});

test('theme validation uses the actual content registry and rejects invalid or duplicate entries', async (t) => {
  const { root } = await fixture(t);
  await fs.mkdir(path.join(root, 'game/content'));
  const actualContent = path.resolve(
    path.dirname(fileURLToPath(import.meta.url)),
    '../game/content.mjs',
  );
  await fs.writeFile(
    path.join(root, 'game/content.mjs'),
    `export { validateTheme } from ${JSON.stringify(pathToFileURL(actualContent).href)};`,
  );
  const document = JSON.parse(
    await fs.readFile(new URL('../game/content/themes.json', import.meta.url), 'utf8'),
  );
  const write = () =>
    fs.writeFile(path.join(root, 'game/content/themes.json'), JSON.stringify(document));
  await write();
  assert.equal((await validateThemes(root)).themes, document.themes.length);
  document.themes.push(structuredClone(document.themes[0]));
  await write();
  await assert.rejects(validateThemes(root), /duplicate theme ID/);
  document.themes.pop();
  document.themes[0].scene = 'unregistered';
  await write();
  await assert.rejects(validateThemes(root), /Invalid theme/);
  document.themes = [];
  await write();
  await assert.rejects(validateThemes(root), /nonempty themes/);
});

test('class validation accepts current data and rejects unsupported mechanics through the core', async (t) => {
  const { root } = await fixture(t);
  await fs.mkdir(path.join(root, 'game/content'));
  await fs.mkdir(path.join(root, 'game/core'));
  const actualCore = path.resolve(
    path.dirname(fileURLToPath(import.meta.url)),
    '../game/core/index.mjs',
  );
  await fs.writeFile(
    path.join(root, 'game/core/index.mjs'),
    `export { validateClassRecipes } from ${JSON.stringify(pathToFileURL(actualCore).href)};`,
  );
  const recipes = JSON.parse(
    await fs.readFile(new URL('../game/content/classes.json', import.meta.url), 'utf8'),
  );
  const write = () =>
    fs.writeFile(path.join(root, 'game/content/classes.json'), JSON.stringify(recipes));
  await write();
  assert.equal((await validateClasses(root)).classes, recipes.length);
  recipes[0].primitive = 'teleport';
  await write();
  await assert.rejects(validateClasses(root), /Invalid class recipes/);
});

test('packaged offline builds generate scoped metadata, generated brand icons, complete integrity inventory and reproducible bytes', async (t) => {
  const { root, out, directory } = await fixture(t);
  await fs.mkdir(path.join(root, 'game/offline'));
  await fs.copyFile(
    new URL('../game/offline.mjs', import.meta.url),
    path.join(root, 'game/offline.mjs'),
  );
  // This fixture exercises the core offline cache, not the separate installed
  // app/update sentinel. Supply its bounded update-context dependency.
  await fs.writeFile(
    path.join(root, 'game/game-updates.mjs'),
    'export function readGameUpdateContext() { return null; }\n',
  );
  await fs.mkdir(path.join(root, 'game/content-design'));
  await fs.copyFile(
    new URL('../game/content-design/limits.mjs', import.meta.url),
    path.join(root, 'game/content-design/limits.mjs'),
  );
  await fs.copyFile(
    new URL('../game/platform.mjs', import.meta.url),
    path.join(root, 'game/platform.mjs'),
  );
  await fs.copyFile(
    new URL('../game/offline/service-worker.template.js', import.meta.url),
    path.join(root, 'game/offline/service-worker.template.js'),
  );
  await fs.mkdir(path.join(root, 'game/playground'));
  await fs.writeFile(
    path.join(root, 'game/playground/index.html'),
    '<html><head><title>Nested</title><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"></head><body>Preview</body></html>',
  );
  await fs.mkdir(path.join(root, 'game/ui'));
  await fs.writeFile(
    path.join(root, 'game/ui/install-entry.mjs'),
    'export const installOwner = true;',
  );
  await fs.mkdir(path.join(root, 'game/communities/coupa'), { recursive: true });
  await fs.writeFile(
    path.join(root, 'game/communities/coupa/index.html'),
    '<!doctype html><html data-community-entry="loading"><head><script type="module" src="../entry.mjs"></script></head><body>Opening community</body></html>',
  );
  await fs.writeFile(
    path.join(root, 'game/communities/entry.mjs'),
    'export const loadSharedHost = true;',
  );
  // Canonical sources remain in the distribution; the complete runtime catalog
  // is the sole copy needed by a player preparing offline play.
  await fs.mkdir(path.join(root, 'game/i18n'));
  await fs.mkdir(path.join(root, 'game/locales/en'), { recursive: true });
  const localeSource = '{"language":"Language"}';
  const localeBundle = 'globalThis.RevealLineTranslations = {en:{common:{language:"Language"}}};';
  await fs.writeFile(path.join(root, 'game/locales/en/common.json'), localeSource);
  await fs.writeFile(path.join(root, 'game/i18n/catalogs.mjs'), localeBundle);
  const source = await fs.readFile(path.join(root, 'game/index.html'), 'utf8');
  const first = await buildProject({ root, out });
  const second = await buildProject({ root, out: path.join(directory, 'second') });
  assert.equal(first.sha256, second.sha256);
  const inspected = await inspectBuildProject({ root });
  const actualManifestBytes = await fs.readFile(path.join(out, 'manifest.json'));
  assert.deepEqual(inspected.manifest, JSON.parse(actualManifestBytes));
  assert.equal(actualManifestBytes.toString(), `${JSON.stringify(inspected.manifest)}\n`);
  assert.equal(inspected.manifestDescriptor.sha256, hash(actualManifestBytes));
  const cache = JSON.parse(await fs.readFile(path.join(out, 'offline-cache.json'), 'utf8'));
  assert.equal(
    await fs.readFile(path.join(out, 'offline-cache.json'), 'utf8'),
    `${JSON.stringify(cache)}\n`,
  );
  const manifest = JSON.parse(await fs.readFile(path.join(out, 'manifest.webmanifest'), 'utf8'));
  assert.equal(manifest.start_url, './game/');
  assert.equal(manifest.scope, './');
  assert.equal(manifest.display, 'fullscreen');
  assert.deepEqual(manifest.display_override, ['fullscreen', 'standalone', 'minimal-ui']);
  assert.ok(manifest.icons.some((i) => i.sizes === '192x192'));
  assert.ok(manifest.icons.some((i) => i.sizes === '512x512'));
  for (const file of cache.files) {
    const bytes = await fs.readFile(path.join(out, file.path));
    assert.equal(hash(bytes), file.sha256);
    assert.equal(bytes.length, file.bytes);
  }
  assert.ok(cache.files.some((f) => f.path === 'game/i18n/catalogs.mjs'));
  assert.ok(!cache.files.some((f) => f.path.startsWith('game/locales/')));
  assert.equal(
    await fs.readFile(path.join(out, 'game/locales/en/common.json'), 'utf8'),
    localeSource,
  );
  assert.equal(await fs.readFile(path.join(out, 'game/i18n/catalogs.mjs'), 'utf8'), localeBundle);
  assert.ok(cache.files.some((f) => f.path === 'game/playground/index.html'));
  assert.ok(
    !cache.files.some(
      (f) =>
        f.path.includes('template') ||
        f.path === 'service-worker.js' ||
        f.path === 'offline-cache.json' ||
        f.path === '_headers',
    ),
  );
  const entry = await fs.readFile(path.join(out, 'game/index.html'), 'utf8');
  assert.match(entry, /revealline-offline/);
  assert.match(entry, /\.\.\/service-worker.js/);
  assert.match(entry, new RegExp(cache.buildId));
  const nested = await fs.readFile(path.join(out, 'game/playground/index.html'), 'utf8');
  assert.match(nested, /\.\.\/\.\.\/manifest.webmanifest/);
  for (const page of [entry, nested])
    assert.equal(
      [...page.matchAll(/<script\b[^>]*src="[^"]*\/ui\/install-entry\.mjs"/g)].length,
      1,
    );
  const community = await fs.readFile(path.join(out, 'game/communities/coupa/index.html'), 'utf8');
  assert.doesNotMatch(community, /install-entry\.mjs/);
  assert.deepEqual(
    [...community.matchAll(/<script\b[^>]*src="([^"]+)"/g)].map((match) => match[1]),
    ['../entry.mjs'],
    'Only the shared-host loader runs before document replacement; install listeners belong to the fetched main host.',
  );
  assert.match(community, /\.\.\/\.\.\/\.\.\/manifest.webmanifest/);
  assert.match(community, /\.\.\/\.\.\/\.\.\/service-worker.js/);
  assert.ok(cache.files.some((file) => file.path === 'game/communities/coupa/index.html'));
  assert.ok(cache.files.some((file) => file.path === 'game/communities/entry.mjs'));
  // Both missing metadata and an already prepared page produce one declaration.
  for (const page of [entry, nested]) {
    for (const [name, content] of [
      ['mobile-web-app-capable', 'yes'],
      ['apple-mobile-web-app-capable', 'yes'],
      ['apple-mobile-web-app-status-bar-style', 'black-translucent'],
    ]) {
      assert.equal([...page.matchAll(new RegExp(`name="${name}"`, 'g'))].length, 1);
      assert.match(page, new RegExp(`<meta name="${name}" content="${content}">`));
    }
  }
  const worker = await fs.readFile(path.join(out, 'service-worker.js'), 'utf8');
  assert.ok(worker.includes(cache.buildId));
  assert.ok(!worker.includes('__XONIX_OFFLINE_CONFIG__'));
  for (const size of [180, 192, 512]) {
    const icon = await fs.readFile(path.join(out, `icons/icon-${size}.png`));
    assert.equal(icon.readUInt32BE(16), size);
    assert.equal(icon.readUInt32BE(20), size);
    assert.ok(icon.length <= 128 * 1024);
  }
  const installManifest = JSON.parse(
    await fs.readFile(path.join(out, 'manifest.webmanifest'), 'utf8'),
  );
  assert.equal(installManifest.name, 'FPV / LINE');
  assert.equal(installManifest.short_name, 'FPV / LINE');
  assert.equal(installManifest.id, './');
  assert.equal(installManifest.scope, './');
  assert.match(
    await fs.readFile(path.join(out, 'credits.html'), 'utf8'),
    /href="\.\/icons\/icon-192\.png"/,
  );
  assert.equal(await fs.readFile(path.join(root, 'game/index.html'), 'utf8'), source);
  await assert.rejects(fs.access(path.join(out, 'game/offline/service-worker.template.js')));
  await fs.writeFile(path.join(root, 'game/core.mjs'), 'export const value=42;');
  await buildProject({ root, out });
  assert.notEqual(
    JSON.parse(await fs.readFile(path.join(out, 'offline-cache.json'), 'utf8')).buildId,
    cache.buildId,
  );
});

test('offline source sentinel requires its template and does not silently emit an incomplete installer', async (t) => {
  const { root, out } = await fixture(t);
  await fs.writeFile(path.join(root, 'game/offline.mjs'), 'export {};');
  await assert.rejects(buildProject({ root, out }), /ENOENT/);
});

test('compact offline catalogue and inventory preserve reader results, source text and integrity', async (t) => {
  const { root, out } = await fixture(t);
  const sources = {
    'game/offline.mjs': 'export {};',
    'game/installed-app.mjs': 'export {};',
    'game/offline/service-worker.template.js': 'const CONFIG = __XONIX_OFFLINE_CONFIG__;',
    'game/offline/app-worker.template.js': 'const CONFIG = __REVEALLINE_LAUNCHER_CONFIG__;',
    'game/offline/app.html': '<html><head></head><body>Installer</body></html>',
    'game/offline/app.mjs': 'export {};',
    'game/offline/navigation.css': 'body { color: navy; }',
    ...Object.fromEntries(
      LAUNCHER_NAVIGATION_FILES.map((file) => [
        'game/' + file,
        file.endsWith('.css') ? 'body { color: navy; }' : 'export {};',
      ]),
    ),
    'game/downloads.css': 'body { color: navy; }',
    'game/edition-context.mjs': 'export {};',
    'game/profile-writer.mjs': 'export {};',
    'game/i18n/index.mjs': 'export {};',
    'game/i18n/bootstrap.mjs': 'export {};',
    'game/i18n/style.css': 'body { color: navy; }',
    'game/vendor/i18next-26.4.2.min.js': 'globalThis.fixture = true;',
    'game/historical-original.json': '{"title":"Retained  original\\nОригінал","revision":1}',
  };
  for (const language of ['en', 'uk'])
    for (const [namespace, keys] of Object.entries({
      ...LAUNCHER_CATALOG_KEYS,
      controllerEditor: ['fixture'],
    }))
      sources[`game/locales/${language}/${namespace}.json`] = JSON.stringify(
        Object.fromEntries(keys.map((key) => [key, `${language}: ${key}  unchanged\ntext`])),
      );
  for (const [name, source] of Object.entries(sources)) {
    await fs.mkdir(path.dirname(path.join(root, name)), { recursive: true });
    await fs.writeFile(path.join(root, name), source);
  }
  await buildProject({ root, out });
  const manifest = JSON.parse(await fs.readFile(path.join(out, 'manifest.json')));
  const inventoryBytes = await fs.readFile(path.join(out, 'offline-inventory.json'));
  const catalogueBytes = await fs.readFile(path.join(out, 'offline-content.json'));
  const catalogue = JSON.parse(catalogueBytes);
  const cache = JSON.parse(await fs.readFile(path.join(out, 'offline-cache.json')));
  const entries = await Promise.all(
    manifest.files
      .filter((file) => file.path !== 'offline-inventory.json')
      .map(async (file) => ({
        name: file.path,
        bytes: await fs.readFile(path.join(out, file.path)),
      })),
  );
  const expected = buildOfflineInventory(entries, catalogue, cache.files);
  const expectedCatalogue = await buildOfflineContent(entries, new Set(), manifest.version);
  assert.deepEqual(catalogue, expectedCatalogue);
  assert.ok(
    catalogueBytes.length < Buffer.byteLength(`${JSON.stringify(expectedCatalogue, null, 2)}\n`),
  );
  const selectedGroups = catalogue.groups.map((group) => group.id);
  assert.ok(selectedGroups.length > 0);
  assert.deepEqual(
    downloadFiles(catalogue, selectedGroups),
    downloadFiles(expectedCatalogue, selectedGroups),
  );
  const catalogueDescriptor = {
    path: 'offline-content.json',
    bytes: catalogueBytes.length,
    sha256: hash(catalogueBytes),
  };
  assert.deepEqual(
    manifest.files.find((file) => file.path === catalogueDescriptor.path),
    catalogueDescriptor,
  );
  assert.deepEqual(
    cache.files.find((file) => file.path === catalogueDescriptor.path),
    catalogueDescriptor,
  );
  const inventory = JSON.parse(inventoryBytes);
  // The build sorts output only after inventory generation. Its record order
  // remains immaterial, while every descriptor, group and size must survive.
  const normalize = (value) => ({
    ...value,
    files: value.files.slice().sort((a, b) => a.path.localeCompare(b.path)),
  });
  assert.deepEqual(normalize(inventory), normalize(expected));
  assert.ok(inventoryBytes.length < Buffer.byteLength(`${JSON.stringify(expected, null, 2)}\n`));
  assert.deepEqual(
    manifest.files.find((file) => file.path === 'offline-inventory.json'),
    { path: 'offline-inventory.json', bytes: inventoryBytes.length, sha256: hash(inventoryBytes) },
  );
  for (const [name, source] of Object.entries(sources)) {
    if (name.startsWith('game/offline/')) continue;
    const emitted = await fs.readFile(path.join(out, name), 'utf8');
    // Current builds project allowlisted runtime module whitespace. The empty
    // module fixtures retain exactly the same export; authored JSON stays exact.
    if (source === 'export {};') assert.match(emitted, /^export\s*\{\s*\};$/, name);
    else assert.equal(emitted, source, name);
    assert.equal(await fs.readFile(path.join(root, name), 'utf8'), source, name);
    const record = inventory.files.find((file) => file.path === name);
    assert.equal(record?.bytes, Buffer.byteLength(emitted), name);
    assert.equal(record?.sha256, hash(Buffer.from(emitted)), name);
  }
});

test('public package has local entry, accurate storage notices and enforced preview headers without changing source serving', async (t) => {
  const { root, out } = await fixture(t);
  const openingTheme = path.join(
    root,
    'game/audio/soundtracks/d4147214e221be28f19d6c6c38afc8d3cf0289a0dc6ac579b26574a0c571bc58.mp3',
  );
  await fs.mkdir(path.dirname(openingTheme), { recursive: true });
  await fs.writeFile(openingTheme, 'exact-path packaging fixture');
  await buildProject({ root, out });
  const sourceServer = await startServer({ root, port: 0 }),
    releaseServer = await startServer({ root: out, port: 0 });
  t.after(() =>
    Promise.all(
      [sourceServer.server, releaseServer.server].map(
        (server) => new Promise((resolve) => server.close(resolve)),
      ),
    ),
  );
  const source = await getRaw(sourceServer.url, '/game/'),
    release = await getRaw(releaseServer.url, '/game/');
  assert.equal(source.headers['content-security-policy'], undefined);
  assert.match(release.headers['content-security-policy'], /script-src 'self' 'wasm-unsafe-eval'/);
  assert.doesNotMatch(release.headers['content-security-policy'], /'unsafe-eval'/);
  assert.equal(
    release.headers['content-security-policy']
      .split(';')
      .find((value) => value.trim().startsWith('connect-src'))
      .trim(),
    "connect-src 'self' https:",
    'Optional sources require HTTPS catalogue access in packaged previews; the manager gates user-selected sources.',
  );
  assert.match(PUBLIC_SECURITY_HEADERS['Content-Security-Policy'], /connect-src 'self';/);
  assert.match(release.headers['content-security-policy'], /media-src 'self' data: blob: https:;/);
  assert.equal(release.headers['referrer-policy'], 'no-referrer');
  assert.equal(release.headers['cache-control'], 'no-cache');
  const entry = await getRaw(releaseServer.url, '/');
  assert.match(entry.body, /Clear a path/);
  assert.doesNotMatch(entry.body, /http-equiv="refresh"/);
  assert.match(entry.body, /\.\/game\/index.html/);
  assert.match((await getRaw(releaseServer.url, '/privacy.html')).body, /does not upload/);
  const credits = (await getRaw(releaseServer.url, '/credits.html')).body;
  assert.match(credits, /PHASER-LICENSE/);
  assert.match(credits, /Carol of the Bells \(Metal Version\)/);
  assert.match(credits, /Alexander Nakarada \(CreatorChords\)/);
  assert.match(credits, /Creative Commons Attribution 4\.0 International/);
  assert.match(credits, /Mykola Leontovych’s <cite[^>]*>Shchedryk<\/cite>/);
  const publishedHeaders = await fs.readFile(path.join(out, '_headers'), 'utf8');
  assert.match(publishedHeaders, /Content-Security-Policy/);
  assert.doesNotMatch(publishedHeaders, /revealline-soundtracks-01/);
  const missing = await getRaw(releaseServer.url, '/missing.mjs');
  assert.equal(missing.status, 404);
  assert.match(missing.headers['content-type'], /text\/plain/);
});

async function optionalPackFixture(t) {
  const data = await fixture(t),
    { root } = data;
  await fs.mkdir(path.join(root, 'game/content/packs'), { recursive: true });
  await fs.mkdir(path.join(root, 'game/offline'));
  await fs.writeFile(path.join(root, 'game/offline.mjs'), 'export {};');
  await fs.copyFile(
    new URL('../game/offline/service-worker.template.js', import.meta.url),
    path.join(root, 'game/offline/service-worker.template.js'),
  );
  const name = 'night-shift.json';
  await fs.copyFile(
    new URL(`../game/content/packs/${name}`, import.meta.url),
    path.join(root, 'game/content/packs', name),
  );
  await fs.writeFile(
    path.join(root, 'game/content/packs/index.json'),
    JSON.stringify({ format: 'xonix-pack-index.v1', packs: [{ id: 'night-shift', path: name }] }),
  );
  for (const module of [
    'packs.mjs',
    'mastery-catalog.mjs',
    'library.mjs',
    'core/level.mjs',
    'core/registry.mjs',
    'data-json.mjs',
  ]) {
    const destination = path.join(root, 'game', module);
    await fs.mkdir(path.dirname(destination), { recursive: true });
    await fs.writeFile(
      destination,
      `export * from ${JSON.stringify(new URL(`../game/${module}`, import.meta.url).href)};\n`,
    );
  }
  const config = {
    version: 'optional-test',
    entry: 'game/index.html',
    include: ['game'],
    optionalOffline: [`game/content/packs/${name}`],
  };
  const setConfig = (value) =>
    fs.writeFile(path.join(root, 'game/build-config.json'), JSON.stringify(value));
  await setConfig(config);
  return { ...data, config, setConfig };
}
test('optional indexed pack keeps exact shipped and ZIP bytes while core cache excludes only the declared source', async (t) => {
  const { root, out, directory } = await optionalPackFixture(t);
  await fs.mkdir(path.join(root, 'game/communities/coupa'), { recursive: true });
  await fs.writeFile(
    path.join(root, 'game/communities/coupa/index.html'),
    '<!doctype html><html data-community-entry="loading"><head></head><body>Opening community</body></html>',
  );
  const result = await buildProject({ root, out });
  const again = await buildProject({ root, out: path.join(directory, 'same') });
  assert.equal(result.sha256, again.sha256);
  const manifest = JSON.parse(await fs.readFile(path.join(out, 'manifest.json'))),
    cache = JSON.parse(await fs.readFile(path.join(out, 'offline-cache.json')));
  const name = 'game/content/packs/night-shift.json',
    original = await fs.readFile(path.join(root, name));
  assert.deepEqual(await fs.readFile(path.join(out, name)), original);
  assert.equal(manifest.files.find((f) => f.path === name).sha256, hash(original));
  assert.equal(
    cache.files.some((f) => f.path === name),
    false,
  );
  assert.ok(cache.files.some((f) => f.path === 'game/content/packs/index.json'));
  assert.deepEqual(cache.optionalPacks, [
    { path: name, id: 'night-shift', name: 'Night Shift', sha256: hash(original) },
  ]);
  const page = await fs.readFile(path.join(out, 'game/index.html'), 'utf8');
  assert.match(page, /optionalPacks/);
  const shell = await fs.readFile(path.join(out, 'game/communities/coupa/index.html'), 'utf8');
  assert.doesNotMatch(shell, /optionalPacks|optionalArtwork/);
  assert.match(shell, /revealline-offline/);
  assert.match(shell, new RegExp(cache.buildId));
  assert.ok(cache.files.some((file) => file.path === 'game/communities/coupa/index.html'));
  const zip = await fs.readFile(path.join(out, 'distribution.zip'));
  assert.ok(zip.includes(original), 'Stored ZIP entry retains exact optional pack payload.');
  const omitted = manifest.files
    .filter((f) => !cache.files.some((c) => c.path === f.path))
    .map((f) => f.path);
  assert.deepEqual(
    omitted.sort(),
    ['_headers', name, 'offline-cache.json', 'service-worker.js'].sort(),
  );
});
test('optional offline policy rejects non-pack, unknown, duplicate, unsafe, missing and excluded sources', async (t) => {
  const { root, config, setConfig } = await optionalPackFixture(t);
  for (const value of [
    null,
    'game/app.mjs',
    ['game/app.mjs'],
    ['game/content/packs/index.json'],
    ['game/content/packs/archive-index.json'],
    ['game/content/packs/archive-catalog.json'],
    ['game/content/packs/missing.json'],
    ['game/content/packs/../night-shift.json'],
    [...config.optionalOffline, ...config.optionalOffline],
  ]) {
    await setConfig({ ...config, optionalOffline: value });
    await assert.rejects(readBuildConfig(root));
  }
  await setConfig({
    ...config,
    include: ['game/index.html'],
    optionalOffline: config.optionalOffline,
  });
  await assert.rejects(collectBuildFiles(root), /not shipped/);
  await setConfig(config);
  await fs.rm(path.join(root, config.optionalOffline[0]));
  await assert.rejects(readBuildConfig(root));
});
test('archived packs stay downloadable with exact bytes while both navigation catalogs remain in the core cache', async (t) => {
  const { root, out, config } = await optionalPackFixture(t);
  const folder = path.join(root, 'game/content/packs');
  await fs.rename(path.join(folder, 'index.json'), path.join(folder, 'archive-index.json'));
  await fs.writeFile(
    path.join(folder, 'index.json'),
    JSON.stringify({ format: 'xonix-pack-index.v1', packs: [] }),
  );
  await generatePackCatalogs({ root, write: true });
  assert.deepEqual((await readBuildConfig(root)).optionalOffline, config.optionalOffline);
  await buildProject({ root, out });
  const cache = JSON.parse(await fs.readFile(path.join(out, 'offline-cache.json')));
  const name = config.optionalOffline[0];
  assert.equal(
    cache.files.some((file) => file.path === name),
    false,
  );
  assert.deepEqual(
    await fs.readFile(path.join(out, name)),
    await fs.readFile(path.join(root, name)),
  );
  for (const metadata of [
    'index.json',
    'catalog.json',
    'archive-index.json',
    'archive-catalog.json',
  ])
    assert.ok(cache.files.some((file) => file.path === `game/content/packs/${metadata}`));
  const before = await fs.readFile(path.join(out, 'manifest.json'));
  const archived = JSON.parse(await fs.readFile(path.join(folder, 'archive-catalog.json')));
  archived.packs[0].campaigns[0].levels[0].name = 'Incorrect archived map';
  await fs.writeFile(path.join(folder, 'archive-catalog.json'), JSON.stringify(archived));
  await assert.rejects(buildProject({ root, out }), /catalog differs/);
  assert.deepEqual(await fs.readFile(path.join(out, 'manifest.json')), before);
  await fs.rm(path.join(folder, 'archive-catalog.json'));
  await assert.rejects(buildProject({ root, out }));
  assert.deepEqual(await fs.readFile(path.join(out, 'manifest.json')), before);
});
test('declaring an optional pack does not relax the 80 MiB core cache budget', async (t) => {
  const { root, out } = await optionalPackFixture(t);
  await fs.writeFile(path.join(root, 'game/core-payload.bin'), Buffer.alloc(80 * 1024 * 1024));
  await assert.rejects(buildProject({ root, out }), /80 MiB/);
  await assert.rejects(fs.access(out));
});
