import { performance } from 'node:perf_hooks';
import { createHash } from 'node:crypto';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const started = performance.now();
const event = (phase, state, extra = {}) => console.log(JSON.stringify({ phase, state, elapsedMs: performance.now() - started, ...extra }));
const inventory = (entries) => entries.map((entry) => ({ path: entry.name, bytes: entry.bytes.length, sha256: createHash('sha256').update(entry.bytes).digest('hex') }));
const stage = async (name, run, describe = (value) => value) => {
  event(name, 'start');
  const began = performance.now(), cpu = process.cpuUsage();
  try {
    const value = await run(), used = process.cpuUsage(cpu);
    event(name, 'complete', { phaseElapsedMs: performance.now() - began, userCpuMs: used.user / 1000, systemCpuMs: used.system / 1000, result: describe(value) });
    return value;
  } catch (error) { event(name, 'failed', { message: error.message }); throw error; }
};
const { readBuildConfig } = await import(`${root}/scripts/game-cli.mjs`);
const config = await readBuildConfig(root);
const { readOptionalDistributionEntries } = await import(`${root}/scripts/optional-distribution.mjs`);
await stage('optional-chapters', () => readOptionalDistributionEntries(root, config.optionalChapters), inventory);
const { readExternalDistributionEntries } = await import(`${root}/scripts/external-distribution.mjs`);
const external = await stage('external-chapters', () => readExternalDistributionEntries(root, config.externalChapters), inventory);
const { buildMissionLibraryIndex, assertMissionLibraryIndex, MISSION_LIBRARY_INDEX_PATH } = await import(`${root}/scripts/mission-library-index.mjs`);
const fs = await import('node:fs/promises');
await stage('mission-library-index', async () => {
  const original = JSON.parse(await fs.readFile(`${root}/${MISSION_LIBRARY_INDEX_PATH}`));
  const generated = await buildMissionLibraryIndex({ root, externalEntries: external });
  assertMissionLibraryIndex(original, generated);
  return { originalMatches: true };
});
const { readSoundtrackDistributionEntries } = await import(`${root}/scripts/soundtrack-distribution.mjs`);
await stage('soundtrack-albums', () => readSoundtrackDistributionEntries(root, config.soundtrackAlbums), inventory);
event('distribution-preparation-operations', 'complete', { scope: 'Read-only original additional-content generation and admission, without localization, full assembly or ZIP/site writes. Not a complete normal build, CI, or publication pass.' });
