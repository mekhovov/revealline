import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const base = '/Volumes/alex/CodexMigrationStaging';
const output = `${base}/practice-local-diagnosis-20261019-evidence`;
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const json = async (file) => JSON.parse(await fs.readFile(file, 'utf8'));
const exists = (file) => fs.access(file).then(() => true, () => false);
const phases = [];
for (const name of ['localization', 'core-preparation', 'distribution-preparation']) {
  const directory = `${base}/practice-${name}-phase-20261019`;
  const receipt = await json(`${directory}/receipt.json`);
  assert(receipt.completed && receipt.sourceUnchanged && !receipt.buildPerformed && !receipt.qualified);
  assert.equal(receipt.source.sourceRevision, '929348a2031f2f994bdc21e3550b34ca1ab4475a');
  assert.deepEqual(receipt.source, receipt.sourceAfter);
  assert.equal(receipt.deadlineMs, 600000);
  assert.equal(receipt.result.exitCode, 0);
  assert(!receipt.result.timedOut && !receipt.result.interrupted && !receipt.result.executionError);
  assert.equal(hash(await fs.readFile(`${directory}/phases.jsonl`)), receipt.logSha256);
  phases.push({ name, source: receipt.source, elapsedMs: receipt.events.at(-1).elapsedMs,
    operations: receipt.events.filter((event) => event.state === 'complete').map(({ phase, phaseElapsedMs }) => ({ phase, phaseElapsedMs })) });
}
const profile = await json(`${base}/practice-localization-external-profile-20261019/receipt.json`);
assert(profile.captureComplete && profile.sourceUnchanged && !profile.qualified && !profile.buildPerformed);
assert.equal(profile.failure, null);
assert.equal(profile.validationResult, null);
assert.equal(profile.windows.length, 3);
const profileSummary = await json(`${base}/practice-localization-external-profile-20261019/summary-3-windows.json`);
for (const window of profileSummary.windows) {
  const raw = await fs.readFile(`${base}/practice-localization-external-profile-20261019/${window.file}`);
  assert.equal(hash(raw), window.sha256);
  const value = JSON.parse(raw);
  assert(value.samples.length > 0 && value.samples.length === value.timeDeltas.length);
}
const build = await json(`${base}/practice-macmini-progress-build-20261019/receipt.json`);
assert(!build.passed && build.sourceUnchanged && build.result.timedOut);
assert.equal(build.deadlineMs, 600000);
assert.equal(build.source.sourceRevision, '56acb4240af76c5b351427cc9e87a422070a4463');
assert.deepEqual(build.before, build.after);
assert.equal(build.before.length, 4429);
assert.equal(build.result.groupCleanup.absent, true);
assert.equal(build.phases.at(-1), 'expanded-files');
assert(!build.storageBudget.abortedForSpace && !build.storageBudget.guardError);
assert.equal(await exists(build.destination), false);
assert.equal(hash(await fs.readFile(`${base}/practice-macmini-progress-build-20261019/build.log`)), build.logSha256);
const tap = await fs.readFile('/private/tmp/practice-clone-veto-final-green-20261019.tap', 'utf8');
for (const line of ['# tests 53', '# pass 53', '# fail 0', '# cancelled 0', '# skipped 0']) assert(tap.split('\n').includes(line));
const academy = await json(`${base}/practice-main-237-academy-active-20261019-audit.json`);
const offline = await json(`${base}/practice-main-237-offline-20261019-audit.json`);
assert(academy.passed && offline.passed);
assert.equal(academy.receiptSha256, hash(await fs.readFile(`${base}/practice-main-237-academy-active-20261019.json`)));
assert.equal(offline.reportSha256, hash(await fs.readFile(`${base}/practice-main-237-offline-20261019.json`)));
assert.equal(offline.offlineRoutes, 6);
const scope = {
  format: 'PracticeLocalDiagnosisEvidence.v1', audited: true,
  toolSource: '623918462685c27f30bb03141f76e02ab863d255',
  simulatorSource: '6177d2cc83adb9cb76ff4088d502c21ddfd7d199',
  phases, targetedTests: { passed: 53, failed: 0, skipped: 0, cancelled: 0 },
  externalProfile: 'Three externally timed sampling windows only. Validation intentionally not completed. Not full-build attribution or performance acceptance.',
  normalBuild: { passed: false, source: build.source, deadlineMs: build.deadlineMs, lastStartedPhase: build.phases.at(-1), outputAbsent: true, inputPinsUnchanged: 4429, ownedGroupAbsent: true },
  academy: { passed: true, receiptSha256: academy.receiptSha256, visiblePausedHeight: academy.visiblePausedHeight, resumedHeight: academy.resumedHeight, syntheticSharedProofExplicit: true },
  offline: { passed: true, receiptSha256: offline.reportSha256, routes: 6, networkBoundary: 'Browser context offline before app navigation following actual Chrome process restart; not machine-wide airplane mode.' },
  limitations: ['No successful full normal build of 623; no current production directory journey.', 'Small ABBA writer runs overlap: no demonstrated full-build improvement.', 'No real all-app loss recovery, native outstanding-digest cancellation, performance-budget approval, human accessibility/novice/content/license acceptance, hardware or publication claim.', 'Historical Worlds active-session remains owner-deferred and unverified.'],
};
await fs.mkdir(output);
for (const name of ['practice-localization-external-profile-20261019', 'practice-localization-phase-20261019', 'practice-core-preparation-phase-20261019', 'practice-distribution-preparation-phase-20261019', 'practice-macmini-progress-build-20261019', 'practice-clone-veto-comparison-20261019'])
  await fs.cp(`${base}/${name}`, `${output}/${name}`, { recursive: true, force: false, errorOnExist: true });
for (const name of [
  'practice-localization-external-profile-20261019.mjs', 'practice-localization-external-profile-20261019.log',
  'practice-localization-profile-target-20261019.mjs', 'practice-localization-profile-summary-20261019.mjs',
  'practice-localization-profile-summary-1-20261019.log', 'practice-localization-profile-summary-3-20261019.log',
  'practice-localization-phase-runner-20261019.mjs', 'practice-localization-phase-runner-20261019.log', 'practice-localization-phase-target-20261019.mjs',
  'practice-core-preparation-phase-runner-20261019.mjs', 'practice-core-preparation-phase-runner-20261019.log', 'practice-core-preparation-phase-target-20261019.mjs',
  'practice-distribution-preparation-phase-runner-20261019.mjs', 'practice-distribution-preparation-phase-runner-20261019.log', 'practice-distribution-preparation-phase-target-20261019.mjs',
  'practice-macmini-progress-build-20261019.mjs', 'practice-macmini-progress-build-20261019.log', 'practice-owned-build-staging-20261019.mjs',
  'practice-build-progress-red-20261019.tap', 'practice-build-progress-green-20261019.tap', 'practice-build-progress-final-green-20261019.tap',
  'practice-clone-veto-red-20261019.tap', 'practice-clone-veto-green-20261019.tap', 'practice-clone-veto-final-green-20261019.tap',
  'practice-clone-veto-comparison-20261019.mjs', 'practice-clone-veto-comparison-20261019.log',
  'practice-main-237-academy-active-audit-20261019.mjs', 'practice-main-237-offline-audit-20261019.mjs',
]) await fs.copyFile(`/private/tmp/${name}`, `${output}/${name}`, fs.constants.COPYFILE_EXCL);
for (const name of [
  'practice-owned-build-staging-20261019.json',
  'practice-main-237-academy-active-20261019.json', 'practice-main-237-academy-active-20261019.log',
  'practice-main-237-academy-active-20261019-audit.json', 'practice-main-237-academy-active-audit-20261019.log',
  'practice-main-237-offline-20261019.json', 'practice-main-237-offline-20261019.log',
  'practice-main-237-offline-20261019-audit.json', 'practice-main-237-offline-audit-20261019.log',
  'practice-main-237-offline-preflight-20261019.json',
]) await fs.copyFile(`${base}/${name}`, `${output}/${name}`, fs.constants.COPYFILE_EXCL);
const images = [...offline.screenshots, JSON.parse(await fs.readFile(`${base}/practice-main-237-academy-active-20261019.json`, 'utf8')).activeSession.screenshot];
for (const row of images) {
  const bytes = await fs.readFile(row.path);
  assert.equal(hash(bytes), row.sha256);
  assert.equal(bytes.length, row.bytes);
  await fs.copyFile(row.path, `${output}/${path.basename(row.path)}`, fs.constants.COPYFILE_EXCL);
}
for (const revision of ['929348a2031f2f994bdc21e3550b34ca1ab4475a', '56acb4240af76c5b351427cc9e87a422070a4463', '623918462685c27f30bb03141f76e02ab863d255']) {
  const directory = `${output}/source-${revision.slice(0, 9)}`;
  await fs.mkdir(directory);
  for (const name of ['game-cli.mjs', 'build-entry-writer.mjs', 'test-game-cli.mjs', 'test-build-entry-writer.mjs'])
    await fs.writeFile(`${directory}/${name}`, execFileSync('git', ['show', `${revision}:scripts/${name}`], { cwd: root }), { flag: 'wx' });
}
await fs.writeFile(`${output}/source.patch`, execFileSync('git', ['diff', '929348a2031f2f994bdc21e3550b34ca1ab4475a..623918462685c27f30bb03141f76e02ab863d255'], { cwd: root }), { flag: 'wx' });
await fs.copyFile('/private/tmp/practice-retain-local-diagnosis-20261019.mjs', `${output}/retention.mjs`, fs.constants.COPYFILE_EXCL);
await fs.writeFile(`${output}/scope.json`, JSON.stringify(scope, null, 2) + '\n', { flag: 'wx' });
const files = [];
async function walk(directory, prefix = '') {
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    const name = prefix + entry.name, location = path.join(directory, entry.name);
    if (entry.isDirectory()) await walk(location, `${name}/`);
    else {
      assert(entry.isFile());
      const bytes = await fs.readFile(location);
      files.push({ path: name, bytes: bytes.length, sha256: hash(bytes) });
    }
  }
}
await walk(output);
files.sort((a, b) => a.path.localeCompare(b.path));
await fs.writeFile(`${output}/inventory.json`, JSON.stringify({ files }, null, 2) + '\n', { flag: 'wx' });
const archive = `${base}/flight-practice-local-diagnosis-20261019-evidence.tgz`;
assert.equal(await exists(archive), false);
execFileSync('tar', ['-czf', archive, '-C', base, path.basename(output)]);
const extracted = await fs.mkdtemp(`${base}/practice-local-diagnosis-verification-`);
execFileSync('tar', ['-xzf', archive, '-C', extracted]);
for (const row of files) {
  const bytes = await fs.readFile(`${extracted}/${path.basename(output)}/${row.path}`);
  assert.equal(bytes.length, row.bytes);
  assert.equal(hash(bytes), row.sha256);
}
const target = `${root}/docs/flight-practice-local-diagnosis-20261019-evidence.tgz`;
await fs.copyFile(archive, target, fs.constants.COPYFILE_EXCL);
assert.equal(hash(await fs.readFile(target)), hash(await fs.readFile(archive)));
const result = { retained: true, sha256: hash(await fs.readFile(target)), files: files.length, bytes: files.reduce((sum, row) => sum + row.bytes, 0), target, extracted, fullBuildPassed: false, academyContinuity: true, offlineRoutes: 6 };
await fs.writeFile(`${base}/practice-local-diagnosis-retention-20261019.json`, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result));
