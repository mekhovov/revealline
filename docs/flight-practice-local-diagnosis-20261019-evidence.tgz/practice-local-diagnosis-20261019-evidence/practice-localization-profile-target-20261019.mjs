import fs from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const output = '/Volumes/alex/CodexMigrationStaging/practice-localization-external-profile-20261019';
const started = performance.now();
try {
  const { validateLocalization } = await import(`${root}/scripts/localization.mjs`);
  const result = await validateLocalization(root);
  await fs.writeFile(`${output}/validation-result.json`, JSON.stringify({ completed: true, result, elapsedMs: performance.now() - started }) + '\n', { flag: 'wx' });
} catch (error) {
  await fs.writeFile(`${output}/validation-result.json`, JSON.stringify({ completed: false, error: error.message, elapsedMs: performance.now() - started }) + '\n', { flag: 'wx' });
  process.exitCode = 1;
}
