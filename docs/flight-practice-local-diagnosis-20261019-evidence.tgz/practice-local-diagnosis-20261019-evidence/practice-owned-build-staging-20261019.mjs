import fs from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
const base = '/Volumes/alex/CodexMigrationStaging';
const exact = `${process.execPath} scripts/game-cli.mjs build --progress stderr --out ${base}/flight-practice-main-237-20261019-progress-production --version v0.151.1 --revision 56acb4240af76c5b351427cc9e87a422070a4463`;
const rows = execFileSync('ps', ['-axo', 'pid=,command='], { encoding: 'utf8' }).split('\n').map((line) => /^\s*(\d+)\s+(.+)$/.exec(line)).filter((row) => row?.[2] === exact);
const report = { format: 'PracticeOwnedBuildStagingObservation.v1', capturedAt: new Date().toISOString(), exactCommandMatches: rows.length, observations: [], scope: 'Read-only ownership witness from exact current build argv and open file descriptors; not permission to remove unrelated staging directories or a completed build.' };
for (const row of rows) {
  const names = execFileSync('lsof', ['-p', row[1], '-Fn'], { encoding: 'utf8', timeout: 3000 }).split('\n');
  const staging = [...new Set(names.filter((name) => name.startsWith(`n${base}/.xonix-build-`)).map((name) => name.slice(1).split('/').slice(0, 5).join('/')))];
  report.observations.push({ pid: Number(row[1]), staging });
}
await fs.writeFile(`${base}/practice-owned-build-staging-20261019.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(report));
