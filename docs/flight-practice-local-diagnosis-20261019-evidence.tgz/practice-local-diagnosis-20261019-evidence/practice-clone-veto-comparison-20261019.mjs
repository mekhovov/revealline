import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import assert from 'node:assert/strict';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const base = '/Volumes/alex/CodexMigrationStaging';
const output = `${base}/practice-clone-veto-comparison-20261019`;
await fs.mkdir(output);
const original = execFileSync('git', ['show', '56acb4240af76c5b351427cc9e87a422070a4463:scripts/build-entry-writer.mjs'], { cwd: root });
const oldModule = `${output}/build-entry-writer-56ac-original.mjs`;
await fs.writeFile(oldModule, original, { flag: 'wx' });
const before = await import(pathToFileURL(oldModule).href);
const after = await import(pathToFileURL(`${root}/scripts/build-entry-writer.mjs`).href);
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const revised = await fs.readFile(`${root}/scripts/build-entry-writer.mjs`);
const paths = execFileSync('git', ['ls-files', '-z', 'game'], { cwd: root, encoding: 'utf8' }).split('\0').filter((name) => /^game\/[^/]+\.mjs$/.test(name));
const entries = [];
for (const name of paths) {
  if ((await fs.stat(`${root}/${name}`)).size > 4096) continue;
  entries.push({ name, bytes: await fs.readFile(`${root}/${name}`) });
  if (entries.length === 24) break;
}
assert.equal(entries.length, 24);
const work = await fs.mkdtemp(`${base}/practice-owned-clone-veto-`);
const report = { format: 'PracticeCloneVetoComparison.v1', originalSource: '56acb4240af76c5b351427cc9e87a422070a4463', originalWriterSha256: hash(original), revisedWriterSha256: hash(revised), node: process.version, work, entries: entries.map((entry) => ({ path: entry.name, bytes: entry.bytes.length, sha256: hash(entry.bytes) })), cases: [], scope: 'ABBA small shared-volume filesystem diagnostic using the same four-worker batch before/after a conservative clone veto. No exclusive resources, full-build, gameplay performance or publication qualification.' };
try {
  for (const [id, module] of [['before-1', before], ['after-1', after], ['after-2', after], ['before-2', before]]) {
    const destination = `${work}/${id}`;
    await fs.mkdir(destination);
    const began = performance.now();
    await module.writeBuildEntries(root, destination, entries);
    const elapsedMs = performance.now() - began;
    let next = 0;
    await Promise.all(Array.from({ length: 4 }, async () => { while (next < entries.length) { const entry = entries[next++]; assert.deepEqual(await fs.readFile(path.join(destination, entry.name)), entry.bytes); } }));
    report.cases.push({ id, elapsedMs, exactFilesVerified: 24 });
    console.log(JSON.stringify(report.cases.at(-1)));
  }
  assert.equal(hash(await fs.readFile(`${root}/scripts/build-entry-writer.mjs`)), report.revisedWriterSha256);
  report.sourceUnchangedDuringProbe = true;
} finally {
  await fs.rm(work, { recursive: true });
  report.ownedTemporaryDirectoryRemoved = true;
  await fs.writeFile(`${output}/report.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ output, cases: report.cases, ownedTemporaryDirectoryRemoved: true }));
}
