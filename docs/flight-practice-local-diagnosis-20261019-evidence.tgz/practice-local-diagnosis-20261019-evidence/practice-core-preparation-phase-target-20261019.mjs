import { performance } from 'node:perf_hooks';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const started = performance.now();
const event = (phase, state, extra = {}) => console.log(JSON.stringify({ phase, state, elapsedMs: performance.now() - started, ...extra }));
const stage = async (name, run) => {
  event(name, 'start');
  const began = performance.now(), cpu = process.cpuUsage();
  try {
    const value = await run(), used = process.cpuUsage(cpu);
    event(name, 'complete', { phaseElapsedMs: performance.now() - began, userCpuMs: used.user / 1000, systemCpuMs: used.system / 1000, result: value });
    return value;
  } catch (error) { event(name, 'failed', { message: error.message }); throw error; }
};
const tools = await stage('import-build-tools', async () => { const module = await import(`${root}/scripts/game-cli.mjs`); return module; });
const config = await stage('read-build-config', () => tools.readBuildConfig(root));
const files = await stage('collect-build-files', () => tools.collectBuildFiles(root, config));
await stage('validate-build-references', () => tools.validateBuildReferences(root, files));
await stage('validate-content-snapshots', () => tools.validateContentSnapshots(root, files));
await stage('validate-cooperative-content', () => tools.validateCoopContent(root));
await stage('validate-campaign', () => tools.validateLevels(root));
await stage('validate-themes', () => tools.validateThemes(root));
await stage('validate-classes', () => tools.validateClasses(root));
await stage('validate-packs', () => tools.validatePacks(root));
event('core-preparation-operations', 'complete', { scope: 'Read-only original core preparation validators, separately from localization and distribution assembly. Not a complete normal build or publication pass.' });
