import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { validateOptionalPackageAdmission } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/optional-package-admission.mjs';
import { readEditionZip } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
import { assertOfflineFlightMatrix } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/optional-installation-offline-flight.mjs';
import { assertC4ImportedWorld, assertC4OfflineFlight } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/practice-imported-world-check.mjs';

const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const bundle = '/Volumes/alex/CodexMigrationStaging/flight-practice-main-237-20261018-candidate';
const output = '/Volumes/alex/CodexMigrationStaging';
const hash = value => createHash('sha256').update(value).digest('hex');
const readJSON = async file => JSON.parse(await fs.readFile(file, 'utf8'));
const bytes = await fs.readFile(path.join(output, 'practice-main-237-offline-20261019.json'));
const report = JSON.parse(bytes);
const envelopeBytes = await fs.readFile(path.join(bundle, 'optional-packages.json'));
const envelope = JSON.parse(envelopeBytes);
assert.equal(envelope.sourceRevision, '6177d2cc83adb9cb76ff4088d502c21ddfd7d199');
assert.equal(hash(envelopeBytes), 'b64909c3127ea428be8d188444bf2ae0873e299b71bfd991a737ba0c658ce2a5');
const admission = await validateOptionalPackageAdmission(envelope, { read: row => fs.readFile(path.join(bundle, row.path)) });
assert.equal(admission.publicEligible, false);
assert.equal(admission.zipMembersVerified, true);
assert.equal(report.sourceRevision, envelope.sourceRevision);
assert.equal(report.sourceTree, envelope.sourceTree);
assert.equal(report.envelopeSha256, hash(envelopeBytes));
assert.equal(report.passed, true);
assert.equal(report.harnessStable, true);
assert.equal(report.checkpoints.length, 9);
assert.deepEqual(report.errors, []);
assert.deepEqual(report.cleanup.errors, []);
assert.equal(report.cleanup.temporaryProfileRemoved, true);
assert.equal(report.closedTabsRelaunch.passed, true);
assert.equal(report.browserRestart.passed, true);
assert.equal(report.browserRestart.contextClosed, true);
assert.equal(report.osInstallationStatus, 'passed');
assert.equal(report.standaloneWindowStatus, 'passed');
assert(report.osApps.every(app => app.installed && app.uninstalled));
assert.equal(report.harnessSha256, hash(await fs.readFile(path.join(root, 'scripts/observe-optional-installation.mjs'))));
assert.equal(report.helperSha256, hash(await fs.readFile(path.join(root, 'scripts/optional-installation-observer-helpers.mjs'))));
assert.equal(report.profiles.importPolicy.policy, 'calibration-only-rates-owner');
assert(report.profiles.input.includes('response retained'));
assert(report.profiles.importPolicy.explicitNotice.includes('Included flight response settings were not applied.'));
assert.equal(report.profiles.importPolicy.priorResponseSha256, report.profiles.importPolicy.retainedResponseSha256);
assert.equal(report.profiles.importPolicy.radioImported, true);
assert.equal(report.profiles.importPolicy.radioVerified, false);
assertOfflineFlightMatrix(report.offlineFlight, report.importedWorld, report.browserRestart);
assert.equal(report.importedWorld.checks.length, 5);
const baseline = report.importedWorld.checks[0].state;
for (const check of report.importedWorld.checks) {
  assert.equal(check.passed, true);
  assertC4ImportedWorld(check.state, baseline);
}
for (const flight of report.importedWorld.flights) {
  assert.deepEqual(assertC4OfflineFlight(flight), flight.acceptance);
  assert(flight.cleanup.completed && flight.cleanup.errors.length === 0);
}
const archives = new Map();
for (const item of envelope.packages) archives.set(item.id, readEditionZip(await fs.readFile(path.join(bundle, item.distribution.path))));
for (const row of report.offlineFlight.runtime) {
  const original = archives.get(row.packageId).get(row.path);
  assert(original);
  assert.equal(original.length, row.bytes);
  assert.equal(hash(original), row.sha256);
}
for (const row of report.importedWorld.authority.runtime) {
  const original = archives.get('fpv-worlds').get(row.path);
  assert(original);
  assert.equal(original.length, row.bytes);
  assert.equal(hash(original), row.sha256);
}
for (const row of report.importedWorld.source)
  assert.equal(hash(await fs.readFile(path.join(root, 'scripts', row.path))), row.sha256);
const pack = await fs.readFile(path.join(root, report.importedWorld.packSource.path));
assert.equal(hash(pack), report.importedWorld.packSource.sha256);
assert.equal(hash(pack), report.importedWorld.authority.pack.sha256);
const screenshots = [];
function collect(value) {
  if (!value || typeof value !== 'object') return;
  if (typeof value.path === 'string' && value.path.endsWith('.png') && value.sha256) screenshots.push(value);
  for (const child of Object.values(value)) collect(child);
}
collect(report);
assert.equal(screenshots.length, 7);
for (const item of screenshots) {
  assert.equal(path.dirname(item.path), output);
  const png = await fs.readFile(item.path);
  assert.equal(png.length, item.bytes);
  assert.equal(hash(png), item.sha256);
  assert.equal(png.subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
  assert.equal(png.readUInt32BE(16), 1280);
  assert.equal(png.readUInt32BE(20), 900);
}
const result = { format: 'PracticeCurrentOfflineAudit.v1', passed: true, reportSha256: hash(bytes), envelopeSha256: hash(envelopeBytes), sourceRevision: envelope.sourceRevision, sourceTree: envelope.sourceTree, browser: report.browser, admission, checkpoints: report.checkpoints.length, offlineRoutes: report.offlineFlight.flights.length + report.importedWorld.flights.length, exactImportedWorldWitnesses: report.importedWorld.checks.length, screenshots: screenshots.map(row => ({ ...row, visuallyQualified: false })), profileImportPolicy: report.profiles.importPolicy, cleanup: report.cleanup, scope: 'Repeatable integrity and predicate audit of original admitted bytes, actual six-route receipt and screenshots. Not independent human review, first-time learning, physical-input or publication approval.' };
await fs.writeFile(path.join(output, 'practice-main-237-offline-20261019-audit.json'), JSON.stringify(result, null, 2) + '\n', {flag:'wx'});
console.log(JSON.stringify({ passed: true, reportSha256: result.reportSha256, checkpoints: result.checkpoints, offlineRoutes: result.offlineRoutes, importedWorldWitnesses: result.exactImportedWorldWitnesses, screenshots: screenshots.length }));
