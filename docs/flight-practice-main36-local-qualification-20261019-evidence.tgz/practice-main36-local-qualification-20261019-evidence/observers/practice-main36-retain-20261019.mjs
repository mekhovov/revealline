import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const base='/Volumes/alex/CodexMigrationStaging',root='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const hash=b=>createHash('sha256').update(b).digest('hex');
const stage=await fs.mkdtemp(base+'/practice-main36-qualified-packet-');
const name='practice-main36-local-qualification-20261019-evidence',out=stage+'/'+name;
await fs.mkdir(out);
const items=[];
async function copy(source,relative){const st=await fs.lstat(source);assert(st.isFile(),'Only regular evidence files');assert(st.size<85*1024**2);const bytes=await fs.readFile(source);await fs.mkdir(path.dirname(out+'/'+relative),{recursive:true});await fs.writeFile(out+'/'+relative,bytes,{flag:'wx'});items.push({path:relative,bytes:bytes.length,sha256:hash(bytes)});}
async function directory(source,relative){for(const e of (await fs.readdir(source,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){assert(!e.isSymbolicLink());if(e.isDirectory())await directory(source+'/'+e.name,relative+'/'+e.name);else await copy(source+'/'+e.name,relative+'/'+e.name);}}
for(const name of ['practice-main36-local-build-20261019','practice-main36-browser-refresh-20261019','practice-main36-academy-recovery-20261019','practice-main36-recovery-supervision-20261019','practice-main36-active-refresh-20261019','practice-main36-native-digest-probe-20261019','practice-main36-native-digest-probe-v2-20261019','practice-main36-suites-20261019','practice-main36-localux-retry-20261019'])await directory(base+'/'+name,name);
for(const e of await fs.readdir(base))if(e.startsWith('practice-main36-offline-20261019')||/^practice-main36-(native-digest|regression|world-attempts)-audit-20261019\.(json|log)$/.test(e))await copy(base+'/'+e,e);
for(const name of ['practice-main36-local-build-20261019.log','practice-main36-browser-refresh-20261019.log','practice-main36-recovery-runner-20261019.log','practice-main36-active-refresh-20261019.log','practice-main36-native-digest-probe-20261019.log','practice-main36-native-digest-probe-v2-20261019.log','practice-main36-suites-20261019.log','practice-main36-materialize-source-20261019.json','practice-main36-materialize-source-20261019.log','practice-main36-localux-retry-20261019.log'])await copy(base+'/'+name,name);
for(const e of await fs.readdir('/private/tmp'))if(/^practice-main36-.*-20261019\.mjs$/.test(e)&&e!=='practice-main36-retain-20261019.mjs'&&!e.includes('world-recovery'))await copy('/private/tmp/'+e,'observers/'+e);
// These are the source-bound results of the maintained local-UX runner, not a
// substitute assembled from stdout. Require its exact recorded output directory.
const localLog=await fs.readFile(base+'/practice-main36-localux-retry-20261019/browser.log','utf8');
const localDirectory=localLog.match(/^Industrial verification receipts: (.+)$/m)?.[1];assert(localDirectory?.startsWith(root+'/.cache/industrial-verification/bcc0b61a8cbc-'));await directory(localDirectory,'local-ux-original');
for(const optional of ['practice-main36-world-recovery-20261019','practice-main36-world-recovery-supervision-20261019']){try{await fs.access(base+'/'+optional+'/observation.json');}catch{if(optional.endsWith('supervision-20261019')){try{await fs.access(base+'/'+optional+'/receipt.json');}catch{continue;}}else continue;}await directory(base+'/'+optional,optional);}
try{await fs.access(base+'/practice-main36-world-recovery-20261019/observation.json');for(const name of ['practice-main36-world-recovery-20261019.mjs','practice-main36-world-recovery-runner-20261019.mjs'])await copy('/private/tmp/'+name,'observers/'+name);await copy(base+'/practice-main36-world-recovery-runner-20261019.log','practice-main36-world-recovery-runner-20261019.log');}catch(error){if(error.code!=='ENOENT')throw error;}
for(const version of ['v2','v3']){
  const stem='practice-main36-world-recovery-'+version;
  await directory(base+'/'+stem+'-20261019',stem+'-20261019');
  await directory(base+'/'+stem+'-supervision-20261019',stem+'-supervision-20261019');
  for(const suffix of ['-20261019.mjs','-runner-20261019.mjs'])await copy('/private/tmp/'+stem+suffix,'observers/'+stem+suffix);
  await copy(base+'/'+stem+'-runner-20261019.log',stem+'-runner-20261019.log');
}
await copy('/private/tmp/practice-main36-retain-20261019.mjs','observers/practice-main36-retain-20261019.mjs');
items.sort((a,b)=>a.path.localeCompare(b.path));
const inventory={format:'PracticeEvidenceInventory.v1',source:'bcc0b61a8cbc984f075fae1260b899fb1b78ff1d',candidateSource:'08fc3430c8f6670a76c1a749b3ad0b65bc9f9ded',files:items,scope:'Original successes, failures, inconclusive traces, observer/audit sources and screenshots. Neither executable release bundle nor human approval. Large immutable production output and candidate packages remain separately pinned, not duplicated here.'};
await fs.writeFile(out+'/inventory.json',JSON.stringify(inventory,null,2)+'\n',{flag:'wx'});
const archive=stage+'/'+name+'.tgz';execFileSync('/usr/bin/tar',['-czf',archive,'-C',stage,name],{timeout:120000});
const expanded=await fs.mkdtemp(base+'/practice-main36-qualified-audit-');execFileSync('/usr/bin/tar',['-xzf',archive,'-C',expanded],{timeout:120000});
const actual=JSON.parse(await fs.readFile(expanded+'/'+name+'/inventory.json'));assert.deepEqual(actual,inventory);for(const row of items){const b=await fs.readFile(expanded+'/'+name+'/'+row.path);assert.equal(b.length,row.bytes);assert.equal(hash(b),row.sha256);}
const b=await fs.readFile(archive);assert(b.length<50*1024**2);const result={archive,bytes:b.length,sha256:hash(b),files:items.length,expandedBytes:items.reduce((sum,r)=>sum+r.bytes,0),extractedAndRehashed:true,stage,expanded};await fs.writeFile(base+'/practice-main36-local-qualification-packet-20261019.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
