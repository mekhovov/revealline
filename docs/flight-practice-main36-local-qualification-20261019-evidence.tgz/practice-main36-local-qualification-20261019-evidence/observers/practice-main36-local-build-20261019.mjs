import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { frozenSource, committedInputMap, verifyCommittedInputs } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
import { readBuildConfig, collectBuildFiles } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/game-cli.mjs';
import { observeIndustrialPhase } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/verify-industrial-features.mjs';

const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const base = '/private/tmp';
const output = '/Volumes/alex/CodexMigrationStaging/practice-main36-local-build-20261019';
const destination = path.join(base, 'practice-main36-production-20261019');
await fs.mkdir(output);
assert.equal(await fs.access(destination).then(() => true, () => false), false);
const source = frozenSource(root), tree = committedInputMap(root);
assert.equal(source.sourceRevision, process.argv[2]);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const config = await readBuildConfig(root);
const files = await collectBuildFiles(root, config);
const tools = execFileSync('git', ['ls-files', 'scripts', 'publishing'], { cwd: root, encoding: 'utf8' }).trim().split('\n').filter((name) => name.endsWith('.mjs'));
const selected = [...new Set([...files, ...tools, 'package.json', 'game/build-config.json'])].sort();
const pins = async () => {
  const rows = [];
  for (const name of selected) {
    const bytes = await fs.readFile(path.join(root, name));
    verifyCommittedInputs(new Map([[name, bytes]]), tree);
    rows.push({ path: name, bytes: bytes.length, sha256: sha(bytes) });
  }
  return rows;
};
const free = async (directory) => { const stat = await fs.statfs(directory); return stat.bavail * stat.bsize; };
const receipt = {
  format: 'PracticeFrozenProductionProgressBuild.v1', startedAt: new Date().toISOString(), source,
  destination, node: process.version, platform: process.platform, arch: process.arch,
  deadlineMs: 600000, publicEligible: false, qualified: false, passed: false,
  scope: 'Normal full production CLI with opt-in stderr progress, unchanged 600000 ms ceiling and original validation, using recovered local disk space. Evidence goes to the approved share. Production writer unchanged; no threadpool override. Tests whether local materialization removes the SMB bottleneck. Not remote execution, hosting, release approval, browser acceptance, or performance qualification.',
};
try {
  receipt.before = await pins();
  receipt.storageBudget = {
    outputVolume: base, networkFilesystem: false, reserveBytes: 1536 * 1024 * 1024,
    estimatedBuildBytes: receipt.before.reduce((sum, row) => sum + row.bytes, 0) * 2,
    freeBefore: await free(base),
    localSystemVolume: '/private/tmp', localSystemFloorBytes: 1024 * 1024 * 1024,
    localSystemFreeBefore: await free('/private/tmp'),
    note: 'Input bytes times two is an estimate, not a generated-output upper bound. Recovered local output volume must retain 1.5 GiB throughout. No browser profile is created during this build.',
  };
  assert(receipt.storageBudget.freeBefore > receipt.storageBudget.estimatedBuildBytes + receipt.storageBudget.reserveBytes, 'Insufficient output margin');
  assert(receipt.storageBudget.localSystemFreeBefore > receipt.storageBudget.localSystemFloorBytes, 'Insufficient system-volume margin');
  receipt.command = ['scripts/game-cli.mjs', 'build', '--progress', 'stderr', '--out', destination, '--version', 'v0.151.1', '--revision', source.sourceRevision];
  console.log(JSON.stringify({ source, selectedFiles: selected.length, destination, deadlineMs: receipt.deadlineMs, storageBudget: receipt.storageBudget }));
  const controller = new AbortController();
  let checking = false;
  const guard = setInterval(async () => {
    if (checking) return;
    checking = true;
    try {
      const [outputFree, localFree] = await Promise.all([free(base), free('/private/tmp')]);
      const budget = receipt.storageBudget;
      budget.minimumOutputObserved = Math.min(budget.minimumOutputObserved ?? Infinity, outputFree);
      budget.minimumSystemObserved = Math.min(budget.minimumSystemObserved ?? Infinity, localFree);
      if (outputFree < budget.reserveBytes || localFree < budget.localSystemFloorBytes) {
        budget.abortedForSpace = true;
        controller.abort();
      }
    } catch (error) { receipt.storageBudget.guardError = error.message; controller.abort(); }
    finally { checking = false; }
  }, 1000);
  try { receipt.result = await observeIndustrialPhase({ command: receipt.command, cwd: root, log: path.join(output, 'build.log'), deadlineMs: receipt.deadlineMs, signal: controller.signal }); }
  finally { clearInterval(guard); while (checking) await new Promise((resolve) => setTimeout(resolve, 10)); }
  const log = await fs.readFile(path.join(output, 'build.log'));
  receipt.logSha256 = sha(log);
  receipt.after = await pins();
  assert.deepEqual(receipt.after, receipt.before);
  assert.deepEqual(frozenSource(root), source);
  receipt.sourceUnchanged = true;
  receipt.passed = receipt.result.exitCode === 0 && !receipt.result.timedOut && !receipt.result.interrupted && !receipt.result.executionError;
  receipt.phases = log.toString().split('\n').filter((line) => /^\[build\] [a-z-]+$/.test(line)).map((line) => line.slice(8));
  if (receipt.passed) {
    receipt.build = JSON.parse(log.toString().split('\n').filter((line) => !/^\[build\] [a-z-]+$/.test(line)).join('\n'));
    assert.equal(receipt.build.sourceRevision, source.sourceRevision);
    assert.equal(receipt.phases.at(-1), 'replace-output');
  }
} catch (error) { receipt.failure = error.message; receipt.passed = false; }
finally {
  receipt.finishedAt = new Date().toISOString();
  await fs.writeFile(path.join(output, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ passed: receipt.passed, result: receipt.result, failure: receipt.failure, output }));
  if (!receipt.passed) process.exitCode = 1;
}
