import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const base='/Volumes/alex/CodexMigrationStaging',hash=b=>createHash('sha256').update(b).digest('hex');
const audits=[];
for(const suffix of ['', '-v2']){
 const out=base+'/practice-main36-native-digest-probe'+suffix+'-20261019';const raw=await fs.readFile(out+'/observation.json'),r=JSON.parse(raw);
 assert(r.passed&&!r.qualified&&!r.r4Complete&&r.elapsedMs<120000&&r.cleanup.every(x=>x.passed));
 assert.equal(r.source.sourceRevision,'bcc0b61a8cbc984f075fae1260b899fb1b78ff1d');assert.deepEqual(r.sourceAfter,r.source);
 assert.equal(r.plan.sourceRevision,'08fc3430c8f6670a76c1a749b3ad0b65bc9f9ded');assert.equal(r.plan.envelopeSha256,'61ae470760baa9f276a0d6c9c22a3f536e4e5de8048246e454c07ef0e56e7270');
 assert.equal(hash(await fs.readFile('/private/tmp/practice-main36-native-digest-probe'+suffix+'-20261019.mjs')),r.observerSha256);
 const cases=[];
 for(const c of r.cases){
  assert(c.finished&&c.contextClosed&&c.traceComplete&&!c.dataLossOccurred);const bytes=await fs.readFile(out+'/'+c.trace.path);assert.equal(bytes.length,c.trace.bytes);assert.equal(hash(bytes),c.trace.sha256);
  const events=JSON.parse(bytes).traceEvents;const digest=events.filter(x=>x.name==='DoDigest'),reply=events.filter(x=>x.name==='DoDigestReply'),marks=events.filter(x=>x.name==='practice-native-cancel-click');
  assert(digest.length>0&&reply.length>0);assert(digest.every(x=>['X','I'].includes(x.ph)));assert.deepEqual([...digest,...reply].sort((a,b)=>a.ts-b.ts),[...c.digests].sort((a,b)=>a.ts-b.ts));assert.deepEqual(marks,c.cancelMarks);
  const intervals=digest.filter(x=>x.ph==='X'),instant=digest.filter(x=>x.ph==='I');
  const overlaps=marks.flatMap(m=>intervals.filter(d=>d.ts<=m.ts&&m.ts<d.ts+d.dur));assert.equal(overlaps.length,0);assert.equal(c.rawTimestampOverlaps.length,0);
  for(const d of digest)assert(events.some(x=>x.name==='thread_name'&&x.pid===d.pid&&x.tid===d.tid&&x.args?.name==='ServiceWorker thread'));
  assert.equal(c.statusAfterSettlement,c.status);assert(c.targets.targetInfos.some(x=>x.type==='service_worker'&&x.url===r.origin+'/revealline/practice/civilian-fpv/releases/v0.151.1/site/optional-practice/civilian-fpv/worker.js'));
  if(!suffix&&c.kind==='cancel'){assert.equal(c.clicks.length,1);assert(c.clicks[0].trusted);assert.equal(c.clicks[0].phase,'Downloading · 28%');assert(/cancelled/i.test(c.status));assert.equal(marks.length,1);}
  else{assert.equal(c.clicks.length,0);assert.equal(marks.length,0);assert(/ready offline/i.test(c.status));}
  if(suffix)assert(c.timingMiss.includes('Timeout'));
  cases.push({kind:c.kind,digestEvents:digest.length,replyEvents:reply.length,durationEvents:intervals.length,instantEvents:instant.length,maxReportedDigestMicroseconds:Math.max(...intervals.map(x=>x.dur)),trustedClicks:c.clicks,positiveOverlap:false,traceSha256:c.trace.sha256});
 }
 audits.push({reportSha256:hash(raw),suffix,browser:r.browser,cases});
}
const result={format:'PracticeNativeDigestAvailabilityAudit.v1',passed:true,r4Complete:false,qualified:false,audits,scope:'Audit of trace availability and two bounded natural-cancellation probes, not a cancellation-during-hashing pass. Native digest events are on service-worker threads, but exact URL-to-thread attribution and prior/sibling preservation are not qualified. Instant events have no positive duration; absence of recorded overlap does not prove overlap impossible. First click occurred at Downloading 28%; stricter final-verification probe missed the short window. No artificial delay, crypto/messaging replacement or late-Ready pass claim.'};
await fs.writeFile(base+'/practice-main36-native-digest-audit-20261019.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
