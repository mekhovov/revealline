import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { frozenSource } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
import { observeIndustrialPhase } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/verify-industrial-features.mjs';
import { FPV_EXERCISE_CASES, GYM_EXERCISE_CASES, validateFirstFlightPlan } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/observe-practice-first-flight.mjs';
import { DIRECTORY_JOURNEY_CASES, validateDirectoryJourneyPlan } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/observe-practice-directory-journey.mjs';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const base = '/Volumes/alex/CodexMigrationStaging';
const output = `${base}/practice-main36-browser-refresh-20261019`;
const bundle = `${base}/flight-practice-main36-20261019-candidate`;
const playwright = '/Users/oleksandr.mekhovov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const source = frozenSource(root);
assert(process.env.OPTIONAL_INSTALLATION_PASSWORD, 'Approved test access must be supplied through the environment');
const bytes = await fs.readFile(`${bundle}/optional-packages.json`), envelope = JSON.parse(bytes);
assert.equal(hash(bytes), '61ae470760baa9f276a0d6c9c22a3f536e4e5de8048246e454c07ef0e56e7270');
const free = async () => { const s = await fs.statfs('/private/tmp'); return s.bavail * s.bsize; };
assert(await free() >= 2 * 1024 ** 3, 'Browser preflight requires 2 GiB local free');
await fs.mkdir(output);
const operations = [];
operations.push({ id: 'offline', command: ['scripts/observe-optional-installation.mjs', playwright, bundle, `${base}/practice-main36-offline-20261019.json`], flags: { OPTIONAL_INSTALLATION_WORLD_SEED: 'worlds-template-copy', OPTIONAL_INSTALLATION_IMPORTED_WORLD: 'roadworks-offline-flight', OPTIONAL_INSTALLATION_OFFLINE_FLIGHT: 'all-three-en' } });
for (const [kind, packageId, cases] of [['fpv', 'civilian-fpv', FPV_EXERCISE_CASES], ['gym', 'civilian-flight', GYM_EXERCISE_CASES]]) {
  const plan = { format: `revealline-practice-${kind}-exercise-plan.v1`, protocol: `practice-exercise-public-ui.${kind}.v1`, caseId: `main36-${kind}-20261019`, deviceLabel: 'Local macOS arm64 Chrome, software keyboard/pointer only', quietWindow: 'Serial owned browser runs after full-build process exit. Other user activity not controlled; no hardware or performance acceptance.', cases: cases.map((row) => row.id), bundle, envelopeSha256: hash(bytes), sourceRevision: envelope.sourceRevision, sourceTree: envelope.sourceTree, packageRevision: envelope.packages.find((row) => row.id === packageId).revision };
  validateFirstFlightPlan(plan);
  const file = `${output}/${kind}-plan.json`;
  await fs.writeFile(file, JSON.stringify(plan, null, 2) + '\n', { flag: 'wx' });
  operations.push({ id: kind, command: ['scripts/observe-practice-first-flight.mjs', file, playwright, `${output}/${kind}`], flags: {} });
}
const build = JSON.parse(await fs.readFile(`${base}/practice-main36-local-build-20261019/receipt.json`));
if (build.passed) {
  assert.deepEqual(build.source, source);
  const plan = { format: 'revealline-practice-directory-production-personal-appearance-plan.v2', protocol: 'practice-directory-production-personal-appearance.v2', caseId: 'main36-production-20261019', deviceLabel: 'Local macOS arm64 Chrome, software keyboard/pointer only', quietWindow: 'Serial owned run against exact normal CLI output. No concurrent owned full build. Other user activity uncontrolled; not performance acceptance.', cases: DIRECTORY_JOURNEY_CASES.map((row) => row.id), bundle, envelopeSha256: hash(bytes), sourceRevision: envelope.sourceRevision, sourceTree: envelope.sourceTree, packageRevision: envelope.packages.find((row) => row.id === 'civilian-fpv').revision, shellRevision: source.sourceRevision, shellTree: source.sourceTree, observerRevision: source.sourceRevision, observerTree: source.sourceTree, distribution: build.destination, distributionManifestSha256: hash(await fs.readFile(`${build.destination}/manifest.json`)) };
  validateDirectoryJourneyPlan(plan);
  const file = `${output}/production-plan.json`;
  await fs.writeFile(file, JSON.stringify(plan, null, 2) + '\n', { flag: 'wx' });
  operations.push({ id: 'production', command: ['scripts/observe-practice-directory-journey.mjs', file, playwright, `${output}/production`], flags: {} });
}
const receipt = { source, candidateSource: envelope.sourceRevision, envelopeSha256: hash(bytes), operations: [], productionBuildPassed: build.passed, scope: 'Exact new-candidate six-route offline refresh, ten public beginner exercises, then six production journeys only if the full build passes. No historical World active-session, hardware, performance, human approval or hosting.' };
for (const operation of operations) {
  for (const key of Object.keys(process.env)) if (key.startsWith('OPTIONAL_INSTALLATION_') && key !== 'OPTIONAL_INSTALLATION_PASSWORD') delete process.env[key];
  Object.assign(process.env, operation.flags);
  assert(await free() >= 2 * 1024 ** 3, 'Browser preflight requires 2 GiB local free');
  assert.deepEqual(frozenSource(root), source);
  const controller = new AbortController();
  let checking = false, abortedForSpace = false;
  const guard = setInterval(async () => { if (checking) return; checking = true; try { if (await free() < 2 * 1024 ** 3) { abortedForSpace = true; controller.abort(); } } catch { controller.abort(); } finally { checking = false; } }, 1000);
  let result;
  try { result = await observeIndustrialPhase({ command: operation.command, cwd: root, log: `${output}/${operation.id}.log`, deadlineMs: 600000, signal: controller.signal }); }
  finally { clearInterval(guard); while (checking) await new Promise((resolve) => setTimeout(resolve, 10)); }
  const logSha256 = hash(await fs.readFile(`${output}/${operation.id}.log`));
  receipt.operations.push({ id: operation.id, result, abortedForSpace, logSha256 });
  receipt.sourceAfter = frozenSource(root);
  assert.deepEqual(receipt.sourceAfter, source);
  await fs.writeFile(`${output}/receipt.json`, JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify(receipt.operations.at(-1)));
  if (result.exitCode !== 0 || result.timedOut || result.interrupted || result.executionError || abortedForSpace) { process.exitCode = 1; break; }
}
