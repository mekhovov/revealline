import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import os from 'node:os';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {performance} from 'node:perf_hooks';
import {setTimeout as pause} from 'node:timers/promises';
import {chromium} from '/Users/oleksandr.mekhovov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {directoryJourneyOverlay} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/observe-practice-directory-journey.mjs';
import {unlockObservedPage,activateOfflineAction,revealFPVOffline} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/optional-installation-observer-helpers.mjs';
import {FPV_EXERCISE_CASES,selectFirstFlightMode,prepareFPVExerciseHUD,activateFirstFlightControl,completeFirstFlightFPVExercise} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/observe-practice-first-flight.mjs';
import {verifyFrozenFPVExercise} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/practice-fpv-exercise-replay.mjs';
import {practiceWorkerCacheInventory} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/practice-worker-cache-inventory.mjs';
import {observeOfflineFlight} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/optional-installation-offline-flight.mjs';
const output='/Volumes/alex/CodexMigrationStaging/practice-main36-academy-recovery-20261019';
const available=await fs.statfs('/private/tmp');assert(available.bavail*available.bsize>=2*1024**3,'Require 2 GiB local browser headroom');
await fs.mkdir(output);assert(process.env.OPTIONAL_INSTALLATION_PASSWORD);
const profile=await fs.mkdtemp(path.join(os.tmpdir(),'practice-academy-eviction-profile-'));
const plan=JSON.parse(await fs.readFile('/Volumes/alex/CodexMigrationStaging/practice-main36-browser-refresh-20261019/fpv-plan.json','utf8'));
assert.equal(plan.sourceRevision,'08fc3430c8f6670a76c1a749b3ad0b65bc9f9ded');
assert.equal(plan.envelopeSha256,'61ae470760baa9f276a0d6c9c22a3f536e4e5de8048246e454c07ef0e56e7270');
const hash=b=>createHash('sha256').update(b).digest('hex');
const start=performance.now(),end=start+600000;
let context,server,origin,closing=false,inventory;
const r={format:'PracticeAcademyOriginRecovery.v2',createdAt:new Date().toISOString(),passed:false,qualified:false,publicEligible:false,plan,browser:null,profile,operations:[],samples:[],exports:[],cleanup:[],sourcePins:[],scope:'One main36 EN Academy actual flight proof, reduced-pool browser-managed eviction, public Notebook restore and final restarted-offline lift/pause. Not default-policy eviction, machine outage, complete origin restoration, Worlds/Gym recovery, aircraft archives, tuning/radio/controller libraries, devices, human approval or publication.'};
let deadline;
async function op(label,work,limit=10000){assert(performance.now()<end);const row={label,pending:true,atMs:performance.now()-start};r.operations.push(row);const task=Promise.resolve().then(work).finally(()=>{row.pending=false;row.elapsedMs=performance.now()-start-row.atMs;});void task.catch(()=>{});let timer;try{const v=await Promise.race([task,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error(label+' timed out')),Math.min(limit,end-performance.now()));})]);assert(performance.now()<end);row.passed=true;return v;}finally{clearTimeout(timer);}}
const feature='--enable-features=StorageQuotaSettings:PoolSizeBytes/524288';
async function launch(reduced,offline=false){await op('Launch owned Chrome '+(reduced?'reduced':'default')+(offline?' offline':''),()=>chromium.launchPersistentContext(profile,{channel:'chrome',headless:true,viewport:{width:1440,height:900},acceptDownloads:true,timeout:10000,args:reduced?[feature]:[]}).then(async c=>{context=c;if(closing)await c.close();return c;}));context.setDefaultTimeout(8000);context.setDefaultNavigationTimeout(8000);if(offline)await context.setOffline(true);return context.newPage();}
async function close(){if(context){await context.close();context=null;}}
async function quota(page){await op('Open native quota diagnostics',()=>page.goto('chrome://quota-internals/'));const q=await op('Read native quota diagnostics',()=>page.evaluate(()=>({pool:document.querySelector('.temp-pool-size')?.textContent,available:document.querySelector('.available-space')?.textContent,evicted:document.querySelector('#eviction-tbody .evicted-buckets')?.textContent,rounds:document.querySelector('#eviction-tbody .eviction-rounds')?.textContent,rows:[...document.querySelectorAll('#usage-and-quota-tbody tr')].map(n=>[...n.querySelectorAll('td')].map(c=>c.textContent))})));q.atMs=performance.now()-start;r.samples.push(q);return q;}
async function picture(page,name){const b=await op('Capture '+name,()=>page.screenshot({timeout:5000}));await fs.writeFile(path.join(output,name),b,{flag:'wx'});return{path:name,bytes:b.length,sha256:hash(b),visualApproval:false};}
async function storage(page){return op('Read storage without opening databases or caches',()=>page.evaluate(async()=>({persisted:await navigator.storage.persisted(),estimate:await navigator.storage.estimate(),caches:await caches.keys(),databases:await indexedDB.databases(),installationPointers:Object.fromEntries(Object.entries(localStorage).filter(([key])=>key.startsWith('revealline.optional-installed.')))})));}
async function dependencies(page){const state=await op('Read and hash each original prepared dependency',()=>page.evaluate(async expected=>{const keys=await caches.keys();if(!keys.includes(expected.name))throw Error('Expected prepared cache missing');for(const f of expected.files){const response=await caches.match(f.url,{cacheName:expected.name});if(!response)throw Error('Missing cached dependency');const b=await response.arrayBuffer(),h=[...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(x=>x.toString(16).padStart(2,'0')).join('');if(b.byteLength!==f.bytes||h!==f.sha256)throw Error('Changed cached dependency');}const workers=(await navigator.serviceWorker.getRegistrations()).map(w=>({scope:w.scope,state:w.active?.state,script:w.active?.scriptURL}));return{files:expected.files.length,workers};},inventory),60000);assert(state.workers.some(w=>w.scope===origin+'/revealline/practice/civilian-fpv/releases/v0.151.1/site/optional-practice/civilian-fpv/'&&w.state==='activated'));return state;}
async function loadApp(page){await op('Open original stable launcher',()=>page.goto(origin+'/revealline/practice/civilian-fpv/app/?action=play&lang=en'));await op('Normal authorized launcher access',()=>unlockObservedPage(page,process.env.OPTIONAL_INSTALLATION_PASSWORD));await op('Resolve immutable current app',()=>page.waitForURL(u=>u.pathname.endsWith('/optional-practice/civilian-fpv/index.html')&&u.search==='?lang=en'));await op('Normal authorized app access',()=>unlockObservedPage(page,process.env.OPTIONAL_INSTALLATION_PASSWORD));await op('Wait for ordinary Home',()=>page.locator('#academy-shell-action-primary').waitFor({state:'visible'}));}
async function press(page,selector){await op('Public '+selector,async()=>{const n=page.locator(selector);await n.waitFor({state:'visible'});assert(await n.isEnabled());await n.press('Enter');});}
async function notebook(page){await press(page,'#academy-shell-action-settings');await press(page,'#academy-settings-tab-data');await press(page,'#notebook-button');}
const field=page=>page.getByRole('textbox',{name:'Flight proof backup JSON',exact:true});
async function exportProof(page,name){const button=page.getByRole('button',{name:'Export verified flight proofs',exact:true});await op('Export native Notebook',()=>button.press('Enter'));const text=await field(page).inputValue();const b=Buffer.from(text);await fs.writeFile(path.join(output,name),b,{flag:'wx'});const row={path:name,bytes:b.length,sha256:hash(b)};r.exports.push(row);return{text,value:JSON.parse(text),pin:row};}
async function prepare(page){await press(page,'#academy-shell-action-settings');await press(page,'#academy-settings-tab-extras');await revealFPVOffline(page,()=>press(page,'#help'));await op('Ordinary download and native readiness',()=>activateOfflineAction(page,{button:'#install-offline',status:'#transfer-status',expected:/ready offline|ready for offline|prepared offline/i}),60000);await press(page,'[data-close="help-dialog"]');await press(page,'#academy-shell-action-settings-back');}
try{
 deadline=setTimeout(()=>{void context?.close();server?.closeAllConnections();},600000);
 const overlay=await op('Strict original artifact admission',()=>directoryJourneyOverlay(plan),60000);
 r.admission=overlay.loaded.admission;
 const files=overlay.loaded.files;
 // loadFPVObservationArtifact exposes its exact admitted member Map as files.
 assert(files instanceof Map,'Require admitted runtime map');
 const types={'.mjs':'text/javascript','.js':'text/javascript','.css':'text/css','.html':'text/html','.json':'application/json','.webmanifest':'application/manifest+json','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.woff2':'font/woff2'};
 server=http.createServer((req,res)=>{const u=new URL(req.url,'http://127.0.0.1');if(u.pathname==='/owned-storage-observation'){res.writeHead(200,{'Content-Type':'text/html','Cache-Control':'no-store'});res.end('<!doctype html><title>Owned read-only storage observation</title>');return;}const name=u.pathname.slice(12)+(u.pathname.endsWith('/')?'index.html':'');const b=u.pathname.startsWith('/revealline/')&&overlay.files.get(name);if(!b){res.writeHead(404);res.end();return;}res.writeHead(200,{'Content-Type':types[path.extname(name)]??'application/octet-stream','Cache-Control':'no-store','Content-Length':b.length});res.end(b);});
 await op('Start owned loopback server',()=>new Promise(resolve=>server.listen(0,'127.0.0.1',resolve)));origin='http://127.0.0.1:'+server.address().port;r.origin=origin;
 const scope=origin+'/revealline/practice/civilian-fpv/releases/v0.151.1/site/optional-practice/civilian-fpv/';inventory=practiceWorkerCacheInventory({workerBytes:files.get('optional-practice/civilian-fpv/worker.js'),baseURL:scope,cacheName:'revealline.optional.package.v1:'+new URL(scope).pathname+':'+plan.packageRevision});r.inventory=inventory;
 const sourceRoot='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';r.observerRevision=execFileSync('git',['rev-parse','HEAD'],{cwd:sourceRoot,encoding:'utf8'}).trim();for(const name of ['observe-practice-directory-journey.mjs','optional-installation-observer-helpers.mjs','observe-practice-first-flight.mjs','practice-fpv-exercise-ui.mjs','practice-fpv-exercise-export.mjs','practice-fpv-exercise-replay.mjs','practice-worker-cache-inventory.mjs'])r.sourcePins.push({path:sourceRoot+'/scripts/'+name,sha256:hash(await fs.readFile(sourceRoot+'/scripts/'+name))});
 for(const name of ['optional-installation-offline-flight.mjs'])r.sourcePins.push({path:sourceRoot+'/scripts/'+name,sha256:hash(await fs.readFile(sourceRoot+'/scripts/'+name))});
 let page=await launch(false);r.browser=await context.browser()?.version()??'persistent Chrome';
 await loadApp(page);await prepare(page);
 const spec=FPV_EXERCISE_CASES[0],result={...spec,actions:[],errors:[],passed:false};r.flight=result;
 await selectFirstFlightMode(page,spec,result);await prepareFPVExerciseHUD(page,spec,result);await activateFirstFlightControl(page,'#academy-shell-action-primary',result);
 await op('Wait for active explicit start',()=>page.waitForFunction(()=>document.querySelector('#flight-app')?.dataset.flightState==='active'));
 await op('Genuine native exercise and actual external proof',()=>completeFirstFlightFPVExercise(page,spec,result,output,files),60000);
 const before=await exportProof(page,'before-eviction-proof.json');assert.equal(before.value.attempts.length,1);
 r.before=await storage(page);r.beforeDependencies=await dependencies(page);assert.equal(r.before.persisted,false,'Protected origin cannot qualify as evictable');assert(r.before.caches.length>0&&r.before.databases.some(x=>x.name==='revealline-journey-v1'));
 await close();page=await launch(true);r.reducedRestartAtMs=performance.now()-start;
 await op('Read native effective command line',()=>page.goto('chrome://version/'));r.version=await page.evaluate(()=>({version:document.querySelector('#version')?.innerText,commandLine:document.querySelector('#command_line')?.innerText,profile:document.querySelector('#profile_path')?.innerText}));assert(r.version.commandLine.includes(feature)&&r.version.profile.includes(path.basename(profile)));
 await page.goto(origin+'/owned-storage-observation');r.afterRestart=await storage(page);r.restartedDependencies=await dependencies(page);assert.deepEqual(r.afterRestart.caches.sort(),r.before.caches.sort());assert(r.afterRestart.databases.some(x=>x.name==='revealline-journey-v1'));assert.equal(r.afterRestart.persisted,false);
 const initial=await quota(page);assert.equal(initial.pool,'512.00 KB');assert(initial.rows.some(x=>x[0]===origin+'/'));r.numericCounterDeltaObserved=false;
 while(performance.now()<end-90000){const q=await quota(page);assert.equal(q.pool,'512.00 KB');if(q.evicted?.trim()&&Number(q.evicted)>0&&Number(q.rounds)>0&&!q.rows.some(x=>x[0]===origin+'/')){r.eviction={atMs:performance.now()-start,evicted:Number(q.evicted),rounds:Number(q.rounds),bucketAbsent:true,counterBaselineAvailable:!!initial.evicted?.trim(),defaultPolicy:false};break;}await pause(5000);}
 assert(r.eviction,'No corroborated native app bucket eviction in bounded window');r.quotaScreenshot=await picture(page,'browser-managed-eviction.png');
 await page.goto(origin+'/owned-storage-observation');r.afterLoss=await storage(page);assert.equal(r.afterLoss.caches.length,0);assert(!r.afterLoss.databases.some(x=>x.name==='revealline-journey-v1'));
 await close();page=await launch(false,true);let offlineFailure;
 try{await page.goto(origin+'/revealline/practice/civilian-fpv/app/?lang=en');}catch(e){offlineFailure=e.message;}
 assert(offlineFailure&&/ERR_INTERNET_DISCONNECTED|ERR_FAILED/.test(offlineFailure));r.offlineMissingShell={failedHonestly:true,error:offlineFailure};
 await close();page=await launch(false);await loadApp(page);await prepare(page);await notebook(page);
 const empty=await exportProof(page,'before-restore-empty.json');assert.equal(empty.value.attempts.length,0);
 await field(page).fill(before.text);const importer=page.getByRole('button',{name:'Import and reverify proofs',exact:true});await importer.press('Enter');await page.waitForFunction(()=>[...document.querySelectorAll('button')].some(n=>n.textContent==='Import and reverify proofs'&&!n.disabled));
 const restored=await exportProof(page,'restored-proof.json');assert.deepEqual(restored.value,before.value);r.restoredReplay=await verifyFrozenFPVExercise(files,restored.text,{packageId:'civilian-fpv',mode:'self-level'});assert(r.restoredReplay.verified);
 r.recovered=await storage(page);r.recoveredDependencies=await dependencies(page);assert(r.recovered.caches.length>0&&r.recovered.databases.some(x=>x.name==='revealline-journey-v1'));
 await close();page=await launch(false,true);await loadApp(page);await notebook(page);const restarted=await exportProof(page,'offline-restarted-proof.json');assert.deepEqual(restarted.value,before.value);r.finalScreenshot=await picture(page,'offline-recovered-notebook.png');
 await press(page,'[data-close="notebook-dialog"]');await press(page,'#academy-shell-action-settings-back');
 const probe=await page.evaluate(async url=>{try{await fetch(url,{cache:'no-store'});return false;}catch{return true;}},origin+'/owned-storage-observation?uncached='+Date.now());assert(probe,'Require uncached network failure before recovered flight');
 r.finalOfflineFlight={};
 await observeOfflineFlight(page,{packageId:'civilian-fpv',expectedURL:page.url(),deadlineAt:Date.now()+Math.min(30000,end-performance.now()),requireActive:()=>assert(performance.now()<end),receipt:r.finalOfflineFlight,capture:()=>picture(page,'offline-recovered-paused-flight.png'),restartConfirmed:true,networkProbeFailed:probe});
 assert(r.finalOfflineFlight.passed&&r.finalOfflineFlight.cleanup.completed);
 const afterProbe=await page.evaluate(async url=>{try{await fetch(url,{cache:'no-store'});return false;}catch{return true;}},origin+'/owned-storage-observation?uncached-after='+Date.now());assert(afterProbe);r.finalOfflineFlight.networkProbeFailedAfter=true;r.passed=true;
}catch(e){r.failure=e.message;r.inconclusive=!r.eviction;process.exitCode=1;}
finally{
 closing=true;clearTimeout(deadline);
 try{await close();const processes=execFileSync('ps',['-axo','pid,args'],{encoding:'utf8',maxBuffer:8*1024*1024});assert(!processes.split('\n').some(line=>line.includes('/Applications/Google Chrome')&&line.includes(profile)));r.cleanup.push({name:'owned Chrome closed',passed:true});}catch(e){r.cleanup.push({name:'owned Chrome closed',passed:false,error:e.message});}
 try{if(server)await new Promise(resolve=>{server.close(resolve);server.closeAllConnections();});r.cleanup.push({name:'owned server closed',passed:true});}catch(e){r.cleanup.push({name:'owned server closed',passed:false,error:e.message});}
 if(r.cleanup.every(x=>x.passed)&&r.operations.every(x=>!x.pending)){assert(profile.startsWith(path.join(os.tmpdir(),'practice-academy-eviction-profile-')));await fs.rm(profile,{recursive:true,force:true});r.cleanup.push({name:'only disposable test profile removed',passed:true});}else r.retainedProfile=profile;
 for(const source of r.sourcePins)assert.equal(hash(await fs.readFile(source.path)),source.sha256);
 r.elapsedMs=performance.now()-start;r.passed&&=r.cleanup.every(x=>x.passed)&&!r.retainedProfile&&r.elapsedMs<600000;
 r.observerSha256=hash(await fs.readFile(new URL(import.meta.url)));await fs.writeFile(output+'/observation.json',JSON.stringify(r,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({passed:r.passed,failure:r.failure,eviction:r.eviction,elapsedMs:r.elapsedMs,cleanup:r.cleanup}));if(!r.passed)process.exitCode=1;
}
