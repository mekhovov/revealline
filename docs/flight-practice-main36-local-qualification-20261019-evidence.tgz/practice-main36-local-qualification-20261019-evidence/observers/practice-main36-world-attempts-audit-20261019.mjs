import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const base='/Volumes/alex/CodexMigrationStaging';
const hash=b=>createHash('sha256').update(b).digest('hex');
const rows=[];
for(const v of ['', '-v2', '-v3']){
 const stem='practice-main36-world-recovery'+v,dir=base+'/'+stem+'-20261019';
 const raw=await fs.readFile(dir+'/observation.json'),r=JSON.parse(raw);
 assert(!r.passed&&!r.qualified&&!r.publicEligible&&r.inconclusive&&!r.eviction);
 assert(r.elapsedMs<600000&&r.cleanup.every(x=>x.passed)&&!r.retainedProfile);
 assert(r.cleanup.some(x=>x.name==='only disposable test profile removed'));
 assert(r.operations.every(x=>!x.pending));
 assert.equal(r.observerRevision,'bcc0b61a8cbc984f075fae1260b899fb1b78ff1d');
 assert.equal(r.plan.envelopeSha256,'61ae470760baa9f276a0d6c9c22a3f536e4e5de8048246e454c07ef0e56e7270');
 assert.equal(hash(await fs.readFile('/private/tmp/'+stem+'-20261019.mjs')),r.observerSha256);
 for(const f of r.sourcePins)assert.equal(hash(await fs.readFile(f.path)),f.sha256);
 for(const f of r.exports){const b=await fs.readFile(dir+'/'+f.path);assert.equal(b.length,f.bytes);assert.equal(hash(b),f.sha256);}
 const s=JSON.parse(await fs.readFile(base+'/'+stem+'-supervision-20261019/receipt.json'));
 assert.equal(s.result.exitCode,1);assert(!s.result.timedOut&&!s.result.interrupted&&!s.abortedForSpace);assert.deepEqual(s.source,s.sourceAfter);
 assert.equal(hash(await fs.readFile(base+'/'+stem+'-supervision-20261019/browser.log')),s.logSha256);
 rows.push({attempt:v||'original',receiptSha256:hash(raw),failure:r.failure,elapsedMs:r.elapsedMs,actualLossObserved:false,recoveryPassed:false,cleanupPassed:true,nativeLessonCompleted:!!r.flight?.exercise?.nativeCompleted,independentLessonReplay:!!r.flight?.independentReplay?.verified});
}
assert(rows[0].failure.includes('#prepare-runtime'));
assert(rows[1].failure.includes('Unexpected offline action result: Offline runtime preparation completed.'));
assert(rows[2].failure.includes('#worlds-settings-tab-content'));
const report={format:'PracticeWorldRecoveryAttemptsAudit.v1',auditPassed:true,recoveryPassed:false,rows,scope:'Three failed observer attempts retained; none reached browser-managed eviction. Third attempt earned/exported/replayed a real lesson before project setup navigation failed. No simulator defect or data-loss/recovery pass inferred. Further retries paused for approach review.'};
await fs.writeFile(base+'/practice-main36-world-attempts-audit-20261019.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(report));
