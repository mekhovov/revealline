import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readEditionZip } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
import { verifyFrozenFPVExercise } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/practice-fpv-exercise-replay.mjs';
import { verifyFrozenGymTranscript } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/practice-exercise-replay.mjs';
const root = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const bundle = '/Volumes/alex/CodexMigrationStaging/flight-practice-main36-20261019-candidate';
const base = '/Volumes/alex/CodexMigrationStaging/practice-main36-browser-refresh-20261019';
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const envelopeBytes = await fs.readFile(`${bundle}/optional-packages.json`);
assert.equal(hash(envelopeBytes), '61ae470760baa9f276a0d6c9c22a3f536e4e5de8048246e454c07ef0e56e7270');
const envelope = JSON.parse(envelopeBytes), maps = new Map();
for (const pkg of envelope.packages) {
  const bytes = await fs.readFile(path.join(bundle, pkg.distribution.path));
  assert.equal(hash(bytes), pkg.distribution.sha256);
  maps.set(pkg.id, readEditionZip(bytes));
}
for (const kind of ['fpv', 'gym']) {
  const output = `${base}/${kind}`, raw = await fs.readFile(`${output}/observation.json`), report = JSON.parse(raw);
  assert(report.completed && report.procedureComplete && !report.qualified && report.cleanup.completed);
  assert.equal(report.plan.sourceRevision, envelope.sourceRevision);
  assert.equal(report.plan.envelopeSha256, hash(envelopeBytes));
  assert.equal(report.cases.length, kind === 'fpv' ? 8 : 2);
  for (const authority of report.authority) {
    assert.equal(hash(await fs.readFile(path.join(root, authority.path))), authority.sha256);
    assert.equal(hash(await fs.readFile(path.join(output, 'authority', path.basename(authority.path)))), authority.sha256);
  }
  assert(report.resourceAcquisitions.every((item) => !item.pending && !item.timedOut));
  const cases = [];
  for (const item of report.cases) {
    assert(item.passed && item.independentReplayVerified && item.exercise.nativeCompleted);
    assert.deepEqual(item.errors, []);
    assert.equal(kind === 'fpv' ? item.exercise.cleanup.keysReleased : item.exercise.cleanup.released, true);
    assert.deepEqual(item.exercise.cleanup.errors, []);
    const file = kind === 'fpv' ? item.export.file : item.exercise.transcript.exportedFile;
    const bytes = await fs.readFile(path.join(output, file.path));
    assert.equal(bytes.length, file.bytes);
    assert.equal(hash(bytes), file.sha256);
    const replay = kind === 'fpv' ? await verifyFrozenFPVExercise(maps.get(item.package), bytes.toString(), { packageId: item.package, mode: item.mode }) : await verifyFrozenGymTranscript(maps.get(item.package), bytes.toString());
    assert(replay.verified);
    const prior = kind === 'fpv' ? item.independentReplay : item.exercise.independentReplay;
    assert.deepEqual(replay.inputs, prior.inputs);
    if (kind === 'fpv') {
      assert.deepEqual(replay.identity, prior.identity);
      assert.equal(replay.frames, prior.frames);
      assert.equal(replay.state.status, 'complete');
    } else assert.equal(replay.snapshot.status, 'complete');
    assert.equal(hash(await fs.readFile(path.join(output, item.completionScreenshot.path))), item.completionScreenshot.sha256);
    cases.push({ id: item.id, package: item.package, locale: item.locale, mode: item.mode, nativeCompleted: true, actualExportSha256: file.sha256, independentlyReplayedAgain: true });
  }
  const result = { format: 'PracticeCurrentExerciseAudit.v1', passed: true, kind, source: envelope.sourceRevision, receiptSha256: hash(raw), cases, scope: 'Actual public UI exercise exports and repeated exact-package replay. Vertical Acro is not rotational proficiency, physical input or human learning. No origin-loss recovery, speech, performance or publication approval.' };
  await fs.writeFile(`${output}/audit-final.json`, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ kind, passed: true, cases: cases.length, receiptSha256: result.receiptSha256 }));
}
