import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readEditionZip } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/publishing/edition-zip.mjs';
const root='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const output='/Volumes/alex/CodexMigrationStaging/practice-main36-browser-refresh-20261019/production';
const raw=await fs.readFile(`${output}/observation.json`), r=JSON.parse(raw);
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const digest=async file=>{const h=createHash('sha256');let bytes=0;for await(const chunk of createReadStream(file)){bytes+=chunk.length;h.update(chunk);}return{bytes,sha256:h.digest('hex')};};
assert(r.completed&&r.procedureComplete&&!r.qualified&&r.cleanup.completed);
assert.equal(r.plan.sourceRevision,'08fc3430c8f6670a76c1a749b3ad0b65bc9f9ded');
assert.equal(r.plan.shellRevision,'bcc0b61a8cbc984f075fae1260b899fb1b78ff1d');
assert.equal(r.plan.observerRevision,r.plan.shellRevision);
assert.equal(r.plan.envelopeSha256,'61ae470760baa9f276a0d6c9c22a3f536e4e5de8048246e454c07ef0e56e7270');
assert.deepEqual(r.requestFailures,[]);
assert(r.resourceAcquisitions.every(row=>!row.pending&&!row.timedOut));
for(const row of r.authority)assert.equal(hash(await fs.readFile(path.join(root,row.path))),row.sha256);
assert.equal(r.distributionIO.length,2);
for(const row of r.distributionIO){assert(row.completed&&row.cleanup.completed);assert.equal(row.completedFiles,3560);assert.equal(row.completedBytes,1074765329);assert.deepEqual(row.cleanup.pending,[]);}
const manifestBytes=await fs.readFile(`${r.plan.distribution}/manifest.json`),manifest=JSON.parse(manifestBytes);
assert.equal(hash(manifestBytes),r.plan.distributionManifestSha256);
assert.equal(manifest.sourceRevision,r.plan.shellRevision);
assert.equal(manifest.files.length,3560);
assert.equal(manifest.totalBytes,1074765329);
for(const row of manifest.files){assert(!path.isAbsolute(row.path)&&!row.path.split('/').includes('..'));assert.deepEqual(await digest(path.join(r.plan.distribution,row.path)),{bytes:row.bytes,sha256:row.sha256});}
const overlay=new Map(r.overlay.map(row=>[row.path,row]));
const envelopeBytes=await fs.readFile(`${r.plan.bundle}/optional-packages.json`),envelope=JSON.parse(envelopeBytes);
assert.equal(hash(envelopeBytes),r.plan.envelopeSha256);
let members=0;
for(const pkg of envelope.packages){const zip=await fs.readFile(path.join(r.plan.bundle,pkg.distribution.path));assert.equal(hash(zip),pkg.distribution.sha256);for(const [name,bytes]of readEditionZip(zip)){const row=overlay.get(`practice/${pkg.id}/releases/${envelope.version}/site/${name}`);assert.equal(row?.sha256,hash(bytes));assert.equal(row?.bytes,bytes.length);members++;if(name.startsWith('launcher/'))assert.equal(overlay.get(`practice/${pkg.id}/app/${name.slice(9)}`)?.sha256,hash(bytes));}}
assert.equal(r.cases.length,6);
let screenshots=0;
for(const c of r.cases){assert(c.passed&&c.cardsVerified===3&&c.playActions===1&&c.standaloneDirectory&&c.mainGameReturn);assert.deepEqual(c.errors,[]);assert.deepEqual(c.runtimeRequestsBeforePlay,[]);assert.equal(c.app.locale,c.locale);assert.equal(new URL(c.app.url).search,`?lang=${c.locale}`);assert.deepEqual(c.personalAppearance.app,c.personalAppearance.main);for(const pin of c.screenshots){const bytes=await fs.readFile(path.join(output,pin.path));assert.equal(hash(bytes),pin.sha256);assert.equal(bytes.length,pin.bytes);screenshots++;}}
assert.equal(screenshots,24);
const zip=await digest(`${r.plan.distribution}/distribution.zip`);
assert.equal((await fs.readFile(`${r.plan.distribution}/distribution.zip.sha256`,'utf8')).trim(),`${zip.sha256}  distribution.zip`);
assert.equal(zip.sha256,'d2ab87ff383a16264c7c32841b522b84b37b8583e0781128dc523c31e618286b');
const archiveCheck=execFileSync('/usr/bin/unzip',['-tq',`${r.plan.distribution}/distribution.zip`],{timeout:60000,encoding:'utf8',maxBuffer:1024*1024});
const result={format:'PracticeMain36ProductionAudit.v1',passed:true,reportSha256:hash(raw),source:r.plan.sourceRevision,shell:r.plan.shellRevision,cases:6,screenshots,manifestFiles:manifest.files.length,manifestBytes:manifest.totalBytes,manifestSha256:hash(manifestBytes),packageMembers:members,zip,archiveCheck,scope:'Independent source/predicate/overlay/screenshot audit; every expanded manifest member rehashed, ZIP digest and native unzip CRC test passed. ZIP members not independently compared with manifest or re-expanded. Functional local journeys, not hosted capacity, native speech, human acceptance or performance approval.'};
await fs.writeFile(`${output}/audit-final.json`,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result));
