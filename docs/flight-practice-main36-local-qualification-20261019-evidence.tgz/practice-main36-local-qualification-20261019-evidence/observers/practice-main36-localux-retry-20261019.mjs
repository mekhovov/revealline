import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { frozenSource } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
import { observeIndustrialPhase } from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/verify-industrial-features.mjs';
const root='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const base='/Volumes/alex/CodexMigrationStaging';
const output=`${base}/practice-main36-localux-retry-20261019`;
const source=frozenSource(root);
const materialized=JSON.parse(await fs.readFile(base+'/practice-main36-materialize-source-20261019.json'));assert(materialized.passed&&materialized.raw.allTrackedSourceContentsAndModesMatch);assert.deepEqual(materialized.source,source);
const free=async()=>{const s=await fs.statfs('/private/tmp');return s.bavail*s.bsize;};
assert(await free()>=2*1024**3);
await fs.mkdir(output);
const controller=new AbortController();
const report={source,deadlineMs:600000,freeBefore:await free(),abortedForSpace:false};
let checking=false;
const guard=setInterval(async()=>{if(checking)return;checking=true;try{const n=await free();report.minimumFree=Math.min(report.minimumFree??Infinity,n);if(n<2*1024**3){report.abortedForSpace=true;controller.abort();}}catch{controller.abort();}finally{checking=false;}},1000);
try{report.result=await observeIndustrialPhase({command:['scripts/verify-industrial-features.mjs','--phase','local-ux'],cwd:root,log:`${output}/browser.log`,deadlineMs:600000,signal:controller.signal});}
finally{clearInterval(guard);while(checking)await new Promise(resolve=>setTimeout(resolve,10));}
report.sourceAfter=frozenSource(root);assert.deepEqual(report.sourceAfter,source);
report.logSha256=createHash('sha256').update(await fs.readFile(`${output}/browser.log`)).digest('hex');
await fs.writeFile(`${output}/receipt.json`,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(report));
if(report.result.exitCode!==0||report.result.timedOut||report.result.interrupted||report.result.executionError||report.abortedForSpace)process.exitCode=1;
