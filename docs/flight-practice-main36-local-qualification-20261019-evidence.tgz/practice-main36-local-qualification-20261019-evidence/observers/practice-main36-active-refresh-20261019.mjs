import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {frozenSource} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
import {observeIndustrialPhase} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/verify-industrial-features.mjs';
const root='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const base='/Volumes/alex/CodexMigrationStaging';
const output=base+'/practice-main36-active-refresh-20261019';
const source=frozenSource(root),hash=b=>createHash('sha256').update(b).digest('hex');
assert.equal(source.sourceRevision,'bcc0b61a8cbc984f075fae1260b899fb1b78ff1d');
assert(process.env.OPTIONAL_INSTALLATION_PASSWORD);
const recovered=JSON.parse(await fs.readFile(base+'/practice-main36-recovery-supervision-20261019/receipt.json'));
assert(!recovered.result.timedOut&&!recovered.result.interrupted,'Previous browser must have settled normally');
const prior=JSON.parse(await fs.readFile(base+'/practice-main36-academy-recovery-20261019/observation.json'));
assert(prior.cleanup.every(x=>x.passed)&&!prior.retainedProfile,'Previous browser resources must be cleaned');
const free=async()=>{const s=await fs.statfs('/private/tmp');return s.bavail*s.bsize;};
await fs.mkdir(output);
const report={source,operations:[],scope:'Refreshed Gym and Academy genuine historical installed-window continuity only. World historical active-session remains owner-deferred; no hardware, human or public release approval.'};
for(const kind of ['gym','academy']){
 for(const key of Object.keys(process.env))if(key.startsWith('OPTIONAL_INSTALLATION_')&&key!=='OPTIONAL_INSTALLATION_PASSWORD')delete process.env[key];
 Object.assign(process.env,{OPTIONAL_INSTALLATION_PREVIOUS_HISTORICAL:'v0.142.4-98ad851',OPTIONAL_INSTALLATION_WORLD_SEED:'worlds-template-copy',OPTIONAL_INSTALLATION_ACTIVE_SESSION:kind+'-v0.142.4-98ad851',OPTIONAL_INSTALLATION_ACTIVE_WINDOW:'owned-pwa-target-activation-98ad851'});
 if(kind==='gym')process.env.OPTIONAL_INSTALLATION_MIGRATION='all-three-98ad851';
 assert(await free()>=2*1024**3);assert.deepEqual(frozenSource(root),source);
 const controller=new AbortController(),row={id:kind,freeBefore:await free(),abortedForSpace:false};let checking=false;
 const guard=setInterval(async()=>{if(checking)return;checking=true;try{const n=await free();row.minimumFree=Math.min(row.minimumFree??Infinity,n);if(n<2*1024**3){row.abortedForSpace=true;controller.abort();}}catch{controller.abort();}finally{checking=false;}},1000);
 try{row.result=await observeIndustrialPhase({command:['scripts/observe-optional-installation.mjs','/Users/oleksandr.mekhovov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs',base+'/flight-practice-main36-20261019-candidate',output+'/'+kind+'.json',base+'/flight-practice-previous-v01424-20261016-candidate'],cwd:root,log:output+'/'+kind+'.log',deadlineMs:600000,signal:controller.signal});}
 finally{clearInterval(guard);while(checking)await new Promise(resolve=>setTimeout(resolve,10));}
 row.logSha256=hash(await fs.readFile(output+'/'+kind+'.log'));report.operations.push(row);report.sourceAfter=frozenSource(root);assert.deepEqual(report.sourceAfter,source);
 await fs.writeFile(output+'/receipt.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(row));
 if(row.result.exitCode!==0||row.result.timedOut||row.result.interrupted||row.result.executionError||row.abortedForSpace){process.exitCode=1;break;}
}
