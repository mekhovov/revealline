import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {chromium} from '/Users/oleksandr.mekhovov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {directoryJourneyOverlay} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/observe-practice-directory-journey.mjs';
import {unlockObservedPage,revealFPVOffline} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/optional-installation-observer-helpers.mjs';
import {frozenSource} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
const root='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test',base='/Volumes/alex/CodexMigrationStaging',output=base+'/practice-main36-native-digest-probe-20261019';
const source=frozenSource(root),hash=b=>createHash('sha256').update(b).digest('hex');
assert.equal(source.sourceRevision,'bcc0b61a8cbc984f075fae1260b899fb1b78ff1d');
assert(process.env.OPTIONAL_INSTALLATION_PASSWORD);
const previous=JSON.parse(await fs.readFile(base+'/practice-main36-active-refresh-20261019/receipt.json'));
assert.equal(previous.operations.length,2);assert(previous.operations.every(x=>x.result.exitCode===0&&!x.result.timedOut&&!x.result.interrupted));
const free=await fs.statfs('/private/tmp');assert(free.bavail*free.bsize>=2*1024**3);
await fs.mkdir(output);
const plan=JSON.parse(await fs.readFile(base+'/practice-main36-browser-refresh-20261019/fpv-plan.json'));
const r={format:'PracticeNativeDigestAvailability.v1',source,plan,passed:false,qualified:false,r4Complete:false,cases:[],cleanup:[],scope:'Bounded real-package native-trace availability and natural Cancel timing probe. No crypto/network/message interception, deliberate slowdown, previous/sibling retention qualification, hardware, performance acceptance or publication.'};
let browser,server,session,traceOpen=false,completeEvent;const start=performance.now();
const timer=setTimeout(()=>{void browser?.close();server?.closeAllConnections();},120000);
const pending=new Set();
try{
 const overlay=await directoryJourneyOverlay(plan);r.admission=overlay.loaded.admission;
 const mime={'.mjs':'text/javascript','.js':'text/javascript','.css':'text/css','.html':'text/html','.json':'application/json','.webmanifest':'application/manifest+json','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.woff2':'font/woff2'};
 server=http.createServer((req,res)=>{const u=new URL(req.url,'http://127.0.0.1');const name=u.pathname.slice(12)+(u.pathname.endsWith('/')?'index.html':'');const b=u.pathname.startsWith('/revealline/')&&overlay.files.get(name);res.writeHead(b?200:404,{'Content-Type':mime[path.extname(name)]??'application/octet-stream','Cache-Control':'no-store'});res.end(b??undefined);});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));r.origin='http://127.0.0.1:'+server.address().port;
 browser=await chromium.launch({channel:'chrome',headless:true,timeout:10000});r.browser=browser.version();session=await browser.newBrowserCDPSession();r.categories=await session.send('Tracing.getCategories');
 for(const kind of ['baseline','cancel']){
  const c={kind,finished:false,traceComplete:false};r.cases.push(c);const context=await browser.newContext({viewport:{width:1440,height:900}});const page=await context.newPage();page.setDefaultTimeout(8000);page.setDefaultNavigationTimeout(8000);
  try{
   await page.goto(r.origin+'/revealline/practice/civilian-fpv/app/?action=play&lang=en');await unlockObservedPage(page,process.env.OPTIONAL_INSTALLATION_PASSWORD);await page.waitForURL(u=>u.pathname.endsWith('/civilian-fpv/index.html'));await unlockObservedPage(page,process.env.OPTIONAL_INSTALLATION_PASSWORD);
   await page.locator('#academy-shell-action-settings').press('Enter');await page.locator('#academy-settings-tab-extras').press('Enter');await revealFPVOffline(page,()=>page.locator('#help').press('Enter'));
   await page.evaluate(()=>{globalThis.__practiceNativeCancel=[];document.addEventListener('click',event=>{if(event.target instanceof HTMLButtonElement&&event.target.textContent.trim()==='Cancel download'){const row={trusted:event.isTrusted,at:performance.now(),phase:document.querySelector('[data-optional-offline-progress] [role="status"]')?.textContent};globalThis.__practiceNativeCancel.push(row);performance.mark('practice-native-cancel-click');}},true);});
   completeEvent=new Promise(resolve=>session.once('Tracing.tracingComplete',resolve));
   await session.send('Tracing.start',{categories:'-*,disabled-by-default-devtools.timeline,devtools.timeline,blink.user_timing,toplevel',options:'record-as-much-as-possible',transferMode:'ReturnAsStream'});traceOpen=true;
   await page.locator('#install-offline').press('Enter');
   if(kind==='cancel'){
    try{await page.waitForFunction(()=>{const p=document.querySelector('[data-optional-offline-progress]');return p&&!p.hidden&&/^Verifying/.test(p.querySelector('[role="status"]')?.textContent??'');},null,{timeout:5000});const cancel=page.locator('[data-optional-offline-progress]').getByRole('button',{name:'Cancel download',exact:true});if(await cancel.isVisible()&&await cancel.isEnabled()){await cancel.click({timeout:1000});c.clickAttempted=true;}}
    catch(e){c.timingMiss=e.message;}
   }
   await page.waitForFunction(()=>/ready offline|ready for offline|prepared offline|cancelled|canceled/i.test(document.querySelector('#transfer-status')?.textContent??''),null,{timeout:30000});
   c.status=await page.locator('#transfer-status').textContent();c.clicks=await page.evaluate(()=>globalThis.__practiceNativeCancel);c.targets=await session.send('Target.getTargets');
   // Observe bounded late-state stability without introducing a crypto delay.
   await page.waitForTimeout(1000);c.statusAfterSettlement=await page.locator('#transfer-status').textContent();
   await session.send('Tracing.end');traceOpen=false;const complete=await Promise.race([completeEvent,new Promise((_,reject)=>setTimeout(()=>reject(Error('Trace completion timeout')),10000))]);assert(complete.stream);c.dataLossOccurred=complete.dataLossOccurred??false;
   const chunks=[];let size=0;for(;;){const row=await session.send('IO.read',{handle:complete.stream,size:1048576});const bytes=Buffer.from(row.data,row.base64Encoded?'base64':'utf8');size+=bytes.length;assert(size<=80*1024**2,'Trace exceeds 80 MiB');chunks.push(bytes);if(row.eof)break;}await session.send('IO.close',{handle:complete.stream});
   const bytes=Buffer.concat(chunks);c.trace={path:kind+'-trace.json',bytes:bytes.length,sha256:hash(bytes)};await fs.writeFile(path.join(output,c.trace.path),bytes,{flag:'wx'});const events=JSON.parse(bytes).traceEvents;
   c.digests=events.filter(e=>e.name==='DoDigest'||e.name==='DoDigestReply');c.cancelMarks=events.filter(e=>e.name==='practice-native-cancel-click');c.workerIdentityEvents=events.filter(e=>/TracingSessionIdForWorker/.test(e.name)||e.name==='thread_name'&&/worker/i.test(e.args?.name??''));
   c.rawTimestampOverlaps=c.cancelMarks.flatMap(mark=>c.digests.filter(d=>d.name==='DoDigest'&&Number.isFinite(d.dur)&&d.ts<=mark.ts&&mark.ts<d.ts+d.dur).map(d=>({mark,digest:d})));
   c.traceComplete=true;c.finished=true;
  }finally{await context.close();c.contextClosed=true;}
 }
 r.passed=r.cases.every(c=>c.finished&&c.contextClosed&&c.traceComplete&&!c.dataLossOccurred);r.naturalOverlapObserved=r.cases.some(c=>c.rawTimestampOverlaps?.length);r.outcome=r.naturalOverlapObserved?'Raw native timestamp overlap found; worker attribution and retention still require independent qualification.':'No natural Cancel/DoDigest overlap established. R4 remains inconclusive, not passed.';
}catch(e){r.failure=e.message;process.exitCode=1;}
finally{
 clearTimeout(timer);if(traceOpen)await session?.send('Tracing.end').catch(()=>{});await session?.detach().catch(()=>{});
 try{await browser?.close();r.cleanup.push({name:'owned browser',passed:true});}catch(e){r.cleanup.push({name:'owned browser',passed:false,error:e.message});}
 try{if(server)await new Promise(resolve=>{server.close(resolve);server.closeAllConnections();});r.cleanup.push({name:'owned server',passed:true});}catch(e){r.cleanup.push({name:'owned server',passed:false,error:e.message});}
 r.sourceAfter=frozenSource(root);assert.deepEqual(r.sourceAfter,source);r.elapsedMs=performance.now()-start;r.observerSha256=hash(await fs.readFile(new URL(import.meta.url)));r.passed&&=r.cleanup.every(c=>c.passed)&&r.elapsedMs<120000;
 await fs.writeFile(output+'/observation.json',JSON.stringify(r,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({passed:r.passed,failure:r.failure,outcome:r.outcome,cases:r.cases.map(c=>({kind:c.kind,digests:c.digests?.length,clicks:c.clicks,overlaps:c.rawTimestampOverlaps?.length,status:c.status,trace:c.trace})),cleanup:r.cleanup}));
}
