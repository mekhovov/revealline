import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {frozenSource} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/frozen-source.mjs';
import {observeIndustrialPhase,summarizeIndustrialTap} from '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/scripts/verify-industrial-features.mjs';
const root='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test',base='/Volumes/alex/CodexMigrationStaging',output=base+'/practice-main36-suites-20261019';
const source=frozenSource(root);assert.equal(source.sourceRevision,'bcc0b61a8cbc984f075fae1260b899fb1b78ff1d');
const trace=JSON.parse(await fs.readFile(base+'/practice-main36-native-digest-probe-v2-20261019/observation.json'));assert(trace.cleanup.every(x=>x.passed));
delete process.env.OPTIONAL_INSTALLATION_PASSWORD;
process.env.PATH='/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin:'+process.env.PATH;
await fs.mkdir(output);
const free=async()=>{const s=await fs.statfs('/private/tmp');return s.bavail*s.bsize;};
const report={source,operations:[],scope:'Fresh local Practice and local-UX software suites on frozen bcc. Not substitute for required remote checks or release approvals.'};
for(const [id,command]of [['practice',['/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/lib/node_modules/npm/bin/npm-cli.js','run','practice:test']],['local-ux',['scripts/verify-industrial-features.mjs','--phase','local-ux']]]){
 assert.deepEqual(frozenSource(root),source);assert(await free()>=2*1024**3);const row={id,freeBefore:await free(),abortedForSpace:false};const controller=new AbortController();let checking=false;
 const guard=setInterval(async()=>{if(checking)return;checking=true;try{const n=await free();row.minimumFree=Math.min(row.minimumFree??Infinity,n);if(n<2*1024**3){row.abortedForSpace=true;controller.abort();}}catch{controller.abort();}finally{checking=false;}},1000);
 try{row.result=await observeIndustrialPhase({command,cwd:root,log:output+'/'+id+'.log',deadlineMs:600000,signal:controller.signal});}
 finally{clearInterval(guard);while(checking)await new Promise(resolve=>setTimeout(resolve,10));}
 const bytes=await fs.readFile(output+'/'+id+'.log');row.logSha256=createHash('sha256').update(bytes).digest('hex');if(id==='practice')row.summary=summarizeIndustrialTap(bytes.toString(),row.result.exitCode,row.result.signal);
 row.sourceAfter=frozenSource(root);assert.deepEqual(row.sourceAfter,source);report.operations.push(row);await fs.writeFile(output+'/receipt.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(row));
 if(row.result.exitCode!==0||row.result.timedOut||row.result.interrupted||row.result.executionError||row.abortedForSpace||row.summary&&!row.summary.passed){process.exitCode=1;break;}
}
