import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import test from 'node:test';

const source = await readFile('/tmp/practice-eviction-guide-observer-sections-20261016.mjs', 'utf8');
const start = source.indexOf('              (locale) => {', source.indexOf("'Guide locale rendering ready'"));
const end = source.indexOf('\n              locale,', start);
assert(start > 0 && end > start);
const functionSource = source.slice(start, end).trim().replace(/,$/, '');
function evaluate(locale, rows) {
  const document = {
    documentElement: { lang: locale },
    querySelector: () => ({ value: locale }),
    querySelectorAll: selector => rows.filter(row => selector === `section[lang="${row.lang}"]`),
  };
  return vm.runInNewContext(`(${functionSource})(${JSON.stringify(locale)})`, { document });
}
const row = (lang, hidden) => ({ lang, hidden, checkVisibility: () => !hidden });
test('Actual two English sections and one Ukrainian section render in English', () => {
  assert.equal(evaluate('en', [row('en', false), row('en', false), row('uk', true)]), true);
});
test('Both English sections must hide in Ukrainian', () => {
  assert.equal(evaluate('uk', [row('en', true), row('en', true), row('uk', false)]), true);
  assert.equal(evaluate('uk', [row('en', false), row('en', true), row('uk', false)]), false);
});
test('Missing selected or opposite locale fails', () => {
  assert.equal(evaluate('en', [row('uk', true)]), false);
  assert.equal(evaluate('en', [row('en', false)]), false);
});
test('Any hidden selected section fails', () => {
  assert.equal(evaluate('en', [row('en', false), row('en', true), row('uk', true)]), false);
});
test('All three maintained guides have exactly the observed section structure', async () => {
  for (const id of ['civilian-flight', 'civilian-fpv', 'fpv-worlds']) {
    const html = await readFile(`/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test/optional-practice/${id}/guide.html`, 'utf8');
    assert.equal([...html.matchAll(/<section lang="en">/g)].length, 2);
    assert.equal([...html.matchAll(/<section lang="uk" hidden>/g)].length, 1);
  }
});
