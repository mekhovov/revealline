import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, mkdtemp, rm } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { tmpdir } from 'node:os';

const repository = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const plan = {
  repository,
  shellRevision: '11aa297825203fdd0dd4db075f5eaeb9aa34660e',
  shellTree: '13654b1fe99d3fd147fd20ecbfcd30721d1703df',
  bundle: '/tmp/practice-eviction-guides-20261016-candidate',
  envelopeSha256: '4258044c72b2ef697134d239910f83f77e85e3b3034c337c28ba6d0930d24ba9',
  sourceRevision: '11aa297825203fdd0dd4db075f5eaeb9aa34660e',
  sourceTree: '13654b1fe99d3fd147fd20ecbfcd30721d1703df',
  packageRevision: '94b45cbec77d9680f587a90a03b2f7f6b3d087908fcd7b6f0c1c2f6cb141ab27',
};
const prior = {
  bundle: '/tmp/practice-onboarding-20261016-candidate',
  envelopeSha256: 'f559fdd7a935f03f15481fe657fbee3eb4b52e3c0c4b48d0bd3c9f70bedab7eb',
  sourceRevision: '1b339bfe6596290b6db17ae0e268e4c8a843071a',
  sourceTree: '08e5a779523e8e356cccc9c45b96340676c1c56d',
  packageRevision: 'bf6f874534664b4c347852a88c676fbdab4dfc9ea148a9e764722a445fe771d9',
};
const playwright =
  '/Users/oleksandr.mekhovov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
const preflight = process.argv[2] === '--preflight',
  output = process.argv[preflight ? 3 : 2];
assert.equal(process.argv.length, preflight ? 4 : 3);
assert(path.isAbsolute(output) && path.dirname(output) === '/tmp');
await mkdir(output);
const sha = (b) => createHash('sha256').update(b).digest('hex');
const pin = (p, b) => ({ path: p, bytes: b.length, sha256: sha(b) });
const load = (n) => import(pathToFileURL(path.join(repository, n)));
const { nativeA11yScope, classifyNativeSourceRequests } = await load(
  'scripts/observe-practice-directory-native-a11y.mjs',
);
const total = nativeA11yScope({ overallMs: 120000, actionMs: 10000 }),
  scopes = [total],
  resources = [];
const report = {
  format: 'PracticeEvictionGuideObservation.v1',
  plan,
  prior,
  passed: false,
  preflightOnly: preflight,
  qualified: false,
  publicEligible: false,
  sourceShellOnly: true,
  productionQualification: false,
  cases: [],
  servedSources: [],
  requestFailures: [],
  authority: [],
  cleanup: [],
  resources: [],
  limitations: [
    'Guide-only headless Chrome software observation; no simulator Play, flight, installation, data recovery, actual eviction or production/hosting qualification.',
    'Warnings and navigation text/visible geometry are checked; screenshots are retained unreviewed. No human readability, speech or physical-device claim.',
  ],
};
let stopped = false,
  server,
  context,
  profile,
  launchAttempted = false,
  tree,
  evidenceBytes = 0;
const clean = async (label, fn) => {
  const s = nativeA11yScope({ overallMs: 5000, actionMs: 5000 });
  scopes.push(s);
  try {
    await s.run(label, fn);
    report.cleanup.push({ label, closed: true });
    return true;
  } catch (e) {
    report.cleanup.push({ label, closed: false, error: e.message });
    return false;
  } finally {
    s.stop();
  }
};
const acquire = async (name, fn, close) => {
  const row = { name, pending: true, acquired: false, closed: false };
  report.resources.push(row);
  return total.run(name, async () => {
    let value;
    try {
      value = await fn();
    } finally {
      row.pending = false;
    }
    row.acquired = true;
    const release = async () => {
      if (!row.closed) {
        await close(value);
        row.closed = true;
      }
    };
    resources.push({ row, release });
    if (stopped) {
      await clean('Late ' + name, release);
      throw Error('Resource arrived after observation stopped.');
    }
    return value;
  });
};
try {
  const [
    helpers,
    frozen,
    { loadFPVObservationArtifact },
    { readEditionZip },
    { unlockObservedPage },
  ] = await total.run('Load maintained helpers', () =>
    Promise.all([
      load('scripts/observe-practice-directory-journey.mjs'),
      load('scripts/frozen-source.mjs'),
      load('scripts/fpv-observation-artifact.mjs'),
      load('publishing/edition-zip.mjs'),
      load('scripts/optional-installation-observer-helpers.mjs'),
    ]),
  );
  const source = () =>
    assert.deepEqual(frozen.frozenSource(repository), {
      sourceRevision: plan.shellRevision,
      sourceTree: plan.shellTree,
    });
  await total.run('Initial clean source', source);
  const names = [
    'scripts/observe-practice-directory-native-a11y.mjs',
    'scripts/practice-native-zoom-capability.mjs',
    'scripts/observe-practice-directory-journey.mjs',
    'scripts/frozen-source.mjs',
    'scripts/fpv-observation-artifact.mjs',
    'scripts/optional-installation-observer-helpers.mjs',
    'publishing/edition-zip.mjs',
    'publishing/optional-package-admission.mjs',
    'publishing/practice-directory.mjs',
  ];
  for (const n of names)
    report.authority.push(
      pin(n, await total.run('Pin helper ' + n, () => readFile(path.join(repository, n)))),
    );
  report.observer = pin(
    path.basename(new URL(import.meta.url).pathname),
    await readFile(new URL(import.meta.url)),
  );
  tree = await total.run('Committed inputs', () => frozen.committedInputMap(repository));
  const overlay = await total.run('Admit new packages', () =>
    helpers.directoryJourneyOverlay(plan),
  );
  const old = await total.run('Admit prior original packages', () =>
    loadFPVObservationArtifact(prior),
  );
  report.artifact = overlay.loaded.binding;
  report.admission = overlay.loaded.admission;
  report.priorAdmission = old.admission;
  report.overlay = [...overlay.files].map(([n, b]) => pin(n, b));
  const oldEnvelope = JSON.parse(
    await total.run('Read old envelope', () =>
      readFile(path.join(prior.bundle, 'optional-packages.json')),
    ),
  );
  const envelope = JSON.parse(
    await total.run('Read new envelope', () =>
      readFile(path.join(plan.bundle, 'optional-packages.json')),
    ),
  );
  report.changedPackages = [];
  for (const item of envelope.packages) {
    const a = oldEnvelope.packages.find((x) => x.id === item.id),
      [ab, bb] = await total.run('Compare original ZIP ' + item.id, () =>
        Promise.all([
          readFile(path.join(prior.bundle, a.distribution.path)),
          readFile(path.join(plan.bundle, item.distribution.path)),
        ]),
      );
    assert.equal(sha(ab), a.distribution.sha256);
    assert.equal(sha(bb), item.distribution.sha256);
    const left = readEditionZip(ab),
      right = readEditionZip(bb);
    assert.deepEqual([...left.keys()].sort(), [...right.keys()].sort());
    const changed = [...right.keys()].filter((n) => !left.get(n).equals(right.get(n))).sort();
    const expected = [
      'optional-package.json',
      `optional-practice/${item.id}/guide.html`,
      `optional-practice/${item.id}/worker.js`,
    ].sort();
    report.changedPackages.push({
      id: item.id,
      members: right.size,
      oldRevision: a.revision,
      newRevision: item.revision,
      changed: changed.map((n) => ({
        path: n,
        before: pin(n, left.get(n)),
        after: pin(n, right.get(n)),
      })),
    });
    assert.deepEqual(changed, expected, 'Unexpected package byte changes');
  }
  if (!preflight) {
    assert(
      process.env.OPTIONAL_INSTALLATION_PASSWORD,
      'Authorized credential must be supplied silently through OPTIONAL_INSTALLATION_PASSWORD.',
    );
    server = await acquire(
      'Owned source server',
      () => helpers.directoryJourneyServer(overlay.files, tree, report),
      async (s) => {
        s.stop();
        s.server.closeAllConnections();
        await new Promise((res, rej) => s.server.close((e) => (e ? rej(e) : res())));
        await s.settled();
      },
    );
    profile = await acquire(
      'Owned fresh profile',
      () => mkdtemp(path.join(tmpdir(), 'practice-eviction-guide-')),
      async (p) => {
        if (stopped && !launchAttempted) await rm(p, { recursive: true });
      },
    );
    report.profilePath = profile;
    const { chromium } = await total.run(
      'Load existing browser',
      () => import(pathToFileURL(playwright)),
    );
    launchAttempted = true;
    context = await acquire(
      'Owned headless Chrome',
      () =>
        chromium.launchPersistentContext(profile, {
          channel: 'chrome',
          headless: true,
          viewport: { width: 1280, height: 900 },
          deviceScaleFactor: 1,
          locale: 'en-US',
          timeout: 10000,
        }),
      (c) => c.close(),
    );
    context.setDefaultTimeout(10000);
    context.setDefaultNavigationTimeout(10000);
    report.browser = context.browser()?.version() ?? 'unavailable';
    report.browserMode = {
      headless: true,
      viewport: { width: 1280, height: 900 },
      deviceScaleFactor: 1,
    };
    if (report.browser === 'unavailable') {
      const versionPage = await acquire(
        'Version-only owned page',
        () => context.newPage(),
        (p) => p.close(),
      );
      const session = await acquire(
        'Read-only browser version',
        () => context.newCDPSession(versionPage),
        (s) => s.detach(),
      );
      report.browser = await total.run('Read actual browser version', () =>
        session.send('Browser.getVersion'),
      );
    }
    const phrases = {
      en: [
        'Browser eviction can remove records and imported worlds, not only cached files.',
        'Keep exported backups outside browser storage.',
        'restore your exported backups with its import tools.',
        'Downloading the app does not recover lost records; without an export, they may be unrecoverable.',
      ],
      uk: [
        'Витіснення браузером може видалити записи та імпортовані світи, а не лише кешовані файли.',
        'експортовані резервні копії поза сховищем браузера.',
        'імпортуйте свої резервні копії його засобами імпорту.',
        'Завантаження застосунку не відновлює втрачені записи; без експорту відновлення може бути неможливим.',
      ],
    };
    for (const locale of ['en', 'uk'])
      for (const pkg of overlay.packages) {
        const s = nativeA11yScope({ overallMs: 30000, actionMs: 10000 });
        scopes.push(s);
        const run = (label, fn) => total.run(label, () => s.run(label, fn));
        const c = {
          id: `${locale}-${pkg.id}`,
          locale,
          package: pkg.id,
          passed: false,
          access: [],
          screenshots: [],
          errors: [],
        };
        report.cases.push(c);
        let page;
        try {
          page = await acquire(
            'Guide ' + c.id,
            () => context.newPage(),
            (p) => p.close(),
          );
          page.on('pageerror', (e) => {
            if (c.errors.length < 10) c.errors.push(e.message.slice(0, 512));
          });
          const root = new URL('revealline/', server.url),
            guide = new URL(
              `practice/${pkg.id}/releases/${report.admission.version}/site/optional-practice/${pkg.id}/guide.html?lang=${locale}`,
              root,
            );
          await run('Open original admitted guide', () =>
            page.goto(guide.href, { waitUntil: 'domcontentloaded' }),
          );
          c.access.push(
            await run('Normal guide access', () =>
              unlockObservedPage(page, process.env.OPTIONAL_INSTALLATION_PASSWORD),
            ),
          );
          await run('Guide locale rendering ready', () =>
            page.waitForFunction(
              (locale) => {
                const active = [
                    ...globalThis.document.querySelectorAll(`section[lang="${locale}"]`),
                  ],
                  other = [
                    ...globalThis.document.querySelectorAll(
                      `section[lang="${locale === 'en' ? 'uk' : 'en'}"]`,
                    ),
                  ];
                return (
                  globalThis.document.documentElement.lang === locale &&
                  globalThis.document.querySelector('#locale')?.value === locale &&
                  active.length > 0 &&
                  active.every((el) => !el.hidden && el.checkVisibility()) &&
                  other.length > 0 &&
                  other.every((el) => el.hidden && !el.checkVisibility())
                );
              },
              locale,
              { timeout: 10000 },
            ),
          );
          const section = page.locator(`section[lang="${locale}"]`);
          c.localizedSections = await run('Read all localized section visibility', () =>
            page
              .locator('section[lang]')
              .evaluateAll((elements) =>
                elements.map((el) => ({
                  lang: el.lang,
                  hidden: el.hidden,
                  visible: el.checkVisibility(),
                })),
              ),
          );
          assert.equal(c.localizedSections.filter((x) => x.lang === 'en').length, 2);
          assert.equal(c.localizedSections.filter((x) => x.lang === 'uk').length, 1);
          for (const entry of c.localizedSections) {
            assert.equal(entry.hidden, entry.lang !== locale);
            assert.equal(entry.visible, entry.lang === locale);
          }
          assert.equal(
            await run('Guide actual language', () => page.locator('html').getAttribute('lang')),
            locale,
          );
          c.headings = await run('Visible guide headings', () =>
            section.locator('h1,h2').allTextContents(),
          );
          assert(c.headings.length >= 6);
          const text = (await run('Visible guide content', () => section.allInnerTexts()))
            .join(' ')
            .replace(/\s+/g, ' ')
            .trim();
          c.warningPhrases = phrases[locale];
          for (const phrase of c.warningPhrases)
            assert(text.includes(phrase), 'Required localized guide warning missing');
          const warning = section.locator('strong').filter({
            hasText:
              locale === 'en'
                ? 'Browser eviction can remove records'
                : 'Витіснення браузером може видалити записи',
          });
          assert.equal(await run('Unique warning', () => warning.count()), 1);
          const paragraph = warning.locator('xpath=..');
          await run('Ordinary warning scroll', () => paragraph.scrollIntoViewIfNeeded());
          c.visibleWarning = await run('Read warning geometry', () =>
            paragraph.evaluate((el) => {
              const r = el.getBoundingClientRect();
              return {
                text: el.innerText.replace(/\s+/g, ' ').trim(),
                visible: el.checkVisibility(),
                x: r.x,
                y: r.y,
                width: r.width,
                height: r.height,
                viewport: {
                  width: globalThis.innerWidth,
                  height: globalThis.innerHeight,
                  dpr: globalThis.devicePixelRatio,
                },
              };
            }),
          );
          const w = c.visibleWarning;
          assert(
            w.visible && w.x >= 0 && w.y >= 0 && w.x + w.width <= 1280 && w.y + w.height <= 900,
          );
          const image = await run('Capture guide warning', () =>
            paragraph.screenshot({ timeout: 5000 }),
          );
          evidenceBytes += image.length;
          assert(evidenceBytes < 16 * 1024 * 1024);
          const screenshot = `${c.id}-warning.png`;
          await run('Save warning image', () =>
            writeFile(path.join(output, screenshot), image, { flag: 'wx' }),
          );
          c.screenshots.push({ ...pin(screenshot, image), visuallyReviewed: false });
          const play = new URL(
            await run('Read app destination only', () =>
              page.locator('#play').getAttribute('href'),
            ),
            guide,
          );
          assert.equal(play.href, new URL(`index.html?lang=${locale}`, guide).href);
          c.appLinkCheckedWithoutOpening = play.href;
          const directory = new URL(
            await run('Read directory destination', () =>
              page.locator('#directory').getAttribute('href'),
            ),
            guide,
          );
          assert.equal(directory.href, new URL(`practice/?lang=${locale}`, root).href);
          await run('Public Back to directory', () => page.locator('#directory').click());
          await run('Directory route', () => page.waitForURL(directory.href));
          assert.equal(
            await run('Directory locale', () => page.locator('html').getAttribute('lang')),
            locale,
          );
          assert.equal(
            await run('Three directory cards', () => page.locator('main article').count()),
            3,
          );
          const main = page.locator('nav a[data-locale]').first();
          const mainURL = new URL(
            await run('Read main return route', () => main.getAttribute('href')),
            directory,
          );
          assert.equal(mainURL.href, new URL(`game/?lang=${locale}`, root).href);
          await run('Public main return', () => main.click());
          await run('Main route', () => page.waitForURL(mainURL.href));
          c.access.push(
            await run('Normal main access', () =>
              unlockObservedPage(page, process.env.OPTIONAL_INSTALLATION_PASSWORD),
            ),
          );
          await run('Main Home visible', () =>
            page.locator('#shell-home[open]').waitFor({ state: 'visible' }),
          );
          c.mainReturnLocale = await run('Main actual return locale', () =>
            page.locator('html').getAttribute('lang'),
          );
          assert.equal(c.mainReturnLocale, locale);
          assert.deepEqual(c.errors, []);
          c.passed = true;
        } catch (e) {
          c.failure = e.message;
        } finally {
          s.stop();
          if (page) await clean('Close guide ' + c.id, () => page.close());
        }
      }
  }
  // End all native/source delivery activity before the final byte/source audit.
  // Keep the idempotent finally path for failures and late acquired resources.
  stopped = true;
  for (const x of [...resources].reverse()) await clean('Settle ' + x.row.name, x.release);
  if (server) await clean('Settle source requests before integrity audit', () => server.settled());
  for (const s of scopes.slice())
    await clean('Settle pending work before integrity audit', () => s.settled());
  assert.equal(scopes.reduce((n, s) => n + s.pending(), 0) + (server?.pending() ?? 0), 0);
  assert(report.resources.every((x) => !x.pending && (!x.acquired || x.closed)));
  assert(report.cleanup.every((x) => x.closed));
  const again = await total.run('Re-admit original new packages', () =>
    helpers.directoryJourneyOverlay(plan),
  );
  assert.deepEqual(
    [...again.files].map(([n, b]) => pin(n, b)),
    report.overlay,
  );
  for (const row of report.servedSources) {
    const b = await total.run('Recheck served ' + row.path, () =>
      readFile(path.join(repository, row.path)),
    );
    assert.equal(sha(b), row.sha256);
    frozen.verifyCommittedInputs(new Map([[row.path, b]]), tree);
  }
  for (const row of report.authority)
    assert.equal(
      sha(
        await total.run('Recheck helper ' + row.path, () =>
          readFile(path.join(repository, row.path)),
        ),
      ),
      row.sha256,
    );
  assert.equal(
    sha(await total.run('Recheck observer', () => readFile(new URL(import.meta.url)))),
    report.observer.sha256,
  );
  await total.run('Final frozen source', source);
  total.check();
  report.sourceStable = true;
  report.passed = preflight || (report.cases.length === 6 && report.cases.every((c) => c.passed));
} catch (e) {
  report.failure = e.message;
} finally {
  stopped = true;
  total.stop();
  for (const x of [...resources].reverse()) await clean('Release ' + x.row.name, x.release);
  if (server) await clean('Join source requests', () => server.settled());
  for (const s of scopes.slice()) await clean('Join pending work', () => s.settled());
  report.pendingOperations = scopes.reduce((n, s) => n + s.pending(), 0) + (server?.pending() ?? 0);
  report.requestClassification = classifyNativeSourceRequests(report.requestFailures, {
    sourceShellOnly: true,
    productionQualification: false,
    buildInfoAbsent: !tree?.has('game/build-info.json'),
  });
  report.profileRemoved = !profile;
  if (
    profile &&
    !report.pendingOperations &&
    report.cleanup.every((x) => x.closed) &&
    report.cases.every((c) => c.errors.length === 0) &&
    report.resources.every((x) => !x.pending && (!x.acquired || x.closed))
  )
    report.profileRemoved = await clean('Remove owned profile', () =>
      rm(profile, { recursive: true }),
    );
  report.passed &&=
    report.pendingOperations === 0 &&
    report.profileRemoved &&
    report.cases.every((c) => c.errors.length === 0) &&
    report.cleanup.every((x) => x.closed) &&
    report.requestClassification.unexpected.length === 0;
  await writeFile(path.join(output, 'observation.json'), JSON.stringify(report, null, 2) + '\n', {
    flag: 'wx',
  });
}
console.log(
  JSON.stringify({
    passed: report.passed,
    preflightOnly: preflight,
    output,
    failure: report.failure,
    cases: report.cases.map((c) => ({ id: c.id, passed: c.passed, failure: c.failure })),
  }),
);
process.exitCode = report.passed ? 0 : 1;
