import assert from 'node:assert/strict';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const repository='/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const directory='/tmp/practice-eviction-guides-20261016-run2';
const reportPath=path.join(directory,'observation.json');
const bytes=await readFile(reportPath),r=JSON.parse(bytes);
const sha=b=>createHash('sha256').update(b).digest('hex');
const pin=(name,b)=>({path:name,bytes:b.length,sha256:sha(b)});
const git=(...args)=>execFileSync('git',['-C',repository,...args],{maxBuffer:32*1024*1024,timeout:10000});
const revision='11aa297825203fdd0dd4db075f5eaeb9aa34660e';
assert.equal(r.plan.shellRevision,revision);
assert.equal(r.plan.shellTree,'13654b1fe99d3fd147fd20ecbfcd30721d1703df');
assert.equal(git('rev-parse',`${revision}^{tree}`).toString().trim(),r.plan.shellTree);
assert(r.passed && r.sourceStable && !r.preflightOnly && !r.qualified && !r.publicEligible && !r.productionQualification && r.sourceShellOnly);
assert.equal(r.observer.sha256,'70ba680219f5cce1bd7b7736392322ce037fec09a39c7ddc84d1610e0e8ea639');
assert.equal(sha(await readFile('/tmp/'+r.observer.path)),r.observer.sha256);
for(const row of r.authority) {
  assert.deepEqual(pin(row.path,git('show',`${revision}:${row.path}`)),row);
  assert.deepEqual(pin(row.path,await readFile(path.join(repository,row.path))),row);
}
const refs=r.servedSources.map(row=>`${revision}:${row.path}`);
const batch=execFileSync('git',['-C',repository,'cat-file','--batch'],{input:refs.join('\n')+'\n',maxBuffer:64*1024*1024,timeout:10000});
let offset=0;
for(const row of r.servedSources){
  const end=batch.indexOf(10,offset),header=batch.subarray(offset,end).toString();
  assert.match(header,/^[0-9a-f]{40} blob [0-9]+$/);
  const count=Number(header.split(' ')[2]),body=batch.subarray(end+1,end+1+count);
  assert.deepEqual(pin(row.path,body),row);
  offset=end+count+2;
}
assert.equal(offset,batch.length);
const {directoryJourneyOverlay}=await import(pathToFileURL(path.join(repository,'scripts/observe-practice-directory-journey.mjs')));
const {readEditionZip}=await import(pathToFileURL(path.join(repository,'publishing/edition-zip.mjs')));
const {loadFPVObservationArtifact}=await import(pathToFileURL(path.join(repository,'scripts/fpv-observation-artifact.mjs')));
const overlay=await directoryJourneyOverlay(r.plan);
assert.deepEqual(overlay.loaded.binding,r.artifact);
assert.deepEqual(overlay.loaded.admission,r.admission);
assert.deepEqual([...overlay.files].map(([name,body])=>pin(name,body)),r.overlay);
const oldAdmission=await loadFPVObservationArtifact(r.prior);
assert.deepEqual(oldAdmission.admission,r.priorAdmission);
const oldBytes=await readFile(path.join(r.prior.bundle,'optional-packages.json'));
assert.equal(sha(oldBytes),r.prior.envelopeSha256);
const old=JSON.parse(oldBytes),current=JSON.parse(await readFile(path.join(r.plan.bundle,'optional-packages.json')));
assert.equal(sha(await readFile(path.join(r.plan.bundle,'optional-packages.json'))),'4258044c72b2ef697134d239910f83f77e85e3b3034c337c28ba6d0930d24ba9');
const changes=[];
for(const pkg of current.packages){
  const prior=old.packages.find(p=>p.id===pkg.id), maps=[];
  for(const [base,item] of [[r.prior.bundle,prior],[r.plan.bundle,pkg]]){
    const zip=await readFile(path.join(base,item.distribution.path));
    assert.equal(sha(zip),item.distribution.sha256);
    maps.push(readEditionZip(zip));
  }
  const [a,b]=maps;
  assert.deepEqual([...a.keys()],[...b.keys()]);
  const changed=[...a].filter(([name,body])=>sha(body)!==sha(b.get(name))).map(([name])=>name).sort();
  assert.deepEqual(changed,['optional-package.json',`optional-practice/${pkg.id}/guide.html`,`optional-practice/${pkg.id}/worker.js`].sort());
  changes.push({id:pkg.id,members:a.size,changed});
}
const expected=['civilian-flight','civilian-fpv','fpv-worlds'].flatMap(id=>['en','uk'].map(locale=>`${locale}-${id}`)).sort();
assert.deepEqual(r.cases.map(c=>c.id).sort(),expected);
const screenshots=[];
for(const c of r.cases){
  assert(c.passed && c.errors.length===0 && c.headings.length>=6);
  assert.equal(c.mainReturnLocale,c.locale);
  assert.deepEqual(c.localizedSections.map(s=>s.lang),['en','en','uk']);
  for(const section of c.localizedSections){assert.equal(section.visible,section.lang===c.locale);assert.equal(section.hidden,section.lang!==c.locale);}
  const w=c.visibleWarning;
  assert(w.visible && w.x>=0 && w.y>=0 && w.x+w.width<=w.viewport.width && w.y+w.height<=w.viewport.height);
  assert.equal(c.warningPhrases.length,4);
  for(const phrase of c.warningPhrases) assert(w.text.includes(phrase));
  assert.equal(new URL(c.appLinkCheckedWithoutOpening).pathname,`/revealline/practice/${c.package}/releases/v0.151.1/site/optional-practice/${c.package}/index.html`);
  assert.equal(new URL(c.appLinkCheckedWithoutOpening).search,`?lang=${c.locale}`);
  assert.equal(c.screenshots.length,1);
  for(const image of c.screenshots){
    const png=await readFile(path.join(directory,image.path));
    assert.equal(sha(png),image.sha256);assert.equal(png.length,image.bytes);
    assert.equal(png.subarray(1,4).toString(),'PNG');
    screenshots.push({...pin(image.path,png),width:png.readUInt32BE(16),height:png.readUInt32BE(20)});
  }
}
assert.equal(r.requestFailures.length,7);
assert.equal(r.requestFailures.filter(x=>x.path==='/favicon.ico' && x.message==='Outside local fixture root.').length,1);
assert.equal(r.requestFailures.filter(x=>x.path==='/revealline/game/build-info.json' && x.message==='Not a committed regular file.').length,6);
assert.equal(r.requestClassification.expected.length,7);assert.equal(r.requestClassification.unexpected.length,0);
assert.equal(r.pendingOperations,0);assert(r.profileRemoved && r.cleanup.every(x=>x.closed));
assert(r.resources.every(x=>!x.pending && (!x.acquired||x.closed)));
await assert.rejects(stat(r.profilePath),{code:'ENOENT'});
const audit={format:'PracticeEvictionGuideIndependentAudit.v1',passed:true,report:pin(reportPath,bytes),observer:r.observer,sourceRevision:revision,sourceTree:r.plan.shellTree,browser:r.browser,admission:r.admission,authorityCount:r.authority.length,servedSourceCount:r.servedSources.length,overlayCount:r.overlay.length,changes,cases:r.cases.map(c=>({id:c.id,mainReturnLocale:c.mainReturnLocale,warningPhraseCount:c.warningPhrases.length})),screenshots,uniqueScreenshotHashes:[...new Set(screenshots.map(x=>x.sha256))],rawRequestCount:7,unexpectedRequests:0,cleanup:true,pendingOperations:0,limitations:['No app Play, simulator flight, installation, recovery or actual browser eviction exercised.','Source-shell guide/navigation check, not production or hosting qualification.','Automated text/geometry and PNG integrity only; visual review is a separate narrated observation, not human readability, assistive technology or physical-device certification.']};
audit.priorAdmission=oldAdmission.admission;
audit.bothOriginalAdmissionsReproduced=true;
audit.log=pin('/tmp/practice-eviction-guides-20261016-run2.log',await readFile('/tmp/practice-eviction-guides-20261016-run2.log'));
audit.helpersBeforeAfterMatchGit=true;
for(const row of r.authority) assert.deepEqual(pin(row.path,await readFile(path.join(repository,row.path))),row);
assert.deepEqual(pin(reportPath,await readFile(reportPath)),audit.report);
assert.equal(audit.uniqueScreenshotHashes.length,2);
await writeFile('/tmp/practice-eviction-guide-independent-audit-final-20261016.json',JSON.stringify(audit,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({passed:true,cases:6,changes,screenshots:audit.uniqueScreenshotHashes,report:audit.report}));
