# Native Chrome zoom capability — temporary proposal

This is a capability probe, not C9 completion. No browser has been run. The active repository, simulator packages, production distribution and credentials are untouched.

## Small scope

`scripts/observe-practice-native-zoom.mjs` creates a fresh owned persistent Chrome profile, a single loopback-only immutable HTML fixture and a Chrome Settings page. The browser is headed, with `viewport: null`, no device-scale override and no existing-browser connection. The Settings page's visible `settings-appearance-page #zoomLevel` control must offer enabled 100% and 200% options. Normal `selectOption` interaction chooses 100 → 200 → 100; there is no private settings API invocation or direct preference-file mutation.

Each step records the selected native option plus fixture outer/inner geometry, DPR, visual viewport scale and a fixed 200-CSS-pixel marker. Passing requires unchanged outer window size, approximately halved CSS viewport and doubled DPR at 200%, unchanged marker CSS geometry, visual scale 1, no CSS transform/zoom, and restoration of the baseline. A real settings screenshot at 200% and three fixture screenshots are hashed. If installed Chrome differs, the run fails; no CSS scaling, device emulation or shortcut fallback can turn it into a pass.

This builds on the ordinary Chrome Appearance → Page zoom setting documented at https://support.google.com/chrome/answer/96810?co=GENIE.Platform%3DDesktop&hl=en and the current Chromium `appearance_page.ts`/`appearance_page.html.ts` visible control. Exact installed-browser support remains unverified.

## API

- `observeNativeChromeZoom({ modulePath, output })`: existing absolute Playwright module, new absolute output directory. Returns the final receipt; no runtime or browser downloads.
- `observeNativeZoomSequence({ page, settings, fixtureURL, run, capture, receipt })`: bounded UI-adapter sequence reusable after capability proof.
- `selectNativeZoom(settings, '1' | '2', run, actions)`: validates the real visible/enabled native control before normal selection.
- `validateZoomControl`, `validateZoomMetrics`, `verifyNativeZoomSequence`: fail-closed pure evidence checks.
- `zoomOperationScope`: 90-second overall / 10-second action ceilings with absolute monotonic checks and tracked pending underlying promises. Tests can shorten, never enlarge the limits.

Future approved invocation (do not run until resource/approval coordination):

```sh
PRACTICE_NATIVE_ZOOM_CAPABILITY=1 node scripts/observe-practice-native-zoom.mjs \
  --playwright /absolute/existing/playwright/index.mjs \
  --output /tmp/fresh-native-zoom-capability-run
```

The output directory must not already exist. It contains `observation.json` and four screenshots. The receipt identifies exact helper/observer and fixture hashes, actual Chrome version, all control and geometry witnesses, cleanup and limitations. This probe does not claim package/source-shell binding: `packageBound`, `qualified` and `publicEligible` are false.

## Ownership and failure behavior

Before browser closure, a separately bounded cleanup route attempts to reset the owned profile's visible setting to 100%. Browser and loopback server close independently; pending acquisition/actions remain tracked, and late resources get an owned close attempt. Only the generated disposable profile can be removed. A missing native control, unverified reset, pending operation, failed close, missing profile removal, page error or authority drift makes the receipt fail. Failed cleanup retains the exact owned profile path. A timeout cannot guarantee that an already-issued native operation stopped; the receipt explicitly preserves that limitation.

No personal profile, global OS preference, VoiceOver setting, physical hardware or authentication state is read or changed. No app is loaded, armed, installed or measured. No reduced-motion, focus-usability or screen-reader claim is made by this capability probe. The full EN/UK six-case source-shell/launcher matrix is deferred until actual native zoom capability succeeds.

## Verification

Fourteen mock/validator tests pass, including mismatched controls, unchanged metrics, CSS/pinch substitutes, unsupported routes, stalled timer-dispatch deadlines and pending-operation ownership. Three proposal files are formatted and linted using the repository configuration. Native execution is pending independent review and root approval. Add the new test to the normal observer test command only when integrating; this proposal does not change package.json or existing observers.
