import assert from 'node:assert/strict';
import { chromium } from '/Users/oleksandr.mekhovov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
import { setTimeout as pause } from 'node:timers/promises';
const folder = '/tmp/practice-active-session-proposal-20261016/';
const receipt = { format: 'OwnedPlainPageCDPWindowRouting.v1', authUsed: false, simulatorUsed: false,
  scope: 'Headless normal Chrome windows, no PWA or simulator qualification. Compare page-session versus browser-session Browser commands with actual bounded state and trusted events.',
  tests: [], cleanup: [] };
const bounded = async (work, limit = 5000) => {
  const end = performance.now() + limit;
  let timer;
  try {
    const value = await Promise.race([Promise.resolve().then(work), new Promise((_, reject) => { timer = setTimeout(() => reject(Error('Probe operation timed out')), limit); })]);
    assert(performance.now() < end, 'Late probe response'); return value;
  } finally { clearTimeout(timer); }
};
let browser, bs, sa, sb, a, b, aw, bw;
async function bounds(session, windowId) { return (await bounded(() => session.send('Browser.getWindowBounds', { windowId }))).bounds; }
async function waitState(session, windowId, expected, log, geometry) {
  const start = performance.now(), end = start + 1500;
  while (performance.now() < end) {
    const value = await bounded(() => session.send('Browser.getWindowBounds', { windowId }), end - performance.now());
    assert(performance.now() < end, 'State response arrived after 1500ms');
    log.push({ elapsedMs: performance.now() - start, bounds: value.bounds });
    if (value.bounds.windowState === expected && (!geometry || ['left', 'top', 'width', 'height'].every(k => value.bounds[k] === geometry[k]))) return true;
    await pause(Math.min(50, Math.max(1, end - performance.now())));
  }
  return false;
}
async function witness(page) { return bounded(() => page.evaluate(() => ({ focused: document.hasFocus(), visibility: document.visibilityState, events: globalThis.routingEvents.slice(-64) }))); }
async function restore(session, info) {
  const log = [];
  await bounded(() => session.send('Browser.setWindowBounds', { windowId: info.windowId, bounds: { windowState: 'normal' } }));
  assert(await waitState(session, info.windowId, 'normal', log));
  const { left, top, width, height } = info.bounds;
  await bounded(() => session.send('Browser.setWindowBounds', { windowId: info.windowId, bounds: { left, top, width, height } }));
  assert(await waitState(session, info.windowId, 'normal', log, info.bounds));
  return log;
}
try {
  browser = await bounded(() => chromium.connectOverCDP('ws://127.0.0.1:63866/devtools/browser/75ffc9e1-b7db-4b7b-88b5-76e8bde3dca5'));
  const context = browser.contexts()[0];
  a = context.pages().find(p => p.url().includes('Owned%20CDP%20route%20A'));
  assert(a, 'Owned probe A missing');
  bs = await bounded(() => browser.newBrowserCDPSession());
  sa = await bounded(() => context.newCDPSession(a));
  receipt.browser = await bounded(() => bs.send('Browser.getVersion'));
  const sourcePath = '/Users/oleksandr.mekhovov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright-core/lib/coreBundle.js';
  const source = await readFile(sourcePath);
  receipt.playwrightSource = { path: sourcePath, sha256: createHash('sha256').update(source).digest('hex'), startLine: 37392, endLine: 37400 };
  const ai = (await bounded(() => sa.send('Target.getTargetInfo'))).targetInfo;
  aw = await bounded(() => bs.send('Browser.getWindowForTarget', { targetId: ai.targetId }));
  assert.equal(aw.bounds.windowState, 'normal');
  receipt.a = { targetId: ai.targetId, ...aw };
  const created = await bounded(() => bs.send('Target.createTarget', { url: 'data:text/html,<title>Owned%20CDP%20route%20B</title><h1>Owned%20plain%20page%20B</h1><button>Focus%20B</button>', newWindow: true }));
  for (let i = 0; i < 30 && !b; i++) { b = context.pages().find(p => p.url().includes('Owned%20CDP%20route%20B')); if (!b) await pause(50); }
  assert(b, 'Owned probe B missing');
  sb = await bounded(() => context.newCDPSession(b));
  bw = await bounded(() => bs.send('Browser.getWindowForTarget', { targetId: created.targetId }));
  assert.equal(bw.bounds.windowState, 'normal'); assert.notEqual(aw.windowId, bw.windowId);
  receipt.b = { targetId: created.targetId, ...bw };
  receipt.focusConfiguration = { method: 'Emulation.setFocusEmulationEnabled', params: { enabled: false }, targets: [ai.targetId, created.targetId] };
  for (const [page, session] of [[a, sa], [b, sb]]) {
    await bounded(() => session.send('Emulation.setFocusEmulationEnabled', { enabled: false }));
    await bounded(() => page.evaluate(() => {
      globalThis.routingEvents = [];
      for (const name of ['focus', 'blur']) addEventListener(name, e => routingEvents.push({ name, trusted: e.isTrusted, at: performance.now(), focused: document.hasFocus(), visibility: document.visibilityState }));
      document.addEventListener('visibilitychange', e => routingEvents.push({ name: 'visibilitychange', trusted: e.isTrusted, at: performance.now(), focused: document.hasFocus(), visibility: document.visibilityState }));
    }));
  }
  // Cross-over repeats both routes without relaxing the production1500ms bound.
  for (const [name, session] of [['page', sa], ['browser', bs], ['page-repeat', sa], ['browser-repeat', bs]]) {
    const test = { route: name, samples: [], passed: false }; receipt.tests.push(test);
    try {
      test.restoredBefore = await restore(bs, aw);
      await bounded(() => a.bringToFront()); await pause(100);
      test.before = await witness(a); assert.equal(test.before.focused, true);
      await bounded(() => b.bringToFront());
      test.afterBForeground = await witness(a);
      test.eventStartCount = test.afterBForeground.events.length;
      await bounded(() => session.send('Browser.setWindowBounds', { windowId: aw.windowId, bounds: { windowState: 'minimized' } }));
      test.observedMinimized = await waitState(session, aw.windowId, 'minimized', test.samples);
      test.crossSessionBounds = await bounds(name.startsWith('page') ? bs : sa, aw.windowId);
      test.afterMinimize = await witness(a);
      test.trustedBlur = test.afterMinimize.events.slice(test.eventStartCount).some(e => e.name === 'blur' && e.trusted && !e.focused);
      test.passed = test.observedMinimized && test.crossSessionBounds.windowState === 'minimized' && test.trustedBlur && !test.afterMinimize.focused;
    } catch (error) { test.error = error.message; }
    finally {
      test.restore = await restore(bs, aw);
      await bounded(() => a.bringToFront());
      test.afterRestore = await witness(a);
    }
  }
  const screenshot = await bounded(() => a.screenshot({ timeout: 5000 }));
  const screenshotPath = folder + 'cdp-window-routing-probe.png';
  await writeFile(screenshotPath, screenshot);
  receipt.screenshot = { path: screenshotPath, bytes: screenshot.length, sha256: createHash('sha256').update(screenshot).digest('hex') };
} catch (error) { receipt.error = error.message; }
finally {
  for (const [name, work] of [
    ...(bs && aw ? [['restore A exact bounds', () => restore(bs, aw)]] : []),
    ...(bs && bw ? [['restore B exact bounds', () => restore(bs, bw)]] : []),
    ...(sa ? [['restore A default focus override', () => sa.send('Emulation.setFocusEmulationEnabled', { enabled: true })], ['detach A', () => sa.detach()]] : []),
    ...(sb ? [['restore B default focus override', () => sb.send('Emulation.setFocusEmulationEnabled', { enabled: true })], ['detach B', () => sb.detach()]] : []),
    ...(bs ? [['detach browser session', () => bs.detach()]] : []),
    ...(browser ? [['close owned browser', () => browser.close()]] : []),
  ]) {
    try { await bounded(work); receipt.cleanup.push({ name, passed: true }); }
    catch (error) { receipt.cleanup.push({ name, passed: false, error: error.message }); }
  }
  receipt.cleanupCompleted = receipt.cleanup.every(r => r.passed);
  receipt.scriptSha256 = createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex');
  await writeFile(folder + 'cdp-window-routing-probe.json', JSON.stringify(receipt, null, 2) + '\n');
}
console.log(JSON.stringify({ output: folder + 'cdp-window-routing-probe.json', browser: receipt.browser, error: receipt.error, tests: receipt.tests.map(t => ({ route: t.route, passed: t.passed, samples: t.samples.length, observedMinimized: t.observedMinimized, crossSessionBounds: t.crossSessionBounds, trustedBlur: t.trustedBlur, error: t.error })), cleanup: receipt.cleanup }, null, 2));
