# Historical active-session deadline correction

Apply only active-session-deadline-minimal.patch. The earlier active-session-deadline.patch is a superseded formatting-heavy intermediate, not the integration artifact.

Base: 11aa297825203fdd0dd4db075f5eaeb9aa34660e in the frozen flight-practice-publication worktree.

The existing bound helper now rejects a successful response that returns at or after its monotonic deadline, even when a synchronous stall prevented timer dispatch. It uses the existing error text and leaves the five-second operation ceiling, shared thirty-second session budget, 1.5-second focus-transfer budget, and independent one-second cleanup budget unchanged.

Document acquisition records the owned handle in its fulfillment before the post-await deadline guard. This allows independent cleanup to dispose a newly resolved handle even when the enclosing operation subsequently rejects as late. Existing pending-owned counters, late-disposal path, and conservative cleanup receipts remain in place.

Validation:

- Final isolated suite: 16/16 passed, no skips/failures (pass-after.tap).
- Original helper with the three new regression tests: 3 failures, 13 explicitly excluded tests (fail-before.tap). The original cleanup incorrectly reported completed:true after its one-second deadline.
- Scoped lint passes using the repository configuration and target filenames.
- git apply --check passes against the frozen worktree.

The tests deliberately block timer dispatch in synthetic Node fixtures. They do not qualify native browser timing, package behavior, active-flight learning, or any expanded app coverage. No application or checkout files were edited and no browser was started.
