# C9 run1: language-selection repair and failed-focus evidence

Temporary proposal against clean source `88867270621a9d59f8041056e2653d21421ad374`. No active checkout changes, browser launch, app/runtime change, deadline change, or acceptance-threshold change. The original failed receipt and images are untouched.

## Findings from the original receipt

`/tmp/practice-directory-native-a11y-20261016-run1/observation.json` contains two passed English cases (Academy/Worlds), one English Gym clipping failure, and three Ukrainian cases failing before entering the directory. Native zoom returned 100→200→100 with unchanged outer width1280, inner width1280→640→1280 and DPR2→4→2. Cleanup/source checks passed. These are software observations, not whole-feature accessibility qualification.

### Ukrainian: confirmed observer assumption

`game/i18n/bootstrap.mjs` selects the saved locale or browser languages (lines24–40), not the main page's `?lang=` query. The observer keeps one `en-US` Chrome profile across all six cases. Its query-only navigation therefore did not establish Ukrainian. The actual Home contains a `[data-language-control]` mount at `game/index.html:3222`; bootstrap creates its `[data-language-select]` and normal change listener at lines274–306.

The repair uses exactly `#shell-home[open] [data-language-select]`: require a unique visible control, read both document language and selected value, use ordinary `selectOption` only when necessary, await and verify both actual values. Each case records requested/before/controlBefore/action/after/controlAfter. There is no direct storage write, `setLocale` invocation, hidden handler, or browser-language substitution. A hidden/ambiguous/nonresponsive control fails normally.

### Gym: actual failed geometry missing; diagnosis remains open

The old observer asserted geometry before adding it to the receipt. Four focus records survive for English Gym: refresh, Play, Details and launcher `#check`. The next deterministic target is `#prepare`; no raw failing rectangle or launcher screenshot was retained. Its exact geometry cannot be reconstructed honestly.

The last recorded Gym `#check` is x32,y292.85546875,width220.7421875,height55.99609375 at inner viewport640×406,DPR4. Academy's passing `#prepare` is x32,y350.50390625,width576,height55.99609375 (bottom406.5). Worlds' passing equivalent ends406.40234375. The native metric page's visual height was406.5 while integer innerHeight was406. A fractional boundary/scroll timing issue is plausible, but neither a runtime defect nor a harmless rounding issue is proven for Gym.

The repair retains every reached focus witness **before** validation, initializes `passed:false`, records the failure string, then rethrows. Passing witnesses become `passed:true`. Additional read-only visualViewport width/height/offsets allow a later result to distinguish fractional viewport geometry from genuine clipping. The original integer viewport +0.5 bound is unchanged, as are all visibility, hit-testing, focus, outline, motion and overflow checks. No force focus, extra scroll, retry-to-pass or altered timing is introduced. The next native run may still fail; it should then retain the evidence needed for a product-versus-observer decision.

## Screenshots and limits

I viewed the original Gym directory page and Academy launcher focus PNGs. The former shows a cropped enlarged region; the latter is a blank strip. They reproduce the already documented native-zoom screenshot limitation and cannot establish the missing Gym target's visible bounds. No original screenshot is relabeled as visual readability proof. Screen-reader speech, physical devices, human readability and full production-build accessibility remain outside this protocol.

## Files, checks and application

`base/` retains the exact two original888 observer/test files. `scripts/` contains only their proposed repairs plus the unchanged existing zoom helper needed by the isolated unit suite. Apply `native-a11y-run1-repair.patch` only after the parent releases the frozen checkout. It changes only the observer and its test; this README is not a repository patch.

18/18 focused tests pass, including exact retained failing geometry, English→Ukrainian normal UI selection, matching-locale no-op, nonresponsive/ambiguous locale rejection, existing full mocked journey, cleanup ownership and absolute deadlines. Formatting/lint pass. No native result has been generated for these changes.
