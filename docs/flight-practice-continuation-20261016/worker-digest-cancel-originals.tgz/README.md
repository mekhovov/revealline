# Deferred digest completion cancellation — test-only proposal

Base inspected: 8c93b49ee7a18d01aadbe4b9d5ccf481addcfa74.
Patch: `digest-cancellation.patch`, SHA-256 `7f29cc992d51b8860ab148b830f79ded844927d189db4d9c97726e5c2240053e`.
Only proposed repository change: game/test/optional-offline-lifecycle.test.mjs.
No active checkout, application, worker, policy, build or browser changes.

Four cases cover both maintained worker families with delayed valid completion and injected delayed rejection. The ordinary fixture downloads two pinned dependencies. The first is staged; the second reaches the worker's actual verifying phase and awaits a wrapped digest promise. The wrapper computes the original Node WebCrypto SHA-256 and holds delivery of that unmodified result. The test sends practice-cancel through the installed worker message handler while the promise remains unresolved, checks that installation has not settled or announced ready, then releases completion in finally.

After settlement, installation must reject; the new partial cache must be removed; no additional cache.put calls or ready phase may occur. An existing previous-version cache under the same owner and an unrelated cache must retain exactly their names, entries, response status/headers and SHA-256 body fingerprints, including another event-loop turn after completion. No pointer/profile/browser-database preservation claim is made by this worker-only fixture.

This is deterministic unit/model coverage of an unresolved digest-return promise. It does NOT measure cancellation during actual native browser cryptographic computation, native UI input timing, process termination, or service-worker scheduling. The rejection case injects an error after a real digest completes; it is not a claim that WebCrypto actually rejected on this device. Existing native receipts remain unchanged.

Validation: isolated full lifecycle copy passed 46/46, zero failures/skips (`pass-after.tap`). The isolated copy rewrites existing relative imports to absolute source URLs solely for temporary execution; the repository patch contains no import changes. Configured Prettier and ESLint pass, and git apply --check passes.

Negative control: `mutant-lifecycle.test.mjs` is temporary and must NOT be applied. It reconstructs each serialized worker function in memory with only the post-digest/pre-write cancellation guard omitted. Both valid-result cases fail with two writes instead of one; the injected-rejection cases still pass. `mutant.tap`: 2 failures, 2 passes, 42 unrelated tests excluded. This establishes regression sensitivity to the intended late-write guard, not a production defect.

After integration run `node --test game/test/optional-offline-lifecycle.test.mjs` normally. No native rerun or qualification follows from these unit tests alone.
