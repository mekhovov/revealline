# Native zoom screenshot framing delta

The original successful capability receipt and source remain unchanged under `/tmp/practice-native-zoom-capability-20261016-run1` and `/tmp/practice-native-zoom-capability-proposal-20261016`; root retained its original authority archive separately.

This proposal changes only the screenshot framing after ordinary native 200% selection. It scrolls the native Page zoom select into view using ordinary browser automation, then reads actual bounding geometry and effective visibility. The screenshot is accepted only if the entire enabled selected control is within the current browser viewport and visibly rendered. No CSS, viewport, zoom, private browser API, or fixture metrics are changed. The CLI copy is byte-identical to the original.

15 focused tests pass, including clipping/hidden/zero-opacity rejection and proof that the scroll plus visible 200% control witness occur before screenshot capture. Native execution is pending root approval; old successful geometry evidence is not retroactively relabeled as visible-option screenshot evidence.
