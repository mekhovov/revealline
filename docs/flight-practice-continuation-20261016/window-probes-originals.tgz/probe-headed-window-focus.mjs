import { chromium } from '/Users/oleksandr.mekhovov/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import { writeFile } from 'node:fs/promises';
import { setTimeout as pause } from 'node:timers/promises';
const output = '/tmp/practice-active-session-proposal-20261016/headed-window-focus-probe.json';
let timer;
const bounded = (work) => Promise.race([work(), new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Probe operation exceeded 5 seconds')),5000);})]).finally(()=>clearTimeout(timer));
const browser = await chromium.connectOverCDP('ws://127.0.0.1:65011/devtools/browser/5222f970-2d8a-4771-99d7-3e1294e35bf8');
const context = browser.contexts()[0];
const a = context.pages().find((page)=>page.url().startsWith('data:text/html,'));
if (!a) throw Error('Owned plain probe A missing');
const browserSession = await browser.newBrowserCDPSession();
const aSession = await context.newCDPSession(a);
const { targetInfo:aInfo } = await aSession.send('Target.getTargetInfo');
const aWindow = await browserSession.send('Browser.getWindowForTarget',{targetId:aInfo.targetId});
const receipt = {format:'IsolatedHeadedChromeWindowFocusProbe.v1',authUsed:false,simulatorUsed:false,
  profile:'/tmp/practice-headed-focus-20261016.ED1xZh',headed:true,browser:await browserSession.send('Browser.getVersion'),aWindow,steps:[],limitations:['Plain-page headed desktop-software window diagnostic, not historical simulator/PWA or physical-device qualification.']};
let b;
try {
  await a.evaluate(()=>{
    globalThis.focusProbeEvents=[];
    for(const name of ['focus','blur']) globalThis.addEventListener(name,(event)=>globalThis.focusProbeEvents.push({name,trusted:event.isTrusted,focused:document.hasFocus(),visibility:document.visibilityState}));
    document.addEventListener('visibilitychange',(event)=>globalThis.focusProbeEvents.push({name:'visibilitychange',trusted:event.isTrusted,focused:document.hasFocus(),visibility:document.visibilityState}));
  });
  const read = async (label) => {
    await pause(200);
    receipt.steps.push({label,a:await bounded(()=>a.evaluate(()=>({focused:document.hasFocus(),visibility:document.visibilityState,events:globalThis.focusProbeEvents.slice(-20)}))),aBounds:await browserSession.send('Browser.getWindowBounds',{windowId:aWindow.windowId}),...(b?{b:await bounded(()=>b.evaluate(()=>({focused:document.hasFocus(),visibility:document.visibilityState})))}:{})});
  };
  await bounded(()=>a.bringToFront());
  await read('A foreground before new window');
  const created=await browserSession.send('Target.createTarget',{url:'data:text/html,<title>Isolated focus probe B</title><h1>Focus probe B</h1><button>Focus B</button>',newWindow:true});
  for(let i=0;i<20&&!b;i++){
    for(const page of context.pages()) if(page!==a&&page.url().includes('focus%20probe%20B')) b=page;
    if(!b) b=context.pages().find((page)=>page!==a&&page.url().startsWith('data:text/html,'));
    if(!b) await pause(50);
  }
  if(!b) throw Error('Owned plain probe B missing');
  receipt.bWindow=await browserSession.send('Browser.getWindowForTarget',{targetId:created.targetId});
  await bounded(()=>a.bringToFront());
  await read('A foreground with B separate window');
  await bounded(()=>b.bringToFront());
  await read('B bringToFront separate window');
  await browserSession.send('Browser.setWindowBounds',{windowId:aWindow.windowId,bounds:{windowState:'minimized'}});
  await read('A minimized via native Browser.setWindowBounds');
  await browserSession.send('Browser.setWindowBounds',{windowId:aWindow.windowId,bounds:{windowState:'normal'}});
  await bounded(()=>a.bringToFront());
  await read('A restored normal and foreground');
  await a.screenshot({path:'/tmp/practice-active-session-proposal-20261016/headed-window-focus-probe-a.png',timeout:5000});
} catch(error) {receipt.error=error.message;}
finally {
  receipt.cleanup=[];
  for(const [name,work] of [['restore owned A bounds',()=>browserSession.send('Browser.setWindowBounds',{windowId:aWindow.windowId,bounds:{windowState:'normal'}})],['close owned browser',()=>browser.close()]]){
    try {await bounded(work);receipt.cleanup.push({name,passed:true});}catch(error){receipt.cleanup.push({name,passed:false,error:error.message});}
  }
  await writeFile(output,JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({output,error:receipt.error,steps:receipt.steps.map(({label,a,aBounds,b})=>({label,a:{focused:a.focused,visibility:a.visibility,events:a.events},aBounds,b})),cleanup:receipt.cleanup},null,2));

