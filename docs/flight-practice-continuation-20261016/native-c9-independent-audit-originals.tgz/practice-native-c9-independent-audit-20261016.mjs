import assert from 'node:assert/strict';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const repo = '/Users/oleksandr.mekhovov/.codex/worktrees/flight-practice-publication/go_test';
const source = '8c93b49ee7a18d01aadbe4b9d5ccf481addcfa74';
const tree = '06e9faf7b167a9ba547bfe610920a02d60a925d0';
const reportPath = '/tmp/practice-native-a11y-8c93-20261016-run1/observation.json';
const planPath = '/tmp/practice-native-a11y-8c93-20261016-plan.json';
const output = '/tmp/practice-native-c9-independent-audit-20261016.json';
const archive = '/tmp/practice-native-8c93-authority-20261016.tgz';
const originals = '/tmp/practice-native-c9-8c93-passed-originals-20261016.tgz';
const sha = (b) => createHash('sha256').update(b).digest('hex');
const pin = (p, b) => ({ path: p, bytes: b.length, sha256: sha(b) });
const git = (...args) => execFileSync('git', ['-C', repo, ...args], { maxBuffer: 128 * 1024 * 1024, timeout: 30000 });
const blob = (p) => git('show', `${source}:${p}`);
const audit = { format: 'IndependentNativeC9Audit.v1', passed: false, source, tree, checks: [], limitations: [
  'Independent read-only receipt and byte audit; no new browser execution.',
  'Half-device-pixel border-box policy is approximate containment, not zero clipping or a complete painted-outline measurement.',
  'PNG hashes/dimensions verified only; no image is visually qualified. Native zoom capture may crop or omit pixels.',
  'No human readability, screen-reader speech, physical keyboard/controller/touch, OS reduced-motion, production-distribution or hosting qualification.',
  'Admission and overlay reproduction reuse the pinned maintained admission implementation; geometry and request classification are recomputed independently here.',
] };
const check = async (name, fn) => { const result = await fn(); audit.checks.push({ name, passed: true, ...(result ? { result } : {}) }); };
const within = (a, b, e = 1e-9) => assert(Math.abs(a - b) <= e, `${a} != ${b}`);
let reportBytes;
try {
  await assert.rejects(stat(output), { code: 'ENOENT' });
  reportBytes = await readFile(reportPath);
  assert(reportBytes.length < 2 * 1024 * 1024 && reportBytes.at(-1) === 10);
  const r = JSON.parse(reportBytes), planBytes = await readFile(planPath), p = JSON.parse(planBytes);
  audit.report = pin(reportPath, reportBytes);
  audit.plan = pin(planPath, planBytes);
  await check('Exact completed protocol, source and plan identities', () => {
    assert.equal(r.passed, true);
    assert.equal(r.protocol.id, 'practice-directory-native-zoom-a11y.v3');
    assert.equal(r.sourceShellOnly, true); assert.equal(r.productionQualification, false);
    assert.equal(r.qualified, false); assert.equal(r.publicEligible, false);
    assert.deepEqual(r.plan, p); assert.equal(p.shellRevision, source); assert.equal(p.shellTree, tree);
    assert.equal(git('rev-parse', `${source}^{tree}`).toString().trim(), tree);
    assert.equal(p.sourceRevision, '1b339bfe6596290b6db17ae0e268e4c8a843071a');
    assert.equal(p.sourceTree, '08e5a779523e8e356cccc9c45b96340676c1c56d');
    assert.equal(p.envelopeSha256, 'f559fdd7a935f03f15481fe657fbee3eb4b52e3c0c4b48d0bd3c9f70bedab7eb');
    assert.equal(p.packageRevision, 'bf6f874534664b4c347852a88c676fbdab4dfc9ea148a9e764722a445fe771d9');
  });
  await check('Original archive pins and exact Git-bound executable authority', async () => {
    const bytes = await readFile(archive), saved = await readFile(originals);
    assert.equal(sha(bytes), '18170fe2303c958cafcdaec66cc404349d39681143932d58d92c20c97f50706e');
    assert.equal(sha(saved), '75292e0d0a848f50eb4f3ed674dbda3e2394fed0e5646486a304aa4ec8db023d');
    audit.authorityArchive = pin(archive, bytes); audit.originalsArchive = pin(originals, saved);
    const rows = [...r.authority, { ...r.observer, path: `scripts/${r.observer.path}` }, { ...r.zoomHelper, path: `scripts/${r.zoomHelper.path}` }];
    assert.equal(new Set(rows.map(x => x.path)).size, rows.length);
    for (const row of rows) {
      const b = blob(row.path); assert.deepEqual(pin(row.path, b), row);
      if (row.path.startsWith('scripts/')) {
        const archived = execFileSync('tar', ['-xOf', archive, row.path], { maxBuffer: 4 * 1024 * 1024, timeout: 10000 });
        assert.equal(sha(archived), row.sha256);
      }
    }
    return { entries: rows.length, archiveScope: 'All report script authorities compared with archive and Git; publishing authorities compared with immutable Git.' };
  });
  await check('Every recorded served source matches immutable Git bytes', () => {
    assert(r.servedSources.length > 100 && r.servedSources.length < 5000);
    assert.equal(new Set(r.servedSources.map(x => x.path)).size, r.servedSources.length);
    // One bounded git batch avoids repeated process launches without reading the whole repository.
    const input = r.servedSources.map(x => `${source}:${x.path}\n`).join('');
    const bytes = execFileSync('git', ['-C', repo, 'cat-file', '--batch'], { input, maxBuffer: 128 * 1024 * 1024, timeout: 30000 });
    let offset = 0, total = 0;
    for (const row of r.servedSources) {
      const end = bytes.indexOf(10, offset), header = bytes.subarray(offset, end).toString();
      assert.match(header, /^[0-9a-f]{40} blob [0-9]+$/);
      const size = Number(header.split(' ')[2]); offset = end + 1;
      const b = bytes.subarray(offset, offset + size); assert.deepEqual(pin(row.path, b), row);
      assert.equal(bytes[offset + size], 10); offset += size + 1; total += size;
    }
    assert.equal(offset, bytes.length);
    return { files: r.servedSources.length, bytes: total };
  });
  await check('Re-admission of original three packages and reproduction of every overlay member', async () => {
    // Current local helper must equal the frozen Git authority before and after import/use.
    const helper = 'scripts/observe-practice-directory-journey.mjs';
    for (const row of r.authority) assert.equal(sha(await readFile(path.join(repo, row.path))), row.sha256);
    const { directoryJourneyOverlay } = await import(pathToFileURL(path.join(repo, helper)));
    const overlay = await directoryJourneyOverlay(p);
    assert.deepEqual(overlay.loaded.binding, r.artifact); assert.deepEqual(overlay.loaded.admission, r.admission);
    assert.deepEqual([...overlay.files].map(([name, bytes]) => pin(name, bytes)), r.overlay);
    assert.equal(r.admission.zipMembersVerified, true); assert.equal(r.admission.publicEligible, false);
    assert.deepEqual(r.admission.packages.map(x => x.id), ['civilian-flight', 'civilian-fpv', 'fpv-worlds']);
    for (const row of r.authority) assert.equal(sha(await readFile(path.join(repo, row.path))), row.sha256);
    return { packages: r.admission.packages, overlayFiles: r.overlay.length, selectedArtifact: r.artifact.package.revision };
  });
  await check('Native zoom100→200→100 from recorded control and independent metrics', () => {
    assert.deepEqual(r.zoomSteps.map(x => x.requested), ['1', '2', '1']);
    const [a,b,c] = r.zoomSteps.map(x => x.metrics);
    for (const step of r.zoomSteps) {
      assert.equal(step.control.value, step.requested);
      assert(step.control.options.some(x => x.value === step.requested && !x.disabled));
      assert.equal(step.metrics.visualScale, 1); assert.equal(step.metrics.markerWidth, 200);
      for (const css of step.metrics.css) { assert.equal(css.zoom, '1'); assert.equal(css.transform, 'none'); }
      assert.equal(step.metrics.outerWidth, a.outerWidth); assert.equal(step.metrics.outerHeight, a.outerHeight);
    }
    within(a.innerWidth / b.innerWidth, 2); within(b.dpr / a.dpr, 2); within(a.visualHeight / b.visualHeight, 2);
    assert.deepEqual(a,c); assert.equal(r.zoomVerified, true); assert.equal(r.zoomResetVerified, true);
    audit.browser = r.browser;
    return r.zoomSteps.map(x => ({ requested: x.requested, metrics: x.metrics }));
  });
  await check('All six EN/UK journeys, all focus geometry and actual main-return locale', () => {
    const expected = ['en','uk'].flatMap(l => ['civilian-flight','civilian-fpv','fpv-worlds'].map(id => `${l}-${id}`));
    assert.deepEqual(r.cases.map(x => x.id), expected);
    let count=0, tolerances=0, legacyFalse=0, maximum=0;
    const residuals=[];
    for (const c of r.cases) {
      assert.equal(c.passed,true); assert.equal(c.failure,undefined); assert.deepEqual(c.errors,[]);
      assert.equal(c.mainReturnLocale,c.locale); assert.equal(c.mainLocaleSelection.after,c.locale);
      assert.equal(c.guideAndReturn,true); assert.equal(c.escapeFocus,'shell-home-practice');
      for(const s of [c.directoryStatus,c.launcherStatus]) assert.deepEqual(s,{role:'status',live:'polite',spoken:false});
      const u=new URL(c.playLink.href); assert.equal(u.pathname,`/revealline/practice/${c.package}/app/`); assert.equal(u.searchParams.get('lang'),c.locale); assert.equal(u.searchParams.get('action'),'play');
      assert.equal(c.focus.length,10);
      const all=[...c.focus, {...c.escapeFocusWitness,geometry:c.escapeFocusGeometry}];
      for(const w of all) {
        count++; assert(w.active && w.focusVisible && w.visible && w.centerHit && w.reducedMotion);
        assert(w.text); assert.equal(w.failure,undefined);
        if(Object.hasOwn(w,'passed')) assert.equal(w.passed,true);
        const v=w.viewport, q=w.rect;
        for(const val of [q.x,q.y,q.width,q.height,v.visualWidth,v.visualHeight,v.dpr]) assert(Number.isFinite(val));
        assert(q.x>=0 && q.y>=0 && q.width>0 && q.height>0);
        assert.equal(v.visualScale,1); assert.equal(v.visualOffsetLeft,0); assert.equal(v.visualOffsetTop,0);
        assert.equal(v.dpr,r.zoomSteps[1].metrics.dpr); assert(v.dpr>=1);
        assert(Math.abs(v.visualWidth-v.width)<1 && Math.abs(v.visualHeight-v.height)<1);
        assert.equal(v.outerWidth,r.zoomSteps[1].metrics.outerWidth); assert.equal(v.width,r.zoomSteps[1].metrics.innerWidth);
        const right=Math.max(0,q.x+q.width-v.visualWidth), bottom=Math.max(0,q.y+q.height-v.visualHeight);
        const rd=right*v.dpr, bd=bottom*v.dpr, legacy=q.x+q.width<=v.width+0.5 && q.y+q.height<=v.height+0.5;
        assert(rd<0.5-1e-9 && bd<0.5-1e-9);
        assert.deepEqual(w.geometry,{policy:'visual-viewport-half-device-pixel.v1',allowanceCss:0.5/v.dpr,rightOverflowCss:right,bottomOverflowCss:bottom,rightOverflowDevicePixels:rd,bottomOverflowDevicePixels:bd,legacyIntegerBoundsPassed:legacy,toleranceUsed:right>0||bottom>0,withinPrecision:true});
        assert(parseFloat(w.outline.width)>0 && !['none','hidden'].includes(w.outline.style));
        assert(!['transparent','rgba(0, 0, 0, 0)'].includes(w.outline.color));
        assert.equal(w.motion.animationName,'none'); assert(w.motion.transitionDuration.split(',').every(x=>parseFloat(x)===0));
        assert(w.documentWidth<=v.width+1);
        if(right>0||bottom>0){tolerances++;residuals.push({case:c.id,id:w.id,rightDevicePixels:rd,bottomDevicePixels:bd});}
        if(!legacy)legacyFalse++; maximum=Math.max(maximum,rd,bd);
      }
    }
    assert.equal(count,66);
    return { witnesses:count,toleranceUsed:tolerances,legacyFalse,maximumOverflowDevicePixels:maximum,residuals };
  });
  await check('Every raw request has exact final source-only classification', () => {
    assert.equal(git('ls-tree',source,'game/build-info.json').length,0);
    assert(r.requestFailures.length<100);
    let builds=0,icons=0; const expected=[],unexpected=[];
    r.requestFailures.forEach((row,index)=>{
      let reason;
      if(row.path==='/revealline/game/build-info.json' && row.message==='Not a committed regular file.' && ++builds<=12)reason='Absent generated release identity in committed source preview';
      else if(row.path==='/favicon.ico' && row.message==='Outside local fixture root.' && ++icons<=12)reason='Browser default icon probe outside fixture root';
      (reason?expected:unexpected).push({index,...row,...(reason?{reason}:{})});
    });
    assert.deepEqual(r.requestClassification,{policy:'bounded-source-preview-probes.v1',sourceShellOnly:true,productionQualification:false,buildInfoAbsent:true,expected,unexpected});
    assert.equal(unexpected.length,0);
    return { rawFailures:r.requestFailures.length,buildIdentityProbes:builds,iconProbes:icons,unexpected:0,rawPreserved:true };
  });
  await check('Complete cleanup, removed owned profile, stable source and explicit limits', async () => {
    assert.equal(r.sourceStable,true); assert.equal(r.pendingOperations,0); assert.equal(r.profileRemoved,true);
    assert(r.cleanup.length>0 && r.cleanup.every(x=>x.closed));
    assert(r.resources.every(x=>!x.pending && (!x.acquired || x.closed)));
    assert(path.basename(r.profilePath).startsWith('practice-native-a11y-'));
    await assert.rejects(stat(r.profilePath),{code:'ENOENT'});
    assert(r.limitations.some(x=>/not literal zero clipping/.test(x)));
    assert(r.limitations.some(x=>/screen-reader/.test(x)));
    assert(r.limitations.some(x=>/screenshots can be cropped/.test(x)));
  });
  await check('Every original PNG byte/hash/dimension retained as visually unreviewed', async () => {
    const images=r.cases.flatMap(c=>c.screenshots); assert.equal(images.length,18);
    assert.equal(new Set(images.map(x=>x.path)).size,18);
    for(const row of images){
      assert.equal(path.basename(row.path),row.path);
      const bytes=await readFile(path.join(path.dirname(reportPath),row.path));
      assert.equal(bytes.length,row.bytes); assert.equal(sha(bytes),row.sha256);
      assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
      assert.equal(bytes.readUInt32BE(16),row.pixelWidth); assert.equal(bytes.readUInt32BE(20),row.pixelHeight);
      assert.equal(row.visuallyReviewed,false);
    }
    audit.images=images; return {images:images.length,visuallyQualified:0};
  });
  assert.equal(sha(await readFile(reportPath)),audit.report.sha256);
  assert.equal(sha(await readFile(planPath)),audit.plan.sha256);
  audit.passed=true;
} catch(error) { audit.error=error.stack; }
audit.auditScript=pin('/tmp/practice-native-c9-independent-audit-20261016.mjs',await readFile('/tmp/practice-native-c9-independent-audit-20261016.mjs'));
await writeFile(output,JSON.stringify(audit,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({passed:audit.passed,output,checks:audit.checks.length,error:audit.error}));
process.exitCode=audit.passed?0:1;
