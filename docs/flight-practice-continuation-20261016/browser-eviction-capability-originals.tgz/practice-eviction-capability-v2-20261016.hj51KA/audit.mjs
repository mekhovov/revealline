import assert from 'node:assert/strict';
import { readFile, writeFile, access } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
const exec = promisify(execFile);
const dir = '/tmp/practice-eviction-capability-v2-20261016.hj51KA';
const sha = b => createHash('sha256').update(b).digest('hex');
const bytes = await readFile(dir + '/observation.json');
assert.equal(sha(bytes), '4902eb57abb08d32de4ec45793d511ab188debd2de960d58ccae6cf5ce086664');
const r = JSON.parse(bytes);
assert.equal(r.format, 'IsolatedBrowserEvictionCapability.v2');
assert.equal(r.completed, true);
assert.equal(r.qualified, false);
assert.equal(r.binaryVersion, 'Google Chrome 155.0.8059.80');
assert.equal(r.numericCounterBaselineAvailable, false);
assert.equal(r.eviction.numericCounterDeltaObserved, false);
assert.equal(r.eviction.browserManagedEvictionObserved, true);
assert.equal(r.eviction.counter, 1);
assert.equal(r.eviction.rounds, 1);
assert(r.elapsedMs < 480000);
assert(r.eviction.atMs - r.reducedRestartAtMs >= 295000);
assert.equal(r.seed.bytes, 1048576);
assert.equal(r.seed.persisted, false);
assert.equal(r.persistedAfterRestart.found, true);
assert.equal(r.persistedAfterRestart.bytes, r.seed.bytes);
assert.equal(r.persistedAfterRestart.sha256, r.seed.sha256);
assert.deepEqual(r.persistedAfterRestart.keys, ['owned-eviction-1m-v1']);
assert.equal(r.beforeEviction.pool, '512.00 KB');
assert.equal(r.beforeEviction.evicted, '');
assert.equal(r.beforeEviction.rounds, '');
assert(r.beforeEviction.rows.some(row => row[0] === r.origin + '/' && row[1] === '_default' && row[2] === '1.00 MB'));
const last = r.samples.at(-1);
assert.equal(last.evicted, '1');
assert.equal(last.rounds, '1');
assert.equal(last.pool, '512.00 KB');
assert(!last.rows.some(row => row[0] === r.origin + '/'));
assert.equal(last.rows.length, 1);
assert(last.rows[0][0].startsWith('chrome-extension://'));
assert.deepEqual(r.after.keys, []);
assert.equal(r.after.persisted, false);
assert.deepEqual(r.cleanup.errors, []);
assert.deepEqual(r.cleanup.remainingOwnedProcesses, []);
assert.equal(r.cleanup.completed, true);
assert.equal(r.cleanup.profileRemoved, true);
await assert.rejects(access(dir + '/profile'), { code: 'ENOENT' });
for (const item of r.source) assert.equal(sha(await readFile(dir + '/' + item.file)), item.sha256);
assert.equal(sha(await readFile(dir + '/probe.mjs')), r.probeSha256);
assert.equal(r.probeSha256, '671f02141d418d5adf2a62085b4737cb923dbad3532b06fdf2be1ebea5866477');
assert(r.operations.every(op => op.pending === false && !op.failed && op.elapsedMs < 10000));
assert.equal(r.operations.filter(op => op.args[0] === 'click').length, 1);
assert.deepEqual(r.operations.find(op => op.args[0] === 'click').args, ['click', '#seed']);
assert(!r.operations.some(op => op.args.some(arg => /simulateStoragePressure|trigger-notification|clearDataForOrigin|Storage\.delete|caches\.delete|indexedDB\.deleteDatabase/.test(arg))));
const processes = (await exec('ps', ['-axo', 'pid,ppid,args'], { timeout: 5000, maxBuffer: 4000000 })).stdout;
assert(!processes.split('\n').some(line => line.includes('/Applications/Google Chrome') && line.includes(dir + '/profile')));
const images = [];
for (const name of ['effective-pool-version.png', 'before-quota.png', 'after-quota.png']) {
  const b = await readFile(dir + '/' + name);
  assert(b.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10])));
  images.push({ name, bytes: b.length, sha256: sha(b) });
}
const prior = [];
for (const path of ['/tmp/practice-eviction-capability-20261016.denCir/observation.json', '/tmp/practice-eviction-capability-20261016-retry.SW3sE2/observation.json']) {
  const b = await readFile(path); assert.equal(JSON.parse(b).completed, false); prior.push({ path, sha256: sha(b), retainedAs: 'inconclusive' });
}
const out = {
  format: 'IsolatedBrowserEvictionCapabilityAudit.v2',
  passed: true,
  claim: 'Fresh owned headless Chrome profile performed browser-managed eviction under an explicitly reduced temporary storage pool, with unchanged native startup timer.',
  notQualified: ['App eviction recovery', 'Default-policy or physical disk-pressure eviction', 'Observed numeric counter delta', 'Persistent-storage or installed-app eviction policy', 'Hardware behavior'],
  receipt: { path: dir + '/observation.json', sha256: sha(bytes) },
  protocol: { path: dir + '/probe.mjs', sha256: r.probeSha256 },
  browserVersion: r.binaryVersion,
  sourceBinding: 'Public source tag matches reported installed Chrome version; not a whole-framework binary attestation.',
  sources: r.source,
  fixture: { origin: r.origin, bytes: r.seed.bytes, sha256: r.seed.sha256, cacheHashVerifiedAfterRestart: true },
  evidence: { beforeCounter: 'unavailable (evictor not yet constructed)', afterCounter: 1, afterRounds: 1, exactBucketRemoved: true, originalCacheAbsent: true, defaultComponentExtensionBucketRetained: true, effectivePool: '512.00 KB', firstEvictionAtMs: r.eviction.atMs, elapsedMs: r.elapsedMs, cleanupCompleted: true, ownedProcessAbsenceRechecked: true },
  images,
  visualReview: 'after-quota.png was inspected: shows pool512.00KB, evicted buckets1, eviction rounds1, errors0. Bucket disappearance is verified from the recorded exact usage-table DOM rows, not claimed visible in the Summary screenshot.',
  prior,
  reuse: 'Feasible narrow capability recipe. Before integrating into an app recovery observer, obtain review of the explicit controlled-policy scope and independently verify public recovery from genuine origin-wide loss; do not relabel cache-entry deletion/quota-denial receipts or promise record retention.'
};
await writeFile(dir + '/audit.json', JSON.stringify(out, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ audit: dir + '/audit.json', passed: out.passed, sha256: sha(await readFile(dir + '/audit.json')), images }));
