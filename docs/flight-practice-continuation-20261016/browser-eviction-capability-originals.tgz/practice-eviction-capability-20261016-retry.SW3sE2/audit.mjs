import assert from 'node:assert/strict';
import { readFile, writeFile, access } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
const exec = promisify(execFile);
const dir = '/tmp/practice-eviction-capability-20261016-retry.SW3sE2';
const first = '/tmp/practice-eviction-capability-20261016.denCir';
const sha = value => createHash('sha256').update(value).digest('hex');
const currentBytes = await readFile(dir + '/observation.json');
const r = JSON.parse(currentBytes);
assert.equal(r.completed, false);
assert.equal(r.cleanup.completed, true);
assert.equal(r.seed.bytes, 1048576);
assert.equal(r.seed.persisted, false);
assert.equal(r.flagPreflight.pool, '512.00 KB');
assert.equal(r.samples.at(-1).pool, '512.00 KB');
assert(r.before.rows.some(row => row[0] === r.origin + '/' && row[1] === '_default'));
assert(r.samples.at(-1).rows.some(row => row[0] === r.origin + '/' && row[1] === '_default'));
assert(r.samples.every(sample => sample.evicted === '' && sample.rounds === ''));
await assert.rejects(access(dir + '/profile'), { code: 'ENOENT' });
const source = [];
for (const path of ['storage/browser/quota/quota_manager_impl.h', 'storage/browser/quota/quota_manager_impl.cc', 'content/browser/resources/quota/quota_internals.ts']) {
  const url = 'https://chromium.googlesource.com/chromium/src/+/refs/tags/155.0.8059.80/' + path + '?format=TEXT';
  const at = performance.now();
  const raw = await exec('curl', ['--fail', '--silent', '--show-error', '--max-time', '12', url], { timeout: 13000, maxBuffer: 1000000 });
  assert(performance.now() - at < 13000);
  const bytes = Buffer.from(raw.stdout, 'base64');
  const file = path.split('/').at(-1);
  await writeFile(dir + '/' + file, bytes, { flag: 'wx' });
  source.push({ url, file, bytes: bytes.length, sha256: sha(bytes) });
}
const header = await readFile(dir + '/quota_manager_impl.h', 'utf8');
assert.match(header, /kMinutesAfterStartupToBeginEviction\s*=\s*base::Minutes\(5\)/);
assert.match(header, /kEvictionInterval\s*=\s*base::Minutes\(30\)/);
const manager = await readFile(dir + '/quota_manager_impl.cc', 'utf8');
assert.match(manager, /if \(temporary_storage_evictor_\)\s*\{/);
assert.match(manager, /PostDelayedTask\([\s\S]{0,300}kMinutesAfterStartupToBeginEviction/);
const processes = (await exec('ps', ['-axo', 'pid,ppid,args'], { timeout: 5000, maxBuffer: 4000000 })).stdout;
const ownedBrowserLines = processes.split('\n').filter(line => line.includes('/Applications/Google Chrome') && line.includes(dir + '/profile'));
assert.equal(ownedBrowserLines.length, 0);
const audit = {
  format: 'IsolatedBrowserEvictionCapabilityAudit.v1',
  status: 'inconclusive', evictionObserved: false, appRecoveryQualified: false,
  browserVersion: r.binaryVersion,
  sourceBinding: 'Exact public Chromium source tag matching installed reported Chrome version; not an attestation of the entire Chrome framework binary.',
  source,
  firstAttempt: { path: first + '/observation.json', sha256: sha(await readFile(first + '/observation.json')), outcome: 'Stopped before fixture creation on exact display-format mismatch; original retained.' },
  retry: { path: dir + '/observation.json', sha256: sha(currentBytes), probeSha256: r.probeSha256, elapsedMs: r.elapsedMs, samples: r.samples.length },
  fixture: { origin: r.origin, bytes: r.seed.bytes, sha256: r.seed.sha256, persisted: false, exactBucketPresentBeforeAndAfter: true },
  observed: { normalPool: r.normalBaseline.pool, reducedPool: r.samples.at(-1).pool, evictionCounters: 'Blank throughout, not interpreted as zero.', ownedBrowserProcessesAfterCleanup: ownedBrowserLines.length, cleanupCompleted: r.cleanup.completed },
  explanation: 'The exact version schedules normal eviction five minutes after database initialization. This exceeds the approved five-minute whole-run budget once setup/cleanup are included; the probe did not trigger or fake an eviction.',
  implementationReadiness: 'Not reusable acceptance evidence yet. Future approved implementation must preflight the startup delay, observe an actual numeric counter baseline and later increase within one browser lifetime, and corroborate exact bucket removal. The current prototype positive-counter predicate alone is not sufficient for that stricter reusable contract.',
  limitations: ['No app or authenticated origin was opened.', 'No delete/clear-storage or simulated pressure operation was used.', 'Only the newly created owned profile was removed after browser close; original receipts and source copies remain.', 'No disk-filling or natural/default-policy eviction claim.', 'No further browser run is authorized by this audit.']
};
await writeFile(dir + '/audit.json', JSON.stringify(audit, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ status: audit.status, audit: dir + '/audit.json', sha256: sha(await readFile(dir + '/audit.json')), source }));
