/** Original-built-byte subset delivery comparison. Never production qualification. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { createReadStream } from 'node:fs';
import { readFile, realpath, stat, mkdir, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { performance } from 'node:perf_hooks';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { setTimeout as pause } from 'node:timers/promises';

const sha = (value) => createHash('sha256').update(value).digest('hex');
export const STARTUP_POLICY = Object.freeze({
  protocol: 'practice-production-home-delivery-diagnostic.v1',
  homeMs: 10000,
  caseMs: 45000,
  browserMs: 100000,
  subsetMs: 120000,
  cacheBytes: 128 * 1024 * 1024,
  maxMembers: 1000,
  maxRequests: 5000,
  locale: 'en',
  modes: ['file', 'memory'],
});
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.mjs': 'text/javascript',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.m4a': 'audio/mp4',
  '.wav': 'audio/wav',
  '.webmanifest': 'application/manifest+json',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.mp3': 'audio/mpeg',
  '.ogg': 'audio/ogg',
  '.ttf': 'font/ttf',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/plain; charset=utf-8',
  '.zip': 'application/zip',
};
export function validateStartupPlan(plan) {
  assert.deepEqual(
    Object.keys(plan).sort(),
    [
      'format',
      'repository',
      'observerRevision',
      'observerTree',
      'previousReceipt',
      'previousReceiptSha256',
    ].sort(),
  );
  assert.equal(plan.format, 'revealline-production-home-delivery-plan.v1');
  for (const key of ['repository', 'previousReceipt'])
    assert(
      typeof plan[key] === 'string' &&
        path.isAbsolute(plan[key]) &&
        plan[key].length < 4096 &&
        path.resolve(plan[key]) === plan[key],
    );
  for (const key of ['observerRevision', 'observerTree']) assert.match(plan[key], /^[a-f0-9]{40}$/);
  assert.match(plan.previousReceiptSha256, /^[a-f0-9]{64}$/);
  return plan;
}
function safeMember(name) {
  assert(
    typeof name === 'string' &&
      name.length <= 1024 &&
      !/[\\\x00-\x20%?#:]/.test(name) &&
      !name.startsWith('/') &&
      name.split('/').every((s) => s && !s.startsWith('.')),
  );
}
export function validateStartupSubset(prior, manifest) {
  assert.equal(prior.format, 'PracticeDirectoryProductionPersonalAppearanceObservation.v2');
  assert.equal(prior.completed, false);
  assert.equal(prior.plan.protocol, 'practice-directory-production-personal-appearance.v2');
  assert.equal(prior.distribution.originalsVerifiedBefore, true);
  assert.equal(prior.distribution.originalsVerifiedAfter, true);
  assert.equal(manifest.sourceRevision, prior.plan.shellRevision);
  assert.equal(manifest.entry, 'game/index.html');
  assert.equal(manifest.formatVersion, 1);
  assert.deepEqual(manifest.files, prior.distribution.originalFiles);
  const all = new Map();
  let total = 0;
  assert(manifest.files.length <= 20000);
  for (const row of manifest.files) {
    safeMember(row.path);
    assert(!all.has(row.path));
    assert.deepEqual(Object.keys(row).sort(), ['bytes', 'path', 'sha256']);
    assert(Number.isSafeInteger(row.bytes) && row.bytes >= 0 && row.bytes <= 128 * 1024 * 1024);
    assert.match(row.sha256, /^[a-f0-9]{64}$/);
    all.set(row.path, row);
    total += row.bytes;
  }
  assert.equal(total, manifest.totalBytes);
  assert(total <= 2 * 1024 ** 3);
  const selected = prior.servedDistribution;
  assert(
    Array.isArray(selected) && selected.length > 0 && selected.length <= STARTUP_POLICY.maxMembers,
  );
  assert.equal(new Set(selected.map((row) => row.path)).size, selected.length);
  for (const row of selected)
    assert.deepEqual(
      row,
      all.get(row.path),
      'Every prefetched member must exactly match original manifest.',
    );
  assert(selected.some((row) => row.path === 'game/index.html'));
  assert(selected.reduce((n, row) => n + row.bytes, 0) <= STARTUP_POLICY.cacheBytes);
  return { all, selected };
}
export function createPinnedMemory(rows, bodies) {
  const kept = new Map();
  let total = 0;
  for (const row of rows) {
    const bytes = bodies.get(row.path);
    assert(Buffer.isBuffer(bytes));
    assert.equal(bytes.length, row.bytes);
    assert.equal(sha(bytes), row.sha256);
    total += bytes.length;
    assert(total <= STARTUP_POLICY.cacheBytes);
    assert(!kept.has(row.path));
    kept.set(row.path, { row, bytes: Buffer.from(bytes) });
  }
  return {
    bytes: total,
    count: kept.size,
    get(name) {
      const entry = kept.get(name);
      if (!entry) return null;
      assert.equal(sha(entry.bytes), entry.row.sha256);
      return Buffer.from(entry.bytes);
    },
  };
}
export function readPublicBootProgress() {
  const doc = globalThis.document;
  const el = doc.querySelector('#shell-home');
  return {
    readyState: doc.readyState,
    bootState: doc.documentElement.dataset.bootState ?? null,
    accessState: doc.documentElement.dataset.accessState ?? null,
    locale: doc.documentElement.lang,
    bootTitle: doc.querySelector('#boot-title')?.textContent?.slice(0, 200) ?? null,
    bootStatus: doc.querySelector('#boot-status')?.textContent?.slice(0, 1200) ?? null,
    homePresent: Boolean(el),
    homeOpen: Boolean(el?.open),
    homeVisible: Boolean(
      el?.open &&
        el.getClientRects().length &&
        globalThis.getComputedStyle(el).visibility !== 'hidden',
    ),
    loadedScripts: doc.querySelectorAll('script[src]').length,
    resources: performance.getEntriesByType('resource').length,
  };
}
function frozen(plan) {
  const git = (args) =>
    execFileSync('git', args, {
      cwd: plan.repository,
      encoding: 'utf8',
      timeout: 10000,
      maxBuffer: 1024 * 1024,
    }).trim();
  assert.equal(
    git(['status', '--porcelain', '--untracked-files=normal']),
    '',
    'Observer helper source must be clean.',
  );
  assert.equal(git(['rev-parse', 'HEAD']), plan.observerRevision);
  assert.equal(git(['rev-parse', 'HEAD^{tree}']), plan.observerTree);
}
export async function startupDiagnosticServer({
  distribution,
  memory,
  readOriginal,
  sourcePath,
  headers,
  requests,
}) {
  let mode = 'file',
    trial = 'not-started',
    accepting = true;
  const pending = new Set();
  const server = createServer((req, res) => {
    const row = {
      trial,
      mode,
      path: String(req.url).split('?')[0],
      startedMs: performance.now(),
      finished: false,
    };
    if (requests.length >= STARTUP_POLICY.maxRequests) {
      res.writeHead(503);
      res.end();
      accepting = false;
      return;
    }
    requests.push(row);
    const work = (async () => {
      try {
        assert(accepting, 'Diagnostic server stopped.');
        assert(['GET', 'HEAD'].includes(req.method));
        const name = sourcePath(req.url);
        safeMember(name);
        assert(distribution.files.has(name), 'Not an original generated member.');
        row.member = name;
        let bytes = row.mode === 'memory' ? memory.get(name) : null;
        row.delivery = bytes ? 'verified-memory' : 'verified-original-file';
        row.readStartedMs = performance.now();
        if (!bytes) bytes = await readOriginal(distribution, name);
        row.bytesReadyMs = performance.now();
        const pin = distribution.files.get(name);
        assert.equal(bytes.length, pin.bytes);
        assert.equal(sha(bytes), pin.sha256);
        row.bytes = bytes.length;
        row.sha256 = pin.sha256;
        if (!accepting || res.destroyed) {
          row.abortedBeforeResponse = true;
          return;
        }
        res.writeHead(200, {
          'content-type': MIME[path.extname(name)] ?? 'application/octet-stream',
          'content-length': bytes.length,
          'cache-control': 'no-store',
          ...headers,
        });
        res.end(req.method === 'HEAD' ? undefined : bytes);
      } catch (error) {
        row.error = error.message;
        if (!res.destroyed) {
          res.writeHead(404, headers);
          res.end('Not a verified production member.');
        }
      }
    })();
    pending.add(work);
    void work.then(
      () => pending.delete(work),
      () => pending.delete(work),
    );
    res.once('finish', () => {
      row.finished = true;
      row.finishedMs = performance.now();
    });
    res.once('close', () => {
      row.closedMs = performance.now();
      row.aborted = !res.writableFinished;
    });
  });
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  return {
    server,
    url: `http://127.0.0.1:${server.address().port}/`,
    setTrial(name, next) {
      assert(STARTUP_POLICY.modes.includes(next));
      trial = name;
      mode = next;
    },
    pending: () => pending.size,
    settled: () => Promise.allSettled([...pending]),
    close: async () => {
      accepting = false;
      server.closeAllConnections?.();
      await new Promise((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve())),
      );
    },
  };
}

export async function observeProductionHomeDelivery({ plan, output, playwrightModule, password }) {
  validateStartupPlan(plan);
  assert(path.isAbsolute(output) && path.isAbsolute(playwrightModule));
  await mkdir(output);
  const report = {
    format: 'ProductionHomeDeliveryDiagnostic.v1',
    policy: STARTUP_POLICY,
    plan,
    completed: false,
    qualified: false,
    publicEligible: false,
    fullDistributionVerified: false,
    cases: [],
    requests: [],
    authority: [],
    resources: [],
    cleanup: [],
    limitations: [
      'Subset diagnostic only; prior full-production failed receipt stays failed.',
      'File mode means verified filesystem reads on each request, not a cold OS/browser cache claim. The same selected files are prefetched before both modes.',
      'Only identical original generated bytes are served; no source fallback, app callback, timer change or authentication bypass.',
      'Ten-second Home condition unchanged. One EN pair is not a performance benchmark, general causal proof, six-case journey or package qualification.',
    ],
  };
  let browser, served, helpers, distribution, memory, rows, priorBytes, prior, manifestBytes;
  const own = new URL(import.meta.url),
    root = plan.repository;
  const deadline = async (promise, ms, label) => {
    let timer;
    try {
      return await Promise.race([
        promise,
        new Promise((_, reject) => {
          timer = setTimeout(() => reject(Error(`${label} timed out`)), ms);
        }),
      ]);
    } finally {
      clearTimeout(timer);
    }
  };
  const close = async (label, fn) => {
    try {
      await deadline(Promise.resolve().then(fn), 5000, label);
      report.cleanup.push({ label, closed: true });
    } catch (error) {
      report.cleanup.push({ label, closed: false, error: error.message });
    }
  };
  const sourceNames = [
    'scripts/observe-practice-directory-journey.mjs',
    'scripts/practice-distribution-io.mjs',
    'scripts/optional-installation-observer-helpers.mjs',
    'scripts/observe-practice-pointer.mjs',
    'scripts/fpv-observation-artifact.mjs',
    'scripts/game-cli.mjs',
  ];
  try {
    frozen(plan);
    report.harnessSha256 = sha(await readFile(own));
    for (const name of sourceNames)
      report.authority.push({ path: name, sha256: sha(await readFile(path.join(root, name))) });
    const load = (name) => import(pathToFileURL(path.join(root, 'scripts', name)).href);
    helpers = await load('observe-practice-directory-journey.mjs');
    const { withDirectoryDistributionIO } = await load('practice-distribution-io.mjs');
    const { PUBLIC_SECURITY_HEADERS } = await load('game-cli.mjs');
    const { acquirePointerResource } = await load('observe-practice-pointer.mjs');
    const { unlockObservedPage } = await load('optional-installation-observer-helpers.mjs');
    async function boundedFile(file, limit, io) {
      const info = await io.perform('stat ' + file, () => stat(file));
      assert(info.isFile() && info.size <= limit);
      let count = 0;
      const chunks = [];
      await io.consume(
        file,
        (signal) => createReadStream(file, { signal }),
        (chunk) => {
          count += chunk.length;
          assert(count <= limit);
          chunks.push(chunk);
        },
      );
      return Buffer.concat(chunks, count);
    }
    report.subsetBefore = {};
    await withDirectoryDistributionIO(
      async (io) => {
        priorBytes = await boundedFile(plan.previousReceipt, 4 * 1024 * 1024, io);
        assert.equal(sha(priorBytes), plan.previousReceiptSha256);
        prior = JSON.parse(priorBytes);
        const distRoot = await io.perform('Original distribution root', () =>
          realpath(prior.plan.distribution),
        );
        assert.equal(distRoot, prior.plan.distribution);
        const manifestPath = path.join(distRoot, 'manifest.json');
        assert.equal(
          await io.perform('Original manifest path', () => realpath(manifestPath)),
          manifestPath,
        );
        manifestBytes = await boundedFile(manifestPath, 8 * 1024 * 1024, io);
        assert.equal(sha(manifestBytes), prior.plan.distributionManifestSha256);
        const manifest = JSON.parse(manifestBytes),
          selected = validateStartupSubset(prior, manifest);
        rows = selected.selected;
        distribution = { root: distRoot, manifest, manifestBytes, files: selected.all };
        assert.equal(
          execFileSync('git', ['rev-parse', '--verify', `${manifest.sourceRevision}^{tree}`], {
            cwd: root,
            encoding: 'utf8',
            timeout: 10000,
          }).trim(),
          prior.plan.shellTree,
        );
        const bodies = new Map();
        await io.members(rows, async (row) => {
          const bytes = await helpers.readDirectoryDistributionFile(distribution, row.path, io);
          bodies.set(row.path, bytes);
        });
        memory = createPinnedMemory(rows, bodies);
      },
      report.subsetBefore,
      { phaseMs: STARTUP_POLICY.subsetMs },
    );
    report.previousReceipt = { path: plan.previousReceipt, sha256: sha(priorBytes) };
    report.originalManifest = {
      sha256: sha(manifestBytes),
      sourceRevision: distribution.manifest.sourceRevision,
      sourceTree: prior.plan.shellTree,
    };
    report.prefetched = { files: rows, bytes: memory.bytes, count: memory.count };
    served = await acquirePointerResource(
      report.resources,
      'diagnostic-server',
      () =>
        startupDiagnosticServer({
          distribution,
          memory,
          readOriginal: helpers.readDirectoryDistributionFile,
          sourcePath: helpers.directorySourcePath,
          headers: PUBLIC_SECURITY_HEADERS,
          requests: report.requests,
        }),
      (s) => deadline(s.close(), 5000, 'Late server close'),
    );
    const { chromium } = await import(pathToFileURL(playwrightModule).href);
    browser = await acquirePointerResource(
      report.resources,
      'diagnostic-browser',
      () => chromium.launch({ channel: 'chrome', headless: true, timeout: 10000 }),
      (b) => deadline(b.close(), 5000, 'Late browser close'),
    );
    report.browser = browser.version();
    const end = performance.now() + STARTUP_POLICY.browserMs;
    for (const mode of STARTUP_POLICY.modes) {
      assert(performance.now() < end);
      const trial = {
        mode,
        locale: 'en',
        homeWithinDeadline: false,
        network: [],
        snapshots: [],
        errors: [],
      };
      report.cases.push(trial);
      served.setTrial(mode, mode);
      let context, page, sampling;
      let settled = false;
      const caseEnd = Math.min(end, performance.now() + STARTUP_POLICY.caseMs);
      const active = () =>
        assert(performance.now() < caseEnd, 'Diagnostic case deadline exceeded.');
      const step = async (p, ms, label) => {
        active();
        const value = await deadline(
          p,
          Math.min(ms, Math.max(1, caseEnd - performance.now())),
          label,
        );
        active();
        return value;
      };
      try {
        active();
        context = await acquirePointerResource(
          report.resources,
          mode + '-context',
          () => browser.newContext({ viewport: { width: 1440, height: 900 }, locale: 'en-US' }),
          (c) => deadline(c.close(), 5000, 'Late context close'),
          Math.min(10000, caseEnd - performance.now()),
        );
        active();
        page = await acquirePointerResource(
          report.resources,
          mode + '-page',
          () => context.newPage(),
          (p) => deadline(p.close(), 5000, 'Late page close'),
          Math.min(10000, caseEnd - performance.now()),
        );
        page.setDefaultTimeout(10000);
        page.on('pageerror', (error) => trial.errors.push(error.message.slice(0, 1024)));
        const requests = new Map();
        page.on('request', (request) => {
          if (trial.network.length >= STARTUP_POLICY.maxRequests) {
            trial.networkOverflow = true;
            return;
          }
          const u = new URL(request.url());
          const item = {
            path: u.pathname,
            type: request.resourceType(),
            startedMs: performance.now(),
            finished: false,
          };
          requests.set(request, item);
          trial.network.push(item);
        });
        page.on('response', (response) => {
          const item = requests.get(response.request());
          if (item) {
            item.responseMs = performance.now();
            item.status = response.status();
          }
        });
        page.on('requestfinished', (request) => {
          const item = requests.get(request);
          if (item) {
            item.finished = true;
            item.finishedMs = performance.now();
          }
        });
        page.on('requestfailed', (request) => {
          const item = requests.get(request);
          if (item) {
            item.failed = true;
            item.failure = request.failure()?.errorText;
            item.finishedMs = performance.now();
          }
        });
        active();
        await step(
          page.goto(served.url + 'revealline/game/?lang=en', {
            waitUntil: 'domcontentloaded',
            timeout: 10000,
          }),
          10000,
          'Document load',
        );
        active();
        trial.formSubmitted = await step(
          unlockObservedPage(page, password),
          10000,
          'Normal access form',
        );
        const started = performance.now();
        const home = page
          .locator('#shell-home[open]')
          .waitFor({ state: 'visible', timeout: STARTUP_POLICY.homeMs })
          .then(
            () => {
              trial.homeElapsedMs = performance.now() - started;
              trial.homeWithinDeadline = trial.homeElapsedMs <= STARTUP_POLICY.homeMs;
            },
            (error) => {
              trial.homeElapsedMs = performance.now() - started;
              trial.homeFailure = error.message;
            },
          )
          .finally(() => {
            settled = true;
          });
        sampling = (async () => {
          while (!settled) {
            try {
              const state = await deadline(
                page.evaluate(readPublicBootProgress),
                1000,
                'Public boot snapshot',
              );
              trial.snapshots.push({
                elapsedMs: performance.now() - started,
                serverPending: served.pending(),
                browserPending: trial.network.filter((x) => !x.finished && !x.failed).length,
                state,
              });
            } catch (error) {
              trial.snapshots.push({ error: error.message });
            }
            if (!settled) await pause(500);
          }
        })();
        await step(home, 11000, 'Unchanged Home observation');
        trial.pendingAtHome = {
          server: served.pending(),
          browser: trial.network.filter((x) => !x.finished && !x.failed).map((x) => x.path),
        };
        active();
        const image = await step(
          page.screenshot({ timeout: 2000 }),
          2500,
          'Home result screenshot',
        );
        await writeFile(path.join(output, mode + '.png'), image, { flag: 'wx' });
        trial.screenshot = { path: mode + '.png', bytes: image.length, sha256: sha(image) };
      } catch (error) {
        trial.failure = error.message;
      } finally {
        settled = true;
        if (context) await close(mode + ' context', () => context.close());
        if (sampling) await close(mode + ' snapshot loop', () => sampling);
        await close(mode + ' request settlement', () => served.settled());
        assert.equal(served.pending(), 0, 'Previous trial reads did not settle.');
      }
    }
    await close('Close browser before subset recheck', () => browser.close());
    browser = null;
    await close('Close server before subset recheck', () => served.close());
    await close('Join server reads', () => served.settled());
    report.pendingServerReads = served.pending();
    served = null;
    report.subsetAfter = {};
    await withDirectoryDistributionIO(
      async (io) => {
        assert.equal(
          sha(
            await boundedFile(path.join(distribution.root, 'manifest.json'), 8 * 1024 * 1024, io),
          ),
          sha(manifestBytes),
        );
        const checked = new Map(rows.map((row) => [row.path, row]));
        for (const row of report.requests)
          if (row.member && row.sha256) checked.set(row.member, distribution.files.get(row.member));
        await io.members([...checked.values()], (row) =>
          helpers.readDirectoryDistributionFile(distribution, row.path, io),
        );
      },
      report.subsetAfter,
      { phaseMs: STARTUP_POLICY.subsetMs },
    );
    frozen(plan);
    assert.equal(sha(await readFile(own)), report.harnessSha256);
    for (const row of report.authority)
      assert.equal(sha(await readFile(path.join(root, row.path))), row.sha256);
    report.sourceStable = true;
    report.completed =
      report.cases.length === 2 &&
      report.cases.every(
        (row) => !row.failure && !row.networkOverflow && typeof row.homeElapsedMs === 'number',
      ) &&
      !report.pendingServerReads &&
      report.cleanup.every((row) => row.closed) &&
      report.resources.every((row) => !row.pending && (!row.timedOut || row.lateClosed));
    report.interpretation =
      report.cases[0]?.homeWithinDeadline === false && report.cases[1]?.homeWithinDeadline === true
        ? 'Known-member delivery path affects this matched Home result; inspect request timings before attributing a specific filesystem cause.'
        : 'No isolated delivery-cause conclusion; inspect public boot progress and request completion.';
  } catch (error) {
    report.failure = error.message;
  } finally {
    if (browser) await close('Browser', () => browser.close());
    if (served) {
      await close('Server', () => served.close());
      await close('Pending server reads', () => served.settled());
      report.pendingServerReads = served.pending();
    }
    report.completed &&= report.cleanup.every((row) => row.closed) && !report.pendingServerReads;
    await writeFile(path.join(output, 'observation.json'), JSON.stringify(report, null, 2) + '\n', {
      flag: 'wx',
    });
  }
  return report;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  assert.equal(process.env.PRACTICE_PRODUCTION_HOME_DIAGNOSTIC, '1');
  assert.equal(process.argv.length, 5, 'Use PLAN_JSON PLAYWRIGHT_MODULE NEW_OUTPUT_DIRECTORY.');
  const plan = JSON.parse(await readFile(process.argv[2], 'utf8'));
  const result = await observeProductionHomeDelivery({
    plan,
    playwrightModule: process.argv[3],
    output: process.argv[4],
    password: process.env.OPTIONAL_INSTALLATION_PASSWORD,
  });
  console.log(
    JSON.stringify({
      completed: result.completed,
      qualified: false,
      failure: result.failure,
      cases: result.cases.map((x) => ({
        mode: x.mode,
        homeWithinDeadline: x.homeWithinDeadline,
        homeElapsedMs: x.homeElapsedMs,
      })),
    }),
  );
  process.exitCode = result.completed ? 0 : 1;
}
