import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import {
  validateStartupPlan,
  validateStartupSubset,
  createPinnedMemory,
  startupDiagnosticServer,
} from './practice-production-startup-diagnostic.mjs';
const sha = (x) => createHash('sha256').update(x).digest('hex');
const body = Buffer.from('<!doctype html><title>Original</title>');
const row = { path: 'game/index.html', bytes: body.length, sha256: sha(body) };
function fixture() {
  const manifest = {
    sourceRevision: 'a'.repeat(40),
    entry: 'game/index.html',
    formatVersion: 1,
    totalBytes: row.bytes,
    files: [row],
  };
  return {
    manifest,
    prior: {
      format: 'PracticeDirectoryProductionPersonalAppearanceObservation.v2',
      completed: false,
      plan: {
        protocol: 'practice-directory-production-personal-appearance.v2',
        shellRevision: manifest.sourceRevision,
      },
      distribution: {
        originalsVerifiedBefore: true,
        originalsVerifiedAfter: true,
        originalFiles: [row],
      },
      servedDistribution: [row],
    },
  };
}
test('plan is explicit and rejects unknown knobs/relative paths', () => {
  const p = {
    format: 'revealline-production-home-delivery-plan.v1',
    repository: '/tmp/repo',
    observerRevision: 'a'.repeat(40),
    observerTree: 'b'.repeat(40),
    previousReceipt: '/tmp/prior.json',
    previousReceiptSha256: 'c'.repeat(64),
  };
  assert.equal(validateStartupPlan(p), p);
  assert.throws(() => validateStartupPlan({ ...p, timeout: 20000 }));
  assert.throws(() => validateStartupPlan({ ...p, repository: 'repo' }));
});
test('only original failed, doubly verified production receipt supplies subset', () => {
  const { prior, manifest } = fixture();
  assert.equal(validateStartupSubset(prior, manifest).selected.length, 1);
  for (const mutation of [
    (p) => (p.completed = true),
    (p) => (p.distribution.originalsVerifiedAfter = false),
    (p) => (p.format = 'other'),
    (p) => p.servedDistribution.push(row),
    (p) => (p.servedDistribution[0] = { ...row, sha256: '0'.repeat(64) }),
  ]) {
    const p = structuredClone(prior);
    mutation(p);
    assert.throws(() => validateStartupSubset(p, manifest));
  }
});
test('manifest rejects traversal, duplicates, inconsistent totals and missing entry', () => {
  for (const mutate of [
    (m) => (m.files[0].path = '../index.html'),
    (m) => m.files.push(m.files[0]),
    (m) => m.totalBytes++,
    (m) => (m.entry = 'other'),
  ]) {
    const { prior, manifest } = fixture();
    const m = structuredClone(manifest);
    mutate(m);
    prior.distribution.originalFiles = m.files;
    assert.throws(() => validateStartupSubset(prior, m));
  }
});
test('private memory copy remains hash-pinned and excludes unknown paths', () => {
  const source = Buffer.from(body);
  const memory = createPinnedMemory([row], new Map([[row.path, source]]));
  source.fill(0);
  assert.deepEqual(memory.get(row.path), body);
  memory.get(row.path).fill(0);
  assert.deepEqual(memory.get(row.path), body);
  assert.equal(memory.get('unknown'), null);
  assert.throws(() => createPinnedMemory([row], new Map([[row.path, Buffer.alloc(body.length)]])));
});
async function serverFixture(readOriginal) {
  const requests = [];
  const server = await startupDiagnosticServer({
    distribution: { files: new Map([[row.path, row]]) },
    memory: createPinnedMemory([row], new Map([[row.path, body]])),
    readOriginal,
    sourcePath: (url) => new URL(url, 'http://127.0.0.1').pathname.slice(1),
    headers: { 'content-security-policy': "default-src 'self'" },
    requests,
  });
  return { ...server, requests };
}
test('file and memory serve identical bytes and headers; only file calls original reader', async () => {
  let reads = 0;
  const s = await serverFixture(async () => {
    reads++;
    return body;
  });
  try {
    for (const mode of ['file', 'memory']) {
      s.setTrial(mode, mode);
      const response = await fetch(s.url + row.path);
      assert.equal(response.status, 200);
      assert.equal(response.headers.get('content-security-policy'), "default-src 'self'");
      assert.equal(response.headers.get('cache-control'), 'no-store');
      assert.deepEqual(Buffer.from(await response.arrayBuffer()), body);
    }
    assert.equal(reads, 1);
    assert.deepEqual(
      s.requests.map((x) => x.delivery),
      ['verified-original-file', 'verified-memory'],
    );
    assert(
      s.requests.every(
        (x) => x.finished && x.sha256 === row.sha256 && x.bytesReadyMs >= x.readStartedMs,
      ),
    );
  } finally {
    await s.close();
    await s.settled();
  }
  assert.equal(s.pending(), 0);
});
test('unlisted path and unexpected original bytes fail closed without source fallback', async () => {
  let reads = 0;
  const s = await serverFixture(async () => {
    reads++;
    return Buffer.alloc(body.length);
  });
  try {
    assert.equal((await fetch(s.url + 'unknown.mjs')).status, 404);
    assert.equal(reads, 0);
    assert.equal((await fetch(s.url + row.path)).status, 404);
    assert.equal(reads, 1);
    assert(s.requests.every((x) => x.error));
    assert.throws(() => s.setTrial('arbitrary', 'other'));
  } finally {
    await s.close();
    await s.settled();
  }
});
test('selected scope metadata is captured at request entry; pending work is joined after close', async () => {
  let release;
  const s = await serverFixture(
    () =>
      new Promise((resolve) => {
        release = () => resolve(body);
      }),
  );
  s.setTrial('first', 'file');
  const result = fetch(s.url + row.path).catch(() => null);
  while (!release) await new Promise((resolve) => setTimeout(resolve, 1));
  assert.equal(s.pending(), 1);
  s.setTrial('second', 'memory');
  await s.close();
  release();
  await s.settled();
  await result;
  assert.equal(s.pending(), 0);
  assert.equal(s.requests[0].trial, 'first');
  assert.equal(s.requests[0].mode, 'file');
  assert.equal(s.requests[0].abortedBeforeResponse, true);
});
