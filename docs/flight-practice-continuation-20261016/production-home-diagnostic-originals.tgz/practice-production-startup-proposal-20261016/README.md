# Original production Home delivery diagnostic (temporary proposal)

This is a two-context EN-only diagnostic, **not production qualification**, not a replacement for the six failed journeys, and not a performance benchmark. It serves only original generated distribution members. It does not run or change app callbacks, clocks, authentication, package publishing, source files, or the 10-second Home condition.

## Fixed comparison

The original failed production receipt supplies the manifest pin, original source/tree, and exact 643 served members (10,300,719 bytes). Before browser launch those members are re-read and hash-verified using the existing bounded four-stream original-distribution I/O helper. A private memory copy is retained (128 MiB hard cap). Both trials use the same original headers/CSP and fresh browser contexts in isolated headless Chrome, normal password form, 1440×900 viewport, and English locale.

1. `file`: every original member is read and verified from the distribution when requested.
2. `memory`: only the selected verified members are returned from memory. Any other original-manifest member is read and verified from the same distribution. Unknown paths fail closed; there is no source fallback.

“File” does **not** mean cold OS cache: the common integrity preflight already read the selected files. The comparison isolates repeated request-time filesystem work, not SMB metadata specifically. If only memory reaches Home, delivery-path sensitivity is demonstrated for this pair; file metadata, file body reads, and scheduling are not independently separated.

The report records per-request acceptance, read start, verified-body availability, finish/abort, exact body pins, pending counts, browser request timings, and read-only public boot text/attributes every 500 ms. Home has the unchanged native 10-second wait after normal authentication; the outer 11-second join is cleanup overhead, not an acceptance extension. Each case is bounded by 45 seconds and the browser phase by 100 seconds. Cleanup attempts independently close browser/server and join owned reads with 5-second bounds; unresolved work makes completion false. The selected members, any additional served originals, manifest, clean source revision/tree, and helper hashes are rechecked afterward. No 1 GB full-build integrity claim is made by this diagnostic; the pinned earlier receipt retains its original full before/after checks.

## API and invocation (root approval required before running)

Exports `validateStartupPlan`, `validateStartupSubset`, `createPinnedMemory`, `readPublicBootProgress`, `startupDiagnosticServer`, and `observeProductionHomeDelivery`.

Strict plan fields are `format: revealline-production-home-delivery-plan.v1`, absolute `repository`, exact clean `observerRevision` and `observerTree`, absolute `previousReceipt`, and `previousReceiptSha256`. Use the existing run2 receipt at `/tmp/practice-production-personal-appearance-v2-20261016-run2/observation.json`, SHA `f15c40a3196b8999ea03cc2219c87f57c441ead62fddf2a9d67d8e5fb41f0296`. Bind observer HEAD/tree at the time root freezes the source. Do not reuse a stale source pin.

```sh
PRACTICE_PRODUCTION_HOME_DIAGNOSTIC=1 node /tmp/practice-production-startup-proposal-20261016/scripts/practice-production-startup-diagnostic.mjs PLAN_JSON ABSOLUTE_EXISTING_PLAYWRIGHT_MODULE NEW_OUTPUT_DIRECTORY
```

The existing authorized `OPTIONAL_INSTALLATION_PASSWORD` environment is consumed only by the normal form and not recorded. Output directory must not exist. The report and screenshots use exclusive writes. `completed` describes complete diagnostic collection/cleanup, not successful Home startup or public eligibility; both qualification flags stay false. Source remains unmodified. Unit tests use only tiny owned loopback fixtures, not Chrome or the external distribution.
