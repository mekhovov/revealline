"""Collect only the pinned small upload-evidence ZIP and read-only final authority metadata."""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,os,selectors,stat,subprocess,time,zipfile
HERE=Path(__file__).resolve().parent
REPO='mekhovov/revealline'
RUN=35307090655  # Actual coordinator-dispatched successor run
RELEASE_ID=391216363
assert type(RUN) is int and RUN > 0 and type(RELEASE_ID) is int and RELEASE_ID > 0, "UNBOUND: root-reviewed actual upload run/release required"
WORKFLOW_SHA='ef491211488b1c06f00ad2efbeb4fb23bbae39b8'  # Reviewed utility workflow commit; not frozen game source
WORKFLOW_TREE='ec21fa39dd49045d90ccc2f8e540ab23b4fbba51'  # Reviewed utility Git tree
RUN_ATTEMPT=1  # Bound to retained actual run original
APPROVED_BINDING_SHA256='8a4dfb48ff6a6db1afa143ae03dfc1fe2bf01e9c89d8ac0f18936c06cf56c216'  # Bound to retained root request and exact binding bytes
assert type(WORKFLOW_SHA) is str and len(WORKFLOW_SHA)==40 and all(c in '0123456789abcdef' for c in WORKFLOW_SHA), 'UNBOUND workflow commit'
assert type(WORKFLOW_TREE) is str and len(WORKFLOW_TREE)==40 and all(c in '0123456789abcdef' for c in WORKFLOW_TREE), 'UNBOUND workflow tree'
assert type(RUN_ATTEMPT) is int and RUN_ATTEMPT>0, 'UNBOUND actual run attempt'
assert type(APPROVED_BINDING_SHA256) is str and len(APPROVED_BINDING_SHA256)==64 and all(c in '0123456789abcdef' for c in APPROVED_BINDING_SHA256), 'UNBOUND reviewed binding digest'
GAME_SOURCE='a7a4e2d7090e2fe9d1843d88b63bc334b95bf61e'
GAME_TREE='8f81812d56299c2819ec083d919d9085a36d223c'
GAME_VERSION='v0.61.1'
BINDING_PATH=HERE/'authority/binding.reviewed.json'
assert hashlib.sha256(BINDING_PATH.read_bytes()).hexdigest()==APPROVED_BINDING_SHA256, 'Reviewed local binding bytes changed'
APPROVAL_PATH=HERE/'small-intake.reviewed.json'
approval_raw=APPROVAL_PATH.read_bytes();assert hashlib.sha256(approval_raw).hexdigest()=='57139fbdb83e6db6de30deee1bdda52ce7209069f0fa1418951c280170d9e5d6'
APPROVAL=json.loads(approval_raw);assert APPROVAL['status']=='ROOT_REVIEWED_ONE_SMALL_ARTIFACT_GET' and APPROVAL['reviewed'] is True
assert (APPROVAL['runId'],APPROVAL['jobId'],APPROVAL['attempt'],APPROVAL['releaseId'])==(RUN,105481641674,1,RELEASE_ID)
assert APPROVAL['source']=={'commit':GAME_SOURCE,'tree':GAME_TREE,'version':GAME_VERSION} and APPROVAL['utility']=={'commit':WORKFLOW_SHA,'tree':WORKFLOW_TREE}
assert APPROVAL['limits']['managedCacheBytes']==32*1024**2 and APPROVAL['limits']['freeReserveBytes']==512*1024**2 and APPROVAL['limits']['maximumExpandedBytes']==16*1024**2
for row in APPROVAL['originalPins']:
 p=Path(row['path']);assert p.is_relative_to(HERE) and not p.is_symlink();raw=p.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
OUT=HERE/'small-evidence-intake'
def capacity(extra=0):
    import shutil
    used=sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())
    assert used+extra+1024*1024 <= 32*1024**2, '32 MiB evidence budget exceeded'
    assert shutil.disk_usage(HERE).free-extra >= 512*1024**2, '512 MiB reserve unavailable'
def safe(path):
    assert path.is_absolute() and path.is_relative_to(HERE) and '..' not in path.parts
    for p in [path,*path.parents]:
        assert not p.is_symlink(),p
        if p!=path and p.exists():assert p.is_dir(),p
safe(OUT);OUT.mkdir()
def write(p,b):
    capacity(len(b));safe(p);p.parent.mkdir(parents=True,exist_ok=True);safe(p)
    with p.open('xb') as f:f.write(b)
def encode(x):return (json.dumps(x,indent=2)+'\n').encode()
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def request(name,endpoint,cap,timeout=60):
    capacity(cap+100000)
    assert endpoint.startswith('repos/'+REPO+'/')
    body=OUT/(name+'.body');err=OUT/(name+'.stderr');receipt=OUT/(name+'.receipt.json')
    for p in [body,err,receipt]:safe(p)
    start=time.monotonic();process=None;failure=None;stats={k:{'observed':0,'stored':0,'eof':False} for k in ['stdout','stderr']}
    with body.open('xb') as bf,err.open('xb') as ef,selectors.DefaultSelector() as selector:
        streams={'stdout':(bf,cap),'stderr':(ef,100000)}
        try:
            process=subprocess.Popen(['gh','api','--method','GET',endpoint],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            for name,pipe in [('stdout',process.stdout),('stderr',process.stderr)]:os.set_blocking(pipe.fileno(),False);selector.register(pipe,selectors.EVENT_READ,name)
            while selector.get_map():
                remaining=timeout-(time.monotonic()-start)
                if remaining<=0:raise TimeoutError('Finite request deadline reached')
                for key,_ in selector.select(min(remaining,.25)):
                    name=key.data;s=stats[name];chunk=os.read(key.fileobj.fileno(),65536)
                    if not chunk:s['eof']=True;selector.unregister(key.fileobj);continue
                    f,limit=streams[name];s['observed']+=len(chunk);part=chunk[:max(0,limit-s['stored'])];f.write(part);s['stored']+=len(part)
                    if s['observed']>limit:raise ValueError('Response exceeded '+name+' byte cap')
            if process.wait(timeout=max(.1,timeout-(time.monotonic()-start)))!=0:raise RuntimeError('gh GET failed')
        except BaseException as e:failure={'type':type(e).__name__,'message':str(e)}
        finally:
            if process:
                if process.poll() is None:process.kill();process.wait(timeout=5)
                process.stdout.close();process.stderr.close()
    record={'method':'GET','endpoint':endpoint,'exitCode':None if not process else process.returncode,'failure':failure,'automaticRetry':False,'timeoutSeconds':timeout,'streams':{name:{**s,'completeOriginal':s['eof'] and s['observed']==s['stored']} for name,s in stats.items()},'body':pin(body),'stderr':pin(err)}
    write(receipt,encode(record));assert failure is None,record
    return body
snapshots=sorted((HERE/'snapshots').glob('*/observation.json'))
assert snapshots
obs=json.loads(snapshots[-1].read_bytes());assert obs['runId']==RUN and obs['attempt']==RUN_ATTEMPT and obs['runStatus']=='completed' and obs['conclusion']=='success'
assert obs['workflowRevisionFromRun']==WORKFLOW_SHA and obs['expectedWorkflowTree']==WORKFLOW_TREE
assert obs['expectedFrozenGameSource']=={'commit':GAME_SOURCE,'tree':GAME_TREE,'version':GAME_VERSION}
for role in ['run','jobs','artifacts','workflowCommit']:
    row=obs[role];assert pin(Path(row['path']))==row
run=json.loads(Path(obs['run']['path']).read_bytes());jobs=json.loads(Path(obs['jobs']['path']).read_bytes());arts=json.loads(Path(obs['artifacts']['path']).read_bytes())
assert run['id']==RUN and run['run_attempt']==RUN_ATTEMPT and run['head_sha']==WORKFLOW_SHA and run['event']=='workflow_dispatch' and run['path']=='.github/workflows/qualify-release-source.yml'
assert jobs['total_count']==len(jobs['jobs'])<=20 and all(j['run_id']==RUN and j['head_sha']==WORKFLOW_SHA for j in jobs['jobs'])
workflow_commit=json.loads(Path(obs['workflowCommit']['path']).read_bytes())
assert workflow_commit['sha']==WORKFLOW_SHA and workflow_commit['tree']['sha']==WORKFLOW_TREE
assert arts['total_count']==len(arts['artifacts'])==1
artifact=arts['artifacts'][0]
assert artifact['name']=='upload-originals-evidence' and artifact['workflow_run']['id']==RUN and artifact['workflow_run']['head_sha']==WORKFLOW_SHA and artifact['expired'] is False
assert type(artifact['size_in_bytes']) is int and 0<artifact['size_in_bytes']<16*1024**2
expected={'id':artifact['id'],'bytes':artifact['size_in_bytes'],'sha256':artifact['digest'].removeprefix('sha256:')}
assert len(expected['sha256'])==64 and expected==APPROVAL['artifact']
write(OUT/'small-artifact-pin.json',encode({'status':'ACTUAL_API_METADATA_PINNED_BEFORE_BODY_GET','runId':RUN,'attempt':run['run_attempt'],'artifact':expected,'metadataOriginal':obs['artifacts']}))
archive=request('upload-originals-evidence-original',f'repos/{REPO}/actions/artifacts/{expected["id"]}/zip',expected['bytes'],60)
actual=pin(archive);assert all(actual[k]==expected[k] for k in ['bytes','sha256'])
with zipfile.ZipFile(archive) as z:
    entries=z.infolist();assert 0<len(entries)==len({e.filename for e in entries})<=2000 and sum(e.file_size for e in entries)<16*1024**2
    capacity(sum(e.file_size for e in entries)+2*1024**2)
    for e in entries:
        n=PurePosixPath(e.filename);assert not n.is_absolute() and '..' not in n.parts and '\\' not in e.filename and not e.is_dir() and not e.flag_bits&1 and stat.S_IFMT(e.external_attr>>16) in [0,stat.S_IFREG]
        write(OUT/'evidence'/str(n),z.read(e))
binding_path=HERE/'authority/binding.reviewed.json'
assert pin(binding_path)['sha256']==APPROVED_BINDING_SHA256
binding=json.loads(binding_path.read_bytes())
assert binding['reviewed'] is True and binding['repository']==REPO
assert binding['source']=={'commit':GAME_SOURCE,'tree':GAME_TREE,'version':GAME_VERSION}
assert binding['artifact']=={'id':10528796184,'runId':35295672698,'bytes':1400982723,'sha256':'f26998fdac85f764b87651ca34d7780829aba9d6141c52785e55e74593c4effa'}
assert binding['release']['id']==RELEASE_ID and binding['release']['tag']==GAME_VERSION
release=request('release-after',f'repos/{REPO}/releases/{RELEASE_ID}',262144)
assets=request('assets-after',f'repos/{REPO}/releases/{RELEASE_ID}/assets?per_page=100',262144)
ref=request('tag-ref-after',f'repos/{REPO}/git/ref/tags/v0.61.1',262144);tag=json.loads(ref.read_bytes());assert tag['object']['type']=='tag'
assert tag['object']['sha']=='4dfdd664e3dab3f7837c86907e2cc26a29854472'
obj=request('tag-object-after',f'repos/{REPO}/git/tags/{tag["object"]["sha"]}',262144)
receipt={'status':'BOUNDED_UPLOAD_EVIDENCE_ORIGINAL_RECEIVED','runId':RUN,'runAttempt':RUN_ATTEMPT,'workflowCommit':WORKFLOW_SHA,'workflowTree':WORKFLOW_TREE,'frozenGameSource':binding['source'],'frozenArtifact':binding['artifact'],'artifact':expected,'archive':actual,'members':len(entries),'uncompressedBytes':sum(e.file_size for e in entries),'largeOriginalDownloaded':False,'remoteMutation':False,'qualificationHelperExecuted':False,'authorityMetadata':[pin(p) for p in [release,assets,ref,obj]]}
write(OUT/'download-receipt.json',encode(receipt));print(json.dumps(receipt,indent=2))
