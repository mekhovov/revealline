"""Read-only reconciliation of one exact v612 upload and its bounded original evidence."""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,os,shutil,subprocess,zipfile
R=Path(__file__).resolve().parent;ROOT=R.parents[1];I=R/'small-evidence-intake';E=I/'evidence';D=R/'authority'
W=ROOT/'.cache/worktrees/p08a-team-composed-d245';Q=W/'.cache/p08a-qualified/team-v0612-bb5e6e7'
RUN=35319405469;RELEASE=391284589;TAG='d139371e181fb88afdffa55cc8308f8d5cb42a97';UTILITY='ef491211488b1c06f00ad2efbeb4fb23bbae39b8'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def check(p,row):
 x=pin(p);assert (x['bytes'],x['sha256'])==(row['bytes'],row['sha256']),str(p);return x
def room(extra=0):
 assert sum(p.stat().st_size for p in R.rglob('*') if p.is_file())+extra+1024**2<=32*1024**2
 assert shutil.disk_usage(R).free-extra>=512*1024**2
def write(name,value):
 raw=(json.dumps(value,indent=2)+'\n').encode();room(len(raw));p=R/name;assert not p.exists();p.write_bytes(raw)
def git(*a):return subprocess.check_output(['git','-C',str(W),*a],env={**os.environ,'GIT_NO_LAZY_FETCH':'1'},timeout=30)
room();approval_raw=(R/'small-intake.reviewed.json').read_bytes();assert sha(approval_raw)=='5de5d4bd174dbd73ed15868c618e0aaea3fc8b4a9295481fe2c79123a391ddd9';approved=json.loads(approval_raw)
assert approved['status']=='ROOT_REVIEWED_ONE_SMALL_ARTIFACT_GET' and approved['reviewed'] is True and approved['runId']==RUN and approved['jobId']==105518290849 and approved['releaseId']==RELEASE
for row in approved['originalPins']:check(Path(row['path']),row)
logged=read(R/'terminal-binding-review.json');assert logged['status']=='TERMINAL_UPLOAD_LOG_BINDING_VERIFIED_ORIGINAL_RECEIPT_UNOPENED' and len(logged['actualLoggedBindings'])==2
check(R/'terminal-binding-review.json',approved['terminalBindingReview']);check(Path(logged['originalLog']['path']),logged['originalLog']);assert all(x['value']==read(D/'binding.reviewed.json') for x in logged['actualLoggedBindings'])
assert sha((D/'upload-request.reviewed.json').read_bytes())=='26321535f264411781028fb8b64ec3b866f04238386f578ce243677412f1a8af' and sha((D/'binding.reviewed.json').read_bytes())=='b4556760b6990fadfa07460ffc417d0ba83286c617675c75413737c63cc02280'
b=read(D/'binding.reviewed.json');assert read(E/'binding.json')==b
assert b['source']=={'commit':'bb5e6e7787bf81232368b96845d716a808c21309','tree':'d8b19e99b762b1c4ac974118abc59935f6ca8e3a','version':'v0.61.2'} and b['release']['id']==RELEASE
request=read(D/'upload-request.reviewed.json');assert json.loads(request['inputs']['artifact_binding'])==b and request['inputs']['operation']=='upload-originals' and request['inputs']['freeze_snapshot'] == 'false'
for p in [*R.glob('snapshots/*/*.receipt.json'),*I.glob('*.receipt.json')]:
 row=read(p);assert row['method']=='GET' and row['exitCode']==0 and row['failure'] is None and row['automaticRetry'] is False
 for role in ['body','stderr']:check(Path(row[role]['path']),row[role]);assert row['streams'][{'body':'stdout','stderr':'stderr'}[role]]['completeOriginal'] is True
obs=read(sorted((R/'snapshots').glob('*/observation.json'))[-1]);run=read(Path(obs['run']['path']));jobs=read(Path(obs['jobs']['path']))['jobs'];ex=read(E/'execution.json')
assert run['id']==RUN and run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1
assert run['head_sha']==ex['workflowSha']==UTILITY and int(ex['runId'])==RUN and int(ex['runAttempt'])==1
assert ex['workflowTree']=='ec21fa39dd49045d90ccc2f8e540ab23b4fbba51'
active=[j for j in jobs if j['conclusion']!='skipped'];assert len(active)==1 and active[0]['id']==105518290849 and active[0]['name']=='upload-originals' and active[0]['conclusion']=='success'
assert git('rev-parse',UTILITY+'^{tree}').decode().strip()==ex['workflowTree']
helpers=[]
for h in ex['helpers']:
 p=h['path'].split('/automation/',1)[1];raw=git('show',UTILITY+':'+p);assert len(raw)==h['bytes'] and sha(raw)==h['sha256'];assert raw==git('show',read(D/'binding.reviewed.json')['source']['commit']+':'+p);helpers.append({'path':p,'bytes':len(raw),'sha256':sha(raw)})
assert len(helpers)==len({x['path'] for x in helpers})==9
assert {x['path'] for x in helpers}=={'publishing/utility/'+n for n in ['inspect_qualified_artifact.py','release_artifact.py','test_release_artifact.py','test_upload_diagnostics.py','test_upload_distribution.py','test_upload_source.py','upload_distribution.py','upload_source.py','verify_frozen_offline.py']}
m=read(E/'retained-manifest.json');prefix='/home/runner/work/revealline/revealline/utility-output/evidence/';rels=[]
for row in m['files']:
 assert row['path'].startswith(prefix);rel=row['path'][len(prefix):];n=PurePosixPath(rel);assert not n.is_absolute() and '..' not in n.parts;check(E/rel,row);rels.append(rel)
assert len(rels)==len(set(rels))==m['count'] and sum(x['bytes'] for x in m['files'])==m['bytes']
actual={str(p.relative_to(E)) for p in E.rglob('*') if p.is_file()};assert actual==set(rels)|{'retained-manifest.json'}
receipt=read(I/'download-receipt.json');check(I/'upload-originals-evidence-original.body',receipt['archive'])
with zipfile.ZipFile(I/'upload-originals-evidence-original.body') as z:
 assert len(z.infolist())==m['count']+1 and set(z.namelist())==actual and z.testzip() is None
 for n in z.namelist():assert z.read(n)==(E/n).read_bytes()
 expanded=sum(v.file_size for v in z.infolist());assert expanded==receipt['uncompressedBytes']
source=b['source'];artifact=b['artifact'];expected={a['name']:a for a in b['release']['assets']};assert len(expected)==9
assert read(E/'source-before.json')==read(E/'source-after.json')==ex['sourceCheckout']=={'sourceRevision':source['commit'],'sourceTree':source['tree'],'trackedCheckoutClean':True}
res=read(E/'result.json');assert res['status']=='ALL_NINE_VERIFIED' and res['operation']=='upload-originals' and res['source']==source and res['artifact']==artifact and res['automaticRetry'] is False
ap=read(E/'artifact-authority.json');assert ap['id']==artifact['id'] and ap['size_in_bytes']==artifact['bytes'] and ap['digest']=='sha256:'+artifact['sha256'] and ap['workflow_run']['id']==artifact['runId'] and ap['workflow_run']['head_sha']==source['commit'] and ap['expired'] is False
dl=read(E/'qualified-artifact-original.download.json');assert dl['status']=='ORIGINAL_RECEIVED_VERIFIED' and dl['bytes']==artifact['bytes'] and dl['sha256']==artifact['sha256'] and dl['artifactId']==artifact['id'] and dl['automaticRetry'] is False
small=sorted(p.name for p in (E/'reviewed-small-assets').iterdir());assert len(small)==7 and set(small)==set(expected)-{'source.tar','distribution.zip'}
for name in small:
 check(E/'reviewed-small-assets'/name,expected[name]);assert (E/'reviewed-small-assets'/name).read_bytes()==(Q/'release-attachments'/name).read_bytes()
for name in ['manifest.json','release.json','distribution.zip.sha256']:assert (E/'qualified-artifact-verified'/name).read_bytes()==(E/'reviewed-small-assets'/name).read_bytes()
inspection=read(E/'qualified-artifact-verified/inspection.json');assert inspection['status']=='PASS' and inspection['gitHead']==source['commit'] and inspection['gitTree']==source['tree'] and inspection['version']==source['version'] and inspection['releaseHashChainVerified'] is True
for k,n in [('sourceTar','source.tar'),('distribution','distribution.zip')]:assert inspection[k]['bytes']==expected[n]['bytes'] and inspection[k]['sha256']==expected[n]['sha256']
manifest=read(E/'qualified-artifact-verified/manifest.json');assert len(manifest['files'])==690 and manifest['sourceRevision']==source['commit']
release=read(E/'qualified-artifact-verified/release.json');assert release['sourceRevision']==source['commit'] and release['sourceArchiveSha256']==expected['source.tar']['sha256'] and release['distributionSha256']==expected['distribution.zip']['sha256'] and release['manifestSha256']==expected['manifest.json']['sha256']
off=read(E/'frozen-offline-review/review.json');assert off['status']=='PASS' and off['sourceRevision']==source['commit'] and off['sourceTree']==source['tree']
for k,p in [('inspectionPin',E/'qualified-artifact-verified/inspection.json'),('manifestPin',E/'qualified-artifact-verified/manifest.json'),('downloadPin',E/'qualified-artifact-original.download.json')]:check(p,off[k])
rows={x['path']:x for x in manifest['files']}
for row in off['originals']:
 p=E/'frozen-offline-review/originals'/row['archivePath'];check(p,row);check(p,rows[row['archivePath']])
q=read(E/'reviewed-small-assets/source-qualification.json');assert q['passed'] is True and q['sourceRevision']==source['commit'] and q['sourceTree']==source['tree'] and q['version']==source['version']
qualified=read(Q/'release-attachment-pins.json');assert {x['name']:(x['bytes'],x['sha256']) for x in qualified}=={n:(x['bytes'],x['sha256']) for n,x in expected.items()}
with zipfile.ZipFile(E/'reviewed-small-assets/source-qualification-evidence.zip') as z:
 assert len(z.infolist())==len(set(z.namelist()))==520 and sum(i.file_size for i in z.infolist())<=32*1024**2 and z.testzip() is None
nested_members=520
api=read(I/'assets-after.body');api_release=read(I/'release-after.body');hosted=read(E/'all-nine-assets.json');assert hosted['status']=='VERIFIED_RELEASE_ASSETS' and hosted['releaseId']==RELEASE and hosted['sourceCommit']==source['commit']
def descriptors(assets):
 assert len(assets)==len({a['name'] for a in assets})==9 and {a['name'] for a in assets}==set(expected)
 for a in assets:
  x=expected[a['name']];assert a['state']=='uploaded' and a['size']==x['bytes'] and a['digest']=='sha256:'+x['sha256']
 return {a['name']:{k:a[k] for k in ['id','name','size','digest','state']} for a in assets}
assets=descriptors(api);assert assets==descriptors(api_release['assets'])==descriptors(hosted['assets'])
assert api_release['id']==RELEASE and api_release['tag_name']=='v0.61.2' and api_release['draft'] is True and api_release['published_at'] is None and api_release['prerelease'] is False
before=read(D/'fresh-seven.json');assert len(before['assets'])==7 and before['id']==RELEASE
for a in before['assets']:assert assets[a['name']]['id']==a['id'] and assets[a['name']]['size']==a['size'] and assets[a['name']]['digest']==a['digest']
large={}
for name in ['source.tar','distribution.zip']:
 x=read(E/(name+'.upload-result.json'));assert x['status']=='UPLOADED_VERIFIED' and x['releaseId']==RELEASE and x['assetName']==name and x['assetId']==assets[name]['id'] and x['bytes']==expected[name]['bytes'] and x['sha256']==expected[name]['sha256'] and x['tagCommit']==source['commit'] and x['postCount']==1 and x['readBackVerified'] is True;large[name]=x
ref=read(I/'tag-ref-after.body');tag=read(I/'tag-object-after.body');assert ref==read(D/'fresh-tag-ref.json') and tag==read(D/'fresh-tag-object.json')
assert ref['object']['type']=='tag' and ref['object']['sha']==tag['sha']==TAG and tag['object']['type']=='commit' and tag['object']['sha']==source['commit']
assert git('rev-parse','HEAD').decode().strip()==source['commit'] and git('rev-parse','HEAD^{tree}').decode().strip()==source['tree'] and git('status','--porcelain','--untracked-files=no')==b''
result={'status':'UPLOAD_EVIDENCE_MATCHES_ALL_NINE_ORIGINAL_ASSETS_PENDING_ROOT_REVIEW','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runId':RUN,'attempt':1,'jobId':active[0]['id'],'workflowCommit':UTILITY,'workflowTree':ex['workflowTree'],'source':source,'releaseId':RELEASE,'tagObject':TAG,'smallEvidenceArtifact':receipt['artifact'],'retainedOriginals':m['count'],'retainedOriginalBytes':m['bytes'],'zipMembers':m['count']+1,'expandedBytes':expanded,'allManifestRowsAndZIPCRCExact':True,'nestedQualificationZIPCRCAndMembers':nested_members,'executedHelpers':helpers,'requestAndRunnerBindingExact':True,'allBoundedGETReceiptsComplete':True,'sevenSmallOriginalsExact':True,'sevenOriginalIdsPreserved':sorted(a['id'] for a in before['assets']),'uploadReceipts':large,'assets':list(assets.values()),'allNineHostedAndFreshAPIDescriptorsExact':True,'frozenSourceCleanBeforeAndAfter':True,'annotatedTagUnchanged':True,'draftAtRead':True,'remoteMutationByThisTask':False,'automaticRetry':False,'largePayloadDownloadedLocally':False,'publicAcceptance':False,'freeBytes':shutil.disk_usage(R).free,'managedBytesBeforeReport':sum(p.stat().st_size for p in R.rglob('*') if p.is_file()),'limits':['Original large payload verification happened on the hosted utility. This task downloaded only its bounded small original evidence.','Root must independently review this proposal before publishing the existing draft. Latest v0.61.1 and Pages selection have not been changed by this task.','Retention of v0.61.1, publication, Pages bytes and player/offline acceptance remain separate.'],'pins':[pin(p) for p in [R/'small-intake.reviewed.json',R/'terminal-binding-review.json',D/'binding.reviewed.json',D/'upload-request.reviewed.json',R/'reconcile-terminal.py',I/'download-receipt.json',I/'upload-originals-evidence-original.body',E/'retained-manifest.json',E/'execution.json',E/'result.json',E/'all-nine-assets.json',E/'source-before.json',E/'source-after.json',E/'source.tar.upload-result.json',E/'distribution.zip.upload-result.json',I/'release-after.body',I/'assets-after.body',I/'tag-ref-after.body',I/'tag-object-after.body']]}
write('terminal-reconciliation.proposed.json',result)
ready={'status':'READY_FOR_ROOT_UPLOAD_EVIDENCE_REVIEW','reviewed':False,'source':source,'releaseId':RELEASE,'tagObject':TAG,'tag':'v0.61.2','draftAtRead':True,'uploadRun':RUN,'allNineAssetsExact':True,'reconciliation':pin(R/'terminal-reconciliation.proposed.json'),'requiredNext':'Root independent evidence review. No retry, replacement draft, publication or Pages change is authorized by this proposal.','notEstablished':['Release publication','Latest selection','v0.61.1 retention admission','Pages deployment','Public byte/player/offline acceptance','Whole-phase completion'],'remoteMutation':False}
write('evidence-review-proposal.json',ready)
print(json.dumps({'reconciliation':pin(R/'terminal-reconciliation.proposed.json'),'proposal':pin(R/'evidence-review-proposal.json'),'status':result['status'],'zipMembers':m['count']+1,'managedBytes':sum(p.stat().st_size for p in R.rglob('*') if p.is_file()),'freeBytes':shutil.disk_usage(R).free},indent=2))
