import fs from 'node:fs/promises';
import { loadCatalog, validateAdmissions } from '../worktrees/v0612-publisher-preparation/publishing/pages-controller/assemble.mjs';
const directory=new URL('../worktrees/v0612-publisher-preparation/publishing/pages-controller/',import.meta.url).pathname;
const {lock,metadata,catalogSha256}=await loadCatalog(directory);
const configuration=JSON.parse(await fs.readFile(directory+'/publication.json'));
if(lock.releases.length!==83||configuration.catalogSha256!==catalogSha256)throw Error('Catalog binding failed');
const verified=await validateAdmissions({directory,configuration,metadata:new Map([['v0.61.2',metadata.get('v0.61.2')]]),requireBrowser:true});
if(verified.qualification.sourceRevision!=='bb5e6e7787bf81232368b96845d716a808c21309'||verified.qualification.sourceTree!=='d8b19e99b762b1c4ac974118abc59935f6ca8e3a')throw Error('Wrong qualification');
console.log(JSON.stringify({status:'PASS_CURRENT_SOURCE_AND_ALL_METADATA_CHAINS',catalogRecords:lock.releases.length,metadataChains:metadata.size,source:verified.qualification.sourceRevision,tree:verified.qualification.sourceTree,unchangedAdmissions:23,scope:'Current qualification and all metadata byte chains validated. Prior 23 archive admissions are unchanged and rehashed from base Git, not rehydrated here. Full admission and assembly remain hosted preview gates.'},null,2));
