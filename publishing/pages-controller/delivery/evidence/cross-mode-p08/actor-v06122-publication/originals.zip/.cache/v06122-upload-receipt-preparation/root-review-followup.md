# Actual terminal and pre-download reservation successor

Root actual terminal originals were adopted byte-for-byte locally. No network calls were made. The two original UTILITY_BINDING log objects equal the canonical reviewed binding, including the original carrier. All nine draft descriptors match. The proposed request remains reviewed:false.

Use the final `intake.py` with `intake-bounds-r2.diff`; the earlier diff and before-preflight source are preserved. Before the first metadata GET, and again immediately before the body GET, it reserves actual compressed bytes +12MiB expanded ceiling +4MiB bounded metadata/stderr/reconciliation allowance against32MiB cumulative managed bytes and512MiB free reserve. At actual9,959,878B compressed this is26,737,094B before existing files and reserve cushion.

Both ZIP validators contain a Python two-character source escape that evaluates to ONE backslash. The one-backslash unsafe member test passes in each helper. Existing inline extraction check is also retained. Fourteen offline tests pass; initial twelve-test output is preserved. No receipt GET, helper network execution, source change or build took place.

The observer's terminal snapshot is an explicitly labeled local adoption of root originals, so it refuses repeat terminal collection. Root should promote only a reviewed copy of `small-intake.proposed.json`, execute `intake.py` once, create an owned empty reconciliation directory, and run `reconcile.bound.py` from repository root. The unbound reconciler and pending request remain preserved.
