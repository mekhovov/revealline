"""Bounded local-only independent verification of root-retained small evidence."""
from pathlib import Path, PurePosixPath
import datetime, hashlib, json, os, shutil, subprocess, zipfile, stat
R=Path.cwd();O=R/'.cache/v06122-upload-receipt-preparation/reconciliation'
U='ef491211488b1c06f00ad2efbeb4fb23bbae39b8';UT='ec21fa39dd49045d90ccc2f8e540ab23b4fbba51'
sha=lambda x:hashlib.sha256(x).hexdigest()
def read(p): return json.loads(p.read_text())
def pin(p):
 raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':sha(raw)}
def check(p,row):
 assert p.is_file() and not p.is_symlink(),str(p)
 x=pin(p);assert (x['bytes'],x['sha256'])==(row['bytes'],row['sha256']),str(p);return x
def git(w,*a):return subprocess.check_output(['git','-C',str(w),*a],env={**os.environ,'GIT_NO_LAZY_FETCH':'1'},timeout=30)
def write(p,value):
 raw=(json.dumps(value,indent=2)+'\n').encode();assert not p.exists()
 assert sum(x.stat().st_size for x in O.rglob('*') if x.is_file())+len(raw)<1024**2
 assert shutil.disk_usage(O).free-len(raw)>=512*1024**2;p.write_bytes(raw)
def validate_receipt_members(infos):
 assert 0 < len(infos) == len({i.filename for i in infos}) <= 256, 'Receipt member count/uniqueness limit'
 assert sum(i.file_size for i in infos) <= 12*1024**2, 'Receipt expanded limit'
 for i in infos:
  assert 0 <= i.file_size <= 10*1024**2, 'Receipt single-member limit'
  n=PurePosixPath(i.filename)
  assert not n.is_absolute() and '..' not in n.parts and '\\' not in i.filename and stat.S_IFMT(i.external_attr>>16) in [0,stat.S_IFREG] and not i.is_dir() and not i.flag_bits&1, 'Unsafe receipt member'

configs=[{'version': 'v0.61.22', 'source': '17e0a455f76c3f4a72f2e596397a0e73463335a5', 'tree': 'e8a544161dc23e67995f21d6bc20d268e4174120', 'base': '.cache/v06122-upload-receipt-preparation', 'observer': '.cache/v06122-upload-receipt-preparation/observation', 'wt': '.cache/worktrees/p08-actor-minimum-next', 'request': '.cache/v06122-release-preparation/upload-request.reviewed.json', 'requestSHA': '91b7e38324af80a924a3405c36204b8014356d692c241653006d3402a3550b56', 'run': 35389188892, 'attempt': 1, 'job': 105743292683, 'small': 10565710108, 'smallBytes': 9959878, 'smallSHA': 'ad144b3db83021afa1aa801ea7e6b5865fee213fec21da2c39332e1ef784b3ca', 'operation': 'upload-originals', 'release': 391751801, 'package': '.cache/p08-actor-minimum-next/source-qualification-v06122-r3/observer'}]
for c in configs:
 for key in ['run','attempt','job','small','smallBytes','release']:
  assert type(c[key]) is int and c[key]>0, 'UNBOUND actual '+key
 for key in ['requestSHA','smallSHA']:
  assert type(c[key]) is str and len(c[key])==64 and all(x in '0123456789abcdef' for x in c[key]), 'UNBOUND actual '+key
 assert c['operation']=='upload-originals', 'This successor requires actual upload authority'
 B=R/c['base'];W=R/c['wt'];I=B/'root-small-intake-r1';E=I/'evidence';V=R/c['observer']
 assert sum(p.stat().st_size for p in B.rglob('*') if p.is_file())<32*1024**2
 assert shutil.disk_usage(B).free>=512*1024**2
 requestPath=R/c['request'];assert pin(requestPath)['sha256']==c['requestSHA'];req=read(requestPath)
 b=json.loads(req['inputs']['artifact_binding']);assert b==read(E/'binding.json') and b['reviewed'] is True
 source={'commit':c['source'],'tree':c['tree'],'version':c['version']};assert b['source']==source
 assert req['inputs']['operation']==c['operation'] and req['inputs']['freeze_snapshot'] is False
 receipt=read(I/'receipt.json');assert receipt['source']==source and receipt['runId']==c['run'] and receipt['jobId']==c['job']
 assert receipt['originalBodyGets']==1 and receipt['largePayloadDownload'] is False
 assert receipt['artifact']=={'id':c['small'],'bytes':c['smallBytes'],'sha256':c['smallSHA']}
 assert c['smallBytes'] <= 12*1024**2, 'Compressed receipt limit'
 zp=I/'original-receipt.zip';check(zp,receipt['artifact'])
 actual={str(p.relative_to(E)) for p in E.rglob('*') if p.is_file()}
 assert actual=={r['path'] for r in receipt['files']}
 for row in receipt['files']:check(E/row['path'],row)
 with zipfile.ZipFile(zp) as z:
  validate_receipt_members(z.infolist())
  assert len(z.infolist())==len(set(z.namelist()))==len(actual) and set(z.namelist())==actual
  assert z.testzip() is None and sum(i.file_size for i in z.infolist())==receipt['expandedBytes']<=12*1024**2
  for n in z.namelist():
   path=PurePosixPath(n);assert not path.is_absolute() and '..' not in path.parts and z.read(n)==(E/n).read_bytes()
 m=read(E/'retained-manifest.json');prefix='/home/runner/work/revealline/revealline/utility-output/evidence/';rels=[]
 for row in m['files']:
  assert row['path'].startswith(prefix);rel=row['path'][len(prefix):];check(E/rel,row);rels.append(rel)
 assert len(rels)==len(set(rels))==m['count'] and actual==set(rels)|{'retained-manifest.json'} and sum(x['bytes'] for x in m['files'])==m['bytes']
 obs=read(sorted((V/'snapshots').glob('*/observation.json'))[-1]);run=read(Path(obs['run']['path']));jobs=read(Path(obs['jobs']['path']))['jobs']
 assert run['id']==c['run'] and run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==U and run['run_attempt']==c['attempt']
 active=[j for j in jobs if j['conclusion']!='skipped'];assert len(active)==1 and active[0]['id']==c['job'] and active[0]['name']==c['operation'] and active[0]['conclusion']=='success'
 log=next((V/'snapshots').glob('*/job-'+str(c['job'])+'-original-log.body'));bindings=[]
 for line in log.read_text().splitlines():
  if 'UTILITY_BINDING:' in line and '"format"' in line:
   try:bindings.append(json.loads(line.split('UTILITY_BINDING:',1)[1]))
   except json.JSONDecodeError:pass
 assert len(bindings)==2 and all(x==b for x in bindings)
 ex=read(E/'execution.json');assert ex['workflowSha']==U and ex['workflowTree']==UT and int(ex['runId'])==c['run'] and ex['runAttempt']==str(c['attempt'])
 expectedCheckout={'sourceRevision':c['source'],'sourceTree':c['tree'],'trackedCheckoutClean':True}
 assert read(E/'source-before.json')==read(E/'source-after.json')==ex['sourceCheckout']==expectedCheckout
 helpers=[]
 for h in ex['helpers']:
  p=h['path'].split('/automation/',1)[1];raw=git(W,'show',U+':'+p)
  assert len(raw)==h['bytes'] and sha(raw)==h['sha256'] and raw==git(W,'show',c['source']+':'+p);helpers.append({'path':p,'bytes':len(raw),'sha256':sha(raw)})
 assert len(helpers)==len({h['path'] for h in helpers})==9 and git(W,'rev-parse',U+'^{tree}').decode().strip()==UT
 result=read(E/'result.json');assert result['source']==source and result['artifact']==b['artifact'] and result['operation']==c['operation'] and result['automaticRetry'] is False
 assert result['status']==('ALL_NINE_VERIFIED' if c['release'] else 'INSPECTED_VERIFIED')
 ar=read(E/'artifact-authority.json');a=b['artifact'];assert ar['id']==a['id'] and ar['size_in_bytes']==a['bytes'] and ar['digest']=='sha256:'+a['sha256'] and ar['workflow_run']['id']==a['runId'] and ar['workflow_run']['head_sha']==c['source'] and ar['expired'] is False
 dl=read(E/'qualified-artifact-original.download.json');assert dl['status']=='ORIGINAL_RECEIVED_VERIFIED' and dl['bytes']==a['bytes'] and dl['sha256']==a['sha256'] and dl['automaticRetry'] is False
 q=E/'qualified-artifact-verified';ins=read(q/'inspection.json');manifest=read(q/'manifest.json');release=read(q/'release.json')
 assert ins['status']=='PASS' and ins['gitHead']==c['source'] and ins['gitTree']==c['tree'] and ins['version']==c['version'] and ins['releaseHashChainVerified'] is True
 assert ins['artifact']['bytes']==a['bytes'] and ins['artifact']['sha256']==a['sha256']
 assert ins['manifestSha256']==pin(q/'manifest.json')['sha256']==release['manifestSha256'] and manifest['sourceRevision']==c['source']
 assert release['sourceRevision']==c['source'] and release['sourceArchiveSha256']==ins['sourceTar']['sha256'] and release['distributionSha256']==ins['distribution']['sha256']
 rows={x['path']:x for x in manifest['files']};assert len(rows)==len(manifest['files'])==ins['distribution']['files']
 off=read(E/'frozen-offline-review/review.json');assert off['status']=='PASS' and off['sourceRevision']==c['source'] and off['sourceTree']==c['tree']
 for k,p in [('inspectionPin',q/'inspection.json'),('manifestPin',q/'manifest.json'),('downloadPin',E/'qualified-artifact-original.download.json')]:check(p,off[k])
 for row in off['originals']:
  p=E/'frozen-offline-review/originals'/row['archivePath'];check(p,row);check(p,rows[row['archivePath']])
 assert all(off['offline'][k] is True for k in ['allOfflineRowsMatchFrozenManifest','allOfflineBytesVerified','offlineBudgetVerified','workerInventoryBindingVerified','entryMetaBindingVerified','entryIncluded'])
 assets=[];nested=None;uploads=[]
 if c['release']:
  expected={a['name']:a for a in b['release']['assets']};assert len(expected)==9 and b['release']['id']==c['release']
  hosted=read(E/'all-nine-assets.json');assert hosted['status']=='VERIFIED_RELEASE_ASSETS' and hosted['releaseId']==c['release'] and hosted['sourceCommit']==c['source']
  assert len(hosted['assets'])==len({a['name'] for a in hosted['assets']})==9
  for a in hosted['assets']:
   n=a['name'];x=expected[n];assert a['size']==x['bytes'] and a['digest']=='sha256:'+x['sha256'] and a['state']=='uploaded';assets.append({k:a[k] for k in ['id','name','size','digest','state']})
  assert {a['name'] for a in assets}==set(expected)
  P=W/c['package'];package=read(P/'release-attachment-pins.json');assert {x['name']:(x['bytes'],x['sha256']) for x in package}=={n:(x['bytes'],x['sha256']) for n,x in expected.items()}
  for n in set(expected)-{'source.tar','distribution.zip'}:
   check(E/'reviewed-small-assets'/n,expected[n]);assert (E/'reviewed-small-assets'/n).read_bytes()==(P/'release-attachments'/n).read_bytes()
  for n in ['manifest.json','release.json','distribution.zip.sha256']:assert (q/n).read_bytes()==(E/'reviewed-small-assets'/n).read_bytes()
  sq=read(E/'reviewed-small-assets/source-qualification.json');assert sq['passed'] is True and sq['sourceRevision']==c['source'] and sq['sourceTree']==c['tree']
  for n,k in [('source.tar','sourceTar'),('distribution.zip','distribution')]:
   x=read(E/(n+'.upload-result.json'));a=next(a for a in assets if a['name']==n);assert x['status']=='UPLOADED_VERIFIED' and x['releaseId']==c['release'] and x['assetId']==a['id'] and x['assetName']==n and x['bytes']==expected[n]['bytes'] and x['sha256']==expected[n]['sha256'] and x['tagCommit']==c['source'] and x['postCount']==1 and x['readBackVerified'] is True
   assert ins[k]['bytes']==expected[n]['bytes'] and ins[k]['sha256']==expected[n]['sha256'];uploads.append(x)
  with zipfile.ZipFile(E/'reviewed-small-assets/source-qualification-evidence.zip') as z:
   assert len(z.infolist())==len(set(z.namelist())) and sum(i.file_size for i in z.infolist())<32*1024**2 and z.testzip() is None;nested=len(z.infolist())
 else:assert b['release'] is None
 assert git(W,'rev-parse','HEAD').decode().strip()==c['source'] and git(W,'rev-parse','HEAD^{tree}').decode().strip()==c['tree'] and git(W,'status','--porcelain','--untracked-files=no')==b''
 out={'status':'INDEPENDENT_LOCAL_RECEIPT_RECONCILIATION_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'runId':c['run'],'jobId':c['job'],'operation':c['operation'],'originals':m['count'],'zipMembers':len(actual),'expandedBytes':receipt['expandedBytes'],'allZIPMembersCRCPinsExact':True,'requestAndTwoLoggedBindingsExact':True,'executedHelpers':helpers,'sourceCleanBeforeAfterAndLocal':True,'frozenInspection':ins,'frozenOfflineReview':off,'allNineHostedAssets':assets,'uploadReceipts':uploads,'sevenSmallAssetsMatchOriginalPackage':bool(c['release']),'nestedQualificationZIPMembers':nested,'pins':[pin(p) for p in [requestPath,I/'receipt.json',zp,E/'retained-manifest.json',E/'execution.json',E/'result.json',E/'source-before.json',E/'source-after.json',q/'inspection.json',q/'manifest.json',q/'release.json',E/'frozen-offline-review/review.json',log,Path(obs['run']['path']),Path(obs['jobs']['path'])]],'limits':['No network requests or remote mutation by this review. Only root-retained small original bytes were read.','Original large payload was verified by hosted utility, not downloaded locally.','Frozen offline byte authority does not claim actual browser offline playback.','Fresh draft/tag API readback, release publication and public acceptance remain root-owned separate gates.']}
 write(O/(c['version']+'-reconciliation.json'),out);print(json.dumps({'version':c['version'],'result':pin(O/(c['version']+'-reconciliation.json')),'originals':m['count'],'members':len(actual),'nested':nested}))
