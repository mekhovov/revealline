from pathlib import Path,PurePosixPath
import subprocess as s,json,hashlib,zipfile,stat,datetime,selectors,os,time,shutil,sys
def validate_receipt_artifact(a):
 assert type(a['id']) is int and a['id'] > 0, 'UNBOUND actual artifact ID'
 assert type(a['bytes']) is int and 0 < a['bytes'] <= 12*1024**2, 'UNBOUND or oversized compressed receipt'
 assert type(a['sha256']) is str and len(a['sha256']) == 64 and all(x in '0123456789abcdef' for x in a['sha256']), 'UNBOUND actual artifact digest'

def validate_receipt_members(infos):
 assert 0 < len(infos) == len({i.filename for i in infos}) <= 256, 'Receipt member count/uniqueness limit'
 assert sum(i.file_size for i in infos) <= 12*1024**2, 'Receipt expanded limit'
 for i in infos:
  assert 0 <= i.file_size <= 10*1024**2, 'Receipt single-member limit'
  n=PurePosixPath(i.filename)
  assert not n.is_absolute() and '..' not in n.parts and '\\' not in i.filename and stat.S_IFMT(i.external_attr>>16) in [0,stat.S_IFREG] and not i.is_dir() and not i.flag_bits&1, 'Unsafe receipt member'

qpath=Path(sys.argv[1]).resolve();q=json.loads(qpath.read_text());assert q['reviewed'] is True
validate_receipt_artifact(q['artifact'])
P=qpath.parent; D=P/'root-small-intake-r1'; D.mkdir(); ATTEMPTS=D/'attempts'; ATTEMPTS.mkdir();request_index=0
sha=lambda b:hashlib.sha256(b).hexdigest()
def check_owned_output(path,owner):
 path,owner=Path(path),Path(owner);assert path.is_relative_to(owner) and '..' not in path.parts and not any(x.is_symlink()for x in [path,*path.parents]);return path
def objput(path,value):
 raw=(json.dumps(value,indent=2)+'\n').encode()
 with Path(path).open('xb')as f:f.write(raw)
def guard_growth(extra):
 assert sum(p.stat().st_size for p in P.rglob('*') if p.is_file()) + extra <= 32*1024**2
 assert shutil.disk_usage(P).free >= 512*1024**2 + extra + 65536
def guard_receipt_download(compressed_bytes):
 # Reserve full permitted expansion plus bounded API, stderr and review output.
 guard_growth(compressed_bytes + 12*1024**2 + 4*1024**2)
def request(path, limit, timeout, destination=None):
 """One finite GET, preserving capped original streams and explicit failure receipts."""
 global request_index
 assert path.startswith('repos/mekhovov/revealline/') and timeout <= 60
 request_index+=1
 prefix=ATTEMPTS/f'request-{request_index:02d}'
 out=destination if destination is not None else prefix.with_suffix('.stdout')
 err=prefix.with_suffix('.stderr');receipt_path=prefix.with_suffix('.json')
 for output in [out,err,receipt_path]:check_owned_output(output,D)
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
 argv=['gh','api','--method','GET',path];proc=None;selector=selectors.DefaultSelector();failure=None
 records={name:{'path':str(p),'limit':cap,'observedBytes':0,'observedHash':hashlib.sha256(),'storedBytes':0,'eof':False}
          for name,p,cap in [('stdout',out,limit),('stderr',err,1000000)]}
 with out.open('xb') as stdout_file,err.open('xb') as stderr_file:
  files={'stdout':stdout_file,'stderr':stderr_file}
  try:
   proc=s.Popen(argv,stdout=s.PIPE,stderr=s.PIPE)
   for name,pipe in [('stdout',proc.stdout),('stderr',proc.stderr)]:
    os.set_blocking(pipe.fileno(),False);selector.register(pipe,selectors.EVENT_READ,name)
   while selector.get_map():
    remaining=timeout-(time.monotonic()-start)
    if remaining<=0:raise TimeoutError('request deadline exceeded')
    for key,_ in selector.select(min(remaining,0.25)):
     name=key.data;rec=records[name];chunk=os.read(key.fileobj.fileno(),65536)
     if not chunk:
      rec['eof']=True;selector.unregister(key.fileobj);continue
     rec['observedBytes']+=len(chunk);rec['observedHash'].update(chunk)
     kept=chunk[:max(0,rec['limit']-rec['storedBytes'])]
     guard_growth(len(kept));files[name].write(kept);rec['storedBytes']+=len(kept)
     if rec['observedBytes']>rec['limit']:raise ValueError(name+' response exceeded retained-prefix bound')
   proc.wait(timeout=max(0.001,timeout-(time.monotonic()-start)))
   if proc.returncode!=0:raise RuntimeError('gh API exited '+str(proc.returncode))
  except (Exception,KeyboardInterrupt) as exc:
   failure={'type':type(exc).__name__,'message':str(exc)}
  finally:
   if proc is not None and proc.poll() is None:
    proc.kill()
    try:proc.wait(timeout=2)
    except s.TimeoutExpired:
     failure=failure or {'type':'CleanupTimeout','message':'Killed child did not terminate within 2 seconds'}
   selector.close()
   if proc is not None:
    proc.stdout.close();proc.stderr.close()
 streams={}
 for name,rec in records.items():
  raw=Path(rec['path']).read_bytes()
  streams[name]={'path':rec['path'],'bytes':len(raw),'sha256':sha(raw),
   'observedBytes':rec['observedBytes'],'observedCapturedSha256':rec['observedHash'].hexdigest(),
   'endOfStreamObserved':rec['eof'],'truncated':rec['observedBytes']>rec['storedBytes'],
   'completeOriginal':rec['eof'] and rec['observedBytes']==rec['storedBytes']}
 receipt={'status':'FAILED_ATTEMPT' if failure else 'COMPLETE_RESPONSE_ONLY','request':{'method':'GET','path':path},
  'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'timeoutSeconds':timeout,'elapsedSeconds':time.monotonic()-start,'exitCode':None if proc is None else proc.returncode,
  'failure':failure,'streams':streams,'automaticRetry':False,
  'scope':'Captured stream hashes cover observed bytes only; partial prefixes are not full originals or inspection PASS.'}
 objput(receipt_path,receipt)
 if failure:raise RuntimeError('GET failed; retained attempt: '+str(receipt_path))
 return None if destination is not None else out.read_bytes()

for r in [q['terminalBindingReview'],*q['originalPins']]:
 raw=Path(r['path']).read_bytes();assert len(raw)==r['bytes'] and sha(raw)==r['sha256']
a=q['artifact'];guard_receipt_download(a['bytes']);raw=request('repos/mekhovov/revealline/actions/artifacts/'+str(a['id']),1000000,60);actual=json.loads(raw)
assert actual['id']==a['id'] and actual['size_in_bytes']==a['bytes'] and actual['digest']=='sha256:'+a['sha256'] and not actual['expired'] and actual['workflow_run']['id']==q['runId'] and actual['workflow_run']['head_sha']==q['utility']['commit']
zpath=D/'original-receipt.zip';guard_receipt_download(a['bytes']);request('repos/mekhovov/revealline/actions/artifacts/'+str(a['id'])+'/zip',a['bytes'],60,destination=zpath)
raw=zpath.read_bytes();assert len(raw)==a['bytes'] and sha(raw)==a['sha256'];E=D/'evidence';E.mkdir();rows=[]
with zipfile.ZipFile(zpath)as z:
 infos=z.infolist();validate_receipt_members(infos)
 guard_growth(sum(i.file_size for i in infos)+65536)
 for i in infos:
  n=PurePosixPath(i.filename);assert not n.is_absolute() and '..'not in n.parts and '\\'not in i.filename and stat.S_IFMT(i.external_attr>>16)in[0,stat.S_IFREG] and not i.is_dir() and not i.flag_bits&1
  b=z.read(i);assert len(b)==i.file_size;f=E/str(n);check_owned_output(f,D);f.parent.mkdir(parents=True,exist_ok=True)
  with f.open('xb')as out:out.write(b)
  rows.append({'path':str(n),'bytes':len(b),'sha256':sha(b)})
receipt={'status':'ROOT_RECEIVED_ORIGINAL_SMALL_RECEIPT','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifact':a,'source':q['source'],'runId':q['runId'],'jobId':q['jobId'],'files':rows,'originalBodyGets':1,'expandedBytes':sum(r['bytes']for r in rows),'requestSha256':sha(qpath.read_bytes()),'helperSha256':sha(Path(__file__).read_bytes()),'largePayloadDownload':False,'semanticAcceptancePending':True};objput(D/'receipt.json',receipt);print(json.dumps({k:v for k,v in receipt.items()if k!='files'},indent=2))
