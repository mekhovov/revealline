from helpers import *
import datetime,re,difflib
F=D/'delivery/evidence/cross-mode-p08/versus-v0616-publication'
assert sha((admin/'index').read_bytes())==json.loads((P/'baseline.json').read_bytes())['indexSha256']
for n in ['node20','node22']:
 t=(P/'checks-r1'/(n+'.stdout')).read_text();assert '# tests 43' in t and '# pass 43' in t and '# fail 0' in t
assert 'Ran 4 tests' in (P/'checks-r1/python.stderr').read_text() and '\nOK\n' in (P/'checks-r1/python.stderr').read_text()
assert all(r['exit']==0 for r in json.loads((P/'checks-r1/results.json').read_bytes()))
for n in ['sync-r2','verify-local-candidate','diff-check']:assert json.loads((P/(n+'.receipt.json')).read_bytes())['exit']==0
assert json.loads((P/'sync.receipt.json').read_bytes())['exit']==1
pub=json.loads((D/'publication.json').read_bytes());oldpub=json.loads(subprocess.check_output(['git','-C',str(W),'show',base+':publishing/pages-controller/publication.json']))
assert len(pub['admissions'])==25 and pub['admissions'][:-1]==oldpub['admissions']
A=R/'.cache/archive25-v0615-main-admission'
for row in json.loads((A/'candidate-pins.json').read_bytes())['records']:
 b=(D/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert pub['admissions'][-1]==json.loads((A/'admission.proposed.json').read_bytes())
alloc=json.loads((D/'allocations.json').read_bytes());assert alloc['shards'][-1]==json.loads((A/'allocation.proposed.json').read_bytes())
for row in json.loads((P/'documentation-preparation.json').read_bytes())['copies']:
 b=(W/row['destination']).read_bytes();assert b==Path(row['path']).read_bytes() and len(b)==row['bytes'] and sha(b)==row['sha256']
selection=[p for p in (P/'checks-r1').rglob('*')if p.is_file() and 'tmp' not in p.parts]
for n in ['baseline.json','sparse-paths.txt','archive-adoption.json','helpers.py','sync-published-originals.mjs','sync.stdout','sync.stderr','sync.receipt.json','sync-r2.stdout','sync-r2.stderr','sync-r2.receipt.json','import-closure-correction.json','run-checks.py','verify-local-candidate.mjs','verify-local-candidate.stdout','verify-local-candidate.stderr','verify-local-candidate.receipt.json','diff-check.stdout','diff-check.stderr','diff-check.receipt.json','verify-preservation.py','prior-preservation.json','documentation-preparation.json','seal-candidate.py']:selection.append(P/n)
bundle(F/'preparation',selection)
tracked=subprocess.check_output(['git','-C',str(W),'diff','--name-only'],text=True).splitlines()
assert set(tracked)=={'.cursor/skills/deploy-release-pages/SKILL.md','publishing/pages-controller/README.md','publishing/pages-controller/delivery/README.md','publishing/pages-controller/allocations.json','publishing/pages-controller/catalog.json','publishing/pages-controller/publication.json'}
newroots=[F,D/'evidence/archive-25/initial-v0615',D/'evidence/current-v0616',D/'metadata/v0.61.6']
files=sorted(set([W/p for p in tracked]+[p for root in newroots for p in root.rglob('*')if p.is_file()]))
for p in files:
 assert p.is_relative_to(W) and not any(x.is_symlink()for x in [p,*p.parents]) and p.stat().st_size<8*1024**2
 if p.suffix=='.json':json.loads(p.read_bytes())
bundles=[]
for dest in [F/'preparation',D/'evidence/archive-25/initial-v0615']:
 idx=json.loads((dest/'originals-index.json').read_bytes());raw=(dest/'originals.zip').read_bytes();assert len(raw)==idx['zip']['bytes'] and sha(raw)==idx['zip']['sha256']
 with zipfile.ZipFile(io.BytesIO(raw))as z:
  assert z.testzip()is None and len(z.infolist())==len(idx['files'])
  for row in idx['files']:
   b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256'];assert (R/row['path']).read_bytes()==b
 bundles.append({'path':str(dest.relative_to(W)),'members':len(idx['files']),'bytes':len(raw),'sha256':sha(raw)})
links=0;newdocs=[F/'README.md',F/'planning/progress-and-next.md',D/'evidence/current-v0616/README.md']
for p in [*newdocs,D/'README.md',D/'delivery/README.md']:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if ':'in target or target.startswith('#'):continue
  target=target.split('#')[0]
  if not target:continue
  dest=(p.parent/target).resolve();rel=dest.relative_to(W).as_posix()
  if not dest.exists():assert subprocess.run(['git','-C',str(W),'cat-file','-e',base+':'+rel],capture_output=True).returncode==0,(p,target)
  links+=1
before=json.loads((P/'root-before.json').read_bytes());assert subprocess.check_output(['git','status','--porcelain','-z']).hex()==before['status']
assert sha((R/'.git/index').read_bytes())==before['indexSha256']
assert sha(subprocess.check_output(['git','diff','--binary']))==before['workdiff']
assert sha(subprocess.check_output(['git','diff','--cached','--binary']))==before['cachedDiff']
assert sha((R/'.git/config').read_bytes())==before['commonConfig']
rows=[pin(p,W)for p in files]
obj(P/'candidate-pins.json',{'format':'revealline-reviewed-candidate-paths.v1','base':base,'worktree':str(W),'files':rows,'totalBytes':sum(r['bytes']for r in rows),'indexUnchanged':True,'stageOrCommitPerformed':False})
obj(P/'original-bundles-check.json',{'status':'PASS_ALL_ZIP_CRC_ROWS_CURRENT_ORIGINALS','bundles':bundles,'localLinksResolved':links,'elevenOriginalCopiesExact':True,'rootStatusIndexAndDiffsUnchanged':True,'commonConfigUnchanged':True})
put(P/'reviewed-hunks.diff',subprocess.check_output(['git','-C',str(W),'diff','--no-ext-diff','--unified=5']))
put(P/'new-documentation.diff',''.join(''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile=p.relative_to(W).as_posix()))for p in newdocs))
put(P/'status-before-review.txt',subprocess.check_output(['git','-C',str(W),'status','--porcelain','--untracked-files=all']))
assert sha((admin/'index').read_bytes())==json.loads((P/'baseline.json').read_bytes())['indexSha256']
put(P/'pr-body.md',"""Select published v0.61.6, which preserves the complete Versus arena and artwork at constrained window sizes. Bind the original qualified source `4fd8e2dac4fdc851d0d2bf0b21e77162d9d405c9` and all nine immutable release assets. Preserve all 86 previous catalog records and 24 archive admissions; append accepted Archive25 retention of v0.61.5 (700 files / 313,375,639 bytes).

The new archive has zero previously accepted paths. Retain the original informational report that incorrectly said 697, its explicit correction and independent complete row proof. Add the small release-skill rule to derive initial/append counts from the actual inventory and preserve narrative corrections without repeating payload requests.

Validation: 43 publisher tests on each of Node 20.19.5 and Node 22.22.2, four Python tests, 87 metadata chains, exact current qualification and the new archive admission. Rehashed 906 prior bodies from Git without hydration; checked the eleven original publication records, ZIP CRC/member pins, relative links and untouched root/index. The first local sync refused two absent sparse imports before any output; exact tracked dependencies were added and the unchanged sync then passed. No game/version or publisher-helper changes.

v0.61.5 remains the accepted public baseline. Hosted full filesystem preview/assembly, Pages deployment, complete v0.61.6 public byte verification and native Versus geometry/navigation remain required. Physical-device/controller, offline/media and parent-phase acceptance remain open.
""")
used=sum(q.stat().st_size for d in [W,P,admin]for q in d.rglob('*')if q.is_file()and not q.is_symlink());free=shutil.disk_usage(R).free;assert used<32*1024**2 and free>=512*1024**2
ready={'status':'READY_FOR_ROOT_HUNK_REVIEW_NOT_STAGED','preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':'codex/v0616-pages-preparation','base':base,'baseTree':json.loads((P/'baseline.json').read_bytes())['baseTree'],'worktree':str(W),'manifest':pin(P/'candidate-pins.json',R),'hunks':pin(P/'reviewed-hunks.diff',R),'newDocumentation':pin(P/'new-documentation.diff',R),'prBody':pin(P/'pr-body.md',R),'source':{'version':'v0.61.6','commit':'4fd8e2dac4fdc851d0d2bf0b21e77162d9d405c9','tree':'d16edac0127fc96139445ae2365cc74499f80921','tagObject':'e8c11ea668e40028e650eec42bdd004f3f7e607c','releaseId':391439978,'qualificationSha256':'65101af99081508d016ae6e8596449438117bc404a45e40a459a4165b40e34e1'},'archive25':{'commit':'70eb8242670ab7e3518b2f8266ca07fef51ecf5c','tree':'5cfd357722dc7aafdae831d8b7bb45eb3c3bbb62','deploymentId':6523753253,'versions':['v0.61.5'],'files':700,'bytes':313375639,'priorCanonicalRows':0,'adoption':pin(P/'archive-adoption.json',R)},'checks':{'node20':43,'node22':43,'python':4,'allMetadataChains':87,'currentSourceAndChangedAdmission':True,'diffCheck':True,'indexUntouched':True},'preservation':pin(P/'prior-preservation.json',R),'originalBundles':pin(P/'original-bundles-check.json',R),'priorCatalogRecordsUnchanged':86,'priorAdmissionsUnchanged':24,'totalAdmissions':25,'acceptedPublicBaseline':'v0.61.5','v616PagesAccepted':False,'phaseAccepted':False,'stageOrCommitPerformed':False,'remoteMutationPerformed':False,'bodyGETs':0,'gameVersionOrPublisherHelperChanges':False,'skillChanged':True,'correctedShippedWorkshopScopePreserved':True,'managedBytesBeforeReady':used,'managedCapBytes':33554432,'freeBytes':free,'reserveBytes':536870912,'remaining':['Root reviews exact paths and hunks, stages only these paths and commits.','Hosted full filesystem publisher assembly/preview, main integration and protected Pages deployment.','Verify deployment identity and complete public bytes; execute native Versus artwork/arena/window/navigation checks.','Keep physical input/device, offline/media and parent phases open.'],'metadataProvenance':'Retained original metadata matched all nine published, Latest and upload-reconciliation descriptors without repeat downloads.','retainedPreparationRefusal':'Initial sync failed on two missing sparse imports before writing; exact base imports hydrated and unchanged helper passed.'}
obj(P/'ready.json',ready)
print(json.dumps({'ready':pin(P/'ready.json',R),'manifest':pin(P/'candidate-pins.json',R),'paths':len(rows),'candidateBytes':sum(r['bytes']for r in rows),'managedBytes':used,'freeBytes':free,'bundleMembers':[x['members']for x in bundles]}))
