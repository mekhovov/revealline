import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { syncReleaseMetadata } from '../worktrees/v0618-publisher-preparation/publishing/pages-controller/sync-release-metadata.mjs';
const sha = b => createHash('sha256').update(b).digest('hex');
const read = async name => JSON.parse(await fs.readFile(new URL('../v0618-release-preparation/root-publish-r1/' + name, import.meta.url)));
const publication = await read('after-release.json');
const latest = await read('after-latest.json');
const before = await read('before-release.json');
const reviewed = await read('completion.json');
const tag = await read('before-tag.json');
const tagObject = await read('before-tag-object.json');
const source = '0ae4330b8a87d332051db112f5e09b7c3cbef9fa';
if (publication.id !== 391546102 || latest.id !== publication.id || publication.tag_name !== 'v0.61.8' || latest.tag_name !== publication.tag_name || publication.draft || publication.prerelease || latest.draft || latest.prerelease || reviewed.status !== 'PUBLISHED_ORIGINALS_LATEST_READBACK_PASS' || reviewed.source !== source) throw Error('Publication not bound');
if (tag.object.sha !== 'd6b9a83d1364c81f23251fae4c3d30241b2e36df' || tag.object.type !== 'tag' || tagObject.sha !== tag.object.sha || tagObject.object.sha !== source || tagObject.object.type !== 'commit') throw Error('Tag identity differs');
const reconciliation = JSON.parse(await fs.readFile(new URL('../v0618-upload-receipt-preparation/reconciliation/v0.61.8-reconciliation.json', import.meta.url)));
if (reconciliation.source.commit !== source || reconciliation.source.tree !== 'bea7eebf35befcae0362b19f7ecfbb75a3942b00' || reconciliation.status !== 'INDEPENDENT_LOCAL_RECEIPT_RECONCILIATION_PASS') throw Error('Reconciliation differs');
const fields = a => ({ id: a.id, name: a.name, size: a.size, digest: a.digest, state: a.state });
const sorted = xs => xs.map(fields).sort((a, b) => a.name.localeCompare(b.name));
const assets = sorted(publication.assets);
for (const asset of publication.assets) {
  if (asset.browser_download_url !== 'https://github.com/mekhovov/revealline/releases/download/v0.61.8/' + encodeURIComponent(asset.name)) throw Error('Published asset URL is not canonical: ' + asset.name);
}
if (assets.length !== 9 || new Set(assets.map(a => a.name)).size !== 9 || !assets.every(a => a.state === 'uploaded')) throw Error('Expected exactly nine uploaded assets');
for (const previous of [before.assets, latest.assets, reconciliation.allNineHostedAssets]) {
  if (JSON.stringify(sorted(previous)) !== JSON.stringify(assets)) throw Error('Original asset identities changed');
}
const result = await syncReleaseMetadata({ versions: ['v0.61.8'], qualificationVersion: 'v0.61.8', download: async (version, name) => {
  if (version !== 'v0.61.8' || !['release.json', 'manifest.json', 'distribution.zip.sha256', 'source-qualification.json'].includes(name)) throw Error('Unexpected metadata');
  const raw = await fs.readFile(new URL('../v0618-upload-receipt-preparation/root-small-intake-r1/evidence/reviewed-small-assets/' + name, import.meta.url));
  const a = assets.find(a => a.name === name);
  if (!a || a.size !== raw.length || a.digest !== 'sha256:' + sha(raw)) throw Error('Published original mismatch: ' + name);
  return raw;
}});
console.log(JSON.stringify({ ...result, publishedReleaseId: publication.id, allNineOriginalAssetIdentitiesPreserved: true, source, downloadedAgain: false, origin: 'Retained original small assets matched against draft, published, Latest and root reconciliation descriptors; mutable URL differences are not asset-byte identities' }, null, 2));
