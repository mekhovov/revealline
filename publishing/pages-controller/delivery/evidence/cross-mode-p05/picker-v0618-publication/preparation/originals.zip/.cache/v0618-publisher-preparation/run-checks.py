import pathlib,subprocess,os,json,time,shutil,hashlib
r=pathlib.Path('/Users/oleksandr.mekhovov/work/my_projects/go_test');w=r/'.cache/worktrees/v0618-publisher-preparation';p=r/'.cache/v0618-publisher-preparation';d=p/'checks-r1';d.mkdir(exist_ok=False);tmp=d/'tmp';tmp.mkdir()
admin=pathlib.Path(subprocess.check_output(['git','rev-parse','--absolute-git-dir'],cwd=w,text=True).strip())
def size():return sum(x.stat().st_size for root in [w,p,admin] for x in root.rglob('*') if x.is_file() and not x.is_symlink())
def cap():
 assert size()<32*1024**2,(size(),'managed cap')
 assert shutil.disk_usage(r).free>=512*1024**2,'reserve'
cap()
files=[str(x.relative_to(w)) for x in sorted((w/'publishing/pages-controller').glob('*.test.mjs'))]
env={**os.environ,'TMPDIR':str(tmp),'PYTHONDONTWRITEBYTECODE':'1'}
inputs=[{'path':str(f.relative_to(w)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted((w/'publishing/pages-controller').glob('*.mjs'))]
(d/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
results=[]
commands=[('node20',['/Users/oleksandr.mekhovov/.local/share/mise/installs/node/20.19.5/bin/node','--test','--test-concurrency=1',*files]),('node22',['/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node','--test','--test-concurrency=1',*files]),('python',['python3','-m','unittest','discover','-s','publishing/pages-controller','-p','test_*.py','-v'])]
for label,cmd in commands:
 cap();start=time.time();out=d/(label+'.stdout');err=d/(label+'.stderr')
 with out.open('xb') as a,err.open('xb') as b:
  child=subprocess.Popen(cmd,cwd=w,stdout=a,stderr=b,env=env)
  while child.poll() is None:
   if time.time()-start>120 or out.stat().st_size+err.stat().st_size>1024**2:child.kill();raise Exception(label+' finite command limit')
   cap();time.sleep(.2)
  result={'label':label,'command':cmd,'exit':child.returncode,'elapsedSeconds':round(time.time()-start,3),'stdoutBytes':out.stat().st_size,'stderrBytes':err.stat().st_size}
 results.append(result);print(json.dumps(result),flush=True)
 if result['exit']!=0:print(err.read_text()[-2000:]+out.read_text()[-3000:],flush=True)
(d/'results.json').write_text(json.dumps(results,indent=2)+'\n');cap()
for row in inputs:assert hashlib.sha256((w/row['path']).read_bytes()).hexdigest()==row['sha256']
assert all(row['exit']==0 for row in results)
print(json.dumps({'managedBytes':size(),'freeBytes':shutil.disk_usage(r).free,'inputsUnchanged':True}),flush=True)
