from helpers import *
import datetime,re
F=D/'delivery/evidence/cross-mode-p05/picker-v0618-publication';E=D/'evidence/archive-26/initial-v0617'
# All pre-existing evidence remains pinned, and only the new admission is appended.
oldpub=json.loads((P/'before-publication.json').read_bytes());oldcat=json.loads((P/'before-catalog.json').read_bytes());oldalloc=json.loads((P/'before-allocations.json').read_bytes());pub=json.loads((D/'publication.json').read_bytes());cat=json.loads((D/'catalog.json').read_bytes());alloc=json.loads((D/'allocations.json').read_bytes())
assert len(cat['releases'])==89 and cat['releases'][:-1]==oldcat['releases'];assert len(pub['admissions'])==26 and pub['admissions'][:-1]==oldpub['admissions'];assert len(alloc['shards'])==26 and alloc['shards'][:-1]==oldalloc['shards']
assert pub['currentVersion']=='v0.61.8' and pub['catalogSha256']==sha((D/'catalog.json').read_bytes()) and pub['allocationSha256']==sha((D/'allocations.json').read_bytes())
tracked=subprocess.check_output(['git','-C',str(W),'diff','--name-only']).decode().splitlines();expected=['publishing/pages-controller/'+n for n in ['README.md','allocations.json','catalog.json','delivery/README.md','publication.json']];assert sorted(tracked)==sorted(expected),tracked
check=subprocess.run(['git','-C',str(W),'diff','--check'],capture_output=True);obj(P/'diff-check.receipt.json',{'exitCode':check.returncode,'stdout':check.stdout.decode(),'stderr':check.stderr.decode()});assert check.returncode==0
for r in json.loads((P/'checks-r1/results.json').read_bytes()):assert r['exit']==0
for r in json.loads((P/'checks-r1/inputs.json').read_bytes()):assert sha((W/r['path']).read_bytes())==r['sha256']
assert json.loads((P/'verify-local-candidate.receipt.json').read_bytes())['exitCode']==0
originalCopies=[]
for r in json.loads((P/'archive-adoption.json').read_bytes())['copiedOriginals']:
 src=R/r['source'];dest=W/r['destination'];assert src.read_bytes()==dest.read_bytes();originalCopies.append(r['destination'])
bundles=[]
for folder in [E,F]:
 idx=json.loads((folder/'originals-index.json').read_bytes());raw=(folder/'originals.zip').read_bytes();assert len(raw)==idx['zip']['bytes'] and sha(raw)==idx['zip']['sha256']
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  assert z.testzip() is None and len(z.infolist())==len(idx['files'])
  for r in idx['files']:
   b=z.read(r['path']);assert len(b)==r['bytes'] and sha(b)==r['sha256'] and (R/r['path']).read_bytes()==b
 bundles.append({'directory':str(folder.relative_to(W)),'members':len(idx['files']),'bytes':len(raw),'crcAndOriginalHashesExact':True})
obj(P/'original-bundles-check.json',{'status':'PASS','bundles':bundles,'archiveDirectCopies':originalCopies})
selection=[P/n for n in ['root-before.json','baseline.json','selected-paths-estimate.json','sparse-paths.txt','sparse-config-before-hydration.json','root-before-finalization.json','helpers.py','helpers-adaptation.diff','sync-predecessor.mjs','sync-published-originals.mjs','sync-adaptation.diff','sync.stdout','sync.stderr','sync.receipt.json','metadata-sync-ready.json','publication-evidence-preparation.json','finalize-candidate.py','archive-adoption.json','final-adoption.json','run-checks.py','verify-local-candidate.mjs','verify-local-candidate.stdout','verify-local-candidate.stderr','verify-local-candidate.receipt.json','verify-preservation.py','prior-preservation.json','original-bundles-check.json','diff-check.receipt.json','seal-candidate.py']]
selection += [p for p in (P/'checks-r1').glob('*') if p.is_file()];prepb=bundle(F/'preparation',selection)
p=F/'README.md';s=p.read_text();s += '\nPublisher preparation checks passed 43 tests on each of Node 20.19.5 and Node 22.22.2 plus four Python extraction tests. The actual 89 metadata chains, exact qualification and Archive26 admission validate; hosted full assembly remains a separate gate. [Preparation originals](preparation/originals.zip) and their [index](preparation/originals-index.json) retain the helper input pins, check outputs and prior-body preservation review.\n';p.write_text(s)
newroots=[E,F,D/'metadata/v0.61.8',D/'evidence/current-v0618'];files=sorted(set([W/n for n in tracked]+[p for d in newroots for p in d.rglob('*') if p.is_file()]))
# Validate readable links without hydrating historical evidence.
links=[]
for p in files:
 if p.suffix!='.md':continue
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in target or target.startswith('#'):continue
  dest=(p.parent/target.split('#')[0]).resolve();rel=dest.relative_to(W).as_posix();exists=dest.is_file()
  if not exists:exists=subprocess.run(['git','-C',str(W),'cat-file','-e',base+':'+rel],capture_output=True).returncode==0
  assert exists,(str(p),target);links.append({'from':str(p.relative_to(W)),'target':target,'exists':True})
obj(P/'final-links.json',{'status':'PASS','links':links})
rawdiff=subprocess.check_output(['git','-C',str(W),'diff','--binary']);put(P/'reviewed-hunks.diff',rawdiff)
newdiff=''
for p in files:
 if str(p.relative_to(W)) not in tracked and p.suffix not in ['.zip']:
  s=p.read_text();newdiff+='--- /dev/null\n+++ b/'+str(p.relative_to(W))+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
put(P/'new-text-paths.diff',newdiff)
before=json.loads((P/'root-before-finalization.json').read_bytes());assert sha((admin/'index').read_bytes())==before['worktreeIndexSha256'];assert sha((R/'.git/index').read_bytes())==before['indexSha256'];assert sha((R/'.git/config').read_bytes())==before['commonConfig'];assert subprocess.check_output(['git','status','--porcelain','-z']).hex()==before['status']
rows=[pin(p,W) for p in files];obj(P/'candidate-pins.json',{'format':'revealline-reviewed-candidate-paths.v1','base':base,'worktree':str(W),'files':rows,'totalBytes':sum(r['bytes']for r in rows),'indexUnchanged':True,'stageOrCommitPerformed':False})
put(P/'pr-body.md','''Select the immutable v0.61.8 Still Media picker-clearance correction and preserve v0.61.7 in accepted Archive26. Focused file fields, labels and outlines remain clear of the sticky rail through the scoped Standard-text source-native journey. Shared Plain/Large propagation belongs to v0.61.9. No game bytes or versions change in this publisher PR.

The selector pins exact source `0ae4330b8a87d332051db112f5e09b7c3cbef9fa`, tree `bea7eebf35befcae0362b19f7ecfbb75a3942b00`, and its original qualification. All nine published asset identities match original upload and Latest readback; four small metadata bodies are reused locally. Archive26 passed all 701 files / 313,387,929 bytes, zero failures/retries and zero prior paths, with scoped native practice, Motion rotation and explorer return. Its root seal, original rows, failed-check records and native images are retained.

Validation: 43 publisher tests on Node 20.19.5 and 22.22.2, four Python tests, all 89 metadata chains and the exact current qualification/new archive admission. All 88 prior catalog rows and 25 previous admissions/allocations remain unchanged; 939 previous original bodies were rehashed without hydration. ZIP CRC/source hashes, relative links, diff scope and untouched indexes pass.

v0.61.7 remains the accepted public baseline. This PR still requires hosted full assembly, protected Pages deployment, complete public bytes and the shipped Standard picker journey. No main-campaign/save, physical-device, offline, audible or whole-phase acceptance is inferred from archive or source checks.
''')
used=sum(p.stat().st_size for d in [W,P,admin]for p in d.rglob('*')if p.is_file()and not p.is_symlink());assert used<32*1024**2 and shutil.disk_usage(R).free>512*1024**2
ready={'status':'READY_FOR_ROOT_HUNK_REVIEW_NOT_STAGED','preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':'codex/v0618-pages-preparation','base':base,'baseTree':json.loads((P/'baseline.json').read_bytes())['baseTree'],'worktree':str(W),'manifest':pin(P/'candidate-pins.json',R),'trackedHunks':pin(P/'reviewed-hunks.diff',R),'newTextPaths':pin(P/'new-text-paths.diff',R),'prBody':pin(P/'pr-body.md',R),'source':{'version':'v0.61.8','commit':'0ae4330b8a87d332051db112f5e09b7c3cbef9fa','tree':'bea7eebf35befcae0362b19f7ecfbb75a3942b00','tagObject':'d6b9a83d1364c81f23251fae4c3d30241b2e36df','releaseId':391546102,'qualificationSha256':'35975fc84614a0a9f43dfa9c15f2a5a54c8d2facd5526728290d583827356084'},'archive26':{'commit':'6189d37ed382fce79a28e7a464c5e7384429ab05','tree':'abe08da1252515a5d084c93b7ee59b1f45348162','runId':35358010420,'deploymentId':6526678454,'files':701,'bytes':313387929,'priorRows':0,'newRows':701},'checks':{'node20':43,'node22':43,'python':4,'metadataChains':89,'currentSourceAndNewAdmission':True,'priorBodiesRehashed':939,'diffCheck':True,'indexUntouched':True},'preservation':pin(P/'prior-preservation.json',R),'originalBundles':pin(P/'original-bundles-check.json',R),'candidatePaths':len(rows),'candidateBytes':sum(r['bytes']for r in rows),'priorCatalogRecordsPreserved':88,'priorAdmissionsPreserved':25,'totalAdmissions':26,'acceptedPublicBaseline':'v0.61.7','v618PagesAccepted':False,'stageOrCommitPerformed':False,'remoteMutationPerformed':False,'bodyGETs':0,'gameVersionOrPublisherHelperChanges':False,'managedBytesBeforeReady':used,'managedCapBytes':32*1024**2,'freeBytes':shutil.disk_usage(R).free,'reserveBytes':512*1024**2,'remaining':['Root exact hunk/index review, commit and publisher PR.','Hosted full original-ZIP publisher assembly and protected deployment.','Complete public byte audit and actual shipped Standard picker/label/focus journey.','Keep Large propagation, device/offline/audio and parent-phase gates separate.']};obj(P/'ready.json',ready);print(json.dumps({'ready':pin(P/'ready.json',R),'manifest':pin(P/'candidate-pins.json',R),'paths':len(rows),'bytes':sum(r['bytes']for r in rows),'managedBytes':used,'preparationBundle':prepb},indent=2))
