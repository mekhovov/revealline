# v0.61.1 public audit — prepared, deployment unbound

The audit targets source `a7a4e2d7090e2fe9d1843d88b63bc334b95bf61e`, tree `8f81812d56299c2819ec083d919d9085a36d223c`, and source qualification SHA `ce94e595f0aa579fa5f64df57795cf49a8bc1404e71c2e861d4900ccc3347fb1`. The exact local qualified record and three small original metadata files are retained. A publication response has not yet been admitted to this cache; future Pages bindings remain unset.

All **81 existing catalog records** come byte-exact from accepted v0.61.0 controller `b2295577461a5792baa37a1ef4c2f9dbdbc75ae9`. The successor is expected to contain **82 versions and 22 archive admissions**. Archive22's separate accepted append preserves v0.60.9 and v0.61.0 under its actual `b9cf5426` deployment. That acceptance and the prior main acceptance are retained; all nine referenced evidence pins were rehashed without duplicating their evidence trees.

The original current-game manifest contains **690 files / 313,108,331 bytes**. It is not the full public inventory. The complete main-site inventory must be derived from the future publisher's successful hosted receipt, including root aliases, hidden files, workers, release records and historical bridges. No prior inventory counts or deployment IDs are reused.

These are the accepted v0.61.0 tools with literal changes only: source/tree/version, preserved catalog hash, the self-check's 81-row expectation, and intentionally unbound intake sentinels. Five operational helpers are byte-identical; seven Python modules retain identical AST structure after literal normalization. Original helper bodies and diffs remain alongside the successors. Nine mocked wrapper tests, the Node 20 self-check and four capacity cases pass with zero real network requests.

After root binds the intended successful Pages run and exact merged controller, use the inherited observer:

```text
python3 -B observe-hosted.failure-retention.py before-1 ACTUAL_CONTROLLER ACTUAL_TREE ACTUAL_PAGES_RUN
```

Retain every original terminal response and derive the intake request from those actual records. Root reviews the exact small `frozen-pages-receipts` artifact, publication response and request before one bounded download. Only then replace `UNBOUND_RECEIPT_ID` and `UNBOUND_REVIEWED_INTAKE_SHA` in the capacity adapter, retaining its unbound body and diff. The 32 MiB cumulative cache limit, 512 MiB reserve, 20 MiB headroom and three expanded-copy allowance remain unchanged. No source TAR, distribution ZIP or Pages body artifact is downloaded locally.

The intake generates an unreviewed binding. Root must check all 81 retained catalog records, the 82-version successor, 22 archive admissions, source qualification and complete publisher inventory. Once approved, the inherited commands are:

```text
node --max-old-space-size=1024 tools/audit-main.mjs --binding ROOT_REVIEWED_BINDING --binding-sha EXACT_SHA --check
node --max-old-space-size=1024 tools/audit-main.mjs --binding ROOT_REVIEWED_BINDING --binding-sha EXACT_SHA --out complete-1
python3 -B review-public.py ACTUAL_CONTROLLER complete-1
python3 -B observe-hosted.failure-retention.py after-1 ACTUAL_CONTROLLER ACTUAL_TREE ACTUAL_PAGES_RUN
python3 -B refresh-after-http.py ROOT_REVIEWED_REFRESH_REQUEST EXACT_SHA
```

The row reviewer expects an exact ordinary copy of the approved binding at `binding.json`; retain that copy's provenance if the reviewed source uses another name. Preserve command outputs, times, exits and failed attempts. The unchanged engine uses eight workers and at most three attempts for transient failures; it streams and hashes bodies without storing them. The 20,000-row and 950,000,000-byte caps remain.

This preparation does not execute observers, receipt intake or the public audit. Source qualification, release publication, public byte verification, actual player journeys, listening, offline recovery, physical input and full-phase acceptance remain distinct. The immediate feature is shared media controls; this does not qualify the whole sound programme. Main and archive paths share a GitHub Pages origin, so no save isolation or migration follows from their different URLs.
