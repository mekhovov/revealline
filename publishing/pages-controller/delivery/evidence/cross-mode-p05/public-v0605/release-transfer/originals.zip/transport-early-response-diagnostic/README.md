# Local-only early-response diagnostic candidate

**No upload, remote API, cleanup or publication is authorized or performed by this packet.** These are small loopback tests and a narrow observer on the existing1,200-second transport. Root must separately review any later operational adoption.

`capture_failure_response_metadata` runs only after the existing process cleanup and bounded reader joins. If the transfer already failed, no HTTP status was captured, the reader finished and its output stayed within limits, the observer recognizes the existing trailer and records only numeric HTTP status/protocol. It does not retain response bodies or headers. Malformed/oversized metadata and curl's no-response000 value remain unknown.

The observer does not change the original exception class, stage, input byte count, incomplete digest, limits, timeout, retry/redirect settings, credential handling, upload target or success path. An early201 still raises `Ambiguous`; it cannot satisfy the complete original-byte/hash and final release-asset guards. Existing coordinator/holder code is not changed or invoked here.

## Discriminating results

The same12 tests run against both versions:

- Baseline:7 pass,4 fail,1 skip. Four early-response assertions fail because the actual HTTP201/500/502/partial502 status is lost. The new observer-only malformed-input test skips because baseline has no observer.
- Candidate:12/12 pass, no failures or skips. All six existing exact-body/auth-pipe/no-redirect/bound/hash/preflight cases remain unchanged and pass.
- Early201,500 and502 produce `BrokenPipeError` with an incomplete body yet retain their actual HTTP code. Every case stays ambiguous; the synthetic response body/credential is absent from the trace.
- A truncated response retains its502 status without success. A timeout with no HTTP response stays `httpStatus:null` and curl exit28. The local fixture uses HTTP/1.1 fallback; this is not a production HTTP/2 test.

Thus early HTTP refusal is distinguishable from a no-response timeout in the new local fixture. The old production response was discarded and still cannot be reconstructed; these tests do not diagnose its actual status or fix the remote service.

Original inputs, existing fixtures, both failed/passing outputs and receipts are preserved. `diagnostic-only.patch` changes only the small observation function and one cleanup call. `review.json` pins all packet files. No full game test suite, build, artifact extraction, source/index/remote mutation or release attempt took place.
