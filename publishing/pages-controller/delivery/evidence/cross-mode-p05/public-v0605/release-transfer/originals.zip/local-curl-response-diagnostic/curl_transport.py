"""Bounded curl transport only; credentials and payload use separate inherited pipes."""
import hashlib
import json
import os
import re
import subprocess
import threading
import time

from upload_distribution import Ambiguous, Refusal, JSON_LIMIT, chunks, require

CURL = '/usr/bin/curl'
MARKER = b'\nREVEALLINE_CURL_RESPONSE '
STDERR_LIMIT = 64 * 1024
UPLOAD_PATH = '/repos/mekhovov/revealline/releases/390920301/assets?name=distribution.zip'


class Capture:
    def __init__(self, pipe, limit, process, keep=True):
        self.pipe, self.limit, self.process, self.keep = pipe, limit, process, keep
        self.body, self.bytes, self.overflow = bytearray(), 0, False
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def run(self):
        try:
            while True:
                body = self.pipe.read(4096)
                if not body:
                    break
                self.bytes += len(body)
                if self.bytes > self.limit:
                    self.overflow = True
                    self.process.kill()
                    break
                if self.keep:
                    self.body.extend(body)
        finally:
            self.pipe.close()



def capture_failure_response_metadata(trace, capture):
    """Observe only bounded numeric HTTP metadata; never promote a failed transfer."""
    if (trace.get('errorClass') is None or trace.get('httpStatus') is not None or
            capture is None or capture.thread.is_alive() or capture.overflow):
        return
    body, marker, metadata = bytes(capture.body).rpartition(MARKER)
    if not marker or len(body) > JSON_LIMIT:
        return
    match = re.fullmatch(rb'([0-9]{3}) ([^\r\n]{0,200}) ([0-9.]{1,4})', metadata)
    if match is None or not 100 <= int(match[1]) <= 599:
        return
    trace['httpStatus'] = int(match[1])
    trace['httpVersion'] = match[3].decode('ascii')


def transfer(token, path, stream, size, expected_hash, trace, *, deadline, _loopback=None):
    """One process/one POST. A started process always fails ambiguous, never retries."""
    require(path == UPLOAD_PATH, 'Only the exact missing distribution path is permitted')
    require(isinstance(token, str) and 1 <= len(token) <= 4096 and
            not any(c.isspace() for c in token), 'Invalid in-memory credential')
    require(type(size) is int and 0 < size <= 512 * 1024 * 1024 and
            re.fullmatch(r'[a-f0-9]{64}', expected_hash), 'Invalid payload descriptor')
    require(time.monotonic() < deadline, 'Operation deadline exceeded')
    if _loopback is not None:
        require(type(_loopback) is tuple and len(_loopback) == 2 and
                _loopback[0] == '127.0.0.1' and type(_loopback[1]) is int and
                0 < _loopback[1] < 65536, 'Synthetic transport must be loopback')
    origin = 'https://uploads.github.com' if _loopback is None else f'http://127.0.0.1:{_loopback[1]}'
    protocol = '=https' if _loopback is None else '=http'
    # No token in argv, environment, disk, trace, or child output retained to disk.
    escaped_token = token.replace('\\', '\\\\').replace('"', '\\"')
    config = ('header = "Authorization: Bearer ' + escaped_token + '"\n').encode()
    read_fd, write_fd = os.pipe()
    process = stdout = stderr = None
    trace.update(stage='preflight', errorClass=None, bodyBytesToCurl=0,
                 byteCountMeaning='Successfully written to curl stdin; not remote acceptance',
                 streamedSha256=None, httpStatus=None, httpVersion=None, curlExit=None,
                 stderrBytes=0, stdoutOverflow=False, stderrOverflow=False, elapsedSeconds=0)
    started = time.monotonic()
    digest = hashlib.sha256()
    try:
        timeout = min(1200, max(1, int(deadline - started)))
        args = [CURL, '-q', '--silent', '--show-error', '--http2', '--proto', protocol,
                '--max-redirs', '0', '--retry', '0', '--connect-timeout', '30', '--max-time', str(timeout),
                '--request', 'POST', '--upload-file', '-', '--config', f'/dev/fd/{read_fd}',
                '--header', 'Content-Type: application/zip', '--header', f'Content-Length: {size}',
                '--header', 'Transfer-Encoding:',
                '--header', 'Expect:', '--header', 'Accept: application/vnd.github+json',
                '--header', 'User-Agent: RevealLine-pinned-original-curl-recovery',
                '--header', 'X-GitHub-Api-Version: 2022-11-28',
                '--write-out', MARKER.decode() + '%{http_code} %{content_type} %{http_version}',
                origin + path]
        env = os.environ.copy()
        # Avoid accidental TLS key material logging inherited from a diagnostic shell.
        for secret_variable in ('SSLKEYLOGFILE', 'GH_TOKEN', 'GITHUB_TOKEN',
                                'GH_ENTERPRISE_TOKEN', 'GITHUB_ENTERPRISE_TOKEN'):
            env.pop(secret_variable, None)
        trace['stage'] = 'start-curl'
        process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, pass_fds=(read_fd,), bufsize=0, env=env)
        os.close(read_fd)
        read_fd = None
        stdout = Capture(process.stdout, JSON_LIMIT + 1024, process)
        stderr = Capture(process.stderr, STDERR_LIMIT, process, keep=False)
        trace['stage'] = 'credential-config'
        view = memoryview(config)
        while view:
            written = os.write(write_fd, view)
            require(written > 0, 'Credential pipe closed early')
            view = view[written:]
        os.close(write_fd)
        write_fd = None
        del config, escaped_token, token
        trace['stage'] = 'stream-body'
        for body in chunks(stream, size):
            require(time.monotonic() < deadline, 'Operation deadline exceeded')
            view = memoryview(body)
            while view:
                written = process.stdin.write(view)
                require(written is not None and written > 0, 'Curl payload pipe closed early')
                digest.update(view[:written])
                trace['bodyBytesToCurl'] += written
                view = view[written:]
        process.stdin.close()
        trace['streamedSha256'] = digest.hexdigest()
        require(trace['bodyBytesToCurl'] == size and digest.hexdigest() == expected_hash,
                'Streamed original identity differs')
        trace['stage'] = 'receive-response'
        trace['curlExit'] = process.wait(timeout=timeout + 10)
        stdout.thread.join(timeout=5)
        stderr.thread.join(timeout=5)
        require(not stdout.thread.is_alive() and not stderr.thread.is_alive(), 'Response reader did not finish')
        require(not stdout.overflow and not stderr.overflow, 'Curl output exceeded bounded limit')
        body, marker, metadata = bytes(stdout.body).rpartition(MARKER)
        require(marker and len(body) <= JSON_LIMIT, 'Missing bounded response metadata')
        match = re.fullmatch(rb'([0-9]{3}) ([^\r\n]{0,200}) ([0-9.]{1,4})', metadata)
        require(match is not None, 'Invalid response metadata')
        trace['httpStatus'] = int(match[1])
        trace['httpVersion'] = match[3].decode()
        trace['stage'] = 'validate-response'
        require(trace['curlExit'] == 0 and trace['httpStatus'] == 201, 'Upload did not return HTTP 201')
        require(match[2].split(b';', 1)[0].strip() == b'application/json', 'Expected JSON API response')
        try:
            result = json.loads(body)
        except (ValueError, UnicodeError):
            raise Refusal('Invalid API JSON') from None
        require(isinstance(result, dict), 'Expected an asset object')
        trace['stage'] = 'response-accepted'
        return result, trace['bodyBytesToCurl'], digest.hexdigest()
    except BaseException as error:
        kind = type(error).__name__
        trace['errorClass'] = kind if kind in {'Refusal', 'BrokenPipeError', 'OSError', 'TimeoutExpired',
                                               'TimeoutError', 'KeyboardInterrupt'} else 'OtherError'
        if process is not None:
            raise Ambiguous('Upload outcome unconfirmed. Do not retry or delete automatically; '
                            'reread the exact release asset list first.') from None
        raise
    finally:
        for descriptor in (read_fd, write_fd):
            if descriptor is not None:
                os.close(descriptor)
        if process is not None:
            if process.poll() is None:
                process.kill()
            process.wait(timeout=10)
            if process.stdin and not process.stdin.closed:
                process.stdin.close()
            trace['curlExit'] = process.returncode
        for capture in (stdout, stderr):
            if capture is not None:
                capture.thread.join(timeout=5)
        capture_failure_response_metadata(trace, stdout)
        if stderr is not None:
            trace['stderrBytes'], trace['stderrOverflow'] = stderr.bytes, stderr.overflow
        if stdout is not None:
            trace['stdoutOverflow'] = stdout.overflow
        trace['elapsedSeconds'] = round(time.monotonic() - started, 6)
