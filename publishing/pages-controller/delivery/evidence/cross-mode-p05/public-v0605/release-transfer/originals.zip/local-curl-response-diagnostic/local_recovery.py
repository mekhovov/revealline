#!/usr/bin/env python3
"""One explicit local distribution upload using unchanged, pinned e412 coordinator and member validators.

No download, cleanup, retry, build, release publication or large extracted copy.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
PINS_SHA = 'dc0df856ecb63b582a7d6274cbde0a5b8f196ca7ccf6e17e07b6d1ecd4e6cedd'
SOURCE = {'commit': 'a336f18306a425f6575b77a3017056d32155043f',
          'tree': 'b80ee2c1ccf455609a6834af14c6760ecce868e3', 'version': 'v0.60.5'}


def checked_inputs():
    manifest = (BASE / 'input-pins.json').read_bytes()
    if hashlib.sha256(manifest).hexdigest() != PINS_SHA:
        raise ValueError('Input pin manifest changed')
    pins = json.loads(manifest)
    for row in pins['files']:
        path = BASE / row['path']
        if path.is_symlink() or not path.is_file() or path.stat().st_size != row['bytes']:
            raise ValueError('Pinned small input identity differs')
        if hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
            raise ValueError('Pinned small input bytes differ')
    return pins


checked_inputs()
sys.path.insert(0, str(BASE / 'helpers'))
import release_artifact as utility


from curl_transport import transfer


class DiagnosticAPI(utility.RecordedGitHub):
    def __init__(self, token, out, diagnostic_path):
        super().__init__(token, out)
        self.diagnostic_path, self.upload_attempts = diagnostic_path, 0

    def upload(self, path, stream, size, expected_hash):
        utility.require(path == '/repos/mekhovov/revealline/releases/390920301/assets?name=distribution.zip',
                        'This one-off helper only permits the missing distribution upload')
        utility.require(self.upload_attempts == 0, 'One upload attempt only; never retry automatically')
        self.upload_attempts += 1
        trace = {}
        try:
            return transfer(self.token, path, stream, size, expected_hash, trace,
                            deadline=self.deadline)
        finally:
            utility.record(self.diagnostic_path, trace)


def upload():
    pins = checked_inputs()
    binding_body = (BASE / 'inputs/binding.json').read_bytes()
    binding = utility.validate_binding(binding_body, 'upload-originals', 'mekhovov/revealline')
    utility.require(binding['source'] == SOURCE and binding['release']['id'] == 390920301,
                    'Frozen source/draft identity differs')
    receipt_body = (BASE.with_name('local-original-recovery') / 'download-receipt.json').read_bytes()
    receipt = utility.parse(receipt_body)
    utility.require(receipt.get('status') == 'EXACT_ORIGINAL_RECEIVED' and
                    receipt.get('source') == SOURCE and receipt.get('artifact') == binding['artifact'] and
                    receipt.get('bytes') == binding['artifact']['bytes'] and
                    receipt.get('sha256') == binding['artifact']['sha256'],
                    'Root exact-original download has not succeeded')
    out = BASE / 'execution'
    original = BASE.with_name('local-original-recovery') / 'execution/qualified-artifact-original.zip'
    outer = original
    utility.require(not outer.is_symlink() and outer.is_file() and
                    outer.stat().st_size == binding['artifact']['bytes'], 'Original outer file is absent or changed')
    # The unchanged PinnedSource/PinnedDistribution constructors hash this whole file
    # and their two exact members before any upload; no 1.36 GB read_bytes allocation.
    out.mkdir()  # Exclusive attempt; no reuse of a failed transport directory.
    os.link(original, out / 'qualified-artifact-original.zip')  # Same inode; no large copy.
    utility.require(os.path.samefile(original, out / 'qualified-artifact-original.zip'),
                    'Original artifact hard link differs')
    evidence = out / 'evidence'
    evidence.mkdir()  # Exclusive execution; a failed/ambiguous invocation cannot be retried here.
    utility.write(evidence / 'binding.json', binding_body)
    utility.write(evidence / 'root-download-receipt.json', receipt_body)
    utility.record(evidence / 'local-execution.json', {
        'scope': 'Independent local curl transport recovery; not a new game qualification or publication',
        'utilityCommit': pins['utilityCommit'], 'utilityTree': pins['utilityTree'],
        'source': SOURCE, 'originalInputs': pins, 'wrapper': utility.pin(Path(__file__)),
        'transport': utility.pin(BASE / 'curl_transport.py'),
        'transportKind': 'curl HTTP/2 negotiation, one POST, no retries or redirects',
        'automaticRetry': False, 'largeExtractedCopies': 0})
    for name in ['inspection.json', 'manifest.json', 'release.json', 'distribution.zip.sha256']:
        utility.write(out / 'qualified-artifact-verified' / name,
                      (BASE / 'inputs/qualified-artifact-verified' / name).read_bytes())
    inspection = utility.parse((out / 'qualified-artifact-verified/inspection.json').read_bytes())
    result = {'status': 'REFUSED', 'source': SOURCE, 'operation': 'local-upload-originals',
              'automaticRetry': False, 'scope': 'Local frozen-byte transport only; no public acceptance'}
    api = None
    try:
        # The credential is captured only in memory; never argv, environment, receipt or error text.
        auth = subprocess.run(['gh', 'auth', 'token', '--hostname', 'github.com'], capture_output=True, timeout=30)
        utility.require(auth.returncode == 0, 'Existing GitHub credential lookup failed')
        token = auth.stdout.decode().strip()
        api = DiagnosticAPI(token, evidence / 'api', evidence / 'upload-transport.json')
        del token, auth
        utility.artifact_authority(api, binding)
        # Root must separately remove only its confirmed unfinished starter first.
        # Exactly the seven small assets plus the original completed source must remain.
        utility.asset_set(api, binding, utility.SMALL_NAMES | {'source.tar'})
        utility.upload_originals(binding, out, inspection, api)
        utility.artifact_authority(api, binding)
        result['status'] = 'ALL_NINE_VERIFIED'
    except (utility.upload_source.Ambiguous, utility.upload_distribution.Ambiguous):
        result.update(status='UNCONFIRMED_REREAD_ASSETS', requiresAssetReread=True)
        raise
    finally:
        if api is not None:
            api.token = ''
        utility.preserve_small_outputs(out)
        utility.record(evidence / 'result.json', result)
        rows = [utility.pin(path) for path in sorted(evidence.rglob('*')) if path.is_file()]
        utility.record(evidence / 'retained-manifest.json', {
            'files': rows, 'count': len(rows), 'bytes': sum(row['bytes'] for row in rows)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['upload'])
    parser.add_argument('--root-go', action='store_true', required=True)
    parser.parse_args()
    upload()
