# Public v0.61.9 portrait-return focus clipping

The cause is the focus helper's use of the dialog **border box** as its scroll viewport. Fractional scroll rounding is not required to explain the recorded failure.

Exact source `6db978db40287151489803e915cb4ecb9ea232ee`, `game/ui/focus-clearance.mjs:16–20`, takes `getBoundingClientRect().bottom` and subtracts its existing 8px safety gap. The Still Media caller at `game/ui/still-media-panel.mjs:193–198` opts into keeping the complete label visible. Its dialog CSS declares a 3px border and `overflow:auto`.

The public screenshot and matching measurement record show:

| Quantity | CSS pixels |
|---|---:|
| Dialog outer top / bottom | 16 / 828 |
| Dialog top border / client height | 3 / 806 |
| Actual scrollport bottom | 16 + 3 + 806 = 825 |
| Current helper's permitted target bottom | 828 − 8 = 820 |
| Picker and label bottom | 819.765625 |
| Focus outline plus outward offset | 3 + 4 = 7 |
| Painted outline bottom | 826.765625 |
| Clipped amount | 1.765625 |

The target passes the existing check because 819.765625 is less than 820, yet its outline crosses the actual overflow clip. Initial portrait and landscape passed; that does not qualify the retained-focus return portrait. Focus, selected file and preview status remain intact. The finding is narrow painted-focus clipping, not lost input or failed preview.

Smallest shared-helper correction: derive the vertical scrollport from `box.top + container.clientTop` and that point plus `container.clientHeight`; constrain the sticky-header/footer reading region inside these bounds, keeping the existing 8px clearance and label-fit fallback. Keep scroll-padding values relative to the same scrollport. At the measured geometry, the permitted bottom becomes 817; moving by 2.765625 puts the outline bottom at824, inside the clip by1px. Retain a safe border-box fallback for minimal non-native test surfaces lacking client metrics; do not silently treat legitimate zero height as a usable positive viewport.

Do not change font sizes, native file control sizes, focus outline styling, operation/status ownership, selection, image bytes, or the data store. Increasing a hard-coded margin alone would hide this particular border mistake while retaining the wrong viewport calculation. Ordinary reading scroll must remain deliberate; this correction should only run through the existing focus/resize/refresh scheduling and lifetime guards.

The helper also serves Missions (`game/ui/game-shell.mjs`) and Replay (`game/app.mjs`), so qualify its full existing test file plus a fractional bordered-scrollport regression and these established focus/label guards. The existing fixture has no client-border geometry and therefore could not expose this defect. Native successor acceptance should repeat the exact settled preview and 390×844 → 844×390 →390×844 keyboard-focused picker journey, measuring the entire outline against the scrollport and the label against the sticky rail. Broader consumer checks remain distinct.

This is a source/evidence analysis. The original public screenshot, measurements, HTTP identity receipt and observations are untouched. The selected observation is copied separately here because the parent may append later public observations. No patch, native action, or public-release correction is claimed by this note.
