# v0.61.9 public metadata identity

PASS: the frozen release build metadata declares v0.61.9 and source `6db978db40287151489803e915cb4ecb9ea232ee`. GitHub Pages run `35370220934` completed successfully for publisher `b88b0e4c63dddcc5339076e29606b2fb1700553f`; deployment `6528856630` and exact successful status `18534250830` agree.

Exactly five bounded raw HTTP GET responses are retained, each with body, headers, curl transport metadata and stderr. Response bodies total 20,666 bytes. All returned HTTP 200 without redirects. `receipt.json` records the comparisons and SHA256 hashes.

This is a small identity receipt for the native-test entry `https://mekhovov.github.io/revealline/releases/v0.61.9/site/game/`. It is not a full deployed-byte audit or proof of UI/gameplay acceptance. Hashes declared by release metadata were recorded, not recomputed from large payloads. The parent owns native checks; the release coordinator owns full artifact/public byte verification. No source or remote state was changed.
