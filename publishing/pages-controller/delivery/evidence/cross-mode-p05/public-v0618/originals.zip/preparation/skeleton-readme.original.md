# v0.61.8 public qualification — pending root acceptance

This documentation-only candidate is based on merged publisher PR 140, commit `e95374932385097fbdee58517f8f9bf269f3cff4`, tree `627c93e560c27d1a4de1858c7ba8992048f02e81`. Exact game source, version and release payloads are unchanged.

v0.61.7 remains the accepted public baseline. The complete v0.61.8 deployed-byte and affected native results will be recorded here only after the coordinator supplies the final root acceptance record. No native, offline, audio, physical-device or whole-phase acceptance is inferred by this skeleton.

[Current dated plan](planning/progress-and-next.md) keeps the later source-qualified queue, local HUD/Team work and actor production correction separate from public acceptance.
