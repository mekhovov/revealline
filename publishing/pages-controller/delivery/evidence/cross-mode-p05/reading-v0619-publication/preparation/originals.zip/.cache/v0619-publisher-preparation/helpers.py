from pathlib import Path
import json,hashlib,zipfile,io,shutil,subprocess
R=Path.cwd();P=R/'.cache/v0619-publisher-preparation';W=R/'.cache/worktrees/v0619-publisher-preparation';D=W/'publishing/pages-controller';admin=Path(subprocess.check_output(['git','-C',str(W),'rev-parse','--absolute-git-dir'],text=True).strip());sha=lambda b:hashlib.sha256(b).hexdigest();base='1b914281e029602b163a61062b979a01cda040d7'
def put(p,b):
 if isinstance(b,str):b=b.encode()
 assert not p.exists();assert sum(q.stat().st_size for d in [W,P,admin]for q in d.rglob('*')if q.is_file()and not q.is_symlink())+len(b)+65536<8*1024**2;assert shutil.disk_usage(R).free>512*1024**2+len(b)+65536;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def obj(p,v):put(p,json.dumps(v,indent=2)+'\n')
def cp(src,dest):put(dest,src.read_bytes())
def pin(p,root=D):b=p.read_bytes();return {'path':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':sha(b)}
def bundle(dest,selected):
 assert len(selected)==len(set(selected));out=io.BytesIO();rows=[]
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(selected):
   assert p.is_file()and not p.is_symlink();b=p.read_bytes();n=p.relative_to(R).as_posix();info=zipfile.ZipInfo(n,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b);rows.append({'path':n,'bytes':len(b),'sha256':sha(b)})
 raw=out.getvalue();assert len(raw)<8*1024**2
 put(dest/'originals.zip',raw);obj(dest/'originals-index.json',{'format':'revealline-finite-originals-index.v1','zip':{'path':'originals.zip','bytes':len(raw),'sha256':sha(raw)},'files':rows,'uncompressedBytes':sum(x['bytes']for x in rows),'originalsByteExact':True,'noScreenshotExportInvented':True})
 with zipfile.ZipFile(io.BytesIO(raw))as z:assert z.testzip()is None and len(z.infolist())==len(rows);assert all(sha(z.read(x['path']))==x['sha256']for x in rows)
 return len(rows),len(raw)
