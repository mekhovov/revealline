import fs from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {validateAdmissions,readOrdinary} from '../worktrees/v0619-publisher-preparation/publishing/pages-controller/assemble.mjs';
import {validateMetadata,digest} from '../worktrees/v0619-publisher-preparation/publishing/pages-controller/metadata.mjs';
const directory=new URL('../worktrees/v0619-publisher-preparation/publishing/pages-controller/',import.meta.url).pathname;
const worktree=new URL('../worktrees/v0619-publisher-preparation/',import.meta.url).pathname;
const base='1b914281e029602b163a61062b979a01cda040d7';
const bytes=await readOrdinary(directory,'catalog.json'),lock=JSON.parse(bytes),metadata=new Map();
if(lock.format!=='revealline-frozen-catalog.v1'||lock.sourceRepository!=='mekhovov/revealline'||lock.releases.length!==90)throw Error('Catalog identity');
for(const pin of lock.releases){
 if(metadata.has(pin.version))throw Error('Duplicate version');
 const names=['release.json','manifest.json','distribution.zip.sha256'];
 const bodies=await Promise.all(names.map(async name=>pin.version==='v0.61.9'?readOrdinary(directory,`metadata/${pin.version}/${name}`):execFileSync('git',['-C',worktree,'show',`${base}:publishing/pages-controller/metadata/${pin.version}/${name}`],{maxBuffer:8000000,env:{...process.env,GIT_NO_LAZY_FETCH:'1'}})));
 metadata.set(pin.version,validateMetadata({recordBytes:bodies[0],manifestBytes:bodies[1],checksumBytes:bodies[2],pin}));
}
const configuration=JSON.parse(await readOrdinary(directory,'publication.json'));
if(configuration.catalogSha256!==digest(bytes))throw Error('Catalog byte pin');
const selected=new Map(['v0.61.7','v0.61.8','v0.61.9'].map(v=>[v,metadata.get(v)]));
const verified=await validateAdmissions({directory,configuration,metadata:selected,requireBrowser:true});
if(verified.qualification.sourceRevision!=='6db978db40287151489803e915cb4ecb9ea232ee'||verified.qualification.sourceTree!=='50391b01ad011079c9ba66fe7e4f9f0ed229a1f9')throw Error('Wrong qualification');
console.log(JSON.stringify({status:'PASS_CURRENT_SOURCE_CHANGED_ARCHIVE_AND_ALL_METADATA_CHAINS',catalogRecords:90,metadataChains:metadata.size,source:verified.qualification.sourceRevision,tree:verified.qualification.sourceTree,changedArchive:'archive-26',retainedVersions:['v0.61.7','v0.61.8'],unchangedAdmissions:25,scope:'All 90 metadata chains use the actual validator; 89 historical inputs are streamed from exact base Git without hydration. Changed archive26 and current619 qualification use actual filesystem admission validation. Full all-admission assembly remains hosted preview.'},null,2));
