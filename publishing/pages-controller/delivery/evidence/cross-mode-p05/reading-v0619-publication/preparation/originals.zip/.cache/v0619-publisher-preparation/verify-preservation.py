from helpers import *
import os
oldpub=json.loads(subprocess.check_output(['git','-C',str(W),'show',base+':publishing/pages-controller/publication.json']))
oldcat=json.loads(subprocess.check_output(['git','-C',str(W),'show',base+':publishing/pages-controller/catalog.json']))
oldalloc=json.loads(subprocess.check_output(['git','-C',str(W),'show',base+':publishing/pages-controller/allocations.json']))
pub=json.loads((D/'publication.json').read_bytes());cat=json.loads((D/'catalog.json').read_bytes());alloc=json.loads((D/'allocations.json').read_bytes())
assert len(oldcat['releases'])==89 and len(cat['releases'])==90 and cat['releases'][:-1]==oldcat['releases']
assert len(pub['admissions'])==26 and [a for a in pub['admissions'] if a['id']!='archive-26']==[a for a in oldpub['admissions'] if a['id']!='archive-26']
assert len(alloc['shards'])==26 and [a for a in alloc['shards'] if a['id']!='archive-26']==[a for a in oldalloc['shards'] if a['id']!='archive-26']
prior_path=R/'.cache/v0618-publisher-preparation/prior-preservation.json';prior=json.loads(prior_path.read_bytes());pins={r['path']:r['sha256']for r in prior['originalBodies']}
def add(path,digest):
 assert path not in pins or pins[path]==digest; pins[path]=digest
for row in oldcat['releases']:
 for name,key in [('release.json','recordSha256'),('manifest.json','manifestSha256'),('distribution.zip.sha256','checksumSha256')]:add('publishing/pages-controller/metadata/'+row['version']+'/'+name,row[key])
for adm in oldpub['admissions']:
 for row in adm['evidence']:add('publishing/pages-controller/'+row['path'],row['sha256'])
add('publishing/pages-controller/'+oldpub['currentSourceQualification']['path'],oldpub['currentSourceQualification']['sha256'])
assert len(pins)<=1100
batch=subprocess.Popen(['git','-C',str(W),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
rows=[]
for path,expected in sorted(pins.items()):
 batch.stdin.write((base+':'+path+'\n').encode());batch.stdin.flush();header=batch.stdout.readline(1000).decode().strip().split();assert len(header)==3 and header[1]=='blob',(path,header);size=int(header[2]);assert size<=16*1024**2
 h=hashlib.sha256();remaining=size
 while remaining:
  chunk=batch.stdout.read(min(65536,remaining));assert chunk;h.update(chunk);remaining-=len(chunk)
 assert batch.stdout.read(1)==b'\n';assert h.hexdigest()==expected,path
 physical=W/path
 if physical.exists():
  assert physical.is_file() and not physical.is_symlink();hp=hashlib.sha256()
  with physical.open('rb')as f:
   for chunk in iter(lambda:f.read(65536),b''):hp.update(chunk)
  assert physical.stat().st_size==size and hp.hexdigest()==expected,path
 rows.append({'path':path,'bytes':size,'sha256':expected,'workingCopyIfPresentExact':True})
batch.stdin.close();assert batch.wait(timeout=20)==0;assert not batch.stderr.read()
assert subprocess.run(['git','-C',str(W),'diff','--cached','--quiet']).returncode==0
obj(P/'prior-preservation.json',{'status':'PASS_ALL_PRIOR_CATALOG_AND_ARCHIVE_ORIGINALS_PRESERVED','base':base,'priorCatalogRecords':89,'unchangedAdmissions':25,'changedAdmission':'archive-26 append-v0618','allEarlierEvidencePreserved':True,'priorPinSelection':pin(prior_path,R),'originalBodies':rows,'bytesRehashed':sum(r['bytes']for r in rows),'indexStaged':False,'noPriorEvidenceHydratedForThisCheck':True})
print(json.dumps({'originalBodies':len(rows),'bytesRehashed':sum(r['bytes']for r in rows),'indexStaged':False,'duplicateHydration':False}))
