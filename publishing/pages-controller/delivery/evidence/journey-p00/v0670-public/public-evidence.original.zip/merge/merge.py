from pathlib import Path
import json,subprocess,hashlib,shutil,datetime,concurrent.futures,sys
assert sys.argv[1:]==['--reviewed-execute-once']
home=Path(__file__).resolve().parent
head='6e470a1e86aa7a7a0127d0acf1344614322e3f50'
base='0c38826fb4bef83b20360b9dd87b1ab7db680536'
tree='f0c22bb22ba7ebdad7d6884d40f4c9d651c6576d'
assert not (home/'began.json').exists()
assert shutil.disk_usage(home).free>256*1024**2+4*1024**2
with (home/'began.json').open('x') as marker:
 marker.write(json.dumps({'head':head,'base':base,'tree':tree,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
def call(name,path,method=None,body=None):
 args=['gh','api','repos/mekhovov/revealline/'+path]
 if method:args+=['--method',method]
 if body is not None:args+=['--input','-']
 try:r=subprocess.run(args,input=None if body is None else json.dumps(body).encode(),capture_output=True,timeout=40)
 except subprocess.TimeoutExpired as e:
  (home/(name+'.stdout.partial')).write_bytes((e.stdout or b'')[:1999999]);(home/(name+'.stderr.private.partial')).write_bytes((e.stderr or b'')[:1999999]);raise
 assert len(r.stdout)<2000000 and len(r.stderr)<2000000
 (home/(name+'.json')).write_bytes(r.stdout);(home/(name+'.stderr.private')).write_bytes(r.stderr)
 assert r.returncode==0,(name,r.returncode)
 return json.loads(r.stdout)
queries={'pr-before':'pulls/174','main-before':'git/ref/heads/main','checks-before':'commits/'+head+'/check-runs?per_page=100','source-run':'actions/runs/35486052277','source-jobs':'actions/runs/35486052277/jobs?per_page=100','publisher-run':'actions/runs/35486052310','publisher-jobs':'actions/runs/35486052310/jobs?per_page=100'}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 values=dict(ex.map(lambda pair:(pair[0],call(*pair)),queries.items()))
pr=values['pr-before'];assert pr['state']=='open' and not pr['draft'] and not pr['merged']
assert pr['head']['sha']==head and pr['head']['ref']=='codex/v0670-pages'
assert pr['base']['sha']==values['main-before']['object']['sha']==base
assert pr['base']['ref']=='main' and pr['base']['repo']['full_name']=='mekhovov/revealline'
assert pr['head']['repo']['full_name']=='mekhovov/revealline'
assert pr['mergeable'] is True and pr['mergeable_state']=='clean',pr['mergeable_state']
for k in ['source-run','publisher-run']:
 r=values[k];assert r['head_sha']==head and r['event']=='pull_request' and r['status']=='completed' and r['conclusion']=='success'
for kind,needed,skipped in [('source-jobs',{'preflight','build','test (1)','test (2)','test (3)','test (4)'},{'release_gate'}),('publisher-jobs',{'assemble'},{'deploy'})]:
 d=values[kind];assert d['total_count']==len(d['jobs'])
 actual={j['name']:j for j in d['jobs']};assert set(actual)==needed|skipped,set(actual)
 for name,j in actual.items():
  assert j['head_sha']==head and j['status']=='completed'
  assert j['conclusion']==('skipped' if name in skipped else 'success'),name
checks=values['checks-before'];assert checks['total_count']==len(checks['check_runs']) and len(checks['check_runs'])>=9
for c in checks['check_runs']:assert c['head_sha']==head and c['status']=='completed' and c['conclusion'] in ['success','skipped','neutral'],c['name']
(home/'premerge-review.json').write_text(json.dumps({'status':'PASS_EXACT_HEAD_ALL_REQUIRED_CHECKS','head':head,'base':base,'tree':tree,'checks':[(c['name'],c['conclusion']) for c in checks['check_runs']],'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
body={'sha':head,'merge_method':'merge','commit_title':'Publish v0.67.0 Journey preview and preserve v0.66.0 in Archive 34 (#174)'}
(home/'merge-request.json').write_text(json.dumps(body,indent=2)+'\n')
merged=call('merge-response','pulls/174/merge','PUT',body)
assert merged['merged'] is True
commit=merged['sha']
post=call('pr-after','pulls/174');assert post['merged'] is True and post['head']['sha']==head and post['merge_commit_sha']==commit
wrapper=call('merge-commit','git/commits/'+commit);assert wrapper['sha']==commit and wrapper['tree']['sha']==tree
assert [p['sha'] for p in wrapper['parents']]==[base,head]
current=call('main-after','git/ref/heads/main');assert current['object']['sha']==commit
record={'status':'MERGED_EXACT_REVIEWED_TREE','commit':commit,'tree':tree,'sourceHead':head,'previousMain':base,'pr':174,'sourceRun':35486052277,'publisherPreviewRun':35486052310,'pagesDeployment':'pending; main push is the only trigger','at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(home/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
