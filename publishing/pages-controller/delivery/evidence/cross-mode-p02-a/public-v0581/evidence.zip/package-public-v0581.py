"""Create additive public evidence from original cache bytes; no Git/network writes."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import zipfile

ROOT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
BASE = ROOT / '.cache/p02a-team-note'
OUT = BASE / 'public-v0581-delivery'
LIMIT = 64 * 1024**2
sha = lambda body: hashlib.sha256(body).hexdigest()


def body(path):
    assert path.is_file() and not path.is_symlink()
    assert not any(p.is_symlink() for p in path.parents)
    assert path.stat().st_size < 20_000_000
    return path.read_bytes()


def load(path):
    return json.loads(body(path))


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


report = load(BASE / 'public-audit/tools/runs/complete-1/report.json')
after = load(BASE / 'public-audit/after-http-review.json')
native = load(BASE / 'public-native/review.json')
assert report['status'] == 'PASS' and report['files'] == 2530 and report['verifiedBytes'] == 637630752
assert report['failedFiles'] == report['retries'] == 0
assert after['status'] == 'PASS_LIVE_AUTHORITIES_UNCHANGED_AFTER_FULL_AUDIT'
assert native['status'] == 'PASS_SCOPED_PUBLIC_TEAM_CORRECTION' and native['phaseAcceptance'] is False
assert native['source'] == report['gameSourceRevision'] == 'c93019a344f6f4c6ac03940c77ea09c81122d911'
assert native['publisher'] == after['controllerCommit'] == report['controllerCommit'] == 'a1a5d0c5295196024af1a158c53acedc2f817c1a'
assert native['deployment'] == report['deploymentId'] == 6474632693
assert len(native['originals']) == 36
for row in native['originals']:
    raw = body(BASE / 'public-native' / row['path'])
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']

groups = ['public-audit', 'public-native', 'source-pr-merge',
          'publisher-v0581-admission', 'release-create', 'publish',
          'upload-dispatch', 'upload-evidence', 'native', 'native-recovered']
standalone = ['root-source-review.json', 'pr-body.md', 'parent-release-review.json',
              'release-notes.md', 'public-v0581-plan.json', 'upload-binding.reviewed.json',
              'upload-binding.draft.json', 'upload-binding.draft.json.inputs.json',
              'utility-inspection-binding.reviewed.json', 'utility-inspection-dispatch.json',
              'publish-reviewed-draft.py', 'prepare-upload-binding.py',
              'native-admission.json', 'package-public-v0581.py']
omissions = {
    'upload-evidence/completed/upload-originals-evidence-original.zip': {
        'reason': 'Redundant artifact envelope; its retained extracted original metadata, result receipts, logs and manifest are included.',
        'retainedArtifactId': 10432356433,
        'expectedBytes': 2685525,
        'expectedSha256': 'fad8ae0bb2986260b13bf1fccf2457dbc4d0d846d783cbc8edaea4f79aacbb25'},
    'upload-evidence/completed/evidence/reviewed-small-assets/source-qualification-evidence.zip': {
        'reason': 'Separate immutable source-qualification archive, already published and byte-pinned by the included release descriptors. This additive bundle contains public evidence.',
        'publicAsset': 'https://github.com/mekhovov/revealline/releases/download/v0.58.1/source-qualification-evidence.zip',
        'expectedBytes': 1738124,
        'expectedSha256': '74d0061de5415d71980f85236377a2afbd6eae4a50106c066e7b8e4006ff7e07'}
}
selected = {}
for group in groups:
    folder = BASE / group
    assert folder.is_dir() and not folder.is_symlink()
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            relative = str(path.relative_to(BASE))
            assert not any(part in ['..', 'node_modules', '__pycache__'] for part in path.parts)
            selected[relative] = path
for name in standalone:
    assert (BASE / name).is_file()
    selected[name] = BASE / name
omitted = []
for relative, description in omissions.items():
    path = selected.pop(relative)
    raw = body(path)
    assert len(raw) == description['expectedBytes'] and sha(raw) == description['expectedSha256']
    omitted.append({'sourcePath': str(path.relative_to(ROOT)), 'path': relative,
                    'bytes': len(raw), 'sha256': sha(raw), **description,
                    'originalRetainedUnchanged': True})
rows = []
for relative, path in sorted(selected.items()):
    assert path.name not in ['source.tar', 'distribution.zip', 'qualified-artifact-original.zip']
    raw = body(path)
    rows.append({'path': relative, 'sourcePath': str(path.relative_to(ROOT)),
                 'bytes': len(raw), 'sha256': sha(raw)})
assert len(rows) == len({r['path'] for r in rows}) < 2000
total = sum(row['bytes'] for row in rows)
assert total < LIMIT and shutil.disk_usage(BASE).free > 512 * 1024**2 + total * 2
assert {r['path'] for r in rows if r['path'].startswith('public-native/')} == {'public-native/review.json'} | {'public-native/' + r['path'] for r in native['originals']}
assert any(r['path'].endswith('release-create/08-draft-api.stderr') for r in rows)
assert any(r['path'].endswith('release-create/08-draft-api.result.json') for r in rows)

readme = f'''# v0.58.1 additive public delivery evidence

This bundle retains {len(rows)} original files / {total:,} bytes for the Team capability-note correction. It records evidence only; **phase acceptance is false and remains owned by the coordinating task after independent review**.

Public-byte verification passed for all 2,530 files / 637,630,752 bytes with 2,530 attempts, no failures or retries. Original inventories, attempt/result rows, hosted/API receipts, static source bodies, executed helper origins, checks and post-audit authority observations are preserved under `public-audit/`.

`public-native/` contains all 36 original screenshot/accessibility/observation files plus the original scoped review. It records Team mute/volume edits, persistence after reload, paused edits, note visibility at desktop/portrait/short-landscape browser sizes, and explicit Back retaining pause. It also preserves the clipped note and unsuccessful first scroll observations. This is not physical touchscreen/controller testing, acoustic listening, injected public storage refusal, a complete Team round, offline qualification or full P03 navigation acceptance.

Source: `c93019a344f6f4c6ac03940c77ea09c81122d911`; source PR #70 merge: `2738da2903f030bb19db95705ef9c9df18cda892`. Publisher PR #71 merge: `a1a5d0c5295196024af1a158c53acedc2f817c1a`; public run `35060819275`; deployment `6474632693`; GitHub release `389657437`.

Source/publisher review and merge provenance, stage/test outputs, release creation, uploads, publication and all related stdout/stderr/result records are retained. The original by-tag 404 after successful draft creation remains under `release-create/08-*`; the later release-list/by-ID resolution is separate. `native/` preserves the earlier unavailable-browser failure and `native-recovered/` retains its later local recovery, with their original limited scope.

`manifest.json` maps every retained member to its exact original source path, byte length and SHA-256. Two redundant binary envelopes are explicitly omitted there: the upload evidence ZIP and the separately published source-qualification evidence ZIP. Their original files are unchanged, and their exact descriptors/locators are retained. No game distribution or source TAR is included. Historical v0.58.0 evidence remains separate and is not relabelled as v0.58.1.

Public test URL: https://mekhovov.github.io/revealline/releases/v0.58.1/site/game/
'''.encode()
manifest = {
    'format': 'revealline-public-delivery-evidence.v1', 'version': 'v0.58.1',
    'phase': 'P02-A', 'phaseAcceptance': False,
    'preparedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceRevision': report['gameSourceRevision'], 'sourceTree': report['qualifiedSourceTree'],
    'publisherRevision': report['controllerCommit'], 'publisherTree': report['controllerTree'],
    'publicRunId': report['runId'], 'deploymentId': report['deploymentId'],
    'releaseId': 389657437,
    'scope': 'Additive original public-byte/native-correction/release provenance; not phase or whole-game acceptance.',
    'nativeStatus': native['status'], 'nativeOriginals': 36,
    'publicFilesVerified': 2530, 'publicBytesVerified': 637630752,
    'files': rows, 'count': len(rows), 'bytes': total,
    'omittedBinaryEvidence': omitted,
    'documentation': {'path': 'README.md', 'bytes': len(readme), 'sha256': sha(readme)},
    'historicalV0580Relabelled': False,
}
encoded = encode(manifest)
OUT.mkdir()
archive = OUT / 'evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for row in rows:
        raw = body(ROOT / row['sourcePath'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        info = zipfile.ZipInfo(row['path'], (1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, raw)
    for name, raw in [('manifest.json', encoded), ('README.md', readme)]:
        info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, raw)
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist()) == len(rows) + 2
    assert set(z.namelist()) == {r['path'] for r in rows} | {'manifest.json', 'README.md'}
    assert z.read('manifest.json') == encoded and z.read('README.md') == readme
    for row in rows:
        raw = z.read(row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        assert raw == body(ROOT / row['sourcePath'])
assert archive.stat().st_size < LIMIT
(OUT / 'manifest.json').open('xb').write(encoded)
(OUT / 'README.md').open('xb').write(readme)
receipt = {'status': 'PASS_ADDITIVE_BUNDLE_BYTES_ONLY', 'version': 'v0.58.1',
           'phaseAcceptance': False, 'originalFiles': len(rows), 'originalBytes': total,
           'archiveBytes': archive.stat().st_size, 'archiveSha256': sha(body(archive)),
           'manifestSha256': sha(encoded), 'readmeSha256': sha(readme),
           'everyOriginalAndZipMemberRehashed': True, 'emptyLogsRetained': sum(r['bytes'] == 0 for r in rows),
           'omittedBinaryEnvelopes': len(omitted), 'sourceAndDistributionArchivesIncluded': False,
           'gitOrRemoteMutation': False, 'independentReviewPending': True}
(OUT / 'receipt.json').open('xb').write(encode(receipt))
print(json.dumps(receipt, indent=2))
