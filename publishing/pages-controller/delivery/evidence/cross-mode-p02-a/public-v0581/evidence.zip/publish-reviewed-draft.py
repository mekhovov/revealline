"""Publish the exact independently reviewed draft once; retain its original response."""
from pathlib import Path
import subprocess,json,hashlib,datetime
P=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
b=read(P/'upload-binding.reviewed.json')
r=read(P/'upload-evidence/completed/review.json')
assert r['status']=='PASS_DRAFT_UPLOAD_ONLY' and r['allNineAPIAssetsMatchBindingAndHostedReceipt'] and r['releaseStillDraft'] and r['releaseId']==389657437
out=P/'publish';out.mkdir()
def get(name,endpoint):
 p=subprocess.run(['gh','api',endpoint],capture_output=True);(out/(name+'.json')).open('xb').write(p.stdout);(out/(name+'.stderr')).open('xb').write(p.stderr);assert p.returncode==0;return json.loads(p.stdout)
x=get('before','repos/mekhovov/revealline/releases/389657437')
assert x['draft'] is True and x['tag_name']=='v0.58.1' and not x['prerelease'] and len(x['assets'])==9
expected={a['name']:a for a in b['release']['assets']}
assert len(expected)==9 and set(a['name'] for a in x['assets'])==set(expected)
for a in x['assets']:
 e=expected[a['name']];assert a['state']=='uploaded' and a['size']==e['bytes'] and a['digest']=='sha256:'+e['sha256']
ref=get('tag-ref','repos/mekhovov/revealline/git/ref/tags/v0.58.1');assert ref['object']['sha']=='a055a08d6f53600276abdf8291d08313c3baf413'
tag=get('tag-object','repos/mekhovov/revealline/git/tags/'+ref['object']['sha']);assert tag['object']['sha']==b['source']['commit'] and tag['object']['type']=='commit'
assert x['body'].strip()==(P/'release-notes.md').read_text().strip()
cmd=['gh','api','-X','PATCH','repos/mekhovov/revealline/releases/389657437','-F','draft=false']
(out/'started.json').open('x').write(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':cmd,'automaticRetry':False},indent=2)+'\n')
p=subprocess.run(cmd,capture_output=True)
(out/'response.json').open('xb').write(p.stdout);(out/'stderr').open('xb').write(p.stderr);(out/'result.json').open('x').write(json.dumps({'exitCode':p.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
assert p.returncode==0
j=json.loads(p.stdout);assert j['id']==389657437 and j['tag_name']=='v0.58.1' and j['draft'] is False and not j['prerelease'] and j['published_at']
print(json.dumps({'url':j['html_url'],'publishedAt':j['published_at'],'draft':j['draft'],'assets':len(j['assets'])}))
