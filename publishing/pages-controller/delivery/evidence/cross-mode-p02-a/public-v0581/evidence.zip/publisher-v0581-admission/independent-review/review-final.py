from pathlib import Path
import subprocess,json,hashlib,copy,datetime
R=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test');W=R/'.cache/worktrees/p02a-v0581-publication';D=R/'.cache/p02a-team-note/publisher-v0581-admission';O=D/'independent-review'
BASE='c93019a344f6f4c6ac03940c77ea09c81122d911';HEAD='73dcb63d1bfbac2caf14690116a99289a61ce846';PREFIX='publishing/pages-controller/'
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_bytes())
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
def blob(ref,p):return git('show',ref+':'+p)
def doc(ref,n):return json.loads(blob(ref,PREFIX+n))
cat=doc(HEAD,'catalog.json');oldcat=doc(BASE,'catalog.json');alloc=doc(HEAD,'allocations.json');oldalloc=doc(BASE,'allocations.json');pub=doc(HEAD,'publication.json');oldpub=doc(BASE,'publication.json')
assert len(oldcat['releases'])==67 and cat['releases'][:-1]==oldcat['releases']
assert len(oldalloc['shards'])==17 and alloc['shards'][:-1]==oldalloc['shards']
assert len(oldpub['admissions'])==17 and pub['admissions'][:-1]==oldpub['admissions']
for current,old,name,key in [(cat,oldcat,'catalog.json','releases'),(alloc,oldalloc,'allocations.json','shards'),(pub,oldpub,'publication.json','admissions')]:
 restored=copy.deepcopy(current);restored[key].pop()
 if key=='admissions':
  for k in ['currentVersion','catalogSha256','allocationSha256','currentSourceQualification']:restored[k]=old[k]
 assert restored==old and (json.dumps(restored,indent=2)+'\n').encode()==blob(BASE,PREFIX+name)
assert pub['currentVersion']=='v0.58.1' and pub['testingRoutes']=={}
assert pub['catalogSha256']==sha(blob(HEAD,PREFIX+'catalog.json')) and pub['allocationSha256']==sha(blob(HEAD,PREFIX+'allocations.json'))
new=pub['admissions'][-1];assert new['id']=='archive-18' and new['infrastructureCommit']=='b83acdd80f0aaa35a72cff8c6b861250e894b1d7' and new['deploymentId']==6474004290 and len(new['evidence'])==37
assert alloc['shards'][-1]=={'id':'archive-18','repository':'mekhovov/revealline-archive-18','versions':['v0.58.0']}
intakes={r['path']:r for r in read(D/'new-evidence-intake.json')['files']};assert len(intakes)==37
rows=[]
for e in new['evidence']:
 path=PREFIX+e['path'];raw=blob(HEAD,path);r=intakes[path];assert raw==Path(r['source']).read_bytes() and sha(raw)==e['sha256']==r['sha256'] and len(raw)==r['bytes'];rows.append({'path':path,'bytes':len(raw),'sha256':sha(raw)})
assert len(set(e['path'] for e in new['evidence']))==37
browser=doc(HEAD,'evidence/archive-18/browser-admission.json');assert browser['phaseAccepted'] is False and browser['infrastructureCommit']==new['infrastructureCommit'] and browser['deploymentId']==new['deploymentId'] and browser['versions']==['v0.58.0']
for e in browser['evidence']:assert sha(blob(HEAD,PREFIX+e['path']))==e['sha256']
release=read(R/'.cache/p02a-team-note/publish/response.json');tag=read(R/'.cache/p02a-team-note/publish/tag-object.json');ref=read(R/'.cache/p02a-team-note/publish/tag-ref.json');entry=cat['releases'][-1]
assert release['id']==389657437 and release['tag_name']=='v0.58.1' and not release['draft'] and not release['prerelease'] and len(release['assets'])==9
assert tag['tag']==entry['version']==pub['currentVersion'] and tag['sha']==ref['object']['sha']==entry['tagObject'] and tag['object']['sha']==entry['sourceRevision']==release['target_commitish']==BASE
assets={a['name']:a for a in release['assets']};mrows=[]
for r in read(D/'published-metadata-intake.json')['paths']:
 raw=blob(HEAD,r['path']);a=assets[Path(r['path']).name];assert raw==Path(r['original']).read_bytes() and len(raw)==r['bytes']==a['size'] and sha(raw)==r['sha256'] and a['digest']=='sha256:'+sha(raw);mrows.append({'path':r['path'],'bytes':len(raw),'sha256':sha(raw),'assetId':a['id']})
assert sum(r['bytes'] for r in mrows)==185503
for field,name in [('recordSha256','release.json'),('manifestSha256','manifest.json'),('checksumSha256','distribution.zip.sha256')]:assert entry[field]==sha(blob(HEAD,PREFIX+'metadata/v0.58.1/'+name))
qpin=pub['currentSourceQualification'];qraw=blob(HEAD,PREFIX+qpin['path']);assert sha(qraw)==qpin['sha256'];q=json.loads(qraw);assert q['passed'] and q['sourceRevision']==q['actualCheckoutCommit']==entry['sourceRevision'] and q['sourceTree']==q['actualCheckoutTree']=='f6055cbcba92d45ef1da2b5d16e7e4f1158c8d2a' and q['tests']['pass']==4333
rec=doc(HEAD,'metadata/v0.58.1/release.json');assert assets['distribution.zip']['digest']=='sha256:'+rec['distributionSha256'] and assets['source.tar']['digest']=='sha256:'+rec['sourceArchiveSha256'] and rec['sourceRevision']==entry['sourceRevision']
expectedModified={PREFIX+s for s in ['README.md','allocations.json','catalog.json','publication.json']};expectedNew={r['path'] for r in rows+mrows}
changes={p:s for s,p in (line.split('\t') for line in git('diff','--name-status',BASE,HEAD).decode().splitlines())};assert {p for p,s in changes.items() if s=='M'}==expectedModified and {p for p,s in changes.items() if s=='A'}==expectedNew and len(changes)==45
oldMeta=git('ls-tree','-r','--name-only',BASE,'--',PREFIX+'metadata').decode().splitlines();assert len(oldMeta)==201
for p in oldMeta:assert blob(HEAD,p)==blob(BASE,p)
assert not git('diff','HEAD').strip() and git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse',HEAD+'^{tree}').decode().strip()=='71798f41b597138a6a0fbf40624d949b5cf90324'
result={'status':'PASS_SCOPED_INDEPENDENT_PUBLISHER_REVIEW','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceBase':BASE,'publisherCommit':HEAD,'publisherTree':'71798f41b597138a6a0fbf40624d949b5cf90324','historicalCatalogEntriesPreserved':67,'historicalMetadataFilesPreserved':201,'oldAdmissionsPreserved':17,'oldAllocationsPreserved':17,'oldJsonBytesRecoverExactly':True,'modifiedScope':sorted(expectedModified),'addedFiles':sorted(expectedNew),'archive18Pins':rows,'publishedMetadata':mrows,'publishedMetadataBytes':185503,'publishedRelease':389657437,'annotatedTagObject':tag['sha'],'releaseAuthorities':'Retained actual publish API response/tag records, not a new network call','qualificationSha256':qpin['sha256'],'testingRoutesUnchanged':True,'runtimeCodeChanged':False,'testsRunByReviewer':False,'stageCommitOrRemoteMutationByReviewer':False,'fullSourceOrPublicAcceptance':False,'earlierCheck':'Working-tree checker stopped at changed-path classification when root staged the new files concurrently. Byte checks passed. This final review is pinned to root commit 73dcb63d and compares Git blobs.'}
(O/'review.json').open('x').write(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k not in ['archive18Pins','publishedMetadata','addedFiles']})
