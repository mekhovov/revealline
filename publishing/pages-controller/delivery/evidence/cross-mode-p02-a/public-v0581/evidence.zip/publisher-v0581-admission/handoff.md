# Archive18 admission preparation for v0.58.1 publication

Prepared branch `codex/p02a-v0581-publication` in `.cache/worktrees/p02a-v0581-publication` at exact source `c93019a344f6f4c6ac03940c77ea09c81122d911`, tree `f6055cbcba92d45ef1da2b5d16e7e4f1158c8d2a`. No commit, staging, tests, source-code execution or remote access.

## Admission and scope

Appended Archive18 allocation for v0.58.0 and existing-format admission bound to infrastructure `b83acdd80f0aaa35a72cff8c6b861250e894b1d7`, tree `69b9a690589500ea78b240ae242efb7309474730`, deployment `6474004290`. The admission retains 37 evidence files: one inventory, one HTTP report, one generated browser wrapper and 34 original reference pins. All 36 original inputs match their retained source bytes. The native review's 24 original files match its own hashes.

Root accepted scoped historical online preservation only: title, saved-flight restoration, flight, clock failure, retry, pause, settings and return. No victory, offline, physical touch/controller, audible-listening or phase acceptance. The wrapper preserves `phaseAccepted: false`; v0.58.0's known Team notice defect remains historical. HTTP report independently records all 665 files / 312,702,795 bytes with zero failures, retries or skips. Static byte review compared all 660 original frozen payload/metadata rows against that complete inventory.

Only existing `README.md`, `allocations.json` and `publication.json` changed. The existing 67-release catalog and all old metadata files remain byte-exact. Removing the appended Archive18 records and restoring the old allocation hash reconstructs the previous allocation/publication bytes exactly. `currentVersion` remains `v0.58.0`; `currentSourceQualification`, `catalogSha256` and empty `testingRoutes` are unchanged.

## Finite population and review

`intake-manifest.json` was retained before worktree creation/population and records 631 explicit Git blob paths, modes, byte sizes and SHA256 hashes (33,362,917 source bytes). `new-evidence-intake.json` records 36 exact originals and the generated wrapper before population. Non-cone sparse paths include those 631 originals and the 37 new evidence destinations. Full Git index retained: 6,525 entries; `index.sparse=false`. All original source hashes/modes matched after population.

Final measured worktree: 668 visible files; 36,183,277 logical bytes including worktree administration and index, 37,912,576 allocated bytes. This is below the 100 MiB bound. Shared pre-existing Git object storage was not duplicated. No unrelated worktree was edited.

Review artifacts: `tracked.diff`, `new-browser-admission.diff`, `git-status.txt`, `candidate-review.json`, `population-command-receipt.json`, `population-byte-receipt.json`, `mutation-receipt.json`. The tracked diff has only the intended appended allocation/admission, allocation hash update and scoped README addition. `git diff --check` passed; this is a whitespace review, not a test or release gate.

## Root continuation

1. Review the exact diffs and original-byte intake.
2. Once the immutable v0.58.1 release exists, admit its exact three metadata paths and published source qualification path to the finite sparse list; synchronize with the existing `sync-release-metadata.mjs` command. Do not derive replacement historical metadata from source.
3. Select v0.58.1 using actual published source/tag/qualification identities, not assumed pins. Update the selector/catalog byte hashes through the existing procedure.
4. Obtain the serialized test slot before controller tests. Stage only reviewed related hunks and exact original evidence files.
5. Complete controller PR, deployment, public inventory and affected native journey gates. Recheck actual hosted archive main/deployment state before final admission.

This preparation alone does not accept P02-A, publish v0.58.1, or modify the public selector.
