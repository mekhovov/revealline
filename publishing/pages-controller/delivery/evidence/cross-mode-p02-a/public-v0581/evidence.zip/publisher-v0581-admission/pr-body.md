Publish the qualified v0.58.1 Team sound-feedback correction as the current playable release. Its permanent explanation now survives mute and volume edits while preference-storage warnings remain separate.

The selector uses the original release files from source `c93019a344f6f4c6ac03940c77ea09c81122d911` and its attached qualification. Both full source runs passed 4,333 tests; source PR #70 is merged. This PR contains publication metadata and historical-preservation evidence only.

- Preserves v0.58.0 in Archive18: all 665 public files verified, plus scoped online title, saved-flight, pause, retry and settings checks.
- Preserves all 67 earlier catalog entries and prior archive admissions unchanged; adds v0.58.1 as entry 68.
- Local controller checks: 37 JavaScript tests and four Python extraction tests pass.
- Public v0.58.1 byte verification and the affected Team journey follow the actual deployment. P02-A acceptance is not inferred from this PR.
