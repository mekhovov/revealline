from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test')
out=root/'.cache/p02a-team-note/publisher-v0581-admission'
ref='c93019a344f6f4c6ac03940c77ea09c81122d911'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def blob(p):return git('show',ref+':'+p)
def dump(name,data):
 with (out/name).open('x') as f: f.write(json.dumps(data,indent=2)+'\n')
prefix='publishing/pages-controller/'
cfg=json.loads(blob(prefix+'publication.json'));cat=json.loads(blob(prefix+'catalog.json'))
configPaths={prefix+'publication.json',prefix+'catalog.json',prefix+'allocations.json',prefix+cfg['currentSourceQualification']['path']}
for rec in cat['releases']:
 for name in ['release.json','manifest.json','distribution.zip.sha256']:configPaths.add(prefix+'metadata/'+rec['version']+'/'+name)
for a in cfg['admissions']:
 for e in a['evidence']:configPaths.add(prefix+e['path'])
tools=['.github/workflows/deploy-pages.yml','.github/workflows/publish-frozen-pages.yml','scripts/pages-archive.mjs','scripts/pages-current-entry.mjs','game/presentation/page-entry.mjs']+[prefix+p for p in ['.gitignore','README.md','assemble.mjs','assemble.test.mjs','catalog.mjs','catalog.test.mjs','extract-current.py','metadata.mjs','metadata.test.mjs','publish.mjs','release-policy.mjs','release-policy.test.mjs','sync-release-metadata.mjs','sync-release-metadata.test.mjs','test_extract_current.py','workflow.test.mjs']]
paths=sorted(configPaths|set(tools));assert len(paths)==631
objects={}
for item in git('ls-tree','-rz',ref,'--',*paths).split(b'\0'):
 if not item:continue
 header,p=item.split(b'\t',1);mode,typ,oid=header.decode().split();assert typ=='blob' and mode in ('100644','100755')
 objects[p.decode()]=(mode,oid)
assert set(objects)==set(paths)
request=''.join(objects[p][1]+'\n' for p in paths).encode()
raw=git('cat-file','--batch') if False else subprocess.check_output(['git','cat-file','--batch'],input=request,cwd=root)
position=0;rows=[]
for p in paths:
 end=raw.index(b'\n',position);head=raw[position:end].decode().split();size=int(head[2]);value=raw[end+1:end+1+size];position=end+size+2
 assert head[0]==objects[p][1] and head[1]=='blob' and len(value)==size
 rows.append({'path':p,'mode':objects[p][0],'gitBlob':objects[p][1],'bytes':size,'sha256':hashlib.sha256(value).hexdigest(),'purpose':'configuration-original' if p in configPaths else 'publisher-tool-or-test'})
assert position==len(raw)
assert sum(r['bytes'] for r in rows)==33362917
manifest={'format':'revealline-finite-source-intake.v1','sourceRevision':ref,'sourceTree':git('rev-parse',ref+'^{tree}').decode().strip(),'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'paths':len(rows),'sourceBytes':sum(r['bytes'] for r in rows),'population':'No checkout until exact manifest and sparse path list retained. Full Git/index retained; no sparse index.','files':rows}
dump('intake-manifest.json',manifest)
(out/'source-paths.txt').write_text(''.join('/'+p+'\n' for p in paths))
base=root/'.cache/p02a-team-note'; audit=base/'archive18-public-audit'; native=base/'archive18-native'
http=audit/'http/http-20260916T045812Z-6a65a60c'
review=json.loads((native/'review.json').read_text())
for item in review['originals']:
 b=(native/item['path']).read_bytes(); assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
sourcePairs=[(audit/'verification-receipts/expected-inventory.json','expected-inventory.json','inventory'),(http/'http-report.json','http-report.json','http'),(native/'review.json','native/review.json','reference')]
sourcePairs += [(native/r['path'],'native/'+r['path'],'reference') for r in review['originals']]
sourcePairs += [(http/n,'http/'+n,'reference') for n in ['http-results.jsonl','http-attempts.jsonl','auditor.py']]
sourcePairs += [(audit/n,n,'reference') for n in ['verification-receipts.zip','verification-receipts/receipt.json','verification-receipts/zip-receipt-v0.58.0.json','deployment.json','deployment-statuses.json','after-hosted-main.json']]
newRows=[]
for src,dst,kind in sourcePairs:
 b=src.read_bytes();newRows.append({'source':str(src),'path':prefix+'evidence/archive-18/'+dst,'kind':kind,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'originalBytes':True})
assert len(newRows)==36 and sum(r['bytes'] for r in newRows)==1810251
refs=[{'path':r['path'][len(prefix):],'sha256':r['sha256']} for r in newRows if r['kind']=='reference']
wrapper={'format':'revealline-archive-browser-admission.v1','status':'PASS','archiveId':'archive-18','infrastructureCommit':'b83acdd80f0aaa35a72cff8c6b861250e894b1d7','deploymentId':6474004290,'versions':['v0.58.0'],'evidence':refs,'scope':'Historical online preservation of original v0.58.0 only. Root accepted the retained native review: title, existing saved-flight restoration paused until explicit Resume, flight, clock-expired result, retry, pause, audio settings and return to title. Full HTTP independently verified all 665 files / 312702795 bytes. No victory, offline, physical touch/controller or audible listening acceptance. Original Team notice defect remains in this historical release; this is not acceptance of the v0.58.1 correction or a completed phase.','observationScopes':[{'version':'v0.58.0','nativeInfrastructureCommit':'b83acdd80f0aaa35a72cff8c6b861250e894b1d7','nativeDeploymentId':6474004290,'evidencePath':'evidence/archive-18/native/review.json','freshBrowserRun':True}],'phaseAccepted':False}
wb=(json.dumps(wrapper,indent=2)+'\n').encode();(out/'browser-admission.json').write_bytes(wb)
newRows.append({'source':str(out/'browser-admission.json'),'path':prefix+'evidence/archive-18/browser-admission.json','kind':'browser','bytes':len(wb),'sha256':hashlib.sha256(wb).hexdigest(),'originalBytes':False,'generatedFrom':'Existing admission schema and root-accepted scoped native review; no schema widening.'})
dump('new-evidence-intake.json',{'format':'revealline-archive-evidence-intake.v1','archiveId':'archive-18','files':newRows,'originalFiles':36,'originalBytes':1810251,'wrapperBytes':len(wb)})
(out/'sparse-paths.txt').write_text(''.join('/'+p+'\n' for p in sorted(set(paths)|{r['path'] for r in newRows})))
print(json.dumps({'sourcePaths':len(rows),'sourceBytes':manifest['sourceBytes'],'newEvidenceFiles':len(newRows),'newEvidenceBytes':sum(r['bytes'] for r in newRows),'sparsePaths':len(paths)+len(newRows),'manifestSha256':hashlib.sha256((out/'intake-manifest.json').read_bytes()).hexdigest()},indent=2))
