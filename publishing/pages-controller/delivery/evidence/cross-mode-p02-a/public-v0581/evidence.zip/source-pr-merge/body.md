Changing Team master mute or volume removed the explanation that this chapter currently uses visual feedback. Keep that explanation in a permanent paragraph and reserve the live status for preference-storage warnings, so successful saves clear only warnings.

The mounted regression verifies successful edits, storage refusal and recovery without starting gameplay or changing player data. Version files are synchronized at 0.58.1; related maintenance guidance, prompt examples and scoped evidence are included.

Validation: both complete hosted source runs pass 4,333 tests, all six source gates, production checks and the ordinary build. The exact frozen source and distribution passed independent inspection. The focused file passes 8/8 on Node20 and Node22; a local native keyboard journey verifies mute, volume, reload and paused edits. Public deployment and the affected public Team journey remain the release acceptance gate.
