/* Generated only in a distribution. No source page registers this template. */
(() => {
  'use strict';
  const CONFIG = {"format":"revealline-offline.v1","version":"v0.58.1","buildId":"db19b030bc8c8d2f830477c472b9b85557b03a31422cf8965b14bc0d4281e00e","files":[{"path":"authoring/asset-studio/component-specimens.mjs","bytes":8982,"sha256":"99f23bf84c7b20862055ad40e28c9537196672ea16cd4bb7a4e95f85a29bb3b6"},
{"path":"authoring/asset-studio/helpers.mjs","bytes":2814,"sha256":"8032c1b16e9b532cb5106118e955f2e98988a89b59ad24bd372d8bc95a1114da"},
{"path":"authoring/asset-studio/index.html","bytes":19628,"sha256":"52491da57241f3e8d8688d455c0c123619f30d47df1aa81f0f26188f0d4e1811"},
{"path":"authoring/asset-studio/operation.mjs","bytes":3500,"sha256":"d000d43ce10a6a0dfeacfe0a7122e894a8816a6fa58c790229768fc019568c31"},
{"path":"authoring/asset-studio/picture-context.mjs","bytes":4456,"sha256":"05ac9d677385b00072bb88ab3a6ad8443bbc618f4995916c4c5f4d8624230e2c"},
{"path":"authoring/asset-studio/preview-fixture.mjs","bytes":1523,"sha256":"4a0a9e507b9cc37b0ba45a620dd3f13a6fe9ab5657dfaf198411635cede3c46d"},
{"path":"authoring/asset-studio/preview.mjs","bytes":17686,"sha256":"96cd2ae1f81ec9483e47b6d26eea21aa708a9d6e8f2bd89e15d23a009a2facd2"},
{"path":"authoring/asset-studio/scene-preview.mjs","bytes":18029,"sha256":"89e48861d360c68aaf6d396980f477816059c327ad96b08c26b54e98c6e66937"},
{"path":"authoring/asset-studio/sprite-panel.mjs","bytes":7997,"sha256":"b662053558f8289922922ebad4eec14ebf51df4873a68a8882cd1a353c486d77"},
{"path":"authoring/asset-studio/studio.css","bytes":16358,"sha256":"af01eb19bff9e45162f52a36734caa05af25865b2751ada48a27ee4ad0657f3d"},
{"path":"authoring/asset-studio/studio.mjs","bytes":43188,"sha256":"135e5f30e114c3841928cf548a133aa43a33b17e9ff1cb923c32218060c89579"},
{"path":"authoring/design-atlas/atlas.css","bytes":40779,"sha256":"96e623bc5f38aaa39925b941dbeb1a0daa8c40b98d6dbe5319c89dde7c9b52a7"},
{"path":"authoring/design-atlas/atlas.mjs","bytes":32304,"sha256":"c3100a434bddbab145e02df98f382c073a9be8230f731ceff606214018acf44d"},
{"path":"authoring/design-atlas/index.html","bytes":24947,"sha256":"3ed4c0332eb2fdaf90b3a69a2bd4abf1c3bd0a9616aa1c48962be9277efd25e6"},
{"path":"authoring/design-atlas/reveal-audit.html","bytes":4528,"sha256":"62adebd0763e8311f83c500e40cb8db265dbd1f2a3dd382a5f4a01e6c9c9d904"},
{"path":"authoring/design-atlas/reveal-audit.json","bytes":75088,"sha256":"f0952cdfaae60d8bed364a9cf2293aa036fe802a9551b55743e863712ff09eda"},
{"path":"authoring/design-atlas/reveal-audit.mjs","bytes":4197,"sha256":"633f3ad7cdb95d9a101862314827445c9d56cfa8deb961b4efbab5bdfa5e22f9"},
{"path":"authoring/design-atlas/reveal-production-plan.json","bytes":30116,"sha256":"2a75bcc228f1fb60d5434ba89562896c4385221e82618d673f0be4555a95c648"},
{"path":"authoring/enemy-catalog/index.html","bytes":2315,"sha256":"340a84ef02a9f059dd6d1ae28184a58b4d110c6f3c669dcb56f7facfe1bfc104"},
{"path":"authoring/enemy-catalog/workshop.mjs","bytes":5651,"sha256":"05a2e36b1af834c42e3f783063d94a707db7b2fa3bf26aea4a4f93e0ade0ecdc"},
{"path":"authoring/library/fpv-field-kit/prepared/reveals/reveals.json","bytes":266665,"sha256":"fc25cf8c335518bdfd2259e26cb08e99184a9cfcf0c01018063d1b928103f92b"},
{"path":"authoring/library/fpv-field-kit/prepared/reveals/review.html","bytes":3935,"sha256":"a8d16f61dd5cbfe8a1a8e639eb23a4bebaa2a81d71ec001f1dfd8e69536b11bf"},
{"path":"authoring/library/fpv-field-kit/prepared/reveals/review.mjs","bytes":5996,"sha256":"a45831d0aa207cd7520db797829a3361082544cac53a1b8a16904d4ef863cb36"},
{"path":"authoring/library/fpv-role-presentations/originals/bomber.png","bytes":905251,"sha256":"88d9a0fac33a45e8cac2dd752df042735deebb21ff172ae0ecf86d81e47826ca"},
{"path":"authoring/library/fpv-role-presentations/originals/carrier.png","bytes":808782,"sha256":"01ed2610a94fa9675d26a618647b8128d3443e111c941199012c72510ad40ad7"},
{"path":"authoring/library/fpv-role-presentations/originals/fiber.png","bytes":899233,"sha256":"6dd3f61124d17a262ee3cef747ea250e6828d5b69a244a13883d575cc97ddce8"},
{"path":"authoring/library/fpv-role-presentations/originals/impact.png","bytes":674845,"sha256":"0999ede773d3cc70176347f39a19a96f05fc0dd96ac12b7fbd0d51304636d7ed"},
{"path":"authoring/library/fpv-role-presentations/originals/interceptor.png","bytes":679275,"sha256":"548431d87442a009fdc81b7561927eaaece164fbc2ade0c834ebd6d5f51f1a5b"},
{"path":"authoring/library/fpv-role-presentations/originals/scout.png","bytes":753111,"sha256":"5d0b29fc773e08e8fdbed1e6a03726c7a16e2c5c06e89e163ab211d032cac957"},
{"path":"authoring/library/fpv-role-presentations/originals/trapper.png","bytes":1052291,"sha256":"13e4aec02c72bf2f4a7cd26eee43c0a5e963de6bee3af3dd62dd22498831c869"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/atlas-bell-warden-v1-aaa88f04dccaa141ffb121acbb6e1b4eb9b89c0ace3e8ebddc172ba4294eabce.png","bytes":65737,"sha256":"aaa88f04dccaa141ffb121acbb6e1b4eb9b89c0ace3e8ebddc172ba4294eabce"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/atlas-carved-chest-v1-1e68e385ea2166b999e7b9041eabaf90d7b5b552a0034cdce576ddc123cbd91b.png","bytes":65737,"sha256":"1e68e385ea2166b999e7b9041eabaf90d7b5b552a0034cdce576ddc123cbd91b"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/atlas-falcon-crest-v3-f3ce0fa984bb43f3a3fa69734c60df3dfa6c8a148f0b1d32778407b92c93a648.png","bytes":65737,"sha256":"f3ce0fa984bb43f3a3fa69734c60df3dfa6c8a148f0b1d32778407b92c93a648"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/atlas-pottery-courier-v1-86089f57441d33c4153d8da5246f5e5c3822c9304d8e7b9a761ae17e5a217ea2.png","bytes":65737,"sha256":"86089f57441d33c4153d8da5246f5e5c3822c9304d8e7b9a761ae17e5a217ea2"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/atlas-swallow-v3-e01a6c53d78acf164d04878b73f06de18cfed676b894bd7353a708fd1005aaf7.png","bytes":65737,"sha256":"e01a6c53d78acf164d04878b73f06de18cfed676b894bd7353a708fd1005aaf7"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/atlas-weaver-shuttle-v3-39c737ed85d1df0c61bb05fce6424d36ea93f452ca19c7542253f37442e914aa.png","bytes":65737,"sha256":"39c737ed85d1df0c61bb05fce6424d36ea93f452ca19c7542253f37442e914aa"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/atlas-woven-basket-v1-3604eeef2dfbdf02c26f8ae8d86984cb453c52574bfd9dd87d28df015f9c50ac.png","bytes":65737,"sha256":"3604eeef2dfbdf02c26f8ae8d86984cb453c52574bfd9dd87d28df015f9c50ac"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/fpv-compact-border-patrol-v1-537de86076d2fa4141f1c37b23774015da66431657a8ff2db3193d66e0c7ade1.png","bytes":65737,"sha256":"537de86076d2fa4141f1c37b23774015da66431657a8ff2db3193d66e0c7ade1"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/fpv-compact-claimed-rover-v1-ddb9f5264822eceb35dcbfa80145c74a3e6d22a547d3171fdfa5095718e90106.png","bytes":65737,"sha256":"ddb9f5264822eceb35dcbfa80145c74a3e6d22a547d3171fdfa5095718e90106"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/fpv-compact-contour-patrol-v1-9df94fb4dcfee56fffc16d15eda5d75ff2fc06a52a7754949ca5fc9e0607a20f.png","bytes":65737,"sha256":"9df94fb4dcfee56fffc16d15eda5d75ff2fc06a52a7754949ca5fc9e0607a20f"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/fpv-compact-eroder-v1-29502a902fadb1d6e1ddf8c4426e61fc5fff9613d3c8608ebfbd55848d5e3720.png","bytes":65737,"sha256":"29502a902fadb1d6e1ddf8c4426e61fc5fff9613d3c8608ebfbd55848d5e3720"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/fpv-compact-hunter-v1-e7445fff125f6827c5106853067d1ff099b16e30cfc0acdbb501dabe81f6a914.png","bytes":65737,"sha256":"e7445fff125f6827c5106853067d1ff099b16e30cfc0acdbb501dabe81f6a914"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/fpv-compact-lane-boss-v1-e44630c2356c86db2611116dde6d12ea121d22aefef263932fabb719fc8e5dfd.png","bytes":65737,"sha256":"e44630c2356c86db2611116dde6d12ea121d22aefef263932fabb719fc8e5dfd"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/fpv-compact-relay-sentinel-v1-9640e613855c6001aa5d2a23550237a6a3235a6637a8a248a7d7cdbc21d534db.png","bytes":65737,"sha256":"9640e613855c6001aa5d2a23550237a6a3235a6637a8a248a7d7cdbc21d534db"},
{"path":"authoring/library/runtime-sprite-candidates-v1/export/manifest.json","bytes":17386,"sha256":"08400bf88a70e9c89bcd1ef207d9c2116450b39a0abf6b12cc17a2683ef4c96c"},
{"path":"authoring/library/tactical-teaching/scenarios/tactical-borrowed-seconds.json","bytes":5188,"sha256":"e5aba681c562093e4ea572b764b575dd8a21e887ac63a556cf8f6b5cb1dfa08e"},
{"path":"authoring/library/tactical-teaching/scenarios/tactical-quiet-crossing.json","bytes":5285,"sha256":"8dfe326ac35c6b75a936d5e5ed83d87ac3545464efc3f62e8c74bbc8bdbd0f3b"},
{"path":"authoring/library/tactical-teaching/scenarios/tactical-read-clearing.json","bytes":4988,"sha256":"a389174ac5619e421c4857635e1e4b6aa5abc6a91a6de5174ee6132e22b33bcd"},
{"path":"authoring/motion-lab/ability-presets.json","bytes":12087,"sha256":"05e956de444eb4ff0ff9867f8438b5dcf18702868d42bf781a98ff7e92d7858a"},
{"path":"authoring/motion-lab/ability.mjs","bytes":16262,"sha256":"287f08add0aacfaf7f5ecb7bf686179f25716c489dbfaa3dc1a54e339af6daf5"},
{"path":"authoring/motion-lab/animation.mjs","bytes":8068,"sha256":"e739040d96daea57fd782f13991d96241e11022803038af8d4d184be15981c40"},
{"path":"authoring/motion-lab/app.js","bytes":51107,"sha256":"67659a6f9c3dac01d8c8ce03f6b32be48578d84aaf3ce188d3187e91f5def166"},
{"path":"authoring/motion-lab/assets/delta-interceptor.png","bytes":468947,"sha256":"00357545f135aa3bc2ed98fa32baf46b3b0a3cd3c596054571746bae153eef9e"},
{"path":"authoring/motion-lab/assets/fixedwing-body.png","bytes":373537,"sha256":"bec5073f36946b3060aa42835ed8486e36c1c155e8b57c5c3058fa4630bf1663"},
{"path":"authoring/motion-lab/assets/fpv-body.png","bytes":644588,"sha256":"31a742f952415fb9dd2742eb9ba7ef1dc7a5aedca4593d817713c61932fe68c4"},
{"path":"authoring/motion-lab/assets/fpv-night.png","bytes":581776,"sha256":"e7df9c8f1ffb7a5ceb883e2130f0f245d208d24aae5d3527f39227ea4c589847"},
{"path":"authoring/motion-lab/assets/fpv-racer.png","bytes":879038,"sha256":"bc77fb42b3fd233a3d4391bc23e093d6d93d202d0482934f79091a310f8c01e6"},
{"path":"authoring/motion-lab/assets/heavy-lift.png","bytes":795459,"sha256":"2e1b871f2336fe2dc6434ed83afb46572f5afffd17803733914a567d39c517ec"},
{"path":"authoring/motion-lab/assets/retro-craft.png","bytes":477364,"sha256":"1d0340673c2cf19ab9b88fed271219da5003f82bcd1bd45da4477c774708551b"},
{"path":"authoring/motion-lab/assets/scout-quad.png","bytes":641545,"sha256":"14b18895b5b1c457b8db47a5c7a0485b502ad6b8fccb91697ae6b46397e73c99"},
{"path":"authoring/motion-lab/assets/ukrainian-bird.png","bytes":290701,"sha256":"fb43fb88833c5a161937097ac74e5588868c82f3b8c896c28139a77c9dffafad"},
{"path":"authoring/motion-lab/collection-presets.json","bytes":16627,"sha256":"c553f4a554a5931a155bb231a477dffa49dd3d501db1cfe17e143d767ab654e8"},
{"path":"authoring/motion-lab/collection.mjs","bytes":16779,"sha256":"90df2634277af9d728087c6b624a6b463d797a8ce5d2df681b60131430b524a4"},
{"path":"authoring/motion-lab/grid-motion.mjs","bytes":2234,"sha256":"939ae0f5126612cf94c39fee0d08f6403d2c97057d8438675991af41aac5baed"},
{"path":"authoring/motion-lab/index.html","bytes":13803,"sha256":"b29b24c227f7ddbb2085f840869760d25d5acfd09e3cf78aac3e25947e13eb33"},
{"path":"authoring/motion-lab/motion.mjs","bytes":9933,"sha256":"64eeff049089fbafe8064605ca0063b66f6bf903dec045674b79c559a7533390"},
{"path":"authoring/motion-lab/presets.json","bytes":50888,"sha256":"c1ad73a04e31f63eaa1244b5a73ba076160960746f57bf0944c53ee28e85d7ba"},
{"path":"authoring/motion-lab/render-ability.mjs","bytes":4534,"sha256":"6f5be692a679b14f6fa18d70905eef89fe3981fe2e4279ed65da763645b3f68b"},
{"path":"authoring/motion-lab/render-character.mjs","bytes":6660,"sha256":"16f55a0a9c8751a9c9ab9e1ea7f741ac727e2786ade9ed288688748e641a8b71"},
{"path":"authoring/motion-lab/steering.mjs","bytes":1208,"sha256":"c649d30f10537db0868c7c671c832add99c961f1a3863807892ccb42c483f826"},
{"path":"authoring/motion-lab/styles.css","bytes":17222,"sha256":"75ad195df9cfb331e85c9c1a30f8b6779875d9c87b525d02d6660c6720f5ab09"},
{"path":"authoring/still-media/examples/dawn-signal/Dawn-Signal-originals.rlmedia","bytes":458062,"sha256":"2cf9fb37b29f36499802638353a0a5b53042f75806b7297638e41c4bc2ccc6d9"},
{"path":"authoring/still-media/examples/dawn-signal/Dawn-Signal-stories.rlstory","bytes":730651,"sha256":"607a0952eb200178b0fe56957aeef4e1cc60784402c060ea60376358ac4d72b6"},
{"path":"authoring/still-media/examples/dawn-signal/manifest.json","bytes":2840,"sha256":"f207698be2328a687d7f9730f18a57740756186dbd4dfc547d016b828334243a"},
{"path":"authoring/still-media/index.html","bytes":5356,"sha256":"b784ebba4c565dc8d814cbe2e81246a83890bdb4992d6b02a6ee1179762859f5"},
{"path":"authoring/still-media/launch.js","bytes":901,"sha256":"69da456b730d1dbfc31b57073e26af5f7543453aa6ba456530a5e667dd725fe4"},
{"path":"authoring/still-media/workshop.mjs","bytes":100,"sha256":"e17e542120ed2f02d89c65aa9bde72b4a17b0e960d1834a19283ccad03c08394"},
{"path":"authoring/video-poster/index.html","bytes":4476,"sha256":"88c15c14163a7ab839085d12df19dd5c84734eb294f67ae8b3076191339b8ec6"},
{"path":"authoring/video-poster/launch.js","bytes":1068,"sha256":"d0b235c18713c23ac0650b72b44eb37186fef636cb13e693df3381c29d535454"},
{"path":"authoring/video-poster/workshop.css","bytes":2438,"sha256":"3c8cf94db5d3c84f0370abdafdce796920d9f08001b80fc675790f0c680cb076"},
{"path":"authoring/video-poster/workshop.mjs","bytes":114,"sha256":"6bc582e33a475201cf6d62d0fb3ffc586447649ec6a4f736a08aba998e50f933"},
{"path":"credits.html","bytes":2761,"sha256":"69a0758bece7aa149798551fd2bc0af46907256df6154842453bf76069177e42"},
{"path":"docs/asset-studio.md","bytes":14208,"sha256":"78c7a93b1d1d618fac3232ae3a7ca33420f6786f4ae0052d0ebe7bff57911845"},
{"path":"docs/field-kit-icons.md","bytes":3574,"sha256":"4ba1e5cf80c0af3ec4de2941dffd52ed37feee7d6e9ab20720f4df01618df21f"},
{"path":"docs/field-kit-production.md","bytes":8912,"sha256":"7dcc6cb0807a11852eacfd524bdbdb31a02302fd2a2b9e5e6499e418954cddd3"},
{"path":"docs/field-kit-reveals.md","bytes":4433,"sha256":"1ab0e701d5b76b6453db8707ff883319a65c000bad5ec915a8c4ea727f11af0d"},
{"path":"docs/field-kit-sprites.md","bytes":7409,"sha256":"309bc8fe2db8c6e9ca892cbfc3c52466238cfd096c1c90817e51610f3a55723f"},
{"path":"docs/field-kit-surfaces.md","bytes":4820,"sha256":"2b1d9ccbd5583a0d32459e2938b08b3ff3c1f15b7525b6c9b3bc93e4fbb6ef42"},
{"path":"docs/field-kit-title-v2.md","bytes":2011,"sha256":"8e08b3887a2bd46a7285787f0370cbde079948ac9a70496ac4fdecfa793a9399"},
{"path":"docs/fpv-redesign-design.md","bytes":14717,"sha256":"4768c9b86f6a6255b9bee0683ce702282ab5e9ac2812c205c9bc417fad4161d0"},
{"path":"docs/fpv-reveal-art-audit.md","bytes":31687,"sha256":"0fcc973c82f2c2d1fda02835cd4735595eb6aaef7b5de0da0e8500af9ccf0bd8"},
{"path":"docs/fpv-typography.md","bytes":8889,"sha256":"e9995526140e209dd242b7167d97a0a45727508cc72ff59cfeaafb9df2e5bd1c"},
{"path":"docs/presentation-audio-and-ui.md","bytes":6134,"sha256":"87345076454137cbbfcddc6566345d72ab852d50b95a2cf3869778351a4f0718"},
{"path":"docs/presentation-runtime.md","bytes":7630,"sha256":"124b16305aa305f0978bb1462434c7c9143bcacce633210129113ea1362fca17"},
{"path":"docs/presentation-system.md","bytes":14003,"sha256":"c31ba61022d63a585bb4e409cb8e3c0ef8cb78166b55a3e757340d32d63bd1f4"},
{"path":"docs/verification/fpv-redesign/baseline/README.md","bytes":1212,"sha256":"24b228ffd975c678b621027ea708a3bd37dc69f991f6235d5c7d78c7fccc002d"},
{"path":"docs/verification/fpv-redesign/baseline/briefing-phone.jpg","bytes":34161,"sha256":"f78f1206336ee34e0f7bc9fdf14eed901fe0a4f5976c0c09c5216433ff27c1c6"},
{"path":"docs/verification/fpv-redesign/baseline/flight-desktop.jpg","bytes":37358,"sha256":"4f587a1d26a76bdf829ea66f803b8b1ed5397c09c3a9786bd2b05688dc52767c"},
{"path":"docs/verification/fpv-redesign/baseline/inventory.json","bytes":1342,"sha256":"5c04725de9464505f5b7a6cd9c02a955d64c6afc24e00a1b7c156a3c6753d2d6"},
{"path":"docs/verification/fpv-redesign/baseline/missions-desktop.jpg","bytes":71739,"sha256":"45086c34650b216825c264798f2d8e6563d694ef4793f1f7c9960b222681094b"},
{"path":"docs/verification/fpv-redesign/baseline/missions-phone.jpg","bytes":37017,"sha256":"cd536880cb4be14595f650c4870888ca0b5874dcd61514c2c6a09ccaa92bab7d"},
{"path":"docs/verification/fpv-redesign/baseline/pause-desktop.jpg","bytes":50480,"sha256":"8db9ee39e9b4acbcc66e826b9a1a346020d0ea1a6842f6add18606f340feca8a"},
{"path":"docs/verification/fpv-redesign/baseline/settings-desktop.jpg","bytes":60514,"sha256":"3c562da2e902c0da660e1d9529cf1cd5123330d3e4ab172b10340448a1feb077"},
{"path":"docs/verification/fpv-redesign/baseline/title-desktop.jpg","bytes":57435,"sha256":"0a6029bc5dc2feac41417c0550ca20998798906a187e42300054bb85c214c74d"},
{"path":"docs/verification/fpv-redesign/baseline/title-phone.jpg","bytes":37598,"sha256":"445aec9e12ce8f734642f3e2e0cbb3c9a90d5b2c266799b728ca96428b2c679a"},
{"path":"game/README.md","bytes":30791,"sha256":"668dd88f7193f82125a9cfdce53adafe1910f8cbbdd3feb0a4fafabec3907a09"},
{"path":"game/app.mjs","bytes":219113,"sha256":"af398bca9d06c1ce96225d5bd5c04c89e4bcd294a35db84527cfe7c0b6a40353"},
{"path":"game/assets/field-kit/icons/contact-sheet.png","bytes":73887,"sha256":"981dcb4f82fc918cc318c483c80accd95423126bd243ffcef2a62e3de9d43f76"},
{"path":"game/assets/field-kit/icons/review.html","bytes":6167,"sha256":"23cb6b9d50beb537ed234f9426387bd4cde9436018ffacf58f5be60d2965e8f4"},
{"path":"game/assets/field-kit/icons/review.mjs","bytes":3704,"sha256":"1201e0402759ff74e367751a3be534e9b15c1d8d80b59b0cf73cc28aad9aaa95"},
{"path":"game/assets/field-kit/sprites/contact-sheet.png","bytes":50526,"sha256":"743fca1d3a1815ec53a2cfb044a985dfdd2093ba8fe3c54f64894629b9286984"},
{"path":"game/assets/field-kit/sprites/enemy-border-patrol.png","bytes":295,"sha256":"5c51f6d7b29af2e8be90adc5d01257f1b5d34ac5aaf0bb533fd2088bd944b683"},
{"path":"game/assets/field-kit/sprites/enemy-bouncer.png","bytes":290,"sha256":"e35ca174c360d5a572c72e6be448666cf3da1438cf0d91f8ea7ff8c221b8eb5e"},
{"path":"game/assets/field-kit/sprites/enemy-claimed-rover.png","bytes":282,"sha256":"fedb83171e9c894c8cbc446d4fb2bf460359b587068a33d0e108b14e185a0adc"},
{"path":"game/assets/field-kit/sprites/enemy-contour-patrol.png","bytes":269,"sha256":"4edc2d90b443fbc191cbd741c824732113a590cd758e32d8e098c63eba4e70a9"},
{"path":"game/assets/field-kit/sprites/enemy-eroder.png","bytes":275,"sha256":"05af7a73b7dadc8821cecccf0abb4f763dafae7ad21500a3293957fa88ed7d76"},
{"path":"game/assets/field-kit/sprites/enemy-lane-boss.png","bytes":446,"sha256":"cea04fc27e33583748da59f8bc873505d15b8c37745f0b30b5a4415f4d7c87cb"},
{"path":"game/assets/field-kit/sprites/enemy-relay-sentinel.png","bytes":515,"sha256":"2d4e0eafa015c8e434082b8be0552556e0abfe057248233a701cac4d1b3f4cd0"},
{"path":"game/assets/field-kit/sprites/pickup-freeze.png","bytes":233,"sha256":"02b4ab6f9e8339b921ac83fa0f72e334ab98edc82a46ae5b70499d4ea5dfb872"},
{"path":"game/assets/field-kit/sprites/pickup-life.png","bytes":185,"sha256":"7e696d173490ae948cead01a22c5650bc6ffef16c70c514ba6d88413d460a192"},
{"path":"game/assets/field-kit/sprites/pickup-objective.png","bytes":156,"sha256":"44ebf8c1d8a028a919012f75978d025d1698aeb3d295c8813edc1a7ebae71868"},
{"path":"game/assets/field-kit/sprites/pickup-slow.png","bytes":159,"sha256":"53f17c3672c097ce79b63629e4dfbffe9d5a2ecacf4ac99ec67704538951d9fe"},
{"path":"game/assets/field-kit/sprites/pickup-speed.png","bytes":137,"sha256":"5cda580ceefd258918dcf6c49f0f8ad68966999c153a876fb01c2f171b659420"},
{"path":"game/assets/field-kit/sprites/pickup-supply.png","bytes":152,"sha256":"7954823e793dd6140528d271c12653fca559eda862ca83c4be73c6bfbdf9c26c"},
{"path":"game/assets/field-kit/sprites/player-bomber-compact.png","bytes":314,"sha256":"33955b0fafb24b5edab1d605d6b3a8453a0073438aa87785cc2376ec36953346"},
{"path":"game/assets/field-kit/sprites/player-bomber-detailed.png","bytes":564,"sha256":"de2406eaf230f4701c82249f0709f1238616cca532d2be1b02d3105503646c3c"},
{"path":"game/assets/field-kit/sprites/player-carrier-compact.png","bytes":328,"sha256":"7258c2453b49a52aaa2ba003c4e076eb7aa2d87d21abb6df65f5f5178f9f6a59"},
{"path":"game/assets/field-kit/sprites/player-carrier-detailed.png","bytes":639,"sha256":"8535d7dec70f8fb64d3c0aa8ac919daa7609a477dada753b67429c9c7ae2cadb"},
{"path":"game/assets/field-kit/sprites/player-fiber-compact.png","bytes":303,"sha256":"ad53247e6be0c1c2a3080a8ebabd0ca24b1394be0caa109138926e821b08ae35"},
{"path":"game/assets/field-kit/sprites/player-fiber-detailed.png","bytes":567,"sha256":"77a93635bc7d39976bbf571f056a68f75ef43e1b655b6512fd293b2b568306e3"},
{"path":"game/assets/field-kit/sprites/player-impact-compact.png","bytes":331,"sha256":"4c0ab153dd814ff806ff0d9a63bb1ef5ad9eac532f8f771d1288265d7327ec68"},
{"path":"game/assets/field-kit/sprites/player-impact-detailed.png","bytes":583,"sha256":"f03dc7d839fef8d53cae7b29cc106dd094c976af6e3758d71110bf0d47140efa"},
{"path":"game/assets/field-kit/sprites/player-interceptor-compact.png","bytes":341,"sha256":"2d0b8b6260f73e3fe008c5ac228021f681747183a586ed7ca9dde3906b22dcc3"},
{"path":"game/assets/field-kit/sprites/player-interceptor-detailed.png","bytes":635,"sha256":"85bb90c58fb61a1fdd212316f223dad209d374386e1aad14f044df4c1ea2af7e"},
{"path":"game/assets/field-kit/sprites/player-scout-compact.png","bytes":325,"sha256":"827da59e870daf2e8548168399449bd894b4cdf7953a1f8ca48a7ed6df8f8d91"},
{"path":"game/assets/field-kit/sprites/player-scout-detailed.png","bytes":600,"sha256":"3fa6527474d2da84fed128052df7ee8ac2b34a25eaf5a162d21be849a12fd65c"},
{"path":"game/assets/field-kit/sprites/player-trapper-compact.png","bytes":327,"sha256":"83b8dea4de4fad710942a60c18f03c34849df904a45edb0316b6287c3770fb3c"},
{"path":"game/assets/field-kit/sprites/player-trapper-detailed.png","bytes":586,"sha256":"78033ee190de99663e4b936e480562d4cc93d9e90190b529ef46d07877c43826"},
{"path":"game/assets/field-kit/sprites/review.html","bytes":143023,"sha256":"7ec2829e571ca42e7d40d21f13a89f9a80e714bb9bde7d047ba6936f0b95160a"},
{"path":"game/assets/field-kit/sprites/sprites.json","bytes":109825,"sha256":"bc4e2fb6cc6608b23e0441c03f94bfd4e8c9613465aeaac55a12c5f33931d111"},
{"path":"game/assets/field-kit/sprites/terrain-lethal.png","bytes":148,"sha256":"963bdc61942194177b4d0dac32ba560c0200f55c83f21d939356b8680b6f644c"},
{"path":"game/assets/field-kit/sprites/terrain-slow.png","bytes":144,"sha256":"544551f875b2fd52c41dbbd384d6710a80fb23d744ae8a9bca3353cd23752a48"},
{"path":"game/assets/field-kit/sprites/terrain-wall.png","bytes":146,"sha256":"326d159fab7ab655e40c493e5e3ae27713157b419788134f23363ef222ad27db"},
{"path":"game/attempt-export.mjs","bytes":3620,"sha256":"14644398b8dc86c70b6ec78ea81ab99e3769358ea638e84a844569694705f819"},
{"path":"game/attempt-file.mjs","bytes":11518,"sha256":"ca2b0a1708820739fb8a1316a70a4d25f4fe8270e17aefdd19919a372f389917"},
{"path":"game/audio-preferences.mjs","bytes":5006,"sha256":"f7319b4084dfeb263e05efffb448a275f65c9aaa9fc7329f986ce6181b453da1"},
{"path":"game/backup-set.mjs","bytes":7510,"sha256":"b146e2b5aa370706f9fef5acaf6472bb89a4463cd042f1bb2260a0e39963486d"},
{"path":"game/backup-storage.mjs","bytes":17265,"sha256":"0089491ea5fb24cd78d9f4a8836d0f141ccdd54ca1f04e5d837e399e8f93303f"},
{"path":"game/backup.mjs","bytes":9540,"sha256":"73cf8a52b49e4978dd6c7b324c575cedd8084695723c791c926e51634b3ec49f"},
{"path":"game/body-derivative.mjs","bytes":1461,"sha256":"03d42444f6b5fea0eb1946ee7e5298e041177ce37f3a939abb4ccf10d5b55398"},
{"path":"game/boot.css","bytes":4734,"sha256":"f458a234db449adcb1f08c126a3c2fec55264247952e901ec2eac5d13d6e2504"},
{"path":"game/boot.mjs","bytes":7772,"sha256":"902b86a6ba9156697c865f7b055e246627c7b4081e797a5e032919ea2128aa11"},
{"path":"game/build-config.json","bytes":5252,"sha256":"ece468d35efe9ef0128336a6543ce8a225bcd46dc1b614888d356a20b4da052d"},
{"path":"game/build-info.json","bytes":143,"sha256":"ecaf5d19b94a8561866e37111da46e73c4b80b02086d1b320e4a09bec05eaab7"},
{"path":"game/campaign-contexts.mjs","bytes":4403,"sha256":"3243fc2fc9d0db9fb6cf913609a86105d87bf80270a24fde10ec3b46d5eb92b8"},
{"path":"game/campaign-difficulty.mjs","bytes":7336,"sha256":"7890880e30df503b69fef0e44e8d58bfa919243aa535ed33c6a1afaa83367b97"},
{"path":"game/challenges.mjs","bytes":1508,"sha256":"2731d620bcb4e6c5e6b65d9e09465e84c507e270d83f02f9b4af218932a98c27"},
{"path":"game/chapter-download.mjs","bytes":1326,"sha256":"c0b7c726951096edde323f552cb7e90b02026bccadc4e382a5515186405facba"},
{"path":"game/character-presentations.mjs","bytes":11597,"sha256":"9a0931cbc7411a90154671e2791beab3651f686cce7dbbdd861a3b47b1303b8f"},
{"path":"game/collection-results.mjs","bytes":852,"sha256":"6785cecc8ad293e8027a1a5d63523192423f1c825a599d16d2f0533d4b5ddba3"},
{"path":"game/content-launch.mjs","bytes":9259,"sha256":"cec26626541e3a7bb89ff07d7b787040668ff308c7833fd8e6636098d60c80a2"},
{"path":"game/content.mjs","bytes":23214,"sha256":"305dfa4d5fb4c4c27856b59abd0e71779d431f68221ac592989be8f828d75b38"},
{"path":"game/content/campaign.json","bytes":18487,"sha256":"fd46e787fec3568b8215497a7004b759d45965123ab2e33cd2d654a41aee1718"},
{"path":"game/content/classes.json","bytes":2227,"sha256":"2f776b0dfd099478ffe78465c7b602cd98896206a222a0ed7fd4405a4a643f84"},
{"path":"game/content/enemy-presentations.json","bytes":9576,"sha256":"b14fe138c264a3afef8635cd35dd67a2093a06804e31f237e01a2ba11ccd0b92"},
{"path":"game/content/external-worlds.json","bytes":12823,"sha256":"7af488500cc928ab94aa5baafdfc5bc8e9766376bc315c1117a2b05d1b539112"},
{"path":"game/content/optional-worlds.json","bytes":3973,"sha256":"83e05e0cbf64341f0f71eb0e47175ec02d7220b0a7696fac3d04f6591da10cd7"},
{"path":"game/content/packs/archive-catalog.json","bytes":2600,"sha256":"6da75db47524940c3d1469274faa652558137ef4ec55d3ef349f4c22ad70341a"},
{"path":"game/content/packs/archive-index.json","bytes":357,"sha256":"cfa5b712f0de86c303748ace3f6a2868eef72b32bfb482514eecaedd37b40082"},
{"path":"game/content/packs/catalog.json","bytes":4898,"sha256":"2e755c604a6ccc7a71d7e7b9c9e869e005856bae26354322aaff91d0d6232c0c"},
{"path":"game/content/packs/classic-lab.json","bytes":40556,"sha256":"661dfa8ec8a7304b2b3efd47195f83a0424fd9e36a2ced570435402cca5c852b"},
{"path":"game/content/packs/equipment-workshop.json","bytes":11127024,"sha256":"a015f79c47d8bac6cd09ba04e50c0c98d759e523eea7d225edbe62a8a5254054"},
{"path":"game/content/packs/fieldcraft.json","bytes":15204,"sha256":"81d01d2a51cd5d1a0f23175d8b13c5bffb73a5eaf53a8f7ddcab9ea53e3ee5fb"},
{"path":"game/content/packs/homeward-skies.json","bytes":11371849,"sha256":"4793e07a45484238bae483e2a2e9354c6d29e0ad2ba2d8d708169bd9e0250b8b"},
{"path":"game/content/packs/index.json","bytes":693,"sha256":"6f5874d7527940f46af7c58427d4ca2a2719613b9abe8246b7e0a43b4e278c67"},
{"path":"game/content/packs/living-threads.json","bytes":9156,"sha256":"c3fe1e692afcd2dfda0cc3c042f0969d1c2e655d663cf0b7034291c29d16ac52"},
{"path":"game/content/packs/night-shift.json","bytes":8848,"sha256":"b82d453a9c7a3feab9b88d960b3bf5cbeca8d5254dec3f259490c54b272acef4"},
{"path":"game/content/packs/sentinel-relay.json","bytes":11416,"sha256":"de523b416fa5a107d8d831061b54277d53b63faf17e58ab828a87e28f0fe48f1"},
{"path":"game/content/recovery-catalogs.json","bytes":279846,"sha256":"d7ee8ce41428960520907e29e7550b6f4dad8ad7a7d21686db6677f2f293e02a"},
{"path":"game/content/scenarios/line-impact-demo.json","bytes":2619,"sha256":"9f916ec62cc885ecf53bc110b5ba98f0f2c1b0307a19ec604054fcbc942a6c14"},
{"path":"game/content/themes.json","bytes":4266,"sha256":"93582f7d9ba53753106df7b63928f086820fc0f68357d3c08f26c0b89fb84774"},
{"path":"game/continuation.mjs","bytes":2831,"sha256":"41f2e36132f69ce1b91bd3a7ee1536e4b2db5e5c957fd5d4309463a48b651b32"},
{"path":"game/controller-bindings.mjs","bytes":11948,"sha256":"03f1ae09fcfc1416e3e5c933056f94643e7b8f27861f0eeed8963c9f738c204e"},
{"path":"game/controller-boost.mjs","bytes":398,"sha256":"c71973fcdf65d6809cea584054f01f445ce0fa1523c32a79986fec7f00c8d012"},
{"path":"game/controller-lab/index.html","bytes":15030,"sha256":"1e88bc042c9e7f2ee7f97f09df2b94154e45d0cd3c56f1c1ae086cffbb9214fb"},
{"path":"game/controller-lab/lab.mjs","bytes":14242,"sha256":"5937d1b323f0d6ef264516e9c64b6746faeb17148aec856391cade963938280c"},
{"path":"game/controller-lab/reading-practice.json","bytes":8518,"sha256":"f2b350c1eb556d6a0ba71e042180a2929ca35e83c40b8106cc3d147af79c98b1"},
{"path":"game/controller-lab/style.css","bytes":4902,"sha256":"35c5b3e46cba52d53f7a4ee833c428254434546e34e22276e5559f0615947685"},
{"path":"game/coop/core.mjs","bytes":37008,"sha256":"f3158679da2d0d1664f4a17d3e3e5cbb761f06e56140d171011fcf52ebfcb6bd"},
{"path":"game/coop/first-connection.mjs","bytes":540,"sha256":"41dda9601c43ae2387e6a04bde0517d97efba01a2897da89be296a161f22961a"},
{"path":"game/coop/geometry.mjs","bytes":8307,"sha256":"b508c9697a3a9ebec1e05ae12508814b93f8c96d92d1d362aca0334c3c1f0ed9"},
{"path":"game/coop/input-policy.mjs","bytes":1519,"sha256":"89e0a28cf383d79ca3c56a3faf6dc3caf9bf6b5c129764fbcdc03612d6220528"},
{"path":"game/coop/library.mjs","bytes":1337,"sha256":"1f8dc508ccf28ee70875d999b1c485e0b162abce8b92d65ec04a564684d092aa"},
{"path":"game/coop/recipes.mjs","bytes":11916,"sha256":"571d77f71f123c758288e33d4d81951ab40778c356e48e32792c44a7e67c9675"},
{"path":"game/coop/relay-yard.mjs","bytes":797,"sha256":"5fa25a3a39902e87dd0d043779f55a1305c393035208fef1fd30a70d50d905ef"},
{"path":"game/coop/threats.mjs","bytes":13742,"sha256":"824128022776185742fbcb409060111c7909181be594e19df0ffdf53c792d54f"},
{"path":"game/core/README.md","bytes":27018,"sha256":"7a3da15802c16785d0b44424e40dd01e498bf1574a815d8d13b943acd9a9ef19"},
{"path":"game/core/abilities.mjs","bytes":3855,"sha256":"bb7cb0df95beb6878878d77cac40b2cb6f2403f74e089db46432659098fb3cde"},
{"path":"game/core/arcade-actions.mjs","bytes":848,"sha256":"fa88d2371b6a6c889550ab196ac0cfbc5dced9ad8493cda126928f4cd53f2726"},
{"path":"game/core/capture.mjs","bytes":8038,"sha256":"960ebb9ecf19a656fd4fb0877cc5a1d967d1e83617b0262ba62dad4c2189aaef"},
{"path":"game/core/classic-contour.mjs","bytes":7465,"sha256":"39f096ad8a10605031eecf49227c06d77cf5032042325c0053439ed311ce5da8"},
{"path":"game/core/classic-definition.mjs","bytes":7266,"sha256":"fa49c1e2442a393b2be8e3d3b34a0eef188bbe158243f7c13cb824d18d1d3638"},
{"path":"game/core/classic-motion.mjs","bytes":12271,"sha256":"d593680e715467fd4ebfd50bf68bfdd2c3690e79ebbc579a64cdbab093c0a020"},
{"path":"game/core/classic-state.mjs","bytes":2306,"sha256":"1964712c73cbb2c793881ccf74a2899ef173eff6cc48251274cb738aa0473377"},
{"path":"game/core/classic-step.mjs","bytes":16343,"sha256":"c6078d7ce18dc8d5b4ecf3414bbf943bcb68dd80951d68e2cc7b8f1bf5b29fca"},
{"path":"game/core/classic-topology.mjs","bytes":6357,"sha256":"aae16753e999d4829dab13503f3ef603e42b73f4b44e782180881160651db3ff"},
{"path":"game/core/contacts.mjs","bytes":5168,"sha256":"aadd6aceee0380ff8e9389f305fe96b6642d553ee255ebfb7bcc1251c2c7c67b"},
{"path":"game/core/encounter.mjs","bytes":8716,"sha256":"7b98eb4ec29998ce902a62388b089a0a26b41675199bb9601e4b2a55f0df44ba"},
{"path":"game/core/enemy-pressure.mjs","bytes":11725,"sha256":"e66302eab2bc961c3328f0fc572f21d3ea67ee32132c4d0d8f15c1c08d04a2cb"},
{"path":"game/core/geometry.mjs","bytes":3989,"sha256":"8ca7877a89ea203f072fbf3b85f304844f3a3abcf992e8ba1a54f39957e6f331"},
{"path":"game/core/index.mjs","bytes":17291,"sha256":"787d7cdc759b04ae2a475e8d5ac49e0618dd26f153336ea71b5920232532e1a2"},
{"path":"game/core/level.mjs","bytes":14178,"sha256":"0a9fa39cdfa6bb6ed4c9b07a231491529777ab099f2cd6528c54fde84d5e41b8"},
{"path":"game/core/line-impact.mjs","bytes":9000,"sha256":"cf6e1b509d6789f3bd922f1374ba4ba7a80933bb8a117058dfe579bb95b547e6"},
{"path":"game/core/movement.mjs","bytes":10912,"sha256":"3f9ee5115eb94c001fe38595f39763b188ea276114ca21d1bc7a426be6e6922a"},
{"path":"game/core/registry.mjs","bytes":6661,"sha256":"ca7e365071ab3c49514343ea7683d8e552d2cd3f9fdbd0f317df64a57c0b7c2c"},
{"path":"game/core/systems.mjs","bytes":4621,"sha256":"ecfc946dbe6caf9feacab674730b8b1844e2f133c40566069d722206c6e546b6"},
{"path":"game/core/versions.mjs","bytes":3074,"sha256":"9bc39659dde70e76c63c9f9bfaa267b3cdfa07966d9096cc079383c71478eec3"},
{"path":"game/couch/coop-feedback.mjs","bytes":2277,"sha256":"b1eeb46daf1873de6dd551c19ee952495d52322587570eba26d7201d0316ccb9"},
{"path":"game/couch/coop-view.mjs","bytes":9934,"sha256":"b1e1347e48e1be2faa2e2bc6bdb9ebba2c40380690861bcb6c046a0f1871ccb3"},
{"path":"game/couch/couch-chapter.mjs","bytes":4112,"sha256":"1490f195f223ebe8f1c99444c6a76681810abc759731464a382ae4361d9b9192"},
{"path":"game/couch/couch-input.mjs","bytes":17426,"sha256":"4c53894d90fcf7b5a70b4fbe77d9cd535689bb983cbaab401ad3fd0b97c7827f"},
{"path":"game/couch/couch-installed-chapters.mjs","bytes":12625,"sha256":"58aef196b26e9e7f0af0bd969c2ec164f90a8721cca058a0c4cbf202e7f3b7fc"},
{"path":"game/couch/couch-shell.mjs","bytes":10249,"sha256":"5d1f542e7d127e9d16c4baeb9cacec70e75a2edd93c8466fab70b861364ab1a0"},
{"path":"game/couch/couch.css","bytes":9189,"sha256":"cab9b05f39138fa83744788e183dd122dac2388052dee739ea1bcb1a282feb7f"},
{"path":"game/couch/couch.mjs","bytes":38697,"sha256":"827720209904e03cda37853574196f9d3faf749b9483be51f41b5b7396abb6f6"},
{"path":"game/couch/index.html","bytes":17963,"sha256":"fd9e0646246f2ce612163ce72939b5e4db1b1edc1638fad7b1846985381cec48"},
{"path":"game/couch/relay-rescue.css","bytes":14217,"sha256":"c22775da611cf6ab4e7a611aeb9492b2e7e3f04f6e7e8d0f657f5689bae4fc03"},
{"path":"game/couch/relay-rescue.html","bytes":17093,"sha256":"845e2c6439a103e35be09b82d249efa26394ad3f4fb1df12c6d59145c0c9553f"},
{"path":"game/couch/relay-rescue.mjs","bytes":23122,"sha256":"3e56c26dcc37b3c47f9b863819ab349b3e35592c7e61a808f682d5953d4d320a"},
{"path":"game/data-json.mjs","bytes":4920,"sha256":"bcf8c3cb859473a39973cc93cee347085d3146164b0b92a02e81df57f6ffc823"},
{"path":"game/difficulty-access.mjs","bytes":5601,"sha256":"c928be5a446a46d4bdc7404b3827d08d12c7042737c8afd57513035b2dbe4b85"},
{"path":"game/difficulty-navigation.mjs","bytes":6725,"sha256":"2cc6d42ea8185a868426d0dae052768c29e250512e843507bdac9fd5b38c9223"},
{"path":"game/enemy-catalog-scenarios.mjs","bytes":3201,"sha256":"fbc58c0ad3ffbf26f759c650795237c6ebd21487732c3bc9aa73ae184ece31f5"},
{"path":"game/enemy-catalog.mjs","bytes":5966,"sha256":"46ce076af222227c5895bec7c8516f4e6e8098cfc81a9432d9fb0d6546e6c447"},
{"path":"game/enemy-guide.mjs","bytes":4922,"sha256":"ab5d6ade0f4525c0e6c5dda6a34b2b2341f5eadb080ba9a82161e94ed46071f3"},
{"path":"game/enemy-presentations.mjs","bytes":4858,"sha256":"9115deec1a9e2126062b7772879cb80ee549b810ef41f2c8b0c6b3b1f944ee0b"},
{"path":"game/external-backup-assets.mjs","bytes":9973,"sha256":"535bbf64635d3a124f947748fa112a07b69ef46f8866527a7581555aafd6d513"},
{"path":"game/external-chapter-backup.mjs","bytes":8476,"sha256":"4a5bc2dd7ee334bde4225a05212238cc07b5bb38cde1d4c9242738d65400a283"},
{"path":"game/external-chapter-catalog.mjs","bytes":5541,"sha256":"73bde936cfbf81f6a9a0a72d59eaca32bd9281c14df9c39e24e3da17fb6c95d2"},
{"path":"game/external-chapter-host.mjs","bytes":23797,"sha256":"0b4ac55f7f5c2341fbdcc402882a83644145dafb4ed0ffcd978a743ba14c7734"},
{"path":"game/external-chapter-install.mjs","bytes":14880,"sha256":"0e3d76ad653bedb57dd7c7903b28d2047a40f7102f351f4a671523034980d010"},
{"path":"game/external-chapter-pointer.mjs","bytes":6486,"sha256":"8b192d551397bbbf3f624c6cb8f6a50e2146997a41d06e5816f1f37c54949408"},
{"path":"game/external-chapter-source.mjs","bytes":32127,"sha256":"37227329d56c3fa11e46953f299b990b6f5ea11457a7cb0b628fb151762b85f8"},
{"path":"game/external-chapter.mjs","bytes":10532,"sha256":"c88368b9198c5c06057675691415bc8b2e7799c640108dbbf7e508c8c68f15c2"},
{"path":"game/external-recovery-catalog.mjs","bytes":6513,"sha256":"8457e82912df9f6afd9fd6a995f9431467219ede6ab20bf9dc4d8b5e5ff160d7"},
{"path":"game/first-flight.mjs","bytes":24628,"sha256":"7600fafa3f9543af3142b41e9ad49d8fff4866a4d81d40728ff45c3ef0475316"},
{"path":"game/flight-media-pins.mjs","bytes":4875,"sha256":"4e153e9e51579963782c83bcadbe62393b665f101111cb2651c8139e1f5d8be7"},
{"path":"game/gallery-difficulty.mjs","bytes":3454,"sha256":"3aec4002e853e7b94aef3ee0939971772f7189ebab42452432f18e692b2893ff"},
{"path":"game/generator.mjs","bytes":2245,"sha256":"1b6fbf899208d0c4ee21c66fad0a68447f00e8eda4d865e90bc53d6737ae97f2"},
{"path":"game/imports.mjs","bytes":4923,"sha256":"439c5495d62b22dd3df3e1b0abb946c18301000018afc8d84a5a8b8ca7c3f51f"},
{"path":"game/index.html","bytes":71796,"sha256":"6c96304284dadcaafe336e082918c38705aeb33cf2915b69557d8c8c0ab8c368"},
{"path":"game/input-presentation.mjs","bytes":1770,"sha256":"79c5e770a98f4c2eeb3f9854b3a2de0518c32f82889907b28b0f5d72e03d6b3c"},
{"path":"game/key-bindings.mjs","bytes":12560,"sha256":"bbd86d04ea7e45d9e140f1712e1e940956375b988841978537cd7a978da0ebe0"},
{"path":"game/library.mjs","bytes":36454,"sha256":"08b95366baaff88d3faee6260410037517b76de7e5a336e2213883f48fdc9f16"},
{"path":"game/managed-media-store.mjs","bytes":37789,"sha256":"7f9b1220b3c5fa7a27183d42df269faa212c6eea728140f89f5c5f9d4bbdf7c2"},
{"path":"game/mastery-awards.mjs","bytes":2816,"sha256":"811ad0eea30187532b1d0114a6350e338dccd10ee0d56b3477b86ca1c617fc03"},
{"path":"game/mastery-catalog.mjs","bytes":13632,"sha256":"2d7d7679b084ff1dcf6c15579605a00dd71cf611f822b79e198703fc4ac045be"},
{"path":"game/mastery-equipment.mjs","bytes":29233,"sha256":"5d45dfb343754c728277ea83a6a32ff46547adf747da65eee5ec0aa30bd09d1a"},
{"path":"game/mastery-records.mjs","bytes":10009,"sha256":"71edb762a8097fec95428444bbcb269ecfb7a02abc7ea5af7b537639cf3b330f"},
{"path":"game/mastery-verification.mjs","bytes":4572,"sha256":"a1d03f1e877762f631e7f387ecfe328704cce60e31b554e70b45b3fb0ee65f89"},
{"path":"game/mastery.mjs","bytes":16941,"sha256":"2794850285f343ac3ea30dabd22bac1e80bc45e6a73734597e364272af9d8504"},
{"path":"game/media-bundle.mjs","bytes":10383,"sha256":"5093074d02751719d230cd57ce021e868f669c8830ebe1264e4a4ea0a00aa2b9"},
{"path":"game/media-library.mjs","bytes":12188,"sha256":"ed1f1abe0b95b9889741ec8929522f0fcaba29a5438b09df18016d3ffffc6eb4"},
{"path":"game/media-presentation.mjs","bytes":1688,"sha256":"6e34dd758d1fbb85c7d6f27c651ee6ea20fc7cba013b40770b0ad24e921733fb"},
{"path":"game/media-still.mjs","bytes":5220,"sha256":"36cd1574adcc3f0b05582c1eefb56d42ce96ccc53e09ad93d9d79b9b62f548e1"},
{"path":"game/media-storage-record.mjs","bytes":11906,"sha256":"4088cff8ad53b36d31df616791f9343f935d0b832cde8f18a7766b9db6f6470e"},
{"path":"game/media-store.mjs","bytes":4947,"sha256":"a1d423742329ab37f41759fa03dbadbbc03c254580813c14f322533743c62607"},
{"path":"game/mission-brief.mjs","bytes":4673,"sha256":"f58220e9de9f0b68de5e100e8fb180856ad31be62b3616ecd0369170c4ae3078"},
{"path":"game/mp3.mjs","bytes":8902,"sha256":"76855e254b283aee0eaf1980b3f7a8c7e7b85a0fdd0e1b72cdf2d154999c3243"},
{"path":"game/multiplayer.mjs","bytes":4315,"sha256":"9addd37b1b5b460019c4cfa365692d4157ede9bb89e749f2e855d2247b4581f1"},
{"path":"game/offline.mjs","bytes":14552,"sha256":"97f8f9f622292344f3a254f7dcf588063106796b17125cd902768837fbfcca1f"},
{"path":"game/optional-chapters.mjs","bytes":8810,"sha256":"6c652e3351497575937110d748e75e5a61a0ba9f28a540f6e9a2a86a60b7f735"},
{"path":"game/packs.mjs","bytes":21347,"sha256":"6ce53ea4b4e0da27ba0bff7f76e5dc8daccc9dc6b1890f223c28e1d89da34f5c"},
{"path":"game/picture-receipts.mjs","bytes":4055,"sha256":"f777e136a1c29077af75b3b4ec053bbf854a9954b4116e13b086c510a78be004"},
{"path":"game/platform.mjs","bytes":2524,"sha256":"737f4e6dabcc08cd45ad5e5b1fb3b16792881897e89927ce5fe7fc609c0f3260"},
{"path":"game/playground/board-view.mjs","bytes":4503,"sha256":"3fadaf2a5e82d2b875d57040738a335443267f7b0f78331021c20fae521c73b9"},
{"path":"game/playground/control-geometry.mjs","bytes":8171,"sha256":"c2f116cb8e3725896ab70cfaad56415c573e888f2530bbbb00d3d3a8a355d1bb"},
{"path":"game/playground/index.html","bytes":28976,"sha256":"95d905b30649cb60c90dd002071d3595dcb6c0c4a8835f799e36c10befc0f56e"},
{"path":"game/playground/model.mjs","bytes":18214,"sha256":"e8d5a7f91add397f19176fa128995bdd9cafaffbd3e0e8c87e1c00db1bb7e62a"},
{"path":"game/playground/playground.css","bytes":6073,"sha256":"cbf4d57ec2d0af1b113fe87ad34d66e222d1aefcf8f1dd14b6c75b3bbbd790be"},
{"path":"game/playground/playground.mjs","bytes":50383,"sha256":"51fe0ca59fdda6accac018166860b94f8e676eac3fc80527eee80563f7b879f7"},
{"path":"game/playground/viewport.mjs","bytes":709,"sha256":"1f924db83e9de28cd7a8ebc7aa3f2e1c57fcf3e0755dedf31c18b8ca2dfa3986"},
{"path":"game/presentation-pins.mjs","bytes":7014,"sha256":"fd6b3b0bfc3cf1860ffe808d8644e7b490a936955d5d90f7c59dc7b9b76ad959"},
{"path":"game/presentation/bundle.mjs","bytes":8883,"sha256":"40f293fceb60c971d46f9069c91bc7594aa4065d23bfdbfc06a3b5db74cf3755"},
{"path":"game/presentation/catalog.mjs","bytes":14535,"sha256":"535739ab7b043e5c3ab9cb6ac982438737f42924635609e8e64618efb850c9c5"},
{"path":"game/presentation/compiled/assets/00b0f847cd1f80495615e3ada13899df67c6df05bf1f6d846ffc46cb3cc3fc5f.png","bytes":107,"sha256":"00b0f847cd1f80495615e3ada13899df67c6df05bf1f6d846ffc46cb3cc3fc5f"},
{"path":"game/presentation/compiled/assets/0233c5f399b93700594af044a5f56687a0742333d32b7bc54ef7122173f1dc65.png","bytes":46655,"sha256":"0233c5f399b93700594af044a5f56687a0742333d32b7bc54ef7122173f1dc65"},
{"path":"game/presentation/compiled/assets/02b4ab6f9e8339b921ac83fa0f72e334ab98edc82a46ae5b70499d4ea5dfb872.png","bytes":233,"sha256":"02b4ab6f9e8339b921ac83fa0f72e334ab98edc82a46ae5b70499d4ea5dfb872"},
{"path":"game/presentation/compiled/assets/044bfaa980686917e6715e3919617a516ee1585e38dd8a63154301eba23d4118.png","bytes":102,"sha256":"044bfaa980686917e6715e3919617a516ee1585e38dd8a63154301eba23d4118"},
{"path":"game/presentation/compiled/assets/0498bcb48294756b5ac9062290e1639e907b1ec69b5dc2e8cfdec3fab58e0bc8.woff2","bytes":40080,"sha256":"0498bcb48294756b5ac9062290e1639e907b1ec69b5dc2e8cfdec3fab58e0bc8"},
{"path":"game/presentation/compiled/assets/05af7a73b7dadc8821cecccf0abb4f763dafae7ad21500a3293957fa88ed7d76.png","bytes":275,"sha256":"05af7a73b7dadc8821cecccf0abb4f763dafae7ad21500a3293957fa88ed7d76"},
{"path":"game/presentation/compiled/assets/0839e0cac64adad321fb07518b14673091bbc1a61a836ff15ebf48510480bbbc.png","bytes":146,"sha256":"0839e0cac64adad321fb07518b14673091bbc1a61a836ff15ebf48510480bbbc"},
{"path":"game/presentation/compiled/assets/084e63a13178e1736ac2eaa12af621d63a786eea4dc21ab5cae8c6acf96c8153.png","bytes":115,"sha256":"084e63a13178e1736ac2eaa12af621d63a786eea4dc21ab5cae8c6acf96c8153"},
{"path":"game/presentation/compiled/assets/08512d067c5f322eb059dc45733fd61534b8bc530a9ebd8b33208d941a603922.png","bytes":122,"sha256":"08512d067c5f322eb059dc45733fd61534b8bc530a9ebd8b33208d941a603922"},
{"path":"game/presentation/compiled/assets/0ae5d58c1169056d086892937112a4605d56ca11b6d11e701d1e7796b18a6af7.png","bytes":134,"sha256":"0ae5d58c1169056d086892937112a4605d56ca11b6d11e701d1e7796b18a6af7"},
{"path":"game/presentation/compiled/assets/0b4b6717b5a2e7c27ad765544730193d1f798f8ccbc08879947f1a8b10e71121.png","bytes":66332,"sha256":"0b4b6717b5a2e7c27ad765544730193d1f798f8ccbc08879947f1a8b10e71121"},
{"path":"game/presentation/compiled/assets/0b5106ea19db098b6cf6068142510fd373731532e5052983e58bb343038404e6.png","bytes":46393,"sha256":"0b5106ea19db098b6cf6068142510fd373731532e5052983e58bb343038404e6"},
{"path":"game/presentation/compiled/assets/150ebf2c0817461fda33425c885488da7f4566b16a83947e94799d8da2df05e5.png","bytes":191,"sha256":"150ebf2c0817461fda33425c885488da7f4566b16a83947e94799d8da2df05e5"},
{"path":"game/presentation/compiled/assets/1aa1245d987000c889a47cd242c9ca976d620e48323cdde2a60358006718cc51.png","bytes":130,"sha256":"1aa1245d987000c889a47cd242c9ca976d620e48323cdde2a60358006718cc51"},
{"path":"game/presentation/compiled/assets/1bd3c9c57cc8790ccbf6f0fd33517d6d1a5520de93e38a99722ed4ee915758ab.png","bytes":62468,"sha256":"1bd3c9c57cc8790ccbf6f0fd33517d6d1a5520de93e38a99722ed4ee915758ab"},
{"path":"game/presentation/compiled/assets/1e3b7ea46131dbee8ca4601fd75862b04fda8ca4aa4b088d9811f5845e05eb7d.png","bytes":50028,"sha256":"1e3b7ea46131dbee8ca4601fd75862b04fda8ca4aa4b088d9811f5845e05eb7d"},
{"path":"game/presentation/compiled/assets/2033ce4e45c2b164edc31e8680244deaa475783dca1aebc6262bfffcd3980eb2.png","bytes":161,"sha256":"2033ce4e45c2b164edc31e8680244deaa475783dca1aebc6262bfffcd3980eb2"},
{"path":"game/presentation/compiled/assets/210d3b2ab32eaef632751e0333321b7e3e2a8571de758e9a02d1f350c483cf61.png","bytes":139,"sha256":"210d3b2ab32eaef632751e0333321b7e3e2a8571de758e9a02d1f350c483cf61"},
{"path":"game/presentation/compiled/assets/228285616ceb1d60be182f971790ee75a67c44a40a787d7d7ed275668a3005e4.png","bytes":40399,"sha256":"228285616ceb1d60be182f971790ee75a67c44a40a787d7d7ed275668a3005e4"},
{"path":"game/presentation/compiled/assets/2444795bb19516949a98519f0e23f9cdf64b454f01a0bb297521d17b5af376da.png","bytes":42982,"sha256":"2444795bb19516949a98519f0e23f9cdf64b454f01a0bb297521d17b5af376da"},
{"path":"game/presentation/compiled/assets/2617aa19f98e0a455046c229a9abcb678efeaa76c07ebe5ce07cb8b00d4d65bf.png","bytes":144,"sha256":"2617aa19f98e0a455046c229a9abcb678efeaa76c07ebe5ce07cb8b00d4d65bf"},
{"path":"game/presentation/compiled/assets/27fca2383ecb60fe0019232ed3f384103f602e36fe583fbad4b018b0c20d08fe.png","bytes":90,"sha256":"27fca2383ecb60fe0019232ed3f384103f602e36fe583fbad4b018b0c20d08fe"},
{"path":"game/presentation/compiled/assets/2a50c451fdee7c54d8bccf7a098f12bcdbdc15905856dc100c8e0d9e99629c33.png","bytes":77493,"sha256":"2a50c451fdee7c54d8bccf7a098f12bcdbdc15905856dc100c8e0d9e99629c33"},
{"path":"game/presentation/compiled/assets/2d0b8b6260f73e3fe008c5ac228021f681747183a586ed7ca9dde3906b22dcc3.png","bytes":341,"sha256":"2d0b8b6260f73e3fe008c5ac228021f681747183a586ed7ca9dde3906b22dcc3"},
{"path":"game/presentation/compiled/assets/2d4e0eafa015c8e434082b8be0552556e0abfe057248233a701cac4d1b3f4cd0.png","bytes":515,"sha256":"2d4e0eafa015c8e434082b8be0552556e0abfe057248233a701cac4d1b3f4cd0"},
{"path":"game/presentation/compiled/assets/2ff89ae01c04bfc698892ec3a35610b7975a6f36596ddd7ddeedbecef248d5d4.png","bytes":136,"sha256":"2ff89ae01c04bfc698892ec3a35610b7975a6f36596ddd7ddeedbecef248d5d4"},
{"path":"game/presentation/compiled/assets/30957860bb1edac99c230a91a34eab8249b43497fda680707276c859f3bd5f0c.png","bytes":34535,"sha256":"30957860bb1edac99c230a91a34eab8249b43497fda680707276c859f3bd5f0c"},
{"path":"game/presentation/compiled/assets/3104d1433851b889c70bbf8fe4d4fecd2b99a3d57d099b402286948283711fb4.png","bytes":37594,"sha256":"3104d1433851b889c70bbf8fe4d4fecd2b99a3d57d099b402286948283711fb4"},
{"path":"game/presentation/compiled/assets/326d159fab7ab655e40c493e5e3ae27713157b419788134f23363ef222ad27db.png","bytes":146,"sha256":"326d159fab7ab655e40c493e5e3ae27713157b419788134f23363ef222ad27db"},
{"path":"game/presentation/compiled/assets/33955b0fafb24b5edab1d605d6b3a8453a0073438aa87785cc2376ec36953346.png","bytes":314,"sha256":"33955b0fafb24b5edab1d605d6b3a8453a0073438aa87785cc2376ec36953346"},
{"path":"game/presentation/compiled/assets/398eaf8dc2f88a2b1a3bc4d2ae5c603f54fd5daa96c9c9c02637bdd4c488e697.png","bytes":51023,"sha256":"398eaf8dc2f88a2b1a3bc4d2ae5c603f54fd5daa96c9c9c02637bdd4c488e697"},
{"path":"game/presentation/compiled/assets/3fa6527474d2da84fed128052df7ee8ac2b34a25eaf5a162d21be849a12fd65c.png","bytes":600,"sha256":"3fa6527474d2da84fed128052df7ee8ac2b34a25eaf5a162d21be849a12fd65c"},
{"path":"game/presentation/compiled/assets/40172d186e595959d100dd0e7e52a78906e904300d93c8c0958d82b6f3b91ff0.png","bytes":148,"sha256":"40172d186e595959d100dd0e7e52a78906e904300d93c8c0958d82b6f3b91ff0"},
{"path":"game/presentation/compiled/assets/40a08a5524dbe269f6eddb019c55beebde3129ba270d97a5fa4d22015a07e0cc.png","bytes":52317,"sha256":"40a08a5524dbe269f6eddb019c55beebde3129ba270d97a5fa4d22015a07e0cc"},
{"path":"game/presentation/compiled/assets/4213f1ac958d600b68f4aa1aa0171d8f5e7a10ca2422154f88cc9b58bda9c0c1.png","bytes":150,"sha256":"4213f1ac958d600b68f4aa1aa0171d8f5e7a10ca2422154f88cc9b58bda9c0c1"},
{"path":"game/presentation/compiled/assets/43db178018db9727dc1d4f6f9231dbe2ad29fe6d75a6a84d5ed97b069e18e3a4.png","bytes":125,"sha256":"43db178018db9727dc1d4f6f9231dbe2ad29fe6d75a6a84d5ed97b069e18e3a4"},
{"path":"game/presentation/compiled/assets/44ebf8c1d8a028a919012f75978d025d1698aeb3d295c8813edc1a7ebae71868.png","bytes":156,"sha256":"44ebf8c1d8a028a919012f75978d025d1698aeb3d295c8813edc1a7ebae71868"},
{"path":"game/presentation/compiled/assets/466b729b69035d65e5a95d5ef9c8d1c337e64a6af3b5fbdcf91cf74d3096d33b.png","bytes":118,"sha256":"466b729b69035d65e5a95d5ef9c8d1c337e64a6af3b5fbdcf91cf74d3096d33b"},
{"path":"game/presentation/compiled/assets/47033ec2cd3b56345394bc13bbb7b10579419559d1e41160d02f8f3eea368672.png","bytes":46277,"sha256":"47033ec2cd3b56345394bc13bbb7b10579419559d1e41160d02f8f3eea368672"},
{"path":"game/presentation/compiled/assets/4797c11d5e17c3f5f9b5b3fa96efb4fd2aabb877fb4d625dfc8eb7465464e145.woff2","bytes":38120,"sha256":"4797c11d5e17c3f5f9b5b3fa96efb4fd2aabb877fb4d625dfc8eb7465464e145"},
{"path":"game/presentation/compiled/assets/4c0ab153dd814ff806ff0d9a63bb1ef5ad9eac532f8f771d1288265d7327ec68.png","bytes":331,"sha256":"4c0ab153dd814ff806ff0d9a63bb1ef5ad9eac532f8f771d1288265d7327ec68"},
{"path":"game/presentation/compiled/assets/4edc2d90b443fbc191cbd741c824732113a590cd758e32d8e098c63eba4e70a9.png","bytes":269,"sha256":"4edc2d90b443fbc191cbd741c824732113a590cd758e32d8e098c63eba4e70a9"},
{"path":"game/presentation/compiled/assets/4f56a78772cd7363a2992a8252e4dc629638dad705a9b981d4561830117f511e.png","bytes":790579,"sha256":"4f56a78772cd7363a2992a8252e4dc629638dad705a9b981d4561830117f511e"},
{"path":"game/presentation/compiled/assets/526656d6f29126aaec7bc7d1abf0769d247b311039c8d069c7e2afc17d112747.png","bytes":135,"sha256":"526656d6f29126aaec7bc7d1abf0769d247b311039c8d069c7e2afc17d112747"},
{"path":"game/presentation/compiled/assets/535cf4dc9b21c9ff7f9c26d4bc0657e8d6820626551b4d34d82e332748e4d9e3.png","bytes":38018,"sha256":"535cf4dc9b21c9ff7f9c26d4bc0657e8d6820626551b4d34d82e332748e4d9e3"},
{"path":"game/presentation/compiled/assets/53f1206a11a8791892f5c844c0641529acbc2c09c8d558676d0d801d72113850.png","bytes":52720,"sha256":"53f1206a11a8791892f5c844c0641529acbc2c09c8d558676d0d801d72113850"},
{"path":"game/presentation/compiled/assets/53f17c3672c097ce79b63629e4dfbffe9d5a2ecacf4ac99ec67704538951d9fe.png","bytes":159,"sha256":"53f17c3672c097ce79b63629e4dfbffe9d5a2ecacf4ac99ec67704538951d9fe"},
{"path":"game/presentation/compiled/assets/53fff7055c1021c80f93590ed4e028c85d59ea4cb2f06ac71644d29989fa2bd7.png","bytes":106,"sha256":"53fff7055c1021c80f93590ed4e028c85d59ea4cb2f06ac71644d29989fa2bd7"},
{"path":"game/presentation/compiled/assets/5428ce32eb31d44ea4b04561d86cc65e31ce79fe50acce40beadfd1d2546b837.png","bytes":47287,"sha256":"5428ce32eb31d44ea4b04561d86cc65e31ce79fe50acce40beadfd1d2546b837"},
{"path":"game/presentation/compiled/assets/544551f875b2fd52c41dbbd384d6710a80fb23d744ae8a9bca3353cd23752a48.png","bytes":144,"sha256":"544551f875b2fd52c41dbbd384d6710a80fb23d744ae8a9bca3353cd23752a48"},
{"path":"game/presentation/compiled/assets/56fadf4288069b7f12e3e33b94c950baab873a1b576d87ad82673b0c5329dd76.png","bytes":74247,"sha256":"56fadf4288069b7f12e3e33b94c950baab873a1b576d87ad82673b0c5329dd76"},
{"path":"game/presentation/compiled/assets/57744cbfe744bd50d932b1dba963539c11dbb176dc1e3171de46c34ea74d48a0.png","bytes":866080,"sha256":"57744cbfe744bd50d932b1dba963539c11dbb176dc1e3171de46c34ea74d48a0"},
{"path":"game/presentation/compiled/assets/57ee2976cb09f29863a4b3a2d8951574a93bf376eda64dbe2a171dc426d8391a.png","bytes":57734,"sha256":"57ee2976cb09f29863a4b3a2d8951574a93bf376eda64dbe2a171dc426d8391a"},
{"path":"game/presentation/compiled/assets/5c51f6d7b29af2e8be90adc5d01257f1b5d34ac5aaf0bb533fd2088bd944b683.png","bytes":295,"sha256":"5c51f6d7b29af2e8be90adc5d01257f1b5d34ac5aaf0bb533fd2088bd944b683"},
{"path":"game/presentation/compiled/assets/5cda580ceefd258918dcf6c49f0f8ad68966999c153a876fb01c2f171b659420.png","bytes":137,"sha256":"5cda580ceefd258918dcf6c49f0f8ad68966999c153a876fb01c2f171b659420"},
{"path":"game/presentation/compiled/assets/6b5afa33051459550ead8fee06fb5e14c9eecf9648906dc1abb7fe7a2c69455c.png","bytes":30571,"sha256":"6b5afa33051459550ead8fee06fb5e14c9eecf9648906dc1abb7fe7a2c69455c"},
{"path":"game/presentation/compiled/assets/70dcff8faa588f074e529704a7d6024fe0a7590b18afa6059488fb505ce4a5f7.png","bytes":159,"sha256":"70dcff8faa588f074e529704a7d6024fe0a7590b18afa6059488fb505ce4a5f7"},
{"path":"game/presentation/compiled/assets/713991ea5d2ba3bbc0f5115c6fdc98f337da90b657b0c43c7db1625073377f90.png","bytes":46471,"sha256":"713991ea5d2ba3bbc0f5115c6fdc98f337da90b657b0c43c7db1625073377f90"},
{"path":"game/presentation/compiled/assets/7258c2453b49a52aaa2ba003c4e076eb7aa2d87d21abb6df65f5f5178f9f6a59.png","bytes":328,"sha256":"7258c2453b49a52aaa2ba003c4e076eb7aa2d87d21abb6df65f5f5178f9f6a59"},
{"path":"game/presentation/compiled/assets/72b6c93f47090f3a3724223477e22cbc461132329768e70b82cdb87d85a72052.png","bytes":25969,"sha256":"72b6c93f47090f3a3724223477e22cbc461132329768e70b82cdb87d85a72052"},
{"path":"game/presentation/compiled/assets/779f36cccce55fd90340acbad1a1cbe03639cd1f98f66d25eaac3c8b0036c31b.png","bytes":46480,"sha256":"779f36cccce55fd90340acbad1a1cbe03639cd1f98f66d25eaac3c8b0036c31b"},
{"path":"game/presentation/compiled/assets/77a93635bc7d39976bbf571f056a68f75ef43e1b655b6512fd293b2b568306e3.png","bytes":567,"sha256":"77a93635bc7d39976bbf571f056a68f75ef43e1b655b6512fd293b2b568306e3"},
{"path":"game/presentation/compiled/assets/78033ee190de99663e4b936e480562d4cc93d9e90190b529ef46d07877c43826.png","bytes":586,"sha256":"78033ee190de99663e4b936e480562d4cc93d9e90190b529ef46d07877c43826"},
{"path":"game/presentation/compiled/assets/78294d66d340a9cc4036814defa9a291b8573949d79318823722b6f51c71fc14.png","bytes":123,"sha256":"78294d66d340a9cc4036814defa9a291b8573949d79318823722b6f51c71fc14"},
{"path":"game/presentation/compiled/assets/7954823e793dd6140528d271c12653fca559eda862ca83c4be73c6bfbdf9c26c.png","bytes":152,"sha256":"7954823e793dd6140528d271c12653fca559eda862ca83c4be73c6bfbdf9c26c"},
{"path":"game/presentation/compiled/assets/7e696d173490ae948cead01a22c5650bc6ffef16c70c514ba6d88413d460a192.png","bytes":185,"sha256":"7e696d173490ae948cead01a22c5650bc6ffef16c70c514ba6d88413d460a192"},
{"path":"game/presentation/compiled/assets/827da59e870daf2e8548168399449bd894b4cdf7953a1f8ca48a7ed6df8f8d91.png","bytes":325,"sha256":"827da59e870daf2e8548168399449bd894b4cdf7953a1f8ca48a7ed6df8f8d91"},
{"path":"game/presentation/compiled/assets/83b8dea4de4fad710942a60c18f03c34849df904a45edb0316b6287c3770fb3c.png","bytes":327,"sha256":"83b8dea4de4fad710942a60c18f03c34849df904a45edb0316b6287c3770fb3c"},
{"path":"game/presentation/compiled/assets/84461bcb3aca9dc91ace6a836df87a153a6c58d75b6a46b8988d9d835f68ad9f.png","bytes":48555,"sha256":"84461bcb3aca9dc91ace6a836df87a153a6c58d75b6a46b8988d9d835f68ad9f"},
{"path":"game/presentation/compiled/assets/8535d7dec70f8fb64d3c0aa8ac919daa7609a477dada753b67429c9c7ae2cadb.png","bytes":639,"sha256":"8535d7dec70f8fb64d3c0aa8ac919daa7609a477dada753b67429c9c7ae2cadb"},
{"path":"game/presentation/compiled/assets/85bb90c58fb61a1fdd212316f223dad209d374386e1aad14f044df4c1ea2af7e.png","bytes":635,"sha256":"85bb90c58fb61a1fdd212316f223dad209d374386e1aad14f044df4c1ea2af7e"},
{"path":"game/presentation/compiled/assets/8664f0283f54db86f6800fb2056045574ff79a5f490f415b3a8929112d8a7d26.png","bytes":40671,"sha256":"8664f0283f54db86f6800fb2056045574ff79a5f490f415b3a8929112d8a7d26"},
{"path":"game/presentation/compiled/assets/8a652da0dfc053d85190a2a0a17a27c43144c90a1cce5ae7883cb70f73df7c50.png","bytes":166,"sha256":"8a652da0dfc053d85190a2a0a17a27c43144c90a1cce5ae7883cb70f73df7c50"},
{"path":"game/presentation/compiled/assets/8b557a3e23bcbf550c01b5fe77618bc6ab31cce51835e80ad807023f2fc8fa47.png","bytes":140,"sha256":"8b557a3e23bcbf550c01b5fe77618bc6ab31cce51835e80ad807023f2fc8fa47"},
{"path":"game/presentation/compiled/assets/8b5ebd66c72bc3a9ccc07c5dedaba2a8c556ea4e78ef1f17650cc99bc1eca666.png","bytes":105,"sha256":"8b5ebd66c72bc3a9ccc07c5dedaba2a8c556ea4e78ef1f17650cc99bc1eca666"},
{"path":"game/presentation/compiled/assets/8d445857cc63417a2b4a9468c854e4ffed3828b3cd1a90cdd8d4f8c951be88f4.png","bytes":169,"sha256":"8d445857cc63417a2b4a9468c854e4ffed3828b3cd1a90cdd8d4f8c951be88f4"},
{"path":"game/presentation/compiled/assets/8fe3df81db48bf682862a06c8f7434365ff49151a2a72a94c0a85ea85a3adf27.png","bytes":23827,"sha256":"8fe3df81db48bf682862a06c8f7434365ff49151a2a72a94c0a85ea85a3adf27"},
{"path":"game/presentation/compiled/assets/94353c17fbc74e21655a3c556075885a144900b6c620ba7b37ab79beb31f246f.png","bytes":41769,"sha256":"94353c17fbc74e21655a3c556075885a144900b6c620ba7b37ab79beb31f246f"},
{"path":"game/presentation/compiled/assets/95b99a09686ab417503cd8444f6b485d1021b6ae3f8e9525a545faafd6254c9c.png","bytes":97,"sha256":"95b99a09686ab417503cd8444f6b485d1021b6ae3f8e9525a545faafd6254c9c"},
{"path":"game/presentation/compiled/assets/963bdc61942194177b4d0dac32ba560c0200f55c83f21d939356b8680b6f644c.png","bytes":148,"sha256":"963bdc61942194177b4d0dac32ba560c0200f55c83f21d939356b8680b6f644c"},
{"path":"game/presentation/compiled/assets/97986545bbd0dd978d7c5cd2b3511b800cb082caf4a584416306b6c3f4283b54.png","bytes":44852,"sha256":"97986545bbd0dd978d7c5cd2b3511b800cb082caf4a584416306b6c3f4283b54"},
{"path":"game/presentation/compiled/assets/9ad64ed82783ba763f61fe954e3cdc8c360df472c8d035ef74579670d2649bba.png","bytes":190,"sha256":"9ad64ed82783ba763f61fe954e3cdc8c360df472c8d035ef74579670d2649bba"},
{"path":"game/presentation/compiled/assets/9b6313464e6e6f26dff9b98405fba899dcd0c6a614fde6df8ed1a2d835c73f34.png","bytes":105,"sha256":"9b6313464e6e6f26dff9b98405fba899dcd0c6a614fde6df8ed1a2d835c73f34"},
{"path":"game/presentation/compiled/assets/9bc684f5da99a255c09d7cd6aac452859d5ec370d344a092901576bdc9405911.png","bytes":37278,"sha256":"9bc684f5da99a255c09d7cd6aac452859d5ec370d344a092901576bdc9405911"},
{"path":"game/presentation/compiled/assets/9c181b9009de288e0ed3349ab0bda4908e67c92587946517115b9231d5ea65b8.png","bytes":143,"sha256":"9c181b9009de288e0ed3349ab0bda4908e67c92587946517115b9231d5ea65b8"},
{"path":"game/presentation/compiled/assets/9e865e30bb22014bc6cc20dd4038415f4b279164ab33c54d9682e7ffc9cf2c91.png","bytes":107,"sha256":"9e865e30bb22014bc6cc20dd4038415f4b279164ab33c54d9682e7ffc9cf2c91"},
{"path":"game/presentation/compiled/assets/9ef850d87a46eee28cbfa3df8f2d2945673b8bf5dc2fdcc4edf1840175e3f7a1.png","bytes":36209,"sha256":"9ef850d87a46eee28cbfa3df8f2d2945673b8bf5dc2fdcc4edf1840175e3f7a1"},
{"path":"game/presentation/compiled/assets/9f649ed85a5ff7d88996729975dfcb3b4df001474b02cd34114dcf4fc5e2b49c.png","bytes":159,"sha256":"9f649ed85a5ff7d88996729975dfcb3b4df001474b02cd34114dcf4fc5e2b49c"},
{"path":"game/presentation/compiled/assets/a07fe2df221cb042a05a7ef78716ae1809e9df5dd54d7dd550c91bd265f7f7fb.png","bytes":71144,"sha256":"a07fe2df221cb042a05a7ef78716ae1809e9df5dd54d7dd550c91bd265f7f7fb"},
{"path":"game/presentation/compiled/assets/a25dc0c7e2f24a5451f3fbb0d24e90fdce796b274d8b54f238cbee0a26e8b857.png","bytes":111,"sha256":"a25dc0c7e2f24a5451f3fbb0d24e90fdce796b274d8b54f238cbee0a26e8b857"},
{"path":"game/presentation/compiled/assets/a3ad1f5a90f71164d77039f7052ce3403e684f1e9acecb0d3c86a7d456e9d509.png","bytes":119,"sha256":"a3ad1f5a90f71164d77039f7052ce3403e684f1e9acecb0d3c86a7d456e9d509"},
{"path":"game/presentation/compiled/assets/aa2e8583a56b36b5357e5462aee6b010b5b894626929afbc553c683462ce42cf.png","bytes":138,"sha256":"aa2e8583a56b36b5357e5462aee6b010b5b894626929afbc553c683462ce42cf"},
{"path":"game/presentation/compiled/assets/ad53247e6be0c1c2a3080a8ebabd0ca24b1394be0caa109138926e821b08ae35.png","bytes":303,"sha256":"ad53247e6be0c1c2a3080a8ebabd0ca24b1394be0caa109138926e821b08ae35"},
{"path":"game/presentation/compiled/assets/b0e9acf3605b9c5440328ef0bea6c0959efd03acdddbc4ac2cc5520e036457b6.png","bytes":113,"sha256":"b0e9acf3605b9c5440328ef0bea6c0959efd03acdddbc4ac2cc5520e036457b6"},
{"path":"game/presentation/compiled/assets/b65d23a488db2a276f1332680fbf394b1aee685fffc42f0b093c01506041f143.png","bytes":116,"sha256":"b65d23a488db2a276f1332680fbf394b1aee685fffc42f0b093c01506041f143"},
{"path":"game/presentation/compiled/assets/bd423baa7b3b4f073251d5c8291aa78ee11c341926d27f9f211aa278bc7557f6.png","bytes":46214,"sha256":"bd423baa7b3b4f073251d5c8291aa78ee11c341926d27f9f211aa278bc7557f6"},
{"path":"game/presentation/compiled/assets/c0f4e7ca9de3a9f06637dbc8d5972b69b7e804f1bbd9579f5724d99a02c5c86b.png","bytes":147,"sha256":"c0f4e7ca9de3a9f06637dbc8d5972b69b7e804f1bbd9579f5724d99a02c5c86b"},
{"path":"game/presentation/compiled/assets/c1aedf89bc3433dc1cb60998fa1e2563480a590c38586332f444c4c12c772fce.png","bytes":40810,"sha256":"c1aedf89bc3433dc1cb60998fa1e2563480a590c38586332f444c4c12c772fce"},
{"path":"game/presentation/compiled/assets/c234ea41a080121e73eeea20e3e3db5cfedcd4d4793bc31cf7cdfb2dad2a96ca.png","bytes":36951,"sha256":"c234ea41a080121e73eeea20e3e3db5cfedcd4d4793bc31cf7cdfb2dad2a96ca"},
{"path":"game/presentation/compiled/assets/c3cd0a0f9997f28d1a295de1c8995ebe81bf782acb1c033036371c49fc40a08e.png","bytes":109,"sha256":"c3cd0a0f9997f28d1a295de1c8995ebe81bf782acb1c033036371c49fc40a08e"},
{"path":"game/presentation/compiled/assets/cae1523d150bbe69f65028676129ba9c51958f4561671c5d6dee1eecfb48b3b5.png","bytes":49664,"sha256":"cae1523d150bbe69f65028676129ba9c51958f4561671c5d6dee1eecfb48b3b5"},
{"path":"game/presentation/compiled/assets/cc1bc2077c62d4cea9aeba86c00d0185b3c93f7c7dfceaede414dc105859196f.png","bytes":111,"sha256":"cc1bc2077c62d4cea9aeba86c00d0185b3c93f7c7dfceaede414dc105859196f"},
{"path":"game/presentation/compiled/assets/cca9df45b2dde64684489deab8f8d2ab8d5a08dab0ec0efc8455786a231c2a04.png","bytes":61879,"sha256":"cca9df45b2dde64684489deab8f8d2ab8d5a08dab0ec0efc8455786a231c2a04"},
{"path":"game/presentation/compiled/assets/ccdfe41a2adaf920c64d99f665d19d9ca6ddc2ea5251ea24bdd63beb2dfc68bd.png","bytes":31289,"sha256":"ccdfe41a2adaf920c64d99f665d19d9ca6ddc2ea5251ea24bdd63beb2dfc68bd"},
{"path":"game/presentation/compiled/assets/cea04fc27e33583748da59f8bc873505d15b8c37745f0b30b5a4415f4d7c87cb.png","bytes":446,"sha256":"cea04fc27e33583748da59f8bc873505d15b8c37745f0b30b5a4415f4d7c87cb"},
{"path":"game/presentation/compiled/assets/d22b1070efad07ed1e6f9d8e42d3dc7e19922478e7abedad3f08d55e53cf065c.png","bytes":40454,"sha256":"d22b1070efad07ed1e6f9d8e42d3dc7e19922478e7abedad3f08d55e53cf065c"},
{"path":"game/presentation/compiled/assets/d4690eb2839e8f90a4ac105502c5b22c1b1cceb643c5d2593ca3a4e61d6aa008.png","bytes":44881,"sha256":"d4690eb2839e8f90a4ac105502c5b22c1b1cceb643c5d2593ca3a4e61d6aa008"},
{"path":"game/presentation/compiled/assets/d5227e40b6ef6c1d722bbfb09c828789facf18b0021d6e600a456fdd37ba7e11.png","bytes":162,"sha256":"d5227e40b6ef6c1d722bbfb09c828789facf18b0021d6e600a456fdd37ba7e11"},
{"path":"game/presentation/compiled/assets/d74c2e8c5713201203f7decea8d57881b657a2aa7b24ea00d182cbe4efa51b8d.png","bytes":42831,"sha256":"d74c2e8c5713201203f7decea8d57881b657a2aa7b24ea00d182cbe4efa51b8d"},
{"path":"game/presentation/compiled/assets/d76f309d8385cd5d20fc2fff72b7f3abc19299cccdde767d76dd9f4a4960929d.png","bytes":38090,"sha256":"d76f309d8385cd5d20fc2fff72b7f3abc19299cccdde767d76dd9f4a4960929d"},
{"path":"game/presentation/compiled/assets/d9ee53a1cc344517624e80785e764da99fa8bd9b90d7f2b9b5d2ac52ff236a4b.png","bytes":188,"sha256":"d9ee53a1cc344517624e80785e764da99fa8bd9b90d7f2b9b5d2ac52ff236a4b"},
{"path":"game/presentation/compiled/assets/dda5900559255b1bad906b80a1b9a3cee914ba732f6dcb4fdb8b3c9bce50633f.png","bytes":32275,"sha256":"dda5900559255b1bad906b80a1b9a3cee914ba732f6dcb4fdb8b3c9bce50633f"},
{"path":"game/presentation/compiled/assets/de2406eaf230f4701c82249f0709f1238616cca532d2be1b02d3105503646c3c.png","bytes":564,"sha256":"de2406eaf230f4701c82249f0709f1238616cca532d2be1b02d3105503646c3c"},
{"path":"game/presentation/compiled/assets/df6e1a2a114dce2da1643a39d608d87ca79d1eaba70cfd62ac02892d0fadec6e.png","bytes":47294,"sha256":"df6e1a2a114dce2da1643a39d608d87ca79d1eaba70cfd62ac02892d0fadec6e"},
{"path":"game/presentation/compiled/assets/e033d8a3118b42b870e2f6350f7ae960b6085b46beb32ae235881a53bfbdc066.png","bytes":42638,"sha256":"e033d8a3118b42b870e2f6350f7ae960b6085b46beb32ae235881a53bfbdc066"},
{"path":"game/presentation/compiled/assets/e325a3a5b3647614bffa5432779f4ade7e865158e384888888f83b073aff033c.png","bytes":123,"sha256":"e325a3a5b3647614bffa5432779f4ade7e865158e384888888f83b073aff033c"},
{"path":"game/presentation/compiled/assets/e35ca174c360d5a572c72e6be448666cf3da1438cf0d91f8ea7ff8c221b8eb5e.png","bytes":290,"sha256":"e35ca174c360d5a572c72e6be448666cf3da1438cf0d91f8ea7ff8c221b8eb5e"},
{"path":"game/presentation/compiled/assets/e85e9aa8f56ba214bcdc9184feb99f526f1a89f66627ac0bf278bffa123dc7c9.png","bytes":40846,"sha256":"e85e9aa8f56ba214bcdc9184feb99f526f1a89f66627ac0bf278bffa123dc7c9"},
{"path":"game/presentation/compiled/assets/ee156b11b8102f73615260895e66be4e420bd3d7c70aec7150b556cdc9999a1c.png","bytes":115,"sha256":"ee156b11b8102f73615260895e66be4e420bd3d7c70aec7150b556cdc9999a1c"},
{"path":"game/presentation/compiled/assets/ee325025999edc73751f62ee92adc73c02fe06d29680da5816f4785e014ef730.png","bytes":69492,"sha256":"ee325025999edc73751f62ee92adc73c02fe06d29680da5816f4785e014ef730"},
{"path":"game/presentation/compiled/assets/efef00b62e24bc89315f26fe888d64658bb63cfcce3eeb047645c812903d3e3f.png","bytes":45086,"sha256":"efef00b62e24bc89315f26fe888d64658bb63cfcce3eeb047645c812903d3e3f"},
{"path":"game/presentation/compiled/assets/f03dc7d839fef8d53cae7b29cc106dd094c976af6e3758d71110bf0d47140efa.png","bytes":583,"sha256":"f03dc7d839fef8d53cae7b29cc106dd094c976af6e3758d71110bf0d47140efa"},
{"path":"game/presentation/compiled/assets/f3f58d09752c8e635e06145abc2460909f90ce2df664a8034a799e0bbe59c3ee.png","bytes":51056,"sha256":"f3f58d09752c8e635e06145abc2460909f90ce2df664a8034a799e0bbe59c3ee"},
{"path":"game/presentation/compiled/assets/f7495ea7b56215ba88c7d465fa6ad9ab22121695e4c674cf183b65ef6d400ae0.png","bytes":106,"sha256":"f7495ea7b56215ba88c7d465fa6ad9ab22121695e4c674cf183b65ef6d400ae0"},
{"path":"game/presentation/compiled/assets/fce2dc8f15375b66d336c1defbca23dfb2310301b62c822206a0a013d19601ef.woff2","bytes":76652,"sha256":"fce2dc8f15375b66d336c1defbca23dfb2310301b62c822206a0a013d19601ef"},
{"path":"game/presentation/compiled/assets/fedb83171e9c894c8cbc446d4fb2bf460359b587068a33d0e108b14e185a0adc.png","bytes":282,"sha256":"fedb83171e9c894c8cbc446d4fb2bf460359b587068a33d0e108b14e185a0adc"},
{"path":"game/presentation/compiled/assets/ff2e2defa02d62198a0be240fb16c8328d8be7c6aa9e3ec4516c7589edd83b22.png","bytes":162,"sha256":"ff2e2defa02d62198a0be240fb16c8328d8be7c6aa9e3ec4516c7589edd83b22"},
{"path":"game/presentation/compiled/manifest.json","bytes":27214,"sha256":"5c9a9af2586896a3b19cff0258a504d2e146609777287cb390a3e76db162c11f"},
{"path":"game/presentation/compiled/runtime.json","bytes":969577,"sha256":"368dac8c09a978c67dca85dd2ae1d1d35edf40f4b3150d175c7e49810a9ac339"},
{"path":"game/presentation/compiled/studio.json","bytes":3234605,"sha256":"b3df72a40a0e8b086c16dd65478f6d2786bd536c849c97a183cfefac4fb5d43b"},
{"path":"game/presentation/compiled/theme.css","bytes":2057,"sha256":"8b3baca084d898773986c1e3691855f92572c6db39901e8e4f9138e23470f9b3"},
{"path":"game/presentation/current-art-sources.mjs","bytes":530468,"sha256":"20a244f16cc1871e88924f30d93876abf04975880ec82124d0597cb2bda68c72"},
{"path":"game/presentation/current-art.mjs","bytes":14639,"sha256":"f38ece4c0d60fcf09910a82eba9e2c8dbd0c79babf95f54cbd93e98291f765e3"},
{"path":"game/presentation/current-picture-baselines.mjs","bytes":12897,"sha256":"f36a077e33397110bcc34e98cd8ac526b836a46e71e999cff9cb7ef6241fe91d"},
{"path":"game/presentation/current-pictures.mjs","bytes":49810,"sha256":"8f5e54c7e68d5f5870dbce6695db713516c0f732ce4aee984f5de50170f51a95"},
{"path":"game/presentation/host.mjs","bytes":27939,"sha256":"f63aae713bad754ca826fa3d7c0ea2455db4f5d56b55882cd2ef6f196ec13798"},
{"path":"game/presentation/icons.mjs","bytes":17030,"sha256":"750dd23fcac12fff007505ec4b8e91d81c2dae6d9e92fdcc8777fddd187a6780"},
{"path":"game/presentation/model.mjs","bytes":26831,"sha256":"921c85a5d4cbabf5384ebd0ad43f62dffc8ff7ff03f97abffcc69634a46c211d"},
{"path":"game/presentation/page-entry.mjs","bytes":2745,"sha256":"4bdbd4bacd1a3e2822c7f49130f8f802dee5eeebf0e194c3c08838a2ab156e5c"},
{"path":"game/presentation/page.mjs","bytes":5300,"sha256":"d3c40d9f05d42dcc2edc35eca39a817e313eafdfa4113a1ca6ecac89681e1ee3"},
{"path":"game/presentation/pixel-art.mjs","bytes":21430,"sha256":"544c975f88686455607dbed2f4babb472dc1ad5d9992d878c8c91dc2b123e582"},
{"path":"game/presentation/published-studio.mjs","bytes":4259,"sha256":"1818506f7057ae787b9f6ec1e9d0f337720e2b4cdc2a4359c2b4fd455fbafa65"},
{"path":"game/presentation/release-pictures.mjs","bytes":14302,"sha256":"74c80b817091f064c5ac775f6450382a4acd7e5a9362ece810e77862f187064d"},
{"path":"game/presentation/runtime.mjs","bytes":7206,"sha256":"c2877907aa6059c506b9c4f62e9e73bf0517c5a38edd9ec0a87788edc9af4b10"},
{"path":"game/presentation/sprite-editor.mjs","bytes":6860,"sha256":"db6345f534b9c30f5ad65c1046ccf6352a1b51907de679dcef123a7de2ae1705"},
{"path":"game/presentation/studio-session.mjs","bytes":11783,"sha256":"b1646b0da0fbb4c9279d87104993260a4540a3ef62867b101524b68db160da53"},
{"path":"game/presentation/studio-store.mjs","bytes":6637,"sha256":"bf7bd4a8e37b31402ab6415e2fc87332349e966fcb6e15c9d7b352ab879e7d38"},
{"path":"game/profile-channel-assets.mjs","bytes":6445,"sha256":"9ec29503959d391f6d134426e983cf9c782bc6abe3ea3a03242fd13f4e498bd8"},
{"path":"game/profile-channel-json.mjs","bytes":1522,"sha256":"e0412dea3f9a1d5fdb27602b6db752f6c62af6bf5d93c010a00834e482346f5a"},
{"path":"game/profile-channel-reader.mjs","bytes":26097,"sha256":"c9a11bae5d3e8825aec26cfdb0a5b8f2e8ace838a7e45d5ebddc244490c6308e"},
{"path":"game/profile-channel.mjs","bytes":3248,"sha256":"baa0c972955bb75a787840bfb21882a026ea364a350bca7193468f5504585be8"},
{"path":"game/profile-original-recovery.mjs","bytes":4284,"sha256":"5ff29313dbaf127d712633d516e169ae28e3d0252c385aa2f4e4702a6552cc4e"},
{"path":"game/profile-recovery-catalogs.mjs","bytes":4649,"sha256":"5a8e16f1ff6b00e5d507c27cc9fa16fc06bebb23fd490399a998a0a15c5006c8"},
{"path":"game/profile-recovery.html","bytes":6005,"sha256":"0ca099df8af83399c9c62bf6df4676d2f8c5ece1a9a04073cf9d58c9f6ec2705"},
{"path":"game/profile-recovery.mjs","bytes":4291,"sha256":"2d67375be243b3092261b9c87c6626b73082ead53ad2be087e1ac14f0c4e17bf"},
{"path":"game/profile-shared-media.mjs","bytes":15469,"sha256":"1b668825850ec511def024d0fcc8cae666eb358c926875252fa575538186068a"},
{"path":"game/profile-transfer.mjs","bytes":14130,"sha256":"eef7f356c827ebc22a50c96356b63ebcb247f46cd33b07357593056c1767f3e2"},
{"path":"game/profile-writer.mjs","bytes":2372,"sha256":"54c871a6bb7bcb6acc15c9d120f66693cf69cfe9363ff82ebbee85aa7fcb78d0"},
{"path":"game/progress.mjs","bytes":14612,"sha256":"7bfdff5fde139b7def3383b95767aac04424becd07302f1f72724295fe3d37b2"},
{"path":"game/release-explorer.mjs","bytes":448,"sha256":"440ca2e8344c4ab7f0053dc3248fbb357ed9bb8b1c4b9423a0988d7419e437f1"},
{"path":"game/replay-player.mjs","bytes":6210,"sha256":"8c2e1e5636ae0fb091c5d02cddc36212ae73899bc4391444ab21e69e7c4fd757"},
{"path":"game/replay-theater/app.mjs","bytes":15693,"sha256":"6e410caa5a512f2361c143b90447259fc6ee796b6a69aea1d2f7611d956a852b"},
{"path":"game/replay-theater/data/fieldcraft-01.replay.json","bytes":7644,"sha256":"61330819bae8b378851efd23a239f6685952d76af54fa6172e55d741702db853"},
{"path":"game/replay-theater/data/fieldcraft-02.replay.json","bytes":9818,"sha256":"093a520328f5cab12f792b888b0316333db04aad9cf868291a5be130d706f8ee"},
{"path":"game/replay-theater/data/fieldcraft-03.replay.json","bytes":7586,"sha256":"1ca12465d5235c6c42312852f45c68bb16d6daa8ab7d06af9fe4216db06e45e8"},
{"path":"game/replay-theater/data/fieldcraft-04.replay.json","bytes":7564,"sha256":"6f61b3229c6d1716d8b27fce35bfe649ea27bc85a9ded1b4b77d5c051aa0efa8"},
{"path":"game/replay-theater/index.html","bytes":11067,"sha256":"32a010b493c7049f0239adb1387faa082e6c0569ccd2b73b88bbdf4f8f23898e"},
{"path":"game/replay-theater/navigation.mjs","bytes":4329,"sha256":"44a7f9f887b1af7f42e84713c55fda031187d92f55485b496ec80951967ba199"},
{"path":"game/replay-theater/theater.css","bytes":7388,"sha256":"ef8f8a90abdac7a96a47b6d6b73649c97819058543b9037fbf8a44462cf936cc"},
{"path":"game/replay.mjs","bytes":23633,"sha256":"4ff829ba1e0998adf003e7991a29daea466ac7d6a2177e2115301020a3247b7b"},
{"path":"game/replays/campaign-routes.json","bytes":59180,"sha256":"335fcd9379f6202e71a36284ac10c14f07edeb375ccf96e310d8546776bb1d73"},
{"path":"game/replays/classic-lab-routes.json","bytes":57670,"sha256":"d8f0c7da011680af5c62e8dbb14f658bfe2f510ed720d2682ec6f18106d10563"},
{"path":"game/replays/expansion-routes.json","bytes":81574,"sha256":"22886cf439f716db31333b3b6d9fae0478f8007aff734632badc7c2f38dc53c8"},
{"path":"game/replays/fieldcraft-routes.json","bytes":388881,"sha256":"53255e41c150b293a67a9771628f81f8b9dd6f42e23be201f3959ebbaa01c43e"},
{"path":"game/replays/first-light-gentle-routes.json","bytes":26858,"sha256":"7c9e8f635169ba398e868c7b8e5fe6c5818a4fa05b7a3d20f604aca7aa8e2e50"},
{"path":"game/replays/first-light-routes.json","bytes":24934,"sha256":"9b258ae74b98104f7e0cb6ed0ce5a4cc6c32234b50845a65d0028bea9a07dd4b"},
{"path":"game/replays/fpv-arcade-r2-routes.json","bytes":98943,"sha256":"38e3c0b0c0c94e8b28055c923a5b0acfb7c96c039587f52bcfb2927d0a7fc6c5"},
{"path":"game/replays/fpv-arcade-r3-routes.json","bytes":84391,"sha256":"b8ea3fb9998aba9131561f4424fea090549049480065d215c6d2b87285f07e69"},
{"path":"game/replays/fpv-arcade-r4-routes.json","bytes":65603,"sha256":"c201476e6846bf0edf66066729cbca01613a55a0711fa643357c818344e776c5"},
{"path":"game/replays/fpv-arcade-r5-routes.json","bytes":316505,"sha256":"0fff81cd1db68106695b3fb92ddbba04025c379597e6d4fa6dc5a8bd0b7825de"},
{"path":"game/replays/gentle-routes.json","bytes":203443,"sha256":"4debc2838b70ca9b3edf0aa2e869b8f697a500ac04f946b120956367d0c22eca"},
{"path":"game/replays/homeward-routes.json","bytes":318515,"sha256":"63a77908b1ce98b480f9fd0431894e4f1d58ad56e4266ae0860206de564d8c1a"},
{"path":"game/replays/sentinel-routes.json","bytes":256854,"sha256":"b704c71879c29810f42dca6e94857c6728d2439c08d1807edc008114bdb85a70"},
{"path":"game/selection-bookmark.mjs","bytes":3083,"sha256":"f3de75f398215ffb1e3087a87912ddcde4d9692f216665cc8a886799dae2a81e"},
{"path":"game/sessions.mjs","bytes":10279,"sha256":"889f44790e68d36af4135445f22f8f484dc6341e36235866c486aced35c13ecb"},
{"path":"game/soundtrack-bundle.mjs","bytes":7059,"sha256":"0707d47e0cbd89c3b3d64cd22acf6b430bb4b5ff581d9a085196a0f5b48f4758"},
{"path":"game/soundtrack-store-legacy.mjs","bytes":9093,"sha256":"73534a723ca283716a97fa04a145c5a677d5e5543b47fc8a9e126b6bb7ff13ab"},
{"path":"game/soundtrack-store.mjs","bytes":1073,"sha256":"2f4d16b4c341ebad5399ed80983e8edda62bb1ea6a2af140fd6f92f2509fc81c"},
{"path":"game/soundtrack.mjs","bytes":10172,"sha256":"dd3bc7362cd2ff2dccabc82137e9389fbf8e1f4859e103915b5af55c7d0184b2"},
{"path":"game/storage.mjs","bytes":1653,"sha256":"c24d54887f80e41820efd471e50130a4c507fe071a16321e81f019135bef2fb7"},
{"path":"game/story-bindings.mjs","bytes":3657,"sha256":"555415656c7052d16b1afe8a742d11baef48c0163a749bc79b2b3821d342425a"},
{"path":"game/story-bundle.mjs","bytes":9428,"sha256":"37eeca95a859b1621c7b068dbda7988c437c0111a62948806f4fb36d7f4b3cd3"},
{"path":"game/story-media-store.mjs","bytes":17612,"sha256":"7cdd1bbf10482c9bdab18657de9657c33dc6b27a6727d356c5ec1752da7aaa50"},
{"path":"game/story-receipts.mjs","bytes":2208,"sha256":"8463ccf09a48cb55c7d46627a03178960e231313dcbd29bb93c5a83b4d5b1492"},
{"path":"game/story-storage-record.mjs","bytes":12312,"sha256":"9fdd834cf7c39e5d84a33236b8f4fcb961242d3d6be54d4945aae9242d63e938"},
{"path":"game/style.css","bytes":45729,"sha256":"1e3c271f89ee4c559cece9518fb2dc75b6408295e459b97625780cc096dec6ba"},
{"path":"game/text-face.mjs","bytes":807,"sha256":"6df38ef690513d0b663a1f533e4f7c88af8adc5e0532efa9eb1b0592fed2e7d0"},
{"path":"game/text-size.mjs","bytes":251,"sha256":"a2517c4ae10a8283865594c5d04bdcc385733b6813c024ed1c635e05755c717a"},
{"path":"game/touch-controls.mjs","bytes":1651,"sha256":"247811a921e69ff3488faa3138e36db42f5bacddccd03e2d52b0f21169809cc6"},
{"path":"game/ui/actor-presentation.mjs","bytes":26201,"sha256":"7717b61e6d4e520fa9938200ab001808db43a74c5e167a6f6a9f1d956ef46a3d"},
{"path":"game/ui/art/field-kit/prepared/title-hangar-portrait-v1.png","bytes":790579,"sha256":"4f56a78772cd7363a2992a8252e4dc629638dad705a9b981d4561830117f511e"},
{"path":"game/ui/art/field-kit/prepared/title-hangar-v1.png","bytes":866080,"sha256":"57744cbfe744bd50d932b1dba963539c11dbb176dc1e3171de46c34ea74d48a0"},
{"path":"game/ui/audio-master.mjs","bytes":5277,"sha256":"b7f4ffa09292d03aa18c3377d343da5699b2affd38f0459ad4e0daa384f8670c"},
{"path":"game/ui/audio.mjs","bytes":26731,"sha256":"b0703011e0981ed4d86d62cb36b721f65f52e7033a4f63417a81287731ee0388"},
{"path":"game/ui/backup-set-panel.mjs","bytes":8446,"sha256":"06593f84e63d8df92ed521bdc9aaf64989f0b7279f54d93fef45df5d3e533fff"},
{"path":"game/ui/backup-set.css","bytes":1622,"sha256":"e4c5c1ee454f09ddd7b722f1ee1e9cb6b0122748ce21a89b22ebf998300ea41b"},
{"path":"game/ui/celebration.mjs","bytes":7855,"sha256":"d242a42e9aa595adc00a6b85b4f2e3ead6f3a5a94e8ddc230b131b1c97827232"},
{"path":"game/ui/classic-view.mjs","bytes":21584,"sha256":"3af76e5a99f7753bef065d5322144f541b50985cf47877738f85be191cb35dc1"},
{"path":"game/ui/controller-boost-host.mjs","bytes":888,"sha256":"cc41000cce1abaf68ca19fcaf053f3803765da43094a866bcde7b2f2c2a9cddf"},
{"path":"game/ui/controller-boost-settings.mjs","bytes":1722,"sha256":"2f1b3fc0f900a275d2949b25a11b9396ca39a9586d56c59913b0713dedd51c66"},
{"path":"game/ui/controller-navigation.mjs","bytes":20848,"sha256":"db1d3952d02e46904d0f8c852157925e1bfc4bc1f34f4e4ed1576e63b45a73b6"},
{"path":"game/ui/controller-preview.mjs","bytes":7643,"sha256":"276fd2d8bd6b7bb910afde37c282e8405efd0e80d411a96afdc54a6e1b571263"},
{"path":"game/ui/controller-reading.mjs","bytes":7040,"sha256":"2094f1e4d7fde2c369ec92f7fd420394c580180db7adcbed1e02622b3bb1b6d1"},
{"path":"game/ui/controller-router.mjs","bytes":15585,"sha256":"e7ebce7d1e2e08ba193f92b2c1e80586713a1f6b98189e7dc303a06f652eebb3"},
{"path":"game/ui/controller-settings.css","bytes":2398,"sha256":"cfdc4360b453dee456605e25cb42d2b570961d31b867f34600d7c6eba427c4cf"},
{"path":"game/ui/controller-settings.mjs","bytes":16514,"sha256":"8c608eda58543578a9f7bd17090fea9d6dc025d7592435b548d263b27cd52fcf"},
{"path":"game/ui/device-controls.css","bytes":20389,"sha256":"07b568711533179efaecfb7785f9ceb6d412d0dd4f4a9b6a34718d38226f495a"},
{"path":"game/ui/direct-tool-launch.js","bytes":2507,"sha256":"665b17159332858b0eb0140eaa9018434a8b2776ba091afacbb2f4ed6ebd3181"},
{"path":"game/ui/earned-picture.mjs","bytes":3709,"sha256":"db21c1183afe5c5cdd181e11675a4143d63c6e8c4e8b13f2966538ebac0fe735"},
{"path":"game/ui/encounter-view.mjs","bytes":6241,"sha256":"90ea3ace8d9906768d51cdb0c6d52b0df2ec776e576a0111fe433e37dc1426f5"},
{"path":"game/ui/enemy-body-assets.mjs","bytes":10113,"sha256":"cec845aa99e50ffca506e0533219c089c5221fce196c25228f9313c65393ce16"},
{"path":"game/ui/enemy-body-motion.mjs","bytes":1179,"sha256":"b23cff03deada23ea77efe8d8834e31f693712775cafcb00aa236b629cb6a554"},
{"path":"game/ui/enemy-catalog-input.mjs","bytes":501,"sha256":"65cb566900d1bf1cf7c4ef8f72bfe4781f2d8f0c4bc3be98ebf32126e66aebb2"},
{"path":"game/ui/enemy-catalog-panel.css","bytes":1534,"sha256":"9def2f7013941af520a798ab68d2a75ebf1de360f56a80d915d3a36a4d83374a"},
{"path":"game/ui/enemy-catalog-panel.mjs","bytes":11273,"sha256":"c15a95b18a45d02abc9779be1ae4b2c5c98f8317da9921782b4b01dd7d1287fd"},
{"path":"game/ui/enemy-guide.css","bytes":2001,"sha256":"0ac8c85b8c6048c7cd3f375880345c281459861836e594619dc5cf5b1858b8d4"},
{"path":"game/ui/enemy-guide.mjs","bytes":17120,"sha256":"06d193bddc46d9f67af1ee773997649d2a241a1e82350a75bcd88cc2239b55f1"},
{"path":"game/ui/enemy-workshop-return.mjs","bytes":3896,"sha256":"292e94f409206bede3f27c9ce49ab8d39b32ebb443b411a7d3d9135ebc8d2bad"},
{"path":"game/ui/event-feedback.mjs","bytes":5824,"sha256":"c558dbe6fbdc91e6e9aae51cf355e557cdebf6f9319cb5ab6d886c75b5760307"},
{"path":"game/ui/field-kit-compiled.css","bytes":22607,"sha256":"9550b98a7bb3a7866716c0a16c06a2b9b32cd3a5542da32489b0f5dd4a652f01"},
{"path":"game/ui/field-kit-components.css","bytes":10003,"sha256":"52f2a5b524f5473b601d313bb4d0b5eaab49231fd9814e4075c494dae74fead8"},
{"path":"game/ui/field-kit-copy.mjs","bytes":3798,"sha256":"4213244b3056492cbd3b57c8d1b7e0a7d282b7d3272011ee73c2a385c1960f0f"},
{"path":"game/ui/field-kit-flow.css","bytes":11341,"sha256":"02c73cb46d9f76da039cade2e6691002b9298539e817bbf40d216c06f7a09708"},
{"path":"game/ui/field-kit-fonts.css","bytes":638,"sha256":"6a71c7612bd5bc9a684b4865e0fafbd802d7c35128da2fff307cabd3e359b0db"},
{"path":"game/ui/field-kit-surfaces.css","bytes":18991,"sha256":"45c804f766efcd48b6045aad4c9e5b498adb5e568aeeed78d65a3d9aaab10347"},
{"path":"game/ui/field-kit-surfaces.mjs","bytes":3149,"sha256":"4bdf868d06b8b862482cba3185fae167c6c62529085a009f3a3c4788051e368f"},
{"path":"game/ui/field-kit-tokens.css","bytes":2496,"sha256":"c58cdb0cdd2b8b1855ba70688b0f136680a37fe3637e41ffc50ae5d40778da5d"},
{"path":"game/ui/first-flight-entry.mjs","bytes":3827,"sha256":"89bb956d86acbe91ed91b13fa19cdac7e65541ffd6fbaa91124cd2eded51dbd2"},
{"path":"game/ui/first-flight-launch.mjs","bytes":957,"sha256":"d91abcd941fb9ecf25fd91083ab24f6c08bf5d8371b55f16b1ba39a016f8e95b"},
{"path":"game/ui/first-flight-preview.mjs","bytes":924,"sha256":"88baf957233a35c91aafdad9d1df70cc381b6f48aafc36b289f79c7d669a93ff"},
{"path":"game/ui/first-flight-view.mjs","bytes":7571,"sha256":"84d4261798e8ccc3defb75db4c7aca11538802e4901c442641905565998e34e7"},
{"path":"game/ui/flight-pictures.mjs","bytes":6565,"sha256":"b9d23ec50a4f5a1922ff5f44db2669cf130d5a0126b721e188d4c051a7a98cf3"},
{"path":"game/ui/focus-clearance.mjs","bytes":2325,"sha256":"71e67d4379cbf2687dda056cd95ffe41142d450e3e15074c3dd2e004426a4296"},
{"path":"game/ui/fonts/METADATA.pb","bytes":955,"sha256":"d34ce835a8c6beb627841951a0d5717cddae9bf9fde49977cd3807614adfec0d"},
{"path":"game/ui/fonts/OFL.txt","bytes":4389,"sha256":"6fe7d64407c69d187748206265977654747d3e2fe9e38e45a62cd03ec4770df6"},
{"path":"game/ui/fonts/Tiny5-Regular.ttf","bytes":132124,"sha256":"cb8168f80cfee2f47f6db59f2a7afbde31cdcdcdcf262e7a993e4d468a5bf4b0"},
{"path":"game/ui/fonts/field-kit/Exo2-OFL.txt","bytes":4386,"sha256":"7f95a8eeecc6904ffc81cd10cc8ebc7fcee72a67922924bf45f02dff03b88127"},
{"path":"game/ui/fonts/field-kit/Handjet-OFL.txt","bytes":4389,"sha256":"934a45d3b43276e1f857301e9cb07e00b829cca3d0c13e8e6f8c6790dd6c8a2c"},
{"path":"game/ui/fonts/field-kit/IBMPlexMono-OFL.txt","bytes":4456,"sha256":"7e6b2818edbd8f6a01ae80641cc8f16a51080d08fb4e532be3a0b6f74adb07da"},
{"path":"game/ui/fonts/field-kit/exo2-ui-400-600.woff2","bytes":76652,"sha256":"fce2dc8f15375b66d336c1defbca23dfb2310301b62c822206a0a013d19601ef"},
{"path":"game/ui/fonts/field-kit/handjet-display-600.woff2","bytes":38120,"sha256":"4797c11d5e17c3f5f9b5b3fa96efb4fd2aabb877fb4d625dfc8eb7465464e145"},
{"path":"game/ui/fonts/field-kit/ibm-plex-mono-500.woff2","bytes":40080,"sha256":"0498bcb48294756b5ac9062290e1639e907b1ec69b5dc2e8cfdec3fab58e0bc8"},
{"path":"game/ui/fonts/field-kit/provenance.json","bytes":3307,"sha256":"bf9cfd7804641437f4b1bddee268249d74726af70a7172a41ed2c4b61f32e8dd"},
{"path":"game/ui/fonts/pixelify-sans/METADATA.pb","bytes":939,"sha256":"adac079f2f599996ffa5952f8fdc66e643db2cdcd9a0bc84ad8ad4b8387567d4"},
{"path":"game/ui/fonts/pixelify-sans/OFL.txt","bytes":4488,"sha256":"b66ba46f511a851ab09998b5a5a9fdbb102545a3864cb993095e1745996873a7"},
{"path":"game/ui/fonts/pixelify-sans/PixelifySans.ttf","bytes":79160,"sha256":"9ba86cd010a4de309d263ceff8e8044092c9db7efda869620cb9ff1c4389e8a5"},
{"path":"game/ui/fonts/pixelify-sans/provenance.json","bytes":898,"sha256":"f569ecff185e90c165687585b7d8aba2cb17a9878b8e4ff7ea9cca400ea3fcb1"},
{"path":"game/ui/fonts/provenance.json","bytes":859,"sha256":"9215b78e5306e67f7dcfeb821ee98682ea62904700705b50a09739ba0d4824a5"},
{"path":"game/ui/fullscreen.mjs","bytes":2325,"sha256":"8f11ff46d30d584d1f069e10c40702a908929027ecfc95eef500a5802f2269ea"},
{"path":"game/ui/game-shell.css","bytes":12750,"sha256":"0cb26b492d50dbd132b7cc287e9ef80b4092293df14cd36b86016a7b6daa19c5"},
{"path":"game/ui/game-shell.mjs","bytes":14325,"sha256":"477ad6ea992908b1e819d3fb33bcaaaa2f972fa73bf81159f8addeabea2e9806"},
{"path":"game/ui/input.mjs","bytes":18003,"sha256":"32deb9e8db1311d550608a352e0364a5977137cc6e747a186f38680cbad10388"},
{"path":"game/ui/key-settings.mjs","bytes":8161,"sha256":"3c03f3d39d725fdaae6746b7e2608acc41331039b1c7eb22e42862934becd0bd"},
{"path":"game/ui/library-panel.mjs","bytes":55870,"sha256":"cdd891667a55eb5a741ef60e11fef49fca36fe105900cf14de1b6f37578c50f5"},
{"path":"game/ui/mastery-view.mjs","bytes":7740,"sha256":"5232533a6fec3c543ac2c633ef0742be8a6e0580e21541d202c4efff76c5a43b"},
{"path":"game/ui/mission-brief.css","bytes":2690,"sha256":"e2bb6384338d837cb536d59894364d488fc50256c11854389607e7dcdc77f194"},
{"path":"game/ui/mission-gallery.mjs","bytes":5387,"sha256":"4e63ef88c6edf78d26a675b667f8a812dbc77aec1ebe862d0777fe0a53e12e8e"},
{"path":"game/ui/mission-picker.css","bytes":3610,"sha256":"5bdfb7446e69cb419267d864ba11e4ab9136e7a2bf9ae6b9d0cd90e9ff00570b"},
{"path":"game/ui/mission-picker.mjs","bytes":10158,"sha256":"dc596d9f8006bdc0e297b1068e70bc84ced474ea91b71877c333f66465c7d912"},
{"path":"game/ui/mission-thumbnails.mjs","bytes":5177,"sha256":"06f19c63b4a0a50b49bd2db7ddf9f65da05f96babc1c2058ab3905405659e3af"},
{"path":"game/ui/modal-navigation.mjs","bytes":3994,"sha256":"f511800fcfba01f86a7e70566578b2016eb056b13aaad54b6632c9ebf2c43b65"},
{"path":"game/ui/music.mjs","bytes":7050,"sha256":"a1ecafd319417d075ec584d8b2f54008a8b877e49848e364bd91603896c44fda"},
{"path":"game/ui/offline-panel.mjs","bytes":4414,"sha256":"0a749d816ffe56470f8faccd248ba580cee73b8625439eb1c8350cfdb5a621cf"},
{"path":"game/ui/operation-status.css","bytes":1889,"sha256":"7e9131637045630f440ed82782bf73c8077397b35fd12c23c64665894ad59f5e"},
{"path":"game/ui/operation-status.mjs","bytes":4173,"sha256":"2048510a877f43e887081d8436532ca6bdadc4633c4cf556ad3c621015af76ab"},
{"path":"game/ui/optional-chapters-panel.css","bytes":3487,"sha256":"0b6babc8a4400496af2f0ac03afbd7dc7bd8d8b635296d79f1da5a55b7faf6de"},
{"path":"game/ui/optional-chapters-panel.mjs","bytes":27229,"sha256":"f477b6347b53995ae05a39f4e6079f091d0f6fad20a223aa2d35aa1d0b09dea6"},
{"path":"game/ui/picture-identity.mjs","bytes":3164,"sha256":"895883a76ddd62578a6c971b11160f4b977dc1b4cc83bc729120a2869820f04c"},
{"path":"game/ui/pixel-theme.css","bytes":21302,"sha256":"15d17963bfa26fe4c8f2f0c12ac5d13e8f3be91afdec6b17828d728d7ac3ee52"},
{"path":"game/ui/practice-navigation.mjs","bytes":1761,"sha256":"81ac683067848898a0978514bc73dd059884a5d5d6710979fca700c7e57bea6b"},
{"path":"game/ui/presentation-draw-image.mjs","bytes":389,"sha256":"d3f0804c19dcfbedb0a886516b14d28eed45233607b6718e1b45f136e030740e"},
{"path":"game/ui/presentation-image.mjs","bytes":9341,"sha256":"719eae1690d847bbcd9befacd6c93dc2cf72dbebb843411a176e175e48923950"},
{"path":"game/ui/profile-recovery-dialog.css","bytes":1726,"sha256":"542398fe48d3184e279c3bef3af0aa40aad98ad4ffb55d238884ee676c08ed58"},
{"path":"game/ui/profile-recovery-dialog.mjs","bytes":6936,"sha256":"7af8243a1d9b0abbf4e51b82acad07ba5da050e9458805c0c9bd13530c9f6246"},
{"path":"game/ui/profile-recovery.css","bytes":1373,"sha256":"9714a487f33603eef71a604b88f0d0dec006d84b66d761019f4cc5b6ebe162c3"},
{"path":"game/ui/profile-recovery.mjs","bytes":13478,"sha256":"bda0ec9cd94068e844ae6be586cb6a7f50281eb267b8cf32bebbf6ae969799f9"},
{"path":"game/ui/profile-transfer-panel.mjs","bytes":6872,"sha256":"5a910445e4e11753a9cb6aeaaf4439ff6af4cb7aa765404f0100161347c7eb19"},
{"path":"game/ui/published-audio.mjs","bytes":5718,"sha256":"3e9e7c163fcd936661fa609870b4b5dfb9099139c8c87e261d966908637c73d0"},
{"path":"game/ui/render.mjs","bytes":34321,"sha256":"93d69f62cfbed4b70a395bf44cd802be5a0f700fd20be6a7187e3c6fe9eaf132"},
{"path":"game/ui/result-picture.mjs","bytes":1693,"sha256":"2e533ecca4b64ae98aaca6819cdd628784d07e53100deecf36d073d8c90cdd79"},
{"path":"game/ui/retry-view.mjs","bytes":2847,"sha256":"b9ac479a23a1d95cd2af53ecbee2a22fbf7a9872fd47a0b8aedf93a45ea030c6"},
{"path":"game/ui/scene-art.mjs","bytes":9119,"sha256":"f6b763dd22a55fa3c729d87862174942b1572b55c4a2e7b0072a88258de9807f"},
{"path":"game/ui/soundtrack-panel.css","bytes":3507,"sha256":"7e48803cada4be1a38ecc8344a9c3350d9a23010721fb59d016b374a15388758"},
{"path":"game/ui/soundtrack-panel.mjs","bytes":50705,"sha256":"ebc25393b2a9254153c4450470e4c7954bccecf95868e308ae74f1888048823b"},
{"path":"game/ui/soundtrack-player.mjs","bytes":24085,"sha256":"6b45ab2c75fc313443c97ec3a64ed8e1526d89052292c6c3ab2c9817b1465932"},
{"path":"game/ui/still-media-catalog.mjs","bytes":5423,"sha256":"3a829a3e80f2bfd44f344bcee2db2d759b0e77c86f404a7df9d41dda96f373d1"},
{"path":"game/ui/still-media-host.mjs","bytes":12718,"sha256":"1b2005af8b02756affeb1f6795e524d26aa7bd0d56a8d3063405cd02e8847d8a"},
{"path":"game/ui/still-media-panel.css","bytes":3035,"sha256":"40c843947c8195f75039c38ee27685c5c630519e6fd0bbe684d9f7f15cb61cb2"},
{"path":"game/ui/still-media-panel.mjs","bytes":29672,"sha256":"9fd25a85a40f3c255c059df6d02bb6d5bc4015a182c758adba126615d55c8ffe"},
{"path":"game/ui/still-media-preview.mjs","bytes":8838,"sha256":"219426e79742e1e92ba57075ae0b3ad9770f88bac44d4e56b99580541a17cf93"},
{"path":"game/ui/still-story-panel.mjs","bytes":24808,"sha256":"ed3c7a3bc4fcb2cd3c44151f33ff3319874a8a33916f795bd9aaf50217626ced"},
{"path":"game/ui/storage-retention.mjs","bytes":3289,"sha256":"b54c22df0a238d794bb88d2a21efee53f0102d40e95f21429e1e102971341456"},
{"path":"game/ui/story-dialog.css","bytes":1110,"sha256":"ffdae66c28010c6865a889cad83351c6abc70bb6e908b58cfad4cc8de266d000"},
{"path":"game/ui/story-dialog.mjs","bytes":8368,"sha256":"24e5373f837dc3dbeee12b7999dc6c69a984e3d450b9d2e3d964a4be50bf2685"},
{"path":"game/ui/touch-steering.mjs","bytes":3599,"sha256":"9fa66aa6a279be8ac78190e097c6a31efd05e47a7dd963b4d65495f928981600"},
{"path":"game/ui/victory-story.mjs","bytes":20448,"sha256":"f269f30b35d147674500c80b6c19214c3fa055e9f4b724785204017e96ea1560"},
{"path":"game/ui/video-poster-workshop.mjs","bytes":10728,"sha256":"3ee3de47a5f6abc0dd144d6c72f8d5ca26825f45f778f5bdf6574d90a340f60a"},
{"path":"game/ui/worlds-browser.mjs","bytes":2374,"sha256":"ede6090dc1983955f19b607f82719123970292750f86595046091abc7bd4efdb"},
{"path":"game/vendor/PHASER-LICENSE.md","bytes":1120,"sha256":"d59c20a9deb5dc240614b428dce5246ae561d15efeeebea0e069d73f0a78fbff"},
{"path":"game/vendor/phaser-4.2.1.min.js","bytes":1375976,"sha256":"66348b1b5141e49b7d5ebbe688cddcb502eab1cb00f21c538686a5b2c5abe4de"},
{"path":"game/victory-story.mjs","bytes":5111,"sha256":"363728b8bf711e0a854b472d1153a40d5db790b7b4234dcb121564cc6d795e49"},
{"path":"game/video-poster.mjs","bytes":17190,"sha256":"23163933aba6a5fb94124161f1b281ae722fcca160832603642464295ac8dc79"},
{"path":"icons/icon-180.png","bytes":561,"sha256":"63c31cdb86ca1f61307e512c00e4e76b23d1c180cc4baa06d2f88af1739985d7"},
{"path":"icons/icon-192.png","bytes":608,"sha256":"a8f31c77674e13440ed3cb812dba4485bd7f5af4dda919f5b74042b001375cb8"},
{"path":"icons/icon-512.png","bytes":2987,"sha256":"c65fa7947235ff38f49d5389762441ce00c9e749ca4e1bc6433bebe29c8f6dbc"},
{"path":"icons/icon.svg","bytes":21242,"sha256":"c9e9ff4035b6f6006bb86e3164ba3a09a6d467e10c9333437e9364213996b881"},
{"path":"index.html","bytes":3129,"sha256":"5b0bed711a786e7ef0f29ba8bba57fcb1ff53a2b216837e101b1bb5590e79589"},
{"path":"manifest.webmanifest","bytes":831,"sha256":"db26e3075099864c73fd9b52e5fcf8abccb8c5fda2a1a4290f254dd17b6b0c1d"},
{"path":"privacy.html","bytes":2612,"sha256":"77f32dc124099dbf9325e8bd0862e500ea826025389420f7b666a8b94dcef2c5"},
{"path":"site/about.html","bytes":26674,"sha256":"1dafd494b1dcc39c478936da39bd838b453939b2fc6c75c993bc78d3d64346fd"},
{"path":"site/landing.css","bytes":33881,"sha256":"51a73a456837e70777ceaefd10f62ae277d0841a348083a6e193f363b973f265"},
{"path":"site/landing.mjs","bytes":4976,"sha256":"a1c77b683da8d34bf6792e7e76ea22fadcbdd442244419b33ad741215b447855"},
{"path":"site/launch.mjs","bytes":991,"sha256":"8fab859b6c363c268e06c3b2976b32433237dfde81d04da039dccfcabc6c59b7"},
{"path":"site/release-catalog.css","bytes":1018,"sha256":"18736359cd160a144d09a157719e22519819923f1072079586f05debb0852640"},
{"path":"site/release-links.mjs","bytes":746,"sha256":"084d72d4d58e8ef11595e0a7857b5e338ee4ff8884eb43f859099bd22a0f2de0"}],"optionalPacks":[{"path":"game/content/packs/fpv-arcade-r2.json","id":"fpv-arcade-r2","name":"FPV Front · First Light R2"},
{"path":"game/content/packs/fpv-arcade-r3.json","id":"fpv-arcade-r3","name":"FPV Front · First Light R3"},
{"path":"game/content/packs/fpv-arcade-r4.json","id":"fpv-arcade-r4","name":"FPV Front · First Light Arcade R4"},
{"path":"game/content/packs/fpv-arcade-r5.json","id":"fpv-arcade-r5","name":"FPV Front · Pressure Lines"},
{"path":"game/content/packs/fpv-arcade.json","id":"fpv-arcade","name":"FPV Front · First Light"},
{"path":"game/content/packs/fpv-pressure-frontier.json","id":"fpv-pressure-frontier","name":"FPV Front · Frontier Lines"},
{"path":"authoring/library/four-worlds-chapters/packs/original-fpv-pressure.json","id":"original-fpv-pressure","name":"FPV Front · Illustrated Pressure"},
{"path":"authoring/library/four-worlds-chapters/packs/original-ukraine-atlas.json","id":"original-ukraine-atlas","name":"Ukraine Atlas · Woven Lines"},
{"path":"authoring/library/four-worlds-chapters/packs/original-retro-1994.json","id":"original-retro-1994","name":"1994 Forever · After Hours"},
{"path":"authoring/library/fpv-route-choices/packs/fpv-route-choices.json","id":"fpv-route-choices","name":"FPV Front · Route Choices — Tactical"}]};
  const MAX_BYTES = 64 * 1024 * 1024;
  const DOWNLOAD_CONCURRENCY = 4;
  if (!Array.isArray(CONFIG.files) || CONFIG.files.length > 2000)
    throw new Error('Offline inventory exceeds its file budget');
  let inventoryBytes = 0;
  for (const file of CONFIG.files) {
    if (!Number.isSafeInteger(file.bytes) || file.bytes < 0 || file.bytes > MAX_BYTES)
      throw new Error('Offline inventory has an invalid byte budget');
    inventoryBytes += file.bytes;
    if (inventoryBytes > MAX_BYTES) throw new Error('Offline inventory exceeds its byte budget');
  }
  const scope = new URL(self.registration.scope);
  const prefix = `revealline-offline:${encodeURIComponent(scope.href)}:`;
  const cacheName = `${prefix}${CONFIG.buildId}`;
  const readyURL = new URL('.offline-ready', scope).href;
  const files = new Map(
    CONFIG.files.map((file) => [
      new URL(file.path.split('/').map(encodeURIComponent).join('/'), scope).href,
      file,
    ]),
  );
  const sameScope = (url) => url.origin === scope.origin && url.pathname.startsWith(scope.pathname);
  const PROTOCOL = 'revealline.offline-progress.v1';
  const subscribers = new Set();
  const MAX_SUBSCRIBERS = 64;
  const SUBSCRIBER_LIFETIME = 5 * 60 * 1000;
  let operationSequence = 0,
    latestProgress;
  function progress(stage, completed = 0, counters = {}) {
    latestProgress = {
      status: 'preparing',
      stage,
      operationId: `${CONFIG.buildId}:${operationSequence}`,
      progress: files.size ? { completed, total: files.size, unit: 'files' } : null,
      ...counters,
    };
    for (const subscriber of subscribers) subscriber.send('progress', latestProgress);
  }
  function subscribe(port, requestId) {
    let closed = false;
    const subscriber = {
      send(kind, report) {
        if (closed) return;
        try {
          port.postMessage({
            ...report,
            format: PROTOCOL,
            requestId,
            kind,
            scope: scope.href,
            buildId: CONFIG.buildId,
            version: CONFIG.version,
          });
        } catch {
          subscriber.close();
        }
      },
      close() {
        if (closed) return;
        closed = true;
        clearTimeout(timer);
        subscribers.delete(subscriber);
        port.onmessage = null;
        port.onmessageerror = null;
        port.close?.();
      },
    };
    const timer = setTimeout(() => subscriber.close(), SUBSCRIBER_LIFETIME);
    port.onmessage = (event) => {
      if (event.data?.type === 'revealline.offline-detach' && event.data.requestId === requestId)
        subscriber.close();
    };
    port.onmessageerror = () => subscriber.close();
    // A tab that disappears without detaching must not retain a port indefinitely.
    if (subscribers.size >= MAX_SUBSCRIBERS) subscribers.values().next().value.close();
    subscribers.add(subscriber);
    return subscriber;
  }
  const hex = (bytes) =>
    Array.from(new Uint8Array(bytes), (n) => n.toString(16).padStart(2, '0')).join('');
  async function downloadVerified(url, file, signal, onDownloaded = () => {}) {
    if (!sameScope(new URL(url))) throw new Error('Precache escaped its distribution scope');
    const response = await fetch(
      new Request(url, { cache: 'reload', credentials: 'same-origin', signal }),
    );
    let reader;
    try {
      if (
        response.redirected ||
        !response.ok ||
        response.type === 'opaque' ||
        response.status === 206 ||
        response.headers
          .get('Vary')
          ?.split(',')
          .some((value) => value.trim() === '*')
      )
        throw new Error(`Offline download failed integrity: ${file.path}`);
      const bytes = new Uint8Array(file.bytes);
      let length = 0;
      if (response.body) {
        reader = response.body.getReader();
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          if (!(value instanceof Uint8Array) || value.byteLength > bytes.byteLength - length)
            throw new Error(`Offline download exceeds its byte budget: ${file.path}`);
          bytes.set(value, length);
          length += value.byteLength;
        }
      }
      if (length !== file.bytes) throw new Error(`Offline download failed integrity: ${file.path}`);
      onDownloaded();
      if (hex(await crypto.subtle.digest('SHA-256', bytes)) !== file.sha256)
        throw new Error(`Offline download failed integrity: ${file.path}`);
      const headers = new Headers(response.headers);
      // Fetch delivers decoded bytes; network encoding/length may describe the wire body.
      headers.delete('Content-Encoding');
      headers.set('Content-Length', String(bytes.byteLength));
      return { bytes, headers, status: response.status, statusText: response.statusText };
    } catch (error) {
      try {
        if (reader) await reader.cancel();
        else await response.body?.cancel();
      } catch {}
      throw error;
    } finally {
      reader?.releaseLock();
    }
  }
  function ownedResponse({ bytes, headers, status, statusText }) {
    const body = bytes.byteLength === 0 && [204, 205].includes(status) ? null : bytes;
    return new Response(body, { headers, status, statusText });
  }
  async function verified(response, file) {
    if (!response || !response.ok || response.type === 'opaque') return false;
    const bytes = await response.clone().arrayBuffer();
    return (
      bytes.byteLength === file.bytes &&
      hex(await crypto.subtle.digest('SHA-256', bytes)) === file.sha256
    );
  }
  async function inspect(notify = () => {}) {
    notify(0, 0);
    const existing = await caches.keys();
    if (!existing.includes(cacheName))
      return {
        status: 'not-ready',
        version: CONFIG.version,
        buildId: CONFIG.buildId,
        count: CONFIG.files.length,
        verified: 0,
        bytes: 0,
        missing: CONFIG.files.map((f) => f.path),
        corrupt: [],
      };
    const cache = await caches.open(cacheName),
      missing = [],
      corrupt = [];
    let count = 0,
      bytes = 0,
      checked = 0;
    for (const [url, file] of files) {
      const response = await cache.match(url);
      if (!response) missing.push(file.path);
      else if (!(await verified(response, file))) corrupt.push(file.path);
      else {
        count++;
        bytes += file.bytes;
      }
      notify(++checked, count);
    }
    const marker = await cache.match(readyURL);
    return {
      status: marker && !missing.length && !corrupt.length ? 'ready' : 'not-ready',
      version: CONFIG.version,
      buildId: CONFIG.buildId,
      count: files.size,
      verified: count,
      bytes,
      missing,
      corrupt,
    };
  }
  async function installFiles() {
    // Finish any existing read before repair so a pre-repair snapshot cannot be
    // reused as the final report after this installation saves its files.
    const cached = await (inspection ??
      inspect((checked, cacheVerified) =>
        progress('checking', checked, { checked, cacheVerified }),
      ));
    if (cached.status === 'ready') return cached;
    // Own and verify every body before creating a new version's cache. Avoid
    // retaining unread network branches while another clone is consumed.
    const entries = [...files],
      downloaded = new Array(entries.length),
      controller = new AbortController();
    let next = 0,
      downloadedCount = 0,
      downloadVerifiedCount = 0,
      saved = 0,
      failure;
    const counters = () => ({
      downloaded: downloadedCount,
      downloadVerified: downloadVerifiedCount,
      saved,
    });
    progress('downloading', 0, counters());
    await Promise.all(
      Array.from({ length: Math.min(DOWNLOAD_CONCURRENCY, entries.length) }, async () => {
        while (!failure && next < entries.length) {
          const index = next++,
            [url, file] = entries[index];
          try {
            downloaded[index] = {
              url,
              ...(await downloadVerified(url, file, controller.signal, () => {
                downloadedCount++;
              })),
            };
            downloadVerifiedCount++;
            progress('downloading', downloadVerifiedCount, counters());
          } catch (error) {
            if (!failure) {
              failure = error;
              controller.abort();
            }
          }
        }
      }),
    );
    if (failure) {
      downloaded.length = 0;
      throw failure;
    }
    const cache = await caches.open(cacheName);
    try {
      progress('saving', 0, counters());
      for (const item of downloaded) {
        await cache.put(item.url, ownedResponse(item));
        item.bytes = null;
        progress('saving', ++saved, counters());
      }
      await cache.put(
        readyURL,
        new Response(CONFIG.buildId, { headers: { 'Content-Type': 'text/plain' } }),
      );
    } catch (error) {
      await caches.delete(cacheName);
      throw error;
    } finally {
      downloaded.length = 0;
    }
  }
  let installation, inspection;
  function install() {
    // Two open tabs repairing one evicted cache share the same bounded work.
    if (!installation) {
      operationSequence++;
      latestProgress = null;
    }
    return (installation ??= installFiles().finally(() => {
      installation = null;
      latestProgress = null;
    }));
  }
  function check() {
    // Observing existing installation remains read-only; never start a repair here.
    if (installation) return installation.then((report) => report ?? check());
    if (!inspection) {
      operationSequence++;
      inspection = inspect((checked, cacheVerified) =>
        progress('verifying', checked, { checked, cacheVerified }),
      ).finally(() => {
        inspection = null;
        if (!installation) latestProgress = null;
      });
    }
    return inspection;
  }
  self.addEventListener('install', (event) => event.waitUntil(install()));
  self.addEventListener('activate', (event) =>
    event.waitUntil(
      (async () => {
        const report = await inspect();
        if (report.status !== 'ready') throw new Error('Incomplete offline cache cannot activate');
        // This only runs once old clients no longer use their worker. No skipWaiting.
        for (const key of await caches.keys())
          if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
        await self.clients.claim();
      })(),
    ),
  );
  self.addEventListener('fetch', (event) => {
    if (event.request.method !== 'GET') return;
    const url = new URL(event.request.url);
    if (!sameScope(url)) return;
    url.search = '';
    url.hash = '';
    if (url.pathname.endsWith('/')) url.pathname += 'index.html';
    const file = files.get(url.href);
    if (!file) return;
    event.respondWith(
      (async () => {
        const cache = await caches.open(cacheName),
          hit = await cache.match(url.href);
        if (hit) return hit;
        try {
          const owned = await downloadVerified(url.href, file);
          await cache.put(url.href, ownedResponse(owned));
          return ownedResponse(owned);
        } catch {
          return new Response(
            'This offline file is unavailable. Reconnect and prepare this game version again.',
            { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } },
          );
        }
      })(),
    );
  });
  self.addEventListener('message', (event) => {
    if (
      !['revealline.offline-check', 'revealline.offline-prepare'].includes(event.data?.type) ||
      !event.ports?.[0]
    )
      return;
    if (!event.source?.url || !sameScope(new URL(event.source.url))) return;
    const port = event.ports[0],
      request = event.data,
      streaming = request.protocol === PROTOCOL;
    if (streaming && (typeof request.requestId !== 'string' || request.requestId.length > 120))
      return;
    const subscriber = streaming ? subscribe(port, request.requestId) : null;
    event.waitUntil(
      (async () => {
        try {
          if (streaming && (request.buildId !== CONFIG.buildId || request.scope !== scope.href)) {
            subscriber.send('terminal', {
              status: 'not-ready',
              message: 'Offline worker belongs to a different build. Reopen this version online.',
            });
            return;
          }
          if (latestProgress) subscriber?.send('progress', latestProgress);
          const report =
            (request.type === 'revealline.offline-prepare' ? await install() : null) ??
            (await check());
          if (subscriber) subscriber.send('terminal', report);
          else port.postMessage(report);
        } catch (error) {
          const report = { status: 'error', message: error.message, buildId: CONFIG.buildId };
          if (subscriber) subscriber.send('terminal', report);
          else port.postMessage(report);
        } finally {
          subscriber?.close();
        }
      })(),
    );
  });
})();
