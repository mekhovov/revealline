"""Check retained upload originals and fresh remote identities. Only bounded GET requests."""
from pathlib import Path,PurePosixPath
import json,hashlib,zipfile,subprocess as s,datetime
P=Path(__file__).resolve().parent;D=P/'completed';E=D/'evidence';W=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/p02a-team-sound-note');sha=lambda b:hashlib.sha256(b).hexdigest();seen={}
def read(p):
 assert p.is_file() and not p.is_symlink() and p.stat().st_size<64000000
 b=p.read_bytes();assert seen.setdefault(str(p),sha(b))==sha(b);return b
def obj(p):return json.loads(read(p))
def pin(p):b=read(p);return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def fresh(name,path):
 b=s.check_output(['gh','api',path]);assert len(b)<1000000;p=D/name;p.open('xb').write(b);return obj(p)
binding=obj(P.parent/'upload-binding.reviewed.json');assert binding['reviewed'] and binding['release']['id']==389657437
source=binding['source'];assert obj(E/'binding.json')==binding
result=obj(E/'result.json');assert result['status']=='ALL_NINE_VERIFIED' and result['operation']=='upload-originals' and result['source']==source and result['artifact']==binding['artifact'] and result['automaticRetry'] is False
run=obj(D/'run.json');jobs=obj(D/'jobs.json');ex=obj(E/'execution.json');assert run['id']==35059957662 and run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==source['commit']==ex['workflowSha'] and source['tree']==ex['workflowTree'];assert ex['runId']==str(run['id']) and ex['runAttempt']=='1'
checks={'sourceRevision':source['commit'],'sourceTree':source['tree'],'trackedCheckoutClean':True};assert obj(E/'source-before.json')==obj(E/'source-after.json')==ex['sourceCheckout']==checks
for row in ex['helpers']:
 relative=str(PurePosixPath(row['path']).relative_to('/home/runner/work/revealline/revealline/automation'));b=s.check_output(['git','show',source['commit']+':'+relative],cwd=W);assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert len(ex['helpers'])==8
job=next(j for j in jobs['jobs'] if j['name']=='upload-originals');assert job['status']=='completed' and job['conclusion']=='success'
for name in ['Verify local utility tests before authenticated work','Verify all originals and upload two absent members to the existing draft','Retain bounded original metadata and every attempt outcome']:
 st=next(x for x in job['steps'] if x['name']==name);assert st['status']=='completed' and st['conclusion']=='success'
manifest=obj(E/'retained-manifest.json');assert manifest['count']==len(manifest['files'])==len({r['path'] for r in manifest['files']}) and manifest['bytes']==sum(r['bytes'] for r in manifest['files'])<64*1024*1024
names=set()
for row in manifest['files']:
 relative=str(PurePosixPath(row['path']).relative_to('/home/runner/work/revealline/revealline/utility-output/evidence'));p=E/relative;b=read(p);assert len(b)==row['bytes'] and sha(b)==row['sha256'];names.add(relative)
assert {str(p.relative_to(E)) for p in E.rglob('*') if p.is_file()}==names|{'retained-manifest.json'}
with zipfile.ZipFile(D/'upload-originals-evidence-original.zip') as z:
 assert set(z.namelist())==names|{'retained-manifest.json'}
 for name in z.namelist():assert z.read(name)==read(E/name)
inspection=obj(E/'qualified-artifact-verified/inspection.json');assert inspection['status']=='PASS' and inspection['gitHead']==source['commit'] and inspection['gitTree']==source['tree'] and inspection['version']==source['version']
prior=obj(W/'.cache/p02a-accepted-main/utility-inspection/evidence/qualified-artifact-verified/inspection.json')
for role in ['artifact','sourceTar','distribution']:
 for key in ['bytes','sha256']:assert inspection[role][key]==prior[role][key]
assert inspection['releaseHashChainVerified'] and inspection['distribution']['allManifestBytesVerified'] and inspection['distribution']['innerManifestIdentical']
expected={r['name']:r for r in binding['release']['assets']};assert len(expected)==9
for name in expected:
 if name in ['source.tar','distribution.zip']:continue
 raw=read(E/'reviewed-small-assets'/name);assert len(raw)==expected[name]['bytes'] and sha(raw)==expected[name]['sha256'] and raw==read(W/'.cache/p02a-accepted-main/release-attachments'/name)
preflight=obj(E/'attachment-preflight.json');assert preflight['files']==150 and preflight['everyMemberCRCAndHashVerified'] is True and preflight['allQualificationPinsResolved'] is True
nine=obj(E/'all-nine-assets.json');assert nine['status']=='VERIFIED_RELEASE_ASSETS' and nine['releaseId']==binding['release']['id'] and nine['sourceCommit']==source['commit'] and nine['tag']==source['version']
release=fresh('release-final-api.json','repos/mekhovov/revealline/releases/389657437');assert release['id']==389657437 and release['tag_name']==source['version'] and release['draft'] is True
assets=fresh('assets-final-api.json','repos/mekhovov/revealline/releases/389657437/assets?per_page=100');assert len(assets)==len(nine['assets'])==len({a['name'] for a in assets})==9
hosted={a['name']:a for a in nine['assets']}
for asset in assets:
 row=expected[asset['name']];assert asset['state']=='uploaded' and asset['size']==row['bytes'] and asset['digest']=='sha256:'+row['sha256'];assert asset['id']==hosted[asset['name']]['id'] and asset['size']==hosted[asset['name']]['size'] and asset['digest']==hosted[asset['name']]['digest']
results={}
for name in ['source.tar','distribution.zip']:
 r=obj(E/(name+'.upload-result.json'));started=obj(E/(name+'.upload-started.json'));asset=next(x for x in assets if x['name']==name)
 assert started['status']=='IN_PROGRESS_REREAD_ASSETS_IF_INTERRUPTED' and started['automaticRetry'] is False
 assert r['status']=='UPLOADED_VERIFIED' and r['repository']==binding['repository'] and r['releaseId']==389657437 and r['tag']==source['version'] and r['tagCommit']==source['commit'] and r['assetName']==name and r['assetId']==asset['id'] and r['postCount']==1 and r['readBackVerified'] is True
 assert r['bytes']==expected[name]['bytes'] and r['sha256']==expected[name]['sha256'] and r['serverDigest']==asset['digest'];results[name]=r
ref=fresh('tag-ref-final-api.json','repos/mekhovov/revealline/git/ref/tags/v0.58.1');assert ref['object']['type']=='tag' and ref['object']['sha']=='a055a08d6f53600276abdf8291d08313c3baf413'
tag=fresh('tag-object-final-api.json','repos/mekhovov/revealline/git/tags/'+ref['object']['sha']);assert tag['tag']=='v0.58.1' and tag['object']['sha']==source['commit'] and tag['object']['type']=='commit'
for p,digest in seen.items():assert sha(Path(p).read_bytes())==digest
review={'status':'PASS_DRAFT_UPLOAD_ONLY','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'run':run['id'],'job':job['id'],'releaseId':release['id'],'releaseStillDraft':True,'annotatedTag':ref['object']['sha'],'retainedOriginals':manifest['count'],'retainedOriginalBytes':manifest['bytes'],'allRetainedZipPairsVerified':True,'allNineAPIAssetsMatchBindingAndHostedReceipt':True,'smallOriginalsRehashed':7,'largeSinglePostReceipts':results,'sourceAndHelperIdentitiesVerified':True,'largeOriginalsDownloadedLocally':False,'publicAcceptance':False,'releaseMutationPerformedByReviewer':False,'pins':[pin(Path(p)) for p in sorted(seen)],'limits':['Remote large originals verified through exact upload byte counters/digests, server readback and authenticated whole-artifact runner inspection; no repeated local large-body download.','Draft upload verification does not establish release publication, Pages deployment, public gameplay/offline or P02-A acceptance.']}
out=D/'review.json';out.open('x').write(json.dumps(review,indent=2)+'\n');print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'status':review['status'],'assets':[(a['name'],a['id'],a['size'],a['digest']) for a in assets]},indent=2))
