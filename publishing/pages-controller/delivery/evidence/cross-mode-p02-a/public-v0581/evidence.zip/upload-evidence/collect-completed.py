"""Receive bounded original upload evidence only; all remote calls GET."""
from pathlib import Path,PurePosixPath
import subprocess as s,json,hashlib,gzip,zipfile,stat,datetime
P=Path(__file__).resolve().parent;rid=35059957662;source='c93019a344f6f4c6ac03940c77ea09c81122d911';sha=lambda b:hashlib.sha256(b).hexdigest()
def get(path):
 b=s.check_output(['gh','api',path]);assert len(b)<1000000;return b
run=get(f'repos/mekhovov/revealline/actions/runs/{rid}');r=json.loads(run)
assert r['head_sha']==source and r['status']=='completed' and r['conclusion']=='success' and r['run_attempt']==1 and r['event']=='workflow_dispatch'
D=P/'completed';D.mkdir()
(D/'run.json').open('xb').write(run)
for name,suffix in [('jobs','/jobs?per_page=100'),('artifacts','/artifacts?per_page=100')]:
 (D/(name+'.json')).open('xb').write(get(f'repos/mekhovov/revealline/actions/runs/{rid}'+suffix))
jobs=json.loads((D/'jobs.json').read_bytes());assert jobs['total_count']==len(jobs['jobs']);matches=[j for j in jobs['jobs'] if j['name']=='upload-originals'];assert len(matches)==1
j=matches[0];assert j['head_sha']==source and j['run_id']==rid and j['conclusion']=='success'
b=s.check_output(['gh','api',f'repos/mekhovov/revealline/actions/jobs/{j["id"]}/logs']);assert len(b)<10000000;(D/f'job-{j["id"]}.log.gz').open('xb').write(gzip.compress(b,mtime=0))
a=json.loads((D/'artifacts.json').read_bytes());assert a['total_count']==len(a['artifacts']);matches=[a for a in a['artifacts'] if a['name']=='upload-originals-evidence'];assert len(matches)==1;a=matches[0]
assert a['workflow_run']['id']==rid and a['workflow_run']['head_sha']==source and not a['expired'] and 0<a['size_in_bytes']<64*1024*1024
zpath=D/'upload-originals-evidence-original.zip';proc=s.Popen(['gh','api',f'repos/mekhovov/revealline/actions/artifacts/{a["id"]}/zip'],stdout=s.PIPE);h=hashlib.sha256();total=0
with zpath.open('xb') as f:
 while True:
  chunk=proc.stdout.read(65536)
  if not chunk:break
  total+=len(chunk);assert total<=a['size_in_bytes'];h.update(chunk);f.write(chunk)
assert proc.wait()==0 and total==a['size_in_bytes'] and 'sha256:'+h.hexdigest()==a['digest']
E=D/'evidence';E.mkdir()
with zipfile.ZipFile(zpath) as z:
 infos=z.infolist();assert len(infos)==len(set(z.namelist()))<=2000 and sum(i.file_size for i in infos)<64*1024*1024
 for i in infos:
  n=PurePosixPath(i.filename);assert not n.is_absolute() and '..' not in n.parts and '\\' not in i.filename and stat.S_IFMT(i.external_attr>>16) in [0,stat.S_IFREG] and not i.is_dir() and not i.flag_bits&1
  raw=z.read(i);assert len(raw)==i.file_size;p=E/str(n);p.parent.mkdir(parents=True,exist_ok=True);p.open('xb').write(raw)
receipt={'status':'ORIGINAL_SMALL_UPLOAD_EVIDENCE_RECEIVED','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'run':rid,'job':j['id'],'artifact':a['id'],'bytes':total,'sha256':h.hexdigest(),'members':len(infos),'originalUncompressedBytes':sum(i.file_size for i in infos),'logOriginalBytes':len(b),'logOriginalSha256':sha(b),'largeSnapshotDownloaded':False,'releaseMutated':False}
(D/'download-receipt.json').open('x').write(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
