# v0.58.1 public audit preparation

Prepared from the accepted v0.58.0 public-byte auditor. `origin/` preserves its original helper bodies, retained catalog and preparation records. The adaptation changes only game source `c93019a344f6f4c6ac03940c77ea09c81122d911`, tree `f6055cbcba92d45ef1da2b5d16e7e4f1158c8d2a`, version `v0.58.1`, exact retained-catalog SHA and matching self-check expectations.

`retained-catalog.json` is the exact c930 Git blob `7154ad13b3d4eb85f71c31e3ceffd632c54f91fe`, containing 67 historical editions through v0.58.0. The next publisher catalog must preserve all of those records and add the current version. Existing guards require ordinary archive admission and empty `testingRoutes`; those guards are unchanged.

The streaming transport is byte-identical: eight concurrent requests, up to three attempts only for transient failures, 300,000 ms request timeout, manual redirects, required MIME validation and streaming hashes. No game bodies are persisted. Every attempt and failed result remains in its original run.

Preparation has not executed helper checks, downloaded a public receipt or created a production binding. Actual merged publisher commit/tree, successful workflow run, deployment/status and small hosted receipt originals must be supplied first. The game source is not the publisher revision.

Next steps are to review `adaptation.diff`, run syntax/offline helper checks, retain the actual nine authority bodies beneath `inputs/<actual-publisher-commit>/`, review their exact pins, run the unchanged `--check`, then run full mode once into a fresh output directory. A full HTTP pass remains separate from browser play, offline execution, physical devices and phase acceptance.
