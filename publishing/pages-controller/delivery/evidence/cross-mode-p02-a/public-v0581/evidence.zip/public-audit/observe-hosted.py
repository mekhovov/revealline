from pathlib import Path
import subprocess,json,hashlib,concurrent.futures,sys,datetime
home=Path(__file__).resolve().parent;out=home/('hosted-observation-'+sys.argv[1]);out.mkdir();queries={'run':'actions/runs/35060819275','jobs':'actions/runs/35060819275/jobs','artifacts':'actions/runs/35060819275/artifacts','main':'git/ref/heads/main','wrapper':'git/commits/a1a5d0c5295196024af1a158c53acedc2f817c1a','deployments':'deployments?sha=a1a5d0c5295196024af1a158c53acedc2f817c1a&per_page=10'}
def get(pair):
 n,s=pair;r=subprocess.run(['gh','api','repos/mekhovov/revealline/'+s],capture_output=True,timeout=35);assert len(r.stdout)<2_000_000;(out/(n+'.json')).write_bytes(r.stdout);(out/(n+'.stderr')).write_bytes(r.stderr);assert r.returncode==0;return n,json.loads(r.stdout)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:result=dict(pool.map(get,queries.items()))
assert result['main']['object']['sha']==result['wrapper']['sha']==result['run']['head_sha']=='a1a5d0c5295196024af1a158c53acedc2f817c1a';assert result['wrapper']['tree']['sha']=='71798f41b597138a6a0fbf40624d949b5cf90324'
for d in result['deployments']:
 if d['environment']=='github-pages':
  assert d['sha']=='a1a5d0c5295196024af1a158c53acedc2f817c1a'
  for name,suffix in [('deployment','deployments/'+str(d['id'])),('statuses','deployments/'+str(d['id'])+'/statuses')]:
   n,value=get((name,suffix));result[n]=value
  break
pins=[]
for p in sorted(out.iterdir()):
 if p.is_file():b=p.read_bytes();pins.append({'path':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'Bounded read-only GitHub API observation','pins':pins};(out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'directory':str(out),'run':{k:result['run'][k] for k in ['id','status','conclusion','head_sha']},'jobs':[{k:j[k] for k in ['id','name','status','conclusion']} for j in result['jobs']['jobs']],'artifacts':[{k:a[k] for k in ['id','name','size_in_bytes','digest']} for a in result['artifacts']['artifacts']],'deployment':{k:result.get('deployment',{}).get(k) for k in ['id','sha','environment']},'latestStatus':{k:result.get('statuses',[{}])[0].get(k) for k in ['id','state','log_url','environment_url']}},indent=2))
