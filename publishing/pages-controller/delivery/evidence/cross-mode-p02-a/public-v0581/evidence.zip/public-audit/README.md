# v0.58.1 public byte verification

PASS: 2,530 public files / 637,630,752 bytes, 2,530 attempts, no failures, retries or skips. The complete streaming audit ran from 2026-09-16T05:50:33.982Z to 2026-09-16T05:52:11.473Z. The approved independent row reconciler compared every result, attempt, URL, byte count and hash with the original hosted inventory.

Game source: `c93019a344f6f4c6ac03940c77ea09c81122d911`, tree `f6055cbcba92d45ef1da2b5d16e7e4f1158c8d2a`. Publisher: `a1a5d0c5295196024af1a158c53acedc2f817c1a`, tree `71798f41b597138a6a0fbf40624d949b5cf90324`. Successful run: `35060819275`. Deployment: `6474632693`; final observed success status `18409175675`.

Test entry: https://mekhovov.github.io/revealline/releases/v0.58.1/site/game/index.html

The original hosted receipt covers all 657 frozen manifest files, current aliases, workers, catalog and 67 historical edition bridges. The exact 120,824-byte receipts ZIP was received from artifact `10432322834` and checked against its GitHub digest. The full Pages artifact and release source/distribution archives were not downloaded locally. Public bodies were streamed for hashes without being persisted.

`tools/runs/complete-1/` contains the complete inventory, every attempt and result, and final report. `public-row-review.json` records the independent row reconciliation. `after-http-review.json` and retained GET responses confirm that main, deployment, latest stable release, annotated tag, game source and all nine release assets remained unchanged after the audit.

The helper adaptation changed only exact source/tree/version, the 67-edition retained catalog and corresponding self-check expectations. Its transport and authority guards remain unchanged, including empty comparison routes, ordinary archive admission, eight concurrent requests, bounded transient-only retries and MIME checks. Syntax and mocked-transport checks passed before production use.

This verifies public bytes and the stated deployment identities. It does not establish browser interactions, offline execution, physical-device support or P02-A acceptance. Those remain separate.
