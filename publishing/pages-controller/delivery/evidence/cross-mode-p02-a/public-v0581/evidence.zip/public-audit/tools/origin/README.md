# v0.58.0 public audit preparation

Prepared from the previously reviewed v0.57.4 auditor, with originals and earlier preparation receipts retained under `origin/`. Only source, tree, version, retained-catalog SHA, and the corresponding offline self-check expectations change. `http-engine.mjs` and all authority/transport algorithms are unchanged.

The retained catalog is the exact 66-release catalog at `0e635af98289fcee74a85caec7636ae2fb8eabd0`. The shipped v0.58.0 qualification retains the six successful hosted gate records required by this auditor; no qualification-rule relaxation is needed.

The coordinating task owns actual hosted authority inputs under this tools directory’s `inputs/`, their binding, and public execution. No production binding or public audit is created by this preparation. After an exact binding is reviewed, `--check` validates it without HTTP; `--critical` is explicitly partial and full mode inspects every hosted inventory row. Preserve each run in a fresh `runs/` directory.

Transport remains eight concurrent requests, at most three attempts, 300,000 ms request timeout, streaming body hashes, reviewed MIME rules, manual redirects, and transient-only retries. A byte-audit pass does not establish browser play, offline behavior, or physical-device acceptance.
