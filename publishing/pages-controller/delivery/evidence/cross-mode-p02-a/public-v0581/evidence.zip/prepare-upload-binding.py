"""Derive an unreviewed upload binding from this patch's retained originals.

Local/cache-only. No network, tag, draft, upload, dispatch or release operation.
Without --draft-api, release.id deliberately stays null and cannot be dispatched.
With --draft-api, require the actual draft and exactly seven uploaded small assets.
Root must independently review the resulting binding before setting reviewed:true.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re

ROOT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/p02a-team-sound-note')
BASE = ROOT / '.cache/p02a-accepted-main'
OUT = Path('/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/p02a-team-note')
SOURCE = {'commit': 'c93019a344f6f4c6ac03940c77ea09c81122d911',
          'tree': 'f6055cbcba92d45ef1da2b5d16e7e4f1158c8d2a', 'version': 'v0.58.1'}
SMALL = {'manifest.json', 'release.json', 'distribution.zip.sha256',
         'source-qualification.json', 'source-qualification-evidence.zip',
         'verification.json', 'qualification-evidence-record.json'}
LARGE = {'source.tar', 'distribution.zip'}
read_pins = {}


def read(path):
    assert path.is_absolute() and path.is_file() and not path.is_symlink()
    assert '..' not in path.parts and not any(p.is_symlink() for p in path.parents)
    assert path.stat().st_size < 20_000_000
    body = path.read_bytes()
    read_pins[str(path)] = {'path': str(path), 'bytes': len(body),
                           'sha256': hashlib.sha256(body).hexdigest()}
    return body


def obj(path):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            assert key not in value
            value[key] = item
        return value
    return json.loads(read(path), object_pairs_hook=unique)


def write(path, value):
    assert path.is_absolute() and path.is_relative_to(OUT)
    assert not any(p.is_symlink() for p in path.parents)
    body = (json.dumps(value, indent=2) + '\n').encode()
    with path.open('xb') as stream:
        stream.write(body)
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--draft-api', type=Path)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists()
assert not Path(str(args.output) + '.inputs.json').exists()
descriptors = obj(BASE / 'release-attachment-pins.json')
assert len(descriptors) == 9 and {r['name'] for r in descriptors} == SMALL | LARGE
assert len({r['name'] for r in descriptors}) == 9
inspection_path = BASE / 'utility-inspection/evidence/qualified-artifact-verified/inspection.json'
inspection = obj(inspection_path)
inspected_binding = obj(BASE / 'utility-inspection/evidence/binding.json')
assert inspected_binding['reviewed'] is True and inspected_binding['release'] is None
assert inspected_binding['source'] == SOURCE
artifact = inspected_binding['artifact']
assert artifact['id'] == 10431786234 and artifact['runId'] == 35056217009
assert inspection['status'] == 'PASS' and inspection['version'] == SOURCE['version']
assert inspection['gitHead'] == SOURCE['commit'] and inspection['gitTree'] == SOURCE['tree']
assert artifact['bytes'] == inspection['artifact']['bytes'] == 1230839391
assert artifact['sha256'] == inspection['artifact']['sha256'] == '3eae320a952801c4635ec106e377829d4b63133d13f61f27a1f43bf6d51fef73'
assets = []
for row in descriptors:
    name = row['name']
    assert type(row['bytes']) is int and row['bytes'] > 0
    assert re.fullmatch('[0-9a-f]{64}', row['sha256'])
    if name in SMALL:
        path = BASE / 'release-attachments' / name
        body = read(path)
        assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
        if 'originalPath' in row:
            assert not row['originalPath'].startswith('/') and '..' not in Path(row['originalPath']).parts
            assert body == read(ROOT / row['originalPath'])
    else:
        role = 'sourceTar' if name == 'source.tar' else 'distribution'
        assert row['bytes'] == inspection[role]['bytes'] and row['sha256'] == inspection[role]['sha256']
        assert row['originalMember'] == inspection[role]['outerMember'] and row['copiedToDisk'] is False
        assert row['originalArchive'] == inspection['artifact']['path']
    assets.append({key: row[key] for key in ('name', 'bytes', 'sha256')})
record = obj(BASE / 'release-attachments/qualification-evidence-record.json')
assert record['sourceQualified'] is True and record['originalFrozenPayloadVerified'] is True
assert record['sourceRevision'] == SOURCE['commit'] and record['sourceTree'] == SOURCE['tree']
assert record['version'] == SOURCE['version'] and len(record['attachments']) == 8
by_name = {r['name']: r for r in assets}
assert {r['name'] for r in record['attachments']} == (SMALL | LARGE) - {'qualification-evidence-record.json'}
for row in record['attachments']:
    assert {key: row[key] for key in ('name', 'bytes', 'sha256')} == by_name[row['name']]
release_id = None
if args.draft_api:
    draft = obj(args.draft_api)
    release_id = draft['id']
    assert type(release_id) is int and 0 < release_id <= 10**14
    assert draft['draft'] is True and draft['prerelease'] is False
    assert draft['tag_name'] == SOURCE['version']
    assert draft['url'] == f'https://api.github.com/repos/mekhovov/revealline/releases/{release_id}'
    assert draft['assets_url'] == draft['url'] + '/assets'
    existing = draft['assets']
    assert len(existing) == 7 and {r['name'] for r in existing} == SMALL
    for row in existing:
        assert type(row['id']) is int and row['id'] > 0 and row['state'] == 'uploaded'
        assert row['url'] == f'https://api.github.com/repos/mekhovov/revealline/releases/assets/{row["id"]}'
        assert row['size'] == by_name[row['name']]['bytes']
        assert row['digest'] == 'sha256:' + by_name[row['name']]['sha256']
value = {'format': 'revealline-release-utility-binding.v1', 'reviewed': False,
         'repository': 'mekhovov/revealline', 'source': SOURCE, 'artifact': artifact,
         'release': {'id': release_id, 'tag': SOURCE['version'], 'assets': assets}}
for path, row in read_pins.items():
    body = Path(path).read_bytes()
    assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
written = write(args.output, value)
receipt = {'status': 'UPLOAD_BINDING_DRAFT_READY' if release_id else 'UPLOAD_BINDING_RELEASE_ID_PENDING',
           'binding': written, 'originals': list(read_pins.values()),
           'localSmallAssetsRehashed': 7, 'largeMembersBoundToHostedInspection': 2,
           'releaseId': release_id, 'existingDraftSmallAssetsVerified': bool(args.draft_api),
           'reviewed': False, 'remoteMutation': False,
           'scope': 'Exact existing utility schema. Root review and hosted draft/tag checks remain mandatory; no dispatch or upload performed.'}
write(Path(str(args.output) + '.inputs.json'), receipt)
print(json.dumps(receipt, indent=2))
