# v0.58.0 public byte verification

PASS: 2,505 public files / 637,489,480 bytes, 2,505 attempts, no failures, retries or skips. The full streaming audit ran from 03:48:50 to 03:50:25 UTC on 16 September 2026. Root and independent peer reconciled every retained result and attempt with the original hosted inventory. No game payload files were persisted.

Game source: `c113a348ae69bd013b67f0d22a5391d604253545`, tree `7cdb91b4cdbf89256f4e0d430f0ec79f4a7e9486`. Publishing revision: `1167291e27773ef076ed64b6e06ba7c0339423a0`, tree `35e7edd148f91cda670aa9fac0593e28df417be4`. Successful run: `35052821808`; deployment: `6473320472`; latest success status: `18406117394`.

Verified test entry: https://mekhovov.github.io/revealline/releases/v0.58.0/site/game/index.html

The hosted receipt covers all 657 frozen manifest files, their canonical metadata, current aliases, workers, catalog and 66 historical bridges. The small original receipts ZIP was downloaded and checked against its GitHub artifact digest. The complete Pages artifact and release source/distribution archives were not downloaded locally. The reused streaming helper changes only frozen identities and corresponding retained-catalog/self-check expectations; its transport is unchanged.

`tools/runs/complete-1/` contains every attempt, result, full inventory and final report. `public-row-review.json`, `peer-review.json` and `after-http-review.json` record distinct reviews. Original API snapshots, receipt ZIP members, hosted job logs, tool origins and provenance, offline helper checks, the initial unreviewed binding and its reviewed successor are retained. The one corrected peer inspection assumption is documented in `binding-review.json`.

Fresh post-audit API observations confirm the same main/deployment/run and latest stable release, tag, source and all nine release assets. This byte verification does not establish browser interaction, offline behavior, physical-device qualification or phase acceptance. Those remain separate release evidence.
