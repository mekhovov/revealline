from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import hashlib, json, os
ROOT = Path(__file__).resolve().parent
PINS = json.loads((ROOT / "source-pins.json").read_bytes())
ASSETS = {}
for row in PINS["files"]:
    raw = (ROOT / row["name"]).read_bytes()
    assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
    ASSETS["/" + row["name"]] = (raw, row["mime"])
ASSETS["/"] = ASSETS["/index.html"]
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        item = ASSETS.get(self.path)
        if item is None:
            self.send_error(404)
            return
        body, mime = item
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)
    def log_message(self, format, *args):
        pass
# Port zero is atomically allocated by the OS: no fixed-port reuse or race.
server = HTTPServer(("127.0.0.1", 0), Handler)
receipt = {"pid": os.getpid(), "url": "http://127.0.0.1:" + str(server.server_port) + "/", "portAllocation": "OS ephemeral bind succeeded", "scope": "Two bounded in-memory static files; no JavaScript, game modules or remote requests."}
(ROOT / "server-start.json").open("x").write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)
server.serve_forever()
