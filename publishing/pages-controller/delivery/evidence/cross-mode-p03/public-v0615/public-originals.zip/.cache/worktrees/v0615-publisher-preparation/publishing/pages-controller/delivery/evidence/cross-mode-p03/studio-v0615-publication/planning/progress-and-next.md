# Current plan — v0.61.4 accepted; v0.61.5 published, Pages pending

**Latest accepted public version: v0.61.4.** Its scoped About correction passed all **3,024 public files / 641,490,279 bytes**, two recovered HTTP 503 attempts, actual public About Escape/Return, Solo Pause/Resume/win/Next and Collection picture/focus restoration. [Accepted scope and evidence](../../public-v0614/README.md)

**The next priorities are dependable navigation, shared readable presentation, and clear cross-mode artwork and feedback.** Publish and verify the already-qualified corrections before expanding campaigns. Keep the three-level benchmark as the gameplay and visual quality gate. The introductory First Signal win does not establish satisfying difficulty or replay value.

P03, P05, P08-A/B, P07 and P18 remain open. P00 integration, P01 loading feedback and P02-A master sound controls retain their accepted scopes. The Team result panel still obscures its earned picture; the local View picture candidate has passed its scoped native journey, and its exact source package is now root-accepted; immutable publication and public gates remain open. Both full hosted source families have now passed 5,902 tests across 465 files. Archive23's original v0.61.1/v0.61.2 retention is accepted. Archive24 now preserves both v0.61.3 and v0.61.4: 1,394 files / 626,715,708 bytes, all 697 prior canonical rows and scoped native play for both cohorts; initial evidence and the first hosted HTTP 500 failure remain retained. This does not advance a parent phase.

**Scope correction:** Enemy Workshop is present in the frozen manifest and public Workshop. Earlier excluded/source-only descriptions were false; see the [dated packaging correction](../../public-v0614/packaging-scope-correction.md). Public v0.61.4 still loses visible focus after its initial catalog closes. The prepared v0.61.20 correction is not part of this acceptance.

## Dated release queue

**Coordination snapshot: 18 September 2026, 11:15 UTC.** This is a scoped evidence and coordinator-status snapshot, not a new native or full-source requalification of later candidates. Historical reports remain unchanged.

| Order | Candidate | Current status | Next gate |
| --- | --- | --- | --- |
| Accepted scope | v0.61.4 — About return and public runtime | Exact source, immutable assets, complete deployed byte audit and actual public About/Solo/Collection journeys accepted | Preserve this limited scope; complete the public Enemy startup-close and Team reward follow-ups. |
| 1 | v0.61.5 — Studio guide continuity | Exact source package qualified; source-native loading, close focus and edited-description/preview continuity passed. Nine immutable assets are published as release 391391690 and GitHub Latest is confirmed; this Pages selector is prepared, not deployed or accepted | Review/merge publisher, verify actual Pages identity and all public bytes, then exercise the shipped Studio guide and ordinary game/history journeys. Broader Studio creation, save/export, device and media gates stay open. |
| 2 | v0.61.6 — Versus board fitting | Qualified package; scoped native geometry passed | Release/public and remaining input gates; arena fitting does not establish every actor body extent. |
| 3 | v0.61.7 — Motion Lab rotation focus | Qualified package; scoped native vertical visibility passed | Release/public gates; retain the right-edge limitation. |
| 4 | v0.61.8 — Still Media picker clearance | Root-accepted source package; exact-source Standard-text native portrait/landscape passed | Release/public and broader reading/device gates. |
| 5 | v0.61.9 — Still Media reading preferences | Root accepted the exact corrected source package `6db978db40287151489803e915cb4ecb9ea232ee`: 5,888 tests across 465 files in each family, build/freeze and frozen inspection. Actual-source Plain/Large portrait and landscape passed | Finish immutable release and public gates. Source qualification is complete; no immutable or public v0.61.9 release is claimed here. |
| 6 | v0.61.20 — Enemy startup-close focus | Root accepted the exact source package `d51acab59232edc4e7f77ab5df491f2c403de709`, tree `1ebd48695649123c08f7092f88cafeb442f9f0d6`: both hosted families passed 5,895 tests across 465 files, frozen inspection and all seven attachments verified. Exact-source keyboard Escape/Back/Tab/Return and responsive focus passed | Immutable release and public gates remain. Enemy Workshop is shipped; verify its affected startup-close focus journey after deployment. |
| 7 | v0.61.21 — Team View picture reward | Exact source `ef1430174dfd35a9df441233988b8737d0401851`, tree `d6fbd2c8f2e7c549eeab602026ee80b3fa3af2d4`; eleven feature/docs/version paths. Both hosted families passed 5,902 tests across 465 files and frozen inspection is accepted. First Connection native win at 66.6%, 0:25, three joint cuts and five reserves; View/Back/Escape, Standard/Plain-Large layouts and explicit Retry passed. Actual Relay Yard timed attempt failed at 0.0%, four reserves and 0/2 anchors and establishes no native win/viewer acceptance. Root accepted the exact final source package: all five assembly stages passed, seven attachments retained, 240 qualification pins and all 251 evidence ZIP members independently checked | Finish immutable release and public viewer/navigation gates. Native Relay Yard win, physical devices and full P07 remain open. |

The v0.61.9 original hosted fixture failure remains retained; later passing evidence does not erase it. Its native dimensions were 390×844 and 844×390. Local packages, previews, full CI and frozen inspection are distinct from immutable publication and accepted public delivery. The queue's later-candidate statuses are coordinator-reported at this checkpoint; this documentation task did not perform new browser or remote CI checks for them. The [original v0.61.9 source-package acceptance](../../public-v0613/queue-evidence/v0619-source-package.original.json) is retained separately. The [original v0.61.21 native reward observation](../../public-v0613/queue-evidence/v06121-source-native.original.json) qualifies only its stated local source journey.

## Prioritized remaining phases

| Order | Phase | Status | Remaining completion gate |
| --- | --- | --- | --- |
| Accepted scopes | P00 / P01 / P02-A | Complete within recorded scopes | Preserve baseline integration, loading feedback and master-sound guarantees. |
| 1 | P03 — native navigation | Partial | Complete current menus, dialogs, mode entry/exit, focus restoration and explicit Back/Resume. The picker-clearance source fix is complete in v0.61.8 with scoped Standard-text native checks; its release/public gate remains. Finish public verification of the source-qualified v0.61.9 reading integration and remaining device coverage. Fix host Close local connections focus loss. Qualify Motion Lab rotation changes and their retained right-edge limitation. Verify whole keyboard/controller/touch journeys. |
| 2 | P05 — shared readable presentation | Partial | Keep focused fields visible beside pinned operation feedback. Fix the short-landscape saving-warning overlap and the source-confirmed Team canvas omission of the Large-text preference. Complete cross-mode preferences, EN/UA glyphs, text modes, zoom and reduced effects. |
| 3 | P08-A — artwork and actor parity | Partial | Preserve exact picture identities and the complete arena; finish readable silhouettes, heading, motion and displayed scale across Solo, Versus and Team with independent collision geometry. Resolve the shared 64-logical-pixel actor cap versus nominal minimum display size on narrow 72-column boards; Versus arena fit alone does not qualify actor body extents. |
| 4 | P08-B — action feedback | Partial | Explain trail danger, capture, loss/recovery, bonuses, Support/rescue and victory without obscuring play; cover reduced effects and every advertised mode. |
| 5 | P09 — challenge and enemy intelligence | Partial foundations | Tune the three-level benchmark, route pressure and warnings/counters. Prove deterministic collision, replay/checkpoints and defeat-once rewards, then complete human difficulty and replay-value playtests. |
| 6 | P07 — rewards and continuation | Partial; ordinary Solo correction accepted in v0.61.0 | Qualify and release the v0.61.21 unobscured View picture candidate; the accepted Team result panel still covers the earned image. Finish all advertised mode transitions, objective/mastery clarity, optional skippable stories, recovery and duplicate-reward safeguards. |
| 7 | P02-B — complete music | Partial | Custom MP3s and shared playlists in every advertised mode; actual transfer and offline playback; audition and qualify synth, chiptune, rock and metal tracks. |
| 8 | P04 — creation framework | Partial | Demonstrate real upload/edit/export/import/play with exact original bytes, previews/history, asset and edition registries, prompts and safe failure recovery. |
| 9 | P06 — discovery and installation | Partial | Compatible catalog, explicit optional downloads, replacement/removal and interrupted-install recovery. Validate storage capacity before campaign expansion. |
| 10 | P10 — richer Team encounters | Queued | First Connection and Relay Yard variants with Support, rescue, shared objectives and a separate two-player readability/encounter matrix. |
| 11 | P11-A–D — FPV campaigns | Queued | Four independently released twelve-mission campaigns with complete art, actors, sound, progression and rewards. |
| 12 | P12-A–D — DroneAid campaigns | Queued | Four independently released twelve-mission campaigns with distinct Support/Combat framing and authored class interactions. |
| 13 | P13 — Ukrainian culture | Queued | Twelve Living Atlas missions with cultural, historical and visual review. |
| 14 | P14 — retro arcade | Queued | Twelve After School Arcade missions with distinct nostalgic art, encounters and music. |
| 15 | P15 — spend management | Queued | Twelve Spend in Motion missions with understandable noncombat goals and complete Coupa-theme presentation. |
| 16 | P16 — supporting workflows | Partial | Complete Collection, scores, replay, learning, data recovery and legacy-content journeys under the established navigation standard. |
| 17 | P17 — reproducible authoring | Partial | Complete guides, AI skills, prompts, templates and CLI examples. Modularize the runtime-maintainer skill (currently over 200 KB) into a concise entry point and scoped reference files; this is future documentation work, not a runtime change in v0.61.5. Independently create, install, play, export and recover an example from a fresh workspace. |
| Release gate | P18 — full browser qualification | Partial evidence | Cross-phase regression, performance, accessibility, media/offline recovery and real touch/controller hardware. Resolve required outstanding issues. |
| Later | Native stores / network multiplayer | Deferred | Separate packaging, signing, lifecycle, hardware, authoritative-network and reconnect gates. |

Bulk content follows the three-level gameplay/presentation benchmark. **132 new Solo missions and 36 Team configurations remain programme targets**, alongside the retained illustration, story, character-animation and finished-music targets. Registry coverage, source checks and a byte audit do not establish complete content or enjoyable challenge.

## Retained content ledger

These are the last accepted ledger limits, retained for planning; this documentation update did not re-audit the content library. Candidate files and enlarged previews do not count as accepted finished content.

| Content | Last accepted scope | Still open |
| --- | --- | --- |
| Map picture families | 15/29 families; 60/116 pictures | 14 families and 56 pictures beyond accepted content. |
| Victory stories | 1/12 | Eleven stories plus complete playback/recovery qualification. |
| Reserve illustrations | 40 selected source originals | Source reserves are not 40 installed missions or runtime derivatives. |
| Character presentations | Partial | Target of 56 complete animated sets remains unmet; body images alone do not count. |
| Finished music | Partial | The 24-track programme still requires completed listening and qualification; recipes or candidate tracks do not establish the album gate. |

## Next implementation focus

Advance the qualified release queue in order while finishing P03 navigation. Publish and verify the v0.61.8 picker-clearance source fix and v0.61.9 reading integration, then complete their broader device gate. The historical public v0.61.1 picker could be activated while covered; source and native fixes now exist, but they are not yet accepted public delivery. Preserve Cancel/Close visibility without placing them over the focused field or its label. Restore a useful keyboard target after Close local connections; the current Back link remains reachable but requires fresh traversal. The public observations and their limits are retained in the [v0.61.1 public report](../../../cross-mode-p05/public-v0611/README.md).

Finish the release/public gate for the separate Motion Lab rotation-focus source correction, retaining the right-edge limitation, then address the compact saving-warning placement and Team canvas Large-text propagation. Local source or focused test success does not close their public device/input gates. Motion Lab's animation recipe has a wrapped label and passed actual keyboard naming; a failed exact automation locator alone is not a semantic-label defect.

Then finish cross-mode artwork and action feedback before judging difficulty on the three-level FPV benchmark. Record comprehension, attempts, loss causes, safe routes and route variety. The introductory First Signal win is a smoke test, not evidence that enemy pressure or replay value is finished. Enemy Workshop is shipped in the public package. Correct earlier excluded/source-only claims and preserve their originals; the public initial-dialog focus defect remains open for v0.61.20. Source-preview observations cannot replace the actual deployed Workshop journey. Complete audible music, story, offline and hardware journeys in their own gates.

The [Xbox navigation guidance](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/112) and [W3C modal-dialog pattern](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/) provide references for visible focus and return paths. The root coordinator freshly checked these references on 18 September 2026. Every close/Back should restore visible focus to a logical opener, and dialog content must not cover Back. Digital controller navigation tests remain separate from physical hardware acceptance.

For each release, report the player-visible result, exact source/PR, playable URL, passed evidence and remaining limitations. Only accepted public scope becomes Complete. Candidate packages, content targets and whole parent phases stay open until their own gates pass.

The [root v0.61.20 package acceptance](../queue-evidence/v0620-source-package.original.json) and [v0.61.21 frozen-inspection reconciliation](../queue-evidence/v0621-inspection-reconciliation.original.json) are retained at this cutoff. Neither establishes a public release; v0.61.21 final package is [root-accepted for exact-source qualification only](../queue-evidence/v0621-source-package.original.json). Its [earlier assembled package receipt](../queue-evidence/v0621-package-ready.original.json) remains retained. No immutable publication, public or full-phase acceptance is inferred.
