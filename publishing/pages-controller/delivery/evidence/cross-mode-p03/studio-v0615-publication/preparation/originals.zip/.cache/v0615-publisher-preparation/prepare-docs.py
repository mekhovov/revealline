from helpers import *
import datetime
F=D/'delivery/evidence/cross-mode-p03/studio-v0615-publication'
publication=R/'.cache/v0615-release-preparation/root-publish-r1'
root_review=json.loads((publication/'review.json').read_bytes())
assert root_review['status']=='RELEASE_PUBLISHED_NINE_ASSET_IDENTITIES_UNCHANGED'
assert root_review['source']=='d34e283819376eb43e4942287d9767b22a4f6487'
upload=R/'.cache/v0615-upload-observation/root-small-intake-r1'
reconciliation=R/'.cache/v0615-v0621-small-evidence-review/v0.61.5-reconciliation.json'
source_review=R/'.cache/p03-qualified/studio-guide-v0615-d34e2838/final-execution/root-package-review.json'
native=R/'.cache/p05-studio-native-v0615/root-native-guide.json'
prior=R/'.cache/p03-public-audit-d6800fa5/root-public-acceptance.json'
q620=R/'.cache/p03-enemy-startup-close-focus-v06120/final-execution-r5/root-package-review.json'
recon621=R/'.cache/v0615-v0621-small-evidence-review/v0.61.21-reconciliation.json'
for src,name in [(publication/'review.json','root-publication.json'),(native,'native-local-observation.json'),(source_review,'root-source-package-review.json'),(reconciliation,'root-upload-reconciliation.json'),(prior,'prior-v0614-public-acceptance.json'),(q620,'queue-evidence/v0620-source-package.original.json'),(recon621,'queue-evidence/v0621-inspection-reconciliation.original.json')]:cp(src,F/name)
selected=[p for p in publication.iterdir()if p.is_file()]
selected += [native,source_review,reconciliation,prior,q620,recon621,upload/'receipt.json',upload/'original-receipt.zip',P/'sync-published-originals.mjs',P/'sync.stdout',P/'sync.stderr',P/'sync.receipt.json']
research=R/'.cache/continuation-research-20260918/navigation.md'
assert sha(research.read_bytes())=='be311e8a70b51b2d6bc4de9bc2cb843ed8ce6c2d98a72e2aea551685e2dc4dd5'
selected.append(research)
count,size=bundle(F,selected)
put(D/'evidence/current-v0615/README.md',"""# v0.61.5 exact-source qualification

The original published qualification binds source `d34e283819376eb43e4942287d9767b22a4f6487`, tree `3af511259e14ed2af11a2e2498535744450a378f`. Each full hosted family passed **5,853 tests across 462 files**, alongside the six source gates, production checks, ordinary build, freeze and original artifact inspection.

The immutable release and GitHub Latest are confirmed. This selector's Pages and public acceptance remain pending. The [publication record](../../delivery/evidence/cross-mode-p03/studio-v0615-publication/README.md) retains the actual source-native Studio guide, focus, edited-description and preview-continuity observations, including the failed automation locator and scope limits. Source qualification, publication and public acceptance remain separate; parent phases stay open.
""")
put(F/'README.md',"""# v0.61.5 — Studio guide continuity

**v0.61.4 remains the latest accepted public baseline.** Its About correction passed the complete **3,024-file / 641,490,279-byte** public audit, with two recovered HTTP 503 attempts and actual About, Solo and Collection keyboard journeys. Enemy Workshop is shipped; its initial-dialog focus defect remains open for the separately source-qualified v0.61.20 correction. [Accepted v0.61.4 scope](../public-v0614/README.md)

**v0.61.5 is published; this Pages selector remains pending acceptance.** The Studio guide opens during current-release collection loading, Escape returns focus to its opener, and opening or closing the guide preserves the edited description and current preview motion. The frozen manifest positively includes `authoring/asset-studio/index.html` and `authoring/asset-studio/studio.mjs`, so the affected Studio journey requires actual public verification after deployment.

Exact source `d34e283819376eb43e4942287d9767b22a4f6487`, tree `3af511259e14ed2af11a2e2498535744450a378f`, source PR116, passed **5,853 tests across 462 files in each hosted family**, all six source gates, production checks, ordinary build/freeze and frozen inspection. Release **391391690**, annotated tag `00c2b328c81dc8894186d7971466424cca1ca8b8`, was published on 18 September 2026 at **10:57:06 UTC**. Nine original asset identities and the GitHub Latest readback match the retained upload reconciliation.

The first publication readback refused full asset-object equality because publishing changes draft download URLs to tag URLs. The successful publication response, prior draft response, actual Latest readback and root reconciliation remain unchanged in the originals. No mutation retry was made. All nine asset IDs, names, sizes, digests and uploaded states match; mutable URLs are not byte identities.

Root's actual source-native observation opened the guide while collection loading continued, then Escape restored `studio-guide-open` focus. The collection completed with 293 slots and ready current/draft previews. A temporary Panel frame description and playing cosmetic loop survived guide open/close. The original description and paused preview were restored without saving or exporting. The failed exact `getByLabel(Motion)` automation lookup remains recorded; inspecting the actual `preview-motion` control allowed native selection, so no product label defect was inferred. This is source-preview evidence, not public acceptance. No save/export/byte round-trip, physical controller/touch, audible listening, offline or full Studio acceptance is claimed. Screenshots were not exported.

Archive24 now retains both **v0.61.3 and v0.61.4** under commit `2ead35c57856ef8948058a1df21788383a6385ed` and deployment `6522823756`. Root accepted **1,394 public files / 626,715,708 bytes**, preserving all **697 prior canonical rows**, plus scoped native play for both cohorts. The first hosted HTTP 500 failure and unchanged successful second attempt remain retained. Its initial v0.61.3 evidence is preserved. This selector preserves all **85 prior catalog entries and 23 other archive admissions**, adds v0.61.5 metadata and replaces only Archive24's reviewed admission/allocation with the provided append.

Before public v0.61.5 acceptance, review and merge the publisher, verify deployment identities and every public byte, then exercise the shipped Studio guide during loading, Escape focus restoration and edit/preview continuity through actual input. Keep ordinary public game and history navigation in the regression check. Existing navigation guidance requires visible logical opener/Back focus; digital controller tests remain separate from physical hardware. [Current plan and remaining gates](planning/progress-and-next.md) retain P03/P05/P07/P08/P18 and broader Studio creation, save/export, media, offline and device work.

The finite originals ZIP preserves the exact publication/readback, complete small upload receipt, source/native reviews and current accepted public baseline. It includes the root publication reconciliation following the mutable-URL refusal; neither failures nor old records are rewritten. The published qualification archive remains the full source authority. No payload GET, rebuilt game or new immutable asset is created by this preparation.
""")
prior_plan=D/'delivery/evidence/cross-mode-p03/public-v0614/planning/progress-and-next.md'
plan=prior_plan.read_text()
plan=plan.replace('# Current plan — v0.61.4 accepted; navigation remains first','# Current plan — v0.61.4 accepted; v0.61.5 published, Pages pending')
plan=plan.replace('[Accepted scope and evidence](../README.md)','[Accepted scope and evidence](../../public-v0614/README.md)').replace('[dated packaging correction](../packaging-scope-correction.md)','[dated packaging correction](../../public-v0614/packaging-scope-correction.md)')
plan=plan.replace('while frozen inspection, final qualification and public gates remain open.','while final qualification and public gates remain open; its frozen inspection has passed.')
plan=plan.replace('Archive24 now separately preserves v0.61.3: 698 files / 313,350,864 bytes, actual keyboard play and Release explorer return.','Archive24 now preserves both v0.61.3 and v0.61.4: 1,394 files / 626,715,708 bytes, all 697 prior canonical rows and scoped native play for both cohorts; initial evidence and the first hosted HTTP 500 failure remain retained.')
plan=plan.replace('18 September 2026, 10:42 UTC','18 September 2026, '+datetime.datetime.now(datetime.timezone.utc).strftime('%H:%M')+' UTC')
lines=plan.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| 1 | v0.61.5'):
  lines[i]='| 1 | v0.61.5 — Studio guide continuity | Exact source package qualified; source-native loading, close focus and edited-description/preview continuity passed. Nine immutable assets are published as release391391690 and GitHub Latest is confirmed; this Pages selector is prepared, not deployed or accepted | Review/merge publisher, verify actual Pages identity and all public bytes, then exercise the shipped Studio guide and ordinary game/history journeys. Broader Studio creation, save/export, device and media gates stay open. |'
 elif line.startswith('| 6 | v0.61.20'):
  lines[i]='| 6 | v0.61.20 — Enemy startup-close focus | Root accepted the exact source package `d51acab59232edc4e7f77ab5df491f2c403de709`, tree `1ebd48695649123c08f7092f88cafeb442f9f0d6`: both hosted families passed5,895 tests across465 files, frozen inspection and all seven attachments verified. Exact-source keyboard Escape/Back/Tab/Return and responsive focus passed | Immutable release and public gates remain. Enemy Workshop is shipped; verify its affected startup-close focus journey after deployment. |'
 elif line.startswith('| 7 | v0.61.21'):
  lines[i]='| 7 | v0.61.21 — Team View picture reward | Exact source `ef1430174dfd35a9df441233988b8737d0401851`, tree `d6fbd2c8f2e7c549eeab602026ee80b3fa3af2d4`; eleven feature/docs/version paths. Both hosted families passed5,902 tests across465 files and frozen inspection is accepted. First Connection native win at66.6%,0:25,three joint cuts andfive reserves; View/Back/Escape, Standard/Plain-Large layouts and explicit Retry passed. Actual Relay Yard timed attempt failed at0.0%,four reserves and0/2anchors and establishes no native win/viewer acceptance. Six semantic inputs are root-reviewed; context preparation is in progress | Finish final source qualification, immutable release and public viewer/navigation gates. Native Relay Yard win, physical devices and full P07 remain open. |'
plan='\n'.join(lines)+'\n'
plan=plan.replace('passed5,','passed 5,').replace('across465','across 465').replace('at66.6%,0:25,three joint cuts andfive','at 66.6%, 0:25, three joint cuts and five').replace('at0.0%,four reserves and0/2anchors','at 0.0%, four reserves and 0/2 anchors').replace('release391391690','release 391391690')
plan=plan.replace('not a runtime change in v0.61.4','not a runtime change in v0.61.5')
plan += '\nThe [root v0.61.20 package acceptance](../queue-evidence/v0620-source-package.original.json) and [v0.61.21 frozen-inspection reconciliation](../queue-evidence/v0621-inspection-reconciliation.original.json) are retained at this cutoff. Neither establishes a public release; v0.61.21 final qualification remains pending.\n'
put(F/'planning/progress-and-next.md',plan)
for path,prefix,replacement in [(D/'README.md','The selector now proposes published','The selector now proposes published **v0.61.5** from exact source `d34e283819376eb43e4942287d9767b22a4f6487`. Archive24 preserves v0.61.3 and v0.61.4 through its accepted 1,394-file / 626,715,708-byte inventory and scoped native play, preserving 697 prior canonical rows. All 85 prior catalog records and 23 other admissions remain unchanged; Archive24 alone receives the reviewed append. The accepted public baseline is v0.61.4. This selector requires publisher preview/merge, Pages deployment, the complete public byte audit and the shipped Studio guide journey. See [current-source inputs](evidence/current-v0615/README.md), [archive append](evidence/archive-24/append-v0614/README.md) and [publication record](delivery/evidence/cross-mode-p03/studio-v0615-publication/README.md).'),(D/'delivery/README.md','**Current accepted public release:','**Current accepted public release: v0.61.4.** Its [accepted report](evidence/cross-mode-p03/public-v0614/README.md) records 3,024 files / 641,490,279 bytes, two recovered HTTP 503 attempts and actual About/Solo/Collection keyboard journeys. Enemy Workshop is shipped; earlier source-only descriptions were incorrect. Its public startup-close focus defect remains open for source-qualified v0.61.20. **v0.61.5 Studio guide continuity is published on GitHub; this Pages selector remains pending.** See the [publication record](evidence/cross-mode-p03/studio-v0615-publication/README.md) and [current plan](evidence/cross-mode-p03/studio-v0615-publication/planning/progress-and-next.md). Archive24 retains both prior public editions. Parent P03/P05/P07/P08/P18 and physical/media/offline gates remain unfinished.')]:
 text=path.read_text().replace('all 85 pinned semantic releases','all 86 pinned semantic releases');lines=text.splitlines();matches=[i for i,l in enumerate(lines)if l.startswith(prefix)];assert len(matches)==1;lines[matches[0]]=replacement;path.write_text('\n'.join(lines)+'\n')
pub=json.loads((D/'publication.json').read_bytes());assert pub['currentVersion']=='v0.61.4';pub['currentVersion']='v0.61.5';pub['catalogSha256']=sha((D/'catalog.json').read_bytes());pub['currentSourceQualification']={'path':'evidence/current-v0615/source-qualification.json','sha256':sha((D/'evidence/current-v0615/source-qualification.json').read_bytes())};(D/'publication.json').write_text(json.dumps(pub,indent=2)+'\n')
obj(P/'documentation-preparation.json',{'publicationOriginals':count,'ZIPBytes':size,'acceptedPublicBaseline':'v0.61.4','v615PagesAccepted':False,'phaseComplete':False,'skillUnchangedAndCorrectedWorkshopScopePreserved':True,'gameSourceAndVersionFilesUntouched':True})
print(json.dumps({'publicationOriginals':count,'ZIPBytes':size,'selector':'v0.61.5','PagesAccepted':False}))
