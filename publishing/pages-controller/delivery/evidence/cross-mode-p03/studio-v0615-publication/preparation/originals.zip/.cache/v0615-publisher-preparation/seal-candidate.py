from helpers import *
import datetime,re,difflib
F=D/'delivery/evidence/cross-mode-p03/studio-v0615-publication'
assert sha((admin/'index').read_bytes())==json.loads((P/'baseline.json').read_bytes())['indexSha256']
for n in ['node20','node22']:
 text=(P/'checks-r1'/(n+'.stdout')).read_text();assert '# tests 43' in text and '# pass 43' in text and '# fail 0' in text
assert 'Ran 4 tests' in (P/'checks-r1/python.stderr').read_text() and '\nOK\n' in (P/'checks-r1/python.stderr').read_text()
assert all(r['exit']==0 for r in json.loads((P/'checks-r1/results.json').read_bytes()))
for n in ['sync','verify-local-candidate','diff-check']:assert json.loads((P/(n+'.receipt.json')).read_bytes())['exit']==0
selection=[p for p in (P/'checks-r1').rglob('*')if p.is_file() and 'tmp'not in p.parts]
for n in ['baseline.json','sparse-paths.txt','archive-adoption.json','helpers.py','sync-published-originals.mjs','sync.stdout','sync.stderr','sync.receipt.json','run-checks.py','verify-local-candidate.mjs','verify-local-candidate.stdout','verify-local-candidate.stderr','verify-local-candidate.receipt.json','diff-check.stdout','diff-check.stderr','diff-check.receipt.json','verify-preservation.py','prior-preservation.json','prepare-docs.py','documentation-preparation.json','queue-before-root621-acceptance.md','queue-cutoff-update.json','seal-candidate.py']:selection.append(P/n)
bundle(F/'preparation',selection)
oldpub=json.loads(subprocess.check_output(['git','-C',str(W),'show',base+':publishing/pages-controller/publication.json']))
pub=json.loads((D/'publication.json').read_bytes());assert len(pub['admissions'])==24
assert [r for r in pub['admissions']if r['id']!='archive-24']==[r for r in oldpub['admissions']if r['id']!='archive-24']
A=R/'.cache/archive24-v0614-main-admission';accepted=json.loads((A/'candidate-pins.json').read_bytes())
for row in accepted['records']:
 b=(D/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
assert next(r for r in pub['admissions']if r['id']=='archive-24')==json.loads((A/'admission.proposed.json').read_bytes())
alloc=json.loads((D/'allocations.json').read_bytes());assert next(r for r in alloc['shards']if r['id']=='archive-24')==json.loads((A/'allocation.proposed.json').read_bytes())
tracked=subprocess.check_output(['git','-C',str(W),'diff','--name-only'],text=True).splitlines()
assert set(tracked)=={'publishing/pages-controller/README.md','publishing/pages-controller/delivery/README.md','publishing/pages-controller/allocations.json','publishing/pages-controller/catalog.json','publishing/pages-controller/publication.json'}
newroots=[F,D/'evidence/archive-24/append-v0614',D/'evidence/current-v0615',D/'metadata/v0.61.5']
files=sorted(set([W/p for p in tracked]+[p for root in newroots for p in root.rglob('*')if p.is_file()]))
for p in files:assert p.is_relative_to(W) and not any(x.is_symlink()for x in [p,*p.parents]) and p.stat().st_size<8*1024**2
bundles=[]
for dest in [F,F/'preparation',D/'evidence/archive-24/append-v0614']:
 index=json.loads((dest/'originals-index.json').read_bytes());raw=(dest/'originals.zip').read_bytes();assert len(raw)==index['zip']['bytes'] and sha(raw)==index['zip']['sha256']
 with zipfile.ZipFile(io.BytesIO(raw))as z:
  assert z.testzip()is None and len(z.infolist())==len(index['files'])
  for row in index['files']:
   b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256'];assert (R/row['path']).read_bytes()==b
 bundles.append({'path':str(dest.relative_to(W)),'members':len(index['files']),'bytes':len(raw),'sha256':sha(raw)})
links=0
newdocs=[F/'README.md',F/'planning/progress-and-next.md',D/'evidence/current-v0615/README.md']
for p in [*newdocs,D/'README.md',D/'delivery/README.md']:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if ':' in target or target.startswith('#'):continue
  target=target.split('#')[0]
  if not target:continue
  dest=(p.parent/target).resolve();relative=dest.relative_to(W).as_posix()
  if not dest.exists():assert subprocess.run(['git','-C',str(W),'cat-file','-e',base+':'+relative],capture_output=True).returncode==0,(p,target)
  links+=1
rows=[pin(p,W)for p in files]
obj(P/'candidate-pins.json',{'format':'revealline-reviewed-candidate-paths.v1','base':base,'worktree':str(W),'files':rows,'totalBytes':sum(r['bytes']for r in rows),'indexUnchanged':True,'stageOrCommitPerformed':False})
obj(P/'original-bundles-check.json',{'status':'PASS_ALL_ZIP_CRC_ROWS_CURRENT_ORIGINALS','bundles':bundles,'localLinksResolved':links,'screenshotsInlineOnly':True})
put(P/'reviewed-hunks.diff',subprocess.check_output(['git','-C',str(W),'diff','--no-ext-diff','--unified=5']))
put(P/'new-documentation.diff',''.join(''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile=p.relative_to(W).as_posix()))for p in newdocs))
put(P/'status-before-review.txt',subprocess.check_output(['git','-C',str(W),'status','--porcelain','--untracked-files=all']))
assert sha((admin/'index').read_bytes())==json.loads((P/'baseline.json').read_bytes())['indexSha256']
put(P/'pr-body.md',"""Select the original published v0.61.5 Studio guide-continuity release after preserving v0.61.4 alongside v0.61.3 in Archive24. The selector binds exact source `d34e283819376eb43e4942287d9767b22a4f6487`; all 85 prior catalog entries, 23 other admissions and Archive24's initial evidence remain unchanged. The provided append retains 1,394 public files / 626,715,708 bytes, all 697 prior canonical rows and scoped native play for both cohorts.

v0.61.4 remains the accepted public baseline. v0.61.5 needs the hosted publisher preview, deployment, complete public byte audit and actual shipped Studio guide/loading, Escape-focus and edit/preview-continuity checks. Enemy Workshop remains explicitly shipped, with its public startup-close issue separate from the accepted v0.61.20 source correction. v0.61.21 is now root-accepted for exact-source qualification only. No game, version or publisher-helper change is included.

Validation: 43 publisher tests on each of Node 20.19.5 and Node 22.22.2; four Python tests; all 86 metadata chains, exact current qualification and changed archive admission; 891 prior bodies rehashed from Git without hydration; original ZIP CRC/member checks; clean tracked diff. Original publication responses and the mutable-URL readback refusal followed by root reconciliation are retained. Public, device, offline/media and parent-phase acceptance remain separate.
""")
used=sum(q.stat().st_size for d in [W,P,admin]for q in d.rglob('*')if q.is_file()and not q.is_symlink());free=shutil.disk_usage(R).free;assert used<32*1024**2 and free>=512*1024**2
ready={'status':'READY_FOR_ROOT_HUNK_REVIEW_NOT_STAGED','preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':'codex/v0615-pages-preparation','base':base,'baseTree':json.loads((P/'baseline.json').read_bytes())['baseTree'],'worktree':str(W),'manifest':pin(P/'candidate-pins.json',R),'hunks':pin(P/'reviewed-hunks.diff',R),'newDocumentation':pin(P/'new-documentation.diff',R),'prBody':pin(P/'pr-body.md',R),'source':{'version':'v0.61.5','commit':'d34e283819376eb43e4942287d9767b22a4f6487','tree':'3af511259e14ed2af11a2e2498535744450a378f','tagObject':'00c2b328c81dc8894186d7971466424cca1ca8b8','releaseId':391391690,'qualificationSha256':'1f56a442e24b7da51a91332366a76c3ea0e1e2968ce11067fc61c94a023ace53'},'archive24':{'commit':'2ead35c57856ef8948058a1df21788383a6385ed','tree':'1669010d35488be79a3f60df7ff1be64db846c40','deploymentId':6522823756,'versions':['v0.61.3','v0.61.4'],'files':1394,'bytes':626715708,'priorCanonicalRows':697,'adoption':pin(P/'archive-adoption.json',R)},'checks':{'node20':43,'node22':43,'python':4,'allMetadataChains':86,'currentSourceAndChangedAdmission':True,'diffCheck':True,'indexUntouched':True},'preservation':pin(P/'prior-preservation.json',R),'originalBundles':pin(P/'original-bundles-check.json',R),'priorCatalogRecordsUnchanged':85,'otherAdmissionsUnchanged':23,'totalAdmissions':24,'archive24InitialEvidenceUnchanged':True,'acceptedPublicBaseline':'v0.61.4','v615PagesAccepted':False,'phaseAccepted':False,'stageOrCommitPerformed':False,'remoteMutationPerformed':False,'bodyGETs':0,'gameVersionOrPublisherHelperChanges':False,'skillChanged':False,'correctedShippedWorkshopScopePreserved':True,'managedBytesBeforeReady':used,'managedCapBytes':33554432,'freeBytes':free,'reserveBytes':536870912,'remaining':['Root reviews the exact path manifest and hunks, stages only these paths and commits.','Hosted full filesystem publisher assembly/preview, main integration and protected Pages deployment.','Verify actual deployment identities and complete public bytes, then shipped Studio guide/loading, Escape-focus and edit/preview-continuity plus public game/history journeys.','Keep broader creation/save/export, physical devices, offline/media and parent phases open.'],'metadataProvenance':'Four retained original small assets matched against all nine draft, published, Latest and upload-reconciliation descriptors; no repeat downloads. The original mutable-URL equality refusal and root reconciliation remain in the publication bundle.','queueCutoff':'v0.61.20 and v0.61.21 exact-source packages are root-accepted; neither is claimed published or publicly accepted.'}
obj(P/'ready.json',ready)
print(json.dumps({'ready':pin(P/'ready.json',R),'manifest':pin(P/'candidate-pins.json',R),'paths':len(rows),'candidateBytes':sum(r['bytes']for r in rows),'managedBytes':used,'freeBytes':free,'bundleMembers':[x['members']for x in bundles]}))
