import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { syncReleaseMetadata } from '../worktrees/v0615-publisher-preparation/publishing/pages-controller/sync-release-metadata.mjs';
const sha = b => createHash('sha256').update(b).digest('hex');
const read = async name => JSON.parse(await fs.readFile(new URL('../v0615-release-preparation/root-publish-r1/' + name, import.meta.url)));
const publication = await read('publish.stdout');
const latest = await read('latest-after.stdout');
const before = await read('release-before.stdout');
const reviewed = await read('review.json');
const tag = await read('tag-before.stdout');
const tagObject = await read('tag-object-before.stdout');
const source = 'd34e283819376eb43e4942287d9767b22a4f6487';
if (publication.id !== 391391690 || latest.id !== publication.id || publication.tag_name !== 'v0.61.5' || latest.tag_name !== publication.tag_name || publication.draft || publication.prerelease || latest.draft || latest.prerelease || reviewed.status !== 'RELEASE_PUBLISHED_NINE_ASSET_IDENTITIES_UNCHANGED' || reviewed.source !== source) throw Error('Publication not bound');
if (tag.object.sha !== '00c2b328c81dc8894186d7971466424cca1ca8b8' || tag.object.type !== 'tag' || tagObject.sha !== tag.object.sha || tagObject.object.sha !== source || tagObject.object.type !== 'commit') throw Error('Tag identity differs');
const reconciliation = JSON.parse(await fs.readFile(new URL('../v0615-v0621-small-evidence-review/v0.61.5-reconciliation.json', import.meta.url)));
if (reconciliation.source.commit !== source || reconciliation.source.tree !== '3af511259e14ed2af11a2e2498535744450a378f' || reconciliation.status !== 'INDEPENDENT_LOCAL_RECEIPT_RECONCILIATION_PASS') throw Error('Reconciliation differs');
const fields = a => ({ id: a.id, name: a.name, size: a.size, digest: a.digest, state: a.state });
const sorted = xs => xs.map(fields).sort((a, b) => a.name.localeCompare(b.name));
const assets = sorted(publication.assets);
if (assets.length !== 9 || new Set(assets.map(a => a.name)).size !== 9 || !assets.every(a => a.state === 'uploaded')) throw Error('Expected exactly nine uploaded assets');
for (const previous of [before.assets, latest.assets, reviewed.assets, reconciliation.allNineHostedAssets]) {
  if (JSON.stringify(sorted(previous)) !== JSON.stringify(assets)) throw Error('Original asset identities changed');
}
const result = await syncReleaseMetadata({ versions: ['v0.61.5'], qualificationVersion: 'v0.61.5', download: async (version, name) => {
  if (version !== 'v0.61.5' || !['release.json', 'manifest.json', 'distribution.zip.sha256', 'source-qualification.json'].includes(name)) throw Error('Unexpected metadata');
  const raw = await fs.readFile(new URL('../v0615-upload-observation/root-small-intake-r1/evidence/reviewed-small-assets/' + name, import.meta.url));
  const a = assets.find(a => a.name === name);
  if (!a || a.size !== raw.length || a.digest !== 'sha256:' + sha(raw)) throw Error('Published original mismatch: ' + name);
  return raw;
}});
console.log(JSON.stringify({ ...result, publishedReleaseId: publication.id, allNineOriginalAssetIdentitiesPreserved: true, source, downloadedAgain: false, preservedFirstReadbackRefusal: reviewed.preservedFirstReadbackRefusal, origin: 'Retained original small assets matched against draft, published, Latest and root reconciliation descriptors; mutable URL differences are not asset-byte identities' }, null, 2));
