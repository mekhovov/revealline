# v0.61.20 public audit preparation

The twelve helpers reuse the accepted v0.61.9 byte-audit protocol with only source/version/catalog identity changes. HTTP transport, retry, no-redirect, MIME, path, receipt CRC, capacity and current-main guards are unchanged. The original helpers and complete diff are retained.

The retained catalog has 90 authorities; the accepted v0.61.9 byte inventory has 3,153 paths/642,265,836 bytes. Its root review explicitly preserves the 1.765625px portrait-return picker-outline failure and partial native scope. This preparation does not close that issue or any parent phase.

The v0.61.20 source is d51acab59232edc4e7f77ab5df491f2c403de709 / tree 1ebd48695649123c08f7092f88cafeb442f9f0d6. Nine descriptors and four original metadata bodies match the retained published release 391660904. These are retained observations, not a new live readback.

All future publisher/controller/run/deployment/receipt/current-inventory fields remain null. Root supplies the actual successful main run and hosted observation, reviews one bounded receipt descriptor and request, then promotes the exact derived binding. The unbound capacity wrapper must not execute before those reviewed identities replace its two placeholders. Commands.pending.json provides the existing sequence: before-authorities, one small intake, binding check, full HTTP, all-row review and fresh after-authorities. Native Enemy Workshop startup close, forward navigation, responsive opener focus and ordinary game return remain separate root-owned journeys. The Workshop is shipped in the frozen manifest.

No API, HTTP, artifact-body GET, browser, source edit, remote mutation or production audit runs during this preparation. Local tests use only mock transports. Main source payloads and every immutable release remain unchanged.
