# v0.61.3 public verification preparation

This cache-only successor retains the accepted v0.61.2 audit helpers and changes only explicit source, version and retained-catalog identities. The source is 58ff1b1da3c5487412e168ce34539866ac2f4970, tree 8fad1311f1403e9134a3b60af029e238bd7cc98e. The 83 prior catalog entries must remain intact; the new selector adds v0.61.3. The publisher carries the independently accepted Archive23 retention admission. Parent phases remain open.

PR128 head 3593f28b5a7654cbee5d235a207adc9283dc40cf has a successful preview run 35328010114. This is not a production deployment. Controller merge/tree, main Pages run/deployment/status, receipt descriptor and full deployed inventory remain intentionally unbound until their actual originals exist.

After the actual main workflow succeeds, use the unchanged finite metadata observer to prepare the small-receipt request. Root reviews that request before one receipt body GET and five bounded authority reads. The intake derives an unreviewed binding. Root then reviews the exact binding before one complete inventory audit. Afterward, reconcile original rows and refresh actual main/deployment/release/source/tag authorities. Do not reuse prior actual run, artifact or inventory identities.

Native public acceptance covers the packaged game and ordinary runtime/navigation. Enemy Workshop is not distributed in the public runtime package: its Return behavior has separate source-workspace evidence. Do not claim a public Enemy Workshop route, full P03 completion, physical-device acceptance, offline qualification or an audio listening pass.

The inherited 32 MiB cumulative output cap, 512 MiB free reserve, single receipt download, strict ZIP members, immutable attempts, MIME/length/hash checks, deadlines and bounded transient retries remain unchanged. No source/index/remote/browser mutation occurs in this preparation. The intake runner remains deliberately unbound and cannot authorize a receipt download.
