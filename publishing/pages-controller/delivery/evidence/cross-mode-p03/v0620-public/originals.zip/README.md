# v0.62.0 main public audit — cache preparation, not executed

This packet adapts the accepted v0.61.24 audit helpers for the scoped Couch/Team entry and continuation release. It does not accept P03, P05, the whole game, offline operation or a physical device. Root owns publisher binding, all API/HTTP/browser execution and final acceptance.

## Known original identity

- Game version: `v0.62.0`; source `72b6845e101850a4ee34df66656dae3c7ad87f5f`; tree `3fda06b8a0b2efd6f500852bde42d6745b87df42`.
- Annotated tag: `8994ae79181904bd1ddc588441dc0b8a0432dff0`; published release `391889344`, timestamp `2026-09-19T02:47:42Z`.
- Expected offline build ID: `1a123d5e0c75253f68bb069577907e0ab14b97e2e37bea21436d3d76b42eb5c8`. This comes from the exact frozen `offline-cache.json`, not `game/build-info.json` (which contains version/source/entry).
- Source qualification: 144435 bytes, SHA `436cffbc13d379e0cb9e0a9f922235f8097bf905172e11ba4599a5c7aa001df8`. The retained root review reports two source-gate families, each 6094 tests in 476 files, actual Node 20.19.6. Those source suites were not rerun here.
- `frozen-asset-expectations.json` retains all nine exact uploaded asset descriptors and build/manifest rows. Source tar, distribution ZIP and qualification-evidence ZIP have not been copied or downloaded here. Small copied originals retain their exact hashes in `original-copy-pins.json`.

The actual publisher commit/tree/PR, main Pages run/attempt, deployment/status, small receipt artifact and complete deployed inventory remain **null and unbound**. Neither accepted624 inventory counts nor a preview inventory may be substituted. There is no active capacity runner, reviewed request, inputs directory or production binding.

## Adaptation and preserved authority

Fourteen donor helpers are retained in `helper-originals/`. Nine candidate helpers are byte-identical. Five change only game version/source/tree, exact accepted predecessor catalog SHA, or matching test values. `adaptation.diff`, `helper-pins.json` and `identity-normalization-proof.json` expose all differences. HTTP transport, MIME policy, byte/path caps, before/after authority checks, retry rules, intake and refresh semantics are unchanged.

`tools/retained-catalog.json` is the exact accepted624 catalog: **95 authorities**, SHA `ac103017db3fa9a7897fc1d61702fa5e14f4206f7103ee260cf370e9c9beb34a`. Accepted controller `fecf205fc79d2e7edea1916444f3219d29c656ed`, tree `ee8caf5c71e162fc8dc354b7e3c37a2b9ef7c605`. All nine predecessor authority pins and five accepted evidence pins were checked locally. Their historic 3280-file/643266110-byte result is not the new inventory.

Retain every prior catalog field exactly, plus the new620 entry. Root should require exactly 96 semantic catalog authorities for this isolated append; the inherited validator permits additional valid entries, so any concurrent addition needs an explicit separate review. Retained semantic authorities are not a claim that all historical HTTP payloads on main remain byte-identical: main contains frozen routes and archive bridges. Archive29's accepted append preserves 701 old rows (699 v623 files and two support files), changes only the root index and adds 699 v624 files. Its accepted authority is external to this main audit; see `predecessor/archive29-root-adoption.json` and root's sealed final admission. No second archive audit or native acceptance is inferred.

## Root binding and execution sequence

`commands.pending.json` contains argument templates only. Their placeholders are deliberately invalid. Before running any command, review and retain fresh actual originals, preserve this preparation, and write separately named reviewed successors.

1. For optional preview observation, bind actual PR/head/tree/base/attempt/worktree and original pins. At most three bounded observations, with at least 60 seconds between unchanged states. Preview success does not establish main deployment.
2. After publisher merge and actual Pages success, retain current-main ref/commit, run/jobs/artifacts, deployment and latest successful status. The observer refuses a main/head/tree mismatch. Do not dispatch a second run through this harness.
3. Retain a fresh stable/Latest release readback and exact ref/tag/source originals. Compare all nine IDs, names, lengths, digests, states and canonical download URLs with `frozen-asset-expectations.json`. Require the new qualification hash above. The current root readback is prior known identity, not an indefinitely fresh authority.
4. Bind the small `frozen-pages-receipts` artifact only. Its exact artifact ID, size/digest, run/head, request SHA and runner `DOWNLOAD` argv must agree. Copy the unbound runner to `run-capacity-bounded-intake.py`, replace only the artifact ID and zero request SHA, review the exact diff, and repin it. Never invoke intake directly, use a preview receipt, or download the large Pages artifact.
5. Review all nine assembled authority originals before promoting `binding.unreviewed.json` to a separately reviewed `binding.json`. Verify source/publisher separation, exact catalog append, tag, unchanged all-history policy, empty comparison routes, archive29 append admission/routing, root/canonical build/manifest rows, and the complete inventory. Actual counts and inventory hash come from this hosted receipt only. The root and canonical `offline-cache.json` must match the retained exact manifest row/build ID.
6. Run local `--check` first; it makes no HTTP request. Then run the full audit **without `--critical`**. A critical-only result is partial. Stream/discard bodies and retain every result and attempt.
7. Run `review-public.py` after full completion. Retain a new post-HTTP hosted observation and bind report/row-review/binding/observation/published-release originals in the reviewed refresh request. Refresh checks Latest/tag/source/assets and latest deployment after full byte verification. Preserve original failures instead of relabelling them.
8. Root separately verifies affected public Couch/Team entry, lobbies, explicit Back/Resume and solo regression, and records scoped acceptance. Full HTTP success does not prove native gameplay, saves, offline operation or physical controllers/touch.

## Limits and inherited caveats

Preparation is capped at 10 MiB, with 512 MiB free reserve. Execution retains the donor's cumulative 32 MiB cache cap, 8 MiB per observation, metadata subprocess timeout 35 seconds and retained stream size strictly below 2000000 bytes. The small receipt is below 10485760 compressed bytes, one GET with a 60-second timeout; the capacity adapter checks expanded copies plus 20 MiB future allowance before extraction. Root must preflight cumulative capacity plus the 512 MiB reserve before execution. All output attempts are exclusive and earlier evidence is preserved.

The inherited capacity wrapper matches the exact download argv. A mismatched bound artifact ID can bypass that particular expansion hook before a later rejection; matching artifact ID/request SHA/argv is mandatory. The initial download is not stream-capped by the wrapper. API `capture_output` size checks happen after capture and are not streaming memory bounds. These are retained donor limitations, not strengthened guarantees.

Full HTTP caps remain 20000 rows, 950000000 total inventory bytes, 800000000 bytes per row, eight streams, 300 seconds per request and at most three transient attempts. Wrong bytes, MIME, redirect or nontransient failures do not receive endless retries. Bodies are discarded after hashing. Node HTTP evidence is not a browser/network-play or MIME-safety certification.

## Verification and remaining work

Nine mock-only Python wrapper tests passed. Self-check, catalog-cohort and all-history-policy checks passed on local Node 20.19.5 and 22.22.2. Python helper ASTs parsed; identity-normalized donor/candidate bytes are identical. These tests create temporary synthetic fixtures, not publication bindings. They made no API or real network requests. See `tests/report.json` and raw outputs.

Fresh publisher identities, original receipt, reviewed execution bindings, complete HTTP audit, post-audit refresh and affected public native journeys remain required. This packet is preparation only. No Git/index/worktree/source changes, release writes, API calls, browser work or public audit occurred here.
