# Actual main intake proposal — not activated

Fresh originals validate main `4eb25587c566346204e6bb1d58a182acc0414872`, tree `709005c7064dc93e06a0bc19b72a33c0e3e73438`, successful push run35418079281 attempt1, deployment6536550091 and latest success18552042808. The tree equals the reviewed PR head tree; the main commit is separate.

`intake-request.proposed.json` uses the exact small receipt artifact10576795144,155026bytes,SHA6bef486a4fbc7d0a41e88d347743cd831443c6529801a88d927c3b74370b75dc. Its retained observation record and every original member were verified by the unchanged pure contract. The fresh published release original (20043bytes,SHA db1e26f16914fcadc72e8476a9bc2c9657ee907780218b23914ca40fb7fb91be) was copied byte-for-byte inside the audit cache. Stable/Latest release391889344, exact source target, fresh tag ref and all nine descriptor projections agree with the frozen expectations.

The request remains `reviewed:false`. The runner proposal changes only the artifact ID and retains its zero request SHA. No active runner or reviewed request was written; neither download nor intake was called. Inventory rows/bytes/hash remain unknown until actual receipt extraction and authority review. The large github-pages artifact is excluded.

Root activation steps:

1. Review this exact request, fresh originals, the parent helper review and source/PR integration checklist. Preserve current pending/unbound originals. Check remaining cumulative32MiB allowance and512MiB free reserve.
2. Copy the proposal to the **audit cache root** as `intake-request.reviewed.json`, only after approval changing `reviewed` to true. Hash the actual final bytes. If only that boolean changes with identical encoding, the expected hash is `748e31754e1bfc04d2f920dfe843e78db5894be629329dc2b28715c7de631740`; recompute rather than trusting the prediction.
3. Copy the unbound runner to **audit cache root** `run-capacity-bounded-intake.py`. Bind DOWNLOAD to artifact10576795144 and its zero request hash to the actual reviewed request SHA. Review these two exact substitutions together and pin the active successor. Do not execute the proposal from this subdirectory (HOME intentionally would differ), and do not invoke intake directly.
4. Run the capacity-wrapped one-time small receipt intake. Root reviews the nine assembled authority originals and the complete actual inventory before promoting `binding.unreviewed.json`. Then perform local `--check`, full HTTP without `--critical`, row reconciliation, fresh post-HTTP authorities and separately scoped native acceptance.

Existing helper transport/capture limitations are unchanged; this proposal is not a new security approval. No network/API/browser/Git/source mutation occurred here. The only writes are this new proposal directory; existing pending/unbound files and prior packets remain intact.
