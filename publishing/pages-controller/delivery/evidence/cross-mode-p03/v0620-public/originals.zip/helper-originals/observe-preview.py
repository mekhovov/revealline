from pathlib import Path
import subprocess,json,hashlib,concurrent.futures,sys,datetime,re,shutil,threading
R=Path.cwd();home=Path(__file__).resolve().parent;label=sys.argv[1];assert re.fullmatch(r'[a-z0-9-]{1,40}',label)
identity_path=Path(sys.argv[2]);assert identity_path.is_absolute() and identity_path.is_relative_to(home) and identity_path.is_file() and not any(p.is_symlink() for p in [identity_path,*identity_path.parents])
binding=json.loads(identity_path.read_bytes());assert binding['status']=='ROOT_SUPPLIED_ACTUAL_PREVIEW_IDENTITY' and binding['executionAuthorized'] is True
head,tree,base,pr=binding['head'],binding['tree'],binding['base'],binding['pullRequest']
assert all(isinstance(x,str) and re.fullmatch(r'[0-9a-f]{40}',x) for x in [head,tree,base]) and type(pr)is int and pr>0
assert binding['repository']=='mekhovov/revealline' and binding['workflow']=='.github/workflows/publish-frozen-pages.yml' and binding['attempt']==1
assert 0<len(binding['originalPins'])<=20
for row in binding['originalPins']:
 p=Path(row['path']);assert p.is_absolute() and p.is_file() and not any(q.is_symlink()for q in [p,*p.parents]);raw=p.read_bytes();assert len(raw)==row['bytes']<2_000_000 and hashlib.sha256(raw).hexdigest()==row['sha256']
worktree=Path(binding['worktree']);assert worktree.is_absolute() and worktree.is_relative_to(R/'.cache/worktrees') and worktree.is_dir() and not any(p.is_symlink() for p in [worktree,*worktree.parents])
admin=Path(subprocess.check_output(['git','-C',str(worktree),'rev-parse','--absolute-git-dir'],text=True).strip())
write_lock=threading.Lock()
def put(path,raw):
 with write_lock:
  assert path.is_relative_to(home) and not path.exists() and not any(p.is_symlink()for p in [path,*path.parents])
  used=sum(p.stat().st_size for root in [home,worktree,admin]for p in root.rglob('*')if p.is_file()and not p.is_symlink())
  assert used+len(raw)+65536<=32*1024**2 and shutil.disk_usage(R).free>=512*1024**2+len(raw)+65536
  assert sum(p.stat().st_size for p in home.rglob('*')if p.is_file())+len(raw)<=8*1024**2
  with path.open('xb')as f:f.write(raw)
assert shutil.disk_usage(R).free>512*1024**2+8*1024**2
out=home/('preview-'+label);out.mkdir()

def get(pair,parse_json=True):
 n,s=pair
 command=['gh','api','--method','GET','repos/mekhovov/revealline/'+s]
 timeout=False
 failure=None
 try:
  r=subprocess.run(command,capture_output=True,timeout=35)
  stdout,stderr,returncode=r.stdout,r.stderr,r.returncode
 except subprocess.TimeoutExpired as error:
  timeout=True
  failure=error
  stdout,stderr,returncode=error.output,error.stderr,None
 # Keep the existing strict <2,000,000-byte response limit. Retention is
 # bounded too; timeout bytes are only the captured prefix, never a full reply.
 streams={}
 for name,raw in [('stdout',stdout),('stderr',stderr)]:
  available=raw is not None
  if available and not isinstance(raw,bytes):
   raise TypeError('Expected binary subprocess output; no text conversion allowed')
  captured=raw if available else b''
  truncated=len(captured)>=2_000_000
  kept=captured[:1_999_999]
  complete=available and not timeout and not truncated
  suffix=(('.json' if parse_json else '.log') if name=='stdout' else '.stderr') if complete else '.'+name+'.partial'
  destination=out/(n+suffix)
  put(destination,kept)
  streams[name]={
   'path':destination.name,'captureAvailable':available,
   'capturedBytes':len(captured) if available else None,
   'capturedSha256':hashlib.sha256(captured).hexdigest() if available else None,
   'retainedBytes':len(kept),'retainedSha256':hashlib.sha256(kept).hexdigest(),
   'completeCapture':available and not timeout,'completeOriginalRetained':complete,
   'retentionTruncated':truncated,
   'scope':'Complete subprocess stream' if available and not timeout else
           'Only subprocess bytes available at timeout; final stream size and hash are unknown'
  }
 reasons=[]
 if timeout:reasons.append('subprocess-timeout')
 if streams['stdout']['retentionTruncated']:reasons.append('stdout-size-limit')
 if streams['stderr']['retentionTruncated']:reasons.append('stderr-size-limit')
 if not timeout and returncode!=0:reasons.append('nonzero-exit')
 value=None
 if not reasons:
  try:value=json.loads(stdout) if parse_json else stdout
  except (UnicodeDecodeError,json.JSONDecodeError) as error:
   failure=error
   reasons.append('invalid-json')
 receipt={
  'format':'revealline-bounded-api-attempt.v1','requestName':n,'command':command,
  'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'status':'FAIL' if reasons else 'COMPLETE_API_RESPONSE',
  'returnCode':returncode,'timedOut':timeout,'timeoutSeconds':35,
  'acceptedStreamBytesLessThan':2_000_000,'streams':streams,
  'failures':reasons,'usableJson':not reasons,'attempts':1,
  'publicationAcceptance':False
 }
 receipt_path=out/(n+'.attempt.json')
 put(receipt_path,(json.dumps(receipt,indent=2)+'\n').encode())
 if reasons:
  raise RuntimeError(n+': '+', '.join(reasons)+'; retained '+str(receipt_path)) from failure
 return n,value

queries={'pull':f'pulls/{pr}','runs':f'actions/workflows/publish-frozen-pages.yml/runs?event=pull_request&head_sha={head}&per_page=10'}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:result=dict(pool.map(get,queries.items()))
assert result['pull']['head']['sha']==head and result['pull']['base']['sha']==base and result['pull']['number']==pr
runs=[r for r in result['runs']['workflow_runs'] if r['head_sha']==head and r['event']=='pull_request' and r['path']=='.github/workflows/publish-frozen-pages.yml']
assert len(runs)==1,[(r['id'],r['head_sha'])for r in runs]
run=runs[0];rqueries={'run':f"actions/runs/{run['id']}",'jobs':f"actions/runs/{run['id']}/jobs",'commit':f'git/commits/{head}','checks':f'commits/{head}/check-runs?per_page=30'}
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:result.update(dict(pool.map(get,rqueries.items())))
assert result['commit']['tree']['sha']==tree and result['run']['head_sha']==head
assert result['run']['id']==run['id'] and result['run']['run_attempt']==binding['attempt'] and result['run']['event']=='pull_request' and result['run']['path']==binding['workflow']
assert result['jobs']['total_count']==len(result['jobs']['jobs'])<=4
assert all(j['run_id']==run['id'] and j['head_sha']==head and j['run_attempt']==binding['attempt'] for j in result['jobs']['jobs'])
terminal=result['run']['status']=='completed'
logs=[]
if terminal:
 result.update([get(('artifacts',f"actions/runs/{run['id']}/artifacts"))])
 for j in result['jobs']['jobs']:
  if j['conclusion']=='skipped':continue
  name,raw=get((str(j['id']),f"actions/jobs/{j['id']}/logs"),parse_json=False)
  logs.append({'jobId':j['id'],'log':name+'.log','attemptReceipt':name+'.attempt.json','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'attempts':1})

pins=[]
for p in sorted(out.iterdir()):
 b=p.read_bytes();pins.append({'path':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
record={'status':'TERMINAL_PREVIEW_OBSERVED'if terminal else'PREVIEW_IN_PROGRESS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tree':tree,'base':base,'pullRequest':pr,'runId':run['id'],'attempt':binding['attempt'],'identityBinding':{'path':str(identity_path),'bytes':identity_path.stat().st_size,'sha256':hashlib.sha256(identity_path.read_bytes()).hexdigest()},'conclusion':result['run']['conclusion'],'jobs':[{k:j[k]for k in ['id','name','status','conclusion']}for j in result['jobs']['jobs']],'pins':pins,'logs':logs,'publicAccepted':False};put(out/'record.json',(json.dumps(record,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in record.items()if k not in ['pins','logs']},indent=2))
