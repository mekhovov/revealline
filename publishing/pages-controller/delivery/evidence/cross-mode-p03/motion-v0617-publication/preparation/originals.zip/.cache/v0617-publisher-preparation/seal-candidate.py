from helpers import *
import datetime,re,difflib
F=D/'delivery/evidence/cross-mode-p03/motion-v0617-publication';E=D/'evidence/archive-25/append-v0616'
for n in ['node20','node22']:
 text=(P/'checks-r1'/(n+'.stdout')).read_text();assert '# tests 43' in text and '# pass 43' in text and '# fail 0' in text
assert 'Ran 4 tests' in (P/'checks-r1/python.stderr').read_text() and '\nOK\n' in (P/'checks-r1/python.stderr').read_text()
assert all(r['exit']==0 for r in json.loads((P/'checks-r1/results.json').read_bytes()))
for n in ['sync','sync-r2','verify-local-candidate','diff-check']:assert json.loads((P/(n+'.receipt.json')).read_bytes())['exit']==0
assert json.loads((P/'prior-preservation.json').read_bytes())['status']=='PASS_ALL_PRIOR_CATALOG_AND_ARCHIVE_ORIGINALS_PRESERVED'
# Pin a finite preparation selection, excluding the forthcoming manifest/ready cycle.
selection=[p for p in (P/'checks-r1').rglob('*')if p.is_file()and 'tmp'not in p.parts]
for n in ['baseline.json','selected-paths-estimate.json','sparse-paths.txt','sparse-config-before-hydration.json','root-before-finalization.json','helpers.py','finalize-candidate.py','archive-adoption.json','sync-predecessor.mjs','sync-first-adapter.mjs','sync-published-originals.mjs','sync-adaptation.diff','sync.stdout','sync.stderr','sync.receipt.json','sync-r2.stdout','sync-r2.stderr','sync-r2.receipt.json','metadata-sync-ready.json','run-checks.py','run-local.py','verify-local-candidate.mjs','verify-local-candidate.stdout','verify-local-candidate.stderr','verify-local-candidate.receipt.json','diff-check.stdout','diff-check.stderr','diff-check.receipt.json','verify-preservation.py','prior-preservation.json','documentation-preparation.json','seal-candidate.py']:selection.append(P/n)
bundle(F/'preparation',selection)
tracked=subprocess.check_output(['git','-C',str(W),'diff','--name-only'],text=True).splitlines();assert set(tracked)=={'.cursor/skills/deploy-release-pages/SKILL.md','publishing/pages-controller/README.md','publishing/pages-controller/delivery/README.md','publishing/pages-controller/allocations.json','publishing/pages-controller/catalog.json','publishing/pages-controller/publication.json'}
newroots=[E,F,D/'metadata/v0.61.7',D/'evidence/current-v0617'];newfiles=[p for root in newroots for p in root.rglob('*')if p.is_file()];files=sorted(set([W/n for n in tracked]+newfiles))
for p in files:
 assert not p.is_symlink()and p.stat().st_size<8*1024**2
 if p.suffix=='.json':json.loads(p.read_bytes())
# Verify every archive/native/preparation original and byte count from its ZIP.
bundles=[]
for dest in [E,F,F/'preparation']:
 idx=json.loads((dest/'originals-index.json').read_bytes());raw=(dest/'originals.zip').read_bytes();assert len(raw)==idx['zip']['bytes']and sha(raw)==idx['zip']['sha256']
 with zipfile.ZipFile(io.BytesIO(raw))as z:
  assert z.testzip()is None and len(z.infolist())==len(idx['files'])
  for row in idx['files']:
   b=z.read(row['path']);assert len(b)==row['bytes']and sha(b)==row['sha256']and (R/row['path']).read_bytes()==b
 bundles.append({'path':str(dest.relative_to(W)),'members':len(idx['files']),'bytes':len(raw),'sha256':sha(raw)})
# Check new prose and changed landing summaries against actual or Git-held link targets.
links=0
for p in [E/'README.md',F/'README.md',F/'planning/progress-and-next.md',D/'evidence/current-v0617/README.md',D/'README.md',D/'delivery/README.md',W/'.cursor/skills/deploy-release-pages/SKILL.md']:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if ':'in target or target.startswith('#'):continue
  target=target.split('#')[0]
  if not target:continue
  dest=(p.parent/target).resolve();rel=dest.relative_to(W).as_posix()
  if not dest.exists():assert subprocess.run(['git','-C',str(W),'cat-file','-e',base+':'+rel],capture_output=True).returncode==0,(p,target)
  links+=1
before=json.loads((P/'root-before-finalization.json').read_bytes());assert sha((admin/'index').read_bytes())==before['worktreeIndexSha256'];assert sha((R/'.git/index').read_bytes())==before['indexSha256'];assert sha((R/'.git/config').read_bytes())==before['commonConfig'];assert subprocess.check_output(['git','status','--porcelain','-z']).hex()==before['status']
# Preserve catalog entries, allocation order, and every unrelated admission.
oldpub=json.loads(subprocess.check_output(['git','-C',str(W),'show',base+':publishing/pages-controller/publication.json']));pub=json.loads((D/'publication.json').read_bytes());oldcat=json.loads((P/'catalog-before-sync.json').read_bytes());cat=json.loads((D/'catalog.json').read_bytes());assert len(cat['releases'])==88 and cat['releases'][:-1]==oldcat['releases'];assert len(pub['admissions'])==25 and [x for x in pub['admissions']if x['id']!='archive-25']==[x for x in oldpub['admissions']if x['id']!='archive-25']
rows=[pin(p,W)for p in files];obj(P/'candidate-pins.json',{'format':'revealline-reviewed-candidate-paths.v1','base':base,'worktree':str(W),'files':rows,'totalBytes':sum(r['bytes']for r in rows),'indexUnchanged':True,'stageOrCommitPerformed':False})
obj(P/'original-bundles-check.json',{'status':'PASS_ALL_ZIP_CRC_ROWS_CURRENT_ORIGINALS','bundles':bundles,'relativeLinksResolved':links,'rootStatusIndexAndConfigUnchanged':True,'nativeArchiveRawJPEGPinsPreserved':True,'sourceNativeScreenshotsRemainInlineOnly':True})
trackedpatch=subprocess.check_output(['git','-C',str(W),'diff','--no-ext-diff','--unified=5']);put(P/'reviewed-hunks.diff',trackedpatch)
newpatch=''
for p in sorted(newfiles):
 if p.suffix=='.zip':continue
 newpatch+=''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile=p.relative_to(W).as_posix()))
put(P/'new-text-paths.diff',newpatch);put(P/'status-before-review.txt',subprocess.check_output(['git','-C',str(W),'status','--porcelain','--untracked-files=all']))
put(P/'pr-body.md','''Select published v0.61.7 for Motion Lab rotation focus, pinned to qualified source `b3262eb02a998c50354758ba922324d023138875`. Its correction preserves the focused field, value and paused preview when the settings panel leaves the viewport. Keep the known right-edge outline limitation and public native verification gate explicit.

Admit the accepted Archive25 append retaining v0.61.5 and v0.61.6 at infrastructure `dff3007d35edb7a1b528884f673219d0e6b8d7d6`: all 1,398 files / 626,758,906 bytes passed, with 699 old rows unchanged and only the root index replaced. Preserve all 87 existing catalog entries, the 24 other admissions and all old archive evidence. Native retention is scoped to mixed keyboard/pointer, reward-free practice in both editions; no main-campaign, durable-save or physical-device claim is added.

Validation: 43 publisher tests on each of Node 20.19.5 and Node 22.22.2, four Python tests, all 88 metadata chains, the exact current qualification and changed archive admission. Rehashed 922 prior bodies without hydrating old evidence; ZIP CRC/member hashes and documentation links pass. All nine original asset identities match draft/published/Latest; small metadata were reused without downloads. Add narrow deployment guidance distinguishing canonical published URLs from immutable asset identity and testing preservation counts in both serialized outputs.

No game/version, frozen payload or publisher runtime helper changes. v0.61.6 remains the accepted public baseline until hosted preview/assembly, Pages deployment, complete public byte verification and the shipped Motion Lab journey pass. Parent phases remain open.
''')
used=sum(q.stat().st_size for d in [W,P,admin]for q in d.rglob('*')if q.is_file()and not q.is_symlink());assert used<32*1024**2 and shutil.disk_usage(R).free>512*1024**2
ready={'status':'READY_FOR_ROOT_HUNK_REVIEW_NOT_STAGED','preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':'codex/v0617-pages-preparation','base':base,'baseTree':json.loads((P/'baseline.json').read_bytes())['baseTree'],'worktree':str(W),'manifest':pin(P/'candidate-pins.json',R),'trackedHunks':pin(P/'reviewed-hunks.diff',R),'newTextPaths':pin(P/'new-text-paths.diff',R),'prBody':pin(P/'pr-body.md',R),'source':{'version':'v0.61.7','commit':'b3262eb02a998c50354758ba922324d023138875','tree':'0f4815e7c4116aeb08bee9696828f143a1ef5479','tagObject':'015093327ac5f465c51cd69074388b4010497156','releaseId':391486325,'qualificationSha256':'b7cee153302a8702071cb80fe463ab39ad458cd284771dd8a1d601a9f4955c15'},'archive25':{'commit':'dff3007d35edb7a1b528884f673219d0e6b8d7d6','tree':'1d1260e806244f0e4ce1d1bc02acc0d6328e5004','deploymentId':6525128114,'versions':['v0.61.5','v0.61.6'],'files':1398,'bytes':626758906,'unchangedPriorRows':699,'priorReleaseRows':697,'priorSupportRows':2,'changedPriorPaths':['index.html'],'newRows':698},'checks':{'node20':43,'node22':43,'python':4,'metadataChains':88,'currentSourceAndChangedAdmission':True,'priorBodiesRehashed':922,'diffCheck':True,'indexUntouched':True},'preservation':pin(P/'prior-preservation.json',R),'originalBundles':pin(P/'original-bundles-check.json',R),'candidatePaths':len(rows),'candidateBytes':sum(r['bytes']for r in rows),'priorCatalogRecordsPreserved':87,'otherAdmissionsPreserved':24,'totalAdmissions':25,'acceptedPublicBaseline':'v0.61.6','v617PagesAccepted':False,'stageOrCommitPerformed':False,'remoteMutationPerformed':False,'bodyGETs':0,'gameVersionOrPublisherHelperChanges':False,'skillChanged':True,'managedBytesBeforeReady':used,'managedCapBytes':32*1024**2,'freeBytes':shutil.disk_usage(R).free,'reserveBytes':512*1024**2,'remaining':['Root exact hunk/index review, commit and publisher PR.','Hosted full original-ZIP publisher assembly and protected deployment.','Complete public byte audit and actual shipped Motion Lab focus/rotation check.','Keep right-edge outline, keyboard-only/Plain/physical/offline and whole-phase limits open.']};obj(P/'ready.json',ready);print(json.dumps({'ready':pin(P/'ready.json',R),'manifest':pin(P/'candidate-pins.json',R),'paths':len(rows),'candidateBytes':ready['candidateBytes'],'managedBytes':used,'bundles':bundles},indent=2))
