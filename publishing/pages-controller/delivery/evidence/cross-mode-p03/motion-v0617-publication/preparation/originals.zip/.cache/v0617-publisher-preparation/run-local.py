from helpers import *
import time,sys
label=sys.argv[1];cmd=sys.argv[2:];start=time.time();assert len(cmd)>0
with (P/(label+'.stdout')).open('xb') as out,(P/(label+'.stderr')).open('xb') as err:
 p=subprocess.run(cmd,cwd=W,stdout=out,stderr=err,timeout=120)
obj(P/(label+'.receipt.json'),{'command':cmd,'cwd':str(W),'exit':p.returncode,'elapsedSeconds':round(time.time()-start,3)})
print((P/(label+'.stdout')).read_text()[-2500:]);print((P/(label+'.stderr')).read_text()[-1500:]);assert p.returncode==0
