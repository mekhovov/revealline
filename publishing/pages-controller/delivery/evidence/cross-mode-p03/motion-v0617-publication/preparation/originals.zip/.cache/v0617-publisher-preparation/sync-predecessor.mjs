import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { syncReleaseMetadata } from '../worktrees/v0616-publisher-preparation/publishing/pages-controller/sync-release-metadata.mjs';
const sha = b => createHash('sha256').update(b).digest('hex');
const read = async name => JSON.parse(await fs.readFile(new URL('../v0616-release-preparation/root-publish-r1/' + name, import.meta.url)));
const publication = await read('after-release.json');
const latest = await read('after-latest.json');
const before = await read('before-release.json');
const reviewed = await read('completion.json');
const tag = await read('before-tag.json');
const tagObject = await read('before-tag-object.json');
const source = '4fd8e2dac4fdc851d0d2bf0b21e77162d9d405c9';
if (publication.id !== 391439978 || latest.id !== publication.id || publication.tag_name !== 'v0.61.6' || latest.tag_name !== publication.tag_name || publication.draft || publication.prerelease || latest.draft || latest.prerelease || reviewed.status !== 'IMMUTABLE_RELEASE_PUBLISHED_LATEST_VERIFIED' || reviewed.source.commit !== source) throw Error('Publication not bound');
if (tag.object.sha !== 'e8c11ea668e40028e650eec42bdd004f3f7e607c' || tag.object.type !== 'tag' || tagObject.sha !== tag.object.sha || tagObject.object.sha !== source || tagObject.object.type !== 'commit') throw Error('Tag identity differs');
const reconciliation = JSON.parse(await fs.readFile(new URL('../v0616-upload-receipt-preparation/reconciliation/v0.61.6-reconciliation.json', import.meta.url)));
if (reconciliation.source.commit !== source || reconciliation.source.tree !== 'd16edac0127fc96139445ae2365cc74499f80921' || reconciliation.status !== 'INDEPENDENT_LOCAL_RECEIPT_RECONCILIATION_PASS') throw Error('Reconciliation differs');
const fields = a => ({ id: a.id, name: a.name, size: a.size, digest: a.digest, state: a.state });
const sorted = xs => xs.map(fields).sort((a, b) => a.name.localeCompare(b.name));
const assets = sorted(publication.assets);
if (assets.length !== 9 || new Set(assets.map(a => a.name)).size !== 9 || !assets.every(a => a.state === 'uploaded')) throw Error('Expected exactly nine uploaded assets');
for (const previous of [before.assets, latest.assets, reconciliation.allNineHostedAssets]) {
  if (JSON.stringify(sorted(previous)) !== JSON.stringify(assets)) throw Error('Original asset identities changed');
}
const result = await syncReleaseMetadata({ versions: ['v0.61.6'], qualificationVersion: 'v0.61.6', download: async (version, name) => {
  if (version !== 'v0.61.6' || !['release.json', 'manifest.json', 'distribution.zip.sha256', 'source-qualification.json'].includes(name)) throw Error('Unexpected metadata');
  const raw = await fs.readFile(new URL('../v0616-upload-receipt-preparation/root-small-intake-r1/evidence/reviewed-small-assets/' + name, import.meta.url));
  const a = assets.find(a => a.name === name);
  if (!a || a.size !== raw.length || a.digest !== 'sha256:' + sha(raw)) throw Error('Published original mismatch: ' + name);
  return raw;
}});
console.log(JSON.stringify({ ...result, publishedReleaseId: publication.id, allNineOriginalAssetIdentitiesPreserved: true, source, downloadedAgain: false, origin: 'Retained original small assets matched against draft, published, Latest and root reconciliation descriptors; mutable URL differences are not asset-byte identities' }, null, 2));
