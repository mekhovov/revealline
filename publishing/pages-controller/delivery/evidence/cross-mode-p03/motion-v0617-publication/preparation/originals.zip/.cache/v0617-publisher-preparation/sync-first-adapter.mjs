import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { syncReleaseMetadata } from '../worktrees/v0617-publisher-preparation/publishing/pages-controller/sync-release-metadata.mjs';
const sha = b => createHash('sha256').update(b).digest('hex');
const read = async name => JSON.parse(await fs.readFile(new URL('../v0617-release-preparation/root-publish-r1/' + name, import.meta.url)));
const publication = await read('after-release.json');
const latest = await read('after-latest.json');
const before = await read('before-release.json');
const reviewed = await read('completion.json');
const tag = await read('before-tag.json');
const tagObject = await read('before-tag-object.json');
const source = 'b3262eb02a998c50354758ba922324d023138875';
if (publication.id !== 391486325 || latest.id !== publication.id || publication.tag_name !== 'v0.61.7' || latest.tag_name !== publication.tag_name || publication.draft || publication.prerelease || latest.draft || latest.prerelease || reviewed.status !== 'PUBLISHED_ORIGINALS_LATEST_READBACK_PASS' || reviewed.source !== source) throw Error('Publication not bound');
if (tag.object.sha !== '015093327ac5f465c51cd69074388b4010497156' || tag.object.type !== 'tag' || tagObject.sha !== tag.object.sha || tagObject.object.sha !== source || tagObject.object.type !== 'commit') throw Error('Tag identity differs');
const reconciliation = JSON.parse(await fs.readFile(new URL('../v0617-upload-receipt-preparation/reconciliation/v0.61.7-reconciliation.json', import.meta.url)));
if (reconciliation.source.commit !== source || reconciliation.source.tree !== '0f4815e7c4116aeb08bee9696828f143a1ef5479' || reconciliation.status !== 'INDEPENDENT_LOCAL_RECEIPT_RECONCILIATION_PASS') throw Error('Reconciliation differs');
const fields = a => ({ id: a.id, name: a.name, size: a.size, digest: a.digest, state: a.state });
const sorted = xs => xs.map(fields).sort((a, b) => a.name.localeCompare(b.name));
const assets = sorted(publication.assets);
if (assets.length !== 9 || new Set(assets.map(a => a.name)).size !== 9 || !assets.every(a => a.state === 'uploaded')) throw Error('Expected exactly nine uploaded assets');
for (const previous of [before.assets, latest.assets, reconciliation.allNineHostedAssets]) {
  if (JSON.stringify(sorted(previous)) !== JSON.stringify(assets)) throw Error('Original asset identities changed');
}
const result = await syncReleaseMetadata({ versions: ['v0.61.7'], qualificationVersion: 'v0.61.7', download: async (version, name) => {
  if (version !== 'v0.61.7' || !['release.json', 'manifest.json', 'distribution.zip.sha256', 'source-qualification.json'].includes(name)) throw Error('Unexpected metadata');
  const raw = await fs.readFile(new URL('../v0617-upload-receipt-preparation/root-small-intake-r1/evidence/reviewed-small-assets/' + name, import.meta.url));
  const a = assets.find(a => a.name === name);
  if (!a || a.size !== raw.length || a.digest !== 'sha256:' + sha(raw)) throw Error('Published original mismatch: ' + name);
  return raw;
}});
console.log(JSON.stringify({ ...result, publishedReleaseId: publication.id, allNineOriginalAssetIdentitiesPreserved: true, source, downloadedAgain: false, origin: 'Retained original small assets matched against draft, published, Latest and root reconciliation descriptors; mutable URL differences are not asset-byte identities' }, null, 2));
