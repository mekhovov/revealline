from pathlib import Path
import subprocess,json,hashlib,datetime,shutil,concurrent.futures,sys,threading,re
A=Path(__file__).resolve().parent;R=Path.cwd();O=A/'hosted-observation-production-r3';D=A/'terminal-details-r1';assert shutil.disk_usage(R).free>512*1024**2+8*1024**2
read=lambda p:json.loads(p.read_bytes());r=read(O/'run.json');jobs=read(O/'jobs.json')['jobs'];dep=read(O/'deployment.json');status=read(O/'statuses.json')[0]
assert r['id']==35352681143 and r['head_sha']=='acd3ee806ec861660363a1b691ec2703032484f1' and r['conclusion']=='success' and r['status']=='completed' and r['event']=='push' and r['run_attempt']==1
assert len(jobs)==2 and all(j['conclusion']=='success'for j in jobs);assert dep['id']==6525736706 and status['id']==18527088341 and status['state']=='success'
arts=[a for a in read(O/'artifacts.json')['artifacts']if a['name']=='frozen-pages-receipts'];assert len(arts)==1;expected=arts[0]
D.mkdir();lock=threading.Lock()
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,raw):
 with lock:
  assert not p.exists();used=sum(p.stat().st_size for p in A.rglob('*')if p.is_file()and not p.is_symlink());assert used+len(raw)+65536<8*1024**2;assert shutil.disk_usage(A).free>512*1024**2+len(raw)+65536
  with p.open('xb')as f:f.write(raw)
def pin(p):b=p.read_bytes();return {'path':p.relative_to(A).as_posix(),'bytes':len(b),'sha256':sha(b)}
def get(pair):
 n,path=pair;cmd=['gh','api','--method','GET','repos/mekhovov/revealline/'+path];timeout=False
 try:q=subprocess.run(cmd,capture_output=True,timeout=35);b,e,code=q.stdout,q.stderr,q.returncode
 except subprocess.TimeoutExpired as x:b,e,code=x.output or b'',x.stderr or b'',None;timeout=True
 over=len(b)>=2000000 or len(e)>=2000000
 put(D/(n+'.body'),b[:1999999]);put(D/(n+'.stderr'),e[:1999999]);put(D/(n+'.attempt.json'),(json.dumps({'command':cmd,'exit':code,'timeout':timeout,'retainedOnlyPrefix':over,'stdoutBytes':len(b),'stdoutSha256':sha(b),'stderrBytes':len(e),'attempts':1},indent=2)+'\n').encode());assert not timeout and not over and code==0;return n,b
queries={'artifact':f"actions/artifacts/{expected['id']}"};queries.update({j['name']+'-log':f"actions/jobs/{j['id']}/logs"for j in jobs})
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:replies=dict(pool.map(get,queries.items()))
a=json.loads(replies['artifact'])
for k in ['id','name','size_in_bytes','digest','expired','workflow_run']:assert a[k]==expected[k]
assert a['id']==10550811249 and a['size_in_bytes']==145766 and a['digest']=='sha256:fbf2ba14619f42c4abf55ef04d131c0ecac27a0a0a21ca6f2dd2dd406510ab73'and not a['expired']
log=replies['assemble-log'].decode();assert '# tests 43'in log and '# pass 43'in log and '# fail 0'in log and 'Ran 4 tests'in log
records=[]
for line in log.splitlines():
 m=re.match(r'^\S+Z (\{.*\})$',line)
 if m:
  try:records.append(json.loads(m.group(1)))
  except ValueError:pass
final=next(v for v in records if v.get('status')=='PASS'and'files'in v);full=next(v for v in records if v.get('files')==final['files']and'controllerTree'in v)
assert full['controllerCommit']==final['controllerCommit']==r['head_sha']and full['controllerTree']=='445341e8df86c89ac63877935fffbbc7f3837a8b';assert full['gameSourceRevision']==final['gameSourceRevision']=='b3262eb02a998c50354758ba922324d023138875' and full['qualifiedSourceTree']=='0f4815e7c4116aeb08bee9696828f143a1ef5479';assert final['publishable']is True and full['publishable']is True and full['files']==final['files']==3103 and full['totalBytes']==final['totalBytes']==641970187
q={'format':'revealline-public-intake-request.v1','reviewed':False,'outputLabel':'main-r1','currentVersion':'v0.61.7','gameSourceRevision':'b3262eb02a998c50354758ba922324d023138875','qualifiedSourceTree':'0f4815e7c4116aeb08bee9696828f143a1ef5479','controllerCommit':r['head_sha'],'controllerTree':full['controllerTree'],'runId':r['id'],'deploymentId':dep['id'],'latestSuccessStatusId':status['id'],'receiptArtifact':{'id':a['id'],'bytes':a['size_in_bytes'],'sha256':a['digest'][7:]},'hostedObservation':pin(O/'record.json'),'publishedRelease':pin(A/'source-originals/published-release.original.json')}
sys.path.insert(0,str(A));from wrapper_contract import observation,published,identity
identity(q);observation(A,q['hostedObservation'],q,q['latestSuccessStatusId']);published(A,q['publishedRelease'])
for p in read(A/'intake-helper-pins.json'):
 b=(A/p['path']).read_bytes();assert len(b)==p['bytes']and sha(b)==p['sha256']
put(A/'intake-request.proposed.json',(json.dumps(q,indent=2)+'\n').encode())
ready={'status':'ACTUAL_TERMINAL_RECEIPT_REQUEST_FOR_ROOT_REVIEW','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'proposal':pin(A/'intake-request.proposed.json'),'hostedObservation':q['hostedObservation'],'publishedRelease':q['publishedRelease'],'source':q['gameSourceRevision'],'sourceTree':q['qualifiedSourceTree'],'controller':q['controllerCommit'],'controllerTree':q['controllerTree'],'run':q['runId'],'deployment':q['deploymentId'],'statusId':q['latestSuccessStatusId'],'receiptArtifact':q['receiptArtifact'],'freshArtifactDescriptor':pin(D/'artifact.body'),'terminalLogs':[pin(D/'assemble-log.body'),pin(D/'deploy-log.body')],'helperPins':pin(A/'intake-helper-pins.json'),'adaptation':pin(A/'intake-adaptation.diff'),'offlineWrapperTests':9,'loggedAssembly':{'files':full['files'],'bytes':full['totalBytes'],'publishable':True,'independentReread':'PASS','nodeTests':43,'pythonTests':4},'scope':'One small two-JSON-member receipt ZIP and five exact-commit metadata authority reads. No source/distribution body download. Root must promote the request and bind existing runner literals before execution.','observedMainEqualsRunAndController':True,'genericObservationAndPublishedGuardsPassed':True,'artifactBodyGets':0,'publicAcceptance':False,'bytesNow':sum(p.stat().st_size for p in A.rglob('*')if p.is_file()),'metadataCapBytes':8*1024**2,'freeBytes':shutil.disk_usage(A).free,'reserveBytes':512*1024**2};put(A/'intake-ready.json',(json.dumps(ready,indent=2)+'\n').encode());print(json.dumps({'requestSha256':sha((A/'intake-request.proposed.json').read_bytes()),'readySha256':sha((A/'intake-ready.json').read_bytes()),'run':q['runId'],'deployment':q['deploymentId'],'statusId':q['latestSuccessStatusId'],'artifactBytes':a['size_in_bytes'],'cacheBytes':ready['bytesNow']},indent=2))
