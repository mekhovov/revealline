#!/usr/bin/env python3
"""R8: two explicit serialized starts on the original R7 profile; no automatic retry."""
from pathlib import Path
from urllib.parse import urlsplit
import argparse,datetime,fcntl,hashlib,json,os,socket,subprocess,time
from completion_binding import P,C,verify,raw
from completion_capacity import check
from startup_readiness import wait_for_owned_endpoint
R=P/'run';PROFILE=Path(C['profile'])
def write(p,value):
 with p.open('x') as f:f.write(json.dumps(value,indent=2)+'\n')
def gone(pid):
 try:os.kill(pid,0);return False
 except ProcessLookupError:return True

def closed(port):
 with socket.socket() as s:s.settimeout(.3);return s.connect_ex(('127.0.0.1',port))!=0

def peers():
 rows=[];projects=Path(C['sourceRoot']).parent
 for line in subprocess.check_output(['ps','-axo','pid=,command='],text=True).splitlines():
  if '/Google Chrome' not in line or '--user-data-dir=' not in line or '--type=' in line:continue
  profile=line.split('--user-data-dir=',1)[1].split(' ',1)[0]
  if profile.startswith(str(projects)+'/') and '/.cache/cross-mode/p01/' in profile:rows.append({'pid':int(line.strip().split(None,1)[0]),'profile':profile})
 return rows

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--go',action='store_true');parser.add_argument('--phase',choices=C['phases'],required=True);a=parser.parse_args();assert a.go,'Explicit reviewed root GO required'
 identity=verify();phase=R/a.phase;idx=C['phases'].index(a.phase)
 assert PROFILE==Path(C['priorRoot'])/'run/profile' and PROFILE.is_dir() and not PROFILE.is_symlink()
 assert not phase.exists(),'Phase already exists; preserve failure, no automatic retry'
 lock=(P/'serial-browser.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 proc=None;port=None
 try:
  assert not peers(),'Another task-owned P01 browser is active'
  if idx==0:
   previous=json.loads(raw(C['priorLaunchPin']));end=json.loads(raw(C['priorClosurePin']))
  else:
   previous=json.loads((R/'01-refused/launch.json').read_text());end=json.loads((R/'01-refused/exit.json').read_text())
  assert previous['profile']==str(PROFILE) and previous['identitySha256']==hashlib.sha256((P/'verified-public-identity.json').read_bytes()).hexdigest()
  assert end['pid']==previous['pid'] and end['exitCode']==0 and end['pidExited'] is True and end['endpointClosed'] is True
  assert gone(previous['pid']) and closed(previous['port']),'Previous browser is still live'
  ready=R/'refusal-proxy-ready.json';proxy=json.loads(ready.read_text());u=urlsplit(proxy['proxy'])
  assert u.scheme=='http' and u.hostname==proxy['host']=='127.0.0.1' and u.port==proxy['port'] and not u.username and not u.password and u.path in ['', '/']
  assert proxy['events']==str(R/'refusal-events.jsonl') and proxy['maxEvents']==1000 and proxy['upstreamConnections']=='none-by-construction'
  if idx==0:
   assert not gone(proxy['pid']) and not closed(proxy['port']),'New owned refusal proxy absent'
   proxy_command=subprocess.check_output(['ps','-p',str(proxy['pid']),'-o','command='],text=True)
   assert all(x in proxy_command for x in [str(P/'refusal_proxy.py'),str(ready),str(R/'refusal-events.jsonl')]),'Proxy ownership differs'
  else:
   assert gone(proxy['pid']) and closed(proxy['port']),'Close the owned refusal proxy before restored phase'
   proxy_command=None
   lines=(R/'refusal-events.jsonl').read_text().splitlines();assert lines and json.loads(lines[-1])['event']=='stopped','Proxy stopped original missing'
  capacity=check('before-'+a.phase,identity)
  assert not (R/'profile').exists(),'R8 must not copy or reset the genuine external profile'
  phase.mkdir(parents=True)
  base=json.loads(raw(C['priorLaunchPin']))['arguments']
  argv=[x for x in base if not x.startswith('--proxy-server=') and x not in ['--proxy-bypass-list=<-loopback>','--no-proxy-server','about:blank']]
  assert argv[0]=='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' and argv.count('--remote-debugging-port=0')==1 and argv.count('--user-data-dir='+str(PROFILE))==1 and '--disable-quic' in argv
  assert sum(x.startswith('--user-data-dir=') for x in argv)==1
  argv+=['--proxy-server='+proxy['proxy'],'--proxy-bypass-list=<-loopback>'] if idx==0 else ['--no-proxy-server'];argv+=['about:blank']
  write(phase/'preflight.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'priorPid':previous['pid'],'priorPort':previous['port'],'previousClosure':end,'zeroPeers':True,'capacity':capacity,'proxy':proxy,'proxyCommand':proxy_command,'profileCopied':False,'profileReset':False})
  env={k:v for k,v in os.environ.items() if k.lower() not in {'http_proxy','https_proxy','all_proxy','no_proxy'} and not k.startswith('AGENT_BROWSER_')}
  assert not peers(),'A task browser appeared before launch'
  started=time.time();deadline=time.monotonic()+300;proc=subprocess.Popen(argv,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  spawn={'phase':a.phase,'pid':proc.pid,'startedAt':started,'profile':str(PROFILE),'arguments':argv,'maximumSeconds':300,'readinessDeadlineSeconds':20,'automaticRestart':False,'familyStartNumber':idx+1,'familyMaximumStarts':2}
  write(phase/'spawn.json',spawn);print(json.dumps(spawn),flush=True)
  notes=phase/'startup-readiness.jsonl';notes.open('x').close();note_rows=note_bytes=0
  def note(value):
   nonlocal note_rows,note_bytes
   row=json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),**value})+'\n';note_rows+=1;note_bytes+=len(row.encode());assert note_rows<=256 and note_bytes<=131072
   with notes.open('a') as f:f.write(row)
  port,version=wait_for_owned_endpoint(PROFILE,proc,started,note=note)
  pf=PROFILE/'DevToolsActivePort';assert pf.is_file() and not pf.is_symlink() and pf.stat().st_mtime>=started
  data=pf.read_bytes();assert len(data)<=1024;parts=data.decode().splitlines();endpoint=urlsplit(version['webSocketDebuggerUrl'])
  assert len(parts)==2 and int(parts[0])==port and endpoint.scheme=='ws' and endpoint.hostname=='127.0.0.1' and endpoint.port==port and endpoint.path==parts[1]
  command=subprocess.check_output(['ps','-p',str(proc.pid),'-o','command='],text=True);assert '--user-data-dir='+str(PROFILE) in command
  assert proc.pid!=previous['pid'] and version['webSocketDebuggerUrl']!=previous['endpoint']
  receipt={**spawn,'endpoint':version['webSocketDebuggerUrl'],'port':port,'version':version,'scope':identity['scope'],'game':identity['url'],'explorer':C['explorer'],'proxyMode':'refused' if idx==0 else 'online','proxy':proxy,'profileReset':False,'profileCopied':False,'identitySha256':hashlib.sha256((P/'verified-public-identity.json').read_bytes()).hexdigest(),'rootAuthorizationSha256':hashlib.sha256((P/'root-authorization.json').read_bytes()).hexdigest(),'deadlineUtc':datetime.datetime.fromtimestamp(started+300,datetime.timezone.utc).isoformat(),'serialization':{'otherP01Browsers':[],'peerReserveBytes':33554432,'ownerLock':str(P/'serial-browser.lock')},'initialTargetBindingRequired':True}
  write(phase/'launch.json',receipt);print(json.dumps(receipt),flush=True)
  while proc.poll() is None:
   assert time.monotonic()<deadline,'Owned R8 300-second deadline'
   assert all(p['pid']==proc.pid and p['profile']==str(PROFILE) for p in peers()),'Concurrent browser violates serial execution'
   check('running',identity,a.phase);time.sleep(min(2,max(0,deadline-time.monotonic())))
  for _ in range(10):
   if closed(port):break
   time.sleep(.1)
  result={'phase':a.phase,'pid':proc.pid,'exitCode':proc.returncode,'pidExited':gone(proc.pid),'endpointClosed':closed(port),'capacity':check('after-exit',identity,a.phase)};write(phase/'exit.json',result)
  assert result['exitCode']==0 and result['pidExited'] and result['endpointClosed'],'Owned closure failed'
 except BaseException as error:
  if proc and proc.poll() is None:
   proc.terminate()
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
  if phase.exists():
   write(phase/'launch-failure.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'type':type(error).__name__,'message':str(error),'phase':a.phase,'ownedPid':proc.pid if proc else None,'noAutomaticRetry':True})
   if not (phase/'exit.json').exists():write(phase/'exit.json',{'phase':a.phase,'pid':proc.pid if proc else None,'exitCode':proc.returncode if proc else None,'pidExited':gone(proc.pid) if proc else True,'endpointClosed':closed(port) if port else None,'startupCompleted':port is not None,'failed':True})
  raise
 finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
if __name__=='__main__':main()
