"""Count only the reused owned profile and new R8 evidence; never write inside R7."""
from pathlib import Path
import argparse,datetime,json,os,shutil,stat
from completion_binding import P,C,value,verify
R=P/'run';PROFILE=Path(C['profile']);L=C['limits']
def check(stage,identity,phase=None):
 assert PROFILE==Path(C['priorRoot'])/'run/profile' and PROFILE.is_dir() and not PROFILE.is_symlink()
 inventory=sum(x['bytes'] for x in value(identity['offlineManifestPin'])['files']);cap=L['profileBaseBytes']+L['offlineInventoryMultiplier']*inventory
 assert cap<=L['maximumProfileBytes'] and L['minimumProjectedFreeBytes']==536870912 and L['peerReserveBytes']==33554432
 profile=evidence=allocated=0;links=[]
 for root,is_profile in [(PROFILE,True),(R,False)]:
  for base,dirs,files in os.walk(root,followlinks=False):
   for name in dirs+files:
    p=Path(base)/name
    try:s=p.lstat()
    except FileNotFoundError:continue
    if stat.S_ISLNK(s.st_mode):
     assert is_profile and PROFILE in p.parents,'Symlink outside owned profile'
     profile+=s.st_size;allocated+=s.st_blocks*512;links.append({'path':str(p.relative_to(PROFILE)),'target':os.readlink(p),'logicalBytes':s.st_size});continue
    if not stat.S_ISREG(s.st_mode):continue
    allocated+=s.st_blocks*512
    if is_profile:profile+=s.st_size
    else:evidence+=s.st_size
 remaining=max(0,cap-profile)+max(0,L['evidenceBytes']-evidence);free=shutil.disk_usage(P).free;projected=free-L['peerReserveBytes']-remaining
 row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':stage,'phase':phase,'profile':str(PROFILE),'profileLogicalBytes':profile,'profileAllowanceBytes':cap,'profileLinks':links,'evidenceLogicalBytes':evidence,'allocatedBytes':allocated,'freeBytes':free,'remainingOwnAllowanceBytes':remaining,'peerReserveBytes':L['peerReserveBytes'],'projectedFreeBytes':projected,'requiredProjectedFreeBytes':L['minimumProjectedFreeBytes'],'capacitySufficient':projected>=L['minimumProjectedFreeBytes']}
 output=R/phase/'capacity.jsonl' if phase else P/'capacity-observations.jsonl'
 with output.open('a') as f:f.write(json.dumps(row)+'\n')
 assert row['capacitySufficient'] and profile<=cap and evidence<=L['evidenceBytes'] and allocated<=L['maximumAllocatedBytes'],json.dumps(row)
 return row
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--stage',default='controller-check');ap.add_argument('--phase',choices=C['phases']);a=ap.parse_args();print(json.dumps(check(a.stage,verify(),a.phase)))
