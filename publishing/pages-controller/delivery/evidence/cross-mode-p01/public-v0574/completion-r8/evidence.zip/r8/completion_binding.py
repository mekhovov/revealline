"""Read-only R8 authority gate; no network, browser or output creation."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
P=Path(__file__).resolve().parent
C=json.loads((P/'completion-config.json').read_text())
ROOTS=[Path(C[k]).resolve() for k in ['sourceRoot','authorityRoot']]
def raw(pin):
 assert isinstance(pin,dict) and type(pin.get('bytes')) is int and 0<=pin['bytes']<=16*1024*1024
 assert re.fullmatch('[a-f0-9]{64}',pin.get('sha256',''))
 p=Path(pin['path']);assert p.is_absolute() and '..' not in p.parts and p.is_file() and not any(x.is_symlink() for x in [p,*p.parents])
 assert any(p.is_relative_to(root) for root in ROOTS)
 data=p.read_bytes();assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],'Pin differs: '+str(p)
 return data
def value(pin):return json.loads(raw(pin))
def manifest(pin):
 m=value(pin);assert len(m['files'])==m['count']==len({r['path'] for r in m['files']})
 for r in m['files']:
  p=Path(r['path']);assert not p.is_absolute() and '..' not in p.parts
  raw({**r,'path':str(P/p)})
 return m

def verify():
 a=json.loads((P/'root-authorization.json').read_text());v=json.loads((P/'verified-public-identity.json').read_text())
 assert a.get('rootGo') is True and a['status']=='AUTHORIZED_BOUNDED_PUBLIC_OFFLINE_COMPLETION' and a['family']==C['family']=='v0574-offline-completion-r8'
 start=datetime.fromisoformat(a['notBefore'].replace('Z','+00:00'));end=datetime.fromisoformat(a['expiresAt'].replace('Z','+00:00'));now=datetime.now(timezone.utc)
 assert start<=now<=end and 0<(end-start).total_seconds()<=3600,'Fresh timed GO required'
 assert a['serializedExecution'] is True and a['maximumBrowserStarts']==2 and a['maximumSecondsPerProcess']==300
 assert C['limits']['maximumBrowserStarts']==2 and C['limits']['automaticRestarts']==0 and C['limits']['browserSecondsPerProcess']==300
 for k in ['sourceRevision','sourceTree','version','scope']:assert a[k]==C[k]==v[k]
 assert C['game']==v['url']==C['scope']+'game/index.html'
 assert raw(C['priorIdentityPin'])==(P/'verified-public-identity.json').read_bytes(),'Prior actual identity must be unchanged'
 for key in ['priorLaunchPin','priorClosurePin','priorIndependentColdReviewPin','priorIndependentClosurePin']:raw(C[key])
 assert Path(a['launcherManifestPin']['path'])==P/'launcher-manifest.json';manifest(a['launcherManifestPin'])
 assert Path(a['controllerManifestPin']['path'])==P/'controller-manifest.json';manifest(a['controllerManifestPin'])
 assert Path(a['freshPublicReviewPin']['path'])==P/'root-fresh-public-review.json'
 fresh=value(a['freshPublicReviewPin']);assert fresh['status']=='FRESH_SOURCE_PUBLICATION_IDENTITY_CONFIRMED'
 at=datetime.fromisoformat(fresh['at'].replace('Z','+00:00'));assert start.timestamp()-900<=at.timestamp()<=now.timestamp()+5,'Fresh authority predates GO by more than15min'
 for k in ['sourceRevision','sourceTree','version']:assert fresh[k]==v[k]
 for k,other in [('publishingRevision','controllerCommit'),('publishingTree','controllerTree'),('run','publicationRunId'),('deployment','deploymentId'),('release','releaseId')]:assert fresh[k]==v[other]
 originals={Path(x['path']).name:(x,raw(x)) for x in fresh['originals']}
 run=json.loads(originals['run.json'][1]);dep=json.loads(originals['deployment.json'][1]);statuses=json.loads(originals['statuses.json'][1]);release=json.loads(originals['release.json'][1]);main=json.loads(originals['main.json'][1])
 assert run['id']==v['publicationRunId'] and run['head_sha']==v['controllerCommit'] and run['status']=='completed' and run['conclusion']=='success'
 assert dep['id']==v['deploymentId'] and dep['sha']==v['controllerCommit'] and statuses[0]['state']=='success'
 assert main['sha']==v['controllerCommit'] and main['commit']['tree']['sha']==v['controllerTree']
 assert release['id']==v['releaseId'] and release['tag_name']==v['version'] and release['draft'] is False and release.get('published_at')
 http={r['url']:r for r in fresh['http']}
 for url,key in [(C['game'].rsplit('/',1)[0]+'/build-info.json','buildInfoPin'),('https://mekhovov.github.io/revealline/current-entry-routing.json','rootEntryRoutingPin')]:
  row=http[url];expected=v[key];raw(expected);assert row['status']==200 and (row['bytes'],row['sha256'])==(expected['bytes'],expected['sha256'])
  assert any((p['bytes'],p['sha256'])==(expected['bytes'],expected['sha256']) for p,data in originals.values()),'Fresh original body absent'
 assert http['https://mekhovov.github.io/revealline/release.json']['status']==200
 q=value(v['qualificationPin']);assert q['passed'] and q['sourceRevision']==C['sourceRevision'] and q['sourceTree']==C['sourceTree']
 report=value(v['publicHttpReportPin']);assert report['status']=='PASS' and report['gameSourceRevision']==C['sourceRevision'] and report['controllerCommit']==v['controllerCommit'] and report['deploymentId']==v['deploymentId']
 offline=value(v['offlineManifestPin']);build=value(v['buildInfoPin']);assert build['sourceRevision']==C['sourceRevision'] and build['version']==offline['version']==C['version'] and offline['buildId']==v['buildId']
 assert len(offline['files'])==609 and sum(r['bytes'] for r in offline['files'])==55473406
 return v
