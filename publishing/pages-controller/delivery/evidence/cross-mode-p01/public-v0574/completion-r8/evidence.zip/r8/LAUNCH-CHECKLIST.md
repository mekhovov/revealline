# R8 remaining offline completion

Preparation only. Keep R7 receipts sealed; the only reused browser state is the original R7/run/profile, used in place by the approved browser, never copied/reset by this launcher.

1. Parent finalizes controller-manifest.json with count/files entries using paths relative to R8; supplies controller helpers and verifies its actual Prepare→609→Verify→609 and restored confirmation scopes.
2. Parent fills root-authorization.json: status AUTHORIZED_BOUNDED_PUBLIC_OFFLINE_COMPLETION, rootGo true; explicit notBefore/expiresAt (at most60minutes); exact freshPublicReviewPin, launcherManifestPin and controllerManifestPin. Source/scope fields remain exact. Fresh public review must be observed within15minutes before the new GO and its corrected actual routing body must match. Prior404 remains preserved.
3. Create only R8/run for new proxy receipts, then invoke copied refusal_proxy.py --port 0 --events R8/run/refusal-events.jsonl --ready R8/run/refusal-proxy-ready.json. It refuses all requests with no upstream connections.
4. Run python3 launch-offline-completion.py --go --phase 01-refused. One fresh process, about:blank, same original profile, exact new proxy. New controller establishes viewport, disables HTTP cache, navigates canonical once; actual native Prepare then Verify. Capacity CLI: python3 completion_capacity.py --stage before-action --phase 01-refused.
5. After actual browser PID/endpoint closure, stop/reap only the owned proxy; preserve its final stopped event. No automatic retry on any failed phase.
6. Run python3 launch-offline-completion.py --go --phase 02-restored only after cold browser and proxy are absent. Same profile, no proxy, one initial about:blank target; parent controller owns finite restored-state confirmation and close.

Both phases use300seconds, at most2browser starts, zero automatic retries,40native actions/four PNG maximum for this limited completion family, no downloads/new flight/history campaign. Reserve512MiB plus32MiB peer allowance and all remaining profile/evidence capacity. Existing R7 corrections and140action/6process limit remain historical and are not relabeled as an original90/3 pass.

All files under R7 outside its explicitly reused profile remain read-only. New spawn/launch/readiness/capacity/exit/failure files use exclusive phase directories. The new evidence allowance is10MiB; profile allowance derives from actual609-file55,473,406-byte frozen inventory.
