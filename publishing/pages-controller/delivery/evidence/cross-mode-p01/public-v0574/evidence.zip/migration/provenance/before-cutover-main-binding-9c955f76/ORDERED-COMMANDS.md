# Execution commands — blocked until actual cutover review and GO

Use this directory's public_binding.py first. It currently refuses because rootGo is false and final cutover fields are null. Fill only actual reviewed originals; never substitute source75d/78fbd CI preparation for deployed authority.

The original profile path is fixed in public-launch-config.json and retained-profile-binding.json. Never create run/profile, copy the profile, remove Singleton links or call a registration/storage API to help migration.

After binding, root review, latest peer closure and fresh capacity:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 public_binding.py
PYTHONDONTWRITEBYTECODE=1 python3 public_capacity.py --actual-binding --stage before-migration
PYTHONDONTWRITEBYTECODE=1 python3 launch-public-chrome.py --go --phase 01-online
```

Start the driver from this directory in a separate owned exec_command with tty:true:

```sh
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node public-driver.mjs --phase 01-online
```

Issue individual JSON commands on that live PTY. Initial sequence:

```json
{"action":"navigate","arg":"game"}
{"action":"read","arg":"summary"}
{"action":"read","arg":"workers"}
{"action":"read","arg":"history"}
```

Inspect actual stable controls and route. On an old cached document, retain document/fromServiceWorker and worker metadata; do not call identity reads against a bridge/error page or label its old cached source as migrated. If needed, use the one reviewed ordinary `{"action":"reload"}` in phase1 and inspect again. Do not issue a direct archive navigation command.

Only at the actual Archive17 game route:

```json
{"action":"read","arg":"identity"}
{"action":"read","arg":"history"}
{"action":"inspect","arg":"#shell-continue"}
{"action":"click","arg":"#shell-continue"}
{"action":"read","arg":"solo"}
{"action":"read","arg":"history"}
{"action":"shot","arg":"archive-paused-continue"}
{"action":"close"}
```

The pointer helper waits for two matching visible, enabled, hit-tested rectangles300ms apart. Use only an actually present Continue control; the original #continue-saved is allowed when visible instead. Native Tab/Shift+Tab and Enter are available only for these controls or a visible exact archive bridge anchor. No movement, Resume, Escape toggle, arbitrary script, import/export or offline action is exposed.

Wait for the exact launcher exit receipt and confirm the driver/PID/port are gone. If phase1 is still pending and root permits the planned second open, repeat the launch and PTY commands with `--phase 02-reopen`. Use the SAME old Play URL via navigate/game. This is a separately commanded normal browser open after all controlled tabs close; no automatic retry. No reload command is allowed in phase2. Close and preserve the pending state if normal archive routing still does not occur.

Final report must cite actual first/reopen URL and worker transitions, document provenance, decoded archive identity, paused-save/presentation/store comparison and all closures. No helper writes an accepted result. migration_checks.py only compares supplied receipts; it cannot establish that a native action happened.
