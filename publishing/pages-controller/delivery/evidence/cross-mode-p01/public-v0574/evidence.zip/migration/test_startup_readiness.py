import tempfile
import time
import unittest
from pathlib import Path
from startup_readiness import wait_for_owned_endpoint


class Clock:
    def __init__(self): self.value = 0
    def now(self): return self.value
    def sleep(self, seconds): self.value += seconds


class Process:
    def __init__(self, code=None): self.code = code
    def poll(self): return self.code


class Readiness(unittest.TestCase):
    def fixture(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        profile = Path(directory.name)
        (profile / 'DevToolsActivePort').write_text('49123\n/devtools/browser/owned\n')
        return profile, Clock(), []

    def test_transient_timeout_then_same_process_ready(self):
        profile, clock, notes = self.fixture()
        calls = []
        def probe(port, remaining):
            calls.append((port, remaining))
            if len(calls) == 1:
                clock.sleep(.5)
                raise TimeoutError('Synthetic first endpoint timeout')
            return {'webSocketDebuggerUrl': 'ws://127.0.0.1:49123/devtools/browser/owned'}
        port, _ = wait_for_owned_endpoint(profile, Process(), time.time() - 10, note=notes.append,
                                          monotonic=clock.now, sleep=clock.sleep, probe=probe)
        self.assertEqual(port, 49123)
        self.assertEqual(len(calls), 2)
        self.assertEqual([x['state'] for x in notes], ['not-ready', 'ready'])
        self.assertLess(clock.value, 20)

    def test_original_twenty_second_deadline(self):
        profile, clock, notes = self.fixture()
        def probe(port, remaining):
            clock.sleep(min(1, remaining))
            raise TimeoutError('Synthetic still starting')
        with self.assertRaisesRegex(TimeoutError, 'original 20-second'):
            wait_for_owned_endpoint(profile, Process(), time.time() - 10, note=notes.append,
                                    monotonic=clock.now, sleep=clock.sleep, probe=probe)
        self.assertAlmostEqual(clock.value, 20)
        self.assertTrue(notes)

    def test_early_process_exit_is_not_restarted_or_probed(self):
        profile, clock, notes = self.fixture()
        def forbidden(*args): self.fail('Exited process must never be probed or restarted')
        with self.assertRaisesRegex(RuntimeError, 'before readiness: 17'):
            wait_for_owned_endpoint(profile, Process(17), time.time() - 10, note=notes.append,
                                    monotonic=clock.now, sleep=clock.sleep, probe=forbidden)
        self.assertEqual(notes, [])
        self.assertEqual(clock.value, 0)


if __name__ == '__main__': unittest.main()
