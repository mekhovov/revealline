import os,tempfile,unittest
from pathlib import Path
from public_capacity import measure
class Accounting(unittest.TestCase):
 def test_profile_link_is_metadata_only_and_never_followed(self):
  with tempfile.TemporaryDirectory() as name:
   base=Path(name);profile=base/'profile';profile.mkdir();outside=base/'outside';outside.mkdir();(outside/'sentinel').write_bytes(b'x'*8192);link=profile/'Singleton';link.symlink_to(outside,target_is_directory=True)
   r=measure(profile,True);self.assertEqual(r['logicalBytes'],link.lstat().st_size);self.assertEqual(len(r['links']),1)
 def test_evidence_symlink_is_refused(self):
  with tempfile.TemporaryDirectory() as name:
   base=Path(name);(base/'link').symlink_to('/definitely-unopened')
   with self.assertRaisesRegex(AssertionError,'Symlink'):measure(base,False)
 def test_special_profile_file_is_refused_without_opening(self):
  with tempfile.TemporaryDirectory() as name:
   base=Path(name);os.mkfifo(base/'pipe')
   with self.assertRaisesRegex(AssertionError,'Special'):measure(base,True)
if __name__=='__main__':unittest.main()
