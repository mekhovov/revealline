#!/usr/bin/env python3
"""Explicit GO-only serial same-profile public launch; no default/automatic browser."""
from pathlib import Path
import argparse,datetime,fcntl,hashlib,http.client,json,os,socket,subprocess,time
from urllib.parse import urlsplit
from public_binding import verify,C,P,raw
from public_capacity import check
from startup_readiness import wait_for_owned_endpoint
R=P/'run';PHASES=C['phases']
def gone(pid):
 try:os.kill(pid,0);return False
 except ProcessLookupError:return True

def closed(port):
 with socket.socket() as s:s.settimeout(.5);return s.connect_ex(('127.0.0.1',port))!=0

def peers():
 # Read-only ownership audit. Unrelated browser processes are not targets or outputs.
 rows=[]
 for line in subprocess.check_output(['ps','-axo','pid=,command='],text=True).splitlines():
  if '/Google Chrome' not in line or '--user-data-dir=' not in line or '--type=' in line:continue
  profile=line.split('--user-data-dir=',1)[1].split(' ',1)[0]
  if any(profile.startswith(str(Path(root)/'.cache/cross-mode/p01')+'/') for root in [C['sourceRoot'],C['authorityRoot']]):rows.append({'pid':int(line.strip().split(None,1)[0]),'profile':profile})
 return rows

def write(path,value):
 with path.open('x') as f:f.write(json.dumps(value,indent=2)+'\n')

def main():
 a=argparse.ArgumentParser();a.add_argument('--go',action='store_true');a.add_argument('--phase',choices=PHASES,required=True);x=a.parse_args()
 assert x.go,'Prepared only: actual root Pages GO is required'
 identity=verify();phase=R/x.phase;profile=Path(C['profile']);idx=PHASES.index(x.phase)
 lock=(P/'serial-browser.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 observed_peers=peers();assert not observed_peers,'Another owned P01 browser is active; serialized execution refused: '+json.dumps(observed_peers)
 assert profile.is_dir() and not profile.is_symlink(),'Original retained profile required; never create/copy/reset it'
 prior=None
 if idx==0:assert not R.exists(),'Initial attempt already exists; no retry/reset'
 else:
  A=json.loads((P/'root-authorization.json').read_text());assert A['allowPlannedReopen'] is True
  previous=R/PHASES[idx-1];prior=json.loads((previous/'launch.json').read_text());end=json.loads((previous/'exit.json').read_text())
  assert end['pid']==prior['pid'] and end['exitCode']==0 and end['pidExited'] and end['endpointClosed'] and gone(prior['pid']) and closed(prior['port'])
  assert prior['profile']==str(profile) and prior['identitySha256']==hashlib.sha256((P/'verified-public-identity.json').read_bytes()).hexdigest() and not phase.exists()
 check('before-launch',identity)
 if idx==0:R.mkdir()
 phase.mkdir()
 args=['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--headless=new','--remote-debugging-port=0','--enable-automation','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-features=OptimizationGuideModelDownloading,OptimizationHintsFetching,OptimizationTargetPrediction,OptimizationHints','--disable-gpu-shader-disk-cache','--disable-default-apps','--disable-sync','--enable-unsafe-swiftshader','--password-store=basic','--use-mock-keychain','--disable-quic','--disable-extensions','--disk-cache-size=4194304','--media-cache-size=1048576','--window-size=390,844','--user-data-dir='+str(profile)]
 proxy=None
 args+=['--no-proxy-server']
 args+=['about:blank']
 env={k:v for k,v in os.environ.items() if k.lower() not in {'http_proxy','https_proxy','all_proxy','no_proxy'} and not k.startswith('AGENT_BROWSER_')}
 started=time.time();proc=None
 try:
  assert not peers(),'Concurrent P01 browser appeared before launch'
  proc=subprocess.Popen(args,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  write(phase/'spawn.json',{'startedAt':started,'phase':x.phase,'pid':proc.pid,'profile':str(profile),'arguments':args,'readinessDeadlineSeconds':20,'browserStarts':1,'automaticRestart':False})
  notes=phase/'startup-readiness.jsonl';notes.open('x').close();note_rows=0;note_bytes=0
  def note(value):
   nonlocal note_rows,note_bytes
   body=json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),**value})+'\n'
   size=len(body.encode());assert note_rows<256 and note_bytes+size<=131072,'Bounded readiness notes exceeded'
   with notes.open('a') as handle:handle.write(body)
   note_rows+=1;note_bytes+=size
  port,version=wait_for_owned_endpoint(profile,proc,started,note=note)
  pf=profile/'DevToolsActivePort';assert pf.is_file() and not pf.is_symlink() and pf.stat().st_mtime>=started
  raw_port=pf.read_bytes();assert len(raw_port)<=1024;lines=raw_port.decode().splitlines()
  endpoint=urlsplit(version['webSocketDebuggerUrl'])
  assert len(lines)==2 and int(lines[0])==port and endpoint.scheme=='ws' and endpoint.hostname in ['127.0.0.1','localhost'] and endpoint.port==port and endpoint.path==lines[1],'Exact current DevTools endpoint file differs'
  command=subprocess.check_output(['ps','-p',str(proc.pid),'-o','command='],text=True);assert '--user-data-dir='+str(profile) in command
  if prior:assert proc.pid!=prior['pid'] and version['webSocketDebuggerUrl']!=prior['endpoint'],'Cold start reused prior process/endpoint'
  receipt={'startedAt':started,'phase':x.phase,'pid':proc.pid,'profile':str(profile),'arguments':args,'endpoint':version['webSocketDebuggerUrl'],'port':port,'version':version,'scope':identity['scope'],'game':identity['url'],'explorer':C['explorer'],'proxyMode':'online','proxy':proxy,'profileReset':False,'identitySha256':hashlib.sha256((P/'verified-public-identity.json').read_bytes()).hexdigest(),'rootAuthorizationSha256':hashlib.sha256((P/'root-authorization.json').read_bytes()).hexdigest(),'serialization':{'peerAllowanceBytes':33554432,'otherP01Browsers':observed_peers,'ownerLock':str(P/'serial-browser.lock')},'initialTargetBindingRequired':True}
  write(phase/'launch.json',receipt);print(json.dumps(receipt),flush=True)
  while proc.poll() is None:
   assert time.time()-started<=C['limits']['browserSecondsPerProcess'],'Owned versioned migration browser duration cap'
   assert all(row['pid']==proc.pid and row['profile']==str(profile) for row in peers()),'Peer browser violates serialized run'
   verify();check('running',identity,x.phase);time.sleep(3)
  endpoint_closed=False
  for _ in range(10):
   if closed(port):endpoint_closed=True;break
   time.sleep(.1)
  result={'phase':x.phase,'pid':proc.pid,'exitCode':proc.returncode,'pidExited':gone(proc.pid),'endpointClosed':endpoint_closed,'capacity':check('after-exit',identity,x.phase)}
  write(phase/'exit.json',result)
  assert result['exitCode']==0 and result['pidExited'] and result['endpointClosed'],'Owned closure failed; retain attempt'
 except BaseException as error:
  if proc and proc.poll() is None:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
  write(phase/'launch-failure.json',{'type':type(error).__name__,'message':str(error),'phase':x.phase,'ownedPid':proc.pid if proc else None,'pidExited':gone(proc.pid) if proc else True,'endpointClosed':closed(port) if 'port' in locals() else None,'exitCode':proc.returncode if proc else None,'noAutomaticRetry':True})
  raise
 finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
if __name__=='__main__':main()
