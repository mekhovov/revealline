import copy,json,unittest
from migration_checks import disposition,OLD,ARCHIVE,SOURCE,KEY
class Comparison(unittest.TestCase):
 def fixture(self):
  before={'url':OLD,'storage':{KEY:json.dumps({'savedAt':'before','runId':'actual-fixture','replay':{'ticks':1848,'checkpoint':{'hash':'same'}},'presentationPins':{'sha256':'picture'}}),'other':'unchanged'},'databases':[{'name':'media','version':4,'stores':[{'name':'mediaBlobs','count':1,'keys':['one'],'sha256':'same','originals':[{'sha256':'one','blobBytes':5}]}]}]}
  after=copy.deepcopy(before);after['url']=ARCHIVE
  return before,after,{'sourceRevision':SOURCE,'channel':'release-v0.57.3'}
 def test_cached_old_is_not_migrated(self):
  b,a,i=self.fixture();a['url']=OLD;self.assertEqual(disposition(b,a,i,'paused')['status'],'CACHED_ORIGINAL_NOT_MIGRATED')
 def test_archive_without_paused_continue_is_incomplete(self):
  b,a,i=self.fixture();self.assertIn('UNPROVEN',disposition(b,a,i,'briefing')['status'])
 def test_same_save_with_only_saved_at_change_is_explicitly_limited(self):
  b,a,i=self.fixture();v=json.loads(a['storage'][KEY]);v['savedAt']='after';a['storage'][KEY]=json.dumps(v);r=disposition(b,a,i,'paused');self.assertEqual(r['savedAtBeforeAfter'],['before','after']);self.assertFalse(r['phaseAccepted']);self.assertFalse(r['rawStorageEqualityClaim'])
 def test_changed_checkpoint_fails(self):
  b,a,i=self.fixture();v=json.loads(a['storage'][KEY]);v['replay']['ticks']+=1;a['storage'][KEY]=json.dumps(v)
  with self.assertRaisesRegex(AssertionError,'Saved'):disposition(b,a,i,'paused')
 def test_changed_original_fails(self):
  b,a,i=self.fixture();a['databases'][0]['stores'][0]['originals'][0]['sha256']='different'
  with self.assertRaisesRegex(AssertionError,'media'):disposition(b,a,i,'paused')
 def test_wrong_source_fails(self):
  b,a,i=self.fixture();i['sourceRevision']='new-source'
  with self.assertRaisesRegex(AssertionError,'identity'):disposition(b,a,i,'paused')
 def test_root_route_cannot_pass_as_versioned_migration(self):
  b,a,i=self.fixture();a['url']='https://mekhovov.github.io/revealline/game/'
  with self.assertRaisesRegex(AssertionError,'route'):disposition(b,a,i,'paused')
if __name__=='__main__':unittest.main()
