"""Pure receipt comparison. It does not open profile storage or grant acceptance."""
import copy
OLD='https://mekhovov.github.io/revealline/releases/v0.57.3/site/game/'
ARCHIVE='https://mekhovov.github.io/revealline-archive-17/releases/v0.57.3/site/game/'
SOURCE='7945c6d07714d41cee9b6f848059b8dc18aed86c'
KEY='revealline.suspended.release-v0.57.3.v1'
def disposition(before,after,identity,flight_state):
 import json
 b=copy.deepcopy(before['storage']);a=copy.deepcopy(after['storage'])
 bs=json.loads(b.pop(KEY));as_=json.loads(a.pop(KEY));times=[bs.pop('savedAt'),as_.pop('savedAt')]
 assert bs==as_ and b==a,'Saved replay/pins or other historical storage changed'
 def stores(value):return [(d['name'],d['version'],[(s['name'],s['count'],s['keys'],s['sha256'],s['originals']) for s in d['stores']]) for d in value['databases']]
 assert stores(before)==stores(after),'Observed historical database/media endpoint changed'
 url=after['url'];assert url in [OLD,OLD+'index.html',ARCHIVE,ARCHIVE+'index.html'],'Unexpected route'
 assert identity['sourceRevision']==SOURCE and identity['channel']=='release-v0.57.3','Actual frozen identity missing or changed'
 if url in [OLD,OLD+'index.html']:state='CACHED_ORIGINAL_NOT_MIGRATED'
 elif flight_state=='paused':state='ARCHIVE_ROUTE_AND_PAUSED_SAVE_OBSERVED_PENDING_PARENT'
 else:state='ARCHIVE_ROUTE_OBSERVED_PAUSED_CONTINUE_UNPROVEN'
 return {'status':state,'savedAtBeforeAfter':times,'rawStorageEqualityClaim':False,'phaseAccepted':False,'physicalOrOfflineClaim':False}
