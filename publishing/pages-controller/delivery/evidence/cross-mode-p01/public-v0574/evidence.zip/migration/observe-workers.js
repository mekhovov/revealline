(async () => {
  const registrations = await navigator.serviceWorker.getRegistrations();
  const cacheNames = await caches.keys();
  if (registrations.length > 32 || cacheNames.length > 64) throw Error('Bounded worker/cache metadata exceeded');
  const worker = value => value ? { scriptURL: value.scriptURL, state: value.state } : null;
  const result = {
    at: new Date().toISOString(), url: location.href, timeOrigin: performance.timeOrigin,
    htmlBuildVersion: document.documentElement.dataset.buildVersion ?? null,
    flightState: document.body.dataset.flightState ?? null,
    pictureState: document.body.dataset.pictureState ?? null,
    controller: worker(navigator.serviceWorker.controller),
    registrations: registrations.map(r => ({ scope: r.scope, active: worker(r.active), waiting: worker(r.waiting), installing: worker(r.installing) })),
    cacheNames, onlineHint: navigator.onLine,
    limitation: 'Read-only metadata. Registration URL alone does not identify installed worker bytes; no update/register/unregister or cache mutation requested.'
  };
  if (new TextEncoder().encode(JSON.stringify(result)).length > 65536) throw Error('Worker metadata byte bound');
  return result;
})()
