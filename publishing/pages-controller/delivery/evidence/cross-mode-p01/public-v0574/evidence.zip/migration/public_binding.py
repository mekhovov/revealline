"""Read-only migration authority guard; no browser, storage access or network."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,re
P=Path(__file__).resolve().parent;C=json.loads((P/'public-launch-config.json').read_text())
def raw(pin):
 p=Path(pin['path']);assert p.is_absolute() and '..' not in p.parts and p.is_file() and not any(q.is_symlink() for q in [p,*p.parents])
 assert any(p.is_relative_to(Path(C[k])) for k in ['sourceRoot','authorityRoot'])
 assert type(pin['bytes']) is int and 0<=pin['bytes']<=20_000_000
 b=p.read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'];return b
def value(pin):return json.loads(raw(pin))
def verify():
 A=json.loads((P/'root-authorization.json').read_text())
 assert A.get('rootGo') is True and A['status']=='AUTHORIZED_VERSIONED_ARCHIVE17_MIGRATION' and A['family']==C['family'],'Actual migration GO absent'
 now=datetime.now(timezone.utc);assert datetime.fromisoformat(A['notBefore'].replace('Z','+00:00'))<=now<datetime.fromisoformat(A['expiresAt'].replace('Z','+00:00'))
 for row in json.loads((P/'input-pins.json').read_text())['files']:raw(row)
 prior=value(C['priorProfileBinding']);assert prior['profile']==C['profile'] and prior['rootScopeClaim'] is False
 old=value(prior['closurePin']);assert old['status']=='ALL_OWNED_PROCESSES_CLOSED' and old['profilePreserved'] is True
 assert all(p['browserPidExited'] and p['driverPidExited'] and p['endpointClosed'] for p in old['processes'])
 assert Path(C['profile']).is_dir() and not Path(C['profile']).is_symlink()
 assert A['identityPin']['path']==str(P/'verified-public-identity.json');I=value(A['identityPin'])
 assert I['version']==C['version']==prior['version']=='v0.57.3' and I['sourceRevision']==prior['sourceRevision']=='7945c6d07714d41cee9b6f848059b8dc18aed86c'
 assert I['sourceTree']==prior['sourceTree']=='6c9970378ac236cd98cd7d1ed36965e298082cb0'
 assert I['scope']==C['scope']=='https://mekhovov.github.io/revealline-archive-17/releases/v0.57.3/site/' and I['url']==C['game']==I['scope']+'game/'
 assert C['oldScope']==prior['oldScope']=='https://mekhovov.github.io/revealline/releases/v0.57.3/site/' and C['oldGame']==prior['oldPlayUrl']==C['oldScope']+'game/'
 fresh=value(A['freshArchiveReviewPin']);assert fresh['status']=='PASS' and fresh['archiveCommit']==I['archiveCommit'] and fresh['runId']==I['runId'] and fresh['deploymentId']==I['deploymentId'] and fresh['successfulCanonicalStatusStillSame'] is True
 cut=C['cutover'];assert cut['version']=='v0.57.4'
 for key in ['sourceRevision','sourceTree','controllerCommit','controllerTree']:assert re.fullmatch('[a-f0-9]{40}',cut[key] or ''),'Actual cutover identity unresolved'
 for key in ['runId','deploymentId']:assert type(cut[key]) is int and cut[key]>0
 assert A['cutoverReviewPin']==cut['parentReviewPin'];parent=value(cut['parentReviewPin']);assert parent['status']=='PASS' and parent['migrationScope']=='main-versioned-v573-to-archive17' and parent['cutoverSource']==cut['sourceRevision'] and parent['cutoverController']==cut['controllerCommit']
 run=value(cut['runPin']);dep=value(cut['deploymentPin']);statuses=value(cut['statusesPin'])
 assert run['id']==cut['runId'] and run['head_sha']==cut['controllerCommit'] and run['status']=='completed' and run['conclusion']=='success'
 assert dep['id']==cut['deploymentId'] and dep['sha']==cut['controllerCommit'] and statuses[0]['state']=='success'
 report=value(cut['httpReviewPin']);assert report['status']=='PASS' and report['currentVersion']==cut['version'] and report['gameSourceRevision']==cut['sourceRevision'] and report['qualifiedSourceTree']==cut['sourceTree'] and report['controllerCommit']==cut['controllerCommit'] and report['controllerTree']==cut['controllerTree'] and report['runId']==cut['runId'] and report['deploymentId']==cut['deploymentId']
 results=[json.loads(v) for v in raw(cut['httpResultsPin']).splitlines() if v.strip()];byurl={v['url']:v for v in results};assert len(byurl)==len(results)
 routing=value(cut['archiveRoutingPin']);assert routing['canonicalSites']['v0.57.3']==I['scope'] and next(v for v in routing['releases'] if v['version']=='v0.57.3')['sourceRevision']==I['sourceRevision']
 for url,key in [('https://mekhovov.github.io/revealline/archive-routing.json','archiveRoutingPin'),(C['oldScope']+'game/index.html','bridgePin'),(C['oldScope']+'service-worker.js','retirementWorkerPin')]:
  b=raw(cut[key]);r=byurl[url];assert r['ok'] is True and r['status']==200 and r['bytesMatch'] and r['hashMatch'] and r['bytes']==len(b) and r['sha256']==hashlib.sha256(b).hexdigest()
 assert json.dumps(I['scope']+'game/index.html').encode() in raw(cut['bridgePin']) and json.dumps(I['scope']).encode() in raw(cut['retirementWorkerPin'])
 raw(A['priorBrowserClosurePin'])
 for field,name in [('controllerManifestPin','controller-preparation-manifest.json'),('launcherManifestPin','launcher-preparation-manifest.json')]:
  assert A[field]['path']==str(P/name);m=value(A[field]);assert m['count']==len(m['files'])==len({r['path'] for r in m['files']})
  for r in m['files']:
   q=Path(r['path']);assert not q.is_absolute() and '..' not in q.parts;raw({**r,'path':str(P/q)})
 return I
if __name__=='__main__':print(json.dumps(verify()))
