# Scoped historical migration verdict

PASS for the authentic old MAIN versioned v0.57.3 profile moving to Archive17 and restoring its saved flight paused. This does not accept P01 or Archive17 offline operation.

The first process truthfully remained on the cached old edition, with an activated old worker and installed waiting worker before and after one ordinary reload. It closed normally. Reopening the same profile and navigating only to the same old Play URL produced the current bridge document, then the canonical Archive17 index. Both document responses were 200 without service-worker/cache delivery; five frozen body hashes and the v0.57.3 source identity matched. No direct archive navigation, forced worker update/activation, cache clearing or registration injection was used.

Native Continue restored the original Orchard flight paused: run `5bcadd37-a7a1-4eed-8ef3-77743c01fc43`, 1,848 ticks, checkpoint `255ca8d70d02c0d7`. All observed raw localStorage strings, full replay/presentation pins and both databases/eight stores equal the authentic prior endpoint before and after Continue. The 52,720-byte original image hash is unchanged. savedAt remains `2026-09-15T21:00:50.250Z`; there are no observed timestamp differences. The final storage read precedes process close, so this does not assert zero writes after that endpoint.

The exact 390×844 PNG shows readable Paused/Resume and the other pause controls; Resume was not activated. Both browser and driver PIDs are absent, both listeners are closed and both launchers exited zero. All 15 action receipts pass; one cancelled ERR_ABORTED during the first ordinary reload is preserved with its unresolved resource identity. The old offline cache remains listed, while the Archive17 page has no controller/registrations and no offline verification.

All raw observations remain in place and are hashed by the manifest. Historical recovery defects remain historical. No physical-device, root-scoped worker, new gameplay, audible output or current-v0.57.4 recovery acceptance is claimed.
