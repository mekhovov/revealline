import test from 'node:test';
import assert from 'node:assert/strict';
import { cancelPendingPicture } from './pending-picture-cancel.mjs';
import { createPictureResponseHold } from './picture-response-hold.mjs';

const canonicalUrl = 'https://example.invalid/releases/v0.57.4/site/game/index.html';
const url = 'https://example.invalid/releases/v0.57.4/site/game/picture.png';
const owner = { packId: '', baseCampaignKey: 'first-signal/2/88639f3aab7b6cc1', levelId: 'signal-01', themeId: 'fpv', levelName: 'First Signal' };
function fixture(options = {}) {
  let clock = 0, phase = 'blank', timerId = 0, hold;
  const timers = new Map(), calls = [], inputs = [], observations = [], failures = [];
  const advance = async ms => {
    clock += ms;
    for (const [id, timer] of [...timers]) if (timer.at <= clock) { timers.delete(id); timer.fn(); }
    await Promise.resolve();
  };
  hold = createPictureResponseHold({
    sessionId: 'owned', url, log() {}, onFailure: e => failures.push(String(e)),
    timers: { setTimeout(fn, ms) { assert.equal(ms, 20000); timers.set(++timerId, { at: clock + ms, fn }); return timerId; }, clearTimeout(id) { timers.delete(id); } },
    call: async (method, args, session) => {
      assert.equal(session, 'owned'); calls.push({ method, args });
      if (method === 'Fetch.continueRequest') {
        if (options.releaseError) throw Error('ambiguous transport');
        await hold.observe({ sessionId: 'owned', method: options.abort ? 'Network.loadingFailed' : 'Network.loadingFinished', params: { requestId: 'network-one', canceled: !!options.abort, timestamp: clock / 1000 } });
      }
    },
  });
  const response = () => hold.observe({ sessionId: 'owned', method: 'Fetch.requestPaused', params: { requestId: 'one', networkId: 'network-one', request: { url, method: 'GET' }, responseStatusCode: 200, resourceType: 'Fetch' } });
  const read = async () => {
    if (options.delayedResponse && clock >= 4200 && hold.status().state === 'armed') await response();
    const settled = hold.status().state === 'released';
    const a = {
      url: canonicalUrl, homeOpen: phase === 'title', missionsOpen: phase === 'missions',
      picture: phase === 'pending' ? 'pending' : 'ready', flight: phase === 'fast' ? 'running' : 'briefing',
      active: phase === 'cancelled' ? 'start-button' : '', state: phase === 'pending' ? 'busy' : phase === 'cancelled' ? 'cancelled' : 'ready',
      status: phase === 'pending' ? 'Preparing original picture' : phase === 'cancelled' ? 'Preparation cancelled' : '',
      cancelVisible: phase === 'pending', cancelFullyVisible: phase === 'pending', cancelHit: phase === 'pending',
      dialogs: phase === 'title' ? ['shell-home'] : phase === 'missions' ? ['shell-missions'] : [],
      selection: { packId: '', campaignKey: owner.baseCampaignKey, levelId: owner.levelId, themeId: owner.themeId, selectedCount: 1, selectedIndex: '0', selectedName: 'First Signal', selectedDisabled: false },
    };
    if (options.wrongOwner) a.selection.packId = 'original-fpv-pressure';
    if (options.obstructed) a.cancelHit = false;
    if (options.lateResume && settled && clock >= 300) a.flight = 'running';
    if (options.lateFocusLoss && settled && clock >= 300) a.active = 'unrelated-button';
    if (options.readFailure && phase === 'pending') throw Error('owned target unavailable');
    return a;
  };
  const run = () => cancelPendingPicture({
    hold, owner, canonicalUrl, now: () => clock, wait: advance, read,
    record: row => observations.push(row),
    navigate: async () => {
      inputs.push('navigate'); phase = 'title';
      if (!options.noResponse && !options.delayedResponse) await response();
      if (options.expireAtBoot) await advance(20000);
    },
    click: async selector => {
      inputs.push(selector);
      if (options.clickFailure) throw Error('visible control unavailable');
      if (selector === '#shell-play') phase = 'missions';
      else { assert.equal(selector, '#shell-deploy'); phase = options.fast ? 'fast' : 'pending'; }
    },
    escape: async () => {
      inputs.push('Escape'); assert.equal(phase, 'pending'); phase = 'cancelled';
      if (options.expireAfterEscape) await advance(20000);
    },
  });
  return { run, hold, calls, inputs, observations, failures, timers };
}
const continuations = f => f.calls.filter(c => c.method === 'Fetch.continueRequest');
test('native order requires exact pending owner, then two settled cancelled samples and one original release', async () => {
  const f = fixture(), result = await f.run();
  assert.equal(result.status, 'NATIVE_PENDING_CANCEL_OBSERVED');
  assert.deepEqual(f.inputs, ['navigate', '#shell-play', '#shell-deploy', 'Escape']);
  assert.equal(result.before.picture, 'pending'); assert.equal(result.before.state, 'busy');
  assert.equal(result.after.active, 'start-button'); assert.equal(result.stable.length, 2);
  const first = f.observations.find(x => x.step === 'released-settled-cancelled');
  const second = f.observations.find(x => x.step === 'second-settled-cancelled');
  assert.ok(second.elapsedMs - first.elapsedMs >= 300);
  assert.equal(continuations(f).length, 1); assert.equal(f.timers.size, 0);
  assert.deepEqual(f.calls.map(c => c.method), ['Fetch.enable', 'Fetch.continueRequest', 'Fetch.disable']);
});
test('wrong owner refuses before any Missions or Deploy input and releases original during cleanup', async () => {
  const f = fixture({ wrongOwner: true }); await assert.rejects(f.run(), /exact Base First Signal/);
  assert.deepEqual(f.inputs, ['navigate']); assert.equal(continuations(f).length, 1);
  assert.equal(f.hold.status().cancelledByNativeEscape, false);
});
for (const [name, options, error] of [
  ['fast completion', { fast: true }, /pending-before-escape/],
  ['obstructed preparation Cancel', { obstructed: true }, /pending-before-escape/],
  ['missing original response', { noResponse: true }, /original-held/],
  ['automatic release during boot', { expireAtBoot: true }, /expired or became unproven/],
]) test(name + ' cannot claim native pending cancellation', async () => {
  const f = fixture(options); await assert.rejects(f.run(), error);
  assert.equal(f.inputs.includes('Escape'), false); assert.equal(f.hold.status().cancelledByNativeEscape, false);
  assert.ok(continuations(f).length <= 1); assert.equal(f.timers.size, 0);
});
test('automatic release after Escape still refuses the cancellation claim', async () => {
  const f = fixture({ expireAfterEscape: true }); await assert.rejects(f.run(), /expired or became unproven/);
  assert.equal(continuations(f).length, 1); assert.equal(f.hold.status().cancelledByNativeEscape, false);
});
for (const options of [{ lateResume: true }, { lateFocusLoss: true }]) test('second observation rejects a late launch or lost Start focus ' + JSON.stringify(options), async () => {
  const f = fixture(options); await assert.rejects(f.run(), /Second stable cancelled observation/);
  assert.equal(continuations(f).length, 1);
});
for (const options of [{ clickFailure: true }, { readFailure: true }]) test('native/observation failure cleans held response without pretending cancellation ' + JSON.stringify(options), async () => {
  const f = fixture(options); await assert.rejects(f.run(), /unavailable/);
  assert.equal(continuations(f).length, 1); assert.equal(f.hold.status().cancelledByNativeEscape, false);
});
test('actual browser cancellation settlement is explicit and never called original delivery', async () => {
  const f = fixture({ abort: true }), result = await f.run();
  assert.equal(result.requestSettlement.method, 'Network.loadingFailed');
  assert.match(result.deliveryClaim, /no original delivery claim/); assert.equal(continuations(f).length, 1);
});
test('ambiguous original continuation is not retried in finally', async () => {
  const f = fixture({ releaseError: true }); await assert.rejects(f.run(), /ambiguous transport/);
  assert.equal(f.hold.status().state, 'ambiguous-release'); assert.equal(continuations(f).length, 1);
});

test('later original request can arrive after title without operator turns or extending its emergency bound', async () => {
  const f = fixture({ delayedResponse: true }), result = await f.run();
  assert.equal(result.status, 'NATIVE_PENDING_CANCEL_OBSERVED'); assert.ok(result.elapsedMs >= 4500);
  assert.equal(continuations(f).length, 1); assert.equal(f.failures.length, 0);
});
