import {cancelPendingPicture} from './pending-picture-cancel.mjs';
import {createPictureResponseHold} from './picture-response-hold.mjs';
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import readline from 'node:readline';
import {R,P,D,phase,config,identity,launch,controllerManifest,browserArguments,call,attachInitial,verifyTarget,evaluate,foreground,events,close,allowedUrl,productUrl,registerCanary,capacity,verifyControllerPins,setViewport,ws} from './public-cdp.mjs';
const eventFile=fs.openSync(path.join(D,'events.jsonl'),'wx');let eventBytes=0,done=false,eventFailure=null;
const eventLimit=3*1024*1024,hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function log(value){if(done)return;const text=JSON.stringify({at:new Date().toISOString(),...value})+'\n';if(eventBytes+Buffer.byteLength(text)>eventLimit){eventFailure='Three MiB per-phase event budget reached';return;}eventBytes+=Buffer.byteLength(text);fs.writeSync(eventFile,text);}
const cleanURL=value=>{const raw=String(value),out={scheme:'invalid',rawUrlBytes:Buffer.byteLength(raw),rawUrlSha256:hash(raw)};try{const u=new URL(raw);out.scheme=u.protocol;const pathname=u.origin+u.pathname;if(['http:','https:'].includes(u.protocol)&&Buffer.byteLength(pathname)<=2048)out.url=pathname;}catch{}return out;};
const digest=value=>typeof value==='string'?{bytes:Buffer.byteLength(value),sha256:hash(value)}:null;
events.push(m=>{
 if(m.sessionId&&m.sessionId!==sid)return;
 const p=m.params||{};
 if(m.method==='Runtime.consoleAPICalled'){for(const a of p.args||[])if(typeof a.value==='string'&&a.value.startsWith('P01_HISTORY '))log({method:'DOM.event',measurement:JSON.parse(a.value.slice(12))});}
 else if(m.method?.startsWith('DOMStorage.domStorage'))log({method:m.method,storageId:p.storageId,key:p.key??null,oldValue:digest(p.oldValue),newValue:digest(p.newValue)});
 else if(m.method==='Network.responseReceived')log({method:m.method,requestId:p.requestId,type:p.type,...cleanURL(p.response.url),status:p.response.status,fromServiceWorker:!!p.response.fromServiceWorker,fromDiskCache:!!p.response.fromDiskCache,fromPrefetchCache:!!p.response.fromPrefetchCache,protocol:p.response.protocol});
 else if(m.method==='Network.requestWillBeSent')log({method:m.method,requestId:p.requestId,type:p.type,httpMethod:p.request.method,...cleanURL(p.request.url)});
 else if(m.method==='Page.frameNavigated')log({method:m.method,frameId:p.frame.id,parentId:p.frame.parentId??null,...cleanURL(p.frame.url)});
 else if(m.method==='Network.loadingFailed')log({method:m.method,requestId:p.requestId,errorText:p.errorText,canceled:p.canceled,blockedReason:p.blockedReason??null});
 else if(['Page.backForwardCacheNotUsed','Runtime.exceptionThrown','Inspector.detached','Target.detachedFromTarget'].includes(m.method)||m.method?.startsWith('Browser.download'))log(m);
});
let sid,target,heartbeat,pictureHold;
function finish(){if(done)return;clearInterval(heartbeat);log({closed:true,eventFailure});done=true;fs.closeSync(eventFile);close();}
ws.addEventListener('close',e=>{log({socketClosed:true,code:e.code,reasonBytes:Buffer.byteLength(String(e.reason||'')),reasonSha256:hash(String(e.reason||'')),clean:e.wasClean});});
let stopping=false;async function signalStop(){if(stopping)return;stopping=true;try{await pictureHold?.cleanup('controller-signal');}catch(error){log({holdCleanupError:String(error)});process.exitCode=1;}finally{finish();process.exit(process.exitCode||0);}}process.on('SIGINT',signalStop);process.on('SIGTERM',signalStop);
const lines=readline.createInterface({input:process.stdin});
let number=0,gameNavigated=false,explorerBackIssued=false,productReloadIssued=false,flightIssued=false;const usedCanaries=new Set();
const receiptCount=()=>config.phases.reduce((n,s)=>n+(fs.existsSync(path.join(R,s))?fs.readdirSync(path.join(R,s)).filter(x=>/^action-\d+\.json$/.test(x)).length:0),0);
const screenshotCount=()=>config.phases.reduce((n,s)=>n+(fs.existsSync(path.join(R,s))?fs.readdirSync(path.join(R,s)).filter(x=>x.endsWith('.png')).length:0),0);
function elementExpression(selector){return`(()=>{const nodes=document.querySelectorAll(${JSON.stringify(selector)});if(nodes.length!==1)return{matches:nodes.length};const e=nodes[0],r=e.getBoundingClientRect(),x=Math.max(1,Math.min(innerWidth-1,r.x+r.width/2)),y=Math.max(1,Math.min(innerHeight-1,r.y+r.height/2)),hit=document.elementFromPoint(x,y),ancestors=[];let blocked=false;for(let n=e;n;n=n.parentElement){const s=getComputedStyle(n);if(n.hidden||n.inert||s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse')blocked=true;ancestors.push({tag:n.tagName,id:n.id,hidden:n.hidden,inert:n.inert,display:s.display,visibility:s.visibility,open:n.tagName==='DIALOG'?n.open:undefined});}return{matches:1,id:e.id,tag:e.tagName,type:e.type,href:e.href||null,text:e.innerText,disabled:!!e.disabled,rect:r.toJSON(),x,y,hit:!!hit&&(hit===e||e.contains(hit)),hitId:hit?.id,visible:!blocked&&r.width>0&&r.height>0&&r.left>=0&&r.right<=innerWidth&&r.top>=0&&r.bottom<=innerHeight,partiallyVisible:!blocked&&r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight,ancestors};})()`;}
const summaries={
 summary:`(()=>({url:location.href,timeOrigin:performance.timeOrigin,navigation:performance.getEntriesByType('navigation').map(n=>({type:n.type,activationStart:n.activationStart})),body:document.body.innerText.slice(0,32000),bodyTruncated:document.body.innerText.length>32000,active:document.activeElement?.id,bootState:document.documentElement.dataset.bootState,flightState:document.body.dataset.flightState,pictureState:document.body.dataset.pictureState,dialogs:[...document.querySelectorAll('dialog[open]')].map(e=>e.id),buttons:[...document.querySelectorAll('button,a,select')].filter(e=>{const r=e.getBoundingClientRect();return r.width&&r.height&&r.bottom>0&&r.top<innerHeight;}).slice(0,100).map(e=>({id:e.id,tag:e.tagName,text:e.innerText?.slice(0,240),disabled:e.disabled,href:e.href,value:e.value}))}))()`,
 selection:`(()=>({url:location.href,selects:['pack-select','level-select','theme-select','campaign-select'].map(id=>{const e=document.getElementById(id);return e?{id,value:e.value,disabled:e.disabled,options:[...e.options].map(o=>({value:o.value,label:o.textContent,disabled:o.disabled||o.parentElement?.disabled===true,selected:o.selected}))}:{id,missing:true};}),missionButtons:[...document.querySelectorAll('#missions button,#mission-picker-cards button,#mission-picker-older-cards button')].map(e=>({id:e.id,text:e.textContent,disabled:e.disabled,selected:e.classList.contains('selected'),data:{...e.dataset}}))}))()`,

};
async function stableClickTarget(read){
 const started=performance.now(),deadline=started+3000;let previous=null,last=null,observations=0;
 const timeout=()=>new Error('Stable visible enabled hit-tested target not observed within 3000ms: '+JSON.stringify({observations,last}));
 async function boundedRead(){
  const remaining=deadline-performance.now();if(remaining<=0)throw timeout();let timer;
  try{return await Promise.race([Promise.resolve().then(read),new Promise((_,reject)=>{timer=setTimeout(()=>reject(timeout()),Math.ceil(remaining));})]);}
  finally{clearTimeout(timer);}
 }
 while(performance.now()<deadline){
  const e=await boundedRead(),observed=performance.now();last=e;observations++;
  if(observed>=deadline)throw timeout();
  const valid=e?.matches===1&&!e.disabled&&e.hit&&e.visible;
  const signature=valid?JSON.stringify({id:e.id,tag:e.tag,type:e.type,href:e.href,rect:e.rect,x:e.x,y:e.y,hitId:e.hitId}):null;
  if(valid&&previous?.signature===signature&&observed-previous.observed>=300){
   return {...e,stability:{observations,matchingObservationGapMs:observed-previous.observed,elapsedMs:observed-started,deadlineMs:3000}};
  }
  previous=valid?{signature,observed}:null;
  const remaining=deadline-performance.now();if(remaining<=0)throw timeout();
  await new Promise(resolve=>setTimeout(resolve,Math.min(300,Math.ceil(remaining))));
 }
 throw timeout();
}
const pendingExpression=`(()=>{const $=id=>document.getElementById(id),c=$('flight-preparation-cancel'),s=$('flight-preparation-status'),r=c?.getBoundingClientRect(),nodes=[...document.querySelectorAll('#missions .selected')],selected=nodes[0],hit=r&&document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return{url:location.href,picture:document.body.dataset.pictureState,flight:document.body.dataset.flightState,active:document.activeElement?.id,cancelVisible:!!c&&!c.hidden&&!c.disabled&&!!r&&r.width>0&&r.height>0,cancelFullyVisible:!!r&&r.width>0&&r.height>0&&r.left>=0&&r.top>=0&&r.right<=innerWidth&&r.bottom<=innerHeight,cancelHit:!!hit&&(hit===c||c?.contains(hit)),cancelRect:r?.toJSON(),status:s?.textContent,state:s?.dataset.state,dialogs:[...document.querySelectorAll('dialog[open]')].map(e=>e.id),homeOpen:!!$('shell-home')?.open,missionsOpen:!!$('shell-missions')?.open,selection:{packId:$('pack-select')?.value,campaignKey:$('campaign-select')?.value,levelId:$('level-select')?.value,themeId:$('theme-select')?.value,selectedCount:nodes.length,selectedIndex:selected?.dataset.level,selectedName:selected?.querySelector('.name')?.textContent,selectedDisabled:!!selected?.disabled}};})()`;
async function readOnly(name){
 if(name==='pending'){const actual=await evaluate(pendingExpression,sid);return{hold:pictureHold.status(),actual};}
 const files={storage:'read-storage.js',history:'read-storage-owners.js',controls:'observe-controls.js',solo:'observe-solo.js',probe:'probe-uncached-same-origin.js'};
 if(files[name]){if(name==='probe'&&phase!=='02-refused'&&phase!=='03-restored')throw Error('Public refusal probe only belongs to cold/restored phases');return evaluate(fs.readFileSync(path.join(P,files[name]),'utf8'),sid);}
 if(summaries[name])return evaluate(summaries[name],sid);
 if(name==='identity'){
  const expected={gameUrl:identity.url,version:identity.version,sourceRevision:identity.sourceRevision,buildId:identity.buildId,scope:identity.scope,buildInfoPin:identity.buildInfoPin,offlineManifestPin:identity.offlineManifestPin};
  return evaluate(`(async()=>{const expected=${JSON.stringify(expected)};if(location.href!==expected.gameUrl)throw Error('Identity observation requires canonical game');const urls=[new URL('game/build-info.json',expected.scope),new URL('offline-cache.json',expected.scope)],records=[];for(let i=0;i<urls.length;i++){const response=await fetch(urls[i],{cache:'no-store'});if(!response.ok)throw Error('Actual identity response '+response.status);const buffer=await response.arrayBuffer(),bytes=new Uint8Array(buffer),sha256=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join(''),pin=i===0?expected.buildInfoPin:expected.offlineManifestPin;if(bytes.byteLength!==pin.bytes||sha256!==pin.sha256)throw Error('Actual identity bytes differ');records.push({url:urls[i].href,bytes:bytes.byteLength,sha256,value:JSON.parse(new TextDecoder().decode(bytes))});}const b=records[0].value,o=records[1].value;if(b.version!==expected.version||b.sourceRevision!==expected.sourceRevision||o.version!==expected.version||o.buildId!==expected.buildId)throw Error('Actual frozen identity differs');return{observedAt:new Date().toISOString(),url:location.href,timeOrigin:performance.timeOrigin,channel:'release-'+b.version,build:b,offline:{version:o.version,buildId:o.buildId,files:o.files.length,bytes:o.files.reduce((sum,r)=>sum+r.bytes,0)},responsePins:records.map(({url,bytes,sha256})=>({url,bytes,sha256})),controller:navigator.serviceWorker.controller?{scriptURL:navigator.serviceWorker.controller.scriptURL,state:navigator.serviceWorker.controller.state}:null};})()`,sid);
 }
 throw Error('Only fixed read-only observation names are allowed');
}
try{
 ({sessionId:sid,target}=await attachInitial());
 const holdBinding=config.pendingPictureResponse;
 const rows=JSON.parse(fs.readFileSync(identity.manifestPin.path)).files;
 const row=rows.find(x=>x.path===holdBinding.path);
 if(!holdBinding.finalManifestApproved||!row||row.bytes!==holdBinding.bytes||row.sha256!==holdBinding.sha256||holdBinding.url!==new URL(holdBinding.path,identity.scope).href)throw Error('Exact final-manifest approved picture hold remains unresolved');
 pictureHold=createPictureResponseHold({call,sessionId:sid,url:holdBinding.url,log,onFailure:error=>{eventFailure=String(error);}});
 events.push(message=>{pictureHold.observe(message).catch(error=>{eventFailure=String(error);});});
 await call('Page.enable',{},sid);await call('Runtime.enable',{},sid);await call('DOMStorage.enable',{},sid);await call('Network.enable',{},sid);
 await call('Page.addScriptToEvaluateOnNewDocument',{source:fs.readFileSync(path.join(P,'observe-history-events.js'),'utf8')},sid);
 await call('Emulation.setDeviceMetricsOverride',{...config.initialViewport,deviceScaleFactor:1,mobile:false},sid);
 await call('Browser.setDownloadBehavior',{behavior:'deny',eventsEnabled:true});
 log({ready:true,phase,controllerPid:process.pid,targetId:target.targetId,browserPid:launch.pid,profile:launch.profile,browserArguments,controllerManifest});
 console.log(JSON.stringify({ready:true,phase,pid:process.pid,targetId:target.targetId,browserPid:launch.pid}));
 heartbeat=setInterval(()=>{log({heartbeat:true,socketState:ws.readyState});call('Browser.getVersion').catch(e=>{eventFailure=String(e);});},5000);
 for await(const line of lines){
  let receipt={at:new Date().toISOString(),phase,pid:launch.pid,profile:launch.profile,targetId:target.targetId};
  try{
   if(line.length>4096)throw Error('Command byte bound');const command=JSON.parse(line),{action,arg,hold=0}=command;receipt.command=command;
   if(eventFailure)throw Error(eventFailure);if(receiptCount()>=config.limits.maximumActions)throw Error('Whole-run action bound');
   receipt.capacity=capacity('before-native-'+action);receipt.target=await verifyTarget(target.targetId);await call('Page.bringToFront',{},sid);receipt.before=await foreground(sid);
   let navigating=false;
   if(action==='close'){
    await pictureHold.cleanup('before-browser-close');
    try{await call('Browser.close');receipt.result={closeAcknowledged:true,actualPidExit:'Required separately in launcher exit.json'};}
    catch(error){if(ws.readyState!==WebSocket.CLOSED)throw error;receipt.result={closeAcknowledged:false,socketClosed:true,actualPidExit:'Required separately in launcher exit.json'};}
   }else if(action==='pending-picture-cancel'){
    if(phase!=='01-online'||gameNavigated||pictureHold.status().state!=='unused')throw Error('One fresh online pending-picture bundle before other navigation only');
    gameNavigated=true;const journal=[],began=performance.now();let initialCanonicalObserved=false;
    const alive=()=>{if(eventFailure)throw Error(eventFailure);if(performance.now()-began>=40000)throw Error('Pending-picture bundle deadline');};
    const nativeClick=async selector=>{
     if(!['#shell-play','#shell-deploy'].includes(selector))throw Error('Unplanned pending-picture control');
     alive();await verifyTarget(target.targetId);await foreground(sid);
     const element=await stableClickTarget(()=>evaluate(elementExpression(selector),sid));journal.push({step:'native-click-target',selector,element});
     for(const type of ['mouseMoved','mousePressed','mouseReleased']){alive();await call('Input.dispatchMouseEvent',{type,x:element.x,y:element.y,...(type==='mouseMoved'?{}:{button:'left',clickCount:1})},sid);}
    };
    receipt.pendingBundleObservations=journal;
    receipt.result=await cancelPendingPicture({hold:pictureHold,owner:holdBinding.owner,canonicalUrl:identity.url,
     navigate:()=>call('Page.navigate',{url:config.rootEntryUrl},sid),
     read:async()=>{alive();const current=await verifyTarget(target.targetId,{initialPending:!initialCanonicalObserved});if(current===null)return{url:null,initialNavigationPending:true};if(current.url===identity.url)initialCanonicalObserved=true;const actual=await evaluate(pendingExpression,sid);if(actual.url===identity.url)initialCanonicalObserved=true;return actual;},
     click:nativeClick,record:row=>journal.push(row),
     escape:async()=>{alive();await verifyTarget(target.targetId);await foreground(sid);const key={key:'Escape',code:'Escape',windowsVirtualKeyCode:27};try{await call('Input.dispatchKeyEvent',{type:'keyDown',...key},sid);}finally{await call('Input.dispatchKeyEvent',{type:'keyUp',...key},sid);}}
    });
   }else if(action==='navigate'){
    if(phase==='01-online'||arg!=='game'||gameNavigated)throw Error('Online navigation belongs to the pending-picture bundle; later phases navigate once');gameNavigated=true;receipt.result=await call('Page.navigate',{url:phase==='01-online'?config.rootEntryUrl:identity.url},sid);navigating=true;
   }else if(action==='canary'){
    if(phase!=='02-refused'||gameNavigated||!['http','https'].includes(arg)||usedCanaries.has(arg))throw Error('One pre-game canary per protocol only');usedCanaries.add(arg);const url=arg+'://p01-refusal.invalid/'+crypto.randomUUID();registerCanary(url);receipt.canary=url;receipt.result=await call('Page.navigate',{url},sid);navigating=true;
   }else if(action==='disable-http-cache'){
    if(phase!=='02-refused'||gameNavigated)throw Error('HTTP-cache setting only before the cold game navigation');await call('Network.setCacheDisabled',{cacheDisabled:true},sid);receipt.result={httpCacheDisabled:true,serviceWorkerBypassChanged:false};
   }else if(action==='read'){receipt.result=await readOnly(arg);}
   else if(action==='inspect'){if(typeof arg!=='string'||arg.length>300)throw Error('Selector bound');receipt.result=await evaluate(elementExpression(arg),sid);}
   else if(action==='shot'){
    if(!/^[a-z0-9-]{1,70}$/.test(arg)||screenshotCount()>=config.limits.maxScreenshots)throw Error('Screenshot bound');const image=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false},sid),bytes=Buffer.from(image.data,'base64');if(bytes.readUInt32BE(16)!==receipt.before.width||bytes.readUInt32BE(20)!==receipt.before.height)throw Error('PNG differs from actual same-target viewport');const file=path.join(D,arg+'.png');fs.writeFileSync(file,bytes,{flag:'wx'});receipt.result={file,bytes:bytes.length,sha256:hash(bytes)};
   }else if(action==='click'||action==='wheel'){
    if(!productUrl(receipt.before.url)||typeof arg!=='string'||arg.length>300)throw Error('Native product selector required');const e=action==='click'?await stableClickTarget(()=>evaluate(elementExpression(arg),sid)):await evaluate(elementExpression(arg),sid);receipt.element=e;
    if(e.matches!==1||e.disabled||!e.hit||(action==='click'?!e.visible:!e.partiallyVisible))throw Error('Actual visible enabled top-layer target refused');
    if(action==='wheel'){const deltaY=Number(command.deltaY);if(!Number.isFinite(deltaY)||Math.abs(deltaY)>800)throw Error('Wheel bound');await call('Input.dispatchMouseEvent',{type:'mouseWheel',x:e.x,y:e.y,deltaX:0,deltaY},sid);}
    else{if(e.id==='picture-reload'){if(phase!=='01-online'||!explorerBackIssued||productReloadIssued)throw Error('One direct product Reload after actual Back only');productReloadIssued=true;}if(e.tag==='A'&&e.href&&!productUrl(e.href)&&!e.href.startsWith('blob:'))throw Error('Link leaves exact public routes');navigating=e.tag==='A'&&productUrl(e.href)||e.id==='picture-reload';for(const type of ['mouseMoved','mousePressed','mouseReleased'])await call('Input.dispatchMouseEvent',{type,x:e.x,y:e.y,...(type==='mouseMoved'?{}:{button:'left',clickCount:1})},sid);}
   }else if(action==='flight'){
    if(flightIssued||!['01-online','02-refused'].includes(phase)||receipt.before.url!==identity.url||!['#shell-deploy','#start-button'].includes(arg))throw Error('One bounded ordinary flight per online/refused phase only');
    const state=await evaluate('({picture:document.body.dataset.pictureState,flight:document.body.dataset.flightState})',sid);if(state.picture!=='ready'||!['briefing','paused'].includes(state.flight))throw Error('Actual ready non-running start required');
    const e=await stableClickTarget(()=>evaluate(elementExpression(arg),sid));receipt.element=e;flightIssued=true;const started=performance.now();let running=null;
    const nativeKey=async name=>{const k={key:name,code:name,windowsVirtualKeyCode:name==='Escape'?27:39};await call('Input.dispatchKeyEvent',{type:'keyDown',...k},sid);if(name==='ArrowRight')await new Promise(r=>setTimeout(r,120));await call('Input.dispatchKeyEvent',{type:'keyUp',...k},sid);};
    try{
     for(const type of ['mouseMoved','mousePressed','mouseReleased'])await call('Input.dispatchMouseEvent',{type,x:e.x,y:e.y,...(type==='mouseMoved'?{}:{button:'left',clickCount:1})},sid);
     const until=performance.now()+1500;
     while(performance.now()<until){const sample=await evaluate('({picture:document.body.dataset.pictureState,flight:document.body.dataset.flightState})',sid);if(sample.flight==='running'){running=sample;break;}await new Promise(r=>setTimeout(r,30));}
     if(!running)throw Error('Actual running state not observed before pause; do not label pending cancellation a flight');
     await nativeKey('ArrowRight');
    }finally{await nativeKey('Escape');}
    const stopped=await evaluate('({picture:document.body.dataset.pictureState,flight:document.body.dataset.flightState})',sid),elapsedMs=performance.now()-started;receipt.result={initial:state,actualRunning:running,afterEscape:stopped,elapsedMs,nativeInputs:['visible Start/Deploy pointer','ArrowRight120ms','Escape']};
    if(elapsedMs>10000||stopped.flight!=='paused')throw Error('Bounded real flight did not pause within ten seconds');
   }else if(action==='key'){
    if(!productUrl(receipt.before.url))throw Error('Keys only belong to product pages');const keys={Escape:27,Tab:9,Enter:13,Space:32,ArrowDown:40,ArrowUp:38,ArrowLeft:37,ArrowRight:39,PageDown:34,PageUp:33,Home:36,End:35},name=arg==='Shift+Tab'?'Tab':arg;if(!keys[name]||!Number.isFinite(hold)||hold<0||hold>350)throw Error('Native key/hold bound');if(name==='Enter'||name==='Space'){const active=await evaluate('({id:document.activeElement?.id,tag:document.activeElement?.tagName,href:document.activeElement?.href})',sid);receipt.keyTarget=active;if(active.id==='picture-reload'){if(phase!=='01-online'||!explorerBackIssued||productReloadIssued)throw Error('One direct product Reload after actual Back only');productReloadIssued=true;}if(active.tag==='A'&&active.href&&!productUrl(active.href)&&!active.href.startsWith('blob:'))throw Error('Focused link leaves exact public routes');navigating=name==='Enter'&&active.tag==='A'&&productUrl(active.href)||active.id==='picture-reload';}const key={key:name==='Space'?' ':name,code:name,windowsVirtualKeyCode:keys[name],modifiers:arg==='Shift+Tab'?8:0};await call('Input.dispatchKeyEvent',{type:'keyDown',...key},sid);if(hold)await new Promise(r=>setTimeout(r,hold));await call('Input.dispatchKeyEvent',{type:'keyUp',...key},sid);
   }else if(action==='viewport'){
    if(phase!=='01-online'||!explorerBackIssued||productReloadIssued||!['portrait','landscape'].includes(arg))throw Error('Only bounded post-Back recovery geometry sample');await setViewport(arg,sid);receipt.result={viewport:arg};
   }else if(action==='back'){
    if(explorerBackIssued||receipt.before.url!==config.explorer)throw Error('One Back must originate from actual Release Explorer');const history=await call('Page.getNavigationHistory',{},sid),entry=history.entries[history.currentIndex-1];receipt.history=history;if(!entry||entry.url!==identity.url)throw Error('Immediate history predecessor is not the canonical game');await call('Page.navigateToHistoryEntry',{entryId:entry.id},sid);explorerBackIssued=true;navigating=true;
   }else throw Error('Unknown bounded action');
   receipt.after=action==='close'?null:navigating?{navigationIssued:true,requiresNextForegroundObservation:true}:await foreground(sid);receipt.ok=true;
  }catch(error){receipt.ok=false;receipt.error=String(error.stack);}
  const file=path.join(D,`action-${String(++number).padStart(3,'0')}.json`),body=JSON.stringify(receipt,null,2)+'\n';if(Buffer.byteLength(body)>3*1024*1024)throw Error('Action receipt bound');fs.writeFileSync(file,body,{flag:'wx'});console.log(JSON.stringify({receipt:file,ok:receipt.ok,...(receipt.result?{result:receipt.result}:{}),...(receipt.error?{error:receipt.error}:{})}));
  if(!receipt.ok||receipt.command?.action==='close'){if(!receipt.ok)process.exitCode=1;break;}
 }
 verifyControllerPins();
}catch(error){log({fatal:String(error.stack)});process.exitCode=1;console.error(String(error.stack));}
finally{lines.close();try{await pictureHold?.cleanup('controller-finally');}catch(error){log({holdCleanupError:String(error)});process.exitCode=1;}finish();}
