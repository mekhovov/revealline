# Commands remain blocked until actual final binding and fresh root GO

No command here grants authorization. The config, identity and root authorization deliberately contain null final authority. Do not insert114a or prior publicv573 authority as defaults. No browser/server/proxy/network was run during this preparation.

1. Root supplies actual final qualified source/tree/version, released originals/Q, frozen build/offline manifest, actual controller/run/deployment and successful full HTTP result originals, plus independent parent byte review. Bind `verified-public-identity.json` using its retained P2 schema; derive every count/byte/build ID from those originals. Set config baseSource/sourceRevision/sourceTree and scope/publicScope/channel from originals. The actual root HTML target is canonical game/index.html: identity.url/config.game must equal the game/index.html target in original current-entry-routing.json. Bind rootEntryRoutingPin to that actual public original and its matching full-audit root HTML/worker overrides. Do not carry the older /game/ URL default. Keep the actual canonical Explorer URL. Rehash the preparation-only files, then bind `originalPreparationManifestPin` to that manifest (the config itself is pinned by the separate launcher manifest to avoid a self-reference).
2. Root supplies the actual final-source pending-preparation correction review and approved finite native cancellation plan. Set both config pins and matching authorization pins; keep physical controller coverage separate. All three executable manifests must match actual files. Pin the predecessor P2 manifest unchanged; do not copy its passing sub-results into the new run.
3. Root independently reviews the fully populated helpers/binding, fresh live authority, serialized peer closure, resource check and absolute output paths. Only then write a new time-bounded root authorization with rootGo:true, status AUTHORIZED_PUBLIC_HISTORY_OFFLINE_BROWSER, family v0574-final-recovery-offline, manualAttempt1, exact source/version/scope and all required pins. Initial run output must not exist. The latest peer closure must be real, not this run's intended receipt.
4. Check binding without launching anything:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r2/public_binding.py
PYTHONDONTWRITEBYTECODE=1 python3 /Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r2/public_capacity.py --actual-binding --stage before-public
```

5. Launch only01-online and its interactive driver in separate owned sessions. Driver MUST use exec_command tty:true; send the single pending-picture-cancel command immediately after ready. Do not insert identity reads or other operator turns inside its hold interval. The bundle itself reads actual controls and allows bounded asynchronous readiness; all subsequent commands remain one at a time. The flight command is a finite bundle of actual native inputs, not a game-state mutation: it requires ready/non-running, clicks the visible target, reads only two data attributes until real running≤1.5s, ArrowRight120ms then Escape in finally, and checks paused≤10s. No broad observation while live. One such bundle each in online/refused phases; none restored.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r2/launch-public-chrome.py --go --phase 01-online
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node /Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r2/public-driver.mjs --phase 01-online
```

6. First online input, supplied to the interactive driver stdin:

```json
{"action":"pending-picture-cancel"}
```

This is one finite command, with an unchanged 20-second armed/held emergency timer, a 40-second total bound and up to 100 bounded read-only DOM samples. It arms and navigates before the first image response, verifies exact Base First Signal, clicks only visible `#shell-play` and `#shell-deploy`, requires actual pending feedback/Cancel while that response remains held, sends native Escape, releases the original once, and checks settled cancellation twice at least 300 ms apart. No manual arm/release or online navigate command is allowed. On any refusal, preserve the receipt and close the owned browser; do not continue to Orchard or reuse the partially completed command.

After success, `read/identity`, `read/summary` and `read/selection` establish the actual browser identity and available normal controls. Return to the title through the visible Main menu control, then follow PLAN.md's original Orchard/history/offline sequence. Commands remain: read identity, summary, selection, history, controls, storage, solo, pending; viewport portrait/landscape only after Back and before direct Reload; inspect selector; click selector; native key with optional hold≤350ms; wheel≤800px; shot bounded name; real Back from exact Explorer once; bounded flight with arg #shell-deploy or #start-button; close. `navigate/game` is allowed only once in each later phase. `reload`, `downloads-on`, `arm-picture-hold` and `release-picture-hold` are absent. Only the actual product picture-reload button after observed Back is allowed once; zero download files/bytes. No gamepad injection exists. All pointer clicks require two matching visible/hit rectangles 300 ms apart within 3 seconds.

7. After online Chrome/controller are fully closed and root checks their exact PID/port receipts, start the original refusal proxy in its own process with absolute paths. Proxy command:

```sh
python3 /Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r2/refusal_proxy.py --ready /Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r2/run/refusal-proxy-ready.json --events /Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r2/run/refusal-events.jsonl --max-events 1000
```

Use the same launch/driver commands with02-refused. Before game navigation, native canary/http then canary/https must produce real refusal with proxy correlation; disable-http-cache remains a separately recorded cold-browser setting, never service-worker bypass. Use identity/solo/history and uncached probe after actual cached document arrival. Same-profile real offline Verify must derive the actual complete inventory. Preserve every failed boundary.
8. Close/reap refused Chrome/controller; only then close/reap the exact owned refusal proxy. Launch03-restored with no proxy, observe uncached restoration, identity and retained saved endpoint, then close/reap. No automatic retries/fourth process. No prior outcome finalizer is copied: emit final classification only from new original receipts.

All90 actions/8PNGs/15MiB evidence/20min-per-process/32MiB peer/512MiB floor guards remain. Owned profile limit is60MiB+2×actual inventory, capped192MiB. Evidence/source symlinks are refused; browser-profile links are metadata only and never followed.
