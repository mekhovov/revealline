// One reviewed native-input bundle. Adapters only read DOM or send real input.
export async function cancelPendingPicture({
  hold, owner, canonicalUrl, navigate, read, click, escape, record,
  now = () => performance.now(), wait = ms => new Promise(resolve => setTimeout(resolve, ms)),
}) {
  const started = now(), deadline = started + 40000;
  let observations = 0;
  const expired = () => {
    if (now() >= deadline) throw Error('Pending-picture bundle exceeded 40000 ms');
    if (['auto-released', 'unobserved', 'abandoned', 'ambiguous-release'].includes(hold.status().state))
      throw Error('Original hold expired or became unproven: ' + hold.status().state);
  };
  const sample = async label => {
    expired();
    if (++observations > 100) throw Error('Pending-picture observation bound');
    const actual = await read();
    expired();
    record({ step: label, elapsedMs: now() - started, actual, hold: hold.status() });
    return actual;
  };
  const until = async (label, predicate, limitMs) => {
    const end = Math.min(deadline, now() + limitMs);
    do {
      const actual = await sample(label);
      if (predicate(actual)) return actual;
      if (now() >= end) break;
      await wait(Math.min(300, end - now()));
    } while (now() < end);
    throw Error('Actual native boundary not observed: ' + label);
  };
  const selection = actual => {
    const s = actual.selection;
    return actual.url === canonicalUrl && s?.packId === owner.packId &&
      s.campaignKey === owner.baseCampaignKey && s.levelId === owner.levelId &&
      s.themeId === owner.themeId && s.selectedCount === 1 &&
      s.selectedIndex === '0' && s.selectedName === owner.levelName && !s.selectedDisabled;
  };
  const cancelled = actual => selection(actual) && actual.flight === 'briefing' &&
    actual.state === 'cancelled' && !!actual.status && !actual.cancelVisible &&
    actual.active === 'start-button' && actual.dialogs.length === 0;
  const originalHeld = () => {
    expired();
    if (hold.status().state !== 'held')
      throw Error('Exact original response is not held; no pending cancellation claim');
  };
  try {
    await hold.arm();
    await navigate();
    const title = await until('canonical-title', a => a.url === canonicalUrl && a.homeOpen, 18000);
    if (!selection(title)) throw Error('Fresh title is not the exact Base First Signal owner');
    // Source75d shell-play opens Missions without selecting the featured pack.
    await click('#shell-play');
    const missions = await until('base-missions', a => a.missionsOpen, 3000);
    if (!selection(missions)) throw Error('Missions changed the exact Base First Signal owner');
    await until('original-held', () => hold.status().state === 'held', 18000);
    originalHeld();
    // Source75d shell-deploy closes Missions, then invokes the original Start.
    await click('#shell-deploy');
    const before = await until('pending-before-escape', a =>
      a.picture === 'pending' && a.flight === 'briefing' && a.state === 'busy' &&
      !!a.status && a.cancelVisible && a.cancelFullyVisible && a.cancelHit &&
      a.dialogs.length === 0, 3000);
    if (!selection(before)) throw Error('Pending launch owner changed before Escape');
    originalHeld();
    await escape();
    const after = await until('cancelled-after-escape', cancelled, 1500);
    originalHeld();
    hold.confirmNativeCancellation();
    await hold.release('after-native-escape');
    const first = await until('released-settled-cancelled', a => {
      const s = hold.status();
      return s.state === 'released' && s.cancelledByNativeEscape && s.settlement && cancelled(a);
    }, 5000);
    const settled = hold.status().settlement;
    if (settled.method !== 'Network.loadingFinished' &&
        !(settled.method === 'Network.loadingFailed' && settled.canceled === true))
      throw Error('Original request did not finish or report an observed cancellation');
    const firstAt = now();
    await wait(300);
    const second = await sample('second-settled-cancelled');
    if (now() - firstAt < 300 || !cancelled(second) || hold.status().state !== 'released')
      throw Error('Second stable cancelled observation failed');
    return {
      status: 'NATIVE_PENDING_CANCEL_OBSERVED', elapsedMs: now() - started, observations,
      owner, before, after, stable: [first, second], requestSettlement: settled,
      deliveryClaim: settled.method === 'Network.loadingFinished'
        ? 'Network completion observed; no response body was read by this adapter.'
        : 'Browser reported request cancellation; no original delivery claim.',
      nativeInputs: ['visible #shell-play pointer', 'visible #shell-deploy pointer', 'Escape'],
    };
  } finally {
    await hold.cleanup('pending-native-bundle-finally');
  }
}
