#!/usr/bin/env python3
"""One final explicitly amended cold completion; preserve all prior attempts/profile."""
from pathlib import Path
import argparse,datetime,fcntl,hashlib,importlib.util,json,os,subprocess,time
from urllib.parse import urlsplit
P=Path(__file__).resolve().parent
DEPENDENCIES={'launch-public-chrome.py': {'path': '/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r7/launch-public-chrome.py', 'bytes': 8122, 'sha256': '1d92c92698226fecb47352c84a89e56912142ae5b3a8cf738403d1a2d4f9c275'}, 'public_binding.py': {'path': '/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r7/public_binding.py', 'bytes': 8430, 'sha256': 'c1d68afa950ecd0e270583974d07e0f0e6b8949bece2ed2f0e07852433b38507'}, 'public_capacity.py': {'path': '/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r7/public_capacity.py', 'bytes': 3202, 'sha256': 'a2b49c13a8ad7fe4b5a4c466f2498bbaab55a10365ad2c451e8a83f488b870d1'}, 'startup_readiness.py': {'path': '/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/public-v0574-recovery-offline-execution-r7/startup_readiness.py', 'bytes': 3198, 'sha256': '93ec0322f8b74d3a510e8ffbec76508f10dccd99dfbce47805a6afbec653c5af'}}
def sha(data):return hashlib.sha256(data).hexdigest()
def pinned(pin):
 p=Path(pin['path']);assert p.is_file() and not any(x.is_symlink() for x in [p,*p.parents])
 data=p.read_bytes();assert len(data)==pin['bytes'] and sha(data)==pin['sha256'],str(p)
 return data
for dependency in DEPENDENCIES.values():pinned(dependency)
spec=importlib.util.spec_from_file_location('retained_public_launcher',P/'launch-public-chrome.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
R=P/'run';PHASE='02-refused-final';D=R/PHASE

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--go',action='store_true');args=ap.parse_args();assert args.go,'Explicit root execution required'
 amendment=json.loads((P/'supplemental-cold-final-launch-amendment.json').read_text())
 assert amendment['rootGo'] is True and amendment['phase']==PHASE and amendment['maximumSeconds']==180 and amendment['starts']==1 and amendment['automaticRestarts']==0
 assert amendment['effectiveWholeFamilyLimits']=={'maximumActions':110,'plannedProcessStarts':5} and amendment['originalWholeFamilyLimits']=={'maximumActions':90,'plannedProcessStarts':3}
 assert pinned(amendment['helperPin'])==Path(__file__).read_bytes()
 for item in amendment['originalPins']:pinned(item)
 identity=base.verify();prior=json.loads((R/'02-refused-completion/launch.json').read_text());end=json.loads((R/'02-refused-completion/exit.json').read_text());failed=json.loads((R/'02-refused-completion/cold-completion.json').read_text())
 assert failed['status']=='FAILED_RETAINED' and len(failed['steps'])==5 and failed['error'].startswith('Error: Expected accessible Verify control')
 assert end['pid']==prior['pid'] and end['exitCode']==0 and end['pidExited'] is True and end['endpointClosed'] is True
 assert base.gone(prior['pid']) and base.closed(prior['port']),'Prior browser PID/endpoint still live'
 profile=R/'profile';assert profile.is_dir() and not profile.is_symlink() and prior['profile']==str(profile)
 assert prior['identitySha256']==sha((P/'verified-public-identity.json').read_bytes())
 assert not D.exists(),'Exclusive supplemental phase already exists; no retry/reset'
 lock=(P/'serial-browser.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 proc=None;port=None;started=None;result=None
 try:
  assert not base.peers(),'Another owned P01 browser is active'
  proxy=json.loads((R/'refusal-proxy-ready.json').read_text());assert proxy==prior['proxy']
  u=urlsplit(proxy['proxy']);assert u.scheme=='http' and u.hostname=='127.0.0.1' and u.port==proxy['port'] and not u.username and not u.password and u.path in ['', '/']
  assert proxy['events']==str(R/'refusal-events.jsonl') and proxy['upstreamConnections']=='none-by-construction' and proxy['maxEvents']==1000
  assert not base.gone(proxy['pid']) and not base.closed(proxy['port']),'Refusal proxy not alive'
  command=subprocess.check_output(['ps','-p',str(proxy['pid']),'-o','command='],text=True)
  assert all(x in command for x in [str(P/'refusal_proxy.py'),str(R/'refusal-proxy-ready.json'),str(R/'refusal-events.jsonl')]),'Proxy ownership differs'
  argv=prior['arguments'];assert argv[0]=='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' and argv[-1]=='about:blank'
  assert all(x in argv for x in ['--remote-debugging-port=0','--user-data-dir='+str(profile),'--proxy-server='+proxy['proxy'],'--proxy-bypass-list=<-loopback>','--disable-quic']) and '--no-proxy-server' not in argv
  assert sum(x.startswith('--user-data-dir=') for x in argv)==1 and sum(x.startswith('--proxy-server=') for x in argv)==1
  capacity=base.check('before-supplemental-launch',identity)
  D.mkdir();base.write(D/'preflight.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'priorPidClosed':prior['pid'],'priorPortClosed':prior['port'],'proxy':proxy,'proxyCommand':command.strip(),'otherP01Browsers':[],'capacity':capacity,'amendment':amendment})
  assert not base.peers(),'Peer appeared before launch'
  env={k:v for k,v in os.environ.items() if k.lower() not in {'http_proxy','https_proxy','all_proxy','no_proxy'} and not k.startswith('AGENT_BROWSER_')}
  started=time.time();deadline=time.monotonic()+180
  proc=subprocess.Popen(argv,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  spawn={'phase':PHASE,'startedAt':started,'pid':proc.pid,'profile':str(profile),'arguments':argv,'maximumSeconds':180,'readinessDeadlineSeconds':20,'starts':1,'automaticRestart':False}
  base.write(D/'spawn.json',spawn);print(json.dumps(spawn),flush=True)
  notes=D/'startup-readiness.jsonl';notes.open('x').close();rows=0;size=0
  def note(value):
   nonlocal rows,size
   data=json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),**value})+'\n';rows+=1;size+=len(data.encode());assert rows<=256 and size<=131072
   with notes.open('a') as f:f.write(data)
  port,version=base.wait_for_owned_endpoint(profile,proc,started,note=note)
  pf=profile/'DevToolsActivePort';assert pf.is_file() and not pf.is_symlink() and pf.stat().st_mtime>=started
  raw=pf.read_bytes();assert len(raw)<=1024;parts=raw.decode().splitlines();endpoint=urlsplit(version['webSocketDebuggerUrl'])
  assert len(parts)==2 and int(parts[0])==port and endpoint.scheme=='ws' and endpoint.hostname in ['127.0.0.1','localhost'] and endpoint.port==port and endpoint.path==parts[1]
  command=subprocess.check_output(['ps','-p',str(proc.pid),'-o','command='],text=True);assert '--user-data-dir='+str(profile) in command
  assert proc.pid!=prior['pid'] and version['webSocketDebuggerUrl']!=prior['endpoint']
  receipt={**prior,'phase':PHASE,'startedAt':started,'pid':proc.pid,'endpoint':version['webSocketDebuggerUrl'],'port':port,'version':version,'profileReset':False,'maximumSeconds':180,'deadlineUtc':datetime.datetime.fromtimestamp(started+180,datetime.timezone.utc).isoformat(),'priorPhase':'02-refused-completion','priorPid':prior['pid'],'serialization':{'otherP01Browsers':[],'ownerLock':str(P/'serial-browser.lock'),'conservativePeerReserveBytes':33554432},'supplementalScope':amendment['scope'],'effectiveWholeFamilyLimits':amendment['effectiveWholeFamilyLimits'],'originalWholeFamilyLimits':amendment['originalWholeFamilyLimits'],'amendmentSha256':sha((P/'supplemental-cold-final-launch-amendment.json').read_bytes())}
  base.write(D/'launch.json',receipt);print(json.dumps(receipt),flush=True)
  while proc.poll() is None:
   assert time.monotonic()<deadline,'Supplemental 180-second deadline'
   assert all(x['pid']==proc.pid and x['profile']==str(profile) for x in base.peers()),'Another P01 browser appeared'
   base.check('running',identity,PHASE);time.sleep(min(2,max(0,deadline-time.monotonic())))
  for _ in range(10):
   if base.closed(port):break
   time.sleep(.1)
  result={'phase':PHASE,'pid':proc.pid,'exitCode':proc.returncode,'pidExited':base.gone(proc.pid),'endpointClosed':base.closed(port),'capacity':base.check('after-exit',identity,PHASE)}
  base.write(D/'exit.json',result)
  assert result['exitCode']==0 and result['pidExited'] and result['endpointClosed'],'Closure failed; preserve originals'
 except BaseException as error:
  if proc and proc.poll() is None:
   proc.terminate()
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
  if D.exists():
   base.write(D/'launch-failure.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'type':type(error).__name__,'message':str(error),'phase':PHASE,'ownedPid':proc.pid if proc else None,'noAutomaticRetry':True})
   if not (D/'exit.json').exists():base.write(D/'exit.json',{'phase':PHASE,'pid':proc.pid if proc else None,'exitCode':proc.returncode if proc else None,'pidExited':base.gone(proc.pid) if proc else True,'endpointClosed':base.closed(port) if port else None,'startupCompleted':port is not None,'failed':True})
  raise
 finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
if __name__=='__main__':main()
