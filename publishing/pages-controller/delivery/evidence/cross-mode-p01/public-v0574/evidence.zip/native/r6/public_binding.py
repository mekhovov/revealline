"""Read-only launch gate. No network, process launch, or output creation on import/check."""
from pathlib import Path
from urllib.parse import urlparse
from datetime import datetime, timezone
import hashlib, json, re
P=Path(__file__).resolve().parent
C=json.loads((P/'public-launch-config.json').read_text())
ROOTS=[Path(C['sourceRoot']).resolve(),Path(C['authorityRoot']).resolve()]
def raw(pin):
 assert isinstance(pin,dict) and type(pin.get('bytes')) is int and 0<=pin['bytes']<=16*1024*1024, 'Missing/bounded evidence pin'
 assert re.fullmatch('[a-f0-9]{64}',pin.get('sha256') or ''), 'Missing evidence SHA'
 path=Path(pin['path']);assert path.is_absolute() and '..' not in path.parts and path.is_file()
 assert not any(x.is_symlink() for x in [path,*path.parents])
 path=path.resolve();assert any(path.is_relative_to(root) for root in ROOTS)
 data=path.read_bytes();assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'], 'Evidence pin mismatch: '+str(path)
 return data
def value(pin):return json.loads(raw(pin))
def verify():
 v=json.loads((P/'verified-public-identity.json').read_text())
 a=json.loads((P/'root-authorization.json').read_text())
 assert a.get('status')=='AUTHORIZED_PUBLIC_HISTORY_OFFLINE_BROWSER' and a.get('rootGo') is True
 assert a.get('family')==C.get('family')=='v0574-final-recovery-offline' and a.get('manualAttempt')==C.get('manualAttempt')==4, 'Exact fresh family authorization required'
 assert re.fullmatch('[a-f0-9]{40}',C.get('baseSource') or '') and re.fullmatch('[a-f0-9]{40}',C.get('sourceTree') or ''), 'Final corrected source remains unresolved'
 assert a['priorEvidenceManifestPin']==C['priorEvidenceManifestPin'];raw(a['priorEvidenceManifestPin'])
 for key in ['pendingPreparationFixReviewPin','pendingPreparationNativePlanPin']:
  assert a[key]==C[key];raw(a[key])
 assert a.get('pendingPreparationReviewApproved') is True, 'Pending Escape/controller Back correction and bounded native plan require actual review'
 raw(a['priorBrowserClosurePin'])
 assert C['sourceRevision']==C['baseSource']
 assert a['sourceRevision']==v['sourceRevision']==C['baseSource'] and a['sourceTree']==v['sourceTree']==C['sourceTree']
 assert a['version']==v['version']==C['version'] and a['scope']==v['scope']==C['publicScope']
 assert C['game']==v['url'] and C['scope']==v['scope']
 assert v['url']==v['scope']+'game/index.html' and v['expectedSaveChannel']==C['expectedChannel']
 assert a['peerReservedBytes']==C['futureRootReservedBytes']==33554432
 assert a.get('serializedExecution') is True and C['serializedExecutionRequired'] is True
 assert datetime.fromisoformat(a['notBefore'].replace('Z','+00:00'))<=datetime.now(timezone.utc)<=datetime.fromisoformat(a['expiresAt'].replace('Z','+00:00')), 'GO not current'
 assert Path(a['publicIdentityPin']['path'])==P/'verified-public-identity.json'
 assert value(a['publicIdentityPin'])==v
 assert a['preparationManifestPin']==C['originalPreparationManifestPin']
 for key,name in [('preparationManifestPin','preparation-manifest.json'),('launcherManifestPin','launcher-preparation-manifest.json')]:
  m=value(a[key]);assert Path(a[key]['path'])==P/name
  assert len(m['files'])==m['count'] and len({row['path'] for row in m['files']})==m['count']
  for row in m['files']:
   path=Path(row['path']);assert not path.is_absolute() and '..' not in path.parts
   raw({'path':str(P/path),'bytes':row['bytes'],'sha256':row['sha256']})
 for key in ['controllerCommit','controllerTree']:assert re.fullmatch('[a-f0-9]{40}',v.get(key) or '')
 for key in ['buildId']:assert re.fullmatch('[a-f0-9]{64}',v.get(key) or '')
 for key in ['releaseId','deploymentId','publicationRunId']:assert type(v.get(key)) is int and v[key]>0
 assert v.get('authorizedPublicRun') is True and v.get('sourceQualificationPassed') is True
 q=value(v['qualificationPin']);assert q['passed'] is True and q['version']==C['version'] and q['sourceRevision']==C['baseSource'] and q['sourceTree']==C['sourceTree']
 assert len(q['gates'])==6 and {g['gate'] for g in q['gates']}=={'validate','lint','format','native-format','motion-syntax','test'}
 assert all(g['step']['status']=='completed' and g['step']['conclusion']=='success' for g in q['gates'])
 release=value(v['releaseMetadataPin']);assert release['id']==v['releaseId'] and release['tag_name']==C['version'] and release['draft'] is False and release.get('published_at')
 manifest=value(v['manifestPin']);assert manifest['version']==C['version'] and manifest['sourceRevision']==C['baseSource']
 rows={r['path']:r for r in manifest['files']};assert len(rows)==len(manifest['files'])
 hold=C['pendingPictureResponse'];assert hold['finalManifestApproved'] is True and hold['maxHeldResponses']==1 and hold['maxHoldMs']==20000
 assert hold['url']==v['scope']+hold['path'] and rows[hold['path']]['bytes']==hold['bytes'] and rows[hold['path']]['sha256']==hold['sha256']
 assert C['limits']['pendingPictureBundleSeconds']==40
 assert hold['owner']=={'baseCampaignKey':'first-signal/2/88639f3aab7b6cc1','levelId':'signal-01','levelRevision':'1','themeId':'fpv','slotId':'picture.fpv.26e53164613e83d0','packId':'','campaignId':'first-signal','levelName':'First Signal'}, 'Exact reviewed Base First Signal owner required'
 build=value(v['buildInfoPin']);assert build['version']==C['version'] and build['sourceRevision']==C['baseSource']
 offline=value(v['offlineManifestPin']);assert offline['version']==C['version'] and offline['buildId']==v['buildId']
 assert 0<len(offline['files'])==len({row['path'] for row in offline['files']})
 assert all(type(row['bytes']) is int and row['bytes']>=0 for row in offline['files'])
 offline_bytes=sum(row['bytes'] for row in offline['files'])
 assert offline_bytes>0 and C['limits']['profileBaseBytes']+C['limits']['offlineInventoryMultiplier']*offline_bytes<=C['limits']['maximumProfileBytes']
 for path,pin in [('game/build-info.json',v['buildInfoPin']),('offline-cache.json',v['offlineManifestPin'])]:
  assert rows[path]['bytes']==pin['bytes'] and rows[path]['sha256']==pin['sha256']
 report=value(v['publicHttpReportPin'])
 assert report['status']=='PASS' and report['currentVersion']==C['version'] and report['gameSourceRevision']==C['baseSource'] and report['qualifiedSourceTree']==C['sourceTree']
 for key in ['controllerCommit','controllerTree','deploymentId']:assert report[key]==v[key]
 assert report['runId']==v['publicationRunId']
 results=[json.loads(line) for line in raw(v['publicHttpResultsPin']).decode().splitlines() if line.strip()]
 by_url={r['url']:r for r in results};assert len(by_url)==len(results), 'Duplicate final HTTP result URL'
 routing=value(v['rootEntryRoutingPin'])
 assert routing['version']==C['version'] and routing['sourceRevision']==C['baseSource'] and routing['canonicalSite']==v['scope']
 assert C['rootEntryUrl']==routing['scope']+'game/'
 assert next(r['target'] for r in routing['htmlEntries'] if r['path']=='game/index.html')==v['url']
 rr=by_url[routing['scope']+'current-entry-routing.json']
 assert rr['ok'] and rr['bytesMatch'] and rr['hashMatch'] and rr['bytes']==v['rootEntryRoutingPin']['bytes'] and rr['sha256']==v['rootEntryRoutingPin']['sha256']
 overrides={r['path']:r for r in routing['rootOverrides']}
 for name,kind in [('game/index.html','html-alias'),('service-worker.js','worker-retirement')]:
  o=overrides[name];r=by_url[routing['scope']+name]
  assert o['kind']==kind and r['ok'] and r['bytesMatch'] and r['hashMatch'] and r['bytes']==o['bytes'] and r['sha256']==o['sha256']
 paths=C['criticalPublicPaths']+[r['path'] for r in C['fixtures'] if r['path']!='game/test/fixtures/audio/silence-mpeg1-layer3.mp3']
 for path in paths:
  expected=rows[path];r=by_url[v['scope']+path]
  assert r['ok'] is True and r['status']==200 and r['bytesMatch'] is True and r['hashMatch'] is True and r['contentTypeAccepted'] is True
  assert r['bytes']==expected['bytes'] and r['sha256']==expected['sha256'], 'Actual decoded HTTP bytes differ: '+path
 for f in C['fixtures']:
  data=(Path(C['sourceRoot'])/f['path']).read_bytes();assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256']
  if f['path'] in rows:assert (rows[f['path']]['bytes'],rows[f['path']]['sha256'])==(f['bytes'],f['sha256'])
 # Parent's independent review and exact GO bind original public authorities; this helper does not replace their full audit.
 raw(v['parentPublicReviewPin'])
 return v
if __name__=='__main__':print(json.dumps(verify()))
