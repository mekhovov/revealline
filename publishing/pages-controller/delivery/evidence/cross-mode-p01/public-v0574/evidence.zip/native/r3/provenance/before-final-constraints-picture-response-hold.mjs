// Browser transport only. Never fetch/read/replace a response body or mutate game state.
export function createPictureResponseHold({call,sessionId,url,log,onFailure,timers=globalThis}){
 const bound=20000;let state='unused',paused=null,timer=null,releasing=null,cancelledByNativeEscape=false;
 const status=()=>({state,url,maxHoldMs:bound,request:paused,cancelledByNativeEscape});
 const note=(event,extra={})=>log({pictureResponseHold:event,...status(),...extra});
 const disable=async()=>{await call('Fetch.disable',{},sessionId);};
 async function release(reason){
  if(releasing)return releasing;
  if(state!=='held')throw Error('Exact original response is not currently held: '+state);
  const requestId=paused.requestId;state=reason==='emergency-timeout'?'auto-released':'released';timers.clearTimeout(timer);timer=null;
  releasing=(async()=>{note('release-requested',{reason});try{await call('Fetch.continueRequest',{requestId},sessionId);note('original-response-released',{reason});}catch(error){state='ambiguous-release';note('release-failed',{reason,error:String(error)});throw error;}finally{await disable();}})();
  return releasing;
 }
 async function arm(){
  if(state!=='unused')throw Error('Only one exact original hold can be armed');
  state='armed';await call('Fetch.enable',{patterns:[{urlPattern:url,requestStage:'Response'}]},sessionId);note('armed');
  timer=timers.setTimeout(()=>{if(state==='armed'){state='unobserved';note('no-matching-response');disable().catch(onFailure);onFailure(Error('Exact original response was not observed within hold deadline'));}},bound);
 }
 async function observe(message){
  if(message.sessionId!==sessionId||message.method!=='Fetch.requestPaused')return;
  const p=message.params,request=p.request;
  if(state!=='armed'||paused||request.url!==url||request.method!=='GET'||p.responseStatusCode!==200||p.resourceType!=='Fetch'||p.responseErrorReason){
   await call('Fetch.continueRequest',{requestId:p.requestId},sessionId);throw Error('Unexpected/duplicate intercepted request; original continued unchanged');
  }
  timers.clearTimeout(timer);paused={requestId:p.requestId,networkId:p.networkId??null,url:request.url,method:request.method,status:p.responseStatusCode,resourceType:p.resourceType,responseHeaders:p.responseHeaders||[],heldAt:new Date().toISOString()};state='held';note('held');
  timer=timers.setTimeout(()=>{release('emergency-timeout').catch(onFailure);onFailure(Error('Original response auto-released; pending cancellation cannot pass'));},bound);
 }
 function confirmNativeCancellation(){if(state!=='held')throw Error('Pending interval ended before native Escape');cancelledByNativeEscape=true;note('native-escape-observed');}
 async function cleanup(reason){
  timers.clearTimeout(timer);timer=null;
  if(state==='held')await release(reason);
  else if(releasing)await releasing;
  else if(state==='armed'){state='abandoned';await disable();note('disarmed',{reason});}
 }
 return{arm,observe,status,release,confirmNativeCancellation,cleanup};
}
