import {WebSocket,createTransport,transportOptions} from './ws-transport.mjs';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
export const P=path.dirname(fileURLToPath(import.meta.url)),R=path.join(P,'run');
export const config=JSON.parse(fs.readFileSync(path.join(P,'public-launch-config.json')));
if(process.execPath!==config.websocketNode||Number(process.versions.node.split('.')[0])!==22)throw Error('Explicit configured Node22 is required');
const argv=process.argv.slice(2);
if(argv.length!==2||argv[0]!=='--phase'||!config.phases.includes(argv[1]))throw Error('Exact --phase 01-online|02-refused|03-restored is required');
export const phase=argv[1],D=path.join(R,phase);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const pythonEnv={...process.env,PYTHONDONTWRITEBYTECODE:'1'};
export const identity=JSON.parse(execFileSync('python3',[path.join(P,'public_binding.py')],{encoding:'utf8',env:pythonEnv,timeout:10000,maxBuffer:4*1024*1024}));
export const authorization=JSON.parse(fs.readFileSync(path.join(P,'root-authorization.json')));
export function verifyControllerPins(){
 const pin=authorization.controllerManifestPin,expected=path.join(P,'controller-preparation-manifest.json');
 if(!pin||pin.path!==expected)throw Error('Actual GO must pin the final public controller manifest');
 const raw=fs.readFileSync(expected);if(raw.length!==pin.bytes||hash(raw)!==pin.sha256)throw Error('Controller manifest pin differs');
 const m=JSON.parse(raw);if(m.count!==m.files.length||new Set(m.files.map(x=>x.path)).size!==m.count)throw Error('Controller manifest inventory differs');
 for(const row of m.files){if(typeof row.path!=='string'||path.isAbsolute(row.path)||row.path.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('Unsafe controller pin path');const file=path.join(P,row.path);let at=file;while(at!==P){if(fs.lstatSync(at).isSymbolicLink())throw Error('Symlink controller original');at=path.dirname(at);}const bytes=fs.readFileSync(file);if(bytes.length!==row.bytes||hash(bytes)!==row.sha256)throw Error('Controller file changed: '+row.path);}
 return pin;
}
export const controllerManifest=verifyControllerPins();
export const launch=JSON.parse(fs.readFileSync(path.join(D,'launch.json')));
if(launch.phase!==phase||launch.profile!==config.profile||launch.scope!==identity.scope||launch.game!==identity.url||launch.explorer!==config.explorer)throw Error('Launch phase/profile/public binding differs');
if(launch.identitySha256!==hash(fs.readFileSync(path.join(P,'verified-public-identity.json')))||launch.rootAuthorizationSha256!==hash(fs.readFileSync(path.join(P,'root-authorization.json'))))throw Error('Launch authority changed');
if(launch.serialization.peerAllowanceBytes!==33554432||launch.serialization.otherP01Browsers.length)throw Error('Launch serialization differs');
export function capacity(stage='before-cdp'){
 return JSON.parse(execFileSync('python3',[path.join(P,'public_capacity.py'),'--actual-binding','--stage',stage],{encoding:'utf8',env:pythonEnv,timeout:10000,maxBuffer:1024*1024}));
}
capacity();process.kill(launch.pid,0);
if(!execFileSync('ps',['-p',String(launch.pid),'-o','command='],{encoding:'utf8',timeout:2000}).includes('--user-data-dir='+launch.profile))throw Error('Owned PID/profile mismatch');
const address=new URL(launch.endpoint);
if(address.protocol!=='ws:'||!['127.0.0.1','localhost'].includes(address.hostname)||Number(address.port)!==launch.port||!address.pathname.startsWith('/devtools/browser/'))throw Error('Not the exact owned loopback browser endpoint');
export const ws=createTransport(launch.endpoint),events=[];
let sequence=0,closing=false;const pending=new Map();
let diagnosticBytes=0,diagnosticRows=0,receivedMessages=0,maximumReceivedBytes=0;
const diagnosticFile=path.join(D,'transport-diagnostics.jsonl');fs.writeFileSync(diagnosticFile,'',{flag:'wx'});
function transportDiagnostic(kind,details={}){
 if(diagnosticRows>=64)return;
 const row=JSON.stringify({at:new Date().toISOString(),kind,readyState:ws.readyState,receivedMessages,maximumReceivedBytes,...details})+'\n';
 if(diagnosticBytes+Buffer.byteLength(row)>65536)return;
 fs.appendFileSync(diagnosticFile,row);diagnosticBytes+=Buffer.byteLength(row);diagnosticRows++;
}
function rejectPending(reason){for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error(reason));}pending.clear();}
// Keep this listener after open; do not record raw payloads, close-reason text or exception excerpts.
ws.addEventListener('error',event=>{const e=event.error||event;transportDiagnostic('error',{name:String(e.name||'Error').slice(0,64),code:typeof e.code==='string'?e.code.slice(0,64):null,messageBytes:Buffer.byteLength(String(e.message||'')),messageSha256:hash(String(e.message||''))});closing=true;rejectPending('Owned CDP transport error');});
ws.addEventListener('close',event=>{transportDiagnostic('close',{code:event.code,wasClean:event.wasClean,reasonBytes:Buffer.byteLength(String(event.reason||'')),reasonSha256:hash(String(event.reason||''))});closing=true;rejectPending('Owned CDP socket closed');});
await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{transportDiagnostic('open-timeout');ws.close();reject(Error('Owned CDP open timeout'));},5000);ws.addEventListener('open',()=>{clearTimeout(timer);transportDiagnostic('open',{options:transportOptions,negotiatedExtensions:ws.extensions});resolve();},{once:true});ws.addEventListener('error',()=>{clearTimeout(timer);reject(Error('Owned CDP connection error'));},{once:true});});
ws.addEventListener('message',({data})=>{
 const bytes=Buffer.byteLength(data);receivedMessages++;maximumReceivedBytes=Math.max(maximumReceivedBytes,bytes);
 if(bytes>transportOptions.maxPayload){transportDiagnostic('message-bound-refused',{bytes});close();return;}
 let m;try{m=JSON.parse(data);}catch{transportDiagnostic('non-json-message-refused',{bytes});close();return;}
 const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}else for(const fn of events)fn(m);
});
export const call=(method,params={},sessionId)=>new Promise((resolve,reject)=>{if(closing||ws.readyState!==WebSocket.OPEN)return reject(Error('Owned CDP is closed'));const id=++sequence,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},5000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));});
export const browserArguments=(await call('Browser.getBrowserCommandLine')).arguments;
for(const flag of ['--user-data-dir='+launch.profile,'--disable-quic','--disable-extensions','--enable-automation'])if(!browserArguments.includes(flag))throw Error('Actual browser flag differs: '+flag);
if(phase==='02-refused'){
 if(!browserArguments.includes('--proxy-server='+launch.proxy.proxy)||!browserArguments.includes('--proxy-bypass-list=<-loopback>')||browserArguments.some(x=>x.startsWith('--proxy-pac-url')||x==='--no-proxy-server'||x.startsWith('--proxy-bypass-list=')&&x!=='--proxy-bypass-list=<-loopback>'))throw Error('Actual refusal proxy flags differ');
}else if(!browserArguments.includes('--no-proxy-server')||browserArguments.some(x=>x.startsWith('--proxy-server')||x.startsWith('--proxy-pac-url')))throw Error('Actual online flags differ');
const canaries=new Set();
export function registerCanary(url){const u=new URL(url);if(phase!=='02-refused'||!['http:','https:'].includes(u.protocol)||u.hostname!=='p01-refusal.invalid'||u.search||u.hash)throw Error('Unplanned canary URL');canaries.add(url);}
export const productUrl=url=>url===identity.url||url===config.explorer;
export const allowedUrl=url=>productUrl(url)||url==='about:blank'||(phase==='01-online'&&url===config.rootEntryUrl)||(phase==='02-refused'&&(canaries.has(url)||(canaries.size>0&&url==='chrome-error://chromewebdata/')));
export async function attachInitial(){
 const targets=(await call('Target.getTargets')).targetInfos,pages=targets.filter(t=>t.type==='page');
 if(pages.length!==1||pages[0].url!=='about:blank')throw Error('One unique fresh owned blank page is required');
 const target=pages[0],file=path.join(D,'owned-target.json');
 fs.writeFileSync(file,JSON.stringify({targetId:target.targetId,pid:launch.pid,profile:launch.profile,endpoint:launch.endpoint,controllerManifest},null,2)+'\n',{flag:'wx'});
 const {sessionId}=await call('Target.attachToTarget',{targetId:target.targetId,flatten:true});await call('Page.bringToFront',{},sessionId);return{sessionId,target};
}
export async function verifyTarget(targetId){const targets=(await call('Target.getTargets')).targetInfos,pages=targets.filter(t=>t.type==='page');if(pages.length!==1||pages[0].targetId!==targetId||!allowedUrl(pages[0].url))throw Error('Unknown page target or navigation outside exact public/canary routes');return pages[0];}
export async function evaluate(expression,sessionId){const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessionId);if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
let currentView=config.initialViewport;
export async function setViewport(name,sessionId){const next=config.viewports?.[name];if(!next)throw Error('Unbound viewport');await call('Emulation.setDeviceMetricsOverride',{...next,deviceScaleFactor:1,mobile:false},sessionId);currentView=next;}
export async function foreground(sessionId){const state=await evaluate('({url:location.href,timeOrigin:performance.timeOrigin,visibility:document.visibilityState,hasFocus:document.hasFocus(),active:document.activeElement?.id,width:innerWidth,height:innerHeight,devicePixelRatio,visualViewport:{width:visualViewport.width,height:visualViewport.height,scale:visualViewport.scale}})',sessionId);const metrics=await call('Page.getLayoutMetrics',{},sessionId);if(!allowedUrl(state.url)||state.visibility!=='visible'||state.hasFocus!==true)throw Error('Owned page is not foreground: '+JSON.stringify(state));const view=currentView;if(state.width!==view.width||state.height!==view.height||state.devicePixelRatio!==1||metrics.cssLayoutViewport.clientWidth!==view.width||metrics.cssLayoutViewport.clientHeight!==view.height)throw Error('Actual same-target viewport differs: '+JSON.stringify({state,metrics,expected:view}));return{...state,metrics};}
export function close(){if(closing)return;closing=true;for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('Controller closed'));}pending.clear();ws.close();}
