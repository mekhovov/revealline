# Two distinct retained-profile cutover checks

Both checks are pending actual v0.57.4 publication and separate from the fresh corrective three-process journey. No browser is authorized by this plan.

## Main-repository versioned v0.57.3 → Archive17

The retained public P2 r2 profile is genuine and remains available. Its observed worker scope is https://mekhovov.github.io/revealline/releases/v0.57.3/site/ (02-refused action007 and03-restored action003), with a real saved flight and fully verified cached v0.57.3 inventory. Preserve it for the actual old-main-repository versioned-route cutover to Archive17. Bind its closure/profile/source/worker/storage originals before execution. After cutover, use normal online navigation to that exact old Play URL and observe what the existing worker actually serves, its update/bridge behavior, eventual archive route, same-origin historical save availability and source/version identity. Do not clear caches, unregister workers, replace storage or silently turn it into a fresh profile. A still-served original cached edition is an observed state; it is not proof that the online archive redirect has taken effect. Record the real update/reload controls if needed and wait for root disposition if normal migration is unavailable.

## Root /revealline/ worker update

This is a separate scope. Before publication, root may identify an authentic retained root-scoped v0.57.3 worker/profile receipt. If none exists, it can authorize establishing a genuine current-v0.57.3 root profile through actual /revealline/game/, ordinary flight/save and UI offline preparation. That is real pre-cutover browser evidence, never a fabricated binding. It requires its own serialized browser GO and actual source/inventory/closure pins.

After cutover, retain the old root controller/cache and save/original hashes, open the real main game natively, observe the actual update/activation path, then verify the new source/build/full offline inventory under the root scope. Preserve historical version channels and original bytes. Do not call skipWaiting/register/update or seed storage through JavaScript; use only actual product controls and ordinary allowed reload. No root-worker migration claim follows from the versioned profile alone, and no cold claim follows before actual new inventory verification.
