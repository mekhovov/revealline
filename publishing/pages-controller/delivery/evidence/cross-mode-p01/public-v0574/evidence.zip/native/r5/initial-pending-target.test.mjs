import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import vm from 'node:vm';
import {createHash} from 'node:crypto';
const dir=new URL('./',import.meta.url);
const cdp=fs.readFileSync(new URL('public-cdp.mjs',dir),'utf8');
const driver=fs.readFileSync(new URL('public-driver.mjs',dir),'utf8');
const config=JSON.parse(fs.readFileSync(new URL('public-launch-config.json',dir)));
const identity=JSON.parse(fs.readFileSync(new URL('verified-public-identity.json',dir)));
const guard=cdp.slice(cdp.indexOf('export async function verifyTarget('),cdp.indexOf('export async function evaluate(')).replace('export ','');
const routes=cdp.slice(cdp.indexOf('export const productUrl='),cdp.indexOf('export async function attachInitial(')).replaceAll('export const','const');
const start=driver.indexOf('read:async()=>');
const read=driver.slice(start+'read:'.length,driver.indexOf(',\n     click:',start));
assert(start>0&&read.endsWith('}'));
assert(driver.includes('let initialCanonicalObserved=false;'));
assert.equal((driver.match(/initialPending:!initialCanonicalObserved/g)||[]).length,1);
const page=(url,id='owned')=>({type:'page',targetId:id,url});
function harness(phase='01-online'){
 let targets=[],dom={url:identity.url,homeOpen:true};const counts={calls:0,evaluations:0};
 const context=vm.createContext({Buffer,phase,identity,config,target:{targetId:'owned'},sid:'modeled',pendingExpression:'read-only-modeled',initialCanonicalObserved:false,alive(){},hash:value=>createHash('sha256').update(value).digest('hex'),call:async method=>{assert.equal(method,'Target.getTargets');counts.calls++;return{targetInfos:targets};},evaluate:async()=>{counts.evaluations++;return dom;}});
 vm.runInContext('const canaries=new Set();'+routes+guard+';globalThis.guard=verifyTarget;globalThis.readActual=('+read+');',context);
 return {context,counts,set:rows=>{targets=rows;},dom:value=>{dom=value;},guard:(options)=>context.guard('owned',options),read:()=>context.readActual()};
}
test('default guard refuses empty owned URL and retains actual bounded diagnostic',async()=>{
 const h=harness();h.set([page('')]);await assert.rejects(h.guard(),/"targetId":"owned","type":"page","url":""/);assert.equal(h.counts.evaluations,0);assert.equal(h.counts.calls,1);
});
test('initial exact single owned empty URL reports pending without evaluate or input',async()=>{
 const h=harness();h.set([page('')]);assert.equal(await h.guard({initialPending:true}),null);const result=await h.read();assert.equal(result.initialNavigationPending,true);assert.equal(result.url,null);assert.equal(h.counts.evaluations,0);assert.equal(h.context.initialCanonicalObserved,false);
});
test('wrong ID, multiple pages and unknown nonempty URL refuse even before canonical',async()=>{
 for(const pages of [[page('','other')],[page(''),page('','second')],[page('https://example.invalid/unknown')]]){const h=harness();h.set(pages);await assert.rejects(h.read(),/Unknown page target/);assert.equal(h.counts.evaluations,0);}
});
test('empty URL exception is unavailable in refused and restored phases',async()=>{
 for(const phase of ['02-refused','03-restored']){const h=harness(phase);h.set([page('')]);await assert.rejects(h.guard({initialPending:true}),/Unknown page target/);assert.equal(h.counts.evaluations,0);}
});
test('canonical target observation retires pending before DOM evaluation and later empty refuses',async()=>{
 const h=harness();h.set([page('')]);await h.read();h.set([page(identity.url)]);h.dom({url:config.rootEntryUrl});await h.read();assert.equal(h.context.initialCanonicalObserved,true);assert.equal(h.counts.evaluations,1);h.set([page('')]);await assert.rejects(h.read(),/Unknown page target/);assert.equal(h.counts.evaluations,1);
});
test('canonical DOM observation also retires pending when target snapshot still says root',async()=>{
 const h=harness();h.set([page(config.rootEntryUrl)]);await h.read();assert.equal(h.context.initialCanonicalObserved,true);h.set([page('')]);await assert.rejects(h.read(),/Unknown page target/);assert.equal(h.counts.evaluations,1);
});
test('unchanged pending-bundle helper preserves 300ms/18s canonical and20s hold bounds',()=>{
 const prior=new URL('../public-v0574-recovery-offline-execution-r4/',dir);
 for(const name of ['pending-picture-cancel.mjs','picture-response-hold.mjs'])assert.deepEqual(fs.readFileSync(new URL(name,dir)),fs.readFileSync(new URL(name,prior)));
 assert.equal(config.pendingPictureResponse.maxHoldMs,20000);const bundle=fs.readFileSync(new URL('pending-picture-cancel.mjs',dir),'utf8');assert(bundle.includes("a => a.url === canonicalUrl && a.homeOpen, 18000"));assert(bundle.includes('await wait(Math.min(300, end - now()))'));
});
