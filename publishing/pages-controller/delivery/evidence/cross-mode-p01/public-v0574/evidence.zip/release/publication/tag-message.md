Reveal Line v0.57.4: picture preparation and recovery corrections

Source: 856850ce8d4597c1fb6e8bb28ddb8a63db337a8c
Source qualification SHA-256: 2856e195ad700b54879aebbd257f1cf1d9ea3d58c56a0c2e002d345aa350b9d8
Both hosted suites: 4256 passed. Frozen originals and offline inventory verified. Public P01 acceptance follows deployment.
