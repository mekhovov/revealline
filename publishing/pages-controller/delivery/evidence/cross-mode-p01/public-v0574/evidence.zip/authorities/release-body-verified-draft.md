# v0.57.4 — Picture preparation and recovery return corrections

Closing Library after Export game data preserves the current picture recovery reason, Export/Reload actions and opener focus. Escape or modeled controller Back during an owned pending launch cancels preparation without a late automatic start. Unjoined picture prewarm failures display their inline recovery reason. Recovery panels use the shared text sizes and adapt their width, spacing and scrolling to keep complete explanations and actions reachable. The source and distribution upload fixtures now wait for the finite mock handler before asserting ambiguous-upload results; production upload behavior is unchanged.

Reviewed corrective scope: recovery return, pending launch back, inline prewarm reason, test fixture synchronization.

Exact game source: `856850ce8d4597c1fb6e8bb28ddb8a63db337a8c` (tree `4cd7f24680af174ea35773d28e07e54e5f39e01f`).

All six source gates passed through the hosted exact-source workflow. Each of the two complete four-shard families passed 4,256 tests with zero failures, cancellations, skips or TODOs. Production reproduction/readiness and the ordinary build passed on the hosted source. 7 local lightweight checks provide corroboration. The full test suite and ordinary build were not run locally; no duplicate local execution is claimed.

The separately authenticated hosted utility inspected the complete frozen original artifact. Its source archive matches all 6,307 tracked files and modes. Every one of the 655 game files matches its original manifest. Local assembly rehashes the retained original metadata and preserves exact runner member descriptors for the source and distribution payloads; it does not download or rehash the large originals locally. The attached evidence preserves the selected original qualification and correction observations, including retained earlier failures; it does not replace verification of this release after deployment.

Predecessor: [v0.57.3](https://github.com/mekhovov/revealline/releases/tag/v0.57.3). Before normal main publication, preserve actual predecessor v0.57.3 through accepted Archive17 admission, then complete the normal main publisher PR/merge, deployed byte verification and applicable native play/offline evidence. Source and attachment qualification alone do not establish public correction or P01 acceptance.

At package assembly, public byte/play/offline verification is pending; acceptance is recorded separately after publication. P01 remains unaccepted. Modeled input, browser observations and physical-device qualification remain separate evidence categories.
