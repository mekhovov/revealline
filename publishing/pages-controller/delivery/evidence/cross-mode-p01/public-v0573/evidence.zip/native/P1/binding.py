"""Read-only launch gate. No network, process launch, or output creation on import/check."""
from pathlib import Path
from urllib.parse import urlparse
from datetime import datetime, timezone
import hashlib, json, re
P=Path(__file__).resolve().parent
C=json.loads((P/'config.json').read_text())
ROOTS=[Path(C['sourceRoot']).resolve(),Path(C['authorityRoot']).resolve()]
def raw(pin):
 assert isinstance(pin,dict) and type(pin.get('bytes')) is int and 0<=pin['bytes']<=16*1024*1024, 'Missing/bounded evidence pin'
 assert re.fullmatch('[a-f0-9]{64}',pin.get('sha256') or ''), 'Missing evidence SHA'
 path=Path(pin['path']);assert path.is_absolute() and not path.is_symlink()
 path=path.resolve();assert any(path.is_relative_to(root) for root in ROOTS)
 data=path.read_bytes();assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'], 'Evidence pin mismatch: '+str(path)
 return data
def value(pin):return json.loads(raw(pin))
def verify():
 v=json.loads((P/'verified-public-identity.json').read_text())
 a=json.loads((P/'root-authorization.json').read_text())
 assert a.get('status')=='AUTHORIZED_PUBLIC_CORRECTIVE_BROWSER' and a.get('rootGo') is True
 assert a['sourceRevision']==v['sourceRevision']==C['baseSource'] and a['sourceTree']==v['sourceTree']==C['sourceTree']
 assert a['version']==v['version']==C['version'] and a['scope']==v['scope']==C['publicScope']
 assert v['url']==v['scope']+'game/' and v['expectedSaveChannel']==C['expectedChannel']
 assert a['peerReservedBytes']==C['futureRootReservedBytes']
 assert datetime.fromisoformat(a['notBefore'].replace('Z','+00:00'))<=datetime.now(timezone.utc)<=datetime.fromisoformat(a['expiresAt'].replace('Z','+00:00')), 'GO not current'
 assert Path(a['publicIdentityPin']['path'])==P/'verified-public-identity.json'
 assert value(a['publicIdentityPin'])==v
 m=value(a['preparationManifestPin']);assert Path(a['preparationManifestPin']['path'])==P/'preparation-manifest.json'
 for row in m['files']:
  p=P/row['path'];assert p.resolve().is_relative_to(P) and not p.is_symlink();b=p.read_bytes()
  assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'], 'Controlling preparation changed'
 for key in ['controllerCommit','controllerTree']:assert re.fullmatch('[a-f0-9]{40}',v.get(key) or '')
 for key in ['buildId']:assert re.fullmatch('[a-f0-9]{64}',v.get(key) or '')
 for key in ['releaseId','deploymentId','publicationRunId']:assert type(v.get(key)) is int and v[key]>0
 assert v.get('authorizedPublicRun') is True and v.get('sourceQualificationPassed') is True
 q=value(v['qualificationPin']);assert q['passed'] is True and q['version']==C['version'] and q['sourceRevision']==C['baseSource'] and q['sourceTree']==C['sourceTree']
 assert len(q['gates'])==6 and all(g['step']['status']=='completed' and g['step']['conclusion']=='success' for g in q['gates'])
 release=value(v['releaseMetadataPin']);assert release['id']==v['releaseId'] and release['tag_name']==C['version'] and release['draft'] is False and release.get('published_at')
 manifest=value(v['manifestPin']);assert manifest['version']==C['version'] and manifest['sourceRevision']==C['baseSource']
 rows={r['path']:r for r in manifest['files']};assert len(rows)==len(manifest['files'])
 build=value(v['buildInfoPin']);assert build['version']==C['version'] and build['sourceRevision']==C['baseSource']
 offline=value(v['offlineManifestPin']);assert offline['version']==C['version'] and offline['buildId']==v['buildId']
 for path,pin in [('game/build-info.json',v['buildInfoPin']),('offline-cache.json',v['offlineManifestPin'])]:
  assert rows[path]['bytes']==pin['bytes'] and rows[path]['sha256']==pin['sha256']
 report=value(v['publicHttpReportPin'])
 assert report['status']=='PASS' and report['currentVersion']==C['version'] and report['gameSourceRevision']==C['baseSource'] and report['qualifiedSourceTree']==C['sourceTree']
 for key in ['controllerCommit','controllerTree','deploymentId']:assert report[key]==v[key]
 assert report['runId']==v['publicationRunId']
 results=[json.loads(line) for line in raw(v['publicHttpResultsPin']).decode().splitlines() if line.strip()]
 by_url={r['url']:r for r in results};assert len(by_url)==len(results), 'Duplicate final HTTP result URL'
 paths=C['criticalPublicPaths']+[r['path'] for r in C['fixtures'] if r['path']!='game/test/fixtures/audio/silence-mpeg1-layer3.mp3']
 for path in paths:
  expected=rows[path];r=by_url[v['scope']+path]
  assert r['ok'] is True and r['status']==200 and r['bytesMatch'] is True and r['hashMatch'] is True and r['contentTypeAccepted'] is True
  assert r['bytes']==expected['bytes'] and r['sha256']==expected['sha256'], 'Actual decoded HTTP bytes differ: '+path
 for f in C['fixtures']:
  data=(Path(C['sourceRoot'])/f['path']).read_bytes();assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256']
  if f['path'] in rows:assert (rows[f['path']]['bytes'],rows[f['path']]['sha256'])==(f['bytes'],f['sha256'])
 # Parent's independent review and exact GO bind original public authorities; this helper does not replace their full audit.
 raw(v['parentPublicReviewPin'])
 return v
if __name__=='__main__':print(json.dumps(verify()))
