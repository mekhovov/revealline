import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
export const P=path.dirname(new URL(import.meta.url).pathname),R=path.join(P,'run');
export const config=JSON.parse(fs.readFileSync(path.join(P,'config.json')));
if(process.execPath!==config.websocketNode||Number(process.versions.node.split('.')[0])!==22)throw Error('Explicit configured Node22 is required');
export const launch=JSON.parse(fs.readFileSync(path.join(R,'launch.json')));
execFileSync('python3',[path.join(P,'capacity.py'),'before-cdp']);
process.kill(launch.pid,0);
if(!execFileSync('ps',['-p',String(launch.pid),'-o','command='],{encoding:'utf8'}).includes('--user-data-dir='+launch.profile))throw Error('Owned PID/profile mismatch');
export const ws=new WebSocket(launch.endpoint);let sequence=0;const pending=new Map();
await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{ws.close();reject(Error('Owned CDP connection deadline'));},5000);ws.onopen=()=>{clearTimeout(timer);resolve()};ws.onerror=e=>{clearTimeout(timer);reject(e)};});
export const events=[];
ws.onmessage=({data})=>{const m=JSON.parse(data),p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}else for(const fn of events)fn(m);};
export const call=(method,params={},sessionId)=>new Promise((resolve,reject)=>{const id=++sequence,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP timeout '+method));},5000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));});
const args=(await call('Browser.getBrowserCommandLine')).arguments;
if(!args.includes('--user-data-dir='+launch.profile))throw Error('Actual browser profile mismatch');
export const allowedUrl=url=>config.allowedUrls.includes(url);
export async function attach({initial=false}={}){
 const targets=(await call('Target.getTargets')).targetInfos, file=path.join(R,'owned-target.json');let target;
 if(initial){if(fs.existsSync(file))throw Error('Target already bound');const candidates=targets.filter(t=>t.type==='page'&&t.url==='about:blank');if(candidates.length!==1)throw Error('Fresh owned blank target not unique');target=candidates[0];fs.writeFileSync(file,JSON.stringify({targetId:target.targetId,profile:launch.profile,endpoint:launch.endpoint},null,2)+'\n',{flag:'wx'});}
 else {const owned=JSON.parse(fs.readFileSync(file));if(owned.profile!==launch.profile||owned.endpoint!==launch.endpoint)throw Error('Target receipt differs');target=targets.find(t=>t.targetId===owned.targetId&&t.type==='page'&&allowedUrl(t.url));if(!target)throw Error('Owned target route changed or closed');}
 const others=targets.filter(t=>t.type==='page'&&t.targetId!==target.targetId),identifiedFile=path.join(R,'identified-other-targets.json'),identified=fs.existsSync(identifiedFile)?JSON.parse(fs.readFileSync(identifiedFile)):[];
 if(others.some(t=>!identified.some(i=>i.targetId===t.targetId&&i.url===t.url)))throw Error('Unidentified owned page; preserve and stop');
 const {sessionId}=await call('Target.attachToTarget',{targetId:target.targetId,flatten:true});
 await call('Page.bringToFront',{},sessionId);
 return {sessionId,target};
}
export async function evaluate(expression,sessionId){const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessionId);if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
export async function foreground(sessionId){const state=await evaluate('({url:location.href,visibility:document.visibilityState,hasFocus:document.hasFocus(),active:document.activeElement?.id})',sessionId);if(!allowedUrl(state.url)||state.visibility!=='visible'||state.hasFocus!==true)throw Error('Owned page not foreground: '+JSON.stringify(state));return state;}
export function close(){for(const p of pending.values())clearTimeout(p.timer);ws.close();}
