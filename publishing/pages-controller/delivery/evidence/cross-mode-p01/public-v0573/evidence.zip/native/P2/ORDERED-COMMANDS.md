No command below grants authorization. root-authorization.json currently has rootGo:false. The public source, build and inventory are already actual pinned inputs; current GO/ownership/capacity must still be reviewed.

1. Parent fills new actual root-authorization.json with status AUTHORIZED_PUBLIC_HISTORY_OFFLINE_BROWSER, rootGo:true, manualAttempt:2, fresh notBefore/expiresAt, the supplied original failed-manifest pin, and the current reviewed three manifest/identity pins. Retain32MiB peer reservation and serialized execution. All old authorization originals remain inside provenance.
2. Check the actual binding and fresh capacity:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /Users/oleksandr.mekhovov/work/my_projects/go_test_p01_file_cancel/.cache/cross-mode/p01/public-v0573-history-offline-r2/public_binding.py
PYTHONDONTWRITEBYTECODE=1 python3 /Users/oleksandr.mekhovov/work/my_projects/go_test_p01_file_cancel/.cache/cross-mode/p01/public-v0573-history-offline-r2/public_capacity.py --actual-binding --stage before-r2
```

3. Start the online launcher in its owned session, then the interactive driver only after its actual launch receipt exists:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /Users/oleksandr.mekhovov/work/my_projects/go_test_p01_file_cancel/.cache/cross-mode/p01/public-v0573-history-offline-r2/launch-public-chrome.py --go --phase 01-online
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node /Users/oleksandr.mekhovov/work/my_projects/go_test_p01_file_cancel/.cache/cross-mode/p01/public-v0573-history-offline-r2/public-driver.mjs --phase 01-online
```

Send one JSON command at a time according to public-controller-notes.md. Inspect real UI before actions, not a blind prerecorded sequence. Follow the unchanged three plan files, including both replay downloads before Explorer and one Reload after the observed Back. Verify actual downloads using verify-replay-download.py with real successful action basenames only. A failed command stops; preserve and close the owned browser.

4. After exact online PID/CDP exit, start only the reviewed refusal_proxy.py using its existing `--ready`, `--events` and bounded arguments described in public-launcher-notes.md. Then launch/drive02-refused with the same two commands, replacing phase. Confirm actual negative HTTP/HTTPS canaries and proxy receipts before game navigation. Never change system proxy or populate caches directly.
5. After exact refused browser exit, close/reap only the owned refusal proxy, then launch/drive03-restored with the same commands and phase03-restored. Observe the bounded restoration probes and final identity/storage, then close/reap owned browser.
6. Retain all actions, errors, transport diagnostics, screenshots, download originals, proxy records and per-phase exit receipts. Create a final manifest only after actual completion or an explicitly incomplete terminal report. Paths are relative to this r2 root. Do not claim pending phases, persisted history, replay delivery, offline readiness or P01 acceptance from preparation.
