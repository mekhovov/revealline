from pathlib import Path
import json,shutil,time,datetime,stat,hashlib
P=Path(__file__).resolve().parent; R=P/'run'; C=json.loads((P/'config.json').read_text()); A=json.loads((P/'root-authorization.json').read_text())
def check(stage):
 assert A['status']=='AUTHORIZED_BOUNDED_PUBLIC_TRANSFER_RECOVERY' and A['sourceRoot']==C['sourceRoot']
 if stage in ['before-server','before-launch','final']:
  for row in json.loads((P/'input-pins.json').read_text())['source']:
   d=(Path(C['sourceRoot'])/row['path']).read_bytes(); assert len(d)==row['bytes'] and hashlib.sha256(d).hexdigest()==row['sha256'],row['path']
 profile=evidence=allocated=downloads=count=0
 profile_root=Path(C['profilePath'])
 for f in list(R.rglob('*'))+list(profile_root.rglob('*')):
  st=f.lstat()
  if not stat.S_ISREG(st.st_mode):continue
  allocated+=st.st_blocks*512
  if f.is_relative_to(profile_root):profile+=st.st_size
  elif f.is_relative_to(R/'downloads'):
   downloads+=st.st_size;count+=not f.name.endswith('.crdownload')
  else:evidence+=st.st_size
 l=C['limits'];free=shutil.disk_usage(P).free;allowance=max(0,l['profileBytes']-profile)+max(0,l['evidenceBytes']-evidence)+max(0,l['downloadsBytes']-downloads);projected=free-allowance-C['futureRootReservedBytes']
 rec={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':stage,'freeBytes':free,'projectedReserveBytes':projected,'profileBytes':profile,'evidenceBytes':evidence,'allocatedBytes':allocated,'downloadBytes':downloads,'downloadFiles':count}
 with (R/'capacity.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 assert projected>=l['minimumProjectedFreeBytes'] and profile<=l['profileBytes'] and evidence<=l['evidenceBytes'] and allocated<=l['maximumActualNewDiskBytes'] and downloads<=l['downloadsBytes'] and count<=l['downloadFiles'],rec
 if stage not in ['final','after-exit'] and (R/'launch.json').exists():assert time.time()-json.loads((R/'launch.json').read_text())['startedAt']<=l['browserSeconds'],'Browser deadline'
 return rec
if __name__=='__main__':print(json.dumps(check(__import__('sys').argv[1] if len(__import__('sys').argv)>1 else 'explicit')))
