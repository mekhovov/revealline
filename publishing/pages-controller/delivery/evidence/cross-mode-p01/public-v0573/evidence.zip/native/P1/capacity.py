from pathlib import Path
import os,json,shutil,time,datetime,stat,hashlib,re
P=Path(__file__).resolve().parent;R=P/'run';C=json.loads((P/'config.json').read_text())


def check(stage):
 remaining=0
 if stage=='before-launch':
  from binding import verify
  verify()
  for pin in C['fixtures']:
   data=(Path(C['sourceRoot'])/pin['path']).read_bytes()
   assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'], 'Approved local fixture changed'
 profile=evidence=downloads=allocated=0;count=0
 for p in R.rglob('*'):
  try: st=p.lstat()
  except FileNotFoundError: continue # Chrome may retire a cache file during the walk; current df still bounds allocation.
  if not stat.S_ISREG(st.st_mode):continue
  allocated+=st.st_blocks*512
  if p.is_relative_to(R/'profile'):profile+=st.st_size
  elif p.is_relative_to(R/'downloads'):
   downloads+=st.st_size;count+=not p.name.endswith('.crdownload')
  else:evidence+=st.st_size
 limits=C['limits'];free=shutil.disk_usage(P).free
 allowance=max(0,limits['profileBytes']-profile)+max(0,limits['evidenceBytes']-evidence)+max(0,limits['downloadsBytes']-downloads)
 reserved=C['futureRootReservedBytes'];assert reserved==33554432;projected=free-remaining-allowance-reserved
 rec={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':stage,'freeBytes':free,'remainingRootArtifactBytes':remaining,'reservedRootBrowserBytes':reserved,'artifactReservationNotRequired':True,'remainingBrowserAllowance':allowance,'projectedReserveBytes':projected,'profileLogicalBytes':profile,'evidenceLogicalBytes':evidence,'downloadBytes':downloads,'downloadFiles':count,'actualAllocatedBytes':allocated}
 with (R/'capacity.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 assert projected>=limits['minimumProjectedFreeBytes'],rec
 assert profile<=limits['profileBytes'] and evidence<=limits['evidenceBytes'] and downloads<=limits['downloadsBytes'] and count<=limits['downloadFiles'] and allocated<=limits['maximumActualNewDiskBytes'],rec
 if (R/'launch.json').exists():assert time.time()-json.loads((R/'launch.json').read_text())['startedAt']<=limits['browserSeconds'], 'Browser deadline'
 return rec
if __name__=='__main__':print(json.dumps(check(__import__('sys').argv[1] if len(__import__('sys').argv)>1 else 'explicit')))
