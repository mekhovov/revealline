#!/usr/bin/env python3
"""Post-closure, local-only original evidence reconciliation; never drives a browser."""
from pathlib import Path
import datetime,hashlib,json,os,socket,struct
P=Path(__file__).resolve().parent;R=P/'run'
def load(p):return json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'path':str(p.relative_to(P)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,v):
 with p.open('x') as f:f.write(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def act(ph,n):return load(R/ph/f'action-{n:03}.json')
def res(ph,n):return act(ph,n)['result']
def saved(q):
 d=q['storage'];v=next((v for k,v in d.items() if k.startswith('revealline.suspended.')),d.get('suspended'))
 return json.loads(v if isinstance(v,str) else v['raw'])
def nostamp(v):return {k:x for k,x in v.items() if k!='savedAt'}
def stores(q):return [(d['name'],d['version'],[(s['name'],s['count'],s['keys'],s['sha256']) for s in d['stores']]) for d in q['databases']]
def gone(pid):
 try:os.kill(pid,0);return False
 except ProcessLookupError:return True
def closed(port):
 with socket.socket() as s:s.settimeout(.5);return s.connect_ex(('127.0.0.1',port))!=0
phases=['01-online','02-refused','03-restored'];launches=[load(R/x/'launch.json') for x in phases];ends=[load(R/x/'exit.json') for x in phases]
processes=[]
for ph,l,e in zip(phases,launches,ends):
 assert e['exitCode']==0 and e['pidExited'] and e['endpointClosed'] and gone(l['pid']) and closed(l['port'])
 ev=[json.loads(x) for x in (R/ph/'events.jsonl').read_text().splitlines()]
 ready=next(x for x in ev if x.get('ready'))
 assert gone(ready['controllerPid'])
 processes.append({'phase':ph,'browserPid':l['pid'],'browserPort':l['port'],'browserPidExited':True,'endpointClosed':True,'driverPid':ready['controllerPid'],'driverPidExited':True,'launcherExit':pin(R/ph/'exit.json'),'lastAction':pin(sorted((R/ph).glob('action-*.json'))[-1])})
proxy=load(R/'refusal-proxy-ready.json');assert gone(proxy['pid']) and closed(proxy['port']) and gone(80112) and closed(65345)
acts=[load(f) for ph in phases for f in sorted((R/ph).glob('action-*.json'))];assert len(acts)==90 and all(x['ok'] for x in acts)
assert all(x['before']['width']==390 and x['before']['height']==844 for x in acts)
pngs=[]
for ph in phases:
 for f in sorted((R/ph).glob('*.png')):
  w,h=struct.unpack('>II',f.read_bytes()[16:24]);assert(w,h)==(390,844);pngs.append({**pin(f),'width':w,'height':h})
assert len(pngs)==6
# Reviewed preparation originally pins pre-GO authorization. Every other prepared original is unchanged.
m=load(P/'r2-preparation-manifest.json');unchanged=[]
for row in m['files']:
 f=P/row['path'];actual=pin(f)
 if row['path']=='root-authorization.json':
  old=P/'provenance/r2-root-authorization-pre-go.json';z=pin(old);assert(z['bytes'],z['sha256'])==(row['bytes'],row['sha256']);continue
 assert actual==row,(row,actual);unchanged.append(row)
old=res('01-online',24);back=res('01-online',31);blocked=res('01-online',50);cold=res('02-refused',4);restored=res('03-restored',4)
sold,sback,sblocked,scold,srest=map(saved,[old,back,blocked,cold,restored])
assert nostamp(sold)==nostamp(sback);assert back['storage']==blocked['storage'];assert blocked['storage']==cold['storage']
assert all(stores(x)==stores(old) for x in [back,blocked,cold,restored])
assert saved(res('02-refused',7))==saved(res('02-refused',8))==scold
assert res('02-refused',7)['flightState']==res('02-refused',8)['flightState']=='paused'
post=saved(res('02-refused',17));assert post['replay']['ticks']>scold['replay']['ticks'] and nostamp(post)==nostamp(srest)
ev=[json.loads(x) for x in (R/'01-online/events.jsonl').read_text().splitlines()]
game=load(P/'verified-public-identity.json')['url']
history=[e for e in ev if e.get('method')=='DOM.event' and e['measurement']['url']==game and e['measurement']['type']in ['pagehide','pageshow'] and e['measurement']['persisted']]
assert {e['measurement']['type'] for e in history}=={'pagehide','pageshow'} and all(e['measurement']['isTrusted'] for e in history)
assert old['timeOrigin']==back['timeOrigin'];assert res('01-online',53)['timeOrigin']!=back['timeOrigin']
downloads=[e for e in ev if e.get('method')=='Browser.downloadProgress' and e['params']['state']=='completed'];assert len(downloads)==2 and len({e['params']['guid'] for e in downloads})==2
f=R/'downloads/revealline-orchard-crossing-replay.json';dp=pin(f);ui1=res('01-online',17);ui2=res('01-online',19)
assert dp['sha256']==ui1['compactExportUtf8']['sha256']==ui2['compactExportUtf8']['sha256'] and dp['bytes']==4051
assert json.loads(f.read_text())==json.loads(ui1['value'])==json.loads(ui2['value'])
cev=[json.loads(x) for x in (R/'02-refused/events.jsonl').read_text().splitlines()]
main=[e for e in cev if e.get('method')=='Network.responseReceived' and e.get('type')=='Document' and e.get('url')==game];assert len(main)==1 and main[0]['status']==200 and main[0]['fromServiceWorker']
assert res('02-refused',5)['outcome']=='rejected';assert res('03-restored',2)['outcome']=='response-received' and res('03-restored',2)['status']==404
px=[json.loads(x) for x in (R/'refusal-events.jsonl').read_text().splitlines()]
assert any(x.get('host')=='p01-refusal.invalid' and x.get('method')=='CONNECT' for x in px)
assert any(x.get('host')=='mekhovov.github.io' and x.get('method')=='CONNECT' for x in px)
for ph,n in [('01-online',63),('01-online',65),('02-refused',17)]:
 q=res(ph,n)['offline'];d=json.loads(q['details'].replace('\\n','\n'));assert d['verified']==d['count']==609 and d['bytes']==55449837 and d['missing']==d['corrupt']==[]
closure={'format':'revealline-native-browser-closure.v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ALL_OWNED_PROCESSES_CLOSED','processes':processes,'proxies':[{'pid':80112,'port':65345,'pidExited':True,'endpointClosed':True,'exitCode':143,'role':'preserved preflight-only relative-argv attempt'},{'pid':proxy['pid'],'port':proxy['port'],'pidExited':True,'endpointClosed':True,'exitCode':143,'role':'actual refused-network phase'}],'profilePreserved':True,'profilePayloadSelected':False,'sourceWrites':False,'actions':90,'actionsByPhase':[66,19,5],'screenshots':6,'downloadCompletedEvents':2,'retainedDownloadFiles':1,'remainingBrowserActions':0,'capacityAllLauncherObservationsPassed':True}
write(R/'closure.json',closure)
checks={'format':'revealline-p01-native-evidence-reconciliation.v1','at':closure['at'],'preparationOriginalsUnchangedExcludingExpectedGoAuthorization':len(unchanged),'priorAuthorizationRetained':pin(P/'provenance/r2-root-authorization-pre-go.json'),'actualAuthorization':pin(P/'root-authorization.json'),'history':{'classification':'native persisted BFCache return','events':history,'sameTimeOrigin':old['timeOrigin'],'checkpoint':sback['replay']['checkpoint'],'runId':sback['runId'],'replayAndPinsEqualExceptSavedAt':True,'departureTimestamp':{'before':sold['savedAt'],'after':sback['savedAt']},'allObservedStoreKeysCountsDigestsEqual':True,'afterResumeAndRecoveryAttemptRawLocalStorageEqualToPostBack':True,'onceOnlyBrowserReloadAction':'run/01-online/action-052.json','newDocumentTimeOrigin':res('01-online',53)['timeOrigin']},'downloads':{'completedBrowserEvents':downloads,'originalUiBefore':pin(R/'01-online/action-017.json'),'originalUiAfter':pin(R/'01-online/action-019.json'),'retainedOriginal':dp,'retainedParsedContentAndCompactUtf8MatchBothUiSamples':True,'twoHistoricalFilesRetained':False,'firstFileIndependentBytes':'UNOBSERVED: second completed download reused the same pathname; no third download attempted.','originalVerifierFailure':pin(R/'replay-download-verifier-count-mismatch.json'),'parentExplicitContinuation':pin(R/'parent-download-continuation-review.json')},'cold':{'documentResponse':main[0],'probe':res('02-refused',5),'twoPausedSamples':['run/02-refused/action-007.json','run/02-refused/action-008.json'],'beforeResumeTicks':scold['replay']['ticks'],'beforeResumeCheckpoint':scold['replay']['checkpoint']['hash'],'afterExplicitResumeTicks':post['replay']['ticks'],'afterExplicitResumeCheckpoint':post['replay']['checkpoint']['hash'],'offlineVerified':{'files':609,'bytes':55449837,'missing':[],'corrupt':[]},'onlineHintIsNotNetworkProof':True},'restored':{'probe':res('03-restored',2),'identity':res('03-restored',3),'savedReplayAndPinsEqualToColdPostResumeExceptDepartureSavedAt':True,'departureTimestamp':{'before':post['savedAt'],'after':srest['savedAt']},'allObservedStoreKeysCountsDigestsEqual':True},'screenshots':pngs,'limitations':['No physical device/controller/audibility claim.','Native browser inputs and native service worker behavior were observed through an isolated CDP target with exact 390×844 metrics.','The initial recording was 1571 ticks / 13.0917 seconds; no <=10 second duration claim.','Screenshot01 is craft loading after installation; earlier action005 is the pending install observation.','Product Reload saved profile was not activated. Exactly one native browser Reload was used.','Recovery controls disappeared after Export game data opened Library and Escape closed it; focus became BODY. This is a required finding pending parent disposition.','No no-write claim spans departure timestamps or explicit Resume.','Original r1 socket1006 cause remains unresolved; the r2 transport local fixture only establishes bounded payload handling.','The relative-proxy-argv preflight failure was manually corrected with explicit parent authorization before any cold Chrome launch.']}
write(R/'measurements.json',checks)
review={'format':'revealline-p01-public-family-review.v1','status':'COMPLETED_WITH_REQUIRED_FINDING','phaseAccepted':False,'family':'P2 history/replay/offline','sourceRevision':load(P/'verified-public-identity.json')['sourceRevision'],'sourceTree':load(P/'verified-public-identity.json')['sourceTree'],'version':'v0.57.3','closed':True,'executionComplete':True,'nativePasses':['Two completed replay-download browser events and verified retained final replay file; first-file byte preservation remains limited.','Persisted Explorer Back, same saved replay/checkpoint/picture pins, paused Continue and explicit Resume.','Actual optional new-owner refusal preserved all observed storage; recovery actions initially visible.','Once-only native browser Reload restored writer session; real offline preparation, Stop, Check progress, and 609-file verification.','Cold same-profile process under actual refusal proxy loaded the service-worker document, restored paused saved Continue, resumed explicitly and verified all cached files.','No-proxy restored process received an uncached online response and retained exact frozen build/offline bytes and saved replay.'],'requiredFindings':[{'id':'P2-RECOVERY-ACTIONS-AFTER-LIBRARY','status':'OPEN_PARENT_DISPOSITION','actions':'01-online/041–051','result':'The initially visible Export game data and Reload saved profile controls disappear after Export opens Library Saves and Escape closes it. Focus is BODY. No product Reload activation or persistent recovery-control claim.'}],'limits':checks['limitations'],'originalFailuresRetained':['provenance/r1-originals.zip','run/replay-download-verifier-count-mismatch.json','run/replay-download-verification.json','run/refusal-proxy-preflight-failure.json','run/failed-preflight-relative-proxy/closure.json'],'closure':pin(R/'closure.json'),'measurements':pin(R/'measurements.json'),'noAcceptanceOrPublicMutation':True}
write(R/'review.json',review)
print(json.dumps({'closure':pin(R/'closure.json'),'measurements':pin(R/'measurements.json'),'review':pin(R/'review.json')},indent=2))
