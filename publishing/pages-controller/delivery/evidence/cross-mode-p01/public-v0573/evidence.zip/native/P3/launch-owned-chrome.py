#!/usr/bin/env python3
from pathlib import Path
import json,subprocess,datetime,time,shutil,http.client,re
P=Path(__file__).resolve().parent
C=json.loads((P/'config.json').read_text());RUN=P/'run'
if '--go' not in __import__('sys').argv: raise SystemExit('Prepared only. Explicit root GO is required before --go.')
assert C['status']=='AUTHORIZED_BOUNDED_PUBLIC_TRANSFER_RECOVERY'
A=json.loads((P/'root-authorization.json').read_text())
assert A['status']==C['status'] and A['sourceRoot']==C['sourceRoot']
assert re.fullmatch('[0-9a-f]{64}',C['publicBuildInfoSha256'] or '')
for key in ['sourceRevision','sourceTree','publishingRevision','publishingTree']:
 assert re.fullmatch('[0-9a-f]{40}',C[key] or '') and A[key]==C[key],key
for key in ['version','publicBuildInfoSha256','publishingRun','pagesDeployment']:
 assert C[key] and A[key]==C[key],key
proof=C['publicHttpCompletion'];assert isinstance(proof,dict)
import hashlib
raw=Path(proof['path']).read_bytes();assert len(raw)==proof['bytes'] and hashlib.sha256(raw).hexdigest()==proof['sha256']
assert A['publicHttpCompletion']==proof
RUN.mkdir(exist_ok=False)
profile=Path(C['profilePath']);assert profile.is_dir();assert not (RUN/'launch.json').exists()
assert '--user-data-dir='+str(profile) not in subprocess.check_output(['ps','-ax','-o','command='],text=True), 'Retained profile already active'
from capacity import check as disk
C['maxBrowserSeconds']=C['limits']['browserSeconds']
disk('before-launch')
args=['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--headless=new','--remote-debugging-port=0','--enable-automation','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-features=OptimizationGuideModelDownloading,OptimizationHintsFetching,OptimizationTargetPrediction,OptimizationHints','--disable-gpu-shader-disk-cache','--disable-default-apps','--disable-sync','--enable-unsafe-swiftshader','--password-store=basic','--use-mock-keychain','--disable-quic','--disable-extensions','--disk-cache-size=4194304','--media-cache-size=1048576','--window-size=390,844','--user-data-dir='+str(profile),'--no-proxy-server','about:blank']
started=time.time();proc=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
 deadline=time.monotonic()+20
 while time.monotonic()<deadline:
  pf=profile/'DevToolsActivePort'
  if pf.exists() and pf.stat().st_mtime>=started:
   port=int(pf.read_text().splitlines()[0]);c=http.client.HTTPConnection('127.0.0.1',port,timeout=1);c.request('GET','/json/version');v=json.loads(c.getresponse().read());c.close();break
  assert proc.poll() is None;time.sleep(.1)
 else:raise RuntimeError('No owned endpoint')
 receipt={'startedAt':started,'pid':proc.pid,'profile':str(profile),'arguments':args,'endpoint':v['webSocketDebuggerUrl'],'port':port,'version':v,'scope':C['scope']}
 (RUN/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 while proc.poll() is None:
  assert time.time()-started<=C['maxBrowserSeconds'],'Owned browser duration cap reached'
  disk('running');time.sleep(3)
 (RUN/'exit.json').write_text(json.dumps({'pid':proc.pid,'exitCode':proc.returncode,'capacity':disk('after-exit')},indent=2)+'\n')
except BaseException as e:
 (RUN/'launch-failure.json').write_text(json.dumps({'type':type(e).__name__,'message':str(e)},indent=2)+'\n')
 if proc.poll() is None:
  proc.terminate()
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
 raise
