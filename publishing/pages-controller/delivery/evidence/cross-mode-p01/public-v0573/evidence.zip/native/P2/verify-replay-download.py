"""Read only actual P2 replay receipts/events/files; no browser, network or source execution."""
from pathlib import Path
import argparse, datetime, hashlib, json, re, stat

P = Path(__file__).resolve().parent
R = P / 'run'
D = R / '01-online'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def raw(path, limit):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_size <= limit,
            'Original must be a bounded regular file: ' + str(path))
    return path.read_bytes()

def pin(path, body):
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def timestamp(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))

parser = argparse.ArgumentParser(description=__doc__)
for name in ['export', 'ui-before', 'download', 'ui-after']:
    parser.add_argument('--' + name, required=True)
args = vars(parser.parse_args())
config = json.loads(raw(P / 'public-launch-config.json', 65536))
launch = json.loads(raw(D / 'launch.json', 65536))
target = json.loads(raw(D / 'owned-target.json', 65536))
require(launch['phase'] == '01-online' and launch['profile'] == config['profile'], 'Launch differs')
receipts, originals = {}, []
for role, name in args.items():
    require(re.fullmatch(r'action-\d{3}\.json', name) is not None, 'Expected actual action basename')
    path = D / name
    body = raw(path, 3 * 1024 * 1024)
    value = json.loads(body)
    require(value['ok'] is True and value['phase'] == '01-online'
            and value['pid'] == launch['pid'] and value['profile'] == launch['profile']
            and value['targetId'] == target['targetId'] and value['before']['url'] == config['game'],
            'Action is not the successful owned canonical online target')
    receipts[role] = value
    originals.append(pin(path, body))
expected_commands = {'export': ('click', '#export-replay'), 'download': ('click', '#download-replay'),
                     'ui_before': ('read', 'replay-json'), 'ui_after': ('read', 'replay-json')}
for role, (action, arg) in expected_commands.items():
    require(receipts[role]['command'] == {'action': action, 'arg': arg}, 'Unexpected native action')
for role in ['export', 'download']:
    element = receipts[role]['element']
    require(element['matches'] == 1 and element['visible'] and element['hit'] and not element['disabled'],
            'Native download trigger lacks its visible enabled top-layer observation')
order = ['export', 'ui_before', 'download', 'ui_after']
times = [timestamp(receipts[role]['at']) for role in order]
require(times == sorted(times) and len(set(args.values())) == 4, 'Original sequence differs')
before, after = receipts['ui_before']['result'], receipts['ui_after']['result']
require(before['value'] == after['value'] and before['compactExportUtf8'] == after['compactExportUtf8'],
        'UI replay changed across native Download JSON')
for ui in [before, after]:
    require(ui['url'] == config['game'] and ui['dialogOpen'] and ui['readOnly']
            and ui['downloadDisabled'] is False, 'Replay UI did not settle in its open readonly host')
    body = ui['value'].encode('utf-8')
    require(ui['rawUiUtf8'] == {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()},
            'Raw UI pin differs')
replay = json.loads(before['value'])
suggested = 'revealline-' + replay['summary']['levelId'] + '-replay.json'
require(re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9._-]{0,179}\.json', suggested) is not None,
        'Unexpected original replay filename')
event_path = D / 'events.jsonl'
event_bytes = raw(event_path, 3 * 1024 * 1024)
events = [json.loads(line) for line in event_bytes.splitlines() if line]
begins = [e for e in events if e.get('method') == 'Browser.downloadWillBegin']
require(len(begins) == 2 and len({e['params']['guid'] for e in begins}) == 2,
        'Expected exactly the automatic and explicit browser download requests')
completed = []
for index, begin in enumerate(begins):
    params = begin['params']
    require(times[index * 2] <= timestamp(begin['at']) <= times[index * 2 + 1]
            and params['suggestedFilename'] == suggested
            and params['url'].startswith('blob:https://mekhovov.github.io/'),
            'Download request is not inside its actual native action interval')
    progress = [e for e in events if e.get('method') == 'Browser.downloadProgress'
                and e['params']['guid'] == params['guid']]
    terminal = [e for e in progress if e['params']['state'] in ['completed', 'canceled']]
    require(len(terminal) == 1 and terminal[0]['params']['state'] == 'completed'
            and timestamp(begin['at']) <= timestamp(terminal[0]['at']) <= times[index * 2 + 1],
            'No original completed download event before the settled UI observation')
    for field in ['totalBytes', 'receivedBytes']:
        require(terminal[0]['params'][field] == before['compactExportUtf8']['bytes'],
                'Completed download event byte count differs from compact UI export')
    completed.append({'begin': begin, 'completed': terminal[0]})
download_dir = R / 'downloads'
require(download_dir.is_dir() and not download_dir.is_symlink(), 'Expected own download directory')
paths = sorted(download_dir.iterdir())
require(len(paths) == 2 and config['limits']['downloadFiles'] == 2, 'Download count differs')
allowed_names = {suggested, suggested[:-5] + ' (1).json'}
require({p.name for p in paths} == allowed_names, 'Unexpected download basename or partial file')
files = []
for path in paths:
    body = raw(path, config['limits']['downloadsBytes'])
    actual = pin(path, body)
    require({k: actual[k] for k in ['bytes', 'sha256']} == before['compactExportUtf8']
            and json.loads(body) == replay, 'Original download differs from compact UI bytes or parsed replay')
    files.append(actual)
require(sum(p['bytes'] for p in files) <= config['limits']['downloadsBytes'], 'Two MiB budget exceeded')
for event in completed:
    actual_path = event['completed']['params'].get('filePath')
    if actual_path is not None:
        require(actual_path in {str(p) for p in paths}, 'Observed download filePath is outside retained originals')
print(json.dumps({'status': 'PASS_SCOPED_REPLAY_DOWNLOAD_ORIGINALS', 'phase': '01-online',
                  'rawUiUtf8': before['rawUiUtf8'], 'compactExportUtf8': before['compactExportUtf8'],
                  'representation': before['compactDerivation'], 'originalActionPins': originals,
                  'eventSnapshot': pin(event_path, event_bytes), 'downloads': files,
                  'browserEvents': completed, 'parsedReplayEqual': True,
                  'limits': 'Only two actual replay downloads and their UI/event identity. Checkpoint, history, native picker cancel, offline and P01 acceptance require separate evidence. Browser event file may continue growing; this pin is the inspected prefix snapshot.'}, indent=2))
