# Sourcing defines bounded command aliases only; it launches nothing.
P1_PREP='/Users/oleksandr.mekhovov/work/my_projects/go_test_p01_file_cancel/.cache/cross-mode/p01/v0573-final-recovery/public-corrective-browser-preparation'
P1_NODE='/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node'
P1_FIX='/Users/oleksandr.mekhovov/work/my_projects/go_test_p01_file_cancel'
p1n() { "$P1_NODE" "$P1_PREP/native.mjs" "$@"; }
p1m() { "$P1_NODE" "$P1_PREP/measure.mjs" "$@"; }
cd "$P1_PREP" || return 1
