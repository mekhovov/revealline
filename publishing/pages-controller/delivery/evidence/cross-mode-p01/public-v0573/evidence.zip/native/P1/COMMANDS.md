For final serialized execution use [ORDERED-COMMANDS.md](ORDERED-COMMANDS.md); it includes the actual-binding gate, reviewed32MiB peer allowance and finite per-case checkpoints. This earlier primitive reference remains below.

# Commands — only after actual parent GO

Use this directory as the working directory. Commands below are a guide, not a batch script: inspect each actual result and visibility before the next native action. Never substitute guessed selectors or use hidden controls. There is no source server.

```sh
python3 binding.py
python3 launch-owned-chrome.py --go
```

Keep the owned launcher active. In subsequent calls, always use this exact binary (the short `node` executable may be Node20 and is deliberately refused):

```sh
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs init
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node observe.mjs
```

Keep that observer active only for the bounded run. It records passive native events and network response/error observations. Bring-to-front and same-target metrics remain enforced for every action. The observer may start after the first page has loaded; its network record is supplementary to the separately pinned all-body HTTP evidence and does not retroactively prove unobserved responses.

Native primitives (each writes an exclusive action receipt):

```sh
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs navigate /game/playground/
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs viewport 390x844
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs upload '#import-file' /Users/oleksandr.mekhovov/work/my_projects/go_test_p01_file_cancel/game/content/packs/classic-lab.json
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node measure.mjs playground imported
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs click '#generate-button'
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node measure.mjs playground generated
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs shot 01-playground-portrait
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node native.mjs click '#undo-button'
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node measure.mjs playground undone
```

Continue the exact PLAN cases with `click <selector>`, `wheel <visible-selector> <bounded-deltaY>`, `key Tab|Escape|PageDown|PageUp`, `key ArrowRight 200`, `viewport 844x390`, and the pinned `upload` fixture paths. `measure.mjs` accepts only `playground`, `music`, `replay` or `still` plus a unique simple label. `native.mjs read` is only for passive inspection of real DOM/save identity; never use setters, injected events, internal application functions or seeded state. Native file selection does not prove cancellation unless the retained trusted event exists.

For the short authentic Music track, after real import and actual selected track:

```sh
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node music-native-sequence.mjs
```

This preserves a same-target 390 × 844 PNG named `01-music-native-portrait.png`, then attempts Finish only if still available. It does not stretch playback or fabricate pending state.

Replay fixture: `game/replay-theater/data/fieldcraft-01.replay.json`. Still fixture: `authoring/still-media/examples/dawn-signal/Dawn-Signal-originals.rlmedia`. All paths are resolved under the pinned fix worktree and rehashed before use. Original Download is enabled through the observer's bounded native download directory; no generated fixture substitutes for the recorded replay.

Cleanup is allowed even when the public authorization expires or a resource guard has stopped the run. It uses only this run's exact PID/profile/script receipts and never finds another browser:

```sh
python3 close-owned.py
```

Then collect the launcher's terminal exit and check the recorded owned ports/PIDs are absent. Preserve receipts and every original. Final packaging excludes Chrome profiles; do not modify prior source-native evidence.
