"""Fresh bounded capacity check; no browser or network operations."""
from pathlib import Path
import argparse,datetime,json,shutil,stat,time
P=Path(__file__).resolve().parent;C=json.loads((P/'public-launch-config.json').read_text());L=C['limits'];R=P/'run'
def check(stage,identity=None,phase=None):
 inventory=None
 if identity is not None:
  from public_binding import value
  inventory=sum(row['bytes'] for row in value(identity['offlineManifestPin'])['files'])
 profile_cap=L['maximumProfileBytes'] if inventory is None else L['profileBaseBytes']+L['offlineInventoryMultiplier']*inventory
 assert profile_cap<=L['maximumProfileBytes']
 profile=evidence=downloads=allocated=count=0
 for path in R.rglob('*'):
  try:s=path.lstat()
  except FileNotFoundError:continue
  if not stat.S_ISREG(s.st_mode):continue
  allocated+=s.st_blocks*512
  if path.is_relative_to(R/'profile'):profile+=s.st_size
  elif path.is_relative_to(R/'downloads'):downloads+=s.st_size;count+=not path.name.endswith('.crdownload')
  else:evidence+=s.st_size
 peer=C['peerAllowanceBytes'];assert peer==33554432 and L['minimumProjectedFreeBytes']==536870912
 allowance=max(0,profile_cap-profile)+max(0,L['evidenceBytes']-evidence)+max(0,L['downloadsBytes']-downloads)
 free=shutil.disk_usage(P).free;projected=free-peer-allowance
 rec={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':stage,'phase':phase,'peerAllowanceBytes':peer,'actualFrozenInventoryBytes':inventory,'profileAllowanceBytes':profile_cap,'freeBytes':free,'remainingOwnAllowanceBytes':allowance,'projectedFreeBytes':projected,'requiredProjectedFreeBytes':L['minimumProjectedFreeBytes'],'profileLogicalBytes':profile,'evidenceLogicalBytes':evidence,'downloadBytes':downloads,'downloadFiles':count,'actualAllocatedBytes':allocated,'capacitySufficient':projected>=L['minimumProjectedFreeBytes'],'browserExecutionAuthorizedByCapacity':False}
 out=(R/phase/'capacity.jsonl') if phase else (P/'public-capacity-observations.jsonl')
 with out.open('a') as f:f.write(json.dumps(rec)+'\n')
 assert rec['capacitySufficient'] and profile<=profile_cap and evidence<=L['evidenceBytes'] and downloads<=L['downloadsBytes'] and count<=L['downloadFiles'] and allocated<=L['maximumNewDiskBytes'],json.dumps(rec)
 if phase and stage=='running':assert time.time()-json.loads((R/phase/'launch.json').read_text())['startedAt']<=L['browserSecondsPerProcess'],'Owned browser deadline'
 return rec
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--stage',default='preparation');a.add_argument('--actual-binding',action='store_true');x=a.parse_args();identity=None
 if x.actual_binding:
  from public_binding import verify
  identity=verify()
 print(json.dumps(check(x.stage,identity)))
