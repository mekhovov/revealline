"""Cleanup only: never locates a browser outside this run's retained PID/profile receipt."""
from pathlib import Path
import datetime,json,os,signal,subprocess,time
P=Path(__file__).resolve().parent;R=P/'run';out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'processes':[]}
for name in ['observer.json','launch.json']:
 p=R/name
 if not p.exists():continue
 record=json.loads(p.read_text());pid=record['pid'];expected=str(P/'observe.mjs') if name=='observer.json' else '--user-data-dir='+str(R/'profile')
 cmd=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True)
 if cmd.returncode:out['processes'].append({'receipt':name,'pid':pid,'alreadyClosed':True});continue
 assert expected in cmd.stdout, 'PID ownership changed; refuse to signal'
 os.kill(pid,signal.SIGTERM)
 deadline=time.monotonic()+8
 while time.monotonic()<deadline:
  current=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True)
  if current.returncode:break
  assert expected in current.stdout,'PID changed during closure'
  time.sleep(.1)
 else:raise RuntimeError('Owned process did not close; retain and report, no global kill')
 out['processes'].append({'receipt':name,'pid':pid,'terminatedAndAbsent':True})
with (R/'closure-processes.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(out))
