# Ordered P1 command checklist — not executed

This is the final serialized command guide. It supplies no actual public identity or GO. Execute one native command at a time and inspect its original result before continuing. A command refusal sends no fallback click; preserve it and review the actual visible layout. The complete PLAN bounds still apply. Ordinary wheel actions below are the previously successful source route, subject to current visible-target checks; they are not instructions to blindly replay a script.

## 0. Actual binding and serialized resource review

Parent first supplies two actual files under this preparation directory:

- `verified-public-identity.json`: final7945c6d/tree6c997037/versionv0.57.3; published release metadata; complete source qualification; actual manifest/build-info/offline originals; actual successful HTTP report and JSONL body results; parent public review. Use the template schema and original file pins; do not fill from an old release or prepared/null record.
- `root-authorization.json`: actual `AUTHORIZED_PUBLIC_CORRECTIVE_BROWSER`, current GO interval, exact identity/preparation manifest pins, `peerReservedBytes: 33554432`. It must authorize serialized execution. The allowance is32MiB only; the512MiB floor remains unchanged. No additional browser may start under this allocation without a new review.

In each command terminal/tool invocation, source the same bounded aliases:

```sh
source /Users/oleksandr.mekhovov/work/my_projects/go_test_p01_file_cancel/.cache/cross-mode/p01/v0573-final-recovery/public-corrective-browser-preparation/p1-env.sh
```

Read-only binding and fresh capacity, after those actual files exist:

```sh
python3 binding.py
python3 - <<'PY'
from pathlib import Path
import json, shutil
from binding import verify
v=verify(); c=json.loads(Path('config.json').read_text()); l=c['limits']
assert not Path('run').exists(), 'No rerun or clobber of original evidence'
assert c['futureRootReservedBytes']==33554432 and l['minimumProjectedFreeBytes']==536870912
own=l['profileBytes']+l['evidenceBytes']+l['downloadsBytes']
free=shutil.disk_usage(Path.cwd()).free
projected=free-own-c['futureRootReservedBytes']
assert projected>=l['minimumProjectedFreeBytes'], (free,own,projected)
print(json.dumps({'status':'ACTUAL_BOUND_PREFLIGHT','source':v['sourceRevision'],'buildId':v['buildId'],'freeBytes':free,'ownAllowanceBytes':own,'peerReservedBytes':c['futureRootReservedBytes'],'projectedReserveBytes':projected}))
PY
```

Fresh empty-profile accounting is74MiB own logical allowance +32MiB peer allowance +512MiB floor =618MiB minimum free (648,019,968bytes). The independent96MiB actual allocation ceiling also remains. Current free space is measured at execution, not assumed from this preparation.

## 1. One owned launch and observer

Run this as a retained long-lived tool/terminal session; leave the3-second guard active:

```sh
python3 launch-owned-chrome.py --go
```

It first validates actual inputs, creates `run/` and one new profile exclusively, launches only its recorded Chrome, then prints `launch.json`. If it exits or records a failure, stop; never reconnect to another browser. Next, in another tool invocation after the launch receipt exists:

```sh
p1n init
p1n read '({url:location.href,bootState:document.documentElement.dataset.bootState,dialogs:[...document.querySelectorAll("dialog[open]")].map(e=>e.id),edition:document.querySelector("#shell-edition")?.textContent})'
```

Inspect actual boot ready and release identity. If still loading, use the same passive read at bounded intervals for at most30seconds; do not use `wait --fn`, timers injected into the app or hidden clicks. Then start the observer in its own retained long-lived invocation:

```sh
"$P1_NODE" "$P1_PREP/observe.mjs"
```

Confirm its ready receipt. The original `observer.json`, target, launch and actual response/error/native event log now belong to this run. The observer starts after the first document, so original full HTTP pins provide prior byte authority; no retrospective network observation is claimed.

## 2. Playground native import, portrait Generate and Undo

```sh
p1n navigate /game/playground/
p1n viewport 390x844
p1m playground initial
p1n upload '#import-file' "$P1_FIX/game/content/packs/classic-lab.json"
p1m playground imported
p1n wheel '#editor-status' 1250
p1n click '#generate-button'
p1m playground generated
p1n shot 02-playground-generated-portrait
p1n wheel '#generate-button' 250
p1n click '#undo-button'
p1m playground undone
```

Checkpoint: the real imported JSON must exist before Generate; record its hash. Status/Cancel and invoking controls must be visible in the actual result; no scroll is inserted between Generate and its measurement/PNG. Fast ready is terminal evidence, not painted busy. Verify real JSON changed and Undo restored it exactly:

```sh
python3 - <<'PY'
from pathlib import Path
import json
rows=[json.loads(Path('run/measure-playground-'+name+'.json').read_text()) for name in ['imported','generated','undone']]
assert all(r['ok'] for r in rows)
a,b,c=[r['observation']['levelJson'] for r in rows]
assert a and a!=b and a==c
print('Actual imported level differs after Generate and is byte-identical after native Undo.')
PY
```

## 3. Playground landscape replay and actual child-ready/Back

```sh
p1n viewport 844x390
p1n wheel '#undo-button' -260
p1n wheel '#generate-button' 1400
p1n click 'details:has(#replay-file)>summary'
p1n upload '#replay-file' "$P1_FIX/game/replay-theater/data/fieldcraft-01.replay.json"
p1m playground replay-result
p1n shot 03-playground-replay-landscape
p1n viewport 390x844
p1n wheel main -1600
p1n wheel main -1600
p1n click '#preview-button'
p1m playground preview-started
```

Checkpoint: original replay result must verify the real recording and remain visible with its Cancel/trigger. Inspect actual child URL/revision and bootState/toolState from the measurement. A `load` alone is not ready. If still pending, use bounded passive measurements with unique labels until ready or the30-second observation bound; record timeout/unobserved honestly. When settled:

```sh
p1m playground preview-settled
p1n shot 04-playground-child-portrait
p1n click '.masthead nav a[href="../"]'
p1n read '({url:location.href,bootState:document.documentElement.dataset.bootState,dialogs:[...document.querySelectorAll("dialog[open]")].map(e=>e.id)})'
```

Checkpoint: Back reaches this exact release's game. No direct-navigation substitution for the successful Back claim and no native BFCache claim without actual persisted evidence.

## 4. Music portrait import, same-session Audition/Finish and Close

```sh
p1n viewport 390x844
p1n click '#shell-options'
p1n click '#soundtrack-open'
p1n wheel '#soundtrack-dialog' 850
p1n upload '#soundtrack-mp3-files' "$P1_FIX/game/test/fixtures/audio/silence-mpeg1-layer3.mp3"
p1n click '#soundtrack-import-mp3'
p1m music imported
p1n wheel '#soundtrack-dialog' 700
"$P1_NODE" "$P1_PREP/music-native-sequence.mjs"
p1m music finished
p1n key Tab
p1m music next-tab
p1n key Escape
p1m music closed
```

Checkpoint: imported track selected, native actual media state, 390×844 PNG and original Finish bounds/hit. The sequence immediately attempts Finish only while available. Natural short-clip completion is an explicit limit, never stretched. Native Tab must reach a visible usable destination, then Escape restores the actual Music opener. If Settings remains open, one genuine Escape returns to Home before the next case:

```sh
p1n key Escape
p1n read '({dialogs:[...document.querySelectorAll("dialog[open]")].map(e=>e.id),active:document.activeElement.id})'
```

## 5. Genuine paused recording and Workshop replay at844×390

```sh
p1n viewport 844x390
p1n click '#shell-featured'
p1n read '({dialogs:[...document.querySelectorAll("dialog[open]")].map(e=>e.id),deployDisabled:document.querySelector("#shell-deploy")?.disabled,flightState:document.querySelector("#flight-state")?.textContent})'
```

Inspect the actual ready/visible Deploy button; wait only through bounded passive reads. Do not replace an unexpected disabled/hidden control. Then:

```sh
p1n click '#shell-deploy'
p1n key ArrowRight 200
p1n key Escape
p1n read '({save:localStorage.getItem("revealline.suspended.release-v0.57.3.v1"),flightState:document.querySelector("#flight-state")?.textContent})'
p1n click '#overlay-menu'
p1n click '#shell-workshop'
p1n wheel '#shell-workshop-dialog' 400
p1n click '#export-replay'
p1m replay initial
p1n shot 05-replay-landscape-initial
```

Checkpoint: a real recorded paused flight exists; initial original status/Download/Close are visible before dialog scrolling. Export already requests one native download. Do not click Download again solely to manufacture busy time. Retain its actual completed event/file; the four-file ceiling remains. Use native Tab one at a time, reading focus after each, at most eight presses, until the readonly JSON has actual focus:

```sh
p1n key Tab
p1m replay focus-01
```

For additional Tab observations use unique labels `focus-02` through `focus-08`; stop as soon as the exact textarea is focused. Do not overwrite an original observation. Once `replay-json` has actual focus:

```sh
p1n key PageDown
p1m replay json-down
p1n key PageUp
p1m replay json-up
p1n shot 06-replay-landscape-json
p1n key Escape
p1m replay closed
p1n read '({save:localStorage.getItem("revealline.suspended.release-v0.57.3.v1"),active:document.activeElement.id,focused:document.activeElement.matches(":focus")})'
```

Checkpoint: actual internal scroll changes, the first visible JSON line stays clear of the measured rail, and Escape returns to the enabled visible Export invoker. Compare real saved checkpoint/pins; isolate the known legitimate savedAt refresh. Native download bytes and JSON must match logically and independently verify after closure. There is no seeded recording or OS-save claim.

## 6. Still native same-file cancellation and exact opener

```sh
p1n navigate /authoring/still-media/
p1n viewport 390x844
p1m still initial
p1n click '#still-host-open'
p1m still opened
p1n upload '#still-media-bundle-file' "$P1_FIX/authoring/still-media/examples/dawn-signal/Dawn-Signal-originals.rlmedia"
p1n wheel '#still-media-dialog' 400
p1n click '#still-media-review-originals'
p1m still reviewed
p1n wheel '#still-media-dialog' -500
p1n upload '#still-media-bundle-file' "$P1_FIX/authoring/still-media/examples/dawn-signal/Dawn-Signal-originals.rlmedia"
p1m still same-file-cancel
p1n shot 07-still-cancel-portrait
p1n key Escape
p1m still closed
```

Checkpoint: initial Review actually settles and enables Restore before reselection. Retain the actual trusted input cancel event; if none occurs, record inconclusive rather than synthesize it. The same dialog/review/file/draft must remain. Escape restores the exact enabled44px opener with actual focus and clear hit geometry. Do not Restore or install.

## 7. Native completion, owned closure and evidence

While the observer is still healthy, inspect its exact completed download events and list only `run/downloads`; never search global Downloads. One final read-only capacity sample is permitted:

```sh
python3 capacity.py final-observation
python3 close-owned.py
```

Collect the launcher's terminal exit. Verify its exact recorded PID and port are gone; do not discover or signal another browser. Preserve every action, PNG, measurement, event, failure, pin and actual download; exclude the profile/cache from evidence. Reconcile 390×844/844×390 from actual PNG headers, never filenames. Rehash unchanged fixture and authority files and have the parent recheck live public authority. Deterministic verification of the actual short replay uses the already qualified `game/replay.mjs` tooling after closure, not browser state injection. No source mutation, build or full tests belong to this run.

Any blocked/failed checkpoint stops the finite run for review with original evidence. Do not improvise a second profile, change app state or turn an unobserved transient into a pass. The12-shot ceiling includes the Music sequence's capture; the listed sequence normally uses seven PNGs.
