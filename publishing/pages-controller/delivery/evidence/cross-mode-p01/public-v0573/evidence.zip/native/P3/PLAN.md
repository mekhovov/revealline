# P3 — bounded public transfer and recovery correction

Preparation only. The selected source is `7945c6d07714d41cee9b6f848059b8dc18aed86c` (`v0.57.3`). Its hosted checks and freeze succeeded. Actual frozen-byte inspection, release, publishing identity and Pages admission remain root-owned prerequisites; no public or browser acceptance is inferred here.

## Before native input

Parent supplies the actual immutable route/build-info SHA, publishing commit/tree/run/deployment and completed HTTP review pin, then gives serialized foreground GO. Record these in new additive authorization/binding originals; retain the initial unresolved configuration. The launcher refuses unresolved or inconsistent identities. No polling, network, browser launch, imported data, or state write occurs during preparation.

Reuse only the already closed task-owned public profile recorded in `retained-profile-preparation.json`. Never reopen its historical v0.42 or v0.57.2 game pages. Existing old-source closure and exact failed-Copy/no-write evidence remain in `input-pins.json`. The genuine v0.42 suspended save and authenticated picture/story/game backup remain the fixtures; no generated save, new win, fabricated index, JS storage write or copied browser credentials.

Capacity is measured immediately before launch and every three seconds: 512 MiB projected free floor, 32 MiB peer reserve, up to 80 MiB profile, 10 MiB evidence and 2 MiB downloads. The session is capped at 20 minutes and eight PNGs. Only the owned process/profile/target can receive native input. Actual visible/hasFocus/URL checks precede each action; an unknown target, identity mismatch, resource threshold or required defect stops the run and is preserved. Close/reap the owned browser and observer afterward.

## A25 — trusted legacy Copy and real Undo

1. Open only the approved new immutable game route, verify its actual served build-info bytes before input, and inspect retained storage read-only. Confirm the old `release-v0.42.0` raw suspended save and closed-writer provenance still match the original endpoints. Stop if the authentic candidate is absent or changed; do not recreate it by reopening the old writer.
2. Prepare the new target through normal Library import of the pinned authentic game-data backup. Shared original picture and story bytes are already retained; confirm their actual descriptors/body hashes. Reuse these bytes rather than reimporting originals unless they are genuinely absent (that condition needs parent review). The genuine backup has an explicit empty external chapter index. Confirm the resulting target index, saved flight, earned picture/score and original body hashes through read-only endpoints.
3. Review v0.42 in Bring progress from an earlier release. Before Review and after review/any naturally reachable Cancel, confirm no old-source or current collection/original changes. One visible Cancel attempt is allowed if an actual operation remains pending; no timing loop or artificial delay. Prior v0.57.2 failed Copy/no-write observations remain distinct evidence, not a new-source pass.
4. Activate Copy reviewed progress once. Require the authentic old suspended-only session, empty collection/default preferences and explicit empty index to commit successfully to the new target; retain before/after UI status, generation/index/saved-session endpoints and original SHA/size proofs. Old v0.42 raw values and all retained shared originals must remain unchanged. Do not resume the copied flight or manufacture progress.
5. Activate actual Undo game-data import once. Require the original target earned collection, score, preferences, installed content/index and saved flight to return, with permitted generation metadata change identified separately. This is a differing-content Copy/Undo case, unlike the prior same-content backup reimport. Preserve old v0.42 and v0.57.2 raw values and original blobs throughout.

## A27 — image verification label and reset

Use the normal direct profile-recovery link after Copy Undo and verify the actual immutable build-info again. Review the exact supported stored channel and shared originals normally. Select the authentic Dawn original: 640×360, 442,522 bytes, SHA `7f851f9806a1be994b2279f3d1acc4f2f39884ac6cf2fdf6b8a7813e61c73745`.

Before Verify, the option/summary must describe available unverified bytes. After actual Verify completes, require both option and summary to say verified during this review, with file preparation explicitly rechecking bytes. Prepare and download the original once and rehash its actual bytes. Re-review originals (or select another real available original if naturally present), require verified state and preparation controls to reset, then Verify the selected authentic original again. Do not claim cancellation/error timing when not observed; focused source tests retain those distinctions. Preserve reader opacity, raw storage and original content. Recovery listing is not proof that the reviewed old channel earned that picture.

## Scope and evidence

Use native scoped mouse/key and actual file-input selection; read-only evaluations collect state/geometry/hashes. Main sample is actual 1280×800 CSS pixels; verify viewport and screenshot dimensions. No physical devices, controller-only/touch-only, audibility, full responsive matrix, additional recovery family, source-runtime changes or whole-P01 acceptance is claimed. Keep earlier failure reports and original fixtures byte-identical. Output compact action receipts, a few screenshots, endpoint comparisons, any exported original, and a finite manifest below the stated budget.

Templates are preserved byte-for-byte. Active tools add only new immutable identity gating, the newly authorized Copy action, removal of historical navigation, finite CDP connection time, and terminate/kill cleanup. The prior helper behavior and all changes are visible in `tools.diff`. A syntax and unresolved-launch refusal check may run locally; it must never start Chrome or make network requests.
