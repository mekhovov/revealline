#!/usr/bin/env python3
"""Explicit GO-only serial same-profile public launch; no default/automatic browser."""
from pathlib import Path
import argparse,datetime,fcntl,hashlib,http.client,json,os,socket,subprocess,time
from urllib.parse import urlsplit
from public_binding import verify,C,P,raw
from public_capacity import check
R=P/'run';PHASES=C['phases']
def gone(pid):
 try:os.kill(pid,0);return False
 except ProcessLookupError:return True

def closed(port):
 with socket.socket() as s:s.settimeout(.5);return s.connect_ex(('127.0.0.1',port))!=0

def peers():
 # Read-only ownership audit. Unrelated browser processes are not targets or outputs.
 rows=[]
 for line in subprocess.check_output(['ps','-axo','pid=,command='],text=True).splitlines():
  if '/Google Chrome' not in line or '--user-data-dir=' not in line or '--type=' in line:continue
  profile=line.split('--user-data-dir=',1)[1].split(' ',1)[0]
  if any(profile.startswith(str(Path(root)/'.cache/cross-mode/p01')+'/') for root in [C['sourceRoot'],C['authorityRoot']]):rows.append({'pid':int(line.strip().split(None,1)[0]),'profile':profile})
 return rows

def write(path,value):
 with path.open('x') as f:f.write(json.dumps(value,indent=2)+'\n')

def main():
 a=argparse.ArgumentParser();a.add_argument('--go',action='store_true');a.add_argument('--phase',choices=PHASES,required=True);x=a.parse_args()
 assert x.go,'Prepared only: actual root Pages GO is required'
 identity=verify();idx=PHASES.index(x.phase);phase=R/x.phase;profile=R/'profile'
 lock=(P/'serial-browser.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 observed_peers=peers();assert not observed_peers,'Another owned P01 browser is active; serialized execution refused: '+json.dumps(observed_peers)
 prior=None
 if idx==0:
  assert not R.exists(),'Initial run already exists; no automatic retry or reset'
 else:
  assert R.is_dir() and profile.is_dir() and not profile.is_symlink()
  assert not phase.exists(),'Planned phase already exists; preserve it'
  previous=R/PHASES[idx-1];prior=json.loads((previous/'launch.json').read_text());end=json.loads((previous/'exit.json').read_text())
  assert end['pid']==prior['pid'] and end['exitCode']==0 and end['pidExited'] is True and end['endpointClosed'] is True
  assert gone(prior['pid']) and closed(prior['port']),'Previous owned browser did not fully exit'
  assert prior['profile']==str(profile) and prior['identitySha256']==hashlib.sha256((P/'verified-public-identity.json').read_bytes()).hexdigest()
 check('before-launch',identity)
 if idx==0:R.mkdir();profile.mkdir()
 phase.mkdir()
 args=['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--headless=new','--remote-debugging-port=0','--enable-automation','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-features=OptimizationGuideModelDownloading,OptimizationHintsFetching,OptimizationTargetPrediction,OptimizationHints','--disable-gpu-shader-disk-cache','--disable-default-apps','--disable-sync','--enable-unsafe-swiftshader','--password-store=basic','--use-mock-keychain','--disable-quic','--disable-extensions','--disk-cache-size=4194304','--media-cache-size=1048576','--window-size=390,844','--user-data-dir='+str(profile)]
 proxy=None
 if idx in [1,2]:
  ready=R/'refusal-proxy-ready.json';proxy=json.loads(ready.read_text());u=urlsplit(proxy['proxy'])
  assert u.scheme=='http' and u.hostname=='127.0.0.1' and not u.username and not u.password and u.path in ['', '/'] and u.port==proxy['port'] and proxy['host']=='127.0.0.1'
  assert proxy['events']==str(R/'refusal-events.jsonl') and proxy['maxEvents']==1000 and proxy['upstreamConnections']=='none-by-construction'
  if idx==1:
   assert not gone(proxy['pid']) and not closed(proxy['port'])
   command=subprocess.check_output(['ps','-p',str(proxy['pid']),'-o','command='],text=True)
   assert str(P/'refusal_proxy.py') in command and str(ready) in command and str(R/'refusal-events.jsonl') in command,'Proxy PID/argv mismatch'
   args+=['--proxy-server='+proxy['proxy'],'--proxy-bypass-list=<-loopback>']
  else:
   assert gone(proxy['pid']) and closed(proxy['port']),'Restore only after prior browser and owned proxy both closed'
   args+=['--no-proxy-server']
 else:args+=['--no-proxy-server']
 args+=['about:blank']
 env={k:v for k,v in os.environ.items() if k.lower() not in {'http_proxy','https_proxy','all_proxy','no_proxy'} and not k.startswith('AGENT_BROWSER_')}
 started=time.time();proc=None
 try:
  assert not peers(),'Concurrent P01 browser appeared before launch'
  proc=subprocess.Popen(args,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  deadline=time.monotonic()+20
  while time.monotonic()<deadline:
   pf=profile/'DevToolsActivePort'
   if pf.exists() and pf.stat().st_mtime>=started:
    lines=pf.read_text().splitlines();port=int(lines[0]);conn=http.client.HTTPConnection('127.0.0.1',port,timeout=1)
    try:conn.request('GET','/json/version');response=conn.getresponse();assert response.status==200;version=json.loads(response.read())
    finally:conn.close()
    endpoint=urlsplit(version['webSocketDebuggerUrl']);assert endpoint.scheme=='ws' and endpoint.hostname in ['127.0.0.1','localhost'] and endpoint.port==port and endpoint.path==lines[1]
    command=subprocess.check_output(['ps','-p',str(proc.pid),'-o','command='],text=True);assert '--user-data-dir='+str(profile) in command
    break
   assert proc.poll() is None,'Owned Chrome exited before endpoint';time.sleep(.1)
  else:raise RuntimeError('No new exact owned endpoint')
  if prior:assert proc.pid!=prior['pid'] and version['webSocketDebuggerUrl']!=prior['endpoint'],'Cold start reused prior process/endpoint'
  receipt={'startedAt':started,'phase':x.phase,'pid':proc.pid,'profile':str(profile),'arguments':args,'endpoint':version['webSocketDebuggerUrl'],'port':port,'version':version,'scope':identity['scope'],'game':identity['url'],'explorer':C['explorer'],'proxyMode':'refused' if idx==1 else 'online','proxy':proxy,'profileReset':False,'identitySha256':hashlib.sha256((P/'verified-public-identity.json').read_bytes()).hexdigest(),'rootAuthorizationSha256':hashlib.sha256((P/'root-authorization.json').read_bytes()).hexdigest(),'serialization':{'peerAllowanceBytes':33554432,'otherP01Browsers':observed_peers,'ownerLock':str(P/'serial-browser.lock')},'initialTargetBindingRequired':True}
  write(phase/'launch.json',receipt);print(json.dumps(receipt),flush=True)
  while proc.poll() is None:
   assert time.time()-started<=C['limits']['browserSecondsPerProcess'],'Owned browser duration cap'
   assert all(row['pid']==proc.pid and row['profile']==str(profile) for row in peers()),'Peer browser violates serialized run'
   check('running',identity,x.phase);time.sleep(3)
  endpoint_closed=False
  for _ in range(10):
   if closed(port):endpoint_closed=True;break
   time.sleep(.1)
  result={'phase':x.phase,'pid':proc.pid,'exitCode':proc.returncode,'pidExited':gone(proc.pid),'endpointClosed':endpoint_closed,'capacity':check('after-exit',identity,x.phase)}
  write(phase/'exit.json',result)
  assert result['exitCode']==0 and result['pidExited'] and result['endpointClosed'],'Owned closure failed; retain attempt'
 except BaseException as error:
  if proc and proc.poll() is None:
   proc.terminate()
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
  write(phase/'launch-failure.json',{'type':type(error).__name__,'message':str(error),'phase':x.phase,'ownedPid':proc.pid if proc else None,'noAutomaticRetry':True})
  raise
 finally:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
if __name__=='__main__':main()
