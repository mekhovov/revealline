import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {WebSocket,createTransport,transportOptions} from '../ws-transport.mjs';
const D=path.dirname(fileURLToPath(import.meta.url));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const results=[];
async function exercise(bytes,refuse){
 const server=new WebSocket.Server({host:'127.0.0.1',port:0,perMessageDeflate:true});
 let client,timer;
 try{
  await new Promise((resolve,reject)=>{server.once('listening',resolve);server.once('error',reject);});
  const address=server.address();assert.equal(address.address,'127.0.0.1');
  const payload='a'.repeat(bytes),row={bytes,refuse,host:address.address,port:address.port,options:transportOptions,messages:0,errors:[],serverOfferedCompression:true};
  server.on('connection',socket=>{socket.on('error',()=>{});socket.send(payload,{compress:true},()=>{});});
  client=createTransport(`ws://127.0.0.1:${address.port}/fixture`);
  await new Promise((resolve,reject)=>{
   timer=setTimeout(()=>reject(Error('Bounded local transport timeout')),10000);
   client.addEventListener('open',()=>{row.opened=true;row.negotiatedExtensions=client.extensions;});
   // A persistent post-open listener observes metadata only, just like the prepared CDP owner.
   client.addEventListener('error',event=>{const e=event.error;row.errors.push({name:e.name,code:e.code,messageBytes:Buffer.byteLength(e.message),messageSha256:sha(e.message)});if(!refuse)reject(Error('Unexpected accepted-case transport error'));});
   client.addEventListener('message',event=>{row.messages++;row.receivedBytes=Buffer.byteLength(event.data);row.receivedSha256=sha(event.data);if(refuse)reject(Error('Over-bound message was delivered'));else client.close(1000);});
   client.addEventListener('close',event=>{row.closeCode=event.code;row.wasClean=event.wasClean;resolve();});
  });
  assert.equal(row.opened,true);assert.equal(row.negotiatedExtensions,'');
  if(refuse){assert.equal(row.messages,0);assert.equal(row.errors.length,1);assert.equal(row.errors[0].code,'WS_ERR_UNSUPPORTED_MESSAGE_LENGTH');}
  else{assert(bytes>4*1024*1024);assert.equal(row.messages,1);assert.equal(row.receivedBytes,bytes);assert.equal(row.receivedSha256,sha(payload));assert.equal(row.errors.length,0);}
  results.push({...row,passed:true});
 }finally{
  clearTimeout(timer);client?.terminate();for(const peer of server.clients)peer.terminate();await new Promise(resolve=>server.close(resolve));
 }
}
await exercise(5*1024*1024,false);
await exercise(16*1024*1024+1,true);
const receipt={status:'PASS_LOCAL_TRANSPORT_ONLY',node:process.version,execPath:process.execPath,options:transportOptions,results,rawPayloadLogged:false,browserStarted:false,productNetworkRequests:0,currentR1Cause:'Still unresolved; this validates the explicit replacement transport, not the cause of the prior1006.',allOwnedLoopbackServersClosed:true};
fs.writeFileSync(path.join(D,'receipt.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt));
