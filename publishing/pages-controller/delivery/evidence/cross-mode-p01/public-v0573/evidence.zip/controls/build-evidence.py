#!/usr/bin/env python3
"""Deterministic evidence packaging only. Never infers P01 acceptance or fetches data."""
import argparse, hashlib, json, re, shutil, stat, zipfile
from pathlib import Path, PurePosixPath
HERE=Path(__file__).resolve().parent
F=HERE.parent
SOURCE='7945c6d07714d41cee9b6f848059b8dc18aed86c'
CONTROLLER='016b14af6b42d27de1f194c1ac5d48f7a0b3eaa9'
FAMILY_ROOTS={'P1':F/'public-corrective-browser-preparation','P3':F/'public-p3-transfer-recovery-preparation','P2':F.parent/'public-v0573-history-offline-r2'}
MAX_FILES=2000;MAX_BYTES=64*1024*1024;MAX_MEMBER=16*1024*1024;RESERVE=512*1024*1024
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda v:(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode()
SECRET=re.compile(rb'(?i)(?:gh[pousr]_[a-z0-9]{24,}|github_pat_[a-z0-9_]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|[?&](?:x-amz-signature|sig|signature|token)=[a-z0-9%+/_.=-]{32,}|authorization["\s:=>]+(?:bearer|token)\s+[a-z0-9_.-]{24,})')
TEXT={'.json','.jsonl','.log','.md','.txt','.mjs','.js','.py','.sh','.diff','.stdout','.stderr'}
inputs={}
def require(ok,message):
 if not ok:raise ValueError(message)
def safe_member(value):
 require(isinstance(value,str) and value and len(value)<=1024,'Invalid member')
 require(not any(ord(c)<32 or ord(c)==127 for c in value) and '\\' not in value,'Unsafe member')
 require(not value.startswith('/') and all(x not in ('','.', '..') for x in value.split('/')),'Unsafe member path')
 parts=PurePosixPath(value).parts
 require(not set(parts)&{'profile','node_modules','Cookies','Cache','Code Cache','GPUCache','Local Storage','IndexedDB','leveldb'},'Profile/cache member refused')
 require(parts[-1] not in {'source.tar','distribution.zip','qualified-artifact-original.zip'},'Payload member refused')
 return value
def ordinary(p):
 p=Path(p)
 require(p.is_absolute() and str(p)==str(p.resolve()),'Canonical absolute source path required')
 allowed=[F,FAMILY_ROOTS['P2']]
 require(any(p==r or r in p.parents for r in allowed),'Source outside explicit evidence roots')
 for c in [p,*p.parents]:
  require(not c.is_symlink(),'Symlink source refused')
 require(p.is_file(),'Missing/nonordinary evidence: '+str(p))
 require(not set(p.parts)&{'profile','node_modules','Cookies','Cache','Code Cache','GPUCache','Local Storage','IndexedDB','leveldb'},'Profile/cache source refused')
 require(p.name not in {'source.tar','distribution.zip','qualified-artifact-original.zip'},'Payload source refused')
 return p
def read_pin(pin):
 require(isinstance(pin,dict) and set(pin)>={'path','bytes','sha256'},'Missing original pin')
 require(type(pin['bytes']) is int and 0<=pin['bytes']<=MAX_MEMBER and re.fullmatch('[a-f0-9]{64}',pin['sha256']),'Invalid pin')
 p=ordinary(pin['path']);before=p.stat();require(before.st_size==pin['bytes'],'Unexpected original byte length: '+str(p));b=p.read_bytes();after=p.stat()
 require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns),'Source changed while reading')
 require(len(b)==pin['bytes'] and sha(b)==pin['sha256'],'Original pin mismatch: '+str(p))
 inputs[str(p)]={'path':str(p),'bytes':len(b),'sha256':sha(b)}
 return b
def scan(member,b):
 if PurePosixPath(member).suffix.lower() in TEXT or PurePosixPath(member).suffix=='':
  require(not SECRET.search(b),'Potential credential/signed URL in '+member)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--binding',required=True);ap.add_argument('--binding-sha',required=True);ap.add_argument('--out',required=True);ap.add_argument('--assemble',action='store_true');a=ap.parse_args()
 require(a.assemble,'Preparation only: explicit --assemble and reviewed root GO binding required')
 require(re.fullmatch('[a-f0-9]{64}',a.binding_sha),'Binding SHA required')
 bp=ordinary(Path(a.binding).absolute());require(bp.stat().st_size<=MAX_MEMBER,'Oversized binding');bb=bp.read_bytes();require(sha(bb)==a.binding_sha,'Reviewed binding changed');binding=json.loads(bb)
 inputs[str(bp)]={'path':str(bp),'bytes':len(bb),'sha256':sha(bb)}
 require(binding.get('format')=='revealline-p01-evidence-assembly-binding.v1' and binding.get('rootGo') is True,'Actual root GO missing')
 require(binding.get('sourceRevision')==SOURCE and binding.get('publishingRevision')==CONTROLLER,'Wrong source/controller')
 require(binding.get('phaseAccepted') is False,'Builder cannot set acceptance')
 require(binding['builderPin']['path']==str(Path(__file__).resolve()),'Wrong reviewed builder');read_pin(binding['builderPin'])
 require(set(binding['templatePins'])=={'README.template.md','acceptance.template.json'},'Both reviewed templates required')
 for name,pin in binding['templatePins'].items():
  require(pin['path']==str(HERE/name),'Wrong reviewed template');read_pin(pin)
 selected=json.loads(read_pin(binding['selectionPin']))
 require(selected.get('sourceRevision')==SOURCE and selected.get('publishingRevision')==CONTROLLER,'Selection identity changed')
 require(selected.get('phaseAccepted') is False,'Unexpected selection acceptance')
 reuse=selected['reuseWithoutRecopy'];asset=reuse['sourceQualificationEvidenceAsset']
 require(asset['releaseId']==389425275 and asset['assetId']==566383839 and asset['bytes']==23954493 and asset['sha256']=='6260b4099024b7eee3fa5323f9998c3c706a0a9efb8577895bd15ddad5ba3f8e','Published source-evidence reference changed')
 require(asset['url']=='https://github.com/mekhovov/revealline/releases/download/v0.57.3/source-qualification-evidence.zip','Source evidence URL changed')
 closing=json.loads(read_pin(binding['completedFamiliesReviewPin']))
 require(closing.get('status')=='READY_FOR_FINAL_P01_EVIDENCE_ASSEMBLY' and closing.get('sourceRevision')==SOURCE and closing.get('publishingRevision')==CONTROLLER and closing.get('allFamiliesClosed') is True,'Final actual family-completion review missing')
 require(closing.get('phaseAccepted') is False,'Completion review cannot infer phase acceptance')
 require(set(binding['families'])==set(FAMILY_ROOTS) and set(closing['families'])==set(FAMILY_ROOTS),'Exactly P1/P2/P3 required')
 entries=[];canonical={};mapping=[]
 def add(pin,member,alias=None):
  member=safe_member(member);require(member!='manifest.json','Reserved output index member');b=read_pin(pin);scan(member,b)
  target=safe_member(alias) if alias else member
  row={'source':pin['path'],'requestedMember':member,'member':target,'bytes':len(b),'sha256':sha(b)}
  if alias:row['sameBytesAsMember']=target
  mapping.append(row)
  if alias:return
  if member in canonical:
   require(canonical[member]['path']==pin['path'] and canonical[member]['bytes']==len(b) and canonical[member]['sha256']==sha(b),'Duplicate member differs')
   return
  canonical[member]={'path':pin['path'],'bytes':len(b),'sha256':sha(b)};entries.append((member,pin))
 for row in selected['selected']:
  require(type(row.get('copy')) is bool,'Explicit copy/alias required')
  add(row,row['member'],None if row['copy'] else row['sameBytesAsMember'])
 add(binding['selectionPin'],'controls/selection-proposal.json')
 add(binding['completedFamiliesReviewPin'],'reviews/completed-families.json')
 add(inputs[str(bp)],'controls/assembly-binding.json')
 for family in ['P1','P2','P3']:
  f=binding['families'][family];require(isinstance(f,dict),'Unresolved family '+family)
  root=FAMILY_ROOTS[family];require(f['root']==str(root),'Unreviewed family root')
  mp=f['manifestPin'];m=json.loads(read_pin(mp));require(root in Path(mp['path']).parents,'Family manifest outside root')
  review=closing['families'][family]
  require(review.get('closed') is True and review.get('allOriginalsIncludingFailuresSelected') is True and review.get('manifestSha256')==mp['sha256'],'Incomplete family completion: '+family)
  require(review.get('disposition') in ['passed','passed-with-limits','failed-retained','inconclusive-retained'] and isinstance(review.get('limits'),list),'Family limits/disposition missing')
  require(isinstance(m.get('files'),list) and m['files'],'Missing final manifest rows')
  require(isinstance(f.get('reportPins'),list) and f['reportPins'] and isinstance(f.get('closurePins'),list) and f['closurePins'],'Actual reports/closures required')
  members=set();manifest_pins={}
  for row in m['files']:
   rel=safe_member(row['path']);require(rel not in members,'Duplicate family manifest path');members.add(rel)
   pin={'path':str(root/rel),'bytes':row['bytes'],'sha256':row['sha256']};manifest_pins[pin['path']]=pin;add(pin,'native/'+family+'/'+rel)
  for pin in f['reportPins']+f['closurePins']:
   require(manifest_pins.get(pin['path'])==pin,'Report/closure must be an original in the family manifest');read_pin(pin)
  add(mp,'native/'+family+'/final-manifest.json')
 for pin in binding.get('additionalReviewedPins',[]):add(pin,pin['member'])
 for row in mapping:
  target=canonical.get(row['member']);require(target and target['bytes']==row['bytes'] and target['sha256']==row['sha256'],'Alias target bytes differ/missing')
 require(len(canonical)<=MAX_FILES and sum(p['bytes'] for p in canonical.values())<=MAX_BYTES,'Evidence collection exceeds bound')
 # Templates stay pending even once evidence is complete; only the parent may later decide acceptance.
 for name in ['README.template.md','acceptance.template.json']:
  pin=binding['templatePins'][name];add(pin,'templates/'+name)
 add(binding['builderPin'],'controls/build-evidence.py')
 index={'format':'revealline-p01-delivery-evidence-index.v1','sourceRevision':SOURCE,'publishingRevision':CONTROLLER,'phaseAccepted':False,'sourceToMember':sorted(mapping,key=lambda x:(x['member'],x['source'])),'files':[{'path':n,'bytes':p['bytes'],'sha256':p['sha256']} for n,p in sorted(entries)],'reuseWithoutRecopy':reuse,'familyDispositions':closing['families'],'scope':'Completed original evidence package, including failures/limits. Packaging is not a phase acceptance decision.'}
 index_bytes=encode(index);require(len(index_bytes)<=4*1024*1024,'Index unexpectedly large');scan('manifest.json',index_bytes)
 total=sum(p['bytes'] for p in canonical.values())+len(index_bytes);require(total<=MAX_BYTES and len(entries)+1<=MAX_FILES,'Final bounded output exceeded')
 require(re.fullmatch('[a-z0-9][a-z0-9-]{0,60}',a.out),'Output must be fresh simple name')
 output_root=F/'acceptance-evidence-output';require(not output_root.is_symlink(),'Symlink output root');output_root.mkdir(exist_ok=True)
 output=output_root/a.out;require(not output.exists(),'Exclusive output already exists')
 require(shutil.disk_usage(F).free>=RESERVE+2*total+2*1024*1024,'Insufficient reserved disk')
 output.mkdir();archive=output/'evidence.zip'
 def zi(name):
  z=zipfile.ZipInfo(name,(1980,1,1,0,0,0));z.create_system=3;z.external_attr=(stat.S_IFREG|0o644)<<16;z.compress_type=zipfile.ZIP_DEFLATED;return z
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=False) as z:
  for name,pin in sorted(entries):z.writestr(zi(name),read_pin(pin),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
  z.writestr(zi('manifest.json'),index_bytes,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
 expected={n:p for n,p in entries};expected['manifest.json']={'bytes':len(index_bytes),'sha256':sha(index_bytes)}
 with zipfile.ZipFile(archive) as z:
  require(z.testzip() is None,'ZIP CRC failure');require(len(z.infolist())==len(expected) and set(z.namelist())==set(expected),'ZIP member set differs')
  for member in z.infolist():
   safe_member(member.filename);b=z.read(member);pin=expected[member.filename]
   require(member.file_size==pin['bytes'] and sha(b)==pin['sha256'],'ZIP member original-byte mismatch')
 for pin in list(inputs.values()):read_pin(pin)
 with (output/'manifest.json').open('xb') as f:f.write(index_bytes)
 blob=archive.read_bytes();record={'format':'revealline-p01-delivery-evidence-record.v1','status':'ASSEMBLED_AND_ALL_MEMBERS_VERIFIED','phaseAccepted':False,'archive':{'path':'evidence.zip','bytes':len(blob),'sha256':sha(blob)},'manifest':{'path':'manifest.json','bytes':len(index_bytes),'sha256':sha(index_bytes)},'members':len(expected),'originalBytes':total,'allSourcesReread':True,'allCRCsAndMemberHashesVerified':True,'rootBindingSha256':a.binding_sha,'sourceRevision':SOURCE,'publishingRevision':CONTROLLER,'limits':'Parent acceptance decision remains separate. No release asset, runtime payload or browser profile copied.'}
 with (output/'record.json').open('xb') as f:f.write(encode(record))
 print(json.dumps(record))
if __name__=='__main__':main()
