"""Bounded subprocess capture for small read-only metadata; never a payload downloader."""
import selectors
import shutil
import subprocess
import time
from pathlib import Path

RESERVE = 512 * 1024**2
TOTAL_LIMIT = 32 * 1024**2
OUT_LIMIT = 2 * 1024**2
ERR_LIMIT = 64 * 1024


def capacity(root, addition=0, *, scope=None, scope_limit=None):
    root = Path(root)
    used = sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
    if used + addition > TOTAL_LIMIT:
        raise RuntimeError('Aggregate execution cap')
    if scope is not None:
        subtotal = sum(p.stat().st_size for p in Path(scope).rglob('*') if p.is_file() and not p.is_symlink())
        if subtotal + addition > scope_limit:
            raise RuntimeError('Managed metadata cap')
    if shutil.disk_usage(root).free < RESERVE + addition + 65536:
        raise RuntimeError('Free-space reserve')


def capture(cmd, *, root, scope, scope_limit=8*1024**2, timeout=45, out_limit=OUT_LIMIT, err_limit=ERR_LIMIT):
    capacity(root, out_limit + err_limit + 65536, scope=scope, scope_limit=scope_limit)
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    selected = selectors.DefaultSelector()
    selected.register(process.stdout, selectors.EVENT_READ, 'out')
    selected.register(process.stderr, selectors.EVENT_READ, 'err')
    buffers = {'out': bytearray(), 'err': bytearray()}
    limits = {'out': out_limit, 'err': err_limit}
    deadline = time.monotonic() + timeout
    timed = oversized = False
    reserve_error = None
    try:
        while selected.get_map():
            if time.monotonic() >= deadline:
                timed = True
                break
            for key, _ in selected.select(min(.2, max(0, deadline-time.monotonic()))):
                chunk = key.fileobj.read1(65536)
                if not chunk:
                    selected.unregister(key.fileobj)
                    continue
                room = limits[key.data] + 1 - len(buffers[key.data])
                buffers[key.data].extend(chunk[:max(0, room)])
                if len(buffers[key.data]) > limits[key.data]:
                    oversized = True
                    break
                try:
                    capacity(root, sum(map(len, buffers.values())) + 65536, scope=scope, scope_limit=scope_limit)
                except RuntimeError as error:
                    reserve_error = str(error)
                    break
            if oversized or reserve_error:
                break
        # A child may close both pipes and continue running: the same deadline applies.
        if not (timed or oversized or reserve_error):
            try:
                code = process.wait(timeout=max(.001, deadline-time.monotonic()))
            except subprocess.TimeoutExpired:
                timed = True
    finally:
        if timed or oversized or reserve_error:
            process.kill()
        code = process.wait(timeout=5)
        selected.close()
        process.stdout.close()
        process.stderr.close()
    stdout, stderr = bytes(buffers['out']), bytes(buffers['err'])
    complete = not (timed or oversized or reserve_error)
    return {'stdout': stdout, 'stderr': stderr, 'exitCode': code, 'timedOut': timed,
            'oversized': oversized, 'reserveError': reserve_error, 'completeOriginal': complete,
            'receivedBytes': len(stdout), 'stderrBytes': len(stderr)}
