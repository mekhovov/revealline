EXECUTION_REQUEST_SHA = 'e1e09326f45b9344c54ba10028028fbbdc9a74d64f230560774284519de48580'
from pathlib import Path
import datetime,hashlib,json,subprocess,time,shutil
D=Path(__file__).resolve().parent
def capacity_gate(root):
 used=sum(p.stat().st_size for p in root.rglob('*') if p.is_file() and not p.is_symlink())
 assert used<=32*1024**2, 'Aggregate execution cap'
 assert shutil.disk_usage(root).free>=512*1024**2+(32*1024**2-used), 'Free-space reserve and remaining execution allowance'
 return used
capacity_gate(D.parent)
O=D/'execution-originals'
raw=(D/'execution-request.reviewed.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==EXECUTION_REQUEST_SHA;assert json.loads(raw)['reviewed'] is True
O.mkdir(exist_ok=False)
commands=[('before',['python3','-B',str(D/'collect-live.py'),'before'],120),('audit',['python3','-B',str(D/'http-tools/http_audit.py'),'--run','--workers','6'],1900),('after',['python3','-B',str(D/'collect-live.py'),'after'],120)]
for name,cmd,timeout in commands:
 capacity_gate(D.parent)
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();timed=False
 with (O/(name+'.stdout')).open('xb') as stdout,(O/(name+'.stderr')).open('xb') as stderr:
  try:p=subprocess.run(cmd,stdout=stdout,stderr=stderr,timeout=timeout);code=p.returncode
  except subprocess.TimeoutExpired:code=None;timed=True
 receipt={'command':cmd,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-t,'exitCode':code,'timedOut':timed}
 (O/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'step':name,**receipt}),flush=True)
 capacity_gate(D.parent)
 if name=='before' and code!=0:raise SystemExit('Before authorities failed; audit not started')
 if name=='audit' and timed:raise SystemExit('Audit process timeout; preserve outputs and diagnose before any continuation')
