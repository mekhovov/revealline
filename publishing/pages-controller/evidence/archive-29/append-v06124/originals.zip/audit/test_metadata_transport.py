"""Tiny local subprocess tests; no API or HTTP calls."""
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import metadata_transport as transport

class BoundsTests(unittest.TestCase):
    def capture(self, script, **kwargs):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            return transport.capture([sys.executable,'-c',script],root=root,scope=root,**kwargs)

    def test_success_retains_exact_streams(self):
        result=self.capture("import sys;sys.stdout.write('original');sys.stderr.write('diagnostic')")
        self.assertTrue(result['completeOriginal'])
        self.assertEqual((result['exitCode'],result['stdout'],result['stderr']),(0,b'original',b'diagnostic'))

    def test_stdout_and_stderr_stop_at_cap_plus_one(self):
        for name,script in [('stdout',"import sys;sys.stdout.write('x'*100000)"),('stderr',"import sys;sys.stderr.write('x'*100000)")]:
            with self.subTest(stream=name):
                result=self.capture(script,out_limit=32,err_limit=32)
                self.assertTrue(result['oversized']);self.assertFalse(result['completeOriginal']);self.assertEqual(len(result[name]),33)

    def test_deadline_covers_open_or_closed_pipes(self):
        for script in ["import time;time.sleep(5)","import os,time;os.close(1);os.close(2);time.sleep(5)"]:
            result=self.capture(script,timeout=.15)
            self.assertTrue(result['timedOut']);self.assertFalse(result['completeOriginal'])

    def test_reserve_refuses_before_process(self):
        with tempfile.TemporaryDirectory() as d,patch.object(transport.shutil,'disk_usage',return_value=SimpleNamespace(free=transport.RESERVE-1)),patch.object(transport.subprocess,'Popen') as process:
            with self.assertRaisesRegex(RuntimeError,'reserve'):
                transport.capture(['forbidden'],root=Path(d),scope=Path(d))
            process.assert_not_called()

    def test_aggregate_cap_refuses_before_process(self):
        with tempfile.TemporaryDirectory() as d,patch.object(transport,'TOTAL_LIMIT',1),patch.object(transport.subprocess,'Popen') as process:
            with self.assertRaisesRegex(RuntimeError,'Aggregate'):
                transport.capture(['forbidden'],root=Path(d),scope=Path(d))
            process.assert_not_called()

if __name__=='__main__':unittest.main()
