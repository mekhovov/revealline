from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,datetime,hashlib,json,subprocess,uuid,re,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from metadata_transport import capture,capacity
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['before','after']);args=parser.parse_args()
request_raw=(root/'execution-request.reviewed.json').read_bytes();request=json.loads(request_raw)
assert request['reviewed'] is True
assert isinstance(request['archiveCommit'],str) and re.fullmatch('[a-f0-9]{40}',request['archiveCommit'])
assert all(type(request[k]) is int and request[k]>0 for k in ['runId','deploymentId','deploymentStatusId'])
source_raw=(root/'inputs/immutable-source-authorities.json').read_bytes()
assert hashlib.sha256(source_raw).hexdigest()=='2c3fc41c6e5e602b1145341bb34da4fd36449bab3d25f2b91f5773eefd36e695'
source_authorities=json.loads(source_raw);assert source_authorities['repository']=='mekhovov/revealline'
capacity(root.parent,scope=root/'live-authorities',scope_limit=8*1024**2)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=root/'live-authorities'/(args.stage+'-'+stamp+'-'+uuid.uuid4().hex[:8]);out.mkdir(parents=True,exist_ok=False)
repo='repos/mekhovov/revealline-archive-29'
paths={'main':repo+'/git/ref/heads/main','run':repo+'/actions/runs/'+str(request['runId']),'deployment':repo+'/deployments/'+str(request['deploymentId']),'statuses':repo+'/deployments/'+str(request['deploymentId'])+'/statuses'}
for authority in source_authorities['releases']:
 version=authority['version']
 paths['source-ref-'+version]='repos/mekhovov/revealline/git/ref/tags/'+version
 paths['source-tag-'+version]='repos/mekhovov/revealline/git/tags/'+authority['tagObject']
 paths['source-release-'+version]='repos/mekhovov/revealline/releases/tags/'+version
def collect(item):
 role,endpoint=item;cmd=['gh','api',endpoint]
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result=capture(cmd,root=root.parent,scope=root/'live-authorities')
 stdout,stderr=result.pop('stdout'),result.pop('stderr')
 (out/(role+'.json')).write_bytes(stdout);(out/(role+'.stderr')).write_bytes(stderr)
 receipt={'command':cmd,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),**result}
 (out/(role+'.attempt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 capacity(root.parent,scope=root/'live-authorities',scope_limit=8*1024**2)
 return role,result['exitCode'],not result['completeOriginal']
collected=[collect(item) for item in paths.items()]
errors=[];docs={}
for role,code,timed in collected:
 if code!=0 or timed:errors.append(role+' API collection failed');continue
 try:docs[role]=json.loads((out/(role+'.json')).read_bytes())
 except Exception as e:errors.append(role+': '+str(e))
if not errors:
 if docs['main']['object']['sha']!=request['archiveCommit']:errors.append('Live main drift')
 run=docs['run']
 if not(run['id']==request['runId'] and run['head_sha']==request['archiveCommit'] and run['status']=='completed' and run['conclusion']=='success'):errors.append('Live run changed')
 dep=docs['deployment']
 if not(dep['id']==request['deploymentId'] and dep['sha']==request['archiveCommit'] and dep['environment']=='github-pages'):errors.append('Live deployment changed')
 status=max(docs['statuses'],key=lambda s:s['id']) if docs['statuses'] else {}
 if not(status.get('id')==request['deploymentStatusId'] and status.get('state')=='success' and status.get('environment_url')=='https://mekhovov.github.io/revealline-archive-29/'):errors.append('Live latest status changed')
if not errors:
 for expected in source_authorities['releases']:
  version=expected['version'];ref=docs['source-ref-'+version];tag=docs['source-tag-'+version];release=docs['source-release-'+version]
  if not(ref['ref']=='refs/tags/'+version and ref['object']['type']=='tag' and ref['object']['sha']==expected['tagObject'] and tag['sha']==expected['tagObject'] and tag['object']['type']=='commit' and tag['object']['sha']==expected['sourceRevision']):errors.append('Immutable source tag changed: '+version)
  projection=sorted([{k:asset[k] for k in ['id','name','size','digest','state','browser_download_url']} for asset in release['assets']],key=lambda item:item['name'])
  if not(release['id']==expected['releaseId'] and release['tag_name']==version and release['draft'] is False and release['prerelease'] is False and projection==expected['assets']):errors.append('Immutable release asset descriptors changed: '+version)
pins=[]
for p in sorted(out.iterdir()):
 if p.is_file():
  b=p.read_bytes();pins.append({'path':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
result={'status':'FAIL' if errors else 'PASS_LIVE_IDENTITIES_UNCHANGED','stage':args.stage,'directory':str(out),'archiveCommit':request['archiveCommit'],'runId':request['runId'],'deploymentId':request['deploymentId'],'deploymentStatusId':request['deploymentStatusId'],'executionRequestSha256':hashlib.sha256(request_raw).hexdigest(),'errors':errors,'pins':pins,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attemptsPerEndpoint':1,'immutableSourceAuthoritiesSha256':hashlib.sha256(source_raw).hexdigest(),'immutableSourceVersions':[r['version'] for r in source_authorities['releases']],'sourceAuthoritiesUnchanged':not errors}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'directory':str(out),'errors':errors}));raise SystemExit(bool(errors))
