"""Exercise actual collector descriptor checks against local original pins; no network."""
import ast
import copy
import json
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parent
SOURCE=(ROOT/'http/collect-live.py').read_text()
BLOCK=next(node for node in ast.parse(SOURCE).body if isinstance(node,ast.If) and any(isinstance(child,ast.For) and ast.unparse(child.target)=='expected' for child in node.body))
CODE=compile(ast.Module(body=[BLOCK],type_ignores=[]),'<collector-source-authority-check>','exec')

class SourceTests(unittest.TestCase):
    def fixture(self):
        expected=json.loads((ROOT/'http/inputs/immutable-source-authorities.json').read_bytes());docs={}
        for row in expected['releases']:
            v=row['version'];docs['source-ref-'+v]={'ref':'refs/tags/'+v,'object':{'type':'tag','sha':row['tagObject']}}
            docs['source-tag-'+v]={'sha':row['tagObject'],'object':{'type':'commit','sha':row['sourceRevision']}}
            docs['source-release-'+v]={'id':row['releaseId'],'tag_name':v,'draft':False,'prerelease':False,'assets':copy.deepcopy(row['assets'])}
        return expected,docs

    def check(self,expected,docs):
        scope={'source_authorities':expected,'docs':docs,'errors':[]};exec(CODE,scope);return scope['errors']

    def test_both_exact_release_cohorts_pass(self):
        self.assertEqual(self.check(*self.fixture()),[])

    def test_mutable_download_counts_do_not_change_immutable_identity(self):
        expected,docs=self.fixture()
        for v in ['v0.61.23','v0.61.24']:
            for a in docs['source-release-'+v]['assets']:a['download_count']=123
        self.assertEqual(self.check(expected,docs),[])

    def test_tag_or_asset_drift_in_either_cohort_refuses(self):
        for v in ['v0.61.23','v0.61.24']:
            for kind in ['tag','digest','missing','duplicate']:
                with self.subTest(version=v,kind=kind):
                    expected,docs=self.fixture()
                    if kind=='tag':docs['source-tag-'+v]['object']['sha']='0'*40
                    else:
                        assets=docs['source-release-'+v]['assets']
                        if kind=='digest':assets[0]['digest']='sha256:'+'0'*64
                        elif kind=='missing':assets.pop()
                        else:assets.append(copy.deepcopy(assets[0]))
                    self.assertTrue(self.check(expected,docs))

if __name__=='__main__':unittest.main()
