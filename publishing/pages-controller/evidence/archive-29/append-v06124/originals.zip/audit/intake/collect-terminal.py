"""One finite read-only original metadata/log collection; never an artifact body GET."""
from pathlib import Path
import subprocess,json,hashlib,datetime,shutil,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from metadata_transport import capture,capacity
P=Path(__file__).resolve().parent;O=P/'terminal-r1'
REPO='mekhovov/revealline-archive-29';COMMIT='9abddbdf00b8b47d93df63d2d465588d06fb0988';TREE='bf8b5d0784bcd466669465b40c7c73a855625c2b';RUN=35415286512;ATTEMPT=1
assert COMMIT and TREE and type(RUN) is int and RUN>0 and type(ATTEMPT) is int and ATTEMPT>0, 'Actual run and attempt must be bound before requests'
O.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
def allowance(n):
 assert sum(f.stat().st_size for f in P.parent.rglob('*') if f.is_file() and not f.is_symlink())+n<=32*1024**2, 'Aggregate execution cap'
 assert sum(f.stat().st_size for f in P.rglob('*') if f.is_file())+n<8*1024**2
 assert shutil.disk_usage(P).free>512*1024**2+n+65536

def get(pair):
 name,path,raw=pair;cmd=['gh','api','repos/'+REPO+'/'+path]
 result=capture(cmd,root=P.parent,scope=P)
 stdout,stderr=result.pop('stdout'),result.pop('stderr')
 (O/(name+('.log' if raw else '.json'))).write_bytes(stdout);(O/(name+'.stderr')).write_bytes(stderr)
 (O/(name+'.receipt.json')).write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,**result,'artifactBodyGET':False},indent=2)+'\n')
 capacity(P.parent,scope=P,scope_limit=8*1024**2)
 assert result['completeOriginal'] and result['exitCode']==0, 'Incomplete original metadata retained; no automatic retry'
 return name,stdout if raw else json.loads(stdout)
queries=[('run',f'actions/runs/{RUN}',False),('jobs',f'actions/runs/{RUN}/attempts/{ATTEMPT}/jobs',False),('artifacts',f'actions/runs/{RUN}/artifacts',False),('main','git/ref/heads/main',False),('commit','git/commits/'+COMMIT,False),('deployments','deployments?sha='+COMMIT+'&per_page=10',False)]
data=dict(get(query) for query in queries)
assert data['main']['object']['sha']==data['commit']['sha']==data['run']['head_sha']==COMMIT and data['commit']['tree']['sha']==TREE
assert data['run']['id']==RUN and data['run']['run_attempt']==ATTEMPT and data['run']['event']=='push' and data['run']['path']=='.github/workflows/deploy.yml' and data['run']['status']=='completed' and data['run']['conclusion']=='success'
assert len(data['jobs']['jobs'])==2 and all(j['conclusion']=='success' for j in data['jobs']['jobs'])
dep=[d for d in data['deployments'] if d['environment']=='github-pages'];assert len(dep)==1;DEP=dep[0]['id']
art=[a for a in data['artifacts']['artifacts'] if a['name']=='archive29-verification-receipts'];assert len(art)==1;ART=art[0]['id']
more=[('deployment',f'deployments/{DEP}',False),('statuses',f'deployments/{DEP}/statuses',False),('artifact-descriptor',f'actions/artifacts/{ART}',False)]+[(f'job-{j["id"]}',f'actions/jobs/{j["id"]}/logs',True) for j in data['jobs']['jobs']]
data.update(dict(get(query) for query in more))
assert data['deployment']['sha']==COMMIT and data['deployment']['ref']=='main' and data['statuses'][0]['state']=='success' and data['statuses'][0]['environment_url'].rstrip('/')=='https://mekhovov.github.io/revealline-archive-29'
a=data['artifact-descriptor'];assert a['id']==ART and a['name']=='archive29-verification-receipts' and a['expired'] is False and a['workflow_run']['id']==RUN and a['workflow_run']['head_sha']==COMMIT and a['size_in_bytes']<2*1024**2 and a['digest'].startswith('sha256:')
pins=[]
for f in sorted(O.iterdir()):
 if f.is_file():b=f.read_bytes();pins.append({'path':str(f.relative_to(P)),'bytes':len(b),'sha256':sha(b)})
result={'status':'ACTUAL_ARCHIVE29_TERMINAL_ORIGINALS_READY','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':REPO,'archiveCommit':COMMIT,'archiveTree':TREE,'runId':RUN,'runAttempt':ATTEMPT,'deploymentId':DEP,'deploymentStatusId':data['statuses'][0]['id'],'artifactId':ART,'artifactBytes':a['size_in_bytes'],'artifactSha256':a['digest'][7:],'pins':pins,'artifactBodyGETs':0,'publicAcceptance':False}
(P/'terminal-originals.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='pins'},indent=2))
