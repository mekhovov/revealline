Retain the original v0.61.23 release for independent play when the main site advances. The original ZIP, annotated tag, qualified source and all metadata are pinned; the game is not rebuilt.

The new archive contains 702 files / 313,450,172 bytes and has zero previously accepted paths. It preserves the 800 MB budget, main-only deployment, explicit immutable tag fetch, corruption guards and full byte verification. Local archive/extractor fixtures passed 24 tests; six tag-fetch tests and the actual fetch-coverage check passed separately on Node20.19.5 and22.22.2.

Hosted extraction, public byte audit and actual archive browser acceptance remain required before main admission. Existing archives and the current public selector remain unchanged.
