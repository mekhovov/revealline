The v0.61.0 archive append stopped before extraction because its workflow fetched only the v0.60.9 tag. Fetch both exact tag refspecs so the existing source-identity check can verify every locked release.

Only one workflow line changes. Both refspecs were reconciled against source-lock.json; the 20 passing archive tests, exact original metadata, inventory, extractor and limits remain unchanged. Failed run35307751274 is retained; deployment was skipped and the public archive was not replaced. A new main push will perform the corrected deployment without retrying the unchanged failed run.
