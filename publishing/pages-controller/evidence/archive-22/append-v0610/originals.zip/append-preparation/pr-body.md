Adds the original v0.61.0 game and source qualification beside v0.60.9, so both remain playable when the main site advances. The prior 697 game, metadata and explorer rows stay byte-identical; only the archive landing page adds the new link.

The reviewed combined inventory is 1,393 files / 626,457,828 bytes, within the unchanged 800 MB limit. Source tags, original metadata, extractor, workflow and prior admission authority are preserved.

Validation: 20 archive tests pass, canonical inventory and all ten related file hashes verified, independent preservation/hunk review passed. The prior single-cohort fixture failure was retained and its explicit expectations updated for both cohorts without dropping the v0.60.9 assertions. Hosted preparation, public byte verification and native archived routes remain separate post-merge gates.
