"""Offline adapter refusal and exact ZIP allowlist tests; no GitHub calls."""
import hashlib, json, runpy, stat, sys, tempfile, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
SOURCE=(ROOT/'intake-small-receipt.py').read_text()
class IntakeTests(unittest.TestCase):
 def test_unreviewed_request_refuses_without_network(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);h=p/'intake-small-receipt.py';h.write_text(SOURCE);raw=b'{"reviewed":false}';(p/'small-receipt-request.reviewed.json').write_bytes(raw)
   with patch.object(sys,'argv',[str(h),hashlib.sha256(raw).hexdigest()]),patch('subprocess.Popen') as network:
    with self.assertRaises(AssertionError):runpy.run_path(str(h))
    network.assert_not_called()
 def test_wrong_review_digest_refuses_without_network(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);h=p/'intake-small-receipt.py';h.write_text(SOURCE);(p/'small-receipt-request.reviewed.json').write_text('{"reviewed":true}')
   with patch.object(sys,'argv',[str(h),'0'*64]),patch('subprocess.Popen') as network:
    with self.assertRaises(AssertionError):runpy.run_path(str(h))
    network.assert_not_called()
 def zip_check(self,kind):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);zpath=p/'fixture.zip';E=p/'receipts';E.mkdir();names=['receipt.json','expected-inventory.json','zip-receipt-v0.60.9.json','zip-receipt-v0.61.0.json']
   with zipfile.ZipFile(zpath,'w') as z:
    for n in names:
     i=zipfile.ZipInfo(n);i.external_attr=(stat.S_IFLNK|0o777)<<16 if kind=='symlink' and n==names[0] else (stat.S_IFREG|0o644)<<16
     z.writestr(i,b'X'*65 if kind=='oversized' and n==names[0] else b'{}')
    if kind=='extra':z.writestr('unexpected.json',b'{}')
    if kind=='traversal':z.writestr('../unexpected.json',b'{}')
   req={'maxUncompressedBytes':1024,'maxMemberBytes':64};expected=set(names)
   code=SOURCE[SOURCE.index('with zipfile.ZipFile(zip_path) as z:'):SOURCE.index('invraw=')]
   exec(compile(code,'real-intake-zip-guard','exec'),{'zipfile':zipfile,'stat':stat,'zip_path':zpath,'E':E,'req':req,'expected':expected})
   self.assertEqual(sorted(p.name for p in E.iterdir()),sorted(names))
 def test_exact_four_json_members_pass(self):self.zip_check('valid')
 def test_extra_member_refuses(self):
  with self.assertRaises(AssertionError):self.zip_check('extra')
 def test_traversal_refuses(self):
  with self.assertRaises(AssertionError):self.zip_check('traversal')
 def test_symlink_member_refuses(self):
  with self.assertRaises(AssertionError):self.zip_check('symlink')
 def test_oversized_member_refuses(self):
  with self.assertRaises(AssertionError):self.zip_check('oversized')
if __name__=='__main__':unittest.main()
