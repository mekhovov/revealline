"""Read-only local authority check; no browser or network. Actual root GO is mandatory."""
from pathlib import Path
import datetime,hashlib,json,stat
P=Path(__file__).resolve().parent;C=json.loads((P/'public-launch-config.json').read_text())
def raw(pin):
 p=Path(pin['path']);assert p.is_absolute() and str(p)==str(p.resolve()) and p.is_file() and not p.is_symlink(),'Ordinary pinned original required'
 b=p.read_bytes();assert len(b)==pin['bytes'] and hashlib.sha256(b).hexdigest()==pin['sha256'],str(p);return b
def value(pin):return json.loads(raw(pin))
def verify():
 A=json.loads((P/'root-authorization.json').read_text());assert A['rootGo'] is True and A['status']=='AUTHORIZED_ARCHIVE17_NATIVE_ONLINE','Actual root GO absent'
 now=datetime.datetime.now(datetime.timezone.utc)
 assert datetime.datetime.fromisoformat(A['notBefore'].replace('Z','+00:00'))<=now<datetime.datetime.fromisoformat(A['expiresAt'].replace('Z','+00:00')),'GO expired/not active'
 assert A['identityPin']['path']==str(P/'verified-public-identity.json');I=value(A['identityPin'])
 assert I['sourceRevision']==C['sourceRevision']=='7945c6d07714d41cee9b6f848059b8dc18aed86c' and I['sourceTree']==C['sourceTree']=='6c9970378ac236cd98cd7d1ed36965e298082cb0'
 assert I['version']==C['version']=='v0.57.3' and I['scope']==C['scope']=='https://mekhovov.github.io/revealline-archive-17/releases/v0.57.3/site/' and I['url']==C['game']==I['scope']+'game/'
 H=value(I['hostedHttpReviewPin']);F=value(I['afterHttpReviewPin']);inventory=value(I['inventoryPin']);receipt=value(I['receiptPin'])
 for evidence in [H,F,receipt]:assert evidence['archiveCommit']==I['archiveCommit'] and evidence.get('archiveTree',I['archiveTree'])==I['archiveTree']
 assert H['status']=='HOSTED_AND_FULL_CANONICAL_HTTP_PASS_NATIVE_PENDING' and H['allRowsAndAttemptsIndependentlyReconciled'] is True and H['failedFiles']==H['failedAttempts']==0 and H['files']==663 and H['bytes']==312654390
 assert F['status']=='PASS' and F['latestDeploymentStillSame'] is True and F['successfulCanonicalStatusStillSame'] is True
 for evidence in [H,F]:assert evidence['runId']==I['runId']==35024424739 and evidence['deploymentId']==I['deploymentId']==6468597117
 assert receipt['status']=='PASS' and receipt['expectedInventorySha256']==I['inventoryPin']['sha256'] and receipt['noHistoricalBuilds'] is True
 rows={r['path']:r for r in inventory['files']};assert len(rows)==len(inventory['files'])==663 and sum(r['bytes'] for r in rows.values())==312654390
 for r in I['criticalRows']:assert {k:r[k] for k in ['path','bytes','sha256']}==rows[r['path']] and r['url']==inventory['base']+r['path']
 assert len(I['criticalRows'])==5 and any(r['path'].endswith('/game/build-info.json') for r in I['criticalRows'])
 fresh=value(A['freshAuthorityReviewPin']);assert fresh['status']=='PASS' and fresh['archiveCommit']==I['archiveCommit'] and fresh['runId']==I['runId'] and fresh['deploymentId']==I['deploymentId'] and fresh['successfulCanonicalStatusStillSame'] is True
 raw(A['priorBrowserClosurePin']);assert A['priorBrowserClosed'] is True
 assert A['controllerManifestPin']['path']==str(P/'controller-preparation-manifest.json');m=value(A['controllerManifestPin']);assert m['count']==len(m['files']) and len({r['path'] for r in m['files']})==m['count']
 for r in m['files']:
  q=Path(r['path']);assert not q.is_absolute() and all(v not in ['.','..',''] for v in q.parts)
  raw({**r,'path':str(P/q)})
 return I
if __name__=='__main__':print(json.dumps(verify()))
