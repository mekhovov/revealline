# Archive17 native attempt 1 — stopped and retained

Canonical v0.57.3 loaded with five exact frozen body pins. Native Base game / First Signal play completed a real one-cut victory: 52.2%, 8,160 points, three lives and 3.625 seconds. The earned still receipt and its original art hash are in action016. No application state was injected.

The next click targeted `#skip-celebration` after that transient had naturally hidden. Action018 records hidden=true, a 0×0 rectangle and no dispatched click. Screenshot03 already shows the stable Results button. This was my stale-control observation error; it does not establish a product failure. The unchanged guard stopped the controller and closed Chrome. No restart occurred.

All three PNGs are exactly 390×844. Screenshot01 paints the ready title, despite its loading filename; only the earlier action003 records boot loading. Screenshot02 is ready mission setup. Screenshot03 is the authentic victory picture with Results, not a paused state.

The Results/Retry, saved pause, Resume, Explorer/Back and paused Continue steps remain unexecuted, so historical native admission is pending. Known immutable v0.57.3 recovery behavior and online-only scope remain explicit; no offline or full P01 acceptance is claimed.

Browser 52134 and driver 52994 are absent; port 51898 is closed. Launcher session 93456 exited 0 and controller session 61812 exited 1. The original profile, 18 action receipts, events, 3 PNGs, actual authorization and failed action are retained. The final manifest excludes profile payloads and preserves the separate original helper manifest.
