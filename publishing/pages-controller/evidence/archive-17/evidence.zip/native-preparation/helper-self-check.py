"""Small local-only fixtures: profile traversal, fail-closed GO, bounded URL metadata."""
from pathlib import Path
import importlib.util,json,os,subprocess,tempfile
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('capacity',P/'public_capacity.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[]
with tempfile.TemporaryDirectory(prefix='archive17-helper-fixture-') as t:
 root=Path(t)/'run';(root/'profile').mkdir(parents=True);external=Path(t)/'outside';external.mkdir();(external/'not-followed').write_bytes(b'x'*8192)
 (root/'profile/ordinary').write_bytes(b'ok');(root/'profile/SingletonSocket').symlink_to(external,target_is_directory=True)
 got=m.measure(root);assert got['profileLogicalBytes']==2+len(str(external)) and len(got['profileLinks'])==1;rows.append('Owned profile link metadata counted; external target not followed')
 (root/'unowned-link').symlink_to(external)
 try:m.measure(root)
 except AssertionError:rows.append('Evidence link refused')
 else:raise AssertionError('Evidence symlink accepted')
 (root/'unowned-link').unlink();(root/'profile/SingletonSocket').unlink();(root/'profile/ordinary').unlink();(root/'profile').rmdir();(root/'profile').symlink_to(external,target_is_directory=True)
 try:m.measure(root)
 except AssertionError:rows.append('Profile root link refused')
 else:raise AssertionError('Profile root symlink accepted')
r=subprocess.run(['python3',str(P/'public_binding.py')],capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});assert r.returncode!=0 and 'Actual root GO absent' in r.stderr;rows.append('Unapproved root authorization refused before browser/network')
s=(P/'public-driver.mjs').read_text();fn=s[s.index('const cleanURL='):s.index('\nconst digest=')]
js="import crypto from 'node:crypto';const hash=b=>crypto.createHash('sha256').update(b).digest('hex');"+fn+"const raw='data:image/png;base64,'+'A'.repeat(5*1024*1024),a=cleanURL(raw);if(a.protocol!=='data:'||a.bytes!==Buffer.byteLength(raw)||a.sha256!==hash(raw)||JSON.stringify(a).length>200)throw Error('URL bound');if(cleanURL('https://example.test/a?q=secret')!=='https://example.test/a')throw Error('HTTP normalization');console.log(JSON.stringify({status:'PASS',nonHttpInputBytes:a.bytes,metadataBytes:Buffer.byteLength(JSON.stringify(a)),queryOmitted:true}));"
r=subprocess.run([json.loads((P/'public-launch-config.json').read_text())['websocketNode'],'--input-type=module','-e',js],capture_output=True,text=True);assert r.returncode==0,r.stderr;rows.append('Five MiB non-HTTP URL retains bytes/hash only; HTTP query omitted')
result={'status':'PASS','cases':rows,'urlFixture':json.loads(r.stdout),'authRefusal':{'exitCode':1,'expectedReason':'Actual root GO absent'},'browserLaunched':False,'networkRequests':0,'scope':'Local helper checks, not native/product qualification'}
with (P/'helper-self-check.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
