"""Emergency closure of this launch's exact Chrome PID only; no browser discovery/fallback."""
from pathlib import Path
import json,os,socket,subprocess,time
P=Path(__file__).resolve().parent;D=P/'run/01-online';L=json.loads((D/'launch.json').read_text());C=json.loads((P/'public-launch-config.json').read_text())
assert L['profile']==C['profile']==str(P/'run/profile')
def alive(pid):
 try:os.kill(pid,0);return True
 except ProcessLookupError:return False
def port_closed():
 with socket.socket() as s:s.settimeout(.3);return s.connect_ex(('127.0.0.1',L['port']))!=0
signal=None
if alive(L['pid']):
 argv=subprocess.check_output(['ps','-p',str(L['pid']),'-o','command='],text=True)
 assert '/Google Chrome' in argv and '--user-data-dir='+L['profile'] in argv,'PID ownership differs; refuse'
 os.kill(L['pid'],15);signal='SIGTERM'
 for _ in range(100):
  if not alive(L['pid']) and port_closed():break
  time.sleep(.1)
result={'pid':L['pid'],'profile':L['profile'],'signal':signal,'pidExited':not alive(L['pid']),'endpointClosed':port_closed(),'launcherReapReceiptStillRequired':True}
with (D/'manual-owned-closure.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
assert result['pidExited'] and result['endpointClosed'],result
print(json.dumps(result))
