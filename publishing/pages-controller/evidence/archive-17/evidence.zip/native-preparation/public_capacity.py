"""No-follow owned-profile accounting. Other symlinks and special files are refused."""
from pathlib import Path
import argparse,datetime,json,os,shutil,stat,time
P=Path(__file__).resolve().parent;C=json.loads((P/'public-launch-config.json').read_text());L=C['limits'];R=P/'run'
def measure(root):
 profile=evidence=allocated=0;links=[];profile_root=root/'profile'
 if root.exists():assert root.is_dir() and not root.is_symlink(),'Ordinary owned run root required'
 if profile_root.exists() or profile_root.is_symlink():assert profile_root.is_dir() and not profile_root.is_symlink(),'Ordinary owned profile root required'
 for base,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   p=Path(base)/name
   try:s=p.lstat()
   except FileNotFoundError:continue
   inside=profile_root in p.parents
   if stat.S_ISLNK(s.st_mode):
    assert inside,'Symlink outside exact owned profile: '+str(p)
    links.append({'path':str(p.relative_to(root)),'target':os.readlink(p),'logicalBytes':s.st_size,'allocatedBytes':s.st_blocks*512});profile+=s.st_size;allocated+=s.st_blocks*512;continue
   if stat.S_ISDIR(s.st_mode):continue
   assert stat.S_ISREG(s.st_mode),'Special file refused: '+str(p)
   allocated+=s.st_blocks*512
   if inside:profile+=s.st_size
   else:evidence+=s.st_size
 return {'profileLogicalBytes':profile,'evidenceLogicalBytes':evidence,'actualAllocatedBytes':allocated,'profileLinks':links}
def check(stage,identity=None,phase=None):
 from public_binding import verify
 if identity is None:identity=verify()
 a=measure(R);profile=a['profileLogicalBytes'];evidence=a['evidenceLogicalBytes'];peer=C['peerAllowanceBytes'];assert peer==33554432 and L['minimumProjectedFreeBytes']==536870912
 remaining=max(0,L['maximumProfileBytes']-profile)+max(0,L['evidenceBytes']-evidence);free=shutil.disk_usage(P).free;projected=free-peer-remaining
 rec={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':stage,'phase':phase,'freeBytes':free,'remainingOwnAllowanceBytes':remaining,'peerAllowanceBytes':peer,'projectedFreeBytes':projected,'requiredProjectedFreeBytes':L['minimumProjectedFreeBytes'],**a,'capacitySufficient':projected>=L['minimumProjectedFreeBytes'],'browserExecutionAuthorizedByCapacity':False}
 out=R/phase/'capacity.jsonl' if phase else P/'public-capacity-observations.jsonl'
 with out.open('a') as f:f.write(json.dumps(rec)+'\n')
 assert rec['capacitySufficient'] and profile<=L['maximumProfileBytes'] and evidence<=L['evidenceBytes'] and a['actualAllocatedBytes']<=L['maximumNewDiskBytes'],json.dumps(rec)
 launch=R/'01-online/launch.json'
 if launch.exists() and stage not in ['after-exit','final']:assert time.time()-json.loads(launch.read_text())['startedAt']<=L['browserSecondsPerProcess'],'Owned browser deadline'
 return rec
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--stage',default='preparation');a.add_argument('--actual-binding',action='store_true');x=a.parse_args();print(json.dumps(check(x.stage)))
