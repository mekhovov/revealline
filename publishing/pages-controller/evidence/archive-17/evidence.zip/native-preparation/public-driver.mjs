import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import readline from 'node:readline';
import {R,P,D,phase,config,identity,launch,controllerManifest,browserArguments,call,attachInitial,verifyTarget,evaluate,foreground,events,close,allowedUrl,productUrl,capacity,verifyControllerPins,ws} from './public-cdp.mjs';
const eventFile=fs.openSync(path.join(D,'events.jsonl'),'wx');let eventBytes=0,done=false,eventFailure=null;
const eventLimit=3*1024*1024,hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function log(value){if(done)return;const text=JSON.stringify({at:new Date().toISOString(),...value})+'\n';if(eventBytes+Buffer.byteLength(text)>eventLimit){eventFailure='Three MiB per-phase event budget reached';return;}eventBytes+=Buffer.byteLength(text);fs.writeSync(eventFile,text);}
const cleanURL=value=>{const raw=String(value||'');try{const u=new URL(raw);return ['http:','https:'].includes(u.protocol)&&u.origin.length+u.pathname.length<=2048?u.origin+u.pathname:{protocol:u.protocol,bytes:Buffer.byteLength(raw),sha256:hash(raw)};}catch{return{protocol:'invalid',bytes:Buffer.byteLength(raw),sha256:hash(raw)};}};
const digest=value=>typeof value==='string'?{bytes:Buffer.byteLength(value),sha256:hash(value)}:null;
events.push(m=>{
 if(m.sessionId&&m.sessionId!==sid)return;
 const p=m.params||{};
 if(m.method==='Runtime.consoleAPICalled'){for(const a of p.args||[])if(typeof a.value==='string'&&a.value.startsWith('P01_HISTORY '))log({method:'DOM.event',measurement:JSON.parse(a.value.slice(12))});}
 else if(m.method?.startsWith('DOMStorage.domStorage'))log({method:m.method,storageId:p.storageId,key:p.key??null,oldValue:digest(p.oldValue),newValue:digest(p.newValue)});
 else if(m.method==='Network.responseReceived')log({method:m.method,requestId:p.requestId,type:p.type,url:cleanURL(p.response.url),status:p.response.status,fromServiceWorker:!!p.response.fromServiceWorker,fromDiskCache:!!p.response.fromDiskCache,fromPrefetchCache:!!p.response.fromPrefetchCache,protocol:p.response.protocol});
 else if(m.method==='Network.requestWillBeSent')log({method:m.method,requestId:p.requestId,type:p.type,httpMethod:p.request.method,url:cleanURL(p.request.url)});
 else if(m.method==='Page.frameNavigated')log({method:m.method,frameId:p.frame.id,parentId:p.frame.parentId??null,url:cleanURL(p.frame.url)});
 else if(m.method==='Network.loadingFailed')log({method:m.method,requestId:p.requestId,errorText:p.errorText,canceled:p.canceled,blockedReason:p.blockedReason??null});
 else if(['Page.backForwardCacheNotUsed','Runtime.exceptionThrown','Inspector.detached','Target.detachedFromTarget'].includes(m.method))log(JSON.parse(JSON.stringify(m,(key,value)=>typeof value==='string'&&(/^(?:data|blob):/.test(value)||value.length>2048)?{bytes:Buffer.byteLength(value),sha256:hash(value)}:value)));
});
let sid,target,heartbeat;
function finish(){if(done)return;clearInterval(heartbeat);log({closed:true,eventFailure});done=true;fs.closeSync(eventFile);close();}
ws.addEventListener('close',e=>{log({socketClosed:true,code:e.code,reasonBytes:Buffer.byteLength(String(e.reason||'')),reasonSha256:hash(String(e.reason||'')),clean:e.wasClean});});
process.on('SIGINT',()=>{finish();process.exit(0);});process.on('SIGTERM',()=>{finish();process.exit(0);});
const lines=readline.createInterface({input:process.stdin});
let number=0,gameNavigated=false,explorerBackIssued=false;
const receiptCount=()=>config.phases.reduce((n,s)=>n+(fs.existsSync(path.join(R,s))?fs.readdirSync(path.join(R,s)).filter(x=>/^action-\d+\.json$/.test(x)).length:0),0);
const screenshotCount=()=>config.phases.reduce((n,s)=>n+(fs.existsSync(path.join(R,s))?fs.readdirSync(path.join(R,s)).filter(x=>x.endsWith('.png')).length:0),0);
function elementExpression(selector){return`(()=>{const nodes=document.querySelectorAll(${JSON.stringify(selector)});if(nodes.length!==1)return{matches:nodes.length};const e=nodes[0],r=e.getBoundingClientRect(),x=Math.max(1,Math.min(innerWidth-1,r.x+r.width/2)),y=Math.max(1,Math.min(innerHeight-1,r.y+r.height/2)),hit=document.elementFromPoint(x,y),ancestors=[];let blocked=false;for(let n=e;n;n=n.parentElement){const s=getComputedStyle(n);if(n.hidden||n.inert||s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse')blocked=true;ancestors.push({tag:n.tagName,id:n.id,hidden:n.hidden,inert:n.inert,display:s.display,visibility:s.visibility,open:n.tagName==='DIALOG'?n.open:undefined});}return{matches:1,id:e.id,tag:e.tagName,type:e.type,href:e.href||null,text:e.innerText,disabled:!!e.disabled,rect:r.toJSON(),x,y,hit:!!hit&&(hit===e||e.contains(hit)),hitId:hit?.id,visible:!blocked&&r.width>0&&r.height>0&&r.left>=0&&r.right<=innerWidth&&r.top>=0&&r.bottom<=innerHeight,partiallyVisible:!blocked&&r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight,ancestors};})()`;}
const summaries={
 summary:`(()=>({url:location.href,timeOrigin:performance.timeOrigin,navigation:performance.getEntriesByType('navigation').map(n=>({type:n.type,activationStart:n.activationStart})),body:document.body.innerText.slice(0,32000),bodyTruncated:document.body.innerText.length>32000,active:document.activeElement?.id,bootState:document.documentElement.dataset.bootState,flightState:document.body.dataset.flightState,pictureState:document.body.dataset.pictureState,dialogs:[...document.querySelectorAll('dialog[open]')].map(e=>e.id),buttons:[...document.querySelectorAll('button,a,select')].filter(e=>{const r=e.getBoundingClientRect();return r.width&&r.height&&r.bottom>0&&r.top<innerHeight;}).slice(0,100).map(e=>({id:e.id,tag:e.tagName,text:e.innerText?.slice(0,240),disabled:e.disabled,href:e.href,value:e.value}))}))()`,
 selection:`(()=>({url:location.href,selects:['pack-select','level-select','theme-select','campaign-select'].map(id=>{const e=document.getElementById(id);return e?{id,value:e.value,disabled:e.disabled,options:[...e.options].map(o=>({value:o.value,label:o.textContent,disabled:o.disabled||o.parentElement?.disabled===true,selected:o.selected}))}:{id,missing:true};}),missionButtons:[...document.querySelectorAll('#missions button,#mission-picker-cards button,#mission-picker-older-cards button')].map(e=>({id:e.id,text:e.textContent,disabled:e.disabled,selected:e.classList.contains('selected'),data:{...e.dataset}}))}))()`,

};
async function readOnly(name){
 const files={history:'read-storage-owners.js',controls:'observe-controls.js',solo:'observe-solo.js'};
 if(files[name]){if(await evaluate('location.href',sid)!==identity.url)throw Error('Game observer requires canonical archive game');return evaluate(fs.readFileSync(path.join(P,files[name]),'utf8'),sid);}
 if(summaries[name])return evaluate(summaries[name],sid);
 if(name==='identity'){
  return evaluate(`(async()=>{const expected=${JSON.stringify(identity)};if(location.href!==expected.url)throw Error('Canonical archive game required');const records=[];for(const row of expected.criticalRows){const r=await fetch(row.url,{cache:'no-store'});if(!r.ok||r.url!==row.url)throw Error('Canonical body failed/redirected');const b=new Uint8Array(await r.arrayBuffer()),sha256=[...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(v=>v.toString(16).padStart(2,'0')).join('');if(b.byteLength!==row.bytes||sha256!==row.sha256)throw Error('Actual frozen body differs');records.push({url:row.url,bytes:b.byteLength,sha256});if(row.path.endsWith('/game/build-info.json')){const value=JSON.parse(new TextDecoder().decode(b));if(value.version!==expected.version||value.sourceRevision!==expected.sourceRevision)throw Error('Actual frozen build identity differs');}}return{url:location.href,timeOrigin:performance.timeOrigin,channel:'release-'+expected.version,records,scope:'Historical online only; no offline admission'};})()`,sid);
 }
 throw Error('Only fixed read-only observation names are allowed');
}
try{
 ({sessionId:sid,target}=await attachInitial());
 await call('Page.enable',{},sid);await call('Runtime.enable',{},sid);await call('DOMStorage.enable',{},sid);await call('Network.enable',{},sid);
 await call('Page.addScriptToEvaluateOnNewDocument',{source:fs.readFileSync(path.join(P,'observe-history-events.js'),'utf8')},sid);
 await call('Emulation.setDeviceMetricsOverride',{...config.initialViewport,deviceScaleFactor:1,mobile:false},sid);
 await call('Browser.setDownloadBehavior',{behavior:'deny',eventsEnabled:true});
 log({ready:true,phase,controllerPid:process.pid,targetId:target.targetId,browserPid:launch.pid,profile:launch.profile,browserArguments,controllerManifest});
 console.log(JSON.stringify({ready:true,phase,pid:process.pid,targetId:target.targetId,browserPid:launch.pid}));
 heartbeat=setInterval(()=>{log({heartbeat:true,socketState:ws.readyState});call('Browser.getVersion').catch(e=>{eventFailure=String(e);});},5000);
 for await(const line of lines){
  let receipt={at:new Date().toISOString(),phase,pid:launch.pid,profile:launch.profile,targetId:target.targetId};
  try{
   if(line.length>4096)throw Error('Command byte bound');const command=JSON.parse(line),{action,arg,hold=0}=command;receipt.command=command;
   if(eventFailure)throw Error(eventFailure);if(['click','inspect','wheel'].includes(action)&&/^(?:#picture-|#offline-|#export-|#import-)/.test(arg||''))throw Error('Action outside finite historical scope');if(receiptCount()>=config.limits.maximumActions)throw Error('Whole-run action bound');
   receipt.capacity=capacity('before-native-'+action);receipt.target=await verifyTarget(target.targetId);await call('Page.bringToFront',{},sid);receipt.before=await foreground(sid);
   let navigating=false;
   if(action==='close'){
    try{await call('Browser.close');receipt.result={closeAcknowledged:true,actualPidExit:'Required separately in launcher exit.json'};}
    catch(error){if(ws.readyState!==WebSocket.CLOSED)throw error;receipt.result={closeAcknowledged:false,socketClosed:true,actualPidExit:'Required separately in launcher exit.json'};}
   }else if(action==='navigate'){
    if(arg!=='game'||gameNavigated)throw Error('Only one initial canonical game navigation per phase');gameNavigated=true;receipt.result=await call('Page.navigate',{url:identity.url},sid);navigating=true;
   }else if(action==='read')receipt.result=await readOnly(arg);
   else if(action==='inspect'){if(typeof arg!=='string'||arg.length>300)throw Error('Selector bound');receipt.result=await evaluate(elementExpression(arg),sid);}
   else if(action==='shot'){
    if(!/^[a-z0-9-]{1,70}$/.test(arg)||screenshotCount()>=config.limits.maxScreenshots)throw Error('Screenshot bound');const image=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false},sid),bytes=Buffer.from(image.data,'base64');if(bytes.readUInt32BE(16)!==receipt.before.width||bytes.readUInt32BE(20)!==receipt.before.height)throw Error('PNG differs from actual same-target viewport');const file=path.join(D,arg+'.png');fs.writeFileSync(file,bytes,{flag:'wx'});receipt.result={file,bytes:bytes.length,sha256:hash(bytes)};
   }else if(action==='click'||action==='wheel'){
    if(!productUrl(receipt.before.url)||typeof arg!=='string'||arg.length>300)throw Error('Native product selector required');const e=await evaluate(elementExpression(arg),sid);receipt.element=e;
    if(e.matches!==1||e.disabled||!e.hit||(action==='click'?!e.visible:!e.partiallyVisible))throw Error('Actual visible enabled top-layer target refused');
    if(action==='wheel'){const deltaY=Number(command.deltaY);if(!Number.isFinite(deltaY)||Math.abs(deltaY)>800)throw Error('Wheel bound');await call('Input.dispatchMouseEvent',{type:'mouseWheel',x:e.x,y:e.y,deltaX:0,deltaY},sid);}
    else{if(e.tag==='A'&&e.href&&!productUrl(e.href))throw Error('Link leaves exact public routes');navigating=e.tag==='A'&&productUrl(e.href)||e.id==='picture-reload';for(const type of ['mouseMoved','mousePressed','mouseReleased'])await call('Input.dispatchMouseEvent',{type,x:e.x,y:e.y,...(type==='mouseMoved'?{}:{button:'left',clickCount:1})},sid);}
   }else if(action==='key'){
    if(!productUrl(receipt.before.url))throw Error('Keys only belong to product pages');const keys={b:66,Escape:27,Tab:9,Enter:13,Space:32,ArrowDown:40,ArrowUp:38,ArrowLeft:37,ArrowRight:39,PageDown:34,PageUp:33,Home:36,End:35},name=arg==='Shift+Tab'?'Tab':arg;if(!keys[name]||!Number.isFinite(hold)||hold<0||hold>350)throw Error('Native key/hold bound');if(name==='Enter'||name==='Space'){const active=await evaluate('({id:document.activeElement?.id,tag:document.activeElement?.tagName,href:document.activeElement?.href})',sid);receipt.keyTarget=active;if(active.tag==='A'&&active.href&&!productUrl(active.href))throw Error('Focused link leaves exact public routes');navigating=name==='Enter'&&active.tag==='A'&&productUrl(active.href)||active.id==='picture-reload';}const key={key:name==='Space'?' ':name,code:name==='b'?'KeyB':name,windowsVirtualKeyCode:keys[name],modifiers:arg==='Shift+Tab'?8:0,...(name==='b'?{text:'b',unmodifiedText:'b'}:{})};await call('Input.dispatchKeyEvent',{type:'keyDown',...key},sid);if(hold)await new Promise(r=>setTimeout(r,hold));await call('Input.dispatchKeyEvent',{type:'keyUp',...key},sid);
   }else if(action==='back'){
    if(explorerBackIssued||receipt.before.url!==config.explorer)throw Error('Back must originate from actual Release Explorer');const history=await call('Page.getNavigationHistory',{},sid),entry=history.entries[history.currentIndex-1];receipt.history=history;if(!entry||entry.url!==identity.url)throw Error('Immediate history predecessor is not the canonical game');await call('Page.navigateToHistoryEntry',{entryId:entry.id},sid);explorerBackIssued=true;navigating=true;
   }else throw Error('Unknown bounded action');
   receipt.after=action==='close'?null:navigating?{navigationIssued:true,requiresNextForegroundObservation:true}:await foreground(sid);receipt.ok=true;
  }catch(error){receipt.ok=false;receipt.error=String(error.stack);}
  const file=path.join(D,`action-${String(++number).padStart(3,'0')}.json`),body=JSON.stringify(receipt,null,2)+'\n';if(Buffer.byteLength(body)>3*1024*1024)throw Error('Action receipt bound');fs.writeFileSync(file,body,{flag:'wx'});console.log(JSON.stringify({receipt:file,ok:receipt.ok,...(receipt.result?{result:receipt.result}:{}),...(receipt.error?{error:receipt.error}:{})}));
  if(!receipt.ok||receipt.command?.action==='close'){if(!receipt.ok)process.exitCode=1;break;}
 }
 verifyControllerPins();
}catch(error){log({fatal:String(error.stack)});process.exitCode=1;console.error(String(error.stack));}
finally{lines.close();if(ws.readyState===1){try{await call('Browser.close');log({ownedCloseRequested:true,reason:'finite-driver-end',pid:launch.pid});}catch(e){log({ownedCloseRequestFailed:String(e.message).slice(0,240),pid:launch.pid});}}finish();}
