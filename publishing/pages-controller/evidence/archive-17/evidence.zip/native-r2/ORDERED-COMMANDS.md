# Archive17 manual attempt 2 — prepared, no browser GO

This second manual attempt preserves all prior failed originals. The helpers are byte-identical to attempt 1; only this guide and required config/profile paths change. The helper set narrows the earlier PLAN to **390 × 844 throughout**, one online process, at most 50 recorded actions, six PNGs, 15 minutes, an 80 MiB profile, 8 MiB evidence, no downloads, a 32 MiB peer allowance and a **512 MiB projected free reserve**. Existing raw plans remain unchanged as provenance. There is no offline, authoring, recovery-reproduction, new win requirement, device matrix or successor-release acceptance.

Work directory for every command:
`/Users/oleksandr.mekhovov/work/my_projects/go_test_p01_file_cancel/.cache/cross-mode/p01/v0573-final-recovery/archive17-v0573-preparation/native-r2`

## Before execution

Parent must review the helpers, source diffs and preparation manifest, confirm P00's browser is closed, and write actual `root-authorization.json` with status `AUTHORIZED_ARCHIVE17_NATIVE_ONLINE`, `rootGo: true`, UTC `notBefore`/`expiresAt`, and exact `identityPin`, `controllerManifestPin`, `priorBrowserClosurePin`, `priorBrowserClosed: true`, and `freshAuthorityReviewPin`. Fresh review must have `status: PASS`, archive commit `f7d7ecd711cb895801412a4bcf7796e63d25887c`, run `35024424739`, deployment `6468597117`, and `successfulCanonicalStatusStillSame: true`, grounded in actual originals. Prepared/null records are refused. Preserve the original pre-GO authorization under provenance.

1. Run `PYTHONDONTWRITEBYTECODE=1 python3 public_binding.py` and `PYTHONDONTWRITEBYTECODE=1 python3 public_capacity.py --actual-binding --stage before-launch`. These read local pins and capacity; neither launches a browser. Do not proceed on refusal.
2. Launch `PYTHONDONTWRITEBYTECODE=1 python3 launch-public-chrome.py --go --phase 01-online` using `exec_command`, retaining its session. It launches one fresh owned Chrome with an empty profile, checks capacity and authorization every three seconds, and terminates/reaps only its process on failure. No source server or offline proxy exists.
3. Once `run/01-online/launch.json` is present, launch the controller below with **`exec_command tty:true`**, retaining its interactive session. Stdin must remain connected; `/dev/null` is refused.

```
/Users/oleksandr.mekhovov/.local/share/mise/installs/node/22.22.2/bin/node public-driver.mjs --phase 01-online
```

4. Send one JSON command per line through only that returned interactive session. Keep every action receipt, event, screenshot, failure and source original. Do not reconnect or modify a live helper.

## Finite native actions

The following are exact supported commands, with ordinary choices based on the observed UI. Wait only for actual readiness; at most three summary reads per pending boundary, within 30 seconds. No arbitrary expression, setter, forged event, hidden click or automatic retry exists.

```
{"action":"navigate","arg":"game"}
{"action":"read","arg":"identity"}
{"action":"read","arg":"summary"}
{"action":"shot","arg":"01-archive-title-portrait"}
{"action":"click","arg":"#shell-play"}
{"action":"click","arg":"#shell-prepare"}
{"action":"click","arg":"#pack-select"}
{"action":"key","arg":"b"}
{"action":"key","arg":"Tab"}
{"action":"read","arg":"selection"}
{"action":"read","arg":"solo"}
```

Use the ordinary Missions entry and native printable type-ahead to choose **Base game**, the same shipped First Signal route used in Archive16. Confirm actual selected value/title before Deploy. If Base game/First Signal is already selected, omit needless changes. The driver supports native wheel movement of a visible dialog (`wheel` with `deltaY` of at most 800), or native Tab/PageDown, only if a needed control is below the current viewport; every click must pass actual enabled/visible/top-layer hit tests. Do not use a hidden selector or simulate selection values. Retain any unavailable prerequisite honestly and stop.

When actual selected picture is ready, continue immediately with visible Deploy and one ordinary ArrowDown press, as in Archive16. Observe the actual outcome, then pause. No fabricated capture or guaranteed victory is inferred from the input.

```
{"action":"shot","arg":"02-ready-mission-portrait"}
{"action":"click","arg":"#shell-deploy"}
{"action":"key","arg":"ArrowDown","hold":250}
{"action":"read","arg":"summary"}
{"action":"key","arg":"Escape"}
{"action":"read","arg":"solo"}
{"action":"shot","arg":"03-capture-or-pause-portrait"}
```

After the capture, read the actual summary again before choosing a control. **Never target `#skip-celebration` in this attempt.** Its transient disappearance caused the retained attempt 1 tooling refusal. Wait for stable results using at most three read observations within 30 seconds. If visible **Results** is present, inspect `#show-result`, then click it and read the summary again. If visible **Try again** is already present, skip Results. Inspect and activate the actual visible `#retry-button` once, then Escape immediately to make a genuine paused saved retry. If a run is paused without a win, inspect and activate actual visible Resume (`#start-button`) once, then Escape. Every control is selected from current observations; a stale/hidden target still refuses and stops. Record actual capture/score/lives/ticks and the paused checkpoint. Do not leave gameplay running while analyzing screenshots. This is one explicitly authorized future manual attempt; no automatic restart or expanded game matrix.

```
{"action":"read","arg":"history"}
{"action":"click","arg":"#overlay-menu"}
{"action":"read","arg":"summary"}
{"action":"click","arg":"#shell-release-explorer"}
{"action":"read","arg":"summary"}
{"action":"back"}
{"action":"read","arg":"summary"}
{"action":"read","arg":"solo"}
{"action":"read","arg":"history"}
```

The visible archive Explorer link goes through the exact archive `/releases/` bridge to the canonical main Explorer. Both routes are allowed, with the real main Explorer required before Back. Back is allowed once, only when its immediate real history predecessor is the canonical archive game. Do not assume persistence: classify actual pagehide/pageshow trusted events, `persisted`, time origin, and current navigation. On the returned title/menu, activate visible `#shell-continue` if present; if the pause overlay is already current, record that state without inventing a Continue click. Read `solo` and `history` again after actual Continue settles, confirming paused state and the saved checkpoint/run/picture identity. Keep legitimate `savedAt` deltas distinct from content identity. Capture a final portrait paused/menu frame with the primary controls visible.

```
{"action":"shot","arg":"04-return-paused-portrait"}
{"action":"read","arg":"identity"}
{"action":"close"}
```

## Closure and final review

On any required failure, stop independent interaction and close this owned browser. Driver completion/error requests `Browser.close` on its already verified owned endpoint. If the transport cannot close it, run `PYTHONDONTWRITEBYTECODE=1 python3 close-owned.py`; this verifies the saved exact PID/profile command and signals only that process. Wait for the original launcher session to return and retain `exit.json` or `launch-failure.json`, PID/endpoint closure and controller exit. No restart. Do not delete the profile.

Produce a final manifest of prep/GO originals, all actions/events/transport diagnostics/PNGs, reports and closure, excluding the profile. Parent performs independent visual/evidence review and a new read-only authority recheck. No full-phase acceptance or archive offline admission follows from this finite historical online run. The immutable v0.57.3 Export/Library-close recovery defect remains explicitly retained.
