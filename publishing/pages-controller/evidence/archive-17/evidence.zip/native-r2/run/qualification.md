# Archive17 manual attempt 2

The finite historical online journey passed at 390 × 844: canonical v0.57.3 title, real First Signal capture (52.2%, 8,160 points, three lives), stable Try again, paused saved retry, actual main Explorer, native Back and visible Continue. The trusted pagehide/pageshow pair reported `persisted: true`; the original time origin, replay checkpoint, run ID and picture pins remained identical. Continue left the flight paused with Resume focused.

The first Escape after Retry was too early; actual observations still showed running. A settled Escape then paused it. The idle retry ran for 92.358 seconds; no short-duration claim is made. The only suspended-save field changed across departure was `savedAt`; other localStorage keys and all observed IndexedDB records and blob hashes matched. No no-write or raw-string-equality claim spans departure.

All 41 actions succeeded, four PNGs are exactly 390 × 844, transport closed cleanly, and the owned Chrome/controller and CDP endpoint are closed. The old attempt and its stale transient-control refusal remain intact. Its historical setup footer clipping is not reclassified as a responsive pass.

This is historical online evidence only. It preserves the known immutable v0.57.3 recovery defect; it does not grant offline admission, physical-device qualification or P01 acceptance. Parent review and final authority reconciliation remain separate.
