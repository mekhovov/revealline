from pathlib import Path
import json,hashlib,datetime,os,socket,subprocess,shutil
D=Path(__file__).resolve().parent;B=D.parent;P=B/'native-r2'
def get(p):return json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,value):
 with (D/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
main=get(D/'main.json');commit=get(D/'commit.json');run=get(D/'run.json');deps=get(D/'deployments.json');dep=get(D/'deployment.json');statuses=get(D/'statuses.json');release=get(D/'release.json');old=get(B/'after-http/release.json');tag=get(D/'tag.json');tagobj=get(D/'tag-object.json');I=get(P/'verified-public-identity.json')
assert main['object']['type']=='commit' and main['object']['sha']==commit['sha']==I['archiveCommit']
assert commit['tree']['sha']==I['archiveTree']
assert run['id']==I['runId'] and run['head_sha']==I['archiveCommit'] and run['status']=='completed' and run['conclusion']=='success' and run['event']=='push'
assert deps[0]['id']==dep['id']==I['deploymentId'] and dep['sha']==I['archiveCommit'] and dep['environment']=='github-pages'
assert statuses[0]['state']=='success' and statuses[0]['environment_url']=='https://mekhovov.github.io/revealline-archive-17/' and '/runs/'+str(I['runId'])+'/' in statuses[0]['log_url']
assert release['id']==old['id']==389425275 and release['tag_name']==old['tag_name']=='v0.57.3' and release['draft'] is False and release['prerelease'] is False and release['published_at']==old['published_at']
assert tag['object']['type']=='tag' and tag['object']['sha']==tagobj['sha']=='081f62bdb9a06941acd52ceeab2e3eaa8f480e30' and tagobj['object']['type']=='commit' and tagobj['object']['sha']==I['sourceRevision'] and tagobj['tag']=='v0.57.3'
keys=['id','name','size','digest','state','browser_download_url'];byname=lambda r:{a['name']:{k:a[k] for k in keys} for a in r['assets']};assets=byname(release)
assert len(release['assets'])==len(assets)==9 and assets==byname(old)
for a in release['assets']:
 current=get(D/('asset-'+str(a['id'])+'.json'));assert {k:current[k] for k in keys}==assets[a['name']] and current['state']=='uploaded' and current['digest'].startswith('sha256:')
manifest=P/'controller-preparation-manifest.json';m=get(manifest);assert m['count']==len(m['files'])==27 and len({r['path'] for r in m['files']})==27
for r in m['files']:
 q=P/r['path'];assert not q.is_symlink() and str(q)==str(q.resolve());actual=pin(q);assert actual['bytes']==r['bytes'] and actual['sha256']==r['sha256']
write('helper-rehash.json',{'status':'PASS','manifestPin':pin(manifest),'files':27,'bytes':sum(r['bytes'] for r in m['files']),'allOriginalsRehashed':True,'rootGo':get(P/'root-authorization.json')['rootGo'],'runAbsent':not (P/'run').exists()})
C=Path('/Users/oleksandr.mekhovov/work/my_projects/go_test_cross_mode/.cache/cross-mode/p01/v0574-recovery-return/native-r6/run');cp=C/'closure.json';closed=get(cp);assert pin(cp)['sha256']=='db36e0e32b19787b2a98165caf1ab7eae19c6f068ba67d6af1550b6de975d33e'
assert [x['exitCode'] for x in closed['sessions']]==[0,0,1] and closed['absentPids']==[88015,88126,88264]
pids=[]
for pid in closed['absentPids']:
 try:os.kill(pid,0)
 except ProcessLookupError:pids.append({'pid':pid,'absent':True})
 else:raise AssertionError('Prior owned process still exists '+str(pid))
ports=[]
for port in [52085,52092]:
 with socket.socket() as s:s.settimeout(.5);closed_port=s.connect_ex(('127.0.0.1',port))!=0
 assert closed_port;ports.append({'port':port,'closed':True})
rows=[]
for line in subprocess.check_output(['ps','-axo','pid=,command='],text=True).splitlines():
 if '/Google Chrome' in line and '--user-data-dir=' in line and '--type=' not in line and '/.cache/cross-mode/p01/' in line:rows.append(line.strip())
assert rows==[],rows
write('prior-owned-closure-review.json',{'status':'PASS','originalClosurePin':pin(cp),'originalLaunchPin':pin(C/'launch.json'),'originalBrowserExitPin':pin(C/'exit.json'),'originalServerExitPin':pin(C/'server-exit.json'),'pids':pids,'ports':ports,'otherP01Browsers':rows,'scope':'Exact process/port absence only; no reinterpretation of r6 retained pre-input geometry refusal'})
api=[pin(D/(name+'.json')) for name in get(D/'requests.json')]
write('review.json',{'status':'PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archiveCommit':I['archiveCommit'],'archiveTree':I['archiveTree'],'runId':I['runId'],'deploymentId':I['deploymentId'],'latestDeploymentStillSame':True,'successfulCanonicalStatusStillSame':True,'canonicalBase':'https://mekhovov.github.io/revealline-archive-17/','originalReleaseNineAssetsAndTagUnchanged':True,'releaseId':release['id'],'gameSource':I['sourceRevision'],'tagObject':tagobj['sha'],'assets':list(assets.values()),'originals':api,'priorAfterHttpReleasePin':pin(B/'after-http/release.json'),'helperRehashPin':pin(D/'helper-rehash.json'),'priorBrowserClosureReviewPin':pin(D/'prior-owned-closure-review.json'),'freeBytes':shutil.disk_usage(P).free,'browserLaunched':False,'rootGo':False,'historicalScope':'Online only; known immutable v0.57.3 recovery defect retained; no full P01 acceptance'})
files=[{**pin(q),'path':q.relative_to(D).as_posix()} for q in sorted(D.iterdir()) if q.is_file()]
write('manifest.json',{'count':len(files),'bytes':sum(x['bytes'] for x in files),'files':files})
print(json.dumps({'review':pin(D/'review.json'),'closure':pin(D/'prior-owned-closure-review.json'),'helperRehash':pin(D/'helper-rehash.json'),'manifest':pin(D/'manifest.json')}))
