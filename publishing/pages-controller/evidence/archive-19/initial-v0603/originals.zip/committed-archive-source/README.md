# RevealLine archive 19

Retain the exact original v0.60.3 release while newer editions become current. This repository contains small original metadata and bounded publication tools. Hosted preparation fetches the original published ZIP, verifies every member against its original manifest, and deletes the temporary ZIP; it never rebuilds a historical game or commits expanded payload files.

The expected complete site is **690 files / 313,096,970 bytes**, within the unchanged **800,000,000-byte** cap. The root links directly to v0.60.3; its Release explorer route uses the exact corrected immediate redirect plus visible fallback to the main live catalog. Metadata, source qualification, annotated tag and frozen source stay unchanged. See `source-lock.json` and `input-authority.json` for exact pins. An authored inventory is an expectation, not proof of deployment.

## Review and publication

Seed main with a README only, no workflow. Put this reviewed candidate on `codex/retain-v0603` and merge its normal PR after tiny tests and hunk review. Configure Actions Pages and a main-only `github-pages` environment before merging. Both workflow jobs are main-only. Exactly one main push starts deployment; manual dispatch is available only for a necessary recorded retry, never a duplicate running deployment. There is no PR Pages upload or deployment, and this inherited workflow does not advertise PR CI.

The workflow checks out the clean pinned source commit only for the unchanged bounded ZIP extractor and its tests. It verifies the original annotated tag/source, metadata, qualification, corruption guards, all extracted bytes and the final complete inventory. Preserve read-only contents permission and deploy-only Pages/id-token permissions, the 3 GiB disk check, the 800 MB/20,000-file budgets and original failure receipts.

Run the complete small local fixture cohort with `python3 -m unittest discover -s tools -p 'test_*.py' -v`. In the pinned source checkout run `python3 -m unittest discover -s publishing/pages-controller -p 'test_extract_current.py' -v`. Those are synthetic local checks, not a payload build or public acceptance. All fixture inputs are temporary and offline.

After successful hosted deployment, collect the exact merge/tree/run/deployment/receipt identities, audit every expected public file, and separately exercise the retained game and Release explorer through real UI. Only then may the main publisher admit this archive. Do not infer disconnected offline behavior, physical-device support, profile migration across origins, or complete P03/P05 acceptance. Production/Viewport authoring hosts remain source-workspace-only; this archive adds no public tool buttons.

Future appends must preserve every existing canonical row and fit the same cap. Never overwrite the original release assets, repurpose existing URLs, raise the cap, or reuse stale admission evidence.
