# Archive 19 bounded public audit — root review pending

The committed archive source is `9b9f164f1e84729a8c2f2d3a450fcf87b10fe590`, merged as `397a6069022ce1333ca332b07df86e05b239a2fd` with exact tree `3766ae0adcea272d904ef8e96fbad012b1e00b8f`. The authored complete inventory is **690 files / 313,096,970 bytes**, SHA-256 `04eb465832be8b5ed769a11953e766a84c3a408eec6c85486d56cf4537e84719`.

Run `35233941351`, attempt 1, completed successfully. The deployment/receipt metadata is retained separately in `../p03-recovery-v0604-retention-route/hosted-observer/terminal/`. The 36,791-byte original receipt ZIP has not yet been downloaded by this adapter. No public body requests or audit execution have occurred.

## Exact reuse and changes

`predecessor/` preserves the existing Archive03 helper bodies. `adaptation.diff` changes fixed repository/site/source/tree/inventory/lock pins, count/bytes, source checkout and authority roots, and the one-version receipt member list. This is an initial archive, so it has **zero predecessor rows**, no invented prior inventory and no preservation claim for old Archive03 rows. It retains full exact validation of every newly frozen canonical row.

The transport implementation, MIME map and bounds are unchanged: 64 KiB chunks, a one-byte oversize check, no redirects, 25-second socket timeout, 90-second attempt deadline, 1,800-second total deadline, at most three recorded attempts per file and four to eight workers (use six). Every failed attempt remains in output. No release payload is persisted.

The seven original roles remain mandatory: main, commit, run, deployment, statuses, artifacts and receiptZIP. All need original body size/hash pins. The exact held source checkout and tree are checked again. Receipt ZIP accepts only `receipt.json`, `expected-inventory.json` and `zip-receipt-v0.60.3.json`; at most 1 MiB uncompressed and 512 KiB per member. The actual inventory, source/tag/ZIP receipts and complete artifact result must agree.

Two static-preparation mistakes were corrected before execution: the archive-ID substitution changed the held checkout path before its full replacement, and a final report field retained the old preserved-row count. Their initial bodies and correction record remain in `initial-adaptation/`. The final static review confirms the real checkout path, zero predecessor reporting, unchanged transport functions and equal MIME/limit constants. All six scripts parse; no changed helper has been operationally executed. Existing 17 offline mocked cases are retained with only the new expected counts, example version and initial-inventory test name changed.

## Required next bindings

Keep `execution-request.pending.json` immutable. It contains actual source/merge/tree/run identity, `reviewed: false`, and null deployment/artifact/original-pin slots pending root intake. Prepare a new proposal from the terminal originals and downloaded small ZIP; root must inspect/promote a separate `execution-request.reviewed.json` before execution. Root-created `root-review.json` must retain the actual review decision.

Both operational wrappers remain `.template` with literal `UNBOUND_REVIEWED_REQUEST_SHA256` sentinels. After root reviews the actual request, prepare separate executable successors substituting only that exact SHA. Do not weaken or remove the guard, overwrite originals, reuse predecessor run IDs, or create a reviewed file during preparation.

After review, use the established sequence: readiness → `collect-live.py before` → complete `http-tools/http_audit.py --run --workers 6` → `collect-live.py after` → independent `reconcile-completed-rows.py`. The audit records all results/attempts and copies exact input/authority originals into a fresh exclusive directory. The reconciler requires the complete inventory, matching final attempts, MIME/size/hash/URL evidence and unchanged before/after authority. Root owns the separate real UI retention journey and final archive admission; no phase, offline or physical-device acceptance is implied.
