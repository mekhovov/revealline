# Archive19 v0.60.4 append — bounded public audit proposal

Actual archive merge `7e771ad4925031ed8a1f6e4294567f43c1457934` has tree `4335f2971b5754c53d090e2dca6f85219bde5246`, identical to held source `d496531ab7d2494951a099a98875770eaae59560`. Automatic main-push run **35244771283**, attempt 1, completed successfully; deployment **6507017787**, success status **18483946637**. No manual dispatch was made.

The original receipt artifact **10507037391** is **72,443 bytes**, SHA-256 `0a59d1bd0e772cd6d1776be54c87362050c6bc68da5a9e66611f81e946b9db64`. Its exact four members, CRC, both original source/tag/ZIP chains and entire inventory match the reviewed source. Original API bodies and ZIP are in `../p05-motion-v0605-retention-plan/hosted-observer/terminal/` and `../p05-motion-v0605-retention-plan/hosted-originals/`. The first REST commit API body remains retained; the strict guard uses the separate original Git-commit API body. No source archive, distribution ZIP or full Pages artifact was downloaded.

## Exact adaptation

The expected inventory is **1,377 files / 626,197,712 bytes**, SHA-256 `85d00fdb446800596ff2f31176a96e1c887f185051e04b3b3204a5d0e171237b`. All **690 prior public rows**, including **687 canonical v0.60.3 rows**, must match byte-for-byte. Both candidate admission and final row reconciliation check this preserved inventory; it is not inferred from a total count.

`predecessor/` retains the six exact initial-Archive19 helpers. `adaptation.diff` changes only actual identity/count/hash/path constants, two-version receipt membership and preservation checks/reporting. HTTP transport, MIME policy, path guards, no-redirect behavior and bounds are unchanged: 64 KiB reads, one-byte oversize check, 25-second socket timeout, 90-second attempt deadline, 1,800-second total deadline, three recorded attempts maximum and four–eight workers (use six). Receipt members retain a 1 MiB combined/512 KiB individual bound. All 17 complete offline mocked cases pass; no public requests were made.

## Root review and future execution

`execution-request.proposed.json` contains all seven exact original pins and actual run/deployment/artifact IDs, with **reviewed false**. Root must review and promote a separate `execution-request.reviewed.json`; never overwrite the proposal or invent success. Keep root's decision in `root-review.json`. The operational/reconciliation wrappers retain `UNBOUND_REVIEWED_REQUEST_SHA256`; only substitute the SHA of the actual promoted request into new executable copies after review.

Execute the existing sequence once: readiness → `collect-live.py before` → full `http-tools/http_audit.py --run --workers 6` → `collect-live.py after` → bound `reconcile-completed-rows.py`. Preserve original outputs and every recorded attempt. Both fresh authority snapshots must bind the same main/run/deployment/latest status around the audit. Existing exclusive output directories prevent overwriting prior results. No source/index/remote mutation is involved.

Root owns separate native journeys and final admission. A hosted PASS or this proposed adapter is not public-byte, browser, offline, physical-input or whole-phase acceptance. The existing historical root index is intentionally unchanged; test v0.60.4 by its exact canonical URL and through the main Release explorer after the new allocation is admitted.
