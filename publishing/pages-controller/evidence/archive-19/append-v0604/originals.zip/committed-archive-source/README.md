# RevealLine archive 19

Retain the exact original v0.60.3 and v0.60.4 editions while newer releases become current. This repository stores small original metadata and bounded publication tools. Hosted preparation downloads the original release ZIPs one at a time, verifies every member against its original manifest and deletes each temporary ZIP. No historical game is rebuilt and no expanded game payload is committed.

The expected complete site is **1,377 files / 626,197,712 bytes**, leaving **173,802,288 bytes** under the unchanged **800,000,000-byte** cap. Every one of the previous 690 public rows remains byte-identical, including the historical v0.60.3 root entry and corrected Release explorer bridge. v0.60.4 is available at `releases/v0.60.4/site/game/`; the shared main catalog provides discovery. Original metadata, source qualification, annotated tags and frozen source identities are unchanged. See `source-lock.json` and the additive `appendProposal` in `input-authority.json`; authored expectations do not prove deployment.

## Review and publication

The existing repository, Actions Pages settings and main-only environment are retained. Review the small append on a branch and merge its normal PR after the complete tiny fixture cohort and hunk review. The main push then starts one deployment automatically. Do not manually dispatch a duplicate run. Both workflow jobs remain main-only; PRs do not publish an artifact or deploy, and this workflow does not advertise PR CI.

The original extractor stays pinned to `a13ab970222498d7c5fa7f62f9fc04fe436979d5`. Only the additional original annotated tag is fetched. Preserve the unchanged extractor and preparation/verification code, read-only contents permission, deploy-only Pages/id-token permissions, 3 GiB workspace check and 800 MB / 20,000-file budgets. Hosted preparation checks original tags, qualifications, every extracted member and the complete combined inventory; retain original failure receipts.

Run the complete offline fixtures with `python3 -m unittest discover -s tools -p 'test_*.py' -v`. The unchanged extractor has its separate four-case complete fixture file in the pinned source checkout. These checks use tiny synthetic payloads; they are not a game build, hosted extraction or public acceptance.

After deployment, collect its actual merge/tree/run/deployment/status and small original receipt artifact. Audit every expected public file, separately exercise both retained editions and their Release explorer bridge, and review the complete predecessor-row comparison before replacing Archive19's main-controller admission. Preserve historical evidence and all other archive owners/catalog records. Do not select a new current game as part of this retention append.

No native-device, disconnected-offline, main-to-archive profile migration, full P03/P05 or public Motion acceptance is implied. The existing root is deliberately preserved; original release assets and canonical paths cannot be replaced. Do not raise the cap or reuse predecessor deployment evidence for this successor.
