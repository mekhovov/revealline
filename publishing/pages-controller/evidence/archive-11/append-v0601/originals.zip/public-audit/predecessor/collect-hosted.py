"""Collect only actual terminal archive15 API originals, small logs and receipts."""
from pathlib import Path
import subprocess,json,datetime,hashlib,zipfile,stat
P=Path(__file__).resolve().parent;O=P/'hosted';SEL=json.loads((O/'actual-run-selection.json').read_bytes());M=json.loads((P/'publication/merge-result.json').read_bytes());REPO='mekhovov/revealline-archive-15';RUN=SEL['runId'];sha=lambda b:hashlib.sha256(b).hexdigest();enc=lambda v:(json.dumps(v,indent=2)+'\n').encode()
def call(name,endpoint,maximum=2_000_000,extension='json'):
 cmd=['gh','api','repos/'+REPO+'/'+endpoint];timed=False
 try:r=subprocess.run(cmd,capture_output=True,timeout=45);stdout,stderr,code=r.stdout,r.stderr,r.returncode
 except subprocess.TimeoutExpired as e:stdout,stderr,code=e.output or b'',e.stderr or b'',None;timed=True
 suffix='.partial' if timed or len(stdout)>=maximum else ''
 for ext,b in [(extension,stdout[:maximum-1]),('stderr',stderr[:1_999_999])]:
  with (O/(name+'.'+ext+suffix)).open('xb')as f:f.write(b)
 with (O/(name+'.attempt.json')).open('xb')as f:f.write(enc({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exitCode':code,'timedOut':timed,'stdoutBytes':len(stdout),'stderrBytes':len(stderr),'acceptedMaxBytesExclusive':maximum}))
 assert not timed and code==0 and len(stdout)<maximum and len(stderr)<2_000_000,(name,code)
 return json.loads(stdout) if extension=='json' else stdout
run=call('run',f'actions/runs/{RUN}');assert run['head_sha']==M['mergedCommit'] and run['head_branch']=='main' and run['event']=='push' and run['path']=='.github/workflows/deploy.yml' and run['status']=='completed' and run['conclusion']=='success'
jobs=call('jobs',f'actions/runs/{RUN}/jobs');assert len(jobs['jobs'])==2 and {j['name']for j in jobs['jobs']}=={'build','deploy'} and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs['jobs'])
artifacts=call('artifacts',f'actions/runs/{RUN}/artifacts');selected=[a for a in artifacts['artifacts'] if a['name']=='archive15-verification-receipts'];assert len(selected)==1;a=selected[0];assert not a['expired'] and 0<a['size_in_bytes']<10_485_760 and a['workflow_run']['id']==RUN and a['workflow_run']['head_sha']==M['mergedCommit']
main=call('main','git/ref/heads/main');commit=call('commit','git/commits/'+M['mergedCommit']);assert main['object']['sha']==commit['sha']==M['mergedCommit'] and commit['tree']['sha']==M['tree']
deps=call('deployments','deployments?environment=github-pages&per_page=10');assert deps and deps[0]['sha']==M['mergedCommit'];dep=call('deployment','deployments/'+str(deps[0]['id']));assert dep['sha']==M['mergedCommit'] and dep['environment']=='github-pages' and dep['ref']=='main'
statuses=call('statuses','deployments/'+str(dep['id'])+'/statuses');assert statuses and statuses[0]['state']=='success' and statuses[0]['environment_url'].rstrip('/')=='https://mekhovov.github.io/revealline-archive-15';url=statuses[0].get('log_url','');assert url=='https://github.com/'+REPO+'/actions/runs/'+str(RUN) or url.startswith('https://github.com/'+REPO+'/actions/runs/'+str(RUN)+'/') or str(dep.get('payload',{}).get('workflow_run_id'))==str(RUN)
raw=call('verification-receipts-original','actions/artifacts/'+str(a['id'])+'/zip',maximum=10_485_760,extension='zip');assert len(raw)==a['size_in_bytes'] and 'sha256:'+sha(raw)==a['digest']
E=O/'receipts';E.mkdir()
with zipfile.ZipFile(O/'verification-receipts-original.zip')as archive:
 expected={'receipt.json','expected-inventory.json','zip-receipt-v0.57.1.json','zip-receipt-v0.59.1.json'}
 names=set();total=0
 for member in archive.infolist():
  assert member.filename in expected and member.filename not in names and not member.is_dir() and not member.flag_bits&1 and stat.S_IFMT(member.external_attr>>16) in (0,stat.S_IFREG)
  names.add(member.filename);total+=member.file_size;assert total<64_000_000
 assert names==expected
 for member in archive.infolist():
  body=archive.read(member);assert len(body)==member.file_size;(E/member.filename).write_bytes(body)
receipt=json.loads((E/'receipt.json').read_bytes());inventory=(E/'expected-inventory.json').read_bytes();assert inventory==(P/'archive15-worktree/expected-inventory.json').read_bytes()
assert receipt['status']=='PASS' and receipt['archiveCommit']==M['mergedCommit'] and receipt['archiveTree']==M['tree'] and receipt['archiveId']=='archive-15' and receipt['files']==1343 and receipt['bytes']==625590130 and receipt['noHistoricalBuilds'] is True and receipt['expectedInventorySha256']==sha(inventory)
for version in ['v0.57.1','v0.59.1']:
 lock=next(x for x in json.loads((P/'archive15-worktree/source-lock.json').read_bytes())['releases'] if x['version']==version)
 z=json.loads((E/('zip-receipt-'+version+'.json')).read_bytes());assert z['version']==version and z['gameSourceRevision']==lock['sourceRevision'] and z['distributionSha256']==lock['distributionSha256'] and z['manifestSha256']==lock['metadata']['manifest.json'] and z['crcAndHashesVerified'] is True
for j in jobs['jobs']:call(j['name'],f'actions/jobs/{j["id"]}/logs',extension='log')
pins=[]
for p in sorted(O.rglob('*')):
 if p.is_file():b=p.read_bytes();pins.append({'path':p.relative_to(O).as_posix(),'bytes':len(b),'sha256':sha(b)})
result={'status':'HOSTED_ARCHIVE_DEPLOYMENT_AND_ORIGINAL_RECEIPTS_VERIFIED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':REPO,'candidate':M['candidate'],'commit':M['mergedCommit'],'tree':M['tree'],'pr':M['pr'],'runId':RUN,'runAttempt':run['run_attempt'],'deploymentId':dep['id'],'statusId':statuses[0]['id'],'environmentURL':statuses[0]['environment_url'],'receiptArtifact':{'id':a['id'],'bytes':len(raw),'sha256':sha(raw)},'files':1343,'bytes':625590130,'inventorySha256':sha(inventory),'manualDispatches':0,'publicByteAcceptance':False,'nativeAcceptance':False,'mainSelectorChanged':False,'pins':pins}
(O/'completion.json').write_bytes(enc(result));print(json.dumps({k:v for k,v in result.items()if k!='pins'}))
