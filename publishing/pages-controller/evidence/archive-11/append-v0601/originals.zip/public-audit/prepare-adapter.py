from pathlib import Path
import json,hashlib,difflib,ast
D=Path(__file__).resolve().parent;P=D.parent/'p05-archive16-public-audit';A=D.parent/'p05-v0602-retention-plan';I=D/'inputs';I.mkdir();C=A/'archive11-candidate';h=lambda b:hashlib.sha256(b).hexdigest()
for name,source in [('expected-inventory.json',C/'expected-inventory.json'),('source-lock.json',C/'source-lock.json'),('predecessor-inventory.json',A/'archive11-originals/expected-inventory.json')]: (I/name).write_bytes(source.read_bytes())
replacements=[('Archive16','Archive11'),('archive16','archive11'),('archive-16','archive-11'),('p05-v0601-retention-plan','p05-v0602-retention-plan'),('6c72f5cf8a82b51fc635dcc4c433c62cfb22c0bf','5fbc2456b4f5f53283398281736349c15972ac53'),('c02d6bf74f731a5e646159434325153ed79e841e7ff58c7f15b580be3440aeaa',h((I/'expected-inventory.json').read_bytes())),('5be38feb73ce5bbd6dfd5448e15773a4e2ca7028ba831a92d9fba90faf83280c',h((I/'predecessor-inventory.json').read_bytes())),('ab38ba6e860014a77487fafc3f2bd9d527a905722ab155ae7eda2666e6c138f6',h((I/'source-lock.json').read_bytes())),('1347','1305'),('625710011','636098834'),('660','618'),('v0.57.2','v0.51.0'),('v0.60.0','v0.60.1')]
files=['http-tools/http_audit.py','http-tools/audit_binding.py','http-tools/test_http_audit.py','collect-live.py'];diff=[];pins=[]
for name in files:
 old=(P/name).read_bytes();q=D/'predecessor'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(old);s=old.decode()
 for before,after in replacements:s=s.replace(before,after)
 if name.endswith('audit_binding.py'):s=s.replace("INFRA = AUTHORITY_ROOT / 'archive11-worktree'","INFRA = ROOT.parent / 'worktrees/archive11-retain-v0601'")
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);diff.extend(difflib.unified_diff(old.decode().splitlines(True),s.splitlines(True),fromfile='predecessor/'+name,tofile=name));pins.append({'path':name,'beforeBytes':len(old),'beforeSha256':h(old),'afterBytes':p.stat().st_size,'afterSha256':h(p.read_bytes())})
 # Compare source AST after only reviewed literal/path substitutions.
 expected=old.decode()
 for before,after in replacements:expected=expected.replace(before,after)
 if name.endswith('audit_binding.py'):expected=expected.replace("INFRA = AUTHORITY_ROOT / 'archive11-worktree'","INFRA = ROOT.parent / 'worktrees/archive11-retain-v0601'")
 assert ast.dump(ast.parse(s))==ast.dump(ast.parse(expected))
(D/'http-tool-adaptation.diff').write_text(''.join(diff));(D/'transport-preservation.json').write_text(json.dumps({'status':'PASS_CONSTANT_AND_HELD_CHECKOUT_PATH_ADAPTATION','comparedFiles':files,'replacements':replacements,'heldCheckoutPathChangeOnly':"INFRA = ROOT.parent / 'worktrees/archive11-retain-v0601'",'astEqualAfterExactNormalization':True,'pins':pins,'limitsUnchanged':{'chunks':65536,'socketSeconds':25,'attemptSeconds':90,'totalSeconds':1800,'attemptsPerFile':3,'workerMin':4,'workerMax':8},'publicBodyRequests':0},indent=2)+'\n')
print(json.dumps({'files':len(files),'patchSha256':h((D/'http-tool-adaptation.diff').read_bytes())}))
