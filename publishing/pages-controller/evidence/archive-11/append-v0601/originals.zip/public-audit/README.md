# Archive11 v0.60.1 append — finite audit handoff

**Prepared for root review. No public-body audit or browser acceptance has run.** The automatic hosted append succeeded and its small original receipts are verified. The proposed execution request remains `reviewed:false`; this task did not create a reviewed request or mutate any remote.

## Actual bound inputs

- Archive merge **0679f16d17afb7df30ae4b310b7fabae29269c3c**, tree **5fbc2456b4f5f53283398281736349c15972ac53**. Held source checkout `.cache/worktrees/archive11-retain-v0601` remains **bbf64e18178be54e21c63eec15b21d1a76278629** with that same tree.
- Automatic main-push run **35210514367**, attempt **1**, completed/success; deployment **6500626261**, latest success status **18469105514** links this run and archive site. No manual dispatch occurred.
- Small receipt artifact **10491474839**, `archive11-verification-receipts`, **68,583 bytes**, SHA-256 **0fc50937a622c90a1d44c31993babd72eb3f88d5a800a8b51e7eba93fcb189ae**. No Pages payload was downloaded.
- Exact expected inventory: **1,305 files / 636,098,834 bytes**, SHA-256 **ca04e9e5bd66e7320111e276e7ac5dd036873c6393795993e389257997c2e72f**. All **618** old v0.51.0 canonical rows remain exact. Only the shared root index changes among old rows; the main release-Explorer bridge is additive.
- `execution-request.proposed.json` SHA-256 **421d2ddd08baf8d98a52aa75d93c987fa89c18354163b3ed8da49148ad87f082** binds the actual seven original authority/receipt bodies. Root must review and promote a distinct copy.

Original run/jobs/artifact/main/commit/deployment/status responses, command attempts, bounded logs, small receipt ZIP and four exact receipt members are under `../p05-v0602-retention-plan/audit-binding-originals/`. Their `completion.json` records actual identities and pins. The main/commit/run/deployment/status/artifact/ZIP binding is rehashed before and after public execution; the held original source tree and inventory also remain required.

## Preserved helpers and checks

`predecessor/` preserves the Archive16 auditor, binding, offline fixtures and live observer plus the previously used bounded terminal collector. `http-tool-adaptation.diff` contains only archive/cohort/count/source/input-pin substitutions and the actual held-checkout path. `collector-adaptation.diff` binds the known merge/run/checkout and receipt names without weakening its accepted-size/time checks. `transport-preservation.json` records the exact source changes and unchanged limits.

The HTTP engine still refuses redirects, validates exact final URL/MIME/body length/SHA, stops at one byte beyond the expected body length, streams 64 KiB chunks without storing payloads, and uses **25-second socket / 90-second attempt / 1,800-second total limits**, at most **three attempts**, and **4–8 workers**. Failed attempts and final results remain separate originals; no execution URL/inventory/output override was introduced.

All **17 offline transport fixtures** and local `--prepare` passed. The unreviewed request was rejected. Actual local receipt/source intake passed with **only the review boolean mocked in memory**; no reviewed file was written and this is not approval. The initially mistyped `--candidate-only` command was rejected by argparse before any audit; its error record remains beside the corrected `--prepare` receipt. See `checks/` for exact outputs and boundaries.

## Root-reviewed execution entrypoint

1. Review the diffs, original actual receipts and all seven proposed pins. Preserve the proposal, create `execution-request.reviewed.json` changing only `reviewed` to `true`, and retain its exact hash in a separate root review. Confirm the held source checkout remains bbf64e18/tree5fbc2456.
2. Run readiness only:

   ```sh
   python3 -B .cache/p05-archive11-public-audit/http-tools/http_audit.py
   ```

3. Once root authorizes full execution, retain stdout/stderr/exit for these distinct commands:

   ```sh
   python3 -B .cache/p05-archive11-public-audit/collect-live.py before
   python3 -B .cache/p05-archive11-public-audit/http-tools/http_audit.py --run --workers 6
   python3 -B .cache/p05-archive11-public-audit/collect-live.py after
   ```

   The auditor creates a unique `http/http-*` directory; it does not overwrite a failed run or save game payloads. Before/after observations must still name the same main, successful run, deployment and latest successful status. Abort on authority drift. No duplicate hosted collector or workflow dispatch is needed.
4. Independently reconcile all 1,305 final unique paths and actual attempts: compare **path iterables**, exact URL/size/hash/status, all 618 old canonical rows, full byte total, failures/retries/skips and the immutable request/runner/input pins. Retain honest outcomes; do not turn a successful retry into a clean first pass. The existing audited row-review procedure suffices; no new evidence framework is required.

## Remaining browser and admission boundary

After successful full-body reconciliation, inspect actual archive index → v0.51.0 and v0.60.1 entry/play/pause/resume, then the main release Explorer. Record performed actions and exact source/URLs. Legacy session behavior, provider failures, save migration, offline, physical controllers/touch and subjective gameplay remain separate.

Only after HTTP and native acceptance may root add an `archive-11/append-v0601` admission package to the main publisher. Preserve all **14** existing evidence pins; demote superseded current roles to reference when the strict schema requires a single current inventory/HTTP/browser authority, then add the measured successor evidence. Append v0.60.1 to Archive11's existing allocation and retain every other owner. Hosted success alone is not public or next-game-release acceptance.
