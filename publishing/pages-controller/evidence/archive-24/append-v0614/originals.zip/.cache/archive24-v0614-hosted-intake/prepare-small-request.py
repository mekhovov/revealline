from pathlib import Path
import json,hashlib,difflib,shutil
P=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):b=p.read_bytes();return {'path':str(p.relative_to(P)),'bytes':len(b),'sha256':sha(b)}
assert shutil.disk_usage(P).free>536870912+4194304
terminal=json.loads((P/'terminal-originals.json').read_bytes());assert terminal['runAttempt']==2 and terminal['runId']==35336603609
for row in terminal['pins']:
 p=P/row['path'];b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
request=json.loads((P.parent/'archive24-v0613-hosted-intake/small-receipt-request.proposed.json').read_bytes())
for key in ['repository','archiveCommit','archiveTree','runId','deploymentId','deploymentStatusId','artifactId','artifactBytes','artifactSha256']:request[key]=terminal[key]
request.update(sourceCheckoutCommit='9255b16b465833d800f9da5fde6a05362997e6d8',apiEndpoint='repos/mekhovov/revealline-archive-24/actions/artifacts/'+str(terminal['artifactId'])+'/zip',expectedMembers=['receipt.json','expected-inventory.json','zip-receipt-v0.61.3.json','zip-receipt-v0.61.4.json'],expectedFiles=1394,expectedBytes=626715708,inventorySha256=sha((P/'inputs/expected-inventory.json').read_bytes()),originalPins=terminal['pins']+[pin(P/'inputs/expected-inventory.json'),pin(P/'inputs/source-lock.json')])
assert request['reviewed'] is False and request['artifactBytes']<request['maxDownloadBytes']
with (P/'small-receipt-request.proposed.json').open('x') as f:json.dump(request,f,indent=2);f.write('\n')
helper=P/'intake-small-receipt.py';old=helper.read_text();(P/'intake-small-receipt.unbound.py').write_text(old);new=old.replace("req['artifactId']==None",f"req['artifactId']=={request['artifactId']}").replace("req['artifactBytes']==None",f"req['artifactBytes']=={request['artifactBytes']}").replace("req['artifactSha256']==None",f"req['artifactSha256']=='{request['artifactSha256']}'")
assert new!=old;helper.write_text(new);(P/'intake-actual-binding.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='intake-small-receipt.unbound.py',tofile='intake-small-receipt.py')))
ready={'status':'ACTUAL_ATTEMPT2_SMALL_RECEIPT_PROPOSED_FOR_ROOT_REVIEW','request':pin(P/'small-receipt-request.proposed.json'),'helper':pin(helper),'helperBindingDiff':pin(P/'intake-actual-binding.diff'),'terminalOriginals':pin(P/'terminal-originals.json'),'runId':terminal['runId'],'runAttempt':2,'artifactId':terminal['artifactId'],'artifactBytes':terminal['artifactBytes'],'artifactSha256':terminal['artifactSha256'],'expectedMembers':request['expectedMembers'],'expectedFiles':1394,'expectedBytes':626715708,'artifactBodyGETs':0,'archiveAccepted':False,'priorFailurePreserved':True,'rootCommand':'python3 -B '+str(helper)+' <root-reviewed-request-sha256>'}
with (P/'terminal-ready.json').open('x') as f:json.dump(ready,f,indent=2);f.write('\n')
print(json.dumps(ready,indent=2))
