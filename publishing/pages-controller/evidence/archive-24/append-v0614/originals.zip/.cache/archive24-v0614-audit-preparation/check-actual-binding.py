"""Local validation of a proposed packet. Does not create reviewed authority or request bodies."""
from pathlib import Path
from unittest.mock import patch
import sys,json,hashlib,shutil
R=Path.cwd();D=R/'.cache/archive24-v0614-public-audit';P=R/'.cache/archive24-v0614-audit-preparation';assert shutil.disk_usage(R).free>536870912+1048576
sys.path.insert(0,str(D/'http-tools'));import audit_binding as binding
source=D/'execution-request.bound-proposed.json';raw=source.read_bytes();request=json.loads(raw);assert request['reviewed'] is False
with patch.object(binding,'REQUEST',source):
 try:binding.validate_execution_binding()
 except ValueError as error:assert str(error)=='Actual request requires explicit review'
 else:raise AssertionError('Unreviewed authority was accepted')
# Test all other identity, source, original ZIP and CRC checks with only the
# review gate injected in memory. This is a local dry check, not root approval.
fixture=json.dumps(dict(request,reviewed=True),indent=2).encode();real_bytes=binding.local_bytes
def bytes_for_check(path,limit=2*1024**2):
 return fixture if path==source else real_bytes(path,limit)
with patch.object(binding,'REQUEST',source),patch.object(binding,'local_bytes',bytes_for_check):result=binding.validate_execution_binding()
assert len(result['rows'])==1394 and sum(r['bytes'] for r in result['rows'])==626715708
assert source.read_bytes()==raw and not (D/'execution-request.reviewed.json').exists()
receipt={'status':'LOCAL_PROPOSED_IDENTITIES_AND_ZIP_PASS_ROOT_REVIEW_STILL_REQUIRED','requestSha256':hashlib.sha256(raw).hexdigest(),'reviewedFlagOnDisk':False,'realUnreviewedRequestRefused':True,'inMemoryReviewFlagWasTestFixtureOnly':True,'sourceCheckoutCommit':request['sourceCheckoutCommit'],'archiveCommit':request['archiveCommit'],'archiveTree':request['archiveTree'],'runId':request['runId'],'deploymentId':request['deploymentId'],'receiptArtifactId':request['receiptArtifactId'],'files':1394,'bytes':626715708,'priorNonIndexRowsPreserved':697,'allSevenAuthorityBodiesRehashed':True,'fourReceiptMembersAndCRCVerified':True,'sourceLockTagCoverageChecked':True,'networkRequests':0,'publicAuditExecuted':False,'rootApprovalCreated':False}
with (P/'actual-binding-check.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt,indent=2))
