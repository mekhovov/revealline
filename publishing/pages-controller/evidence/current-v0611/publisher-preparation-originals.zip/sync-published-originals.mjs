import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { syncReleaseMetadata } from "file:///Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/worktrees/v0611-publisher-preparation/publishing/pages-controller/sync-release-metadata.mjs";
const directory = "/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/v0611-publisher-preparation/published-metadata-get-r1";
const receipt = JSON.parse(await fs.readFile(directory + '/receipt.json'));
const byName = new Map(receipt.checks.map(row => [row.name, row]));
const result = await syncReleaseMetadata({versions:['v0.61.1'], qualificationVersion:'v0.61.1', download:async (version,name) => {
  if (version !== 'v0.61.1' || !byName.has(name)) throw new Error('Unexpected metadata input');
  const row=byName.get(name), raw=await fs.readFile(directory+'/'+name);
  if (raw.length!==row.bytes || createHash('sha256').update(raw).digest('hex')!==row.sha256) throw new Error('Published original pin changed');
  return raw;
}});
console.log(JSON.stringify(result,null,2));
