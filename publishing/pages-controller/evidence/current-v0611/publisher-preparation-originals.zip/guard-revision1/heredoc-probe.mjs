import assert from 'node:assert/strict';
import { checkArchiveTagFetch } from './archive-tag-fetch.mjs';
const lock={format:'revealline-archive-originals.v2',releases:[{version:'v0.60.9'},{version:'v0.61.0'}]};
const workflow=`jobs:
  build:
    steps:
      - name: Print a documentation example, without fetching
        run: |
          cat <<'EOF'
          - name: Not a real workflow step
            working-directory: source
            run: git fetch --depth=1 origin refs/tags/v0.60.9:refs/tags/v0.60.9 refs/tags/v0.61.0:refs/tags/v0.61.0
          EOF
`;
assert.throws(()=>checkArchiveTagFetch(lock,workflow),/every locked tag/);
