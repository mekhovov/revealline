import fs from 'node:fs/promises';
const dir=new URL('./',import.meta.url),identity=JSON.parse(await fs.readFile(new URL('target-identity.json',dir),'utf8'));
const active=await (await fetch('http://127.0.0.1:61469/json/list')).json();
const target=active.find(t=>t.id===identity.id);
if(!target||target.type!=='page'||!['about:blank','https://mekhovov.github.io/revealline-archive-12/','https://mekhovov.github.io/revealline/releases/'].some(p=>target.url===p||target.url.startsWith(p)))throw Error('Owned browser target or allowed route changed');
const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});
let id=0;const pending=new Map();ws.addEventListener('message',e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);pending.delete(m.id);m.error?p?.reject(Error(JSON.stringify(m.error))):p?.resolve(m.result);}});
const call=(method,params={})=>new Promise((resolve,reject)=>{const i=++id;pending.set(i,{resolve,reject});ws.send(JSON.stringify({id:i,method,params}));});
const expression=`JSON.stringify({at:new Date().toISOString(),url:location.href,title:document.title,viewport:{width:innerWidth,height:innerHeight},body:document.body.innerText,focus:{tag:document.activeElement?.tagName,id:document.activeElement?.id,text:document.activeElement?.textContent},visibleDialogs:[...document.querySelectorAll('dialog,[role=dialog]')].filter(e=>e.getClientRects().length).map(e=>({id:e.id,text:e.innerText})),canvas:[...document.querySelectorAll('canvas')].map(e=>({width:e.width,height:e.height,rect:(()=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}})()})),storageKeys:(()=>{try{return Object.keys(localStorage)}catch{return null}})(),serviceWorker:navigator.serviceWorker?.controller?.scriptURL||null})`;
const snap=async()=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true});if(r.exceptionDetails)throw Error('Observation failed');return JSON.parse(r.result.value)};
const [action,name,arg,ms]=process.argv.slice(2);if(!/^[a-z0-9-]+\.json$/.test(name||''))throw Error('Bounded new observation filename required');
const before=await snap();let detail={};
try{
 if(action==='hold'){
  const keys={ArrowLeft:37,ArrowUp:38,ArrowRight:39,ArrowDown:40,Space:32};if(!(arg in keys)||!Number.isInteger(Number(ms))||Number(ms)<1||Number(ms)>6000)throw Error('Invalid bounded native key');
  const key={key:arg==='Space'?' ':arg,code:arg,windowsVirtualKeyCode:keys[arg],nativeVirtualKeyCode:keys[arg]};
  await call('Input.dispatchKeyEvent',{type:'keyDown',...key});try{await new Promise(r=>setTimeout(r,Number(ms)));}finally{await call('Input.dispatchKeyEvent',{type:'keyUp',...key});}
  detail={key:arg,durationMs:Number(ms),nativeTrustedInput:true};
 }else if(action==='offline'||action==='online'){
  await call('Network.enable');await call('Network.emulateNetworkConditions',{offline:action==='offline',latency:0,downloadThroughput:-1,uploadThroughput:-1});detail={pageNetworkOffline:action==='offline'};
 }else if(action!=='snapshot')throw Error('Unknown bounded browser observation');
 const record={action,...detail,targetId:target.id,before,after:await snap()};await fs.writeFile(new URL(name,dir),JSON.stringify(record,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({file:name,action,url:record.after.url,body:record.after.body.slice(0,3000)}));
}finally{ws.close();}
