Preserve the immutable v0.57.1 release in its own archive so the main game can later advance to a corrective release. The hosted workflow uses the reviewed original-ZIP extractor and exact tag/source/metadata/qualification pins; no game build, asset replacement or other archive change occurs.

The complete artifact is 662 files / 312,555,435 bytes. All 654 original game files are preserved, with original metadata and source qualification, the existing build marker, and a root/canonical release-explorer bridge. The source TAR and original ZIP remain GitHub Release attachments. Known Library and craft-loading placement defects stay documented as historical behavior; this does not accept P01.

Validation: 20 infrastructure tests and four pinned extractor corruption tests pass. All 16 candidate file bytes match the reviewed pins; metadata-derived inventory and unchanged 800 MB budget pass. Initial copied fixture identity mismatches were retained and corrected only to the exact v0.57.1 constants. Bootstrap main contains no workflow. Both jobs are main-only, and one normal merge triggers publication; manual dispatch remains only a guarded retry after an actual failure.

After deployment, admission still requires original hosted receipts, every public body/MIME/hash, and a separately coordinated native historical play/return sample. No main controller selector change is included.
