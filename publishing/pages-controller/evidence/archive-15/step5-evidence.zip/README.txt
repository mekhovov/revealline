Archive15 completed infrastructure and full HTTP evidence only.
98 original step-5 files and their original evidence index are byte-preserved.
Initial local fixture mismatches and pre-request output-directory refusal remain retained.
There were no actual HTTP failed attempts, retries, skipped files or persisted bodies.
Native browser admission is pending; this package does not assert browser, physical-device, offline or P01 acceptance.
Archive15 preserves historical v0.57.1 including known Library, craft-feedback and Controller Apply focus findings. The later v0.57.2 feature correction remains separately qualified; P01 stays open for other loading hosts.
No credentials or signed URLs are intentionally included; static credential scan is recorded separately.
