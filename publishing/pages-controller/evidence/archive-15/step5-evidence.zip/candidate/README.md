# Reveal Line archive 15

Preserve original v0.57.1 from source `4c85277ac7393eeeabab035387d4d4ae8734aba1`, tree `d3549d0efd15529f71f4cff9a940bdda5e84f3a6`. The annotated tag, release metadata, original ZIP and source qualification are pinned in `source-lock.json` and `input-authority.json`.

This archive retains historical behavior. Known v0.57.1 Library operation placement and craft-loading feedback behind the Missions modal remain in its immutable game. The corrective release is qualified separately; this archive does not accept P01. No game source, artwork, sound or saved originals are rebuilt or replaced.

`tools/prepare.py` runs only in a fresh hosted workspace with at least3GiB free. It verifies clean pinned extractor source, exact annotated tag, original metadata/qualification, the one original ZIP and every ZIP member. It rereads all662 artifact files (312,555,435 bytes), including hidden files. Missing, extra, changed, unsafe and linked paths fail. The800,000,000-byte archive budget is unchanged.

The canonical game is `releases/v0.57.1/site/game/`. Manifest/checksum/build marker stay beneath `site/`; release and original source qualification stay beside it. Original ZIP/source TAR and qualification evidence remain immutable GitHub Release attachments. The root links the original ZIP; `/releases/` redirects with accessible fallback to the main explorer so browser Back returns naturally without changing frozen game pages.

The reviewed workflow checks out only pinned extractor/tests. It runs tiny infrastructure tests, then hosted extraction/verification and one automatic main-push deployment. Both jobs are main-only; serialized workflow_dispatch is retained only for a needed retry after an actual failed attempt, never a concurrent duplicate. Bootstrap main contains no workflow. No source tags, other archives or main selector are changed.

Local checks: `python3 -m unittest discover -s tools -p 'test_*.py' -v`, plus the pinned extractor's four synthetic corruption tests. Hosted/public receipt, complete streamed HTTP/MIME/hash verification and a separately coordinated native historical play/capture/pause plus explorer Back sample are required before a new controller admission. Every source/HTTP/browser/physical evidence category and historical defect remains distinct.
