from pathlib import Path
import sys,subprocess,json,datetime,hashlib
O=Path(__file__).resolve().parent;label,cwd,*argv=sys.argv[1:]
assert label.replace('-','').isalnum() and argv
folder=O/'remote';folder.mkdir(exist_ok=True);path=folder/(label+'.json');assert not path.exists()
start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=cwd,capture_output=True,text=True,timeout=180)
assert len(r.stdout.encode())+len(r.stderr.encode())<3*1024*1024
obj={'startedAt':start,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':cwd,'argv':argv,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
with path.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
print(r.stdout);print(r.stderr,file=sys.stderr);print('RECEIPT',path,'SHA256',hashlib.sha256(path.read_bytes()).hexdigest(),file=sys.stderr)
raise SystemExit(r.returncode)
