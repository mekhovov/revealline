from pathlib import Path
import subprocess,json,hashlib,datetime,shutil
R=Path.cwd();O=R/'.cache/cross-mode/p01/archive15-v0571';C=O/'candidate';P=R/'.cache/cross-mode/p01/v0572/archive15-plan';T=R/'.cache/cross-mode/p01/archive14-v057/repository';TC='740878b685b08edb40db5494f7ebbe71536b523a';sha=lambda b:hashlib.sha256(b).hexdigest()
C.mkdir(exist_ok=False);(O/'evidence/tooling').mkdir(parents=True)
plan=json.loads((P/'plan.json').read_text());assert plan['expectedInventory']['sha256']=='c5cf1352d8bcaaa36dd53d65e570ecc8e571bc3724641325521e09e54dd7b89f'
paths=subprocess.check_output(['git','-C',str(T),'ls-tree','-r','--name-only',TC]).decode().splitlines();assert len(paths)==16
for path in paths:
 b=subprocess.check_output(['git','-C',str(T),'show',TC+':'+path]);dest=C/path.replace('v0.57.0','v0.57.1');dest.parent.mkdir(parents=True,exist_ok=True)
 if path.startswith('metadata/'):
  b=(P/'original-metadata'/Path(path).name).read_bytes()
 elif path=='index.html':b=(P/'planned-root/index.html').read_bytes()
 elif path=='releases/index.html':assert b==(P/'planned-root/releases/index.html').read_bytes()
 elif path=='expected-inventory.json':b=(P/'expected-inventory.json').read_bytes()
 elif path=='.github/workflows/deploy.yml':b=b.replace(b'archive 14',b'archive 15').replace(b'archive-14',b'archive-15').replace(b'archive14',b'archive15').replace(b'v0.57.0',b'v0.57.1')
 elif path=='source-lock.json':
  d=json.loads(b);d.update({'archiveId':'archive-15','repository':'mekhovov/revealline-archive-15','expectedInventorySha256':plan['expectedInventory']['sha256'],'expectedFiles':662,'expectedBytes':312555435})
  r=d['releases'][0];r.update({'version':'v0.57.1','sourceRevision':plan['originalRelease']['sourceRevision'],'sourceTree':plan['originalRelease']['sourceTree'],'tagObject':plan['originalRelease']['tagObject'],'distributionSha256':next(a['sha256'] for a in plan['originalRelease']['assets'] if a['name']=='distribution.zip'),'distributionBytes':312616348})
  r['metadata']={n:sha((P/'original-metadata'/n).read_bytes()) for n in ['release.json','manifest.json','distribution.zip.sha256']};r['sourceQualification']={'sha256':sha((P/'original-metadata/source-qualification.json').read_bytes()),'bytes':52290};b=(json.dumps(d,indent=2)+'\n').encode()
 elif path=='input-authority.json':
  d={'format':'revealline-archive-preservation-candidate.v1','status':'REVIEWED_PLAN_AUTHORIZED_FOR_ARCHIVE_ONLY_EXECUTION','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archiveId':'archive-15','repository':'mekhovov/revealline-archive-15','templateRepository':'mekhovov/revealline-archive-14','templateCommit':TC,'toolingCommit':plan['template']['extractorCommit'],'extractorSha256':plan['template']['extractorSha256'],'publishedMetadataCommit':plan['controllerCommit'],**plan['originalRelease'],'capacity':plan['capacity'],'knownHistoricalFindings':plan['knownHistoricalFindings'],'preservation':'All654 original manifest rows and original release/checksum/manifest/qualification bytes. No game rebuild or replacement. ZIP/source TAR remain immutable release attachments.','scope':'Only Archive15 infrastructure/publication; no other archive, game source, main controller or tag changes. Native archival evidence follows separately; P01 unaccepted.'};b=(json.dumps(d,indent=2)+'\n').encode()
 elif path=='README.md':
  b='''# Reveal Line archive 15

Preserve original v0.57.1 from source `4c85277ac7393eeeabab035387d4d4ae8734aba1`, tree `d3549d0efd15529f71f4cff9a940bdda5e84f3a6`. The annotated tag, release metadata, original ZIP and source qualification are pinned in `source-lock.json` and `input-authority.json`.

This archive retains historical behavior. Known v0.57.1 Library operation placement and craft-loading feedback behind the Missions modal remain in its immutable game. The corrective release is qualified separately; this archive does not accept P01. No game source, artwork, sound or saved originals are rebuilt or replaced.

`tools/prepare.py` runs only in a fresh hosted workspace with at least3GiB free. It verifies clean pinned extractor source, exact annotated tag, original metadata/qualification, the one original ZIP and every ZIP member. It rereads all662 artifact files (312,555,435 bytes), including hidden files. Missing, extra, changed, unsafe and linked paths fail. The800,000,000-byte archive budget is unchanged.

The canonical game is `releases/v0.57.1/site/game/`. Manifest/checksum/build marker stay beneath `site/`; release and original source qualification stay beside it. Original ZIP/source TAR and qualification evidence remain immutable GitHub Release attachments. The root links the original ZIP; `/releases/` redirects with accessible fallback to the main explorer so browser Back returns naturally without changing frozen game pages.

The reviewed workflow checks out only pinned extractor/tests. It runs tiny infrastructure tests, then hosted extraction/verification and one automatic main-push deployment. Both jobs are main-only; serialized workflow_dispatch is retained only for a needed retry after an actual failed attempt, never a concurrent duplicate. Bootstrap main contains no workflow. No source tags, other archives or main selector are changed.

Local checks: `python3 -m unittest discover -s tools -p 'test_*.py' -v`, plus the pinned extractor's four synthetic corruption tests. Hosted/public receipt, complete streamed HTTP/MIME/hash verification and a separately coordinated native historical play/capture/pause plus explorer Back sample are required before a new controller admission. Every source/HTTP/browser/physical evidence category and historical defect remains distinct.
'''.encode()
 dest.write_bytes(b)
for name in ['extract-current.py','test_extract_current.py']:
 b=subprocess.check_output(['git','show','0594b60136db000c9d6c87527c7885c2c51a2562:publishing/pages-controller/'+name]);(O/'evidence/tooling'/name).write_bytes(b)
assert sha((O/'evidence/tooling/extract-current.py').read_bytes())==plan['template']['extractorSha256']
actual=[p for p in C.rglob('*') if p.is_file()];assert len(actual)==16
pins=[{'path':str(p.relative_to(C)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(actual)]
receipt={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'templateCommit':TC,'planSha256':sha((P/'plan.json').read_bytes()),'candidateFiles':pins,'count':16,'bytes':sum(x['bytes'] for x in pins),'sourcePayloadDownloaded':False,'localFreeBytes':shutil.disk_usage(O).free,'archiveOnlyAuthorized':True,'scope':'Prepared candidate only, no remote writes or payload assembly yet.'}
(O/'candidate-pins.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'count':16,'bytes':receipt['bytes'],'pinsSha256':sha((O/'candidate-pins.json').read_bytes()),'freeBytes':receipt['localFreeBytes']}))
