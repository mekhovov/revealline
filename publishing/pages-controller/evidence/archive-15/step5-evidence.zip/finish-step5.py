from pathlib import Path
import subprocess,json,hashlib,datetime
O=Path(__file__).resolve().parent;HTTP=O/'http/http-20260915T141905Z-4c092b47';P=O/'post-http';SHA='546610e6bae47f80122ee59cd69baa6546f6fe39';RUN=34980491924;DEP=6460910463;REPO='mekhovov/revealline-archive-15';H=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p.relative_to(O)),'bytes':len(b),'sha256':H(b)}
report=json.loads((HTTP/'http-report.json').read_text());expected=json.loads((O/'repository/expected-inventory.json').read_text());result=[json.loads(x) for x in (HTTP/'http-results.jsonl').read_text().splitlines()];attempts=[json.loads(x) for x in (HTTP/'http-attempts.jsonl').read_text().splitlines()]
assert report['status']=='PASS' and report['files']==662 and report['verifiedBytes']==312555435 and report['archiveCommit']==SHA and report['failedFiles']==0 and not report['skipped'] and report['payloadFilesPersisted'] is False
assert len(result)==len({x['path'] for x in result})==662 and {x['path'] for x in result}=={x['path'] for x in expected['files']}
ex={x['path']:x for x in expected['files']}
for row in result:
 a=ex[row['path']];assert row['status']=='PASS' and row['bytes']==a['bytes'] and row['sha256']==a['sha256'] and row['url']==row['finalURL'] and row['requestStarted']
 assert any(x==row for x in attempts)
assert len(attempts)==report['attempts'] and sum(x['status']!='PASS' for x in attempts)==report['failedAttempts']
P.mkdir(exist_ok=False)
def api(route,name):
 r=subprocess.run(['gh','api','repos/'+REPO+'/'+route],capture_output=True,timeout=60);assert r.returncode==0,r.stderr.decode();assert len(r.stdout)<2*1024*1024
 with (P/name).open('xb') as f:f.write(r.stdout)
 return json.loads(r.stdout)
main=api('git/ref/heads/main','main.json');assert main['object']['sha']==SHA
r=api('actions/runs/'+str(RUN),'run.json');assert r['status']=='completed' and r['conclusion']=='success' and r['head_sha']==SHA and r['run_attempt']==1
allruns=api('actions/runs?per_page=100','all-runs.json');assert allruns['total_count']==1 and len(allruns['workflow_runs'])==1 and allruns['workflow_runs'][0]['id']==RUN and allruns['workflow_runs'][0]['event']=='push'
deployments=api('deployments?environment=github-pages&per_page=100','deployments.json');assert len(deployments)==1 and deployments[0]['id']==DEP and deployments[0]['sha']==SHA
statuses=api('deployments/'+str(DEP)+'/statuses?per_page=100','statuses.json');assert statuses[0]['state']=='success' and statuses[0]['environment_url']=='https://mekhovov.github.io/revealline-archive-15/' and str(RUN) in statuses[0]['log_url']
post={'status':'PASS','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'infrastructureCommit':SHA,'runId':RUN,'deploymentId':DEP,'latestMainRunAndDeploymentUnchanged':True,'oneAutomaticRunNoManualDuplicates':True,'httpFinishedAt':report['verifiedAt'],'pins':[pin(p) for p in sorted(P.iterdir())]}
(P/'review.json').write_text(json.dumps(post,indent=2)+'\n')
completion={'status':'PASS_STEPS_1_TO_5','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Archive15 infrastructure and actual hosted plus full HTTP verification only. Native step6 and controller admission remain pending; P01 unaccepted.','version':'v0.57.1','sourceRevision':'4c85277ac7393eeeabab035387d4d4ae8734aba1','sourceTree':'d3549d0efd15529f71f4cff9a940bdda5e84f3a6','tagObject':'8b2c1106606ab42d3246b1bc836c4e6b1ad1cb3f','infrastructureCommit':SHA,'infrastructureTree':'9881cab9459e1d2dc6f093c8e002468973406829','workflowRunId':RUN,'deploymentId':DEP,'files':662,'bytes':312555435,'actualHTTPAttempts':len(attempts),'actualHTTPFailedAttempts':report['failedAttempts'],'retriedFiles':report['retriedFiles'],'publicBase':expected['base'],'noPayloadFilesPersisted':True,'candidateFilePins':16,'tests':{'candidateInfrastructure':20,'exactCommittedInfrastructure':20,'pinnedExtractor':4,'httpTool':15,'hostedInfrastructure':20,'hostedExtractor':4},'preservedPreparationFailures':['evidence/infrastructure-tests-initial.log','evidence/initial-fixture-correction.json','remote/016-http-tool-tests.json','evidence/http-test-pin-correction.json','evidence/http-initial-directory-failure.json'],'actualPublicFailuresPreserved':report['failures'],'originalsUnchanged':True,'otherArchivesOrMainModified':False,'nativeBrowserComplete':False,'controllerAdmissionComplete':False,'phaseAccepted':False,'observerClosed':'Hosted observer exited0 after actual success; full HTTP process completed. No browser launched.','knownHistoricalDefects':['Library progress/controls placement in immutable v0.57.1','Craft loading status behind Missions modal in immutable v0.57.1'],'nextNativePlan':'After separate foreground GO and512MiB+100MiB capacity guard, fresh exact named profile for Archive15 only: title→Deploy→ordinary capture→pause, release explorer→Back, bounded portrait route sample; retain visibility/identity/error observations and known defects, close owned browser. No fixture import/offline build/state injection or claims of corrective behavior.','keyPins':[pin(O/'candidate-pins.json'),pin(O/'prepublication-review.json'),pin(O/'committed-candidate.json'),pin(O/'merged-commit.json'),pin(O/'hosted/review.json'),pin(O/'hosted/original-receipts.zip'),pin(O/'hosted/receipt.json'),pin(HTTP/'http-report.json'),pin(HTTP/'http-results.jsonl'),pin(HTTP/'http-attempts.jsonl'),pin(P/'review.json')]}
(O/'completion-step5.json').write_text(json.dumps(completion,indent=2)+'\n')
selected=[]
for p in sorted(O.rglob('*')):
 if not p.is_file() or p.is_symlink() or '.git' in p.parts or '__pycache__' in p.parts or 'repository' in p.relative_to(O).parts or p.name=='evidence-index.json':continue
 assert p.stat().st_size<4*1024*1024
 selected.append(pin(p))
idx={'scope':'Completed Archive15 steps1–5 originals, preparation attempts, exact16-file candidate, helpers and HTTP rows; no duplicate Git checkout, profile or payload. Native/controller admission still pending.','files':selected,'count':len(selected),'bytes':sum(x['bytes'] for x in selected)}
(O/'evidence-index.json').write_text(json.dumps(idx,indent=2)+'\n')
for x in selected:
 b=(O/x['path']).read_bytes();assert len(b)==x['bytes'] and H(b)==x['sha256']
print(json.dumps({'completion':pin(O/'completion-step5.json'),'index':pin(O/'evidence-index.json'),'count':len(selected),'bytes':idx['bytes'],'publicFiles':662,'publicBytes':312555435,'failedAttempts':report['failedAttempts'],'retries':report['retriedFiles']}))
