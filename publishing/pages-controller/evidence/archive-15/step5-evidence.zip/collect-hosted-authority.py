from pathlib import Path
import subprocess,json,hashlib,zipfile,io,datetime,re
O=Path(__file__).resolve().parent;H=O/'hosted';REPO='mekhovov/revealline-archive-15';RUN=34980491924;SHA='546610e6bae47f80122ee59cd69baa6546f6fe39';TREE='9881cab9459e1d2dc6f093c8e002468973406829';digest=lambda b:hashlib.sha256(b).hexdigest()
def save(name,b):
 with (H/name).open('xb') as f:f.write(b)
def api(path,name):
 r=subprocess.run(['gh','api','repos/'+REPO+'/'+path],capture_output=True,timeout=60)
 assert r.returncode==0,(path,r.stderr.decode());assert len(r.stdout)<2*1024*1024;save(name,r.stdout);return json.loads(r.stdout)
def pin(p):
 b=p.read_bytes();return {'path':str(p.relative_to(H)),'bytes':len(b),'sha256':digest(b)}
run=json.loads((H/'run.json').read_text());jobs=json.loads((H/'jobs.json').read_text());artifacts=json.loads((H/'artifacts.json').read_text())
assert run['id']==RUN and run['head_sha']==SHA and run['head_commit']['tree_id']==TREE and run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1 and run['event']=='push'
assert jobs['total_count']==2 and {j['name'] for j in jobs['jobs']}=={'build','deploy'} and all(j['conclusion']=='success' and j['run_id']==RUN for j in jobs['jobs'])
for j in jobs['jobs']:
 assert all(s['conclusion']=='success' for s in j['steps'])
 log=(H/f'job-{j["id"]}.log').read_text();assert '##[error]' not in log
 if j['name']=='build':
  assert SHA in log and '0594b60136db000c9d6c87527c7885c2c51a2562' in log
  assert 'Ran 20 tests' in log and 'Ran 4 tests' in log
candidates=[x for x in artifacts['artifacts'] if x['name']=='archive15-verification-receipts'];assert len(candidates)==1;a=candidates[0]
assert not a['expired'] and a['workflow_run']['id']==RUN and a['workflow_run']['head_sha']==SHA and 0<a['size_in_bytes']<2*1024*1024 and re.fullmatch(r'sha256:[0-9a-f]{64}',a['digest'])
r=subprocess.run(['gh','api',f'repos/{REPO}/actions/artifacts/{a["id"]}/zip'],capture_output=True,timeout=60);assert r.returncode==0,r.stderr.decode();b=r.stdout;assert len(b)==a['size_in_bytes'] and 'sha256:'+digest(b)==a['digest'];save('original-receipts.zip',b)
expected={'receipt.json','zip-receipt-v0.57.1.json','expected-inventory.json'};members=[]
with zipfile.ZipFile(io.BytesIO(b)) as z:
 infos=z.infolist();assert {x.filename for x in infos}==expected and len(infos)==3
 for x in infos:
  assert not x.is_dir() and x.file_size<512*1024 and x.compress_size<=len(b) and not x.flag_bits&1
  raw=z.read(x);assert len(raw)==x.file_size;save(x.filename,raw);members.append({'path':x.filename,'bytes':len(raw),'sha256':digest(raw),'crc32':x.CRC})
rec=json.loads((H/'receipt.json').read_text());ziprec=json.loads((H/'zip-receipt-v0.57.1.json').read_text());inv=(H/'expected-inventory.json').read_bytes();localinv=(O/'repository/expected-inventory.json').read_bytes();lock=json.loads((O/'repository/source-lock.json').read_text())
assert inv==localinv and digest(inv)=='c5cf1352d8bcaaa36dd53d65e570ecc8e571bc3724641325521e09e54dd7b89f'
assert rec['status']=='PASS' and rec['files']==662 and rec['bytes']==312555435 and rec['archiveId']=='archive-15' and rec['archiveCommit']==SHA and rec['archiveTree']==TREE and rec['toolingCommit']==lock['toolingCommit'] and rec['expectedInventorySha256']==digest(inv) and rec['noHistoricalBuilds'] is True
assert len(rec['releases'])==1 and rec['releases'][0]['version']=='v0.57.1' and rec['releases'][0]['sourceRevision']==lock['releases'][0]['sourceRevision'] and rec['releases'][0]['tagObject']==lock['releases'][0]['tagObject'] and rec['releases'][0]['originalZipExtraction']==ziprec
assert ziprec['distributionSha256']==lock['releases'][0]['distributionSha256'] and ziprec['manifestSha256']==lock['releases'][0]['metadata']['manifest.json'] and ziprec['manifestFilesVerified']==654 and ziprec['membersVerified']==655 and ziprec['crcAndHashesVerified'] is True
main=api('git/ref/heads/main','main-ref.json');assert main['object']['sha']==SHA
list_=api('deployments?sha='+SHA+'&environment=github-pages&per_page=20','deployments.json');assert len(list_)==1;dep=list_[0];assert dep['sha']==SHA and dep['environment']=='github-pages';jdep=api('deployments/'+str(dep['id']),'deployment.json');assert dep==jdep
status=api('deployments/'+str(dep['id'])+'/statuses?per_page=100','deployment-statuses.json');assert status and status[0]['state']=='success' and status[0]['environment_url']=='https://mekhovov.github.io/revealline-archive-15/' and str(RUN) in status[0]['log_url']
pages=api('pages','pages.json');assert pages['build_type']=='workflow' and pages['html_url']=='https://mekhovov.github.io/revealline-archive-15/'
review={'status':'PASS','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual hosted archive original ZIP/member/full inventory and successful deployment authority. Public HTTP and browser admission remain separate.','repository':REPO,'infrastructureCommit':SHA,'infrastructureTree':TREE,'workflowRunId':RUN,'deploymentId':dep['id'],'environmentURL':status[0]['environment_url'],'sourceRevision':lock['releases'][0]['sourceRevision'],'sourceTree':lock['releases'][0]['sourceTree'],'tagObject':lock['releases'][0]['tagObject'],'originalReceiptArtifact':{'id':a['id'],'bytes':len(b),'sha256':digest(b),'members':members},'files':662,'bytes':312555435,'frozenManifestFiles':654,'zipMembersVerified':655,'allStepsPassed':True,'infrastructureTests':20,'extractorTests':4,'noHistoricalBuilds':True,'actualPublicHTTPComplete':False,'nativeBrowserComplete':False,'phaseAccepted':False,'pins':[pin(p) for p in sorted(H.iterdir()) if p.is_file() and p.suffix in ['.json','.log','.zip','.py'] and p.name!='review.json']}
save('review.json',(json.dumps(review,indent=2)+'\n').encode());print(json.dumps({'review':pin(H/'review.json'),'deploymentId':dep['id'],'artifactId':a['id'],'bytes':len(b),'files':662,'artifactBytes':312555435}))
