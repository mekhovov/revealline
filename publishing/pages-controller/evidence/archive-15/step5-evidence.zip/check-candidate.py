from pathlib import Path
import subprocess,hashlib,json,datetime,sys,ast,difflib,re
R=Path.cwd();O=R/'.cache/cross-mode/p01/archive15-v0571';C=O/'candidate';T=R/'.cache/cross-mode/p01/archive14-v057/repository';TC='740878b685b08edb40db5494f7ebbe71536b523a';sha=lambda b:hashlib.sha256(b).hexdigest()
pins=json.loads((O/'candidate-pins.json').read_text());steps=[]
for x in pins['candidateFiles']:
 b=(C/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
for name,argv,cwd in [('infrastructure-tests',[sys.executable,'-m','unittest','discover','-s','tools','-p','test_*.py','-v'],C),('extractor-tests',[sys.executable,'-m','unittest','discover','-s',str(O/'evidence/tooling'),'-p','test_extract_current.py','-v'],R)]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=cwd,capture_output=True,text=True);log=(r.stdout+r.stderr).encode();path=O/'evidence'/(name+'.log');path.write_bytes(log);steps.append({'name':name,'argv':argv,'cwd':str(cwd),'startedAt':start,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'log':str(path.relative_to(O)),'bytes':len(log),'sha256':sha(log)});assert r.returncode==0,(name,r.stdout,r.stderr)
for p in (C/'tools').glob('*.py'):ast.parse(p.read_text())
sys.path.insert(0,str(C/'tools'));import verify
lock,inventory=verify.locked_inputs(C);assert len(inventory['files'])==662 and sum(x['bytes'] for x in inventory['files'])==312555435
wf=(C/'.github/workflows/deploy.yml').read_text();assert wf.count("if: github.ref == 'refs/heads/main'")==2 and 'workflow_dispatch:' in wf and 'cancel-in-progress: false' in wf and 'include-hidden-files: true' in wf and 'refs/tags/v0.57.1:refs/tags/v0.57.1' in wf
assert 'archive14' not in wf and 'archive-14' not in wf and 'v0.57.0' not in wf
oldwf=subprocess.check_output(['git','-C',str(T),'show',TC+':.github/workflows/deploy.yml']).decode();assert oldwf.replace('archive 14','archive 15').replace('archive-14','archive-15').replace('archive14','archive15').replace('v0.57.0','v0.57.1')==wf
# Original extraction/verification/test sources and canonical explorer bridge are byte-identical.
unchanged=['.gitignore','tools/prepare.py','tools/verify.py','tools/test_verify.py','releases/index.html']
for p in unchanged:assert (C/p).read_bytes()==subprocess.check_output(['git','-C',str(T),'show',TC+':'+p])
diffs=[]
for x in pins['candidateFiles']:
 p=x['path'];oldp=p.replace('v0.57.1','v0.57.0');old=subprocess.check_output(['git','-C',str(T),'show',TC+':'+oldp]).decode();new=(C/p).read_text();diffs.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='archive14/'+oldp,tofile='archive15/'+p))
(O/'candidate.diff').write_text(''.join(diffs))
for x in pins['candidateFiles']:assert sha((C/x['path']).read_bytes())==x['sha256']
receipt={'scope':'Prepared exact16-file candidate, local tiny tests and static review only. No original payload downloaded/extracted, hosted/public tests or acceptance.','status':'PASS','candidatePinsSha256':sha((O/'candidate-pins.json').read_bytes()),'templateCommit':TC,'steps':steps,'syntax':{'files':4,'result':'PASS'},'lockedMetadataInventory':{'files':662,'bytes':312555435,'result':'PASS'},'unchangedOriginalTemplateFiles':unchanged,'workflowDiff':'Only reviewed archive15/v0571 names; main-only jobs, serialized noncancelled concurrency, guarded manual retry and hidden-file upload preserved.','originalMetadataAndQualification': 'Byte-identical to verified source/release originals pinned in reviewed plan.','browser':'Pending separately coordinated native evidence; known historical Library/craft defects must remain disclosed.','expectedArchiveHeadroomBytes':487444565,'mainPublisherChanges':False,'candidateDiffSha256':sha((O/'candidate.diff').read_bytes())}
(O/'prepublication-review.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'reviewSha256':sha((O/'prepublication-review.json').read_bytes()),'steps':steps,'diffBytes':(O/'candidate.diff').stat().st_size}))
