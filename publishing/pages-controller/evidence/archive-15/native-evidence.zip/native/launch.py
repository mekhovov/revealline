from pathlib import Path
import datetime,json,shutil,subprocess,time,http.client
P=Path(__file__).resolve().parent;profile=P/'profile';reserve=512*1024**2
assert not profile.exists() and not (P/'launch.json').exists()
free=shutil.disk_usage(P).free;assert free>=reserve+110*1024**2
scope={'authorization':'Parent sole foreground GO for short Archive15 native journey','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archiveCommit':'546610e6bae47f80122ee59cd69baa6546f6fe39','deploymentId':6460910463,'runId':34980491924,'version':'v0.57.1','sourceRevision':'4c85277ac7393eeeabab035387d4d4ae8734aba1','scope':['title','Deploy','ordinary keyboard capture','pause','Explorer','native Back','one portrait sample'],'phaseAccepted':False,'freeBytes':free,'reserveBytes':reserve,'startupAllowanceBytes':100*1024**2,'evidenceAllowanceBytes':10*1024**2,'noImportsOfflineOrExtraRepetitions':True}
(P/'authorization.json').write_text(json.dumps(scope,indent=2)+'\n')
args=['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','--headless=new','--remote-debugging-port=0','--enable-automation','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-features=OptimizationGuideModelDownloading,OptimizationHintsFetching,OptimizationTargetPrediction,OptimizationHints','--disable-gpu-shader-disk-cache','--disable-default-apps','--disable-sync','--enable-unsafe-swiftshader','--password-store=basic','--use-mock-keychain','--disable-quic','--disable-extensions','--disk-cache-size=16777216','--media-cache-size=8388608','--window-size=1280,800','--user-data-dir='+str(profile),'--no-proxy-server','about:blank']
p=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
def get(port,s):
 c=http.client.HTTPConnection('127.0.0.1',port,timeout=2);c.request('GET',s);r=json.loads(c.getresponse().read());c.close();return r
try:
 deadline=time.monotonic()+20
 while True:
  assert p.poll() is None
  f=profile/'DevToolsActivePort'
  if f.exists():
   port=int(f.read_text().splitlines()[0]);v=get(port,'/json/version');targets=get(port,'/json/list');pages=[t for t in targets if t['type']=='page'];assert len(pages)==1;break
  if time.monotonic()>deadline:raise RuntimeError('Owned Chrome endpoint deadline')
  time.sleep(.1)
 out={'pid':p.pid,'profile':str(profile),'arguments':args,'port':port,'endpoint':v['webSocketDebuggerUrl'],'target':pages[0]['id'],'session':'p01-archive15-v0571','version':v,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (P/'launch.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
 while p.poll() is None:
  free=shutil.disk_usage(P).free;size=sum(x.stat().st_size for x in profile.rglob('*') if x.is_file())
  with (P/'capacity.jsonl').open('a') as f:f.write(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freeBytes':free,'profileBytes':size,'pid':p.pid})+'\n')
  assert free>=reserve+64*1024**2 and size<=100*1024**2,'Capacity protective stop'
  time.sleep(2)
 (P/'exit.json').write_text(json.dumps({'pid':p.pid,'exitCode':p.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
finally:
 if p.poll() is None:
  p.terminate()
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
