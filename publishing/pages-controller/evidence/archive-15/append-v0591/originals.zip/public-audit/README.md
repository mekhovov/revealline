# Archive15 bounded public audit — prepared, not executed

Uses Archive14's retained auditor. `predecessor/` preserves both original scripts; `http-tool-adaptation.diff` records the adaptation and explicit binding gate. `transport-preservation.json` confirms identical validation, redirect, streaming and retry syntax trees except the User-Agent label. All **17 offline fixture tests pass**; no public request/audit ran.

The held candidate contains **1,343 files / 625,590,130 bytes**. All **659 earlier v0.57.1 canonical rows**, hidden metadata and the release explorer bridge remain exact. Only the shared index changes among earlier artifact rows. The candidate and predecessor inventory/source-lock originals are copied and hash-pinned under `inputs/`.

## Actual binding required before execution

`execution-request.template.json` documents the finite request. `execution-request.proposed.json` now contains the actual terminal successor IDs and seven original file pins from the publication agent, with **reviewed=false**. It names merge506a6cb97d0c5987532771520bfa30795b6fe28d, treef60feabca81ced825f7e8fbd9e03378557fe6fdd, run35187337590, deployment6496510042, success18459515021 and receipt10482787312. These are not authorization or a public result.

The owner must independently review the exact request and originals, then create `execution-request.reviewed.json` with reviewed=true. The program has no base URL or inventory override. It refuses absent/unreviewed requests, mismatched commits/trees, nonterminal/non-successful runs, wrong latest deployment status, wrong artifact ID/ZIP digest, changed local input/authority pins, or receipts that do not bind both exact release cohorts and the complete inventory. The original small ZIP is read locally with bounded members; game/source/distribution archives are not downloaded by this tool.

Readiness only, zero network requests:

```sh
python3 .cache/p05-archive15-public-audit/http-tools/http_audit.py --prepare
```

After the actual binding is reviewed, validate it locally (still zero network requests):

```sh
python3 .cache/p05-archive15-public-audit/http-tools/http_audit.py
```

Only after the owner authorizes the public audit:

```sh
python3 .cache/p05-archive15-public-audit/http-tools/http_audit.py --run --workers 6
```

The bound run streams canonical bodies through SHA256 without saving payloads: 64 KiB chunks, no redirects, strict canonical URLs/status200/size/hash/MIME/identity encoding, at most three attempts,25-second sockets,90-second per-attempt and1,800-second overall deadline,4–8 bounded workers. Every attempted request—including failures/retries—is retained. A one-byte oversize read stops a response exceeding its pin.

Each unique `http/http-*` directory retains exact input inventory, audited scripts, execution request, seven small authority originals, every result/attempt and final report. Local source/authority pins are rechecked at completion; changes fail the report. This does not perform a fresh live GitHub authority read or prove native/offline/device acceptance; the owner retains those separate steps. Never overwrite a failed run or silently widen MIME/retry policy.

No archive/source/main/index or remote state was changed by preparation. `preparation.json` pins this packet. The copied tests' three predecessor-specific preflight cases were replaced with preparation-preservation/missing-request/changed-pin guards; their14 transport cases retain the reviewed checks. No hosted-success assertion is simulated as public acceptance.
