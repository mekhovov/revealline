# Archive15 v0.59.1 append — ready for root review

Candidate is **unstaged and uncommitted** in:

`/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/p05-v060-retention-plan/archive15-worktree`

- Branch: `codex/archive15-retain-v0591`
- Base commit: `546610e6bae47f80122ee59cd69baa6546f6fe39`
- Computed candidate tree: `f60feabca81ced825f7e8fbd9e03378557fe6fdd` (calculated from reviewed file bytes; no tree object/commit created).
- Patch: `candidate.patch`, SHA256 `43f87d71ee9bb0f765eccf4a7f6a7c75af21cfc0c2ced275d7a56f0feb6c57a8`.
- All path/body hashes and preservation assertions: `candidate-review.json`.

The candidate inventory contains **1,343 files / 625,590,130 bytes**, leaving **174,409,870 bytes** below the unchanged800 MB cap. Inventory SHA256: `735f6f7083944e29dda79d5b9f264577658386d5a75f6c38978e6deeb4db2ee6`.

## Exact changed paths

Modified:

1. `.github/workflows/deploy.yml` — fetch the added immutable v0.59.1 tag as well as v0.57.1.
2. `README.md` — both editions, current derived capacity and explicit preparation scope.
3. `expected-inventory.json` — original new manifest rows plus exact metadata and revised index.
4. `index.html` — add v0.59.1 Play/ZIP/qualification links, retain existing destinations.
5. `source-lock.json` — append the actual v0.59.1 cohort and new derived inventory pin.
6. `tools/test_prepare.py` — retain v0.57.1 assertions; add actual new cohort identity and totals.

Added:

7. `input-authority-v0591.json` — actual release/tag/source/asset descriptors and prepared-only status.
8. `metadata/v0.59.1/distribution.zip.sha256`
9. `metadata/v0.59.1/manifest.json`
10. `metadata/v0.59.1/release.json`
11. `metadata/v0.59.1/source-qualification.json`

All659 old canonical v0.57.1 rows remain exact. Existing four metadata files, `input-authority.json`, the release-explorer bridge, production tools and all42 main-controller admission pins remain unchanged. Only the shared index changes among old deployed artifact rows. `archive15-originals/` retains all16 baseline source bodies. No repository instructions file was present in that finite tree.

## Checks and original authorities

- `checks/archive/{stdout.txt,stderr.txt,receipt.json}`: **20 tests passed** using tiny local fixtures.
- `checks/extractor/{stdout.txt,stderr.txt,receipt.json}`: **4 pinned synthetic extractor tests passed**.
- Existing production `locked_inputs` reconciles every derived inventory row against the exact metadata; old/current full file comparisons passed.
- `git diff --check` and reverse patch apply-check passed. The index is untouched.
- `originals/` retains bounded original Release/tag/source/archive-main API replies and attempts. The four added metadata bodies came from accepted main10df Git objects and match actual published asset IDs, sizes and SHA256 values.
- `originals/controller-admission42-verification.json` rehashes every original controller pin at main10df; it is not a new admission.

The GitHub Release API's `immutable:false` is not changed by this preparation. Original assets are digest-pinned and must be rechecked before execution; the project promise to preserve published bytes does not assert GitHub-enforced immutable releases.

## Root-owned next steps

Review the11 paths and original records before any stage/commit/push. A future actual committed tree should match the computed candidate tree unless reviewed changes intervene. Existing workflow/source helpers were not replaced. No commit, PR, merge, hosted extraction, public byte audit, native check or main selector change was performed.

After an authorized archive deployment, collect its actual successor commit/tree/run/deployment/status and small receipt artifact; perform the complete bounded public-byte audit and native v0.57.1/v0.59.1/bridge checks. Only then prepare a successor main admission. Keep all42 earlier evidence bodies; replace their current browser/http/inventory roles with reference where needed. Up to22 new pins remain within the strict64 total; use a compact original evidence package rather than deleting old history.

The cache-only `allocation-fragment.json` proposes archive15's future versions but is **not a complete valid current selector or admission**. Root must compose it with the real successor evidence and later v0.60.0 metadata. Main currently remains v0.59.1, and no future publication ID is supplied here.
