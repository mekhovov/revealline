# Archive15 append: merged and hosted deployment verified

The root-reviewed 11-file candidate was staged with exact index hashes, committed and normally merged through [PR2](https://github.com/mekhovov/revealline-archive-15/pull/2). The sole automatic main-push run completed successfully; no manual dispatch was issued.

| Identity | Actual value |
|---|---|
| Candidate commit | `08278bb9a1903a9f614f32a9e5e085cd01ee2ac0` |
| Merge commit | `506a6cb97d0c5987532771520bfa30795b6fe28d` |
| Exact reviewed/merged tree | `f60feabca81ced825f7e8fbd9e03378557fe6fdd` |
| Main workflow | [35187337590, attempt 1](https://github.com/mekhovov/revealline-archive-15/actions/runs/35187337590) |
| Deployment / successful status | `6496510042` / `18459515021` |
| Receipt artifact | `10482787312`, 70,743 bytes |
| Original receipt ZIP SHA256 | `f695c13f7fffdbdc84127457b2272986db192e11382394681b507b3a4131e8e6` |
| Derived and hosted inventory | 1,343 files / 625,590,130 bytes |
| Exact inventory SHA256 | `735f6f7083944e29dda79d5b9f264577658386d5a75f6c38978e6deeb4db2ee6` |

Candidate 11-file hashes and actual staged review are in `publication/index-review.json`; the original staged diff, commit/push/PR/guard/merge stdout, stderr and exit receipts remain in `publication/`. `hosted/completion.json` pins all retained terminal API replies, small original receipt ZIP, four exact extracted members, build/deploy logs and every retrieval attempt.

The hosted receipt binds both original game cohorts to the exact merged archive commit/tree. Both original ZIP extractions passed the existing complete integrity checks; the full generated artifact was reread. The inventory byte-for-byte equals the reviewed candidate, including all 659 earlier v0.57.1 canonical rows.

One local preparation failure is retained: initial `git add` refused the new root `input-authority-v0591.json` because it lay outside the sparse path list. The other reviewed paths were staged. Explicit `git add --sparse -- input-authority-v0591.json` completed that one path without changing its bytes; all 11 index pins and the computed tree were then verified before commit. No push, merge, hosted or download failure occurred.

**Still pending:** complete public HTTP/MIME/length/SHA audit, native old/new edition and release-explorer checks, fresh successor admission and eventual main selector composition. Those are root-owned. This hosted result does not claim public/native/offline/hardware or game-phase acceptance. Archive source checkout is clean on its candidate branch; the original game checkout and current main game selector were not edited.

Canonical routes ready for root's actual checks:

- [v0.59.1](https://mekhovov.github.io/revealline-archive-15/releases/v0.59.1/site/game/)
- [v0.57.1](https://mekhovov.github.io/revealline-archive-15/releases/v0.57.1/site/game/)
