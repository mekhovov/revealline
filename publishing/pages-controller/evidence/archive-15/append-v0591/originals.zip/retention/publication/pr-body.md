Preserve the original v0.59.1 game alongside v0.57.1 so the next current edition can retain both historical routes. Append the published metadata and qualified source identity, add archive links, and fetch both immutable tags using the existing hosted extractor.

All 659 existing canonical rows, original v0.57.1 metadata and production tools stay byte-identical. The complete derived inventory is 1,343 files / 625,590,130 bytes, within the unchanged 800 MB limit.

Validation: 20 archive fixture tests and four pinned extractor corruption tests passed; root and independent reviews checked every original metadata/body pin and inventory row. Hosted extraction, deployment and complete public/native verification follow this merge; this PR does not change the main game selector.
