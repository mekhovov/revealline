# Archive20 public byte-audit preparation

Status: terminal hosted receipt verified; public audit is **not yet authorized or executed**. Root native play remains separate.

Actual main `861182677647a1678064b64b0d46c11999a0e731`, tree `351e6b6dbfcc040dfe8ca50041dff5b4a50085a0`; held source checkout `e907e816b12f54475011ae23c3a4a406959a0857` has the same tree. Automatic push run `35269408835` succeeded, deployment `6511264098`, successful status `18493688092`. Only verification artifact `10518087424` was downloaded: 37,077 bytes, SHA-256 `9f8fc49010e9530566634cabc720149289dbc8dcc7096fb67c574168ecb570e6`. No Pages or game ZIP was downloaded.

The original three-member receipt confirms 695 files / 313,159,164 bytes, exact reviewed inventory, v0.60.5 source/tag/original distribution and no historical rebuild. Intake originals and the literal-only collector diff are in `../v0606-archive20-retention-candidate/hosted-originals/` and `intake-small-receipt.diff`. Descriptor selection was performed by the delegated agent under the parent's explicit bounded-intake authorization; it is not root approval of the public HTTP request.

`execution-request.proposed.json` pins seven actual original authorities with safe relative paths. It remains `reviewed:false`. `adaptation.diff` shows only identity, directory, inventory/count and edition substitutions from the accepted **initial** Archive19 route (`.cache/p03-archive19-public-audit`). Transport, limits, retry preservation, exact-URL/hash/MIME checks, before/after authorities and row reconciliation are unchanged. This is a fresh archive, so there are no predecessor archive rows.

Seventeen complete mocked tests passed in `checks/offline.*`; `checks/readiness.json` verifies every prepared inventory row without public requests. The held source checkout must remain at e907e816 for final binding validation.

Root's next steps after reviewing the actual request and originals:

1. Preserve the proposal and create a separate `execution-request.reviewed.json` with `reviewed:true`; retain a `root-review.json`.
2. Replace the exact `UNBOUND_ROOT_REVIEWED_REQUEST_SHA256` literal in `run-reviewed-operations.py` and `reconcile-completed-rows.py` with the reviewed file SHA-256, retaining these preparation bodies/diff first.
3. Validate without HTTP: `python3 -B -c "import sys; sys.path.insert(0, '.cache/v0606-archive20-public-audit/http-tools'); from audit_binding import validate_execution_binding; b=validate_execution_binding(); print(b['requestSha256'],len(b['rows']))"`.
4. After explicit authorization run once: `python3 -B .cache/v0606-archive20-public-audit/run-reviewed-operations.py` (before → all 695 bodies, six workers → after). All output is exclusive and failure-retaining; payload bodies are streamed and not persisted.
5. If the full audit and both authority snapshots pass, run `python3 -B .cache/v0606-archive20-public-audit/reconcile-completed-rows.py` once. Do not infer native acceptance from byte results.

No main publisher selector/admission/source files or remote settings changed by this preparation.
