# Archive23 v0.61.2 verification preparation

This cache-only adapter is ready for actual deployment metadata and root review. It does not authorize a receipt download or a public audit. The candidate tree is `408f2baf1f673ae3f8a12399290740636ed0d363`; root committed source `15b49e4edc505ba6944859092033dff271c6639a`.

The expected site contains 1,393 files and 626,679,348 bytes. All 697 previously accepted non-index rows remain exact; only the archive index changes, and 695 v0.61.2 rows are added. Both immutable tags must appear in the workflow fetch.

The accepted Archive23 helpers are retained with explicit extension diffs. The eight adapted helpers reuse the accepted Archive22 two-cohort implementation; AST checks confirm only declared identity constants differ from that implementation. The four receipt members are receipt.json, expected-inventory.json and the v0.61.1/v0.61.2 ZIP receipts. No distribution payload is downloaded or retained.

Local validation passed 22 HTTP fixtures, seven bounded-intake fixtures, exact inventory preparation, and the actual two-tag workflow check. These are offline checks. Actual merge, run, deployment, status and artifact identities remain unbound until original successful deployment metadata is available. The small request and full audit request require separate root review.

Public retention still requires before/after authorities, one complete byte audit, row reconciliation and the root's native journey. GitHub Pages project paths share an origin; no independent save origin is implied. The v0.61.2 results panel currently obscures the earned picture; an unobscured View picture reward remains a P07 follow-up. This work cannot close P03, P05, P08 or P18.
