from pathlib import Path, PurePosixPath
from urllib.parse import quote
from collections import Counter
import datetime,difflib,hashlib,io,json,os,shutil,subprocess,zipfile
R=Path.cwd(); P=R/'.cache/archive23-v0611-main-admission'; D=R/'.cache/archive23-v0611-public-audit'; H=R/'.cache/archive23-v0611-hosted-intake'; AP=R/'.cache/archive23-v0611-audit-preparation'; AW=R/'.cache/worktrees/archive23-v0611'; W=R/'.cache/worktrees/archive23-v0611-main-admission'
BASE='8309a4db407bc4a0d15b4aac42430385837d465c'; TREE='eb41b6a2259fe911d7a466aec783fc3a1298cdd7'; PREFIX='publishing/pages-controller/'; E='evidence/archive-23/initial-v0611/'
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1'); sha=lambda b:hashlib.sha256(b).hexdigest(); read=lambda p:json.loads(p.read_bytes()); enc=lambda o:(json.dumps(o,indent=2)+'\n').encode()
def used():return sum(f.stat().st_size for p in [P,W] if p.exists() for f in p.rglob('*') if f.is_file() and not f.is_symlink())
def guard(n):assert n>=0 and used()+n<=32*1024**2;assert shutil.disk_usage(R).free-n>=512*1024**2

def put(p,b):guard(len(b));p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b)
def dump(p,o):put(p,enc(o))
def git(path,rev=BASE,repo=R):return subprocess.check_output(['git','-C',str(repo),'show',rev+':'+path],env=ENV)
def pin(p,root=R):b=p.read_bytes();return {'path':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':sha(b)}
assert subprocess.check_output(['git','rev-parse',BASE+'^{tree}'],env=ENV,text=True).strip()==TREE
row=read(D/'row-review.json'); acc=read(D/'root-acceptance.json');native=read(D/'native-root.json');inv=read(D/'inputs/expected-inventory.json'); req=read(D/'execution-request.reviewed.json')
assert sha((D/'root-acceptance.json').read_bytes())=='b10b03c28d3e4cea33721f6d0502f64b4452a513263301beb4af69e83e6678a7'
assert sha((D/'native-root.json').read_bytes())=='10da4968a4c09a9c0ef3a1f5ba23d17e5769c7e7db5dfefc386c44124d9554eb'
for q in row['evidencePins']+acc['evidence']:
 b=(D/q['path']).read_bytes();assert len(b)==q['bytes'] and sha(b)==q['sha256']
assert row['status']=='PASS' and acc['status']=='ROOT_ACCEPTED_IMMUTABLE_V0611_ARCHIVE_RETENTION'
reportpath=next((D/'http').glob('*/http-report.json')); rp=reportpath.parent;report=read(reportpath)
rows=[json.loads(v) for v in (rp/'http-results.jsonl').read_text().splitlines()];attempts=[json.loads(v) for v in (rp/'http-attempts.jsonl').read_text().splitlines()]
expected={r['path']:r for r in inv['files']};assert len(expected)==len(inv['files'])==len(rows)==len(attempts)==698;assert Counter(r['path'] for r in rows)==Counter(expected.keys());assert rows==attempts
# MIME allow-list is retained alongside the precise executed auditor; derive it without importing executable code.
import ast
module=ast.parse((rp/'auditor.py').read_text());mime_node=next(n for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MIMES' for t in n.targets));mimes=ast.literal_eval(mime_node.value)
for v in rows:
 e=expected[v['path']];url=inv['base']+quote(v['path'],safe='/')
 assert v['status']=='PASS' and v['attempt']==1 and v['requestStarted'] is True and v['statusCode']==200
 assert v['url']==v['finalURL']==url and v['bytes']==v['expectedBytes']==e['bytes'] and v['sha256']==v['expectedSha256']==e['sha256']
 assert v['contentEncoding']=='identity' and v['contentType'].split(';')[0].strip().lower() in mimes[PurePosixPath(v['path']).suffix.lower()]
assert sum(v['bytes'] for v in rows)==row['verifiedBytes']==report['expectedBytes']==report['verifiedBytes']==acc['bytes']==313331293
assert report['failedAttempts']==report['failedFiles']==report['retriedFiles']==0 and report['skipped']==[]
for k in ['archiveCommit','archiveTree','runId','deploymentId','deploymentStatusId']:assert req[k]==row[k]==report[k]==acc[k]
a,b=[D/p for p in row['authoritySnapshots']]
assert read(a/'result.json')['at']<report['startedAt']<report['verifiedAt']<read(b/'result.json')['at']
for n in ['main','run','deployment','statuses']:assert (a/(n+'.json')).read_bytes()==(b/(n+'.json')).read_bytes()
small=H/'root-small-get-r1/artifact.original.zip';assert sha(small.read_bytes())=='ac99ada0d5f67b0c30ec4b1bdce61a502e99f9a9c0a2dcee2af08ba5331e70f5'
with zipfile.ZipFile(small) as z:
 assert z.testzip() is None and len(z.infolist())==3
 assert z.read('expected-inventory.json')==(D/'inputs/expected-inventory.json').read_bytes()
review={'status':'PASS_INDEPENDENT_RECORDED_ROW_AND_AUTHORITY_REVIEW','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceMain':BASE,'sourceTree':TREE,'files':698,'verifiedBytes':313331293,'attempts':698,'failedAttempts':0,'retries':0,'skips':0,'evidencePinsRehashed':len(row['evidencePins']),'rootAcceptancePinsRehashed':len(acc['evidence']),'allRowsAndAttemptsChecked':True,'rootReceiptZIPCRCAndExactInventory':True,'beforeAfterAuthoritiesIdentical':True,'nativeObservationOriginalRehashed':True,'scope':'Reconciliation of recorded exact public-body hashes, original descriptors, URLs and authorities; no new network or browser session. The root browser record and root acceptance are separate scoped originals.','originals':[pin(D/n) for n in ['row-review.json','root-acceptance.json','native-root.json','execution-request.reviewed.json']]}
dump(P/'independent-review.json',review)
baseb={n:git(PREFIX+n) for n in ['catalog.json','allocations.json','publication.json']}; catalog,alloc,config=[json.loads(baseb[n]) for n in ['catalog.json','allocations.json','publication.json']]
assert len(catalog['releases'])==82 and len(alloc['shards'])==len(config['admissions'])==22 and config['currentVersion']=='v0.61.1'
assert config['catalogSha256']==sha(baseb['catalog.json']) and config['allocationSha256']==sha(baseb['allocations.json'])
prior=[]
for admission in config['admissions']:
 for q in admission['evidence']:
  raw=git(PREFIX+q['path']);assert sha(raw)==q['sha256'];prior.append({'path':PREFIX+q['path'],'bytes':len(raw),'sha256':sha(raw)})
dump(P/'prior-originals-preservation.json',{'status':'PASS_EXACT_BASE_GIT_BODIES','base':BASE,'tree':TREE,'catalogRecords':82,'priorAdmissions':22,'priorAllocations':22,'originalPins':prior,'files':len(prior),'bytes':sum(v['bytes'] for v in prior),'duplicateDiskHydration':False})
selected=[PREFIX+n for n in ['catalog.json','allocations.json','publication.json','assemble.mjs','catalog.mjs','metadata.mjs','evidence/current-v0611/source-qualification.json']]+['scripts/pages-archive.mjs','scripts/pages-current-entry.mjs']
basefiles={n:git(n) for n in selected};guard(sum(len(b) for b in basefiles.values())+2_000_000)
assert not W.exists()
subprocess.run(['git','worktree','add','--no-checkout','-b','codex/archive23-v0611-admission',str(W),BASE],check=True,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
subprocess.run(['git','-C',str(W),'config','core.sparseCheckout','true'],check=True,env=ENV)
sparse=Path(subprocess.check_output(['git','-C',str(W),'rev-parse','--git-path','info/sparse-checkout'],env=ENV,text=True).strip());sparse.parent.mkdir(parents=True,exist_ok=True);sparse.write_text('\n'.join('/'+n for n in selected)+'\n')
subprocess.run(['git','-C',str(W),'read-tree','-mu','HEAD'],check=True,env=ENV)
for n,raw in basefiles.items():assert (W/n).read_bytes()==raw
for n,raw in baseb.items():put(P/'before'/n,raw)
C=W/PREFIX; ED=C/E; members={}
def add(root,relative,label):
 f=root/relative;assert f.is_file() and not f.is_symlink();raw=f.read_bytes();assert len(raw)<8_000_000;name=label+'/'+relative;assert '..' not in PurePosixPath(name).parts
 value=(raw,str(f.relative_to(R)))
 if name in members:assert members[name]==value
 else:members[name]=value
for q in row['evidencePins']:add(D,q['path'],'public-audit')
for n in ['row-review.json','root-acceptance.json','native-root.json','run-reviewed-operations.py','execution-request.proposed.json','inputs/expected-inventory.json']:add(D,n,'public-audit')
for p in sorted((D/'http-tools').glob('*.py')):add(D,p.relative_to(D).as_posix(),'public-audit')
for folder in ['terminal-r1','root-small-get-r1']:
 for f in sorted((H/folder).rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:add(H,f.relative_to(H).as_posix(),'hosted-intake')
for n in ['discovery.json','terminal-ready.json','small-receipt-request.proposed.json','collect-terminal.py']:add(H,n,'hosted-intake')
for f in sorted(AP.rglob('*')):
 if f.is_file() and '__pycache__' not in f.parts:add(AP,f.relative_to(AP).as_posix(),'audit-preparation')
for n in subprocess.check_output(['git','-C',str(AW),'ls-tree','-r','--name-only','9dcd9771049047a0aaf3651f11ab3ef07bbf058d'],text=True,env=ENV).splitlines():
 raw=git(n,'9dcd9771049047a0aaf3651f11ab3ef07bbf058d',AW);assert len(raw)<1_000_000;members['committed-archive-source/'+n]=(raw,'git:mekhovov/revealline-archive-23@9dcd9771049047a0aaf3651f11ab3ef07bbf058d:'+n)
add(P,'independent-review.json','admission-review');assert sum(len(raw) for raw,_ in members.values())<8_000_000
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,(raw,_) in sorted(members.items()):
  i=zipfile.ZipInfo(n,(2026,9,18,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,raw)
zraw=buf.getvalue()
with zipfile.ZipFile(io.BytesIO(zraw)) as z:
 assert z.testzip() is None and sorted(z.namelist())==sorted(members)
 for n,(raw,_) in members.items():assert z.read(n)==raw
put(ED/'originals.zip',zraw)
index={'format':'revealline-small-original-evidence-index.v1','files':[{'path':n,'source':src,'bytes':len(raw),'sha256':sha(raw)} for n,(raw,src) in sorted(members.items())],'bytes':sum(len(raw) for raw,_ in members.values()),'compressedBytes':len(zraw),'noGameOrSourcePayloadArchives':True,'memberBytesReopenedAndRehashed':True};dump(ED/'originals-index.json',index)
for src,n in [(D/'inputs/expected-inventory.json','expected-inventory.json'),(D/'inputs/source-lock.json','source-lock.json'),(reportpath,'http-report.json'),(D/'row-review.json','row-review.json'),(D/'root-acceptance.json','root-acceptance.json'),(D/'native-root.json','native-observation.json'),(H/'root-small-get-r1/receipt.json','hosted-completion.json'),(P/'independent-review.json','independent-review.json')]:put(ED/n,src.read_bytes())
browser={'format':'revealline-archive-browser-admission.v1','status':'PASS','reviewed':True,'archiveId':'archive-23','infrastructureCommit':acc['archiveCommit'],'deploymentId':acc['deploymentId'],'versions':['v0.61.1'],'evidence':[{'path':E+n,'sha256':sha((ED/n).read_bytes())} for n in ['root-acceptance.json','native-observation.json','originals.zip','originals-index.json']],'scope':'Exact original v0.61.1 retention under the new archive path. Root observed title entry, Continue, a real cut, Pause and explicit Resume, return to title, and Release explorer return. Complete public bytes were verified separately.','observationProvenance':'Root transcription of actual native keyboard and accessibility observations with inline screenshots; no exported browser session or saved screenshot file.','limits':['The existing game tab retained saving ownership; this does not qualify durable saves or migration.','No offline, multiplayer, audio, physical controller or touch certification.','Known v0.61.1 picker and local-connections Close focus gaps remain.','The archive path shares the GitHub Pages origin; it does not isolate saves.','No full P03, P05 or P18 phase acceptance.'],'phaseAccepted':False,'physicalDeviceAccepted':False,'durableSaveAccepted':False,'wholeGameComplete':False};dump(ED/'browser-admission.json',browser)
put(ED/'README.md',b'''# Archive 23: original v0.61.1 retention

The complete public audit passed **698 files / 313,331,293 bytes**, with **698 attempts and no failures, retries or skips**. Every result matches the exact expected path, byte count, SHA-256, final URL and accepted MIME type. Before/after deployment authorities remained unchanged. This new archive path has no predecessor canonical rows; earlier archive repositories and their admission records remain unchanged.

The deployment is bound to archive merge `b5b0be38b2d5fd2eb5c7647ab1cdf026aa49b667`, tree `0450f1ca681b595bcb06cf4f0d3a023030881821`, run `35316681141`, and deployment `6519185571` / status `18511870331`. The game remains source `a7a4e2d7090e2fe9d1843d88b63bc334b95bf61e` and release `391216363`; its original distribution and source qualification are unchanged.

Root accepted the scoped retention journey: title, Continue, Pause and explicit Resume, a real cut reaching 5.1% / 800 points with three lives, then title and Release explorer return. Saving ownership remained with another game tab. The original native observation and acceptance are retained byte for byte. These observations do not establish offline, audio, multiplayer, durable saving or physical device acceptance. Known picker and local-connections Close focus gaps remain. P03, P05 and P18 remain open.

The bounded originals ZIP preserves the hosted three-member receipt, before/after authorities, all 698 HTTP results and attempts, executed helpers, their retained preparation history, and the committed archive source. Every member was reopened and rehashed. The index records each original path, byte count and SHA-256. Public payload bodies, the source TAR and the distribution ZIP are not stored here.

The main-site change appends one allocation and admission while preserving all 82 catalog records, all 22 previous admissions and allocations, the current v0.61.1 selector, source qualification and testing routes. A hosted preview still validates the complete filesystem before the integration is merged and deployed.
''')
alloc['shards'].append({'id':'archive-23','repository':'mekhovov/revealline-archive-23','versions':['v0.61.1']})
config['admissions'].append({'id':'archive-23','infrastructureCommit':acc['archiveCommit'],'deploymentId':acc['deploymentId'],'evidence':[{'path':E+f.name,'sha256':sha(f.read_bytes()),'kind':{'http-report.json':'http','expected-inventory.json':'inventory','browser-admission.json':'browser'}.get(f.name,'reference')} for f in sorted(ED.iterdir())]})
allocraw=enc(alloc);config['allocationSha256']=sha(allocraw);configraw=enc(config);guard(len(allocraw)+len(configraw));(C/'allocations.json').write_bytes(allocraw);(C/'publication.json').write_bytes(configraw)
assert alloc['shards'][:-1]==json.loads(baseb['allocations.json'])['shards'] and config['admissions'][:-1]==json.loads(baseb['publication.json'])['admissions']
assert {k:v for k,v in config.items() if k not in ['allocationSha256','admissions']}=={k:v for k,v in json.loads(baseb['publication.json']).items() if k not in ['allocationSha256','admissions']}
assert (C/'catalog.json').read_bytes()==baseb['catalog.json']
patch=''.join(v for n in ['allocations.json','publication.json'] for v in difflib.unified_diff(baseb[n].decode().splitlines(True),(C/n).read_text().splitlines(True),fromfile='a/'+PREFIX+n,tofile='b/'+PREFIX+n));put(P/'configuration.patch',patch.encode())
dump(P/'preparation.json',{'status':'PREPARED_FOR_LOCAL_VALIDATION_ROOT_INTEGRATION_REVIEW_PENDING','base':BASE,'tree':TREE,'worktree':str(W),'catalogRecordsPreserved':82,'oldAdmissionsPreserved':22,'oldAllocationsPreserved':22,'oldEvidencePinsRehashed':len(prior),'currentVersion':'v0.61.1','currentSelectorChanged':False,'sourceQualificationChanged':False,'newEvidenceFiles':len(list(ED.iterdir())),'originalMembers':len(members),'originalBytes':index['bytes'],'originalZIPBytes':len(zraw),'managedBytes':used(),'guardBytes':32*1024**2,'reserveBytes':512*1024**2,'nativeEvidenceScope':'Root scoped retention acceptance only','noNetwork':True,'noStagingCommitPush':True})
print(json.dumps(read(P/'preparation.json'),indent=2))
