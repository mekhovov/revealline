import fs from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { validateAdmissions } from '../worktrees/archive23-v0611-main-admission/publishing/pages-controller/assemble.mjs';
import { validateMetadata, digest } from '../worktrees/archive23-v0611-main-admission/publishing/pages-controller/metadata.mjs';
const repo='/Users/oleksandr.mekhovov/work/my_projects/go_test';
const directory=repo+'/.cache/worktrees/archive23-v0611-main-admission/publishing/pages-controller';
const base='8309a4db407bc4a0d15b4aac42430385837d465c';
const bytes=await fs.readFile(directory+'/catalog.json'), lock=JSON.parse(bytes);
const config=JSON.parse(await fs.readFile(directory+'/publication.json'));
if(lock.releases.length!==82||digest(bytes)!==config.catalogSha256)throw Error('Catalog altered');
const metadata=new Map();
for(const pin of lock.releases){
 const get=name=>execFileSync('git',['show',base+':publishing/pages-controller/metadata/'+pin.version+'/'+name],{cwd:repo,env:{...process.env,GIT_NO_LAZY_FETCH:'1'},maxBuffer:8_000_000});
 metadata.set(pin.version,validateMetadata({recordBytes:get('release.json'),manifestBytes:get('manifest.json'),checksumBytes:get('distribution.zip.sha256'),pin}));
}
const slice=new Map([['v0.61.1',metadata.get('v0.61.1')]]);
const verified=await validateAdmissions({directory,configuration:config,metadata:slice,requireBrowser:true});
if(verified.qualification.sourceRevision!=='a7a4e2d7090e2fe9d1843d88b63bc334b95bf61e'||verified.qualification.sourceTree!=='8f81812d56299c2819ec083d919d9085a36d223c')throw Error('Wrong source');
if(verified.admissions.length!==1||verified.admissions[0].id!=='archive-23'||Object.keys(verified.canonicalSites).length!==0)throw Error('Current selector affected');
console.log(JSON.stringify({status:'PASS_CURRENT_SOURCE_AND_NEW_RETENTION_ADMISSION',catalogRecords:82,exactBaseMetadataChainsVerified:metadata.size,validatedArchiveIds:verified.admissions.map(a=>a.id),currentVersion:config.currentVersion,currentCanonicalSites:verified.canonicalSites,source:verified.qualification.sourceRevision,scope:'New archive23 evidence checked through unchanged real validator; all 613 prior evidence pins rehashed directly from exact base Git. Full filesystem hosted preview remains required.'},null,2));
