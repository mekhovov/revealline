# RevealLine archive 23

Retain the exact published v0.61.1 media-controls release while a separately qualified later edition becomes current. The original source is `a7a4e2d7090e2fe9d1843d88b63bc334b95bf61e` and its original source qualification has SHA-256 `ce94e595f0aa579fa5f64df57795cf49a8bc1404e71c2e861d4900ccc3347fb1`. Existing picker and host-focus findings remain part of that release; this archive changes no game code.

This candidate expects **698 files / 313,331,293 bytes**, with **486,668,707 bytes** remaining under the unchanged 800,000,000-byte archive cap. Archive22 already retains v0.60.9 and v0.61.0 in 626,457,828 bytes; adding this cohort would exceed its cap. Archive22 and all earlier historical paths remain unchanged.

## Publication procedure

Root must independently review the sixteen candidate files and exact source/tag/release/asset pins. Create a README-only public repository seed, record its actual commit, then adopt these bodies on a codex branch and create/merge its reviewed source PR. Do not transplant Archive22 history. Configure Actions Pages and a main-only github-pages environment before merging. Preserve contents-read and deploy-only Pages/id-token permissions, main-only jobs, and non-cancelling concurrency. The single merge push starts deployment; do not also manually dispatch.

Hosted preparation uses the unchanged pinned a13ab970 extractor, requires 3 GiB free, fetches every source-lock tag explicitly, verifies annotated tag/source identity, checks the original ZIP and every manifest member, and keeps bounded extraction receipts. The 800 MB/20,000-file limits remain. Never rebuild an archived game or overwrite an existing release. Small local fixture checks and declared tag-fetch coverage do not establish hosted/public success.

After the actual run, retain source/tree/run/attempt/jobs/deployment/status and exact small artifact descriptors. Verify all expected public bytes with fresh before/after authority, then separately exercise title, real play, Pause/Resume and Release explorer back to the main catalog. New archive23 has no prior canonical rows; do not claim a predecessor-byte comparison under this new archive path. Pages project paths share the github.io origin, so save migration or isolation is not inferred.

Only after archive retention acceptance may the separately reviewed next-main selector move v0.61.1 ownership from current-main to archive23. Preserve all 82 existing catalog records and all 22 earlier allocation/admission records exactly. This proposal includes no current selector edit or archive admission and is independent of unverified v0.61.2 Team win acceptance. Physical controls, offline recovery, audible playback and complete P03/P05 phase acceptance remain separate.
