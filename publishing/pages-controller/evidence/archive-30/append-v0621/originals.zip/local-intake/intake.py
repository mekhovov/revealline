"""One explicit reviewed receipt-only GET; preserve failures without URL/credential output."""
from pathlib import Path
import datetime,hashlib,json,os,selectors,subprocess,sys,time
from contract import ROOT,sha,guard,authority,extract_zip

def main(args):
    if len(args)!=1: raise ValueError('One reviewed request SHA required')
    q,originals,raw=authority(args[0]);guard(8*1024**2+32*1024**2+65536)
    out=ROOT/'intake';out.mkdir(exist_ok=False);(out/'request.original.json').write_bytes(raw)
    endpoint='repos/mekhovov/revealline/actions/artifacts/'+str(q['artifact']['id'])+'/zip';cmd=['gh','api','--method','GET',endpoint]
    artifact=out/'evidence-original.zip';errfile=out/'transport.stderr';start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();proc=None;failure=None;selector=selectors.DefaultSelector();counts={'out':0,'err':0}
    with artifact.open('xb') as stdout,os.fdopen(os.open(errfile,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600),'wb') as stderr:
        targets={'out':stdout,'err':stderr};caps={'out':q['artifact']['bytes'],'err':100000}
        try:
            proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            for name,pipe in [('out',proc.stdout),('err',proc.stderr)]:os.set_blocking(pipe.fileno(),False);selector.register(pipe,selectors.EVENT_READ,name)
            while selector.get_map():
                remaining=60-(time.monotonic()-start)
                if remaining<=0: raise TimeoutError('Artifact deadline')
                for key,_ in selector.select(min(.25,remaining)):
                    block=os.read(key.fileobj.fileno(),65536)
                    if not block:selector.unregister(key.fileobj);continue
                    name=key.data;counts[name]+=len(block);kept=block[:max(0,caps[name]-(counts[name]-len(block)))];guard(len(kept));targets[name].write(kept)
                    if counts[name]>caps[name]:raise ValueError('Artifact stream exceeded exact cap')
            proc.wait(timeout=max(.001,60-(time.monotonic()-start)))
            if proc.returncode!=0:raise RuntimeError('Artifact transport failed')
        except (Exception,KeyboardInterrupt) as exc:failure=type(exc).__name__
        finally:
            if proc is not None and proc.poll() is None:proc.kill();proc.wait(timeout=5)
            selector.close()
            if proc is not None:proc.stdout.close();proc.stderr.close()
    body=artifact.read_bytes();receipt={'status':'FAILED_ATTEMPT' if failure else 'RESPONSE_CAPTURED_NOT_YET_ADMITTED','startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exitCode':None if proc is None else proc.returncode,'failureType':failure,'observedBytes':counts['out'],'retainedBytes':len(body),'retainedSha256':sha(body),'stderrBytes':errfile.stat().st_size,'stderrSha256':sha(errfile.read_bytes()),'automaticRetry':False,'reviewedRequestSha256':args[0],'rawStderrPrinted':False};(out/'attempt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    if failure or len(body)!=q['artifact']['bytes'] or sha(body)!=q['artifact']['sha256']:raise ValueError('Receipt GET failed/incomplete; originals retained, no retry')
    members=extract_zip(artifact,out/'evidence');result={'status':'OUTER_ARTIFACT_RECEIVED_NOT_PUBLIC_ACCEPTANCE','runId':q['runId'],'jobId':q['jobId'],'artifact':q['artifact'],'members':len(members),'expandedBytes':sum(r['bytes'] for r in members),'publicAccepted':False};(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));return 0
if __name__=='__main__':
    try:raise SystemExit(main(sys.argv[1:]))
    except Exception as exc:print(type(exc).__name__+': receipt intake failed; inspect retained safe receipts',file=sys.stderr);raise SystemExit(1)
