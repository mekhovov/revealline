from pathlib import Path,PurePosixPath
import hashlib,json,re,stat,zipfile,shutil
ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def strict(raw):
    def pairs(items):
        result={}
        for k,v in items:
            if k in result: raise ValueError('Duplicate JSON key')
            result[k]=v
        return result
    return json.loads(raw,object_pairs_hook=pairs)
def safe_name(value):
    if not isinstance(value,str) or not value or len(value)>1024 or value.startswith('/') or re.search(r'[\\\x00-\x1f\x7f:%?#]',value) or any(x in ('','.','..') for x in value.split('/')): raise ValueError('Unsafe retained path')
    return value
def bounded(path,limit):
    if any(p.is_symlink() for p in [path,*path.parents]) or not path.is_file() or path.stat().st_size>limit: raise ValueError('Invalid bounded original')
    b=path.read_bytes()
    if len(b)>limit: raise ValueError('Original grew past bound')
    return b
def guard(extra=0):
    if sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())+extra>50331648 or shutil.disk_usage(ROOT).free<536870912+extra+65536: raise ValueError('Intake capacity guard')
def authority(expected_sha):
    raw=bounded(ROOT/'request.reviewed.json',65536)
    if sha(raw)!=expected_sha: raise ValueError('Reviewed request hash mismatch')
    q=strict(raw)
    if q['format']!='revealline-archive30-hosted-receipt-intake.v1' or q['reviewed'] is not True or q['repository']!='mekhovov/revealline' or q['utilityCommit']!='4dd68d07c5c984e78336b21a694a4e245d0934e9' or q['utilityTree']!='e4f67d5d786f0882c9d481a69781418e9ae18319' or q['branch']!='codex/archive30-v0621-http-audit': raise ValueError('Wrong utility authority')
    for k in ['runId','runAttempt','jobId']:
        if type(q[k]) is not int or q[k]<=0: raise ValueError('Actual hosted identity required')
    a=q['artifact']
    if type(a['id']) is not int or a['id']<=0 or type(a['bytes']) is not int or not 0<a['bytes']<=8388608 or not re.fullmatch('[a-f0-9]{64}',a['sha256'] or '') or a['name']!='archive30-public-byte-audit-evidence': raise ValueError('Small artifact required')
    if q['limits']!={'zipBytes':8388608,'expandedBytes':33554432,'managedBytes':50331648,'freeReserveBytes':536870912,'members':4096} or q['expectedFiles']!=1408 or q['expectedBytes']!=627086405: raise ValueError('Bounds changed')
    if set(q['originalPins'])!={'run','jobs','artifacts','utilityReview'}: raise ValueError('Missing original roles')
    originals={}
    for role,pin in q['originalPins'].items():
        path=ROOT/safe_name(pin['path']);b=bounded(path,2000000)
        if len(b)!=pin['bytes'] or sha(b)!=pin['sha256']: raise ValueError('Original pin changed')
        originals[role]=strict(b)
    r=originals['run'];c=originals['utilityReview'];jobs=originals['jobs'];arts=originals['artifacts']
    if c['status']!='ROOT_REVIEWED_READONLY_HOSTED_PUBLIC_AUDIT' or c['utilityCommit']!=q['utilityCommit'] or c['utilityTree']!=q['utilityTree'] or r['id']!=q['runId'] or r['head_sha']!=q['utilityCommit'] or r['head_commit']['tree_id']!=q['utilityTree'] or r['head_branch']!=q['branch'] or r['event']!='workflow_dispatch' or r['path']!='.github/workflows/qualify-release-source.yml' or r['run_attempt']!=q['runAttempt'] or r['status']!='completed': raise ValueError('Run/utility mismatch')
    if jobs['total_count']!=len(jobs['jobs']) or len(jobs['jobs'])!=1: raise ValueError('Unexpected jobs')
    job=jobs['jobs'][0]
    if job['id']!=q['jobId'] or job['name']!='audit' or job['run_id']!=q['runId'] or job['head_sha']!=q['utilityCommit'] or job['run_attempt']!=q['runAttempt'] or job['status']!='completed': raise ValueError('Job mismatch')
    if arts['total_count']!=len(arts['artifacts']): raise ValueError('Incomplete artifacts')
    found=[v for v in arts['artifacts'] if v['id']==a['id']]
    if len(found)!=1: raise ValueError('Artifact missing or duplicate')
    v=found[0]
    if v['name']!=a['name'] or v['expired'] or v['size_in_bytes']!=a['bytes'] or v['digest']!='sha256:'+a['sha256'] or v['workflow_run']['id']!=q['runId'] or v['workflow_run']['head_sha']!=q['utilityCommit']: raise ValueError('Artifact mismatch')
    return q,originals,raw

def extract_zip(path,destination):
    if destination.exists(): raise ValueError('Fresh extraction directory required')
    with zipfile.ZipFile(path) as z:
        infos=z.infolist();names=[i.filename for i in infos]
        if len(infos)>4096 or len(names)!=len(set(names)) or sum(i.file_size for i in infos)>33554432: raise ValueError('Archive inventory bound')
        for i in infos:
            safe_name(i.filename.rstrip('/') if i.is_dir() else i.filename)
            mode=stat.S_IFMT(i.external_attr>>16)
            if i.flag_bits&1 or mode not in (0,stat.S_IFREG,stat.S_IFDIR) or (mode==stat.S_IFDIR)!=i.is_dir() and mode!=0: raise ValueError('Archive member type')
        guard(sum(i.file_size for i in infos));destination.mkdir()
        for i in infos:
            p=destination/i.filename
            if i.is_dir():p.mkdir(parents=True,exist_ok=True);continue
            p.parent.mkdir(parents=True,exist_ok=True);body=z.read(i)
            if len(body)!=i.file_size: raise ValueError('Member size mismatch')
            with p.open('xb') as f:f.write(body)
        return [{'path':i.filename,'bytes':i.file_size} for i in infos if not i.is_dir()]
