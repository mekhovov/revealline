"""Independent local reconciliation of the original hosted artifact. No network or Git."""
from pathlib import Path,PurePosixPath
from collections import Counter,defaultdict
from urllib.parse import quote
import ast,datetime,json,sys
from contract import ROOT,sha,strict,authority,safe_name,bounded

def main(args):
    if len(args)!=1:raise ValueError('Reviewed request SHA required')
    q,originals,raw=authority(args[0]);D=ROOT/'intake/evidence';zipbody=bounded(ROOT/'intake/evidence-original.zip',8388608)
    assert len(zipbody)==q['artifact']['bytes'] and sha(zipbody)==q['artifact']['sha256']
    assert originals['run']['conclusion']=='success' and originals['jobs']['jobs'][0]['conclusion']=='success'
    read=lambda p:strict(bounded(p,33554432));host=read(D/'hosted-result.json');assert host['status']=='PASS_HTTP_ROWS_ONLY' and host['sourceUnchanged'] is True and not host['nativeAcceptance'] and not host['releaseAcceptance'] and not host['publicAdmission']
    assert [r['name'] for r in host['steps']]==['binding','audit','reconcile'] and all(r['exitCode']==0 and r['timedOut'] is False for r in host['steps'])
    identity=read(D/'hosted-identity.json');assert identity['utilityWorkflowSha']==q['utilityCommit'] and identity['hostedRunId']==str(q['runId']) and identity['hostedRunAttempt']==str(q['runAttempt']) and identity['archiveCommit']=='cf9113746d96cf50d7cb8491d58dece53bd9cc60' and identity['archiveTree']=='c3baca75f63c6e886b6cfa3a0f7a81f3da0d4188'
    assert (D/'utility-runner.py').read_bytes()==(ROOT/'expected/hosted_run.py').read_bytes()
    assert (D/'payload-pins.original.json').read_bytes()==(ROOT/'expected/payload-pins.json').read_bytes()
    for row in read(ROOT/'expected/payload-pins.json'):
        body=bounded(D/safe_name(row['path']),33554432);assert len(body)==row['bytes'] and sha(body)==row['sha256']
    dispatch=read(ROOT/'expected/dispatch-request.json');assert read(D/'dispatch-binding.original.json')==strict(dispatch['inputs']['archive_binding'])
    H=D/'http';reqraw=(H/'execution-request.reviewed.json').read_bytes();assert reqraw==(ROOT/'expected/execution-request.json').read_bytes();req=strict(reqraw);assert sha(reqraw)=='ac0b16f2172689be950595641ea9156963ba003c017b96711ff67dd833130b36'
    reports=list((H/'http').glob('*/http-report.json'));assert len(reports)==1;folder=reports[0].parent;report=read(reports[0]);invraw=(folder/'expected-inventory.json').read_bytes();assert invraw==(ROOT/'expected/inventory.json').read_bytes();inv=strict(invraw)['files'];expected={r['path']:r for r in inv}
    rows=[strict(s) for s in (folder/'http-results.jsonl').read_text().splitlines()];attempts=[strict(s) for s in (folder/'http-attempts.jsonl').read_text().splitlines()]
    assert report['status']=='PASS' and len(expected)==len(inv)==len(rows)==705 and Counter(r['path'] for r in rows)==Counter(r['path'] for r in inv)
    tree=ast.parse((ROOT/'expected/http_audit.py').read_bytes());MIMES=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MIMES' for t in n.targets))
    groups=defaultdict(list)
    for r in attempts:assert r['path'] in expected;groups[r['path']].append(r)
    for r in rows:
        e=expected[r['path']];g=groups[r['path']];url='https://mekhovov.github.io/revealline-archive-30/'+quote(r['path'],safe='/');assert 1<=len(g)<=3 and [v['attempt'] for v in g]==list(range(1,len(g)+1)) and r==g[-1]
        assert r['status']=='PASS' and r['statusCode']==200 and r['requestStarted'] is True and r['url']==r['finalURL']==url and r['bytes']==r['expectedBytes']==e['bytes'] and r['sha256']==r['expectedSha256']==e['sha256'];assert r['contentType'].split(';')[0].strip().lower() in MIMES[PurePosixPath(r['path']).suffix.lower()]
    assert sum(r['bytes'] for r in rows)==report['verifiedBytes']==report['expectedBytes']==313563420 and report['attempts']==len(attempts) and report['failedAttempts']==sum(r['status']!='PASS' for r in attempts) and report['retriedFiles']==sum(len(v)>1 for v in groups.values()) and not report['failedFiles'] and not report['skipped'] and report['sourcePinsUnchanged'] and report['allFinalURLsExact']
    assert report['workers']==6 and report['maxAttemptsPerFile']==3 and report['socketTimeoutSeconds']==25 and report['attemptDeadlineSeconds']==90 and report['auditDeadlineSeconds']==1800
    assert report['priorInventoryRows']==report['preservedOldCanonicalRows']==report['preservedPriorReleaseRows']==report['preservedRootSupportRows']==0 and report['newRows']==705 and report['newBytes']==313563420 and report['preservedRootSupportPaths']==report['changedPriorPaths']==[]
    for key in ['archiveCommit','archiveTree','sourceCheckoutCommit','runId','deploymentId','deploymentStatusId','receiptArtifactId']:assert report[key]==req[key]
    assert report['executionRequestSha256']==sha(reqraw) and (folder/'execution-request.json').read_bytes()==reqraw and (folder/'auditor.py').read_bytes()==(H/'http-tools/http_audit.py').read_bytes() and (folder/'audit_binding.py').read_bytes()==(H/'http-tools/audit_binding.py').read_bytes()
    for role,pin in req['pins'].items():
        body=bounded(D/'intake'/safe_name(pin['path']),33554432);assert len(body)==pin['bytes'] and sha(body)==pin['sha256'];assert (folder/'authority-originals'/(role+('.zip' if role=='receiptZIP' else '.json'))).read_bytes()==body
    obs=[]
    for stage in ['before','after']:
        found=list((H/'live-authorities').glob(stage+'-*/result.json'));assert len(found)==1;v=read(found[0]);assert v['status']=='PASS_LIVE_IDENTITIES_UNCHANGED' and not v['errors'] and v['executionRequestSha256']==sha(reqraw)
        for pin in v['pins']:
            body=bounded(found[0].parent/safe_name(pin['path']),2000000);assert len(body)==pin['bytes'] and sha(body)==pin['sha256']
        for key in ['archiveCommit','runId','deploymentId','deploymentStatusId']:assert v[key]==req[key]
        obs.append(found[0].parent)
    assert read(obs[0]/'result.json')['at']<report['startedAt']<report['verifiedAt']<read(obs[1]/'result.json')['at']
    for n in ['main','run','deployment','statuses']:assert (obs[0]/(n+'.json')).read_bytes()==(obs[1]/(n+'.json')).read_bytes()
    current=read(obs[1]/'main.json');run=read(obs[1]/'run.json');dep=read(obs[1]/'deployment.json');status=max(read(obs[1]/'statuses.json'),key=lambda x:x['id']);assert current['object']['sha']==req['archiveCommit'] and run['id']==req['runId'] and run['head_sha']==req['archiveCommit'] and run['status']=='completed' and run['conclusion']=='success' and dep['id']==req['deploymentId'] and dep['sha']==req['archiveCommit'] and status['id']==req['deploymentStatusId'] and status['state']=='success' and status['environment_url']=='https://mekhovov.github.io/revealline-archive-30/'
    proof=read(H/'row-review.json');assert proof['status']=='PASS' and proof['files']==705 and proof['verifiedBytes']==313563420 and proof['attempts']==len(attempts) and proof['allExpectedPathsExactlyOnce'] and proof['beforeAfterOriginalAPIBodiesUnchanged'] and not proof['browserAccepted'] and not proof['phaseAccepted']
    for pin in proof['evidencePins']:
        body=bounded(H/safe_name(pin['path']),33554432);assert len(body)==pin['bytes'] and sha(body)==pin['sha256']
    for stage in ['before','audit','after']:
        r=read(H/'execution-originals'/(stage+'.receipt.json'));assert r['exitCode']==0 and not r['timedOut']
    result={'status':'PASS_INDEPENDENT_HOSTED_HTTP_RECEIPT_RECONCILIATION','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'utilityCommit':q['utilityCommit'],'utilityTree':q['utilityTree'],'hostedRunId':q['runId'],'hostedArtifact':q['artifact'],'files':705,'verifiedBytes':313563420,'attempts':len(attempts),'failedAttempts':report['failedAttempts'],'retries':len(attempts)-705,'priorRows':0,'allPathsExactlyOnce':True,'allOriginalsAndHelperPinsMatch':True,'beforeAfterArchiveAuthoritiesUnchanged':True,'reviewedRequestSha256':args[0],'nativeAcceptance':False,'publicAdmission':False,'scope':'Independent receipt-only review. Root must combine actual native evidence and final authority refresh before admission.'}
    with (ROOT/'independent-review.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result));return 0
if __name__=='__main__':
    try:raise SystemExit(main(sys.argv[1:]))
    except Exception as exc:print(type(exc).__name__+': hosted receipt reconciliation failed; no admission',file=sys.stderr);raise SystemExit(1)
