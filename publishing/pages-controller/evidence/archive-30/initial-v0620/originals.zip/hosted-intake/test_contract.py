from pathlib import Path
import hashlib,json,shutil,stat,tempfile,unittest,zipfile
from unittest.mock import patch
import contract
HERE=Path(__file__).resolve().parent
class ReceiptContractTests(unittest.TestCase):
    def test_actual_original_authority_matches_only_reviewed_request(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td).resolve();shutil.copytree(HERE/'originals',root/'originals');q=json.loads((HERE/'request.proposed.json').read_bytes());q['reviewed']=True;raw=(json.dumps(q,indent=2)+'\n').encode();(root/'request.reviewed.json').write_bytes(raw)
            with patch.object(contract,'ROOT',root):
                accepted,originals,_=contract.authority(contract.sha(raw));self.assertEqual(accepted['artifact']['id'],10578498415);self.assertEqual(originals['run']['head_sha'],q['utilityCommit'])
                with self.assertRaises(ValueError):contract.authority('0'*64)
                q['artifact']['bytes']+=1;raw=(json.dumps(q,indent=2)+'\n').encode();(root/'request.reviewed.json').write_bytes(raw)
                with self.assertRaises(ValueError):contract.authority(contract.sha(raw))
    def test_unsafe_paths_rejected(self):
        for v in ['../x','/x','a//b','a/../b','a\\b','a?b','a:b','a%20b']:
            with self.subTest(v=v),self.assertRaises(ValueError):contract.safe_name(v)
    def test_duplicate_json_rejected(self):
        with self.assertRaises(ValueError):contract.strict('{"id":1,"id":2}')
    def test_safe_zip_extracts_exact_bytes(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td).resolve();z=root/'x.zip'
            with zipfile.ZipFile(z,'w') as f:f.writestr('a/b.json',b'{}')
            with patch.object(contract,'ROOT',root):rows=contract.extract_zip(z,root/'out')
            self.assertEqual(rows,[{'path':'a/b.json','bytes':2}]);self.assertEqual((root/'out/a/b.json').read_bytes(),b'{}')
    def test_traversal_zip_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td).resolve();z=root/'x.zip'
            with zipfile.ZipFile(z,'w') as f:f.writestr('../escape',b'x')
            with self.assertRaises(ValueError):contract.extract_zip(z,root/'out')
            self.assertFalse((root/'out').exists())
    def test_symlink_zip_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td).resolve();z=root/'x.zip';i=zipfile.ZipInfo('link');i.external_attr=(stat.S_IFLNK|0o777)<<16
            with zipfile.ZipFile(z,'w') as f:f.writestr(i,b'target')
            with self.assertRaises(ValueError):contract.extract_zip(z,root/'out')
    def test_changed_original_refuses(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td).resolve();shutil.copytree(HERE/'originals',root/'originals');q=json.loads((HERE/'request.proposed.json').read_bytes());q['reviewed']=True;raw=(json.dumps(q,indent=2)+'\n').encode();(root/'request.reviewed.json').write_bytes(raw);(root/'originals/run.json').write_bytes(b'{}')
            with patch.object(contract,'ROOT',root),self.assertRaises(ValueError):contract.authority(contract.sha(raw))
if __name__=='__main__':unittest.main()
