from pathlib import Path
import subprocess,json,hashlib,datetime,zipfile,stat
P=Path(__file__).resolve().parent;B=P/'small-receipt-request.authorized.json';raw=B.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(raw)=='7b4ebfe2f47d35cb7ff509554e5bf65de31142c0006d3e41518c49aab28b62ac';req=json.loads(raw);assert req['reviewed'] is True
for pin in req['originalPins']:
 b=(P/pin['path']).read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256']
O=P/'hosted-originals';O.mkdir(exist_ok=False);(O/'reviewed-download-request.json').write_bytes(raw);cmd=['gh','api',req['apiEndpoint']];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
# Same bounded, timeout-protected small-artifact call as the reviewed Archive03 collector.
timed=False
try:r=subprocess.run(cmd,capture_output=True,timeout=45);stdout,stderr,code=r.stdout,r.stderr,r.returncode
except subprocess.TimeoutExpired as e:stdout,stderr,code=e.output or b'',e.stderr or b'',None;timed=True
attempt={'argv':cmd,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code,'timedOut':timed,'receivedBytes':len(stdout),'maxAcceptedBytesExclusive':req['maxDownloadBytes'],'bindingSha256':sha(raw)}
(O/'download.attempt.json').write_text(json.dumps(attempt,indent=2)+'\n');(O/'download.stderr').write_bytes(stderr[:1999999]);(O/'download.exit').write_text(str(code)+'\n')
if timed or code!=0 or len(stdout)>=req['maxDownloadBytes']:
 (O/'download.partial').write_bytes(stdout[:req['maxDownloadBytes']-1]);raise RuntimeError('Small receipt GET failed; preserved bounded partial; no retry')
zip_path=P/req['outputRelativeToRetentionRoot'];zip_path.write_bytes(stdout);assert len(stdout)==req['artifactBytes'] and sha(stdout)==req['artifactSha256']
E=O/'receipts';E.mkdir();expected=set(req['expectedMembers'])
with zipfile.ZipFile(zip_path) as z:
 infos=z.infolist();assert len(infos)==len(expected) and {i.filename for i in infos}==expected;assert sum(i.file_size for i in infos)<=req['maxUncompressedBytes']
 for i in infos:assert not i.is_dir() and not i.flag_bits&1 and stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG) and i.file_size<=req['maxMemberBytes']
 assert z.testzip() is None
 for i in infos:
  body=z.read(i);assert len(body)==i.file_size;(E/i.filename).write_bytes(body)
invraw=(E/'expected-inventory.json').read_bytes();inv=json.loads(invraw);lock=json.loads((P/'candidate/source-lock.json').read_bytes());receipt=json.loads((E/'receipt.json').read_bytes());assert invraw==(P/'candidate/expected-inventory.json').read_bytes();assert sha(invraw)==req['inventorySha256'];assert len(inv['files'])==req['expectedFiles'] and sum(r['bytes'] for r in inv['files'])==req['expectedBytes']
assert receipt['status']=='PASS' and receipt['archiveId']=='archive-21' and receipt['archiveCommit']==req['archiveCommit'] and receipt['archiveTree']==req['archiveTree'] and receipt['files']==req['expectedFiles'] and receipt['bytes']==req['expectedBytes'] and receipt['expectedInventorySha256']==req['inventorySha256'] and receipt['noHistoricalBuilds'] is True and receipt['toolingCommit']==lock['toolingCommit'];assert len(receipt['releases'])==len(lock['releases'])==2
for expected in lock['releases']:
 rr=[r for r in receipt['releases'] if r['version']==expected['version']];assert len(rr)==1;rr=rr[0];z=json.loads((E/('zip-receipt-'+expected['version']+'.json')).read_bytes());assert rr['sourceRevision']==expected['sourceRevision'] and rr['tagObject']==expected['tagObject'] and rr['originalZipExtraction']==z;assert z['version']==expected['version'] and z['gameSourceRevision']==expected['sourceRevision'] and z['distributionSha256']==expected['distributionSha256'] and z['manifestSha256']==expected['metadata']['manifest.json'] and z['crcAndHashesVerified'] is True
pins=[]
for p in sorted(O.rglob('*')):
 if p.is_file():b=p.read_bytes();pins.append({'path':p.relative_to(P).as_posix(),'bytes':len(b),'sha256':sha(b)})
result={'status':'ORIGINAL_SMALL_RECEIPT_VALIDATED_NO_PUBLIC_AUDIT','archiveCommit':req['archiveCommit'],'archiveTree':req['archiveTree'],'runId':req['runId'],'deploymentId':req['deploymentId'],'deploymentStatusId':req['deploymentStatusId'],'receiptArtifactId':req['artifactId'],'receiptBytes':len(stdout),'receiptSha256':sha(stdout),'files':len(inv['files']),'bytes':sum(r['bytes'] for r in inv['files']),'inventorySha256':sha(invraw),'crcAndExactFourMembersPassed':True,'exactCandidateInventoryAndSourceChainPassed':True,'pins':pins,'publicByteAcceptance':False,'nativeAcceptanceNotAltered':True};(O/'completion.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='pins'},indent=2))
D=P.parent/'v0609-archive21-append-public-audit';proposal=json.loads((D/'execution-request.pending.json').read_bytes());assert proposal['reviewed'] is False;proposal.update(deploymentId=req['deploymentId'],deploymentStatusId=req['deploymentStatusId'],receiptArtifactId=req['artifactId'])
for role in proposal['pins']:
 path=zip_path if role=='receiptZIP' else P/'hosted-observation-initial'/(('wrapper' if role=='commit' else role)+'.json');b=path.read_bytes();proposal['pins'][role]={'path':path.relative_to(P).as_posix(),'bytes':len(b),'sha256':sha(b)}
p=D/'execution-request.proposed.json';assert not p.exists();p.write_text(json.dumps(proposal,indent=2)+'\n');print('execution proposal sha',sha(p.read_bytes()))
