"""Additional offline checks for Archive21's one reviewed root-index replacement."""
import copy
import hashlib
import json
from pathlib import Path
import unittest
from unittest.mock import patch
import audit_binding as binding

class AppendPreservationTests(unittest.TestCase):
    def setUp(self):
        self.current_path=binding.ROOT/'inputs/expected-inventory.json'
        self.original=binding.local_bytes
        self.current=json.loads(self.original(self.current_path))

    def mutated(self, callback):
        value=copy.deepcopy(self.current);callback(value['files'])
        raw=(json.dumps(value,indent=2)+'\n').encode()
        def held(path,*args):
            return raw if path==self.current_path else self.original(path,*args)
        return patch.object(binding,'local_bytes',held),patch.object(binding,'INVENTORY_SHA',hashlib.sha256(raw).hexdigest())

    def test_actual_predecessor_695_canonical_and_697_all_rows_preserved(self):
        _,rows,_=binding.candidate_inventory();current={r['path']:r for r in rows}
        old=json.loads(self.original(binding.ROOT/'inputs/predecessor-inventory.json'))['files']
        self.assertEqual([r['path'] for r in old if current.get(r['path'])!=r],['index.html'])
        self.assertEqual(sum(current.get(r['path'])==r for r in old),697)
        self.assertEqual(sum(r['path'].startswith('releases/v0.60.7/') for r in old),695)

    def test_prior_body_change_refused_even_if_candidate_digest_rebound(self):
        def change(rows):
            next(r for r in rows if r['path'].startswith('releases/v0.60.7/'))['sha256']='0'*64
        a,b=self.mutated(change)
        with a,b,self.assertRaisesRegex(ValueError,'predecessor public row changed'):
            binding.candidate_inventory()

    def test_prior_path_replacement_refused_even_with_identical_size(self):
        def change(rows):
            next(r for r in rows if r['path'].startswith('releases/v0.60.7/'))['path']='releases/v0.60.7/site/rogue.json'
        a,b=self.mutated(change)
        with a,b,self.assertRaisesRegex(ValueError,'predecessor public row changed'):
            binding.candidate_inventory()

    def test_predecessor_inventory_digest_change_refused(self):
        with patch.object(binding,'OLD_SHA','0'*64),self.assertRaisesRegex(ValueError,'Predecessor inventory pin changed'):
            binding.candidate_inventory()

    def test_added_edition_prefix_change_refused(self):
        def change(rows):
            next(r for r in rows if r['path'].startswith('releases/v0.60.8/'))['path']='releases/v0.60.9/site/rogue.json'
        a,b=self.mutated(change)
        with a,b,self.assertRaisesRegex(ValueError,'Wrong added canonical cohort'):
            binding.candidate_inventory()

    def test_root_index_edit_requires_exact_prepared_inventory_pin(self):
        value=copy.deepcopy(self.current);next(r for r in value['files'] if r['path']=='index.html')['sha256']='0'*64
        raw=json.dumps(value).encode()
        with patch.object(binding,'local_bytes',lambda path,*args:raw if path==self.current_path else self.original(path,*args)),self.assertRaisesRegex(ValueError,'Prepared input pin changed'):
            binding.candidate_inventory()

if __name__=='__main__':unittest.main()
