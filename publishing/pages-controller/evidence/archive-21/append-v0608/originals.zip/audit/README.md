# Archive21 v0.60.8 append audit — prepared for root review

This cache prepares retention needed before the next main-site selection. It audits Archive21’s v0.60.7 and v0.60.8 editions; the v0609 cache label does not claim that Archive21 contains v0.60.9.

The actual merge is `44d383dbae4c1d95cf59512b21d2524e191937e6`, tree `668e425a0f4fa0dc0cf7d0376e581482c5213767`. Automatic push run **35298846214** completed successfully, with build **105456972027** and deploy **105457117776**. Deployment **6516114363**, status **18504806073**, points to the intended Archive21 site. The held exact append checkout is `ff70f75bc656addd591ac04bacc7faa19603ed90` in `.cache/worktrees/archive21-v0608`, with the same tree.

The candidate contains **1,393 files /626,433,016 bytes**. All **695 canonical v0.60.7 rows** remain byte-identical. Across the 698-row predecessor inventory, **697 rows are unchanged**; only the reviewed root `index.html` gains the second edition link. The **695 v0.60.8 rows** are new. Both the complete predecessor inventory and current inventory are pinned.

One small hosted receipt was downloaded: artifact **10529052511**, **73,296 bytes**, SHA-256 `2ae5da4df18c95ccf5461cc04f3b40ed54ae669f6e337476fd37cedb2f58045f`. Its four allowlisted members total **289,556 bytes**: complete inventory, preparation receipt and the two original-ZIP extraction receipts. CRC, exact extracted bytes, source/tag/distribution chains and candidate inventory comparison passed. The Pages artifact and game distribution bodies were not downloaded locally. Terminal APIs and originals are in `../v0609-archive21-append-observation/`.

The HTTP engine comes from the accepted Archive20 two-edition append. Six helpers retain their AST structure after literal normalization. The two explicit preservation adaptations require all 697 unchanged predecessor rows, retain 695 canonical v607 rows, and allow only the pinned root-index replacement. `fetch_once`, `check_row` and `NoRedirect` remain AST-identical after the single Archive20 → Archive21 User-Agent label change. Exact URL/size/hash/MIME verification, no redirects, six workers, 25-second socket timeout, 90-second attempt deadline, 1,800-second overall deadline and three-attempt ceiling remain unchanged. No payload files are persisted by the HTTP engine.

**23 offline tests pass**, including six explicit preservation checks. Final `--prepare` validates all 1,393 rows with zero requests. Earlier checks and two local review corrections are preserved: the inherited total-preservation display label was corrected from 695 to 697; an overly strict raw-AST assertion detected the expected User-Agent label and was narrowed to that exact literal. No transport or acceptance behavior was weakened.

`execution-request.proposed.json` is explicitly **reviewed:false**. `adapter-review.json` is the preparer’s review, not an independent-agent or root signoff; the delegated child slot was unavailable. Root must review the complete final diffs, seven original authority pins and request. A separate reviewed request and root-review record then permit replacing only `UNBOUND_ROOT_REVIEWED_REQUEST_SHA256` in the runner and reconciler. Preserve both unbound versions and the proposal.

After root review, the intended commands are:

```sh
python3 -B .cache/v0609-archive21-append-public-audit/http-tools/http_audit.py
python3 -B .cache/v0609-archive21-append-public-audit/run-reviewed-operations.py
python3 -B .cache/v0609-archive21-append-public-audit/reconcile-completed-rows.py
```

The first validates actual binding without network; the runner performs before-authorities → full streamed inventory → after-authorities; the reconciler checks every result and attempt, all preserved rows, admitted originals and unchanged authority bodies. The full public-body audit has not started. Maintain a 32 MiB cumulative evidence budget and at least 512 MiB free before these operations. Root owns actual browser play, acceptance, source commits and any publisher changes. A byte pass does not establish native input, offline, save, physical-device or whole-phase acceptance.
