# Archive14 native preservation evidence

Captured against the actual deployed immutable v0.57.0 game. The fresh named Chromium profile used normal UI inputs and read-only DOM observations. Native ArrowDown produced a real 1.5% capture and score 340; pause/resume and a single explorer Back round trip passed. The profile and caches are excluded.

Boot/bridge intermediate observations and the existing session-only history warning are retained. Portrait/landscape screenshots are observations, not full device qualification. The known v0.57.0 offline portrait defect remains in this archived original and is being corrected separately. No P01 acceptance, physical-input or new offline claim.
