from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys

R = Path.cwd()
O = R / '.cache/archive27-v06120-append-preparation'
W = O / 'candidate'
BASE = '8b5495a4a8374ef3f8020707cde2cec9c7ba8e23'
TREE = '20f5504cfc080ae58e163c37206758f1b3ba6dc2'
SOURCE = 'd51acab59232edc4e7f77ab5df491f2c403de709'
SOURCE_TREE = '1ebd48695649123c08f7092f88cafeb442f9f0d6'
TAG = 'f07889a5220722112d3b6eeb7ae97eecc60c40a5'
VERSION = 'v0.61.20'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(p.read_bytes())

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], env=ENV, timeout=30)

def pin(p):
    b = p.read_bytes()
    return {'path': str(p.relative_to(R)), 'bytes': len(b), 'sha256': sha(b)}

def put(p, body):
    assert p.is_relative_to(O) or p.is_relative_to(W)
    assert not p.is_symlink()
    used = sum(x.stat().st_size for t in [O, W] for x in t.rglob('*') if x.is_file() and not x.is_symlink())
    assert used + len(body) < 8 * 1024**2
    assert shutil.disk_usage(R).free >= 512 * 1024**2 + len(body) + 65536
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(body)

def dump(p, value):
    put(p, (json.dumps(value, indent=2) + '\n').encode())

S = R / '.cache/archive27-v0619-source'
assert git(S, 'rev-parse', 'HEAD^{tree}').decode().strip() == TREE
assert git(S, 'status', '--porcelain').strip() == b''
prior_accept_path = R / '.cache/archive27-v0619-public-audit/root-acceptance.json'
public_accept_path = R / '.cache/p03-public-audit-v06120-preparation/root-partial-public-review.json'
prior_accept, public_accept = read(prior_accept_path), read(public_accept_path)
assert prior_accept['archiveCommit'] == BASE and prior_accept['archiveTree'] == TREE
assert prior_accept['files'] == 701 and prior_accept['verifiedBytes'] == 313404982
assert public_accept['version'] == VERSION and public_accept['gameSource'] == SOURCE
assert public_accept['status'] == 'ROOT_PUBLIC_BYTES_ACCEPTED_NATIVE_PARTIAL'
assert not public_accept['phaseAcceptance'] and not public_accept['nativeAcceptance']['completePhonePresentation']
assert git(R, 'rev-parse', SOURCE + '^{tree}').decode().strip() == SOURCE_TREE
published_path = R / '.cache/v06120-release-preparation/root-publish-r1/publish.json'
latest_path = published_path.with_name('latest.json')
tag_path = published_path.with_name('tag.json')
tag_object_path = published_path.with_name('tag-object.json')
published, latest = read(published_path), read(latest_path)
assert published['id'] == latest['id'] == 391660904
assert published['tag_name'] == latest['tag_name'] == VERSION
assert not published['draft'] and not published['prerelease'] and not latest['draft']
keys = ['id', 'name', 'size', 'digest', 'state', 'browser_download_url']
descriptors = lambda r: sorted([{k: a[k] for k in keys} for a in r['assets']], key=lambda a: a['name'])
assert descriptors(published) == descriptors(latest)
after_refresh = read(R / '.cache/p03-public-audit-v06120-preparation/after-http-authorities-main-r1/release.json')
assert descriptors(published) == descriptors(after_refresh)
assets = {a['name']: a for a in published['assets']}
assert len(assets) == 9
assert read(tag_path)['object']['sha'] == read(tag_object_path)['sha'] == TAG
assert read(tag_object_path)['object']['sha'] == SOURCE
metadata = []
for name in ['release.json', 'manifest.json', 'distribution.zip.sha256', 'source-qualification.json']:
    original = R / '.cache/p03-public-audit-v06120-preparation/source-originals' / name
    body = original.read_bytes()
    asset = assets[name]
    assert len(body) == asset['size'] and 'sha256:' + sha(body) == asset['digest']
    dest = W / 'metadata' / VERSION / name
    put(dest, body)
    metadata.append({'path': str(dest.relative_to(W)), 'original': pin(original), 'assetId': asset['id']})
oldlock = read(O / 'baseline/source-lock.json')
lock = read(W / 'source-lock.json')
assert lock == oldlock and [r['version'] for r in lock['releases']] == ['v0.61.9']
cohort = {'version': VERSION, 'sourceRevision': SOURCE, 'sourceTree': SOURCE_TREE, 'tagObject': TAG,
          'distributionSha256': assets['distribution.zip']['digest'][7:], 'distributionBytes': assets['distribution.zip']['size'],
          'metadata': {n: assets[n]['digest'][7:] for n in ['release.json', 'manifest.json', 'distribution.zip.sha256']},
          'sourceQualification': {'sha256': assets['source-qualification.json']['digest'][7:], 'bytes': assets['source-qualification.json']['size']}}
lock['releases'].append(cohort)
workflow = W / '.github/workflows/deploy.yml'
text = workflow.read_text()
old = 'git fetch --depth=1 origin refs/tags/v0.61.9:refs/tags/v0.61.9'
assert text.count(old) == 1
put(workflow, text.replace(old, old + ' refs/tags/v0.61.20:refs/tags/v0.61.20').encode())
index = W / 'index.html'
text = index.read_text()
assert text.count('The original v0.61.9 build, preserved') == 1
text = text.replace('The original v0.61.9 build, preserved', 'The original v0.61.9 and v0.61.20 builds, preserved')
needle = '    <p><a href="releases/v0.61.9/site/game/">Play v0.61.9</a></p>'
assert text.count(needle) == 1
put(index, text.replace(needle, needle + '\n    <p><a href="releases/v0.61.20/site/game/">Play v0.61.20</a></p>').encode())
sys.path.insert(0, str(W / 'tools'))
from verify import metadata_inventory, locked_inputs
rows = [row for release in lock['releases'] for row in metadata_inventory(W, release)]
for name in ['.nojekyll', 'index.html', 'releases/index.html']:
    body = b'' if name == '.nojekyll' else (W / name).read_bytes()
    rows.append({'path': name, 'bytes': len(body), 'sha256': sha(body)})
rows.sort(key=lambda r: r['path'])
inventory = read(O / 'baseline/expected-inventory.json')
oldrows = {r['path']: r for r in inventory['files']}
newrows = {r['path']: r for r in rows}
assert len(oldrows) == 701 and len(rows) == len(newrows) and set(oldrows) <= set(newrows)
changed = [path for path, row in oldrows.items() if newrows[path] != row]
unchanged = [path for path, row in oldrows.items() if newrows[path] == row]
prior_release_rows = [path for path in oldrows if path.startswith('releases/v0.61.9/')]
assert changed == ['index.html'] and len(unchanged) == 700 and len(prior_release_rows) == 698
assert all(path in unchanged for path in prior_release_rows)
added = [row for row in rows if row['path'] not in oldrows]
assert all(row['path'].startswith('releases/v0.61.20/') for row in added)
total, added_bytes = sum(r['bytes'] for r in rows), sum(r['bytes'] for r in added)
assert total < lock['budgetBytes'] == 800000000 and len(rows) < 20000
inventory['files'] = rows
dump(W / 'expected-inventory.json', inventory)
lock.update(expectedInventorySha256=sha((W / 'expected-inventory.json').read_bytes()), expectedFiles=len(rows), expectedBytes=total)
dump(W / 'source-lock.json', lock)
locked_inputs(W)
assert lock['releases'][0] == oldlock['releases'][0]
test = W / 'tools/test_prepare.py'
text = test.read_text()
assert text.count('(701, 313404982)') == 1
text = text.replace('(701, 313404982)', f'({len(rows)}, {total})')
text = text.replace("[r['version'] for r in lock['releases']], ['v0.61.9']", "[r['version'] for r in lock['releases']], ['v0.61.9', 'v0.61.20']")
needle = "        self.assertEqual(sum(r['bytes'] for r in cohort), 313403588)"
assert text.count(needle) == 1
text = text.replace(needle, needle + f"\n        release = lock['releases'][1]\n        self.assertEqual(release['tagObject'], '{TAG}')\n        self.assertEqual(release['sourceRevision'], '{SOURCE}')\n        self.assertEqual(release['sourceTree'], '{SOURCE_TREE}')\n        self.assertEqual(release['sourceQualification'], {{'sha256': '{cohort['sourceQualification']['sha256']}', 'bytes': {cohort['sourceQualification']['bytes']}}})\n        cohort = [r for r in inventory['files'] if r['path'].startswith('releases/v0.61.20/')]\n        self.assertEqual(len(cohort), {len(added)})\n        self.assertEqual(sum(r['bytes'] for r in cohort), {added_bytes})")
put(test, text.encode())
readme = f'''# RevealLine archive 27

Retain the exact published v0.61.9 and v0.61.20 releases. The accepted v0.61.9 cohort stays unchanged. The appended v0.61.20 source is `{SOURCE}`, tree `{SOURCE_TREE}`, annotated tag `{TAG}`, release `391660904`. Original release metadata, source qualification, game code and artwork are copied from immutable originals, never rebuilt or edited.

The combined inventory is **{len(rows):,} files / {total:,} bytes**, leaving **{800000000-total:,} bytes** below the unchanged 800,000,000-byte cap. All **698 prior v0.61.9 release rows** and both support rows `.nojekyll` and `releases/index.html` remain exact: **700 unchanged prior rows**. Only root `index.html` changes to add the edition. The append adds **{len(added)} v0.61.20 rows / {added_bytes:,} bytes**. The main Release explorer bridge and other archives stay unchanged.

## Evidence and limits

The initial archive was root-accepted at `{BASE}`, tree `{TREE}`, after all 701 public files / 313,404,982 bytes passed with zero retries. That initial archive had zero previously accepted paths. Its scoped keyboard flight, Pause/explicit Resume and Workshop-return checks do not qualify a fresh full win, offline installation, audio, physical devices or complete responsive presentation. The retained v0.61.9 Large/Plain portrait-return picker focus outline still clips by approximately 1.77 CSS pixels; archiving does not correct it.

Main v0.61.20 has separately accepted public bytes: 3,178 files / 642,414,414 bytes with zero final failures, retries or skips and matching fresh authorities. Its native result is partial: keyboard startup-close and Back focus pass, but at 390×844 the wrapped Enemy Workshop Return button obscures part of the Open workshop outline. The inherited Large/Plain picker-clearance issue also remains until a separately qualified correction is deployed. Physical touch/controller, full offline, wider player journeys and phase acceptance remain open. Public byte acceptance is not full feature or native acceptance.

This append is a local proposal. Hosted extraction, a full archive byte audit and both-version native retention remain pending. Earlier archive acceptance and main byte acceptance do not qualify the new append. All shipped routes, including Enemy Workshop and Still Media, are defined by positive original manifest entries. All Pages projects share one github.io origin; fresh play may update continuation state and does not prove save isolation or migration.

## Append procedure

Review the eleven changed candidate bodies and exact original source/tag/release pins. Adopt them onto the actual accepted archive main tree before a root-owned commit and PR. The merge push deploys once; do not also dispatch manually. Preserve Actions Pages, main-only deployment, read-only build permissions, deploy-only Pages/id-token permissions and non-cancelling concurrency.

The extractor and archive verifier are unchanged. Explicit tag fetch covers both v0.61.9 and v0.61.20, with annotated-tag and peeled-source verification. Keep the 3 GiB hosted reserve, 800 MB inventory and 20,000-file limits, every-member ZIP checks and independent artifact reread. Local fixtures and declared-tag checks do not establish hosted extraction or public delivery.

Bind the actual new archive commit/tree, workflow attempt/jobs, deployment/status and receipt. Audit every row with fresh authorities before and after, proving 700 unchanged prior rows, the one root-index exception and {len(added)} additions. Check each edition's title, ordinary safe play, Pause/explicit Resume and explorer return, plus the affected Enemy Workshop startup-close journey. Preserve the known incomplete outline/presentation gates; do not infer their repair from retention.

Only after separate archive acceptance may a later main publisher update Archive27's ownership and admission. This candidate changes no game source, main selector or admission and does not close a parent phase.
'''
put(W / 'README.md', readme.encode())
stats = {'priorFiles':701,'priorReleaseRows':698,'priorUnchangedFiles':len(unchanged),'changedPriorFiles':changed,'addedFiles':len(added),'addedBytes':added_bytes,'totalFiles':len(rows),'totalBytes':total,'spareBytes':800000000-total}
authority = {'status':'LOCAL_APPEND_PROPOSAL_NOT_DEPLOYED','preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'baseTree':TREE,'publisherCommit':public_accept['publisher'],'version':VERSION,'source':SOURCE,'tree':SOURCE_TREE,'tagObject':TAG,'releaseId':published['id'],'releasePublishedAt':published['published_at'],'originalMetadata':metadata,'originalAssetDescriptors':descriptors(published),'authorityOriginals':[pin(p) for p in [published_path,latest_path,tag_path,tag_object_path,public_accept_path,prior_accept_path]],'priorAcceptedInventory':pin(O/'baseline/expected-inventory.json'),'preservation':stats,'futureCommit':None,'futureRun':None,'futureDeployment':None,'archiveAppendAccepted':False,'scope':'Main public bytes accepted with explicit partial native status; prior archive acceptance is separate from this future append deployment/native retention.', 'mainPublicPhaseAccepted':False, 'mainPublicNativeComplete':False}
dump(W / 'append-v06120-authority.json', authority)
dump(O / 'artifact-plan.json', stats)
dump(O / 'metadata-provenance.json', metadata)
for name in ['tools/prepare.py','tools/verify.py','tools/test_verify.py','input-authority.json','releases/index.html']:
    assert (W/name).read_bytes() == (O/'baseline'/name).read_bytes()
for name in ['release.json','manifest.json','distribution.zip.sha256','source-qualification.json']:
    assert (W/'metadata/v0.61.9'/name).read_bytes() == (O/'baseline/metadata/v0.61.9'/name).read_bytes()
print(json.dumps(stats,indent=2))
