from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys

R = Path.cwd()
O = R / '.cache/archive26-v0618-append-preparation'
W = R / '.cache/worktrees/archive26-v0618-append'
BASE = '6189d37ed382fce79a28e7a464c5e7384429ab05'
TREE = 'abe08da1252515a5d084c93b7ee59b1f45348162'
SOURCE = '0ae4330b8a87d332051db112f5e09b7c3cbef9fa'
SOURCE_TREE = 'bea7eebf35befcae0362b19f7ecfbb75a3942b00'
TAG = 'd6b9a83d1364c81f23251fae4c3d30241b2e36df'
VERSION = 'v0.61.8'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(p.read_bytes())

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], env=ENV, timeout=30)

def pin(p):
    b = p.read_bytes()
    return {'path': str(p.relative_to(R)), 'bytes': len(b), 'sha256': sha(b)}

def put(p, body):
    assert p.is_relative_to(O) or p.is_relative_to(W)
    assert not p.is_symlink()
    used = sum(x.stat().st_size for t in [O, W] for x in t.rglob('*') if x.is_file() and not x.is_symlink())
    assert used + len(body) < 16 * 1024**2
    assert shutil.disk_usage(R).free >= 512 * 1024**2 + len(body) + 65536
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(body)

def dump(p, value):
    put(p, (json.dumps(value, indent=2) + '\n').encode())

assert git(W, 'rev-parse', 'HEAD').decode().strip() == BASE
assert git(W, 'rev-parse', 'HEAD^{tree}').decode().strip() == TREE
assert git(W, 'status', '--porcelain').strip() == b''
prior_accept_path = R / '.cache/archive26-v0617-public-audit/root-acceptance.json'
public_accept_path = R / '.cache/p05-public-audit-v0618-preparation/root-public-acceptance.json'
prior_accept, public_accept = read(prior_accept_path), read(public_accept_path)
assert prior_accept['archiveCommit'] == BASE and prior_accept['archiveTree'] == TREE
assert prior_accept['files'] == 701 and prior_accept['verifiedBytes'] == 313387929
assert public_accept['version'] == VERSION and public_accept['source'] == SOURCE and public_accept['tree'] == SOURCE_TREE
assert public_accept['status'] == 'ROOT_ACCEPTED_SCOPED_PUBLIC_RELEASE'
published_path = R / '.cache/v0618-release-preparation/root-publish-r1/after-release.json'
latest_path = published_path.with_name('after-latest.json')
tag_path = published_path.with_name('before-tag.json')
tag_object_path = published_path.with_name('before-tag-object.json')
published, latest = read(published_path), read(latest_path)
assert published['id'] == latest['id'] == 391546102
assert published['tag_name'] == latest['tag_name'] == VERSION
assert not published['draft'] and not published['prerelease'] and not latest['draft']
keys = ['id', 'name', 'size', 'digest', 'state', 'browser_download_url']
descriptors = lambda r: sorted([{k: a[k] for k in keys} for a in r['assets']], key=lambda a: a['name'])
assert descriptors(published) == descriptors(latest)
after_refresh = read(R / '.cache/p05-public-audit-v0618-preparation/after-http-authorities-full-public-r1/result.json')
assert descriptors(published) == after_refresh['assets']
assets = {a['name']: a for a in published['assets']}
assert len(assets) == 9
assert read(tag_path)['object']['sha'] == read(tag_object_path)['sha'] == TAG
assert read(tag_object_path)['object']['sha'] == SOURCE
metadata = []
for name in ['release.json', 'manifest.json', 'distribution.zip.sha256', 'source-qualification.json']:
    original = R / '.cache/p05-public-audit-v0618-preparation/source-originals' / name
    body = original.read_bytes()
    asset = assets[name]
    assert len(body) == asset['size'] and 'sha256:' + sha(body) == asset['digest']
    dest = W / 'metadata' / VERSION / name
    put(dest, body)
    metadata.append({'path': str(dest.relative_to(W)), 'original': pin(original), 'assetId': asset['id']})
oldlock = read(O / 'originals/source-lock.json')
lock = read(W / 'source-lock.json')
assert lock == oldlock and [r['version'] for r in lock['releases']] == ['v0.61.7']
cohort = {'version': VERSION, 'sourceRevision': SOURCE, 'sourceTree': SOURCE_TREE, 'tagObject': TAG,
          'distributionSha256': assets['distribution.zip']['digest'][7:], 'distributionBytes': assets['distribution.zip']['size'],
          'metadata': {n: assets[n]['digest'][7:] for n in ['release.json', 'manifest.json', 'distribution.zip.sha256']},
          'sourceQualification': {'sha256': assets['source-qualification.json']['digest'][7:], 'bytes': assets['source-qualification.json']['size']}}
lock['releases'].append(cohort)
workflow = W / '.github/workflows/deploy.yml'
text = workflow.read_text()
old = 'git fetch --depth=1 origin refs/tags/v0.61.7:refs/tags/v0.61.7'
assert text.count(old) == 1
put(workflow, text.replace(old, old + ' refs/tags/v0.61.8:refs/tags/v0.61.8').encode())
index = W / 'index.html'
text = index.read_text()
assert text.count('The original v0.61.7 build, preserved') == 1
text = text.replace('The original v0.61.7 build, preserved', 'The original v0.61.7 and v0.61.8 builds, preserved')
needle = '    <p><a href="releases/v0.61.7/site/game/">Play v0.61.7</a></p>'
assert text.count(needle) == 1
put(index, text.replace(needle, needle + '\n    <p><a href="releases/v0.61.8/site/game/">Play v0.61.8</a></p>').encode())
sys.path.insert(0, str(W / 'tools'))
from verify import metadata_inventory, locked_inputs
rows = [row for release in lock['releases'] for row in metadata_inventory(W, release)]
for name in ['.nojekyll', 'index.html', 'releases/index.html']:
    body = b'' if name == '.nojekyll' else (W / name).read_bytes()
    rows.append({'path': name, 'bytes': len(body), 'sha256': sha(body)})
rows.sort(key=lambda r: r['path'])
inventory = read(O / 'originals/expected-inventory.json')
oldrows = {r['path']: r for r in inventory['files']}
newrows = {r['path']: r for r in rows}
assert len(oldrows) == 701 and len(rows) == len(newrows) and set(oldrows) <= set(newrows)
changed = [path for path, row in oldrows.items() if newrows[path] != row]
unchanged = [path for path, row in oldrows.items() if newrows[path] == row]
prior_release_rows = [path for path in oldrows if path.startswith('releases/v0.61.7/')]
assert changed == ['index.html'] and len(unchanged) == 700 and len(prior_release_rows) == 698
assert all(path in unchanged for path in prior_release_rows)
added = [row for row in rows if row['path'] not in oldrows]
assert all(row['path'].startswith('releases/v0.61.8/') for row in added)
total, added_bytes = sum(r['bytes'] for r in rows), sum(r['bytes'] for r in added)
assert total < lock['budgetBytes'] == 800000000 and len(rows) < 20000
inventory['files'] = rows
dump(W / 'expected-inventory.json', inventory)
lock.update(expectedInventorySha256=sha((W / 'expected-inventory.json').read_bytes()), expectedFiles=len(rows), expectedBytes=total)
dump(W / 'source-lock.json', lock)
locked_inputs(W)
assert lock['releases'][0] == oldlock['releases'][0]
test = W / 'tools/test_prepare.py'
text = test.read_text()
assert text.count('(701, 313387929)') == 1
text = text.replace('(701, 313387929)', f'({len(rows)}, {total})')
text = text.replace("[r['version'] for r in lock['releases']], ['v0.61.7']", "[r['version'] for r in lock['releases']], ['v0.61.7', 'v0.61.8']")
needle = "        self.assertEqual(sum(r['bytes'] for r in cohort), 313386535)"
assert text.count(needle) == 1
text = text.replace(needle, needle + f"\n        release = lock['releases'][1]\n        self.assertEqual(release['tagObject'], '{TAG}')\n        self.assertEqual(release['sourceRevision'], '{SOURCE}')\n        self.assertEqual(release['sourceTree'], '{SOURCE_TREE}')\n        self.assertEqual(release['sourceQualification'], {{'sha256': '{cohort['sourceQualification']['sha256']}', 'bytes': {cohort['sourceQualification']['bytes']}}})\n        cohort = [r for r in inventory['files'] if r['path'].startswith('releases/v0.61.8/')]\n        self.assertEqual(len(cohort), {len(added)})\n        self.assertEqual(sum(r['bytes'] for r in cohort), {added_bytes})")
put(test, text.encode())
readme = f'''# RevealLine archive 26

Retain the exact published v0.61.7 and v0.61.8 releases. The accepted v0.61.7 cohort remains unchanged. The appended v0.61.8 source is `{SOURCE}`, tree `{SOURCE_TREE}`, annotated tag `{TAG}`, release `391546102`. Original release metadata, source qualification, game code and artwork are not rebuilt or edited.

This append expects **{len(rows):,} files / {total:,} bytes**, leaving **{800000000-total:,} bytes** below the unchanged 800,000,000-byte cap. It preserves all **698 prior v0.61.7 release rows** and the two support rows `.nojekyll` and `releases/index.html`: **700 unchanged prior rows**. Only the archive root `index.html` changes to add the new edition. The append adds **{len(added)} v0.61.8 rows / {added_bytes:,} bytes**. The main Release explorer bridge and other archives remain unchanged.

## Evidence and limits

The initial archive was accepted at `{BASE}`, tree `{TREE}`, after all 701 original public files / 313,387,929 bytes passed with zero retries. That initial deployment had zero previously accepted paths. Its scoped native checks covered v0.61.7 practice capture, Pause/explicit Resume, guide/Workshop return, Motion Standard/Large rotation and Release explorer return. The original narrow Motion screenshot is excluded and its correction retained. The known right-edge focus outline and cross-navigation pause limits remain open; no physical-device, full-win, save-migration or offline claim follows.

Main v0.61.8 is separately root-accepted: 3,128 files / 642,118,555 bytes, one preserved HTTP 503 recovered once and zero final failures. Standard-text Still Media picker label, field and full focus outline remained visible through portrait-landscape-portrait, with filename/status retention and Escape/Close return. The setup mixed pointer and keyboard; opening local media can upgrade its database. No zero-storage-mutation or after-rotation pixel-identity claim is made. Large/Plain propagation belongs to v0.61.9, not this release.

This append remains a local proposal until its own hosted extraction, full public audit and both-version native retention pass. Main acceptance does not establish archive acceptance. All shipped paths, including Still Media, Motion Lab and Enemy Workshop, are defined by positive entries in the original artifact-root manifests.

## Append procedure

Review the eleven candidate paths and original source/tag/release pins, commit on the isolated `codex/` branch, and merge the reviewed PR. The merge push starts deployment once; do not also dispatch it manually. Preserve Actions Pages, main-only deployment, read-only build permissions, deploy-only Pages/id-token permissions and non-cancelling concurrency.

The pinned extractor and archive verifier are unchanged. The workflow explicitly fetches both locked tags, v0.61.7 and v0.61.8, and verifies annotated tags and peeled source commits. Keep the 3 GiB hosted reserve, 800 MB inventory and 20,000-file limits, every-member ZIP validation and independent artifact reread. Local fixture and tag-declaration checks do not establish hosted extraction or public delivery.

Bind the actual archive commit/tree, workflow attempt/jobs, deployment/status and small receipt. Audit the complete inventory with fresh authority before and after, proving the 700 unchanged rows, one changed root index and {len(added)} new rows. Separately check each edition's title, ordinary safe play, Pause/explicit Resume and explorer return, plus the affected v0.61.8 Standard picker journey. All Pages project paths share one github.io origin; session-only play is not save isolation or migration proof.

Only after archive acceptance may a separate main publisher append v0.61.8 to Archive26 ownership and replace its admission before the v0.61.9 selector advances. This proposal changes no main selector or existing admission. Whole P03/P05/P07/P08/P18, physical controls, audio, offline and other local Team/actor/HUD work remain open.
'''
put(W / 'README.md', readme.encode())
stats = {'priorFiles':701,'priorReleaseRows':698,'priorUnchangedFiles':len(unchanged),'changedPriorFiles':changed,'addedFiles':len(added),'addedBytes':added_bytes,'totalFiles':len(rows),'totalBytes':total,'spareBytes':800000000-total}
authority = {'status':'LOCAL_APPEND_PROPOSAL_NOT_DEPLOYED','preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'baseTree':TREE,'publisherCommit':public_accept['controller'],'version':VERSION,'source':SOURCE,'tree':SOURCE_TREE,'tagObject':TAG,'releaseId':published['id'],'releasePublishedAt':published['published_at'],'originalMetadata':metadata,'originalAssetDescriptors':descriptors(published),'authorityOriginals':[pin(p) for p in [published_path,latest_path,tag_path,tag_object_path,public_accept_path,prior_accept_path]],'priorAcceptedInventory':pin(O/'originals/expected-inventory.json'),'preservation':stats,'futureCommit':None,'futureRun':None,'futureDeployment':None,'archiveAppendAccepted':False,'scope':'Accepted main release and prior archive are separate from this future append deployment/native retention.'}
dump(W / 'append-v0618-authority.json', authority)
dump(O / 'artifact-plan.json', stats)
dump(O / 'metadata-provenance.json', metadata)
for name in ['tools/prepare.py','tools/verify.py','tools/test_verify.py','input-authority.json','releases/index.html']:
    assert (W/name).read_bytes() == (O/'originals'/name).read_bytes()
for name in ['release.json','manifest.json','distribution.zip.sha256','source-qualification.json']:
    assert (W/'metadata/v0.61.7'/name).read_bytes() == (O/'originals/metadata/v0.61.7'/name).read_bytes()
print(json.dumps(stats,indent=2))
