from pathlib import Path
import subprocess,json,hashlib,datetime,zipfile,stat
import sys,shutil,time,selectors
P=Path(__file__).resolve().parent
assert len(sys.argv)==2 and len(sys.argv[1])==64, 'Root-reviewed request SHA is required'
B=P/'small-receipt-request.reviewed.json';raw=B.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(raw)==sys.argv[1];req=json.loads(raw);assert req['reviewed'] is True
assert req['repository']=='mekhovov/revealline-archive-27' and type(req['artifactId']) is int and req['artifactId']>0 and req['artifactId']==10562923008
assert req['artifactBytes']==73579 and req['artifactSha256']=='44ecb56fc300a2654b6d8d8905707c70f5912273bbc951ba9f50268795f2ad38'
def allowance(n):
 assert sum(p.stat().st_size for p in P.rglob('*') if p.is_file() and not p.is_symlink())+n <= 8*1024**2, 'Managed intake cap'
 assert shutil.disk_usage(P).free >= 512*1024**2+n+65536, 'Free-space reserve'
allowance(3*1024**2)
for pin in req['originalPins']:
 b=(P/pin['path']).read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256']
O=P/'hosted-originals';O.mkdir(exist_ok=False);(O/'reviewed-download-request.json').write_bytes(raw);cmd=['gh','api','--method','GET',req['apiEndpoint']];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
# Same bounded, timeout-protected small-artifact call as the reviewed Archive03 collector.
timed=False
# Read bounded pipes; terminate at 45 seconds or first byte beyond the tiny ZIP cap.
process=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
sel=selectors.DefaultSelector();sel.register(process.stdout,selectors.EVENT_READ,'out');sel.register(process.stderr,selectors.EVENT_READ,'err')
buffers={'out':bytearray(),'err':bytearray()};deadline=time.monotonic()+45;oversized=False
try:
 while sel.get_map():
  if time.monotonic()>=deadline: timed=True;break
  for key,_ in sel.select(min(0.2,max(0,deadline-time.monotonic()))):
   chunk=key.fileobj.read1(65536)
   if not chunk: sel.unregister(key.fileobj);continue
   limit=req['maxDownloadBytes'] if key.data=='out' else 65536
   room=limit+1-len(buffers[key.data]);buffers[key.data].extend(chunk[:max(0,room)])
   if len(buffers[key.data])>limit: oversized=True;break
  if oversized:break
finally:
 if timed or oversized:process.kill()
 code=process.wait(timeout=5);sel.close()
 stdout,stderr=bytes(buffers['out']),bytes(buffers['err'])
 if oversized:code=-1
allowance(len(stdout)+len(stderr)+req['maxUncompressedBytes']+65536)
attempt={'argv':cmd,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code,'timedOut':timed,'receivedBytes':len(stdout),'maxAcceptedBytesExclusive':req['maxDownloadBytes'],'bindingSha256':sha(raw)}
(O/'download.attempt.json').write_text(json.dumps(attempt,indent=2)+'\n');(O/'download.stderr').write_bytes(stderr[:1999999]);(O/'download.exit').write_text(str(code)+'\n')
if timed or code!=0 or len(stdout)>=req['maxDownloadBytes']:
 (O/'download.partial').write_bytes(stdout[:req['maxDownloadBytes']-1]);raise RuntimeError('Small receipt GET failed; preserved bounded partial; no retry')
zip_path=P/req['outputRelativeToRetentionRoot'];zip_path.write_bytes(stdout);assert len(stdout)==req['artifactBytes'] and sha(stdout)==req['artifactSha256']
E=O/'receipts';E.mkdir();expected=set(req['expectedMembers'])
with zipfile.ZipFile(zip_path) as z:
 infos=z.infolist();assert len(infos)==len(expected) and {i.filename for i in infos}==expected;assert sum(i.file_size for i in infos)<=req['maxUncompressedBytes']
 for i in infos:assert not i.is_dir() and not i.flag_bits&1 and stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG) and i.file_size<=req['maxMemberBytes']
 assert z.testzip() is None
 for i in infos:
  body=z.read(i);assert len(body)==i.file_size;(E/i.filename).write_bytes(body)
invraw=(E/'expected-inventory.json').read_bytes();inv=json.loads(invraw);lock=json.loads((P/'inputs/source-lock.json').read_bytes());receipt=json.loads((E/'receipt.json').read_bytes());assert invraw==(P/'inputs/expected-inventory.json').read_bytes();assert sha(invraw)==req['inventorySha256'];assert len(inv['files'])==req['expectedFiles'] and sum(r['bytes'] for r in inv['files'])==req['expectedBytes']
assert receipt['status']=='PASS' and receipt['archiveId']=='archive-27' and receipt['archiveCommit']==req['archiveCommit'] and receipt['archiveTree']==req['archiveTree'] and receipt['files']==req['expectedFiles'] and receipt['bytes']==req['expectedBytes'] and receipt['expectedInventorySha256']==req['inventorySha256'] and receipt['noHistoricalBuilds'] is True and receipt['toolingCommit']==lock['toolingCommit'];assert len(receipt['releases'])==len(lock['releases'])==2
assert [r['version'] for r in lock['releases']]==['v0.61.9','v0.61.20']
for expectedRelease,rr in zip(lock['releases'],receipt['releases']):
 version=expectedRelease['version'];z=json.loads((E/('zip-receipt-'+version+'.json')).read_bytes());assert rr['version']==version
 assert rr['sourceRevision']==expectedRelease['sourceRevision'] and rr['tagObject']==expectedRelease['tagObject'] and rr['originalZipExtraction']==z
 assert z['version']==version and z['gameSourceRevision']==expectedRelease['sourceRevision'] and z['distributionSha256']==expectedRelease['distributionSha256'] and z['manifestSha256']==expectedRelease['metadata']['manifest.json'] and z['crcAndHashesVerified'] is True
pins=[]
for p in sorted(O.rglob('*')):
 if p.is_file():b=p.read_bytes();pins.append({'path':p.relative_to(P).as_posix(),'bytes':len(b),'sha256':sha(b)})
result={'status':'ORIGINAL_SMALL_RECEIPT_VALIDATED_NO_PUBLIC_AUDIT','archiveCommit':req['archiveCommit'],'archiveTree':req['archiveTree'],'runId':req['runId'],'deploymentId':req['deploymentId'],'deploymentStatusId':req['deploymentStatusId'],'receiptArtifactId':req['artifactId'],'receiptBytes':len(stdout),'receiptSha256':sha(stdout),'files':len(inv['files']),'bytes':sum(r['bytes'] for r in inv['files']),'inventorySha256':sha(invraw),'crcAndExactFourMembersPassed':True,'exactCandidateInventoryAndSourceChainPassed':True,'pins':pins,'publicByteAcceptance':False,'nativeAcceptanceNotAltered':True};(O/'completion.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='pins'},indent=2))
