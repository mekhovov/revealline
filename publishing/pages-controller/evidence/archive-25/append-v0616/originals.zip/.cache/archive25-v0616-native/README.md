# Archive 25 native retention smoke

Bounded real CUA checks passed for archived v0.61.5 and v0.61.6. Each reward-free Field Guide practice session started, accepted direction taps, closed a cut to 8.6% / 02040 with three lives, paused and explicitly resumed, then returned to its opener. About/build history retained immutable version identity.

The existing v0.61.5 Relay Orchard flight was left intact. v0.61.6 Home showed Start; no main flight was started. This is practice/session evidence, not save migration, full-win, physical-input, offline, audio or exhaustive layout qualification. See observations.json for exact routes and limitations. Raw JPEGs are unmodified.
