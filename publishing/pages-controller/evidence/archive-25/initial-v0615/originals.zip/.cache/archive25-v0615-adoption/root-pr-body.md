Retain the original v0.61.5 release at a separate historical play route before the next game version becomes current. The source/tag, four original metadata bodies and complete 700-file / 313,375,639-byte inventory are pinned; no game payload is rebuilt and existing archives remain unchanged.

The exact sixteen adopted files and staged blobs were reviewed. Twenty archive fixtures, four bounded-extractor fixtures and tag-fetch checks passed during preparation. Actions Pages is configured with a main-only deployment environment. Merging starts one hosted extraction/deployment; its public byte and actual play checks are still required before the main publisher may admit this archive.

v0.61.5 has separately passed main-site public acceptance. Preparation-time pending language in the preserved input record remains historical evidence.
