# Archive25 preservation-count correction

The initial Archive25 publication has zero previously accepted canonical rows. All 700 paths are newly admitted at this archive URL: 697 paths belong to v0.61.5 and three are archive-root files. Its source candidate starts from a README-only seed. This is a separate project path on the same GitHub Pages origin, not a new storage origin.

The executed auditor inherited the number 697 in two informational fields from the preceding Archive24 append: `--prepare` output `preservedCanonicalRows` and final report `preservedOldCanonicalRows`. Those fields are wrong and must be read as zero. The original helper and report are retained unchanged. The independent row reconciliation reports zero and verifies every actual response against the 700-row inventory.

I removed the predecessor-inventory verification and corrected the binding and reconciler, but missed the two summary literals in the transport module. Existing fixtures checked input identity and transport outcomes, not those summary outputs. This was an incomplete adaptation and review, not a network failure.

No other current identity/count mismatch was found in the active helpers. Archive03 references describe helper ancestry; v0.61.4 strings in fixtures are deliberate negative cases. The comment about an earlier append failure refers to the historical tag-fetch incident. These are not current deployment claims.

The separate future-template patch defines one explicit prior-row count for both summary fields. It is unexecuted and is not applied to this audit. Before adopting it, add offline fixtures that run both preparation and synthetic completed-report paths and assert zero for initial archives. Append templates must derive their count from an explicitly reviewed predecessor inventory and prove each preserved row; the summary must equal that proof. A response-byte audit does not need repeating for this metadata correction.
