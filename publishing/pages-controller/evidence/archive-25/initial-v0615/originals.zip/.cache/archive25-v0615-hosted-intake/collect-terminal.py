"""One finite read-only original metadata/log collection; never an artifact body GET."""
from pathlib import Path
import subprocess,json,hashlib,datetime,concurrent.futures,shutil
P=Path(__file__).resolve().parent;O=P/'terminal-r1';O.mkdir()
REPO='mekhovov/revealline-archive-25';COMMIT='70eb8242670ab7e3518b2f8266ca07fef51ecf5c';TREE='5cfd357722dc7aafdae831d8b7bb45eb3c3bbb62';RUN=35342134221
sha=lambda b:hashlib.sha256(b).hexdigest()
def allowance(n):
 assert sum(f.stat().st_size for f in P.rglob('*') if f.is_file())+n<16*1024**2
 assert shutil.disk_usage(P).free>512*1024**2+n+65536

def get(pair):
 name,path,raw=pair;allowance(2*2_000_000);cmd=['gh','api','repos/'+REPO+'/'+path];timed=False
 try:r=subprocess.run(cmd,capture_output=True,timeout=35);stdout,stderr,code=r.stdout,r.stderr,r.returncode
 except subprocess.TimeoutExpired as e:stdout,stderr,code,timed=e.output or b'',e.stderr or b'',None,True
 truncated=len(stdout)>=2_000_000 or len(stderr)>=2_000_000
 (O/(name+('.log' if raw else '.json'))).write_bytes(stdout[:1_999_999]);(O/(name+'.stderr')).write_bytes(stderr[:1_999_999])
 (O/(name+'.receipt.json')).write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exit':code,'timeout':timed,'retentionTruncated':truncated,'receivedBytes':len(stdout),'completeOriginal':not timed and not truncated,'artifactBodyGET':False},indent=2)+'\n')
 assert not timed and not truncated and code==0
 return name,stdout if raw else json.loads(stdout)
queries=[('run',f'actions/runs/{RUN}',False),('jobs',f'actions/runs/{RUN}/attempts/1/jobs',False),('artifacts',f'actions/runs/{RUN}/artifacts',False),('main','git/ref/heads/main',False),('commit','git/commits/'+COMMIT,False),('deployments','deployments?sha='+COMMIT+'&per_page=10',False)]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as e:data=dict(e.map(get,queries))
assert data['main']['object']['sha']==data['commit']['sha']==data['run']['head_sha']==COMMIT and data['commit']['tree']['sha']==TREE
assert data['run']['id']==RUN and data['run']['run_attempt']==1 and data['run']['event']=='push' and data['run']['path']=='.github/workflows/deploy.yml' and data['run']['status']=='completed' and data['run']['conclusion']=='success'
assert len(data['jobs']['jobs'])==2 and all(j['conclusion']=='success' for j in data['jobs']['jobs'])
dep=[d for d in data['deployments'] if d['environment']=='github-pages'];assert len(dep)==1;DEP=dep[0]['id']
art=[a for a in data['artifacts']['artifacts'] if a['name']=='archive25-verification-receipts'];assert len(art)==1;ART=art[0]['id']
more=[('deployment',f'deployments/{DEP}',False),('statuses',f'deployments/{DEP}/statuses',False),('artifact-descriptor',f'actions/artifacts/{ART}',False)]+[(f'job-{j["id"]}',f'actions/jobs/{j["id"]}/logs',True) for j in data['jobs']['jobs']]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as e:data.update(dict(e.map(get,more)))
assert data['deployment']['sha']==COMMIT and data['deployment']['ref']=='main' and data['statuses'][0]['state']=='success' and data['statuses'][0]['environment_url'].rstrip('/')=='https://mekhovov.github.io/revealline-archive-25'
a=data['artifact-descriptor'];assert a['id']==ART and a['name']=='archive25-verification-receipts' and a['expired'] is False and a['workflow_run']['id']==RUN and a['workflow_run']['head_sha']==COMMIT and a['size_in_bytes']<2*1024**2 and a['digest'].startswith('sha256:')
pins=[]
for f in sorted(O.iterdir()):
 if f.is_file():b=f.read_bytes();pins.append({'path':str(f.relative_to(P)),'bytes':len(b),'sha256':sha(b)})
result={'status':'ACTUAL_ARCHIVE25_TERMINAL_ORIGINALS_READY','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':REPO,'archiveCommit':COMMIT,'archiveTree':TREE,'runId':RUN,'runAttempt':1,'deploymentId':DEP,'deploymentStatusId':data['statuses'][0]['id'],'artifactId':ART,'artifactBytes':a['size_in_bytes'],'artifactSha256':a['digest'][7:],'pins':pins,'artifactBodyGETs':0,'publicAcceptance':False}
(P/'terminal-originals.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='pins'},indent=2))
