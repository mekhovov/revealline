Preserve the published v0.57.2 game as its exact original distribution, with all 655 manifest entries and 8 archive wrapper/metadata entries. This keeps historical releases available while the next corrective patch follows its own qualification.

The source, annotated tag, nine original asset identities, ZIP, source qualification and complete 663-file / 312,625,191-byte inventory are pinned. Hosted preparation enforces the 800 MB archive budget and verifies every original ZIP member and output byte. Both workflow jobs and the Pages environment permit main only.

Validation: 20 infrastructure tests and 4 pinned extractor corruption tests pass against this exact commit; staged diff and clean tree verified. Public byte and native history review follow deployment. Known historical file-input, replay placement and picture-writer return defects remain unchanged and do not accept P01.
