import json,subprocess,sys,os,http.client,datetime,time
from pathlib import Path
P=Path(__file__).resolve().parent;name,*action=sys.argv[1:]
assert name.replace('-','').isalnum() and action and not(P/(name+'.json')).exists()
assert not any(x in action for x in ['--auto-connect','--all','--fn'])
l=json.loads((P/'launch.json').read_text());health=json.loads((P/'events.jsonl.health.json').read_text());assert health['state']=='ready' and not health['capped']
assert time.time()-datetime.datetime.fromisoformat(health['time'].replace('Z','+00:00')).timestamp()<8
args=subprocess.check_output(['ps','-p',str(l['pid']),'-o','command='],text=True);assert '--user-data-dir='+l['profile'] in args
c=http.client.HTTPConnection('127.0.0.1',l['port'],timeout=2);c.request('GET','/json/list');pages=[x for x in json.loads(c.getresponse().read()) if x['type']=='page'];c.close();assert len(pages)==1 and pages[0]['id']==l['target']
url=pages[0]['url'];assert url=='about:blank' or url.startswith('https://mekhovov.github.io/revealline-archive-16/') or url=='https://mekhovov.github.io/revealline/releases/'
env={k:v for k,v in os.environ.items() if not k.startswith('AGENT_BROWSER_') and k.lower() not in ['http_proxy','https_proxy','all_proxy','no_proxy']};env['AGENT_BROWSER_DEFAULT_TIMEOUT']='10000'
cmd=['/Users/oleksandr.mekhovov/.local/share/mise/installs/node/20.19.5/bin/agent-browser','--config',str(P/'agent-browser.json'),'--session',l['session'],'--cdp',str(l['port'])]
g=subprocess.run(cmd+['eval','({url:location.href,visibilityState:document.visibilityState,hasFocus:document.hasFocus()})'],env=env,capture_output=True,text=True,timeout=15);assert g.returncode==0,g.stderr
v=json.loads(g.stdout);assert v['visibilityState']=='visible' and v['hasFocus'] is True,v
start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(cmd+action,env=env,capture_output=True,text=True,timeout=30)
out={'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':l['target'],'port':l['port'],'session':l['session'],'visibilityBefore':v,'observerHealthBefore':health,'action':action,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
with (P/(name+'.json')).open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(r.stdout);print(r.stderr,file=sys.stderr);raise SystemExit(r.returncode)
