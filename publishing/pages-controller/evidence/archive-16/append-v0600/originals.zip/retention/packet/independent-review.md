# Independent Archive16 candidate review

PASS for preparation only. No actionable findings.

Reviewed uncommitted candidate on `codex/archive16-retain-v0600`, baseline `275a3061e8233a2c1046a494e613dca03783e231` / tree `d2ff87cdf8b6b6d3aa01b761adb1ec947b8f9b6d`. Six tracked modifications and five new files; no staged changes.

- Inventory independently confirms **1,347 files / 625,710,011 bytes**, SHA-256 `c02d6bf74f731a5e646159434325153ed79e841e7ff58c7f15b580be3440aeaa`, with 174,289,989 bytes below the unchanged 800,000,000-byte cap. All 660 old v0.57.2 canonical rows and old shared rows except the declared root index are unchanged. The 684 new canonical rows match an independent derivation from original metadata and the fixed build marker.
- Four v0.60.0 metadata bodies are byte-identical to saved originals and pinned controller origins; sizes, hashes and asset IDs match saved Release API record 390511341. Source `170508f11dd41204b7e24917a823f21701c15961`, tree `287ea0fddf97f594af0ce9eba452a24dc5f507c7`, and annotated tag `03bf36ae9a36f5e776464bd5ef75043cfba727d7` agree across qualification, source-lock and the saved API binding chain.
- Old cohort, old metadata, production tools, original authority, explorer bridge, 3 GiB workspace floor, budget and safety guards are unchanged. The entire workflow change adds only the v0.60.0 tag fetch. Test diff retains synthetic cases and updates committed-metadata expectations.
- Original controller admission and all 40 evidence pins match Git objects at `587f4e75cc9dde7ae0db7ffac34320761b94588c`. Candidate deployment, HTTP acceptance and native admission fields remain null.

Scope: local file/Git-object and saved API-record review only. No tests, browser, network, large payload downloads, extraction, source/index edits, Git staging/commit, remote writes, deployment or acceptance performed. Root owns remote execution. The saved Release API platform immutability flag is `false`; current original descriptors are pinned, and this flag does not establish or imply any asset mutation.

Reviewed file bindings (SHA-256):

- `.github/workflows/deploy.yml`: `9c5cf186ad748998b03913e80118eb4a7cb550ac8c95a3509e9a829b0b279872` (3110 bytes)
- `README.md`: `cc86f8828aafa1694de856433bbe11c29af71c0106159f2d063208f954f0bf2f` (3794 bytes)
- `expected-inventory.json`: `c02d6bf74f731a5e646159434325153ed79e841e7ff58c7f15b580be3440aeaa` (278327 bytes)
- `index.html`: `320b6a916018478d0a9ea6445d5b541758e776e07d3552699a676835704a072b` (1120 bytes)
- `input-authority-v0600.json`: `3d9efcb2061f562b02101619fd64ff8ddbb5851c7b75a0a000988a26f6c901dd` (4259 bytes)
- `metadata/v0.60.0/distribution.zip.sha256`: `32e43f528d43f2923f9e8692b54f6aaa1e62589c1de69ccb06852c32c629f016` (83 bytes)
- `metadata/v0.60.0/manifest.json`: `1557e4bb9c0ab8ba23086d839c4efdb6b2041442945aafb87ba25ba7487906e4` (125543 bytes)
- `metadata/v0.60.0/release.json`: `88bbe7e5d39fbd2a9b54e78baafeed5e545e140e0ce30df1ef5630fb99b8d9e7` (465 bytes)
- `metadata/v0.60.0/source-qualification.json`: `9ee364bf236aacfde4c5610f45d165e6cf8e9ebc24b5eab38ce164ce10d6c5cd` (81429 bytes)
- `source-lock.json`: `ab38ba6e860014a77487fafc3f2bd9d527a905722ab155ae7eda2666e6c138f6` (2263 bytes)
- `tools/test_prepare.py`: `23ce164fb8d490a52af07fb05e61c0c8f8036974af9346128657303a94a2f9e5` (17273 bytes)

Final README follow-up reviewed: the tool paragraph now correctly states that committed-metadata checks pin both v0.57.2 and v0.60.0 authorities. Its file binding above was refreshed; other reviewed candidate files were unchanged by this follow-up.
