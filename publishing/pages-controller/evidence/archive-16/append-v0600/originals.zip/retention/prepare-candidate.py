from pathlib import Path
import subprocess, json, hashlib, sys, datetime
PACKET = Path(__file__).resolve().parent
WT = PACKET / 'archive16-worktree'
ORIGINALS = PACKET / 'originals'
BASE = PACKET / 'archive16-originals'
BASE.mkdir()
sha = lambda b: hashlib.sha256(b).hexdigest()
encoded = lambda v: (json.dumps(v, indent=2) + '\n').encode()
git = lambda *a: subprocess.check_output(['git', '-C', str(WT), *a])
assert git('rev-parse', 'HEAD').decode().strip() == '275a3061e8233a2c1046a494e613dca03783e231'
assert git('status', '--porcelain') == b''
for name in git('ls-files').decode().splitlines():
    b = git('show', 'HEAD:' + name)
    p = BASE / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    assert (WT / name).read_bytes() == b
review = json.loads((ORIGINALS / 'metadata-review.json').read_bytes())
release = json.loads((ORIGINALS / 'release-v0600.json').read_bytes())
assets = {x['name']: x for x in release['assets']}
md = WT / 'metadata/v0.60.0'
md.mkdir()
for name in ['release.json', 'manifest.json', 'distribution.zip.sha256', 'source-qualification.json']:
    b = (ORIGINALS / name).read_bytes()
    assert len(b) == assets[name]['size'] and 'sha256:' + sha(b) == assets[name]['digest']
    (md / name).write_bytes(b)
lock = json.loads((WT / 'source-lock.json').read_bytes())
oldlock = json.loads((BASE / 'source-lock.json').read_bytes())
cohort = {
    'version': 'v0.60.0', 'sourceRevision': review['sourceRevision'],
    'sourceTree': review['sourceTree'],
    'distributionSha256': assets['distribution.zip']['digest'][7:],
    'distributionBytes': assets['distribution.zip']['size'], 'tagObject': review['tagObject'],
    'metadata': {name: sha((md / name).read_bytes()) for name in ['release.json', 'manifest.json', 'distribution.zip.sha256']},
    'sourceQualification': {'sha256': sha((md / 'source-qualification.json').read_bytes()), 'bytes': (md / 'source-qualification.json').stat().st_size},
}
assert lock['releases'] == oldlock['releases'] and len(lock['releases']) == 1
lock['releases'].append(cohort)
index = (WT / 'index.html').read_text()
index = index.replace('Historical v0.57.2 is preserved with its original game bytes.', 'Historical v0.57.2 and v0.60.0 are preserved with their original game bytes.')
index = index.replace('Inspect source qualification</a>', 'Inspect v0.57.2 source qualification</a>')
insert = '''      <li><a href="releases/v0.60.0/site/game/">Play v0.60.0</a></li>
      <li><a href="https://github.com/mekhovov/revealline/releases/download/v0.60.0/distribution.zip">Download the original v0.60.0 ZIP</a></li>
      <li><a href="releases/v0.60.0/source-qualification.json">Inspect v0.60.0 source qualification</a></li>
'''
needle = '      <li><a href="https://mekhovov.github.io/revealline/releases/">'
assert index.count(needle) == 1
(WT / 'index.html').write_text(index.replace(needle, insert + needle))
wf = WT / '.github/workflows/deploy.yml'
s = wf.read_text()
needle = 'run: git fetch --depth=1 origin refs/tags/v0.57.2:refs/tags/v0.57.2'
assert s.count(needle) == 1
wf.write_text(s.replace(needle, needle + ' refs/tags/v0.60.0:refs/tags/v0.60.0'))
sys.path.insert(0, str(WT / 'tools'))
import verify
rows = [row for c in lock['releases'] for row in verify.metadata_inventory(WT, c)]
rows.extend([{'path': '.nojekyll', 'bytes': 0, 'sha256': sha(b'')}, *({'path': name, 'bytes': (WT / name).stat().st_size, 'sha256': sha((WT / name).read_bytes())} for name in ['index.html', 'releases/index.html'])])
rows.sort(key=lambda row: row['path'])
verify.validate_rows(rows)
oldinv = json.loads((BASE / 'expected-inventory.json').read_bytes())
inv = dict(oldinv, files=rows)
(WT / 'expected-inventory.json').write_bytes(encoded(inv))
lock.update(expectedInventorySha256=sha(encoded(inv)), expectedFiles=len(rows), expectedBytes=sum(x['bytes'] for x in rows))
(WT / 'source-lock.json').write_bytes(encoded(lock))
assert lock['releases'][0] == oldlock['releases'][0]
oldcanon = [x for x in oldinv['files'] if x['path'].startswith('releases/v0.57.2/')]
assert len(oldcanon) == 660 and all(x in rows for x in oldcanon)
newindex = {x['path']: x for x in rows}
assert [x['path'] for x in oldinv['files'] if newindex.get(x['path']) != x] == ['index.html']
verify.locked_inputs(WT)
authority = {
    'format': 'revealline-archive-append-candidate.v1',
    'status': 'PREPARED_FOR_ROOT_REVIEW_NOT_COMMITTED_OR_DEPLOYED',
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'predecessorArchiveCommit': git('rev-parse', 'HEAD').decode().strip(),
    'predecessorArchiveTree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
    'sourceControllerAtPreparation': review['sourceController'],
    'archiveId': 'archive-16', 'sourceRepository': 'mekhovov/revealline',
    **{k: review[k] for k in ['version', 'sourceRevision', 'sourceTree', 'tagObject', 'releaseId', 'publishedAt']},
    'assets': review['assets'], 'metadataOrigins': review['metadata'],
    'preservedCanonicalRows': len(oldcanon),
    'capacity': {'files': len(rows), 'bytes': lock['expectedBytes'], 'budgetBytes': lock['budgetBytes'], 'headroomBytes': lock['budgetBytes'] - lock['expectedBytes']},
    'archiveInfrastructureCommit': None, 'archiveDeploymentId': None,
    'archiveHttpAcceptance': None, 'archiveNativeAdmission': None,
    'scope': 'Small original metadata and derived inventory only. Existing original payloads, source-lock cohort, input authority, release-explorer bridge and all40 controller evidence pins preserved. Root review, commit, hosted/public/native verification and successor admission remain pending.',
}
(WT / 'input-authority-v0600.json').write_bytes(encoded(authority))
s = (WT / 'README.md').read_text()
s = s.replace('download one original ZIP; validate every ZIP member', 'download both original ZIPs; validate every ZIP member')
s = s.replace('Canonical play is `releases/v0.57.2/site/game/`. The exact 655 manifest rows plus eight declared wrapper/metadata files form the pinned 663-file inventory.', f'Canonical play is available at `releases/v0.57.2/site/game/` and `releases/v0.60.0/site/game/`. Their original manifest rows and declared wrapper/metadata files form the pinned {len(rows):,}-file / {lock["expectedBytes"]:,}-byte inventory.')
s += f'''
## Prepared v0.60.0 append

The added original v0.60.0 is frozen source `{review['sourceRevision']}`, tree `{review['sourceTree']}`, annotated tag `{review['tagObject']}`. Its four small metadata/qualification bodies match the actual published asset digests. `input-authority-v0600.json` records these authorities separately from the unchanged earlier `input-authority.json`.

All 660 v0.57.2 canonical rows remain byte-identical. Only the archive's shared index changes among old deployed rows; the release-explorer bridge and production tools remain unchanged. The combined original artifact leaves {lock['budgetBytes'] - lock['expectedBytes']:,} bytes below the unchanged 800,000,000-byte cap. Source/distribution payloads are not downloaded locally or rebuilt by this preparation.

This append is a prepared candidate, not a new archive admission. Root review, commit, the existing hosted main-push workflow, complete public-byte verification and scoped old/new edition browser observations remain required. The earlier v0.57.2 limitations remain historical facts; no P05, offline, physical-device or human-playtest completion is implied.
'''
(WT / 'README.md').write_text(s)
p = WT / 'tools/test_prepare.py'
s = p.read_text()
needle = "self.assertEqual((lock['expectedFiles'], lock['expectedBytes']), (663, 312625191))"
assert s.count(needle) == 1
s = s.replace(needle, f"self.assertEqual((lock['expectedFiles'], lock['expectedBytes']), ({len(rows)}, {lock['expectedBytes']}))")
needle = "self.assertEqual(len(lock['releases']), 1)"
assert s.count(needle) == 1
s = s.replace(needle, "self.assertEqual([r['version'] for r in lock['releases']], ['v0.57.2', 'v0.60.0'])")
needle = "self.assertEqual(len(rows), 1)\n        self.assertEqual(rows[0]['bytes'], 64747)"
assert s.count(needle) == 1
s = s.replace(needle, "self.assertEqual(len(rows), 2)\n        self.assertEqual(rows[0]['bytes'], 64747)\n        successor = lock['releases'][1]\n        self.assertEqual(successor['tagObject'], '" + review['tagObject'] + "')\n        self.assertEqual(successor['sourceRevision'], '" + review['sourceRevision'] + "')\n        self.assertEqual(successor['sourceTree'], '" + review['sourceTree'] + "')\n        self.assertEqual(successor['sourceQualification'], " + repr(cohort['sourceQualification']) + ")\n        self.assertEqual(rows[1]['bytes'], " + str(cohort['sourceQualification']['bytes']) + ")")
p.write_text(s)
print(json.dumps({'files':len(rows),'bytes':lock['expectedBytes'],'budgetBytes':lock['budgetBytes'],'headroomBytes':lock['budgetBytes']-lock['expectedBytes'],'oldCanonicalRowsUnchanged':len(oldcanon),'inventorySha256':lock['expectedInventorySha256']}))
