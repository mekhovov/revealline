# Archive16 v0.60.0 retention — root review handoff

The candidate is **unstaged and uncommitted** in `archive16-worktree/`, branch `codex/archive16-retain-v0600`. No commit, push, PR, merge, workflow dispatch, deployment, main-controller edit or large ZIP/TAR download was performed.

- Actual remote base: `275a3061e8233a2c1046a494e613dca03783e231`, tree `d2ff87cdf8b6b6d3aa01b761adb1ec947b8f9b6d`; rechecked unchanged after preparation.
- Computed candidate tree: **`6c72f5cf8a82b51fc635dcc4c433c62cfb22c0bf`**. Derived directly from ordinary file bytes; no Git index/tree object or commit was written for this calculation.
- `candidate.patch`: SHA-256 **`08184ce7f17930f923976deabcf07751b4a84540a3feb72b9b2c6dc93b468e82`**.
- `candidate-review.json` pins all eleven changed bodies and preservation checks; `archive16-originals/` contains all sixteen baseline source bodies. No repository instructions file was present in that finite tree.

## Exact changes and capacity

Six modified paths: `.github/workflows/deploy.yml` (fetch the second original tag), `README.md`, `expected-inventory.json`, `index.html`, `source-lock.json`, `tools/test_prepare.py` (retain old assertions and add the new exact cohort).

Five additions: `input-authority-v0600.json` and the four original `metadata/v0.60.0/{distribution.zip.sha256,manifest.json,release.json,source-qualification.json}` bodies.

The derived artifact has **1,347 files / 625,710,011 bytes**, leaving **174,289,989 bytes** under the actual unchanged **800,000,000-byte archive cap**. Its inventory SHA-256 is `c02d6bf74f731a5e646159434325153ed79e841e7ff58c7f15b580be3440aeaa`. The hosted free-space floor remains **3 GiB**. The earlier main-release route compared against main's 950 MB cap; `../p05-team-v0601-release-route/ARCHIVE16-ACTUAL-ADDENDUM.md` corrects that distinction without erasing its earlier cutoff.

All **660 original v0.57.2 canonical rows** remain exact, including every original manifest/worker/qualification body. Only the shared archive index changes among old deployed rows. Old metadata, `input-authority.json`, the accessible main-Explorer bridge, production preparation/verifier and corruption guards are unchanged. All **40 existing main-controller evidence pins** were reread and matched; their bodies and current admission were not changed. A later successor admission must preserve these pins and stay within the existing 64-pin limit.

## Actual original authorities and checks

The four new metadata files came from committed main `587f4e75cc9dde7ae0db7ffac34320761b94588c` and match fresh published asset sizes/digests from release **390511341**. The actual annotated v0.60.0 tag is `03bf36ae9a36f5e776464bd5ef75043cfba727d7`, peeling to source `170508f11dd41204b7e24917a823f21701c15961`, tree `287ea0fddf97f594af0ce9eba452a24dc5f507c7`. All nine asset descriptors and small API originals/exit receipts are retained under `originals/`. Original distribution is 313,121,021 bytes, SHA-256 `297e2b39949310ad831706775201f6f3c6553589a1d389997d6ca2a54f70e184`; it was **not** downloaded locally.

- Existing archive suite: **20 passed**, tiny fixtures only; `checks/archive/` retains full stdout/stderr/exit. Intentional rejected-tag messages are expected passing refusal cases.
- Exact pinned extractor at `0594b60136db000c9d6c87527c7885c2c51a2562`: **4 synthetic corruption checks passed**, `checks/extractor/`. No game build or payload extraction ran locally.
- `locked_inputs` reconciled every derived row against the originals. Hunk/line review, `git diff --check`, reverse patch application check and empty-index check passed. The only edit after those runtime checks was README wording; production/test bytes are unchanged.
- Independent static review is retained at `packet/independent-review.md`, including its final README binding. This is not root approval or hosted/public/browser acceptance.

GitHub's Release API currently reports `immutable:false`; the project preserves the published bytes through exact pins, without claiming GitHub-enforced immutability. Recheck actual assets before the hosted work if circumstances change.

## Minimal root-owned execution

After reviewing the exact eleven paths and originals, use this existing branch. Recheck remote main first; stop if it no longer matches the base.

```sh
RL_ARCHIVE=/Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/p05-v0601-retention-plan/archive16-worktree
test "$(gh api repos/mekhovov/revealline-archive-16/git/ref/heads/main --jq .object.sha)" = 275a3061e8233a2c1046a494e613dca03783e231
git -C "$RL_ARCHIVE" add -- .github/workflows/deploy.yml README.md expected-inventory.json index.html source-lock.json tools/test_prepare.py input-authority-v0600.json metadata/v0.60.0/distribution.zip.sha256 metadata/v0.60.0/manifest.json metadata/v0.60.0/release.json metadata/v0.60.0/source-qualification.json
git -C "$RL_ARCHIVE" diff --cached --check
```

Rehash each staged body against `candidate-review.json`, inspect the related hunks, and require `git write-tree` to equal the computed candidate tree above before committing.

```sh
git -C "$RL_ARCHIVE" commit -m 'Retain immutable v0.60.0 in Archive16'
git -C "$RL_ARCHIVE" push -u origin codex/archive16-retain-v0600
gh pr create --repo mekhovov/revealline-archive-16 --base main --head codex/archive16-retain-v0600 --title 'Retain v0.60.0 alongside v0.57.2' --body-file /Users/oleksandr.mekhovov/work/my_projects/go_test/.cache/p05-v0601-retention-plan/pr-body.md
```

Bind the actual new PR/head, independently review it, then use normal merge with `--match-head-commit`. Future IDs are intentionally absent:

```sh
gh pr merge "$RL_ACTUAL_ARCHIVE_PR" --repo mekhovov/revealline-archive-16 --merge --match-head-commit "$RL_ACTUAL_ARCHIVE_HEAD"
gh run list --repo mekhovov/revealline-archive-16 --workflow deploy.yml --branch main --event push --limit 5 --json databaseId,headSha,status,conclusion
```

One main push automatically invokes the existing archive workflow. **Do not also dispatch it manually.** The workflow has main-only jobs, an unchanged pinned extractor, serialized execution and complete reread. It retains the small `archive16-verification-receipts` artifact; collect actual commit/tree/run/deployment/status/artifact originals and the complete expected inventory, not the large Pages payload. A necessary retry after a recorded failure follows the existing explicit workflow-dispatch route.

Next required gates: bounded full public-byte audit of all 1,347 expected files, fresh authorities, and actual old/new edition plus main-Explorer browser checks. Only after those pass may root prepare the successor Archive16 admission/allocation and v0.60.1 current selector. Preserve all old pins, demoting obsolete current evidence roles to reference when the strict schema requires it. No future archive infrastructure/deployment ID or admission is invented by this proposal.
