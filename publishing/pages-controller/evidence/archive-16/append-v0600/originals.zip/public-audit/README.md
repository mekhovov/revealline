# Archive16 append: bounded audit and admission handoff

Prepared only. No public inventory audit, native acceptance, controller admission, source/index change or remote mutation was performed by this task. Root owns those operations. The Team v0.60.1 helper peer review found no actionable issues; see `../p05-team-public-audit-822f3290/peer-route-review.md`.

## Actual inputs and checks

- Archive commit `fcea949bca18193e9303143766a6eecdf4cb8b61`, tree `6c72f5cf8a82b51fc635dcc4c433c62cfb22c0bf`; held local source commit `a509feaa280b1bb1cb9efb90457e2de7af4e3775` has that exact tree.
- Automatic run `35200608771` completed successfully; deployment `6498838394`, latest successful status `18464928886` links that run/site/commit.
- Original receipt artifact `10487357957`, `archive16-verification-receipts`, 70,961 bytes, SHA256 `99793cac42a6fe5fc4c80662e7d51a7c2d5dbd3fe668df2e3f81e0bd0323a03f`. Only this small ZIP was downloaded; the 523,054,308-byte Pages artifact was explicitly excluded. Original API outputs/commands/stderr and ZIP are under `../p05-v0601-retention-plan/audit-binding-originals/`.
- Exact candidate: 1,347 files / 625,710,011 bytes; inventory SHA256 `c02d6bf74f731a5e646159434325153ed79e841e7ff58c7f15b580be3440aeaa`. All 660 old v0.57.2 canonical rows remain equal. The 684 v0.60.0 rows use the original source `170508f11dd41204b7e24917a823f21701c15961`, tree `287ea0fddf97f594af0ce9eba452a24dc5f507c7`.
- `execution-request.proposed.json` SHA256 `fa15798f8708a68b2255b4cbe8c35ff904fd147390e8e2ed3f78766aa26760ed` binds the actual seven authority/receipt originals and remains `reviewed:false`. No reviewed request was created by this task.
- All 17 offline fixtures and candidate-only check passed. Unreviewed request rejection passed. Actual local receipt intake passed with **only the review boolean mocked in memory**; this is preparation evidence, not authorization/public acceptance. See `checks/`.

## Minimal adaptation

`predecessor/` preserves the accepted Archive15 auditor, binding, fixture tests, observer, corrected row-review and acceptance originals. `http-tool-adaptation.diff` has only site/cohort/count/source/input-pin substitutions. `transport-preservation.json` proves AST equality after exact constant normalization: same descriptor checks, streaming SHA256, one-byte oversize cutoff, redirect refusal, MIME allowlist, 64 KiB chunks, 25-second socket/90-second attempt/1,800-second total limits, three attempts, 4–8 workers, retained attempt records and post-audit input/authority reconciliation. The live observer changes only archive endpoint labels. No broad framework or weaker policy was added.

## Root execution after independent review

1. Review the exact diff, original authority/receipt pins and proposed request SHA. Create a separate `execution-request.reviewed.json` from the proposed request with only `reviewed` changed to `true`; keep the proposal untouched. Record the reviewed request's SHA in root's review record.
2. Run readiness (no network):

   ```sh
   python3 .cache/p05-archive16-public-audit/http-tools/http_audit.py
   ```

3. Save before authorities, run the complete audit once, then save after authorities (do not replace a failed run):

   ```sh
   python3 .cache/p05-archive16-public-audit/collect-live.py before
   python3 .cache/p05-archive16-public-audit/http-tools/http_audit.py --run --workers 6
   python3 .cache/p05-archive16-public-audit/collect-live.py after
   ```

   Capture each command's exit/stdout/stderr as an original. The audit creates a unique `http/http-*` directory and never stores game payloads. No base/inventory override exists. The two authority observations must still name this same main/run/deployment/latest successful status; abort on drift.

4. Reconcile the actual final rows and attempts using the accepted Archive15 corrected rule retained in `predecessor/row-review-corrected.json`: compare **path iterables**, not descriptor mapping values, against all 1,347 unique inventory paths. Require every final row's exact URL, bytes, SHA and status; count actual failed attempts/retries separately; require no failed/skipped/uninspected files; compare 660 old rows; pin exact report/request/scripts/API originals and before/after observations. The auditor retains its unchanged built-in final coverage and binding reconciliation. Archive15's extra row review was an independently recorded review, not a reusable standalone script; this packet does not invent one or claim it has executed.

## Separate native and controller admission

Root native checks should record both canonical routes (`releases/v0.57.2/site/game/`, `releases/v0.60.0/site/game/`), actual route identity/rendering and performed interactions, plus the shared release explorer bridge. Respect the archive's session-only warning; do not infer save migration, offline/device/controller/audio or full P03/P05 acceptance from startup or HTTP proof. Preserve provider failures if any and add later success as separate evidence.

After real HTTP reconciliation and root native acceptance, follow the accepted layout in `../p05-v060-publisher-plan/`:

- Keep all 40 old Archive16 evidence bodies/paths/hashes. Only old inventory/http/browser `kind` roles become `reference` where the strict schema requires a single current authority. Proposed allocation becomes `["v0.57.2", "v0.60.0"]`; other archives remain equal.
- Add a compact ten-pin package under `evidence/archive-16/append-v0600/`: current inventory (`inventory`), actual HTTP report (`http`), source lock, actual row review, hosted completion, originals index, originals ZIP, root native observations, root native acceptance (all `reference`), and the actual browser admission (`browser`). This yields 50 pins, below the unchanged 64 limit. No future bodies/hashes are allocated now.
- Preserve exact small original files in the compact ZIP and reopen/re-hash every member using its index. Include actual publication/receipt/API/audit attempts/results, preserved failed steps, and native originals; no game/source payload. Explicitly force-stage only the reviewed originals ZIP if the ignore rule excludes it.
- Use the production `loadCatalog` and `validateAdmissions(..., {requireBrowser:true})` route from the prior cache validator, with the **actual current main** metadata/evidence and new admission. Keep 71 predecessor catalog entries unchanged until the root-owned actual v0.60.1 metadata is available; a real successor adds the 72nd. Recheck the current main base before composition rather than replacing a newer complete publication.json.
- Root owns current selector, publication PR/deployment, main public audit and final release acceptance. Successful Archive16 hosting alone does not close the Team release or wider P05.
