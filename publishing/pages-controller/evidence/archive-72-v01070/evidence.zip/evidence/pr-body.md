Preserve published v0.107.0 from its original GitHub Release ZIP in Archive72, using the accepted Archive71 extraction and verification scaffold. The generated inventory pins 1,144 files / 595,435,481 bytes, including the main release-explorer bridge; no game is rebuilt.

Validation: configure --check, explicit immutable-tag fetch coverage and all 20 archive infrastructure tests pass. The initial stale donor-fixture failure and its correction remain in preparation evidence. Hosted extraction, deployment, complete public-byte audit and scoped native admission remain pending. Original v0.107 source qualification retains its automated-test waiver; archive checks do not replace game qualification.

This PR does not modify the main Pages selector or publish v0.108.0.
