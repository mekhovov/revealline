"""Independent finite reconciliation of the retained Archive72 public audit."""
from pathlib import Path
import collections
import hashlib
import json
import subprocess
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / 'public-audit/http/http-20260924T230512Z-b1707212'
BASE = 'https://mekhovov.github.io/revealline-archive-72/'
COMMIT = '12f9b350f9461d7721ba389af9c7590d6b5f621f'
TREE = '4449eead1322886eea88718941ace998f4b74e8d'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def lines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]

def main():
    inventory_raw = (ROOT / 'candidate/expected-inventory.json').read_bytes()
    inventory = json.loads(inventory_raw)
    expected = {row['path']: row for row in inventory['files']}
    assert len(expected) == len(inventory['files']) == 1144
    assert sum(row['bytes'] for row in expected.values()) == 595435481
    assert inventory['base'] == BASE
    assert (AUDIT / 'expected-inventory.json').read_bytes() == inventory_raw
    report = read(AUDIT / 'http-report.json')
    results = lines(AUDIT / 'http-results.jsonl')
    attempts = lines(AUDIT / 'http-attempts.jsonl')
    assert report['status'] == 'PASS' and report['archiveCommit'] == COMMIT
    assert report['archiveTree'] == TREE and report['sourceCheckoutCommit'] == COMMIT
    assert report['runId'] == 36070705920 and report['deploymentId'] == 6649956472
    assert report['deploymentStatusId'] == 18809597530 and report['receiptArtifactId'] == 10837907888
    assert report['expectedInventorySha256'] == sha(inventory_raw)
    assert report['files'] == len(results) == len(expected)
    assert {row['path'] for row in results} == set(expected)
    assert report['expectedBytes'] == report['verifiedBytes'] == 595435481
    assert report['failedFiles'] == 0 and report['failures'] == report['skipped'] == []
    assert report['allFinalURLsExact'] and report['sourcePinsUnchanged']
    assert report['authorityError'] is None and not report['payloadFilesPersisted']
    assert not report['auditDeadlineExceeded']
    mimes = {'.html': {'text/html'}, '.mjs': {'text/javascript', 'application/javascript'}, '.js': {'text/javascript', 'application/javascript'}, '.css': {'text/css'}, '.json': {'application/json'}, '.webmanifest': {'application/manifest+json','application/json'}, '.png': {'image/png'}, '.jpg': {'image/jpeg'}, '.svg': {'image/svg+xml'}, '.woff2': {'font/woff2'}, '.ttf': {'font/ttf','application/x-font-ttf','application/font-sfnt'}, '.txt': {'text/plain'}, '.md': {'text/plain','text/markdown','text/x-markdown','application/octet-stream'}, '.pb': {'application/octet-stream','text/plain'}, '.rlmedia': {'application/octet-stream'}, '.rlstory': {'application/octet-stream'}, '.sha256': {'application/octet-stream','text/plain'}, '': {'application/octet-stream','text/plain'}}
    by_path = collections.defaultdict(list)
    for item in attempts:
        assert item['path'] in expected
        by_path[item['path']].append(item)
    assert set(by_path) == set(expected)
    mime_counts = collections.Counter()
    for result in results:
        pin = expected[result['path']]
        attempt_rows = by_path[result['path']]
        assert [x['attempt'] for x in attempt_rows] == list(range(1, len(attempt_rows)+1))
        assert 1 <= len(attempt_rows) <= 3 and result == attempt_rows[-1]
        assert result['status'] == 'PASS' and result['requestStarted']
        assert result['statusCode'] == 200
        assert result['url'] == result['finalURL'] == BASE + quote(pin['path'], safe='/')
        assert result['bytes'] == result['expectedBytes'] == pin['bytes']
        assert result['sha256'] == result['expectedSha256'] == pin['sha256']
        assert result['contentEncoding'].strip().lower() in ('', 'identity')
        if result['contentLength'] is not None:
            assert int(result['contentLength']) == pin['bytes']
        mime = result['contentType'].split(';',1)[0].strip().lower()
        assert mime in mimes[Path(pin['path']).suffix.lower()]
        mime_counts[mime] += 1
    assert report['attempts'] == len(attempts)
    assert report['failedAttempts'] == sum(x['status'] != 'PASS' for x in attempts)
    assert report['retriedFiles'] == sum(len(x)>1 for x in by_path.values())
    manifest = read(ROOT / 'candidate/metadata/v0.107.0/manifest.json')
    for row in manifest['files']:
        assert expected['releases/v0.107.0/site/'+row['path']] == {**row, 'path':'releases/v0.107.0/site/'+row['path']}
    assert len(manifest['files']) == 1136
    for filename in ['release.json','manifest.json','distribution.zip.sha256','source-qualification.json']:
        raw = (ROOT/'candidate/metadata/v0.107.0'/filename).read_bytes()
        urlpath = 'releases/v0.107.0/'+('site/' if filename in ['manifest.json','distribution.zip.sha256'] else '')+filename
        assert expected[urlpath]['bytes'] == len(raw) and expected[urlpath]['sha256'] == sha(raw)
    assert subprocess.check_output(['git','-C',str(ROOT/'candidate'),'rev-parse','HEAD'],text=True).strip() == COMMIT
    assert subprocess.check_output(['git','-C',str(ROOT/'candidate'),'rev-parse','HEAD^{tree}'],text=True).strip() == TREE
    assert subprocess.check_output(['git','-C',str(ROOT/'candidate'),'status','--porcelain'],text=True) == ''
    for row in read(ROOT/'evidence/prepared-source-pins.json')['files']:
        raw = (ROOT/'candidate'/row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    result = {'status':'PASS','scope':'Every retained result and attempt reconciled with exact source inventory, original manifest/metadata and allowed MIME; no new network or browser requests.','archiveCommit':COMMIT,'archiveTree':TREE,'files':len(results),'bytes':sum(x['bytes'] for x in results),'attempts':len(attempts),'failedAttempts':report['failedAttempts'],'retriedFiles':report['retriedFiles'],'preservedPriorAcceptedPaths':0,'originalManifestRows':1136,'releaseCohortRows':1141,'rootSupportRows':3,'mimeCounts':dict(sorted(mime_counts.items())),'reportSha256':sha((AUDIT/'http-report.json').read_bytes()),'inventorySha256':sha(inventory_raw),'sourcePinsUnchanged':True}
    output=ROOT/'evidence/http-row-reconciliation.json'
    with output.open('x') as f:
        f.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

if __name__ == '__main__':
    main()
