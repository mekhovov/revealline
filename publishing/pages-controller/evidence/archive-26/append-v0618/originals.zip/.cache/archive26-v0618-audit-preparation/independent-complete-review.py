from pathlib import Path,PurePosixPath
from collections import Counter
from urllib.parse import quote
import json,hashlib,datetime,ast,subprocess,os,shutil
R=Path.cwd();A=R/'.cache/archive26-v0618-public-audit';N=R/'.cache/archive26-v0618-native';P=R/'.cache/archive26-v0618-audit-preparation';sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_bytes())
def pin(p):
 b=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(b),'sha256':sha(b)}
row=read(A/'row-review.json');assert row['status']=='PASS' and row['errors']==[]
for x in row['evidencePins']:
 b=(A/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
req=read(A/'execution-request.reviewed.json');assert sha((A/'execution-request.reviewed.json').read_bytes())==row['executionRequestSha256'] and req['reviewed'] is True
reports=list(A.glob('http/*/http-report.json'));assert len(reports)==1;H=reports[0].parent;report=read(reports[0]);iv=read(H/'expected-inventory.json')['files'];assert (H/'expected-inventory.json').read_bytes()==(A/'inputs/expected-inventory.json').read_bytes()
results=[json.loads(x) for x in (H/'http-results.jsonl').read_text().splitlines()];attempts=[json.loads(x) for x in (H/'http-attempts.jsonl').read_text().splitlines()];expected={x['path']:x for x in iv}
assert len(iv)==len(expected)==len(results)==len(attempts)==1399 and Counter(x['path'] for x in results)==Counter(expected.keys())==Counter(x['path'] for x in attempts)
byattempt={x['path']:x for x in attempts};code=ast.parse((A/'http-tools/http_audit.py').read_text());mimes=next(ast.literal_eval(n.value) for n in code.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MIMES' for t in n.targets));base='https://mekhovov.github.io/revealline-archive-26/'
for x in results:
 e=expected[x['path']];assert x==byattempt[x['path']] and x['attempt']==1 and x['status']=='PASS' and x['statusCode']==200 and x['requestStarted'] is True
 assert x['url']==x['finalURL']==base+quote(x['path'],safe='/');assert x['bytes']==x['expectedBytes']==e['bytes'] and x['sha256']==x['expectedSha256']==e['sha256'];assert x['contentType'].split(';')[0].strip().lower() in mimes[PurePosixPath(x['path']).suffix.lower()]
assert sum(x['bytes'] for x in results)==626777746==report['verifiedBytes']==report['expectedBytes'];assert report['attempts']==1399 and report['failedAttempts']==report['retriedFiles']==report['failedFiles']==0 and report['skipped']==[] and report['allFinalURLsExact'] and report['sourcePinsUnchanged'] and report['payloadFilesPersisted'] is False
oldraw=(A/'inputs/prior-expected-inventory.json').read_bytes();prior={x['path']:x for x in json.loads(oldraw)['files']};assert sha(oldraw)=='47ef28d187e21adc30d38934bab98d23280ee4a82233586772223151b8993d9d'
E={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0'};W=R/'.cache/worktrees/archive26-v0618-append';assert subprocess.check_output(['git','show','6189d37ed382fce79a28e7a464c5e7384429ab05:expected-inventory.json'],cwd=W,env=E)==oldraw
unchanged={k for k,v in prior.items() if expected.get(k)==v};changed=set(prior)-unchanged;added=set(expected)-set(prior);releases={k for k in unchanged if k.startswith('releases/v0.61.7/')};assert len(prior)==701 and len(unchanged)==700 and len(releases)==698 and unchanged-releases=={'.nojekyll','releases/index.html'} and changed=={'index.html'} and len(added)==698 and sum(expected[k]['bytes'] for k in added)==313389738
for key,v in [('priorInventoryRows',701),('preservedOldCanonicalRows',700),('preservedPriorReleaseRows',698),('preservedRootSupportRows',2),('changedPriorPaths',['index.html']),('newRows',698),('newBytes',313389738)]:assert report[key]==v
assert row['oldCanonicalRowsPreserved']==700 and row['newRows']==698
for k in ['archiveCommit','archiveTree','sourceCheckoutCommit','runId','deploymentId','deploymentStatusId','receiptArtifactId']:assert row[k]==report[k]==req[k]
stages=[]
for prefix in ['before','after']:
 paths=list((A/'live-authorities').glob(prefix+'-*/result.json'));assert len(paths)==1;p=paths[0];v=read(p);assert v['status']=='PASS_LIVE_IDENTITIES_UNCHANGED' and not v['errors'] and v['executionRequestSha256']==row['executionRequestSha256']
 for x in v['pins']:
  b=(p.parent/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 stages.append((p,v))
assert stages[0][1]['at']<report['startedAt']<report['verifiedAt']<stages[1][1]['at']
for n in ['main','run','deployment','statuses']:assert (stages[0][0].parent/(n+'.json')).read_bytes()==(stages[1][0].parent/(n+'.json')).read_bytes()
m=read(N/'manifest.json');assert len(m['files'])==23 and len({x['path'] for x in m['files']})==23
for x in m['files']:
 b=(N/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
assert sum(x['bytes'] for x in m['files'])==1430817
nr=read(N/'root-review.json');p=nr['manifest'];assert p==pin(N/'manifest.json') and nr['status']=='ROOT_SCOPED_ARCHIVE_NATIVE_PASS'
native=read(N/'review.json');assert native['archiveCommit']==row['archiveCommit'] and native['archiveTree']==row['archiveTree'] and native['pagesRun']==row['runId'] and native['versionSources']=={'v0.61.7':'b3262eb02a998c50354758ba922324d023138875','v0.61.8':'0ae4330b8a87d332051db112f5e09b7c3cbef9fa'}
obs=read(N/'observations.json');byname={x['name']:x for x in obs};assert len(byname)==len(obs)
for name,size in [('13-v618-picker-portrait',[390,844]),('14-v618-picker-landscape',[844,390]),('15-v618-picker-return-portrait',[390,844])]:
 o=byname[name];assert o['active']=='still-media-file' and o['viewport']==size and '46655 original bytes verified' in o['status']
 boxes={x['id']:x for x in o['rects']};rail=boxes['still-media-operations'];label=boxes['still-media-file-label'];field=boxes['still-media-file'];assert label['y']>rail['bottom'] and field['y']-7>rail['bottom'] and field['bottom']+7<=size[1] and field['value'].endswith('revealline-owned-preview.png')
for name in ['16-v618-escape-opener','17-v618-close-opener']:assert byname[name]['active']=='still-host-open'
assert '2 retained image records' in native['mediaRecordsBeforeAfter'] and 'generation 2' in native['mediaRecordsBeforeAfter']
result={'status':'INDEPENDENT_LOCAL_COMPLETE_ROWS_AND_NATIVE_PINS_PASS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archiveCommit':row['archiveCommit'],'archiveTree':row['archiveTree'],'runId':row['runId'],'deploymentId':row['deploymentId'],'deploymentStatusId':row['deploymentStatusId'],'receiptArtifactId':row['receiptArtifactId'],'files':1399,'verifiedBytes':626777746,'attempts':1399,'failedAttempts':0,'failedFiles':0,'retries':0,'skipped':0,'priorRows':701,'unchangedPriorRows':700,'unchangedReleaseRows':698,'unchangedSupportRows':2,'changedPriorPaths':['index.html'],'newRows':698,'newBytes':313389738,'rowEvidencePinsRehashed':len(row['evidencePins']),'nativeManifestMembersRehashed':23,'nativeManifestBytes':1430817,'nativeGeometryRecordsChecked':3,'nativeScope':'Read retained actual record/root scope; rehashed complete native bundle and independently checked Standard picker label/focus/viewport rectangles and Escape/Close opener. No new visual/native execution. Earlier safe writer refusal and screenshot/provider limits remain preserved.','limitations':['Root acceptance remains separate. No new API, body GET, test/helper execution or browser interaction.','Native review remains practice/Standard picker only, no campaign win, physical controls, Large, offline, audible, zero-write save or whole-phase claim.'],'pins':[pin(p) for p in [A/'row-review.json',reports[0],H/'http-results.jsonl',H/'http-attempts.jsonl',A/'inputs/prior-expected-inventory.json',N/'manifest.json',N/'review.json',N/'root-review.json',N/'observations.json',Path(__file__)]]}
out=A/'independent-peer.json';assert not out.exists() and shutil.disk_usage(R).free>512*1024**2;out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(pin(out)))
