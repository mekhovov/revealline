# Archive26 append audit handoff

Prepared for the actual merged Archive26 append of v0.61.8 alongside v0.61.7. This is local helper preparation and original terminal metadata retention; root owns receipt intake, public HTTP, native acceptance and the final seal.

- Actual merge: `93df1a6ee4dcf1c9a5eda6591d6c30e06a3cceff`, tree `c086f46401ceeffadc3b2e63b0483d66cf497f32`. Held checkout `ff1c6f46a5a70c4461a0abe5b3ecff764cbe9135` has that exact tree. The current-main guard is unchanged.
- Actual completed run `35365854149`, attempt 1; deployment `6528078392`; latest success status `18532460318`. The sole terminal collection and actual step logs are retained under `../archive26-v0618-hosted-intake/terminal-r1/`.
- Actual small artifact `10556890521`: 73,593 bytes, SHA-256 `0498a13f54484b009c8f3a63db188f61b8f9fa439b26525d6039181b6f2438c8`. No artifact body has been downloaded by this preparation.
- Current inventory: 1,399 rows / 626,777,746 bytes, SHA-256 `56f31e238cc2c459843db514139d5fa2bee2cf61dbf543cf2d2856f6468eca94`.
- Accepted prior inventory: 701 rows, SHA-256 `47ef28d187e21adc30d38934bab98d23280ee4a82233586772223151b8993d9d`. Exactly 700 descriptors are unchanged: 698 release rows and two root support rows. Only `index.html` changes. The 698 new release rows total 313,389,738 bytes. These are source inventory preservation facts; successful public HTTP still must verify every current row.

## Root binding and execution

1. Review `intake-proposal-ready.json`, the original terminal descriptors, `full-helper-adaptation.diff`, and `intake-actual-binding.diff`. Preserve the unbound and proposed requests. Promote the exact proposed small receipt request to `../archive26-v0618-hosted-intake/small-receipt-request.reviewed.json` with `reviewed: true` only after review. Execute the existing helper once:

   `python3 -B .cache/archive26-v0618-hosted-intake/intake-small-receipt.py <SHA256-of-reviewed-request>`

2. The helper requires the exact original ZIP digest and four allowed JSON members: receipt, inventory, and separate v0.61.7/v0.61.8 extraction receipts. It verifies both source/tag/distribution/manifest chains. Keep every actual intake output, including any refusal, without retry.

3. Fill only the actual `receiptZIP` pin in the preserved HTTP proposed-request successor. Root reviews all seven authority roles, promotes `execution-request.reviewed.json`, and binds its exact SHA in `run-reviewed-operations.py` and `reconcile-completed-rows.py`. Both currently retain `EXECUTION_REQUEST_SHA = None`, and no reviewed HTTP request is created by this preparation. Create the ordinary `internal-review.json` from the actual local binding validation result; do not copy a donor success.

4. Local authority/receipt validation may be run before HTTP with `PYTHONPATH=.cache/archive26-v0618-public-audit/http-tools python3 -B -c 'from audit_binding import validate_execution_binding; validate_execution_binding()'`. This reads retained originals and exact held Git objects only. Root then runs the existing `run-reviewed-operations.py` once for before / full HTTP / after, followed by `reconcile-completed-rows.py` on its retained complete outputs.

Set `PYTHONDONTWRITEBYTECODE=1 GIT_NO_LAZY_FETCH=1 GIT_OPTIONAL_LOCKS=0` for local helper use. Do not repeat the completed terminal collector or add a second metadata source. Fresh before/after authority snapshots remain required by the audit workflow. Native acceptance is separate.

The inherited limits remain unchanged: terminal metadata retention 8 MiB, small intake 16 MiB, free reserve 512 MiB plus prospective bytes and 64 KiB; small ZIP below 2 MiB, expanded at most 1 MiB, member at most 512 KiB, one 45-second intake request. HTTP streams bodies without persisting payloads; socket 25 s, per-attempt 90 s, full audit 1,800 s, at most three attempts per row, six workers by the reviewed runner, no redirects, exact URL/MIME/size/hash checks. All failed attempts remain evidence.

Local checks: 27 inherited HTTP/preservation fixtures, eight intake refusal/allowlist fixtures, and finite `--prepare` all passed. No new generic framework, source edit, stage, commit, deployment, public audit or native action was performed. The previous accepted Archive26 seal is referenced only as the prior baseline, never as acceptance of this append.
