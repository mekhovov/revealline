from pathlib import Path
import ast, datetime, difflib, hashlib, json, os, re, shutil, subprocess

ROOT = Path(__file__).resolve().parents[2]
PREP = Path(__file__).resolve().parent
HTTP = ROOT / '.cache/archive26-v0618-public-audit'
INTAKE = ROOT / '.cache/archive26-v0618-hosted-intake'
WT = ROOT / '.cache/worktrees/archive26-v0618-append'
DONOR_HTTP = ROOT / '.cache/archive25-v0616-public-audit'
DONOR_INTAKE = ROOT / '.cache/archive25-v0616-hosted-intake'
sha = lambda b: hashlib.sha256(b).hexdigest()
env = {**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_OPTIONAL_LOCKS': '0'}
git = lambda *args: subprocess.check_output(['git', '-C', str(WT), *args], env=env)
merge_path = ROOT / '.cache/archive26-v0618-append-preparation/root-merge-r1/completion.json'
merge = json.loads(merge_path.read_bytes())
COMMIT = merge['commit']; TREE = merge['tree']; CHECKOUT = git('rev-parse', 'HEAD').decode().strip()
assert COMMIT == '93df1a6ee4dcf1c9a5eda6591d6c30e06a3cceff'
assert TREE == git('rev-parse', 'HEAD^{tree}').decode().strip() == 'c086f46401ceeffadc3b2e63b0483d66cf497f32'
assert git('status', '--porcelain', '--untracked-files=no') == b''
PRIOR = '6189d37ed382fce79a28e7a464c5e7384429ab05'
current = (WT / 'expected-inventory.json').read_bytes()
lock = (WT / 'source-lock.json').read_bytes()
prior_path = ROOT / '.cache/archive26-v0617-public-audit/inputs/expected-inventory.json'
prior = prior_path.read_bytes()
assert prior == git('show', PRIOR + ':expected-inventory.json')
assert current == git('show', CHECKOUT + ':expected-inventory.json')
assert lock == git('show', CHECKOUT + ':source-lock.json')
assert sha(current) == '56f31e238cc2c459843db514139d5fa2bee2cf61dbf543cf2d2856f6468eca94'
assert sha(prior) == '47ef28d187e21adc30d38934bab98d23280ee4a82233586772223151b8993d9d'

def used():
    return sum(p.stat().st_size for d in [PREP, HTTP, INTAKE] if d.exists() for p in d.rglob('*') if p.is_file())

def put(path, raw):
    assert not path.exists() and len(raw) < 1024**2
    assert used() + len(raw) <= 16*1024**2
    assert shutil.disk_usage(ROOT).free >= 512*1024**2 + len(raw) + 65536
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream: stream.write(raw)

def objput(path, obj): put(path, (json.dumps(obj, indent=2) + '\n').encode())
def pin(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(raw), 'sha256': sha(raw)}

strings = {
    'archive25-v0616': 'archive26-v0618', 'Archive25': 'Archive26',
    'ARCHIVE25': 'ARCHIVE26', 'archive25': 'archive26', 'archive-25': 'archive-26',
    'v0.61.5': 'v0.61.7', 'v0.61.6': 'v0.61.8',
    '1d1260e806244f0e4ce1d1bc02acc0d6328e5004': TREE,
    'a2c682106f640725af0ecd8045cf7e2e87fa50d755f2c5745279697a535ad33e': sha(current),
    '196ea8dae7d1c6fbce2b732737d64825f2aa61e1b7b6e30ebdd70f1d55b0b48d': sha(lock),
    'cf01f611c966af3289b56ed55bf3ae173ab30c99d15a786d6706a5fe0b2eff3a': sha(prior),
    '70eb8242670ab7e3518b2f8266ca07fef51ecf5c': PRIOR,
}
numbers = {'1398':'1399', '626758906':'626777746', '700':'701', '699':'700', '697':'698', '313383188':'313389738'}
pattern = re.compile('|'.join(re.escape(k) for k in sorted(strings, key=len, reverse=True)))
def adapt(text):
    text = pattern.sub(lambda m: strings[m.group()], text)
    return re.sub(r'\b(?:'+'|'.join(numbers)+r')\b', lambda m:numbers[m.group()], text)

spec = [(DONOR_HTTP / n, HTTP / n) for n in [
    'http-tools/audit_binding.py', 'http-tools/http_audit.py', 'http-tools/test_http_audit.py',
    'http-tools/test_preservation_output.py', 'collect-live.py']]
spec += [(DONOR_HTTP / (n+'.unbound'), HTTP / n) for n in ['run-reviewed-operations.py','reconcile-completed-rows.py']]
spec += [(DONOR_INTAKE / n, INTAKE / n) for n in ['collect-terminal.py','intake-small-receipt.py','test_intake.py']]
rows=[]; diffs=[]
for donor, target in spec:
    original = donor.read_bytes(); text = adapt(original.decode())
    if target.name == 'collect-terminal.py':
        text = text.replace("P=Path(__file__).resolve().parent;O=P/'terminal-r1';O.mkdir()", "P=Path(__file__).resolve().parent;O=P/'terminal-r1'")
        text = text.replace("COMMIT='dff3007d35edb7a1b528884f673219d0e6b8d7d6'", 'COMMIT='+repr(COMMIT))
        text = text.replace('RUN=35349533736', "RUN=None\nassert COMMIT and TREE and type(RUN) is int and RUN>0, 'Actual run must be bound before requests'\nO.mkdir()")
    if target.name == 'intake-small-receipt.py':
        text = text.replace("req['artifactId']==10548776809", "req['artifactId']==None")
        text = text.replace("req['artifactBytes']==73543 and req['artifactSha256']=='b91f70a48be5efd85fc3769155b53e9e231174702d927c1e82db93caf74b1649'", "req['artifactBytes']==None and req['artifactSha256']==None")
    ast.parse(text)
    relative = target.relative_to(HTTP if target.is_relative_to(HTTP) else INTAKE)
    category = 'http' if target.is_relative_to(HTTP) else 'intake'
    saved = PREP / 'originals' / category / relative
    put(saved, original);put(target, text.encode())
    diff = ''.join(difflib.unified_diff(original.decode().splitlines(True), text.splitlines(True), fromfile=str(donor.relative_to(ROOT)), tofile=str(target.relative_to(ROOT))))
    diff_path = PREP / 'diffs' / category / (str(relative)+'.diff');put(diff_path, diff.encode());diffs.append(diff)
    rows.append({'donor':pin(donor),'original':pin(saved),'adapted':pin(target),'diff':pin(diff_path)})
put(PREP/'full-helper-adaptation.diff',''.join(diffs).encode())
for d in [HTTP, INTAKE]:
    put(d/'inputs/expected-inventory.json',current);put(d/'inputs/source-lock.json',lock)
put(HTTP/'inputs/prior-expected-inventory.json',prior)

request = {'format':'revealline-archive26-http-request.v1','reviewed':False,'archiveCommit':COMMIT,
    'archiveTree':TREE,'sourceCheckoutCommit':CHECKOUT,'runId':None,'deploymentId':None,
    'deploymentStatusId':None,'receiptArtifactId':None,
    'pins':{k:None for k in ['main','commit','run','deployment','statuses','artifacts','receiptZIP']}}
objput(HTTP/'execution-request.unbound.json', request)
receipt_request = {'format':'revealline-archive26-small-receipt-request.v1','reviewed':False,
    'repository':'mekhovov/revealline-archive-26','archiveCommit':COMMIT,'archiveTree':TREE,
    'sourceCheckoutCommit':CHECKOUT,'runId':None,'deploymentId':None,'deploymentStatusId':None,
    'artifactId':None,'artifactBytes':None,'artifactSha256':None,'apiEndpoint':None,
    'outputRelativeToRetentionRoot':'hosted-originals/verification-receipts-original.zip',
    'expectedMembers':['receipt.json','expected-inventory.json','zip-receipt-v0.61.7.json','zip-receipt-v0.61.8.json'],
    'maxDownloadBytes':2097152,'maxUncompressedBytes':1048576,'maxMemberBytes':524288,
    'expectedFiles':1399,'expectedBytes':626777746,'inventorySha256':sha(current),'originalPins':[]}
objput(INTAKE/'small-receipt-request.unbound.json',receipt_request)
objput(PREP/'adaptation-record.json',{'status':'LOCAL_HELPER_ADAPTATION_ONLY','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'donor':'Accepted Archive25 v0.61.6 append, nonempty prior inventory','helpers':rows,
    'knownMerge':pin(merge_path),'sourceCheckout':{'path':str(WT),'commit':CHECKOUT,'tree':TREE,'trackedClean':True},
    'priorAcceptance':pin(ROOT/'.cache/archive26-v0617-public-audit/root-acceptance.json'),
    'inventoryPins':[pin(HTTP/'inputs'/n) for n in ['expected-inventory.json','source-lock.json','prior-expected-inventory.json']],
    'changes':'Archive identities, two cohort versions, exact pins, derived count constants and unbound future run/artifact/request literals only. Terminal unbound assertion added before output-directory creation. HTTP transport, retry, MIME and limits unchanged.',
    'noCurrentAcceptanceCopied':True,'networkRequests':0,'artifactBodyGETs':0,'managedBytes':used()})
print(json.dumps({'status':'ADAPTED_NOT_EXECUTED','helpers':len(rows),'managedBytes':used(),'actualArchiveCommit':COMMIT,'actualArchiveTree':TREE,'sourceCheckoutCommit':CHECKOUT}))
