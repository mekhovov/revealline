# Archive 26 v0.61.8 Still Media lock analysis

Read-only source/evidence review; no browser, storage, server, source, test or release action.

## Observed facts

- `observations.json` records **Another game tab owns saving… session-only** on Archive26 v0.61.8 Home before Still Media opens. The subsequent dialog says **Close the source game and finish its pack or backup operation, then retry**, with no verified media loaded.
- Coordinator reports closing that test tab, closing local connections and retrying in a fresh tab did not clear the condition. This review did not independently operate the browser.
- Earlier retained `.cache/p05-public-native-v0618/review.json` ends successful public picker cleanup on the main repository's **v0.61.8 Home**, after closing local-media connections. `root-native-review.json` confirms that earlier scoped pass.
- **Coordinator-reported resolution:** the release coordinator found its sole tab still on that main-path v0.61.8 Home (Start First Signal) and navigated it to the Archive26 index. A single fresh Still Media retry then succeeded with **2 image records, 2 revisions, generation 2**. The owned PNG subsequently previewed successfully at **768×576 / 46,655 verified bytes**. Rotation was still pending when this update was recorded; it is not claimed here.

## Exact source behavior

Source is local tag v0.61.8, commit `0ae4330b8a87d332051db112f5e09b7c3cbef9fa`.

- `game/ui/still-media-host.mjs:14–33` reads its module-relative `game/build-info.json`; the exact version becomes `release-${info.version}`. Only an actual 404 chooses dev. Main game `game/app.mjs:264–274,331–335` derives the same release channel. No archive project path is included.
- `still-media-catalog.mjs:13–26` uses `revealline.library.${channel}.v1.writer`. Lines 56–64 request that writer with `ifAvailable:true` and emit the observed sentence when no lock is obtained. The shipped host's default external-catalog path means this exact refusal is the outer **writer lock**, before catalogue inspection. The external host's backup-lock refusal has different wording (`external-chapter-host.mjs:107–110`); persistent backup recovery also has different messages. The generic observed sentence is not evidence of corrupt data or a stale journal.
- Main and archive project URLs are both `https://mekhovov.github.io`: project path changes do not create a new origin. The same exact release in the same browser storage context intentionally shares its writer, profile and installed-content authority across those paths. Different release versions, localhost ports or truly separate browser profiles do not share this lock.
- `profile-writer.mjs:31–66` holds one exclusive writer for the page lifetime. `app.mjs:363–370` claims it before Home. Home alone can therefore own the lease without a flight. A denied tab has a no-op release function and never obtains/retries the lease automatically.
- `app.mjs:434–435,1817–1836` releases the lease on pagehide, including persisted navigation. `1882–1890` keeps a BFCache return session-only rather than silently reclaiming it. The ordinary Pictures & stories link (`game/index.html:1601–1605`) is same-tab navigation, not target=_blank.
- Still Media **Close local connections** only retires that host's own managers/panel (`still-media-host.mjs:149–160,294–299`). It cannot release another game document's lifetime writer.

## Interpretation and ordinary recovery

The observed resolution supports expected **same-origin/same-channel writer exclusion**: the earlier main-path Home remained active in the coordinator's tab, and navigating that tab away allowed the immediate fresh retry. The Archive26 Home had already been denied before navigation; its own same-tab exit was not the blocking writer. No same-tab navigation defect is established. This conclusion combines the recorded source behavior with the coordinator's reported UI recovery; this lane did not query locks or operate the browser.

Inspect existing tabs/windows in the **same browser storage context** for v0.61.8 main/archived game pages (including the previous test's returned Home or an installed game window). Preserve any owned in-progress work, finish/cancel its ordinary pack/backup action if necessary, then navigate the identified test-owned game away or close it normally. Return directly to the intended Archive26 Still Media page and choose **Reload saved media and installed maps**, or close its dialog and choose **Open local media** again. Do not reopen v0.61.8 Home in a second tab immediately before retrying: it would reclaim the writer. Merely switching tabs or leaving a writer page hidden is not pagehide. Do not clear storage, delete journals, change the release channel, steal locks or bypass the catalogue guard. If no owner can be identified, retain the blocked gate and its evidence; the source alone does not authorize attributing a runtime regression.

## Pins

The known local v0.61.9 candidate's `game/ui/still-media-catalog.mjs` is byte-identical to v0.61.8 (5,423 B, SHA256 `3a829a3e80f2bfd44f344bcee2db2d759b0e77c86f404a7df9d41dda96f373d1`).

- `game/profile-writer.mjs`: 2372 B, SHA256 `54c871a6bb7bcb6acc15c9d120f66693cf69cfe9363ff82ebbee85aa7fcb78d0`.
- `game/ui/still-media-catalog.mjs`: 5423 B, SHA256 `3a829a3e80f2bfd44f344bcee2db2d759b0e77c86f404a7df9d41dda96f373d1`.
- `game/ui/still-media-host.mjs`: 12718 B, SHA256 `1b2005af8b02756affeb1f6795e524d26aa7bd0d56a8d3063405cd02e8847d8a`.
- `game/app.mjs`: 281027 B, SHA256 `e4cef90b6593435c30def4501d1c2e2aa2062bfe330bc2d920abc364bff84cfe`.
- `game/external-chapter-host.mjs`: 23797 B, SHA256 `0b4ac55f7f5c2341fbdcc402882a83644145dafb4ed0ffcd978a743ba14c7734`.
