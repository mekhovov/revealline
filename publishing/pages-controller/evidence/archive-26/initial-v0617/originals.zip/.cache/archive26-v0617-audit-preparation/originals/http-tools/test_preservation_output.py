"""Offline count/output regression; synthetic audit results do not qualify public bytes."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch
import audit_binding as binding
import http_audit as audit

class PreservationOutputTests(unittest.TestCase):
    def test_empty_prior_has_zero_preservation(self):
        _, rows, _ = binding.candidate_inventory()
        value = binding.derive_preservation(rows, [])
        self.assertEqual(value['preservedOldCanonicalRows'], 0)
        self.assertEqual(value['preservedPriorReleaseRows'], 0)
        self.assertEqual(value['preservedRootSupportRows'], 0)
        self.assertEqual(value['newRows'], 1398)

    def test_actual_prior_has_explicit_release_support_index_counts(self):
        _, rows, _ = binding.candidate_inventory()
        value = binding.preservation_metadata(rows)
        self.assertEqual(value, {
            'priorInventoryRows': 700, 'preservedOldCanonicalRows': 699,
            'preservedPriorReleaseRows': 697, 'preservedRootSupportRows': 2,
            'preservedRootSupportPaths': ['.nojekyll', 'releases/index.html'],
            'changedPriorPaths': ['index.html'], 'newRows': 698, 'newBytes': 313383188,
        })

    def test_changed_prior_pin_refuses(self):
        _, rows, _ = binding.candidate_inventory()
        with patch.object(binding, 'PRIOR_INVENTORY_SHA', '0' * 64):
            with self.assertRaisesRegex(ValueError, 'Prior inventory pin changed'):
                binding.preservation_metadata(rows)

    def test_removed_or_changed_prior_payload_and_duplicate_refuse(self):
        _, rows, _ = binding.candidate_inventory()
        old = json.loads((binding.ROOT / 'inputs/prior-expected-inventory.json').read_bytes())['files']
        target = next(r for r in old if r['path'].startswith('releases/v0.61.5/'))
        removed = [r for r in rows if r['path'] != target['path']]
        changed = [({**r, 'sha256': '0' * 64} if r['path'] == target['path'] else r) for r in rows]
        for current in [removed, changed, [*rows, rows[0]]]:
            with self.subTest(kind=len(current)), self.assertRaises(ValueError):
                binding.derive_preservation(current, old)

    def test_prepare_prints_actual_preservation_without_network(self):
        out = io.StringIO()
        with patch('sys.argv', ['http_audit.py', '--prepare']), contextlib.redirect_stdout(out), patch.object(audit.urllib.request, 'build_opener') as network:
            self.assertEqual(audit.main(), 0)
            network.assert_not_called()
        value = json.loads(out.getvalue())
        self.assertEqual(value['files'], 1398)
        self.assertEqual(value['bytes'], 626758906)
        self.assertEqual(value['preservedOldCanonicalRows'], 699)
        self.assertEqual(value['preservedPriorReleaseRows'], 697)
        self.assertEqual(value['preservedRootSupportRows'], 2)
        self.assertEqual(value['changedPriorPaths'], ['index.html'])
        self.assertEqual(value['newRows'], 698)
        self.assertEqual(value['networkRequests'], 0)

    def test_final_report_uses_same_derived_actual_counts_without_http(self):
        # Exercise report serialization only. All row outcomes below are injected
        # fixtures; transport verification is covered separately in test_http_audit.
        raw, rows, _ = binding.candidate_inventory()
        fixture_request = {k: 'offline-fixture' for k in ['archiveCommit', 'archiveTree', 'sourceCheckoutCommit', 'runId', 'deploymentId', 'deploymentStatusId', 'receiptArtifactId']}
        fixture = {'request': fixture_request, 'requestRaw': b'{}', 'requestSha256': hashlib.sha256(b'{}').hexdigest(), 'evidenceBodies': {}}
        def pinned():
            audit.COMMIT = fixture_request['archiveCommit']; audit.BINDING = fixture
            return raw, rows
        def checked(row, opener, record_attempt, **kwargs):
            value = {'path': row['path'], 'status': 'PASS', 'requestStarted': True, 'bytes': row['bytes'], 'attempt': 1, 'url': audit.BASE + row['path'], 'finalURL': audit.BASE + row['path']}
            record_attempt(value)
            return value
        with tempfile.TemporaryDirectory() as name:
            directory = Path(name); (directory / 'inputs').mkdir()
            shutil.copyfile(binding.ROOT / 'inputs/prior-expected-inventory.json', directory / 'inputs/prior-expected-inventory.json')
            with patch.object(audit, 'BASE_DIR', directory), patch.object(audit, 'pinned_inventory', pinned), patch.object(audit, 'validate_execution_binding', return_value=fixture), patch.object(audit, 'check_row', checked), patch.object(audit.urllib.request, 'build_opener', return_value=object()), patch('sys.argv', ['http_audit.py', '--run']), contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(audit.main(), 0)
            output = json.loads(next((directory / 'http').glob('*/http-report.json')).read_bytes())
            self.assertEqual(output['files'], 1398)
            self.assertEqual(output['expectedBytes'], 626758906)
            for key, value in binding.preservation_metadata(rows).items():
                self.assertEqual(output[key], value)

if __name__ == '__main__':
    unittest.main()
