from pathlib import Path
import ast,datetime,difflib,hashlib,json,re
D=Path(__file__).resolve().parent;R=D.parent.parent;P=D.parent/'p05-archive03-public-audit';C=D.parent/'p05-v0603-retention-plan/explorer-correction/candidate';sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def js(p,v):write(p,(json.dumps(v,indent=2)+'\n').encode())
names=['http-tools/http_audit.py','http-tools/audit_binding.py','http-tools/test_http_audit.py','collect-live.py','collect-hosted.proposed.py','run-reviewed-operations.py.template','reconcile-completed-rows.py.template']
replacements=[('7a8901a7632887104d8dcb7fec488543594a5771','a574fdae893f46de18c9108a55c8be220eb5dc19'),('d6f7c3558004d4b13109e7037b48192330aaa0fb','1eff31098cc79cf923f4429fe6dd8d97f520972a'),('00925a6e796ff920d3d9ea05e6006196251d70af','a58c47fe5d5c77c7acbb1d41c074dca1ede975c0'),('21557cb035c638f32693ce3f9a3b2e62ba61888e428ff9c25554bcbd2a1eb4ed',sha((C/'expected-inventory.json').read_bytes())),('eb46707413c59b14b50cb47b96f57f0aafcd5b69f16ed619ef09cfafb8685768',sha((C/'source-lock.json').read_bytes())),("r['path'] != ''","r['path'] != 'releases/index.html'"),("r['path']!=''","r['path']!='releases/index.html'"),("O=P/'audit-binding-originals'","O=P/'audit-explorer-originals'"),("'pr':3","'pr':4")]
diffs=[];pins=[]
class ClearConstants(ast.NodeTransformer):
 def visit_Constant(self,node):return ast.copy_location(ast.Constant(value=None),node)
for n in names:
 a=(P/n).read_bytes();write(D/'predecessor'/n,a);s=a.decode()
 for old,new in replacements:s=s.replace(old,new)
 s=re.sub(r'(?<![A-Za-z0-9_])783088453(?![A-Za-z0-9_])','783087639',s);b=s.encode();write(D/n,b)
 assert ast.dump(ClearConstants().visit(ast.parse(a)))==ast.dump(ClearConstants().visit(ast.parse(b))),n
 diffs.extend(difflib.unified_diff(a.decode().splitlines(True),s.splitlines(True),fromfile='predecessor/'+n,tofile=n));pins.append({'path':n,'originalBytes':len(a),'originalSha256':sha(a),'bytes':len(b),'sha256':sha(b)})
for name in ['expected-inventory.json','source-lock.json']:write(D/'inputs'/name,(C/name).read_bytes())
write(D/'inputs/predecessor-inventory.json',(P/'inputs/predecessor-inventory.json').read_bytes());write(D/'adaptation.diff',''.join(diffs).encode());js(D/'actual-run-selection.json',{'runId':35222747833})
js(D/'execution-request.pending.json',{'format':'revealline-archive03-http-request.v1','reviewed':False,'archiveCommit':'1eff31098cc79cf923f4429fe6dd8d97f520972a','archiveTree':'a574fdae893f46de18c9108a55c8be220eb5dc19','sourceCheckoutCommit':'a58c47fe5d5c77c7acbb1d41c074dca1ede975c0','runId':35222747833,'deploymentId':'UNBOUND_ACTUAL_DEPLOYMENT','deploymentStatusId':'UNBOUND_ACTUAL_STATUS','receiptArtifactId':'UNBOUND_ACTUAL_SMALL_RECEIPT','pins':'UNBOUND_ACTUAL_ORIGINALS'})
js(D/'preparation.json',{'status':'CACHE_ONLY_PREPARED_ROOT_REVIEW_REQUIRED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':pins,'ASTIdenticalIgnoringLiterals':True,'replacements':replacements,'numericTokenReplacement':{'783088453':783087639},'scope':'Only exact successor identities, input hashes, one explicit shared explorer exception and exclusive output directory changed. Transport/ZIP/MIME/deadline/retry/authority kernels identical. Current first-deployment originals untouched.','originalLegacyRowsPreserved':802,'originalCanonicalRowsPreserved':798,'inventory':{'files':1490,'bytes':783087639,'sha256':sha((C/'expected-inventory.json').read_bytes())},'sourceLockSha256':sha((C/'source-lock.json').read_bytes()),'unknownIDs':['deploymentId','deploymentStatusId','receiptArtifactId'],'operationalCollectorsExecuted':False,'publicRequests':0,'reviewedRequestCreated':False})
print(json.dumps({'collectorSha256':sha((D/'collect-hosted.proposed.py').read_bytes()),'adaptationSha256':sha((D/'adaptation.diff').read_bytes()),'sourceLockSha256':sha((C/'source-lock.json').read_bytes())},indent=2))
