# Archive03 shared-explorer successor verification

Prepared for root review; no operational GET collector or second public audit has run. Actual source a58c47fe5d5c77c7acbb1d41c074dca1ede975c0, merge1eff31098cc79cf923f4429fe6dd8d97f520972a, treea574fdae893f46de18c9108a55c8be220eb5dc19, PR4, automatic run35222747833 attempt1. Deployment/status/receipt IDs remain unbound until actual terminal originals are collected.

`collect-hosted.proposed.py` is the prior reviewed bounded GET-only collector with literal-only source/tree/PR/output/byte-count changes. It reads the exact successful run, both jobs, current main/tree, latest linked deployment/status, and downloads only the reviewed-name small verification receipt. The receipt ZIP must be under10MiB, have exactly six allowed members, and match descriptor SHA/size and the four original cohort proofs. It retains job logs and all attempts under `../p05-v0603-retention-plan/audit-explorer-originals/`. Never download the large Pages/site artifact. Root must authorize this execution first:

```
python3 -B .cache/p05-archive03-explorer-public-audit/collect-hosted.proposed.py
```

After actual intake, prepare `execution-request.proposed.json` with reviewed:false and seven exact original pins. Root review creates a separate approved request. Bind the wrapper/reconciler sentinel to its exact SHA; do not remove the sentinel guard. Only then run before → six-worker full HTTP audit → after, retaining stdout/stderr/exit, and reconcile all original rows/attempts offline.

This successor inventory has1,490 files /783,087,639 bytes. Shared `releases/index.html` is the only deliberate original-row exception; all802 other original rows and798 canonical historical rows remain exact. Every row, including the new bridge, receives full streamed body/hash/size/status/final-URL/MIME verification. Before/after authority, 64KiB chunks,25s socket/90s attempt/1800s total, three attempts maximum and no payload persistence are unchanged. All17 existing offline cases pass; ASTs are identical after constants are erased.

First-deployment audit, its two transport retries and the native navigation failure remain untouched in `../p05-archive03-public-audit/` and the retained native originals. A passing successor HTTP audit is not native acceptance: root must verify the actual title Release explorer reaches the main live catalog and browser Back, plus retained edition play within its stated limits. No main selector or admission is changed by these helpers.
