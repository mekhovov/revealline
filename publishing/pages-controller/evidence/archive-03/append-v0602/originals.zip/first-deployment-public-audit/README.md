# Archive03 public verification — actual receipt intake ready

Actual source 00925a6e796ff920d3d9ea05e6006196251d70af merged as d6f7c3558004d4b13109e7037b48192330aaa0fb with exact tree 7a8901a7632887104d8dcb7fec488543594a5771. Automatic run 35221206781 attempt 1 and both jobs passed. GET-only collector executed once after root review: deployment 6502627452 / status 18473782474; small artifact 10497376178 is 79,723 bytes, SHA 793a5441591906e156bcd58431889eebf69cb3700c7431d6f06c89b05f606c4e. No large Pages or original release payload downloaded.

All six allowed ZIP members, four original release cohort receipts and 1,490-file / 783,088,453-byte inventory matched. All 39 retained originals rehashed. Original APIs/attempts/job logs/ZIP/members live at `../p05-v0603-retention-plan/audit-binding-originals/`. `intake-binding-review.json` binds this scoped intake; no public-body or native acceptance is implied.

## Root review and execution

`execution-request.proposed.json` has reviewed:false and actual seven original pins. SHA b75ca40eea587f11ea408f106f5467bd2ed8709d069654bc2247a2689e435591. Preserve pending and source-only proposals. Root must review the exact identities and originals, then create a separate `execution-request.reviewed.json`; changing the boolean is explicit root approval, not preparation.

After approval, readiness and operations are:

```sh
python3 -B .cache/p05-archive03-public-audit/http-tools/http_audit.py
python3 -B .cache/p05-archive03-public-audit/collect-live.py before
python3 -B .cache/p05-archive03-public-audit/http-tools/http_audit.py --run --workers 6
python3 -B .cache/p05-archive03-public-audit/collect-live.py after
```

Retain each stdout/stderr/exit. The optional `run-reviewed-operations.py.template` and independent `reconcile-completed-rows.py.template` require literal binding to the actual reviewed request SHA before promotion to their executable filenames. Their exact hash sentinel is `UNBOUND_REVIEWED_REQUEST_SHA256`; do not remove this guard. Neither wrapper has been executed. The reconciliation must wait until actual before/report/after outputs exist, preserve all attempts/retries and bind every path, hash, MIME and authority original. Old cohort count is 798; the additional unconditional old-inventory rule preserves all 803 old rows, including legacy HTML/JSON.

## Reused bounds / preparation evidence

Predecessor original helper bodies are retained. `adaptation.diff` changes only fixed site/source/tree/count/cohort data, input pins and held-checkout path; transport loops, retry ceilings, timeouts, MIME policy, one-byte oversize check, no-redirect policy and exact original validation remain. The fixed receipt list expands from two to four original release versions. Each HTTP body is streamed and hashed without saving payloads; 64 KiB chunks, 25-second socket/90-second attempt/1,800-second total, maximum 3 attempts and 4–8 workers remain unchanged. Small receipt download is <10MiB; extraction <64MB; binding member proof remains ≤1MiB.

All 17 offline mocked transport fixtures pass. Initial naive numeric substitution changed a digit substring inside a SHA; the candidate-pin fixture caught it. `initial-adaptation/` and `checks-initial-pin-failure/` preserve the original failure. Corrected substitution targets numeric tokens only; `checks/` retains the complete 17-case passing result. No public body requests occurred during preparation. Native acceptance, admission and main selector remain root-owned and separate.
